package com.ags.health.hr.admin.security;

import com.ags.health.hr.admin.services.AccessResolverService;
import io.jsonwebtoken.Claims;
import io.jsonwebtoken.JwtException;
import io.jsonwebtoken.JwtParser;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.io.Decoders;
import io.jsonwebtoken.security.Keys;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.filter.OncePerRequestFilter;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * Verifies the auth-services JWT signature (HS256, Base64-decoded secret - exactly like JwtService and the
 * gateway JwtUtil) and loads the caller's effective access. Authorities produced:
 * <ul>
 *   <li>{@code ROLE_<role>} for {@code hasRole('SUPER_ADMIN')}</li>
 *   <li>{@code <OBJECT>:<ACTION>} for {@code hasAuthority('USER:MANAGE')}</li>
 * </ul>
 * An inactive user stays authenticated (identity is valid) but has no roles and no permissions.
 */
@Slf4j
public class JwtAuthFilter extends OncePerRequestFilter {

    private final JwtParser parser;
    private final AccessResolverService accessResolver;
    private final ProblemResponseWriter problems;

    public JwtAuthFilter(String base64Secret, AccessResolverService accessResolver, ProblemResponseWriter problems) {
        if (base64Secret == null || base64Secret.isBlank()) {
            throw new IllegalStateException("admin.security.jwt-secret (env JWT_SECRET) must be set");
        }
        byte[] key;
        try {
            key = Decoders.BASE64.decode(base64Secret.trim());
        } catch (RuntimeException e) {
            throw new IllegalStateException("JWT_SECRET is not valid Base64. Use the exact secret of auth-services JwtService.", e);
        }
        if (key.length < 32) {
            throw new IllegalStateException("JWT_SECRET decodes to " + key.length * 8 + " bits, HS256 needs at least 256. "
                    + "It must be the same value auth-services JwtService and gateway JwtUtil use (they Base64-decode it too), "
                    + "otherwise no token issued at login will be accepted here.");
        }
        this.parser = Jwts.parserBuilder()
                .setSigningKey(Keys.hmacShaKeyFor(key))
                .build();
        this.accessResolver = accessResolver;
        this.problems = problems;
    }

    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain chain)
            throws ServletException, IOException {
        String header = request.getHeader(HttpHeaders.AUTHORIZATION);
        if (header == null || SecurityContextHolder.getContext().getAuthentication() != null) {
            chain.doFilter(request, response);
            return;
        }
        String token = header.startsWith("Bearer ") ? header.substring(7).trim() : header.trim();
        Claims claims;
        try {
            claims = parser.parseClaimsJws(token).getBody();
        } catch (JwtException | IllegalArgumentException ex) {
            log.debug("Rejected token: {}", ex.getMessage());
            problems.write(response, HttpStatus.UNAUTHORIZED, "INVALID_TOKEN", "Session expired or token invalid");
            return;
        }

        String userId = claims.get("userId") == null ? null : String.valueOf(claims.get("userId"));
        String email = claims.get("email", String.class) != null ? claims.get("email", String.class) : claims.getSubject();
        String userType = claims.get("userType") == null ? null : String.valueOf(claims.get("userType"));
        String name = claims.get("userName", String.class);

        EffectiveAccess access = accessResolver.resolve(userId, email, userType);
        List<GrantedAuthority> authorities = new ArrayList<>();
        if (access.active()) {
            access.roles().forEach(r -> authorities.add(new SimpleGrantedAuthority("ROLE_" + r)));
            access.permissions().forEach(p -> authorities.add(new SimpleGrantedAuthority(p)));
        }
        CurrentUser user = new CurrentUser(userId != null ? userId : access.userId(), email, name, userType, access);
        SecurityContextHolder.getContext().setAuthentication(new SmartieAuthentication(user, authorities));
        chain.doFilter(request, response);
    }
}
