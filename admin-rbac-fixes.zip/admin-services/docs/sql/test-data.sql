-- =====================================================================================================
-- admin-services TEST DATA - local / DEV / QA only. NEVER run on UAT or production.
--
-- Runs on PostgreSQL 13+ and H2 2.x (authdb), with or without MODE=PostgreSQL.
-- Idempotent: every insert is guarded, so running it twice changes nothing.
-- Run AFTER admin-services has started once (tables + seed roles / permissions must exist).
--
-- What you get (all e-mails @agshealth.com, all ids 7e570000-...):
--   Laura    SUPER_ADMIN (2nd admin, so the bootstrap admin is not the last one)                  smartie id sa-2
--   Megan    TA_HEAD, scope ALL                                                                   tah-1
--   Kevin    RECRUITMENT_MANAGER, scope LOB (Healthcare RCM, Medical Coding) -> Megan             rm-1
--   Diana    RECRUITMENT_MANAGER as TL, scope TEAM -> Kevin                                       tl-1
--   Amanda   RECRUITMENT_MANAGER, scope LOCATION (Chennai, Trichy) -> Megan                       rm-2
--   Paige    RECRUITER -> Diana. ALLOW OFFER:VIEW (C, expires in 30 days), DENY REPORT:VIEW       rec-1
--   Ryan     RECRUITER -> Diana. EXPIRED ALLOW CANDIDATE:EXPORT (shows as expired)                rec-2
--   Scott    RECRUITER -> Kevin. Never logged in (loginLinked = false)
--   Victor   INTERVIEWER                                                                          int-1
--   Aaron    EMPLOYEE + INTERVIEWER, ALLOW JOB:VIEW                                               emp-1
--   Derek    RECRUITER, INACTIVE with reason -> Diana                                             rec-3
--
-- Team check: Diana's team = rec-1, rec-2 (Derek is inactive). Kevin's team = Diana, Paige, Ryan, Scott (no id yet).
-- Generate a token for any of them with scripts/dev-token.sh <smartie id> <email> <userType>.
--
-- Clean up (reverse order):
--   DELETE FROM adm_audit_log WHERE entity_id LIKE '7e570000-%' OR correlation_id = 'test-data';
--   DELETE FROM adm_user_permission WHERE CAST(user_id AS VARCHAR(36)) LIKE '7e570000-%';
--   DELETE FROM adm_user_scope WHERE CAST(user_id AS VARCHAR(36)) LIKE '7e570000-%';
--   DELETE FROM adm_user_role WHERE CAST(user_id AS VARCHAR(36)) LIKE '7e570000-%';
--   UPDATE adm_app_user SET manager_id = NULL WHERE CAST(id AS VARCHAR(36)) LIKE '7e570000-%';
--   DELETE FROM adm_app_user WHERE CAST(id AS VARCHAR(36)) LIKE '7e570000-%';
-- =====================================================================================================

-- ---------- 1. users (managers first, the manager_id foreign key needs them) ----------
INSERT INTO adm_app_user (id, smartie_user_id, email, full_name, employee_code, user_type, status, scope_level, manager_id, created_by)
SELECT CAST('7e570000-0000-4000-8000-000000000001' AS UUID), 'sa-2', 'laura.m@agshealth.com', 'Laura Mitchell', 'AGS90001', 'EMPLOYEE_HR_ADMIN', 'ACTIVE', NULL, NULL, 'test-data'
WHERE NOT EXISTS (SELECT 1 FROM adm_app_user WHERE email = 'laura.m@agshealth.com');
INSERT INTO adm_app_user (id, smartie_user_id, email, full_name, employee_code, user_type, status, scope_level, manager_id, created_by)
SELECT CAST('7e570000-0000-4000-8000-000000000002' AS UUID), 'tah-1', 'megan.s@agshealth.com', 'Megan Sullivan', 'AGS90002', 'EMPLOYEE_HR_ADMIN', 'ACTIVE', NULL, NULL, 'test-data'
WHERE NOT EXISTS (SELECT 1 FROM adm_app_user WHERE email = 'megan.s@agshealth.com');
INSERT INTO adm_app_user (id, smartie_user_id, email, full_name, employee_code, user_type, status, scope_level, manager_id, created_by)
SELECT CAST('7e570000-0000-4000-8000-000000000003' AS UUID), 'rm-1', 'kevin.w@agshealth.com', 'Kevin Walsh', 'AGS90003', 'EMPLOYEE_HR_ADMIN', 'ACTIVE', 'LOB', CAST('7e570000-0000-4000-8000-000000000002' AS UUID), 'test-data'
WHERE NOT EXISTS (SELECT 1 FROM adm_app_user WHERE email = 'kevin.w@agshealth.com');
INSERT INTO adm_app_user (id, smartie_user_id, email, full_name, employee_code, user_type, status, scope_level, manager_id, created_by)
SELECT CAST('7e570000-0000-4000-8000-000000000004' AS UUID), 'tl-1', 'diana.r@agshealth.com', 'Diana Reed', 'AGS90004', 'EMPLOYEE_HR_ADMIN', 'ACTIVE', 'TEAM', CAST('7e570000-0000-4000-8000-000000000003' AS UUID), 'test-data'
WHERE NOT EXISTS (SELECT 1 FROM adm_app_user WHERE email = 'diana.r@agshealth.com');
INSERT INTO adm_app_user (id, smartie_user_id, email, full_name, employee_code, user_type, status, scope_level, manager_id, created_by)
SELECT CAST('7e570000-0000-4000-8000-000000000005' AS UUID), 'rm-2', 'amanda.m@agshealth.com', 'Amanda Moore', 'AGS90005', 'EMPLOYEE_HR_ADMIN', 'ACTIVE', 'LOCATION', CAST('7e570000-0000-4000-8000-000000000002' AS UUID), 'test-data'
WHERE NOT EXISTS (SELECT 1 FROM adm_app_user WHERE email = 'amanda.m@agshealth.com');
INSERT INTO adm_app_user (id, smartie_user_id, email, full_name, employee_code, user_type, status, scope_level, manager_id, created_by)
SELECT CAST('7e570000-0000-4000-8000-000000000006' AS UUID), 'rec-1', 'paige.r@agshealth.com', 'Paige Roberts', 'AGS90006', 'EMPLOYEE_HR', 'ACTIVE', NULL, CAST('7e570000-0000-4000-8000-000000000004' AS UUID), 'test-data'
WHERE NOT EXISTS (SELECT 1 FROM adm_app_user WHERE email = 'paige.r@agshealth.com');
INSERT INTO adm_app_user (id, smartie_user_id, email, full_name, employee_code, user_type, status, scope_level, manager_id, created_by)
SELECT CAST('7e570000-0000-4000-8000-000000000007' AS UUID), 'rec-2', 'ryan.c@agshealth.com', 'Ryan Carter', 'AGS90007', 'EMPLOYEE_HR', 'ACTIVE', NULL, CAST('7e570000-0000-4000-8000-000000000004' AS UUID), 'test-data'
WHERE NOT EXISTS (SELECT 1 FROM adm_app_user WHERE email = 'ryan.c@agshealth.com');
INSERT INTO adm_app_user (id, smartie_user_id, email, full_name, employee_code, user_type, status, scope_level, manager_id, created_by)
SELECT CAST('7e570000-0000-4000-8000-000000000008' AS UUID), NULL, 'scott.p@agshealth.com', 'Scott Parker', 'AGS90008', 'EMPLOYEE_HR', 'ACTIVE', NULL, CAST('7e570000-0000-4000-8000-000000000003' AS UUID), 'test-data'
WHERE NOT EXISTS (SELECT 1 FROM adm_app_user WHERE email = 'scott.p@agshealth.com');
INSERT INTO adm_app_user (id, smartie_user_id, email, full_name, employee_code, user_type, status, scope_level, manager_id, created_by)
SELECT CAST('7e570000-0000-4000-8000-000000000009' AS UUID), 'int-1', 'victor.a@agshealth.com', 'Victor Adams', 'AGS90009', 'EMPLOYEE_NON_HR', 'ACTIVE', NULL, NULL, 'test-data'
WHERE NOT EXISTS (SELECT 1 FROM adm_app_user WHERE email = 'victor.a@agshealth.com');
INSERT INTO adm_app_user (id, smartie_user_id, email, full_name, employee_code, user_type, status, scope_level, manager_id, created_by)
SELECT CAST('7e570000-0000-4000-8000-000000000010' AS UUID), 'emp-1', 'aaron.c@agshealth.com', 'Aaron Cooper', 'AGS90010', 'EMPLOYEE_NON_HR', 'ACTIVE', NULL, NULL, 'test-data'
WHERE NOT EXISTS (SELECT 1 FROM adm_app_user WHERE email = 'aaron.c@agshealth.com');
INSERT INTO adm_app_user (id, smartie_user_id, email, full_name, employee_code, user_type, status, scope_level, manager_id, status_changed_date, status_changed_by, status_reason, created_by)
SELECT CAST('7e570000-0000-4000-8000-000000000011' AS UUID), 'rec-3', 'derek.j@agshealth.com', 'Derek Johnson', 'AGS90011', 'EMPLOYEE_HR', 'INACTIVE', NULL, CAST('7e570000-0000-4000-8000-000000000004' AS UUID), CURRENT_TIMESTAMP - INTERVAL '15' DAY, 'first.admin@agshealth.com', 'Left the organisation on 15-Sep-2026', 'test-data'
WHERE NOT EXISTS (SELECT 1 FROM adm_app_user WHERE email = 'derek.j@agshealth.com');

-- ---------- 2. roles (looked up by code, so the seed UUIDs do not matter) ----------
INSERT INTO adm_user_role (user_id, role_id) SELECT CAST('7e570000-0000-4000-8000-000000000001' AS UUID), r.id FROM adm_role r WHERE r.code = 'SUPER_ADMIN'
  AND NOT EXISTS (SELECT 1 FROM adm_user_role x WHERE x.user_id = CAST('7e570000-0000-4000-8000-000000000001' AS UUID) AND x.role_id = r.id);
INSERT INTO adm_user_role (user_id, role_id) SELECT CAST('7e570000-0000-4000-8000-000000000002' AS UUID), r.id FROM adm_role r WHERE r.code = 'TA_HEAD'
  AND NOT EXISTS (SELECT 1 FROM adm_user_role x WHERE x.user_id = CAST('7e570000-0000-4000-8000-000000000002' AS UUID) AND x.role_id = r.id);
INSERT INTO adm_user_role (user_id, role_id) SELECT CAST('7e570000-0000-4000-8000-000000000003' AS UUID), r.id FROM adm_role r WHERE r.code = 'RECRUITMENT_MANAGER'
  AND NOT EXISTS (SELECT 1 FROM adm_user_role x WHERE x.user_id = CAST('7e570000-0000-4000-8000-000000000003' AS UUID) AND x.role_id = r.id);
INSERT INTO adm_user_role (user_id, role_id) SELECT CAST('7e570000-0000-4000-8000-000000000004' AS UUID), r.id FROM adm_role r WHERE r.code = 'RECRUITMENT_MANAGER'
  AND NOT EXISTS (SELECT 1 FROM adm_user_role x WHERE x.user_id = CAST('7e570000-0000-4000-8000-000000000004' AS UUID) AND x.role_id = r.id);
INSERT INTO adm_user_role (user_id, role_id) SELECT CAST('7e570000-0000-4000-8000-000000000005' AS UUID), r.id FROM adm_role r WHERE r.code = 'RECRUITMENT_MANAGER'
  AND NOT EXISTS (SELECT 1 FROM adm_user_role x WHERE x.user_id = CAST('7e570000-0000-4000-8000-000000000005' AS UUID) AND x.role_id = r.id);
INSERT INTO adm_user_role (user_id, role_id) SELECT CAST('7e570000-0000-4000-8000-000000000006' AS UUID), r.id FROM adm_role r WHERE r.code = 'RECRUITER'
  AND NOT EXISTS (SELECT 1 FROM adm_user_role x WHERE x.user_id = CAST('7e570000-0000-4000-8000-000000000006' AS UUID) AND x.role_id = r.id);
INSERT INTO adm_user_role (user_id, role_id) SELECT CAST('7e570000-0000-4000-8000-000000000007' AS UUID), r.id FROM adm_role r WHERE r.code = 'RECRUITER'
  AND NOT EXISTS (SELECT 1 FROM adm_user_role x WHERE x.user_id = CAST('7e570000-0000-4000-8000-000000000007' AS UUID) AND x.role_id = r.id);
INSERT INTO adm_user_role (user_id, role_id) SELECT CAST('7e570000-0000-4000-8000-000000000008' AS UUID), r.id FROM adm_role r WHERE r.code = 'RECRUITER'
  AND NOT EXISTS (SELECT 1 FROM adm_user_role x WHERE x.user_id = CAST('7e570000-0000-4000-8000-000000000008' AS UUID) AND x.role_id = r.id);
INSERT INTO adm_user_role (user_id, role_id) SELECT CAST('7e570000-0000-4000-8000-000000000009' AS UUID), r.id FROM adm_role r WHERE r.code = 'INTERVIEWER'
  AND NOT EXISTS (SELECT 1 FROM adm_user_role x WHERE x.user_id = CAST('7e570000-0000-4000-8000-000000000009' AS UUID) AND x.role_id = r.id);
INSERT INTO adm_user_role (user_id, role_id) SELECT CAST('7e570000-0000-4000-8000-000000000010' AS UUID), r.id FROM adm_role r WHERE r.code = 'EMPLOYEE'
  AND NOT EXISTS (SELECT 1 FROM adm_user_role x WHERE x.user_id = CAST('7e570000-0000-4000-8000-000000000010' AS UUID) AND x.role_id = r.id);
INSERT INTO adm_user_role (user_id, role_id) SELECT CAST('7e570000-0000-4000-8000-000000000010' AS UUID), r.id FROM adm_role r WHERE r.code = 'INTERVIEWER'
  AND NOT EXISTS (SELECT 1 FROM adm_user_role x WHERE x.user_id = CAST('7e570000-0000-4000-8000-000000000010' AS UUID) AND x.role_id = r.id);
INSERT INTO adm_user_role (user_id, role_id) SELECT CAST('7e570000-0000-4000-8000-000000000011' AS UUID), r.id FROM adm_role r WHERE r.code = 'RECRUITER'
  AND NOT EXISTS (SELECT 1 FROM adm_user_role x WHERE x.user_id = CAST('7e570000-0000-4000-8000-000000000011' AS UUID) AND x.role_id = r.id);

-- ---------- 3. data scope values for LOB / LOCATION users ----------
INSERT INTO adm_user_scope (user_id, dimension, scope_value) SELECT CAST('7e570000-0000-4000-8000-000000000003' AS UUID), 'LOB', 'Healthcare RCM'
WHERE NOT EXISTS (SELECT 1 FROM adm_user_scope WHERE user_id = CAST('7e570000-0000-4000-8000-000000000003' AS UUID) AND dimension = 'LOB' AND scope_value = 'Healthcare RCM');
INSERT INTO adm_user_scope (user_id, dimension, scope_value) SELECT CAST('7e570000-0000-4000-8000-000000000003' AS UUID), 'LOB', 'Medical Coding'
WHERE NOT EXISTS (SELECT 1 FROM adm_user_scope WHERE user_id = CAST('7e570000-0000-4000-8000-000000000003' AS UUID) AND dimension = 'LOB' AND scope_value = 'Medical Coding');
INSERT INTO adm_user_scope (user_id, dimension, scope_value) SELECT CAST('7e570000-0000-4000-8000-000000000005' AS UUID), 'LOCATION', 'Chennai'
WHERE NOT EXISTS (SELECT 1 FROM adm_user_scope WHERE user_id = CAST('7e570000-0000-4000-8000-000000000005' AS UUID) AND dimension = 'LOCATION' AND scope_value = 'Chennai');
INSERT INTO adm_user_scope (user_id, dimension, scope_value) SELECT CAST('7e570000-0000-4000-8000-000000000005' AS UUID), 'LOCATION', 'Trichy'
WHERE NOT EXISTS (SELECT 1 FROM adm_user_scope WHERE user_id = CAST('7e570000-0000-4000-8000-000000000005' AS UUID) AND dimension = 'LOCATION' AND scope_value = 'Trichy');

-- ---------- 4. granular user permissions (ALLOW adds, DENY removes, expired ones are ignored) ----------
INSERT INTO adm_user_permission (user_id, permission_code, effect, conditional, expires_at, reason, granted_by)
SELECT CAST('7e570000-0000-4000-8000-000000000006' AS UUID), 'OFFER:VIEW', 'ALLOW', TRUE, CURRENT_TIMESTAMP + INTERVAL '30' DAY, 'Covering offers for Kevin during his leave', 'first.admin@agshealth.com'
WHERE NOT EXISTS (SELECT 1 FROM adm_user_permission WHERE user_id = CAST('7e570000-0000-4000-8000-000000000006' AS UUID) AND permission_code = 'OFFER:VIEW');
INSERT INTO adm_user_permission (user_id, permission_code, effect, conditional, expires_at, reason, granted_by)
SELECT CAST('7e570000-0000-4000-8000-000000000006' AS UUID), 'REPORT:VIEW', 'DENY', FALSE, NULL, 'Contract recruiter, no report access', 'first.admin@agshealth.com'
WHERE NOT EXISTS (SELECT 1 FROM adm_user_permission WHERE user_id = CAST('7e570000-0000-4000-8000-000000000006' AS UUID) AND permission_code = 'REPORT:VIEW');
INSERT INTO adm_user_permission (user_id, permission_code, effect, conditional, expires_at, reason, granted_by)
SELECT CAST('7e570000-0000-4000-8000-000000000007' AS UUID), 'CANDIDATE:EXPORT', 'ALLOW', FALSE, CURRENT_TIMESTAMP - INTERVAL '5' DAY, 'Expired: one-time data pull for audit', 'first.admin@agshealth.com'
WHERE NOT EXISTS (SELECT 1 FROM adm_user_permission WHERE user_id = CAST('7e570000-0000-4000-8000-000000000007' AS UUID) AND permission_code = 'CANDIDATE:EXPORT');
INSERT INTO adm_user_permission (user_id, permission_code, effect, conditional, expires_at, reason, granted_by)
SELECT CAST('7e570000-0000-4000-8000-000000000010' AS UUID), 'JOB:VIEW', 'ALLOW', FALSE, NULL, 'Hiring manager for his own team openings', 'first.admin@agshealth.com'
WHERE NOT EXISTS (SELECT 1 FROM adm_user_permission WHERE user_id = CAST('7e570000-0000-4000-8000-000000000010' AS UUID) AND permission_code = 'JOB:VIEW');

-- ---------- 5. a few audit rows for the audit / user history screens ----------
INSERT INTO adm_audit_log (id, category, action, entity_type, entity_id, actor_id, actor_name, actor_email, actor_roles, outcome, description, correlation_id, service_name)
SELECT CAST('7e57a000-0000-4000-8000-000000000001' AS UUID), 'SECURITY', 'ADMIN_USER_CREATED', 'ADMIN_USER', '7e570000-0000-4000-8000-000000000006', 'sa-1', 'First Admin', 'first.admin@agshealth.com', 'SUPER_ADMIN', 'SUCCESS', 'Created Paige Roberts with role RECRUITER', 'test-data', 'admin-services'
WHERE NOT EXISTS (SELECT 1 FROM adm_audit_log WHERE id = CAST('7e57a000-0000-4000-8000-000000000001' AS UUID));
INSERT INTO adm_audit_log (id, category, action, entity_type, entity_id, actor_id, actor_name, actor_email, actor_roles, outcome, description, correlation_id, service_name)
SELECT CAST('7e57a000-0000-4000-8000-000000000002' AS UUID), 'SECURITY', 'ADMIN_USER_PERMISSIONS_CHANGED', 'ADMIN_USER', '7e570000-0000-4000-8000-000000000006', 'sa-1', 'First Admin', 'first.admin@agshealth.com', 'SUPER_ADMIN', 'SUCCESS', 'ALLOW OFFER:VIEW (C) until +30 days, DENY REPORT:VIEW', 'test-data', 'admin-services'
WHERE NOT EXISTS (SELECT 1 FROM adm_audit_log WHERE id = CAST('7e57a000-0000-4000-8000-000000000002' AS UUID));
INSERT INTO adm_audit_log (id, category, action, entity_type, entity_id, actor_id, actor_name, actor_email, actor_roles, outcome, description, correlation_id, service_name)
SELECT CAST('7e57a000-0000-4000-8000-000000000003' AS UUID), 'SECURITY', 'ADMIN_USER_DEACTIVATED', 'ADMIN_USER', '7e570000-0000-4000-8000-000000000011', 'sa-1', 'First Admin', 'first.admin@agshealth.com', 'SUPER_ADMIN', 'SUCCESS', 'Left the organisation on 15-Sep-2026', 'test-data', 'admin-services'
WHERE NOT EXISTS (SELECT 1 FROM adm_audit_log WHERE id = CAST('7e57a000-0000-4000-8000-000000000003' AS UUID));

-- ---------- 6. quick checks ----------
-- SELECT u.full_name, u.status, u.scope_level, r.code FROM adm_app_user u JOIN adm_user_role ur ON ur.user_id = u.id JOIN adm_role r ON r.id = ur.role_id WHERE u.created_by = 'test-data' ORDER BY u.full_name;
-- SELECT r.code, COUNT(u.id) AS active_users FROM adm_role r LEFT JOIN adm_user_role ur ON ur.role_id = r.id LEFT JOIN adm_app_user u ON u.id = ur.user_id AND u.status = 'ACTIVE' GROUP BY r.code ORDER BY r.code;

