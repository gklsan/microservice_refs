# admin-services - RBAC decisions and answers to the team review

Scope of this drop:

- Admin user account creation
- Admin user list - search, deactivate, reactivate
- Granular user-based permission definition
- The RBAC core these three need: roles, permission matrix, effective access, audit

Out of scope for now: access-override requests, enterprise config, master data, search filters, log viewer screen. The reference zip has them. They plug into the same tables later.

---

## 1. The model in one screen

```
auth-services   -> who you are   (login, JWT: userId, email, userType)
admin-services  -> what you can do (roles, permissions, data scope)   <- single RBAC source

effective permissions = union(active role permissions)
                      + user ALLOW grants (not expired)
                      - user DENY grants  (deny always wins)
data scope            = user scope_level, else widest default_scope of the active roles
team                  = everyone reporting to the user (manager hierarchy, recursive)
```

- Nothing about permissions goes into the JWT. admin-services resolves access on every request.
- Other services will call `GET /internal/rbac/effective` and cache it for up to 2 minutes.
- Result: a revoke or deactivation applies at once in admin-services and within 2 minutes everywhere else. No re-login and no refresh-token games.

### What "A" and "C" mean in the matrix

- A (allow): allowed on any record inside the user's data scope.
- C (conditional): allowed only on records the user owns or is assigned to. A wide scope does not help.
  - Recruiter `CANDIDATE:DELETE` (C) = only candidates the recruiter owns.
  - Interviewer `INTERVIEW:UPDATE` (C) = only interviews where they sit on the panel.
  - Super Admin `CANDIDATE:VIEW` (C) = no candidate content by default (RABAC: "no candidate-content access by default").
- The permission is still a Spring authority, so `@PreAuthorize("hasAuthority('INTERVIEW:UPDATE')")` passes at the endpoint. The service then calls `AccessEvaluator.check(...)` with the record's owner / panel ids. The same check is exposed as `POST /rbac/check`.

---

## 2. Roles

Eight roles: the seven of the architect's access matrix plus TA_HEAD. Codes are readable. The R-id stays in `legacy_code` so anyone can trace a row back to the matrix sheet.

TA_HEAD was added after the sprint-tracker review: S4 #113 "JD edit with TA Head approval" must find TA Heads by role, which is impossible if a TA Head is only a Recruitment Manager with ALL visibility.

| Code | R-id | Default scope | Who |
|---|---|---|---|
| SUPER_ADMIN | R01 | ALL | Platform owner. Users, roles, configuration |
| RECRUITER | R02 | OWN | Recruiter |
| RECRUITMENT_MANAGER | R03 | TEAM | TL, TA Manager (visibility set per user) |
| TA_HEAD | - | ALL | Head of TA: manager rights + approvals (JD edit, overrides, workflow approvals) |
| INTERVIEWER | R04 | OWN | Panel member |
| VENDOR | R05 | OWN | Agency user |
| CANDIDATE | R06 | OWN | Self-service candidate |
| EMPLOYEE | R07 | OWN | Internal employee, Buddy Finder |

Where TL, Manager and TA Head fit:

- TL and Manager hold RECRUITMENT_MANAGER. What differs is how much they see, not what they can do.
- The admin picks the visibility on the user screen:
  - TL -> TEAM (own records + everyone reporting to them)
  - Manager -> LOB (plus the LOB list, optional location list)
- TA Head holds TA_HEAD (ALL visibility, approval permissions), so approval routing can find TA Heads by role.

---

## 3. Permission matrix (seeded defaults)

Codes follow the reference services (workflow-services, notification-engine, digihire starter) so their `@PreAuthorize` checks resolve: `JOB`, `CANDIDATE`, `APPLICATION`, `WORKFLOW`, `NOTIFICATION_TEMPLATE`, `CONFIG`, `USER`, `ROLE` ... Modules of the architect's matrix the reference did not have keep VIEW / CREATE / UPDATE / DELETE. The integration test asserts every code the reference services check exists.

A = allow, C = conditional, blank = no access. Privileged permissions exist only on SUPER_ADMIN.

| Permission | SA | REC | RM | TAH | INT | VEN | CAN | EMP |
|---|---|---|---|---|---|---|---|---|
| `USER:VIEW` | A |  |  |  |  |  |  |  |
| `USER:MANAGE` (privileged) | A |  |  |  |  |  |  |  |
| `ROLE:VIEW` | A |  |  |  |  |  |  |  |
| `ROLE:MANAGE` (privileged) | A |  |  |  |  |  |  |  |
| `CONFIG:VIEW` | A |  |  |  |  |  |  |  |
| `CONFIG:MANAGE` (privileged) | A |  |  |  |  |  |  |  |
| `MASTER_DATA:MANAGE` | A |  |  |  |  |  |  |  |
| `INTEGRATION:VIEW` | A |  |  |  |  |  |  |  |
| `INTEGRATION:CREATE` (privileged) | A |  |  |  |  |  |  |  |
| `INTEGRATION:UPDATE` (privileged) | A |  |  |  |  |  |  |  |
| `AUDIT_LOG:VIEW` | A |  |  |  |  |  |  |  |
| `AUDIT_LOG:EXPORT` | A |  |  |  |  |  |  |  |
| `WORKFLOW:VIEW` | A | A | A | A |  |  |  |  |
| `WORKFLOW:CONFIGURE` | A |  |  |  |  |  |  |  |
| `WORKFLOW:PUBLISH` | A |  |  |  |  |  |  |  |
| `WORKFLOW:APPROVE` |  |  |  | A |  |  |  |  |
| `WORKFLOW:ASSIGN` | A |  |  |  |  |  |  |  |
| `WORKFLOW:DELETE` | C |  |  |  |  |  |  |  |
| `REQUISITION_TEMPLATE:VIEW` | A |  |  |  |  |  |  |  |
| `REQUISITION_TEMPLATE:CREATE` | A |  |  |  |  |  |  |  |
| `REQUISITION_TEMPLATE:UPDATE` | A |  |  |  |  |  |  |  |
| `REQUISITION_TEMPLATE:DELETE` | C |  |  |  |  |  |  |  |
| `NOTIFICATION_TEMPLATE:VIEW` | A |  |  | A |  |  |  |  |
| `NOTIFICATION_TEMPLATE:MANAGE` | A |  |  |  |  |  |  |  |
| `NOTIFICATION_TEMPLATE:SEND` |  | A | A | A |  |  |  |  |
| `RECRUITING_ANALYTICS:VIEW` | A |  |  | A |  |  |  |  |
| `ACCESS_OVERRIDE:REQUEST` |  | A | A | A |  |  |  |  |
| `ACCESS_OVERRIDE:APPROVE` |  |  | A | A |  |  |  |  |
| `JOB:VIEW` |  | A | A | A | A | C |  |  |
| `JOB:CREATE` |  |  | A | A |  |  |  |  |
| `JOB:UPDATE` |  |  | A | A |  |  |  |  |
| `JOB:DELETE` |  |  | C | C |  |  |  |  |
| `JOB:PUBLISH` |  |  | A | A |  |  |  |  |
| `JOB:EDIT_JD` |  |  | A | A |  |  |  |  |
| `JOB:MAP` |  | A | A | A |  |  |  |  |
| `CANDIDATE:VIEW` | C | A | A | A |  |  |  |  |
| `CANDIDATE:CREATE` |  | A | A | A |  |  |  |  |
| `CANDIDATE:UPDATE` | C | A | A | A |  |  |  |  |
| `CANDIDATE:DELETE` |  | C | C | C |  |  |  |  |
| `CANDIDATE:EXPORT` | C |  | A | A |  |  |  |  |
| `CANDIDATE:VIEW_SENSITIVE` |  |  |  |  |  |  |  |  |
| `CANDIDATE_SUMMARY:VIEW` |  |  | C | C | C |  |  |  |
| `APPLICATION:VIEW` |  | A | A | A | C |  |  |  |
| `APPLICATION:CREATE` |  | A | A | A |  |  |  |  |
| `APPLICATION:UPDATE` |  | A | A | A |  |  |  |  |
| `APPLICATION:DELETE` |  | C | C | C |  |  |  |  |
| `APPLICATION:MAP` |  | A | A | A |  |  |  |  |
| `APPLICATION:REJECT` |  | A | A | A |  |  |  |  |
| `APPLICATION:HOLD` |  | A | A | A |  |  |  |  |
| `APPLICATION:SCHEDULE_INTERVIEW` |  | A | A | A |  |  |  |  |
| `APPLICATION:MOVE_STAGE` |  | A | A | A |  |  |  |  |
| `APPLICATION:BULK_UPDATE` |  |  | A | A |  |  |  |  |
| `INTERVIEW:VIEW` |  | A |  |  | C |  |  |  |
| `INTERVIEW:CREATE` |  | A |  |  |  |  |  |  |
| `INTERVIEW:UPDATE` |  | A |  |  | C |  |  |  |
| `INTERVIEW:DELETE` |  | C |  |  |  |  |  |  |
| `INTERVIEW_FEEDBACK:VIEW` |  |  |  |  | A |  |  |  |
| `INTERVIEW_FEEDBACK:CREATE` |  |  |  |  | A |  |  |  |
| `INTERVIEW_FEEDBACK:UPDATE` |  |  |  |  | A |  |  |  |
| `OTHER_PANEL_FEEDBACK:VIEW` |  |  |  |  | C |  |  |  |
| `SELECTION:VIEW` |  | A |  |  |  |  |  |  |
| `SELECTION:CREATE` |  | A |  |  |  |  |  |  |
| `SELECTION:UPDATE` |  | A |  |  |  |  |  |  |
| `SELECTION:DELETE` |  | C |  |  |  |  |  |  |
| `SELECTION_OFFER:VIEW` |  | A | A | A |  |  |  |  |
| `SELECTION_OFFER:CREATE` |  |  | C | C |  |  |  |  |
| `SELECTION_OFFER:UPDATE` |  |  | A | A |  |  |  |  |
| `SELECTION_OFFER:DELETE` |  |  | C | C |  |  |  |  |
| `OFFER:VIEW` |  |  |  |  | C |  |  |  |
| `OFFER_APPROVAL_QUEUE:VIEW` |  |  | A | A |  |  |  |  |
| `REPORT:VIEW` |  | A | A | A |  |  |  |  |
| `CANDIDATE_SUBMISSION:VIEW` |  |  |  |  |  | A |  |  |
| `CANDIDATE_SUBMISSION:CREATE` |  |  |  |  |  | A |  |  |
| `CANDIDATE_SUBMISSION:UPDATE` |  |  |  |  |  | C |  |  |
| `CANDIDATE_STATUS:VIEW` |  |  |  |  |  | C |  |  |
| `JOB_OPPORTUNITY:VIEW` |  |  |  |  |  |  | A |  |
| `CANDIDATE_SELF:VIEW` |  |  |  |  |  |  | A |  |
| `CANDIDATE_SELF:CREATE` |  |  |  |  |  |  | A |  |
| `CANDIDATE_SELF:UPDATE` |  |  |  |  |  |  | A |  |
| `CANDIDATE_SELF:DELETE` |  |  |  |  |  |  | C |  |
| `APPLICATION_SELF:VIEW` |  |  |  |  |  |  | A |  |
| `APPLICATION_SELF:CREATE` |  |  |  |  |  |  | A |  |
| `APPLICATION_SELF:UPDATE` |  |  |  |  |  |  | C |  |
| `APPLICATION_SELF:DELETE` |  |  |  |  |  |  | C |  |
| `INTERVIEW_SCHEDULE:VIEW` |  |  |  |  |  |  | A |  |
| `INTERVIEW_SCHEDULE:UPDATE` |  |  |  |  |  |  | C |  |
| `OFFER_SELF:VIEW` |  |  |  |  |  |  | A |  |
| `OFFER_SELF:UPDATE` |  |  |  |  |  |  | C |  |
| `CONSENT_PRIVACY:VIEW` |  |  |  |  |  |  | A |  |
| `CONSENT_PRIVACY:CREATE` |  |  |  |  |  |  | A |  |
| `CONSENT_PRIVACY:UPDATE` |  |  |  |  |  |  | C |  |
| `EMPLOYEE_PROFILE:VIEW` |  |  |  |  |  |  |  | A |
| `EMPLOYEE_PROFILE:UPDATE` |  |  |  |  |  |  |  | C |
| `EMPLOYEE_REFERRAL:VIEW` |  |  |  |  |  |  |  | A |
| `EMPLOYEE_REFERRAL:CREATE` |  |  |  |  |  |  |  | A |
| `EMPLOYEE_REFERRAL:UPDATE` |  |  |  |  |  |  |  | C |
| `EMPLOYEE_REFERRAL:DELETE` |  |  |  |  |  |  |  | C |
| `INTERVIEW_ASSIGNMENT:VIEW` |  |  |  |  |  |  |  | C |

UX changes against the architect's literal matrix (each one answers a review question, see section 5):

- Recruitment Manager gets UPDATE on candidates and applications (was delete-but-not-edit).
- Interviewer sees a candidate summary instead of the full profile, and only for assigned candidates.
- Interviewer has no create / delete on interviews. UPDATE only on interviews they are assigned to.
- Interviewer pipeline and offers are conditional (assigned candidates only).
- Candidate DELETE on profile / applications means "close account" / "withdraw". The owning service must do a soft delete. The architect's matrix said delete, the code today hard-deletes (see open items).

---

## 4. Admin screen rules (server-enforced)

- Only an active SUPER_ADMIN can create users, change roles, change grants, deactivate or reactivate (`USER:MANAGE`), change roles / matrix (`ROLE:MANAGE`) or enterprise configuration (`CONFIG:MANAGE`). Reading needs `USER:VIEW` / `ROLE:VIEW` / `CONFIG:VIEW`.
- Nobody can change their own account: roles, grants, scope, manager or status. Another Super Admin must do it (`SELF_MODIFICATION_NOT_ALLOWED`).
- The last active Super Admin can not be deactivated or lose the role (`LAST_SUPER_ADMIN`). A row lock stops two admins from removing each other at the same second.
- SUPER_ADMIN role can not be retired and must keep `USER:VIEW/MANAGE`, `ROLE:VIEW/MANAGE`, `CONFIG:VIEW/MANAGE` unconditionally.
- Privileged permissions (`USER:MANAGE`, `ROLE:MANAGE`, `CONFIG:MANAGE`, `INTEGRATION:CREATE/UPDATE`) live only on SUPER_ADMIN. They can not be added to another role or given as a user-level grant.
- CANDIDATE and VENDOR roles can not be given from the admin screen. Those come from registration and vendor onboarding.
- Deactivation needs a reason. Deactivate / reactivate are idempotent.
- Users are never deleted. Roles are never deleted, they are retired (`active=false`) and stop granting anything on the next request.
- Every change writes `adm_audit_log` with before / after / added / removed, actor and correlation id, in the same transaction.

---

## 5. Answers to the review questions

### Overall

Q. admin-services already manages roles and permissions. Keep one RBAC system?
- Yes. auth-services stays identity only. admin-services is the only place that answers "what can this user do".
- Two systems would give two answers to the same question. Most of the bugs raised below come from that split.

Q. Where do TL, TA Head and Manager fit? How does "my team / my LOB / my location" work?
- One role, RECRUITMENT_MANAGER. Visibility is per user: TEAM, LOB, LOCATION or ALL (section 2).
- TEAM uses the manager hierarchy (`manager_id`, recursive query, inactive users skipped).
- LOB / LOCATION use the values set on the user. `AccessEvaluator` applies them per record.

### Bugs in the proposed auth-services design

Q. Conditional permissions are left out of perms, so they can never be allowed.
- Fixed by design. Conditional permissions ARE in the permission set, flagged in `conditionalPermissions`. `AccessEvaluator` allows them on owned / assigned records only.

Q. A retired role still grants its permissions at next login.
- Not possible here. Access is resolved on every request and only active roles count. Test: `retiringARoleRemovesItsPermissionsOnTheNextRequest`.

Q. After the backfill nobody has R01. Who manages roles on day one?
- `BOOTSTRAP_SUPER_ADMIN_EMAILS`. Every start makes those e-mails active SUPER_ADMINs (idempotent, audited). It is also the break-glass path.

Q. Which role does a user who registers after the migration get?
- No backfill at all. A user without an admin record gets the fallback role of their userType, live: CANDIDATE -> CANDIDATE, VENDOR -> VENDOR, EMPLOYEE_NON_HR -> EMPLOYEE, EMPLOYEE_HR -> RECRUITER, EMPLOYEE_HR_ADMIN -> RECRUITMENT_MANAGER.
- The fallback can never give SUPER_ADMIN, even if someone configures it.

Q. JwtService Base64-decodes the secret, the filter uses `getBytes()`. Will signatures match?
- admin-services uses `Decoders.BASE64.decode`, the same as auth-services and the gateway. The integration test signs tokens that way.
- The secret comes from `JWT_SECRET`. The hardcoded copies in JwtService and JwtUtil should move to the same env variable.

Q. Deleting the refresh token leaves the access token alive for an hour.
- Not used. Nothing is baked into the token, so there is nothing to outlive. A deactivated user keeps a valid login but has zero permissions on the next request.

Q. Delete-then-insert on a kept permission hits the unique constraint.
- Role and user permissions are element collections. A full replace assigns a new collection, so Hibernate deletes the owner's rows first and inserts after. Test: `granularPermissionsReplaceWithoutPrimaryKeyClash` keeps a permission and flips its flag.

Q. RoleAssignmentService has no `@Transactional`.
- Every service here is class-level `@Transactional`. Audit rows use the same transaction.

Q. What sets currentUserId for grant / revoke?
- Always the verified JWT, through `SecurityUtils`. Never a request field.

Q. Authz is both `@Component` and `@Bean`.
- No custom bean. Plain `hasRole` / `hasAuthority`.

Q. Security config lives in common-utils. How is it picked up?
- admin-services owns its own `SecurityConfig`. When other services adopt RBAC, the shared piece goes in smartie-common-utils and registers through `META-INF/spring/...AutoConfiguration.imports`, the same way `TomcatSecurityConfig` is already picked up. Package scanning is not involved.

Q. With `anyRequest().authenticated()`, how do login, registration and public job / kiosk pages work?
- They stay in auth-services, which the gateway leaves open. admin-services has no public page, only health checks.
- When other services adopt this, each one lists its public paths. Rollout is one service at a time, so this is checked per service.

Q. Is the table `smartieuser` or `smartie_user`?
- admin-services never joins it. It links by e-mail and stores the smartie user id as text.
- The knowledge base disagrees with itself on the id type (UUID in 10-auth-services, BIGINT in 90-open-questions). Text works for both.

Q. No Flyway, deploys run from bash. Plain SQL?
- Yes. `db/schema-admin.sql` and `db/data-admin.sql` run on every start through `spring.sql.init`. Both are idempotent. No extra deploy step. Hibernate runs with `ddl-auto=validate`.

Q. Can the RDS user run `CREATE EXTENSION pgcrypto`?
- Not needed. `gen_random_uuid()` is built into PostgreSQL 13+. Confirm RDS is 13 or newer.

### Design issues

Q. What stops retiring R01, stripping its permissions, revoking the last Super Admin, or self-granting?
- All four are blocked. See section 4.

Q. Role and permission changes are not audited.
- They are: ROLE_CREATED, ROLE_UPDATED, ROLE_RETIRED, ROLE_RESET_TO_DEFAULTS, PERMISSION_MATRIX_UPDATED, ADMIN_USER_* events, all in `adm_audit_log`.

Q. Null permissions, grant already exists, revoke a role the user does not have?
- Roles and grants are full-replace PUTs. Null is a 400. Duplicate roles collapse. A permission listed twice is a 400 (`DUPLICATE_PERMISSION`) so the admin sees the conflict. Removing a role is "don't list it", so revoking a missing role can not fail. Sending the same body twice changes nothing and writes no audit row.

Q. `APIException` is called with two strings, the codebase uses (message, status).
- admin-services has `APIException(HttpStatus, code, message)` with `badRequest / conflict / forbidden / notFound`. The status is explicit, not guessed from message text like in the other services.

Q. Do we need a "create permission" API?
- No. A permission does nothing until code checks it. New permissions come in `data-admin.sql` with the code that checks them, in the same pull request.

Q. Readable role codes instead of R01-R07?
- Yes. R-ids kept in `legacy_code`.

Q. Permissions as Spring authorities?
- Yes. `ROLE_<code>` for roles and `<OBJECT>:<ACTION>` for permissions.

Q. A typo in a seeded permission code is dropped silently by the JOIN.
- `adm_default_role_permission` has foreign keys to `adm_role` and `adm_permission`. A typo stops the start-up with a clear error. Checked on PostgreSQL 16.

### Permission matrix questions (answered from the user's point of view)

Q. Recruitment Manager can delete candidate profiles and pipeline entries but not edit them?
- A supervisor who can remove a record but can not fix a typo in it will delete and ask the recruiter to recreate. That is worse for data and audit. Manager now has EDIT (A) and keeps DELETE as C.

Q. Should an Interviewer delete any interview when a Recruiter needs a condition?
- No. Panel members don't schedule, recruiters do (BRD 4.12). An interviewer who cannot attend needs "decline / ask to reschedule", which is an EDIT on their own interview. INTERVIEW for Interviewer is now VIEW (C) and EDIT (C). No create, no delete.

Q. Deleting a candidate should use its own permission, not USERS_ROLES_DELETE?
- Yes. `CANDIDATE:DELETE` is its own permission. Deactivating an admin user is part of `USER:MANAGE`.

Q. Panel members become R07 in the backfill. How do they get R04?
- No backfill. The admin adds INTERVIEWER to the employee from the user screen. A user can hold several roles, so a panel member is EMPLOYEE + INTERVIEWER.

Q. Should an Interviewer see full candidate profiles?
- No. They need experience, skills, resume and earlier feedback to interview well. They do not need ID proofs, contact details or salary. Interviewer gets `CANDIDATE_SUMMARY:VIEW` (C, assigned candidates only) instead of `CANDIDATE:VIEW`. The architect's sheet had two conflicting R04 rows for this. This settles them.

---

## 6. Open items that need a decision from you

- Candidate "delete" today is a hard delete in candidate-services (`candidateRepository.deleteById`). The matrix says candidates can delete their profile and applications. I made it C and wrote "close account / withdraw". Confirm with the business before candidate-services is wired, because hard delete loses the audit trail.
- Recruitment Manager has no INTERVIEW access in the architect's matrix. A manager reviewing a pipeline will likely want to see interviews. One matrix-screen change if you agree.
- The architect's matrix is incomplete for BRD roles like HR Ops and Offer Approver (role catalog R08, R09). Create them from the matrix screen when needed.
- RDS PostgreSQL version must be 13+.
- Deactivating a manager keeps their reports pointing at them. The audit row records how many active reports they had. Decide whether the UI should force re-assignment first.


---

## 7. Sprint tracker check (P5-S1 and what later sprints need)

| Tracker | Status in this drop |
|---|---|
| #1-3 Default permission set - Job / Candidate / Application | Done. `GET /admin/permission-matrix/defaults?objectType=JOB` |
| #22 Admin user account creation | Done |
| #23 Admin user list - search, deactivate, reactivate | Done |
| #24 Granular user-based permission definition | Done (ALLOW / DENY, conditional, expiry) |
| #25 Role-to-permission mapping matrix | Done |
| #32 Restrict enterprise configuration to Admin | Done. `/admin/config`, credentials refused (`USE_SECRET_STORE`) |
| #4 Role-driven dynamic search filters | Not built (Ehthikash). Needs master data (DEP-S1-03) |
| #5 / #7 Visibility, TL / Manager elevated | Framework ready: `DataScope`, `AccessEvaluator`, `ScopeFilter` (common-utils). Wiring per service pending |
| #6 / #8 Shared access, override with approver | Contract ready (`sharedObjects`, `SHARED_BY_APPROVAL`, manager chain). Workflow not built |
| #9-14 Central logging | `adm_audit_log` matches the reference starter's columns. One table for all services |
| #26-31 Workflow config | Permission codes the reference workflow-services checks are seeded |
| S2 #33-36 Secrets | Kept out of enterprise config on purpose |
| S2 #37 Role creation | Already available |
| S2 #38-39 Approval hierarchy | Must be its own tables, not `manager_id` |
| S4 #90 Role-restricted ID documents | `CANDIDATE:VIEW_SENSITIVE` seeded, granted to nobody until HR Ops is defined |
| S4 #113 JD edit with TA Head approval | `TA_HEAD` role + `JOB:EDIT_JD` / `WORKFLOW:APPROVE` |
| S5 #149 Vendor role mapping | Needs an internal endpoint for vendor-services and an AGENCY scope dimension |
