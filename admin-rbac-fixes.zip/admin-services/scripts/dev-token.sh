#!/usr/bin/env bash
# DEV / LOCAL ONLY. Mints an auth-services style JWT (HS256, Base64-decoded secret) so you can call
# admin-services from Swagger UI or the .http file without logging in through the UI.
#
#   JWT_SECRET=<same value as the service> ./scripts/dev-token.sh first.admin@agshealth.com [userId] [userType] [minutes]
#
# The e-mail must exist in adm_app_user (e.g. one of BOOTSTRAP_SUPER_ADMIN_EMAILS) to get admin rights.
set -euo pipefail
: "${JWT_SECRET:?set JWT_SECRET to the same Base64 secret admin-services uses}"
EMAIL="${1:?usage: dev-token.sh <email> [userId] [userType] [minutes]}"
USER_ID="${2:-dev-$(echo -n "$EMAIL" | cksum | cut -d' ' -f1)}"
USER_TYPE="${3:-EMPLOYEE_HR_ADMIN}"
MINUTES="${4:-60}"
NOW=$(date +%s); EXP=$((NOW + MINUTES * 60))

b64url() { openssl base64 -A | tr '+/' '-_' | tr -d '='; }
HEADER=$(printf '{"alg":"HS256","typ":"JWT"}' | b64url)
PAYLOAD=$(printf '{"sub":"%s","email":"%s","userId":"%s","userType":"%s","userName":"%s","iat":%d,"exp":%d}' \
  "$EMAIL" "$EMAIL" "$USER_ID" "$USER_TYPE" "$EMAIL" "$NOW" "$EXP" | b64url)
KEY_HEX=$(printf '%s\n' "$JWT_SECRET" | openssl base64 -d -A | od -An -v -tx1 | tr -d ' \n')
SIG=$(printf '%s.%s' "$HEADER" "$PAYLOAD" | openssl dgst -sha256 -mac HMAC -macopt "hexkey:$KEY_HEX" -binary | b64url)
echo "$HEADER.$PAYLOAD.$SIG"
