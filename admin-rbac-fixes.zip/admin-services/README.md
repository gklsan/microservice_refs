# admin-services

Admin user management and RBAC for DigiHire Phase 5 (BRD 4.1, 4.3).

- Admin user account creation
- Admin user list: search, deactivate, reactivate
- Granular user-based permissions (ALLOW / DENY, conditional, expiry)
- Roles and the role x permission matrix (7 roles of the access matrix)
- Effective access for the UI (`/rbac/me`) and for other services (`/internal/rbac/effective`)

Read next:

- `docs/SETUP.md` - env variables, gateway route, deploy script, endpoint list
- `docs/RBAC-DECISIONS.md` - the model, the matrix, and answers to the team review

Layout follows smartie-core (`controllers / services / resources / entities / data / enums / exceptions / config / security / utils`, base package `com.ags.health.hr.admin`).
