package com.ags.health.hr.admin.services;

import com.ags.health.hr.admin.config.AdminProperties;
import com.ags.health.hr.admin.entities.AppUser;
import com.ags.health.hr.admin.entities.Role;
import com.ags.health.hr.admin.entities.RolePermission;
import com.ags.health.hr.admin.entities.UserPermissionGrant;
import com.ags.health.hr.admin.enums.PermissionEffect;
import com.ags.health.hr.admin.enums.ScopeLevel;
import com.ags.health.hr.admin.enums.UserStatus;
import com.ags.health.hr.admin.resources.AppUserRepository;
import com.ags.health.hr.admin.resources.PermissionRepository;
import com.ags.health.hr.admin.resources.RoleRepository;
import com.ags.health.hr.admin.security.EffectiveAccess;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyCollection;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

/** The permission formula, without Spring or a database. */
class AccessResolverServiceTest {

    private AppUserRepository users;
    private RoleRepository roles;
    private AccessResolverService service;

    @BeforeEach
    void setUp() {
        users = mock(AppUserRepository.class);
        roles = mock(RoleRepository.class);
        AdminProperties props = new AdminProperties();
        props.getAccess().setFallbackRolesByUserType(Map.of(
                "CANDIDATE", List.of("CANDIDATE"),
                "EMPLOYEE_HR_ADMIN", List.of("SUPER_ADMIN", "RECRUITMENT_MANAGER")));
        service = new AccessResolverService(users, roles, mock(PermissionRepository.class), props);
        when(users.findTeamSmartieUserIds(any())).thenReturn(List.of("r1", "r2"));
    }

    private static Role role(String code, ScopeLevel scope, boolean active, RolePermission... perms) {
        Role r = Role.create(code, code);
        r.setDefaultScope(scope);
        r.setActive(active);
        r.setPermissions(Set.of(perms));
        return r;
    }

    private static RolePermission a(String code) {
        return new RolePermission(code, false);
    }

    private static RolePermission c(String code) {
        return new RolePermission(code, true);
    }

    private static UserPermissionGrant grant(String code, PermissionEffect effect, boolean conditional, Instant expires) {
        return new UserPermissionGrant(code, effect, conditional, expires, null, "admin", Instant.now());
    }

    private AppUser user(Role... r) {
        AppUser u = AppUser.create("Rec@AGSHealth.com", "Rec", "EMPLOYEE_HR");
        u.setRoles(Set.of(r));
        when(users.findWithAccessBySmartieUserId("s1")).thenReturn(Optional.empty());
        when(users.findWithAccessByEmail("rec@agshealth.com")).thenReturn(Optional.of(u));
        return u;
    }

    @Test
    void unionOfRolesAndUnconditionalWins() {
        user(role("RECRUITER", ScopeLevel.OWN, true, a("CANDIDATE_PROFILE:VIEW"), c("CANDIDATE_PROFILE:DELETE")),
             role("RECRUITMENT_MANAGER", ScopeLevel.TEAM, true, a("CANDIDATE_PROFILE:DELETE")));
        EffectiveAccess e = service.resolve("s1", "rec@agshealth.com", "EMPLOYEE_HR");
        assertThat(e.permissions()).containsExactlyInAnyOrder("CANDIDATE_PROFILE:VIEW", "CANDIDATE_PROFILE:DELETE");
        assertThat(e.conditionalPermissions()).isEmpty();
        assertThat(e.scope().level()).isEqualTo(ScopeLevel.TEAM);
        assertThat(e.scope().teamUserIds()).containsExactlyInAnyOrder("r1", "r2");
    }

    @Test
    void denyWinsAndExpiredGrantsAreIgnored() {
        AppUser u = user(role("RECRUITER", ScopeLevel.OWN, true, a("CANDIDATE_PROFILE:VIEW"), a("REPORT:VIEW")));
        u.setPermissionGrants(Set.of(
                grant("REPORT:VIEW", PermissionEffect.DENY, false, null),
                grant("OFFER:VIEW", PermissionEffect.ALLOW, true, null),
                grant("SELECTION:VIEW", PermissionEffect.ALLOW, false, Instant.now().minus(1, ChronoUnit.DAYS))));
        EffectiveAccess e = service.resolve("s1", "rec@agshealth.com", "EMPLOYEE_HR");
        assertThat(e.permissions()).containsExactlyInAnyOrder("CANDIDATE_PROFILE:VIEW", "OFFER:VIEW");
        assertThat(e.conditionalPermissions()).containsExactly("OFFER:VIEW");
    }

    @Test
    void retiredRoleGrantsNothing() {
        user(role("RECRUITER", ScopeLevel.OWN, false, a("CANDIDATE_PROFILE:VIEW")));
        EffectiveAccess e = service.resolve("s1", "rec@agshealth.com", "EMPLOYEE_HR");
        assertThat(e.roles()).isEmpty();
        assertThat(e.permissions()).isEmpty();
    }

    @Test
    void inactiveUserHasNoAccess() {
        AppUser u = user(role("RECRUITER", ScopeLevel.OWN, true, a("CANDIDATE_PROFILE:VIEW")));
        u.setStatus(UserStatus.INACTIVE);
        EffectiveAccess e = service.resolve("s1", "rec@agshealth.com", "EMPLOYEE_HR");
        assertThat(e.active()).isFalse();
        assertThat(e.permissions()).isEmpty();
    }

    @Test
    void firstLoginLinksSmartieUserId() {
        AppUser u = user(role("RECRUITER", ScopeLevel.OWN, true));
        service.resolve("s1", "REC@agshealth.com", "EMPLOYEE_HR");
        assertThat(u.getSmartieUserId()).isEqualTo("s1");
    }

    @Test
    void explicitUserScopeOverridesRoleDefault() {
        AppUser u = user(role("RECRUITMENT_MANAGER", ScopeLevel.TEAM, true));
        u.setScopeLevel(ScopeLevel.ALL);
        assertThat(service.resolve("s1", "rec@agshealth.com", "EMPLOYEE_HR").scope().level()).isEqualTo(ScopeLevel.ALL);
    }

    @Test
    void fallbackNeverGrantsSuperAdmin() {
        when(users.findWithAccessByEmail("new@agshealth.com")).thenReturn(Optional.empty());
        Role manager = role("RECRUITMENT_MANAGER", ScopeLevel.TEAM, true, a("REPORT:VIEW"));
        when(roles.findByCodeIn(anyCollection())).thenAnswer(inv -> {
            List<String> codes = List.copyOf(inv.getArgument(0));
            assertThat(codes).doesNotContain("SUPER_ADMIN");
            return List.of(manager);
        });
        EffectiveAccess e = service.resolve("s9", "new@agshealth.com", "EMPLOYEE_HR_ADMIN");
        assertThat(e.configured()).isFalse();
        assertThat(e.roles()).containsExactly("RECRUITMENT_MANAGER");
    }
}
