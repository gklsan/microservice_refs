package com.ags.health.hr.admin.security;

import com.ags.health.hr.admin.enums.ScopeLevel;
import org.junit.jupiter.api.Test;

import java.util.Set;

import static org.assertj.core.api.Assertions.assertThat;

class AccessEvaluatorTest {

    private static EffectiveAccess access(ScopeLevel level, Set<String> perms, Set<String> conditional,
                                          Set<String> team, Set<String> lobs) {
        return new EffectiveAccess("me", null, "me@x.com", true, true, Set.of("R"), perms, conditional,
                new DataScope(level, "me", team, lobs, Set.of()));
    }

    private static AccessEvaluator.Target owned(String owner, String lob) {
        return new AccessEvaluator.Target("CANDIDATE", "c1", owner, Set.of(), lob, null);
    }

    @Test
    void missingPermissionIsDenied() {
        EffectiveAccess a = access(ScopeLevel.ALL, Set.of("CANDIDATE_PROFILE:VIEW"), Set.of(), Set.of(), Set.of());
        assertThat(AccessEvaluator.check(a, "CANDIDATE_PROFILE:DELETE", owned("x", null)).reason())
                .isEqualTo("MISSING_PERMISSION");
    }

    @Test
    void conditionalPermissionIgnoresWideScope() {
        // Recruiter-style delete: "C" -> only own records, even with ALL scope
        EffectiveAccess a = access(ScopeLevel.ALL, Set.of("CANDIDATE_PROFILE:DELETE"), Set.of("CANDIDATE_PROFILE:DELETE"),
                Set.of(), Set.of());
        assertThat(AccessEvaluator.check(a, "CANDIDATE_PROFILE:DELETE", owned("someone-else", null)).allowed()).isFalse();
        assertThat(AccessEvaluator.check(a, "CANDIDATE_PROFILE:DELETE", owned("me", null)).allowed()).isTrue();
    }

    @Test
    void conditionalAllowsAssignee() {
        EffectiveAccess a = access(ScopeLevel.OWN, Set.of("INTERVIEW:EDIT"), Set.of("INTERVIEW:EDIT"), Set.of(), Set.of());
        AccessEvaluator.Target panel = new AccessEvaluator.Target("INTERVIEW", "i1", "recruiter", Set.of("me", "p2"), null, null);
        assertThat(AccessEvaluator.check(a, "INTERVIEW:EDIT", panel).reason()).isEqualTo("CONDITION_OWNER_OR_ASSIGNEE");
    }

    @Test
    void teamScopeSeesReportsRecords() {
        EffectiveAccess a = access(ScopeLevel.TEAM, Set.of("CANDIDATE_PROFILE:VIEW"), Set.of(), Set.of("rec1"), Set.of());
        assertThat(AccessEvaluator.check(a, "CANDIDATE_PROFILE:VIEW", owned("rec1", null)).reason()).isEqualTo("SCOPE_TEAM");
        assertThat(AccessEvaluator.check(a, "CANDIDATE_PROFILE:VIEW", owned("rec2", null)).allowed()).isFalse();
    }

    @Test
    void lobScope() {
        EffectiveAccess a = access(ScopeLevel.LOB, Set.of("CANDIDATE_PROFILE:VIEW"), Set.of(), Set.of(), Set.of("VOICE"));
        assertThat(AccessEvaluator.check(a, "CANDIDATE_PROFILE:VIEW", owned("x", "VOICE")).reason()).isEqualTo("SCOPE_LOB");
        assertThat(AccessEvaluator.check(a, "CANDIDATE_PROFILE:VIEW", owned("x", "CODING")).allowed()).isFalse();
    }

    @Test
    void ownScopeOnlyOwnRecords() {
        EffectiveAccess a = access(ScopeLevel.OWN, Set.of("CANDIDATE_PROFILE:VIEW"), Set.of(), Set.of(), Set.of());
        assertThat(AccessEvaluator.check(a, "CANDIDATE_PROFILE:VIEW", owned("x", null)).allowed()).isFalse();
        assertThat(AccessEvaluator.check(a, "CANDIDATE_PROFILE:VIEW", owned("me", null)).allowed()).isTrue();
    }

    @Test
    void inactiveUserGetsNothing() {
        EffectiveAccess a = new EffectiveAccess("me", null, "me@x.com", false, true, Set.of(), Set.of(), Set.of(), null);
        assertThat(AccessEvaluator.check(a, "CANDIDATE_PROFILE:VIEW", null).allowed()).isFalse();
    }
}
