package com.ags.health.hr.admin.services;

import com.ags.health.hr.admin.entities.AppUser;
import com.ags.health.hr.admin.entities.Role;
import com.ags.health.hr.admin.enums.UserStatus;
import com.ags.health.hr.admin.exceptions.APIException;
import com.ags.health.hr.admin.resources.AppUserRepository;
import com.ags.health.hr.admin.resources.RoleRepository;
import com.ags.health.hr.admin.security.CurrentUser;
import com.ags.health.hr.admin.security.EffectiveAccess;
import com.ags.health.hr.admin.security.SmartieAuthentication;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.security.core.context.SecurityContextHolder;

import java.util.List;
import java.util.Set;

import static org.assertj.core.api.Assertions.assertThatCode;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

class AdminGuardTest {

    private AppUserRepository users;
    private RoleRepository roles;
    private AdminGuard guard;
    private AppUser target;

    @BeforeEach
    void setUp() {
        users = mock(AppUserRepository.class);
        roles = mock(RoleRepository.class);
        guard = new AdminGuard(users, roles);
        target = AppUser.create("other@agshealth.com", "Other", "EMPLOYEE_HR_ADMIN");
        target.setRoles(Set.of(Role.create("SUPER_ADMIN", "Super Admin")));
        loginAs("caller@agshealth.com", null);
    }

    @AfterEach
    void clear() {
        SecurityContextHolder.clearContext();
    }

    private static void loginAs(String email, java.util.UUID adminUserId) {
        EffectiveAccess access = new EffectiveAccess("s-caller", adminUserId, email, true, true,
                Set.of("SUPER_ADMIN"), Set.of(), Set.of(), null);
        SecurityContextHolder.getContext().setAuthentication(new SmartieAuthentication(
                new CurrentUser("s-caller", email, "Caller", "EMPLOYEE_HR_ADMIN", access), List.of()));
    }

    @Test
    void selfModificationByEmailOrRecordIsRejected() {
        loginAs("OTHER@agshealth.com", null);
        assertThatThrownBy(() -> guard.rejectSelfModification(target))
                .isInstanceOf(APIException.class).hasFieldOrPropertyWithValue("code", "SELF_MODIFICATION_NOT_ALLOWED");
        loginAs("alias@agshealth.com", target.getId());
        assertThatThrownBy(() -> guard.rejectSelfModification(target)).isInstanceOf(APIException.class);
        loginAs("caller@agshealth.com", null);
        assertThatCode(() -> guard.rejectSelfModification(target)).doesNotThrowAnyException();
    }

    @Test
    void lastSuperAdminCanNotBeDeactivatedOrStripped() {
        when(users.countByRoleAndStatus("SUPER_ADMIN", UserStatus.ACTIVE)).thenReturn(1L);
        assertThatThrownBy(() -> guard.rejectRemovingLastSuperAdmin(target, true, false))
                .hasFieldOrPropertyWithValue("code", "LAST_SUPER_ADMIN");
        assertThatThrownBy(() -> guard.rejectRemovingLastSuperAdmin(target, false, true))
                .hasFieldOrPropertyWithValue("code", "LAST_SUPER_ADMIN");
        verify(roles, org.mockito.Mockito.times(2)).lockByCode("SUPER_ADMIN");
    }

    @Test
    void removingOneOfTwoSuperAdminsIsFine() {
        when(users.countByRoleAndStatus("SUPER_ADMIN", UserStatus.ACTIVE)).thenReturn(2L);
        assertThatCode(() -> guard.rejectRemovingLastSuperAdmin(target, true, false)).doesNotThrowAnyException();
    }

    @Test
    void keepingTheRoleNeedsNoLock() {
        assertThatCode(() -> guard.rejectRemovingLastSuperAdmin(target, true, true)).doesNotThrowAnyException();
        org.mockito.Mockito.verifyNoInteractions(roles);
    }
}
