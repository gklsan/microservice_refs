package com.ags.health.hr.admin;

import org.springframework.test.context.TestPropertySource;

/**
 * All integration scenarios on the local set-up: H2 authdb without MODE=PostgreSQL, like the shared .env TCP URL.
 * Needs com.h2database:h2 on the classpath (runtime dependency in pom.xml).
 */
@TestPropertySource(properties = {
        "spring.datasource.url=jdbc:h2:mem:authdb_it;DB_CLOSE_DELAY=-1;DB_CLOSE_ON_EXIT=FALSE",
        "spring.datasource.driver-class-name=org.h2.Driver",
        "spring.datasource.username=sa",
        "spring.datasource.password=",
        // a shell with DB_DIALECT=PostgreSQLDialect (from .env.uat) must not leak into the H2 run
        "spring.jpa.properties.hibernate.dialect=org.hibernate.dialect.H2Dialect"
})
class H2AuthdbSmokeTest extends AdminServicesIntegrationTest {
}
