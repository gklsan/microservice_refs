package com.ags.health.hr.admin;

import io.zonky.test.db.postgres.embedded.EmbeddedPostgres;
import org.junit.jupiter.api.condition.EnabledIfSystemProperty;
import org.springframework.test.context.DynamicPropertyRegistry;
import org.springframework.test.context.DynamicPropertySource;

import java.io.IOException;

/**
 * All integration scenarios on real PostgreSQL (the UAT / prod engine), using embedded binaries - no Docker.
 * Opt-in because the binaries are downloaded from Maven Central and can be blocked on office machines:
 * <pre>mvn test -Dit.postgres=true</pre>
 * Run it in CI / on Linux before every STG deploy.
 */
@EnabledIfSystemProperty(named = "it.postgres", matches = "true")
class PostgresIntegrationTest extends AdminServicesIntegrationTest {

    private static EmbeddedPostgres pg;

    @DynamicPropertySource
    static void postgres(DynamicPropertyRegistry r) throws IOException {
        if (pg == null) {
            pg = EmbeddedPostgres.builder().start();
        }
        r.add("spring.datasource.url", () -> pg.getJdbcUrl("postgres", "postgres"));
        r.add("spring.datasource.username", () -> "postgres");
        r.add("spring.datasource.password", () -> "postgres");
        r.add("spring.datasource.driver-class-name", () -> "org.postgresql.Driver");
        r.add("spring.jpa.properties.hibernate.dialect", () -> "org.hibernate.dialect.PostgreSQLDialect");
    }
}
