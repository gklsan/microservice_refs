package com.ags.health.hr.admin.entities;

import jakarta.persistence.Column;
import jakarta.persistence.EntityListeners;
import jakarta.persistence.MappedSuperclass;
import jakarta.persistence.Version;
import lombok.Getter;
import lombok.Setter;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import java.time.Instant;

/**
 * Audit fields shared by admin-services entities. Same idea as auth-services CommonEndity
 * (createdDate / updatedDate) plus who changed it and an optimistic-lock version.
 */
@Getter
@Setter
@MappedSuperclass
@EntityListeners(AuditingEntityListener.class)
public abstract class CommonEntity {

    @CreatedDate
    @Column(name = "created_date", nullable = false, updatable = false)
    private Instant createdDate;

    @CreatedBy
    @Column(name = "created_by", updatable = false)
    private String createdBy;

    @LastModifiedDate
    @Column(name = "updated_date")
    private Instant updatedDate;

    @LastModifiedBy
    @Column(name = "updated_by")
    private String updatedBy;

    /** Wrapper type on purpose: null = new entity, so save() persists instead of merging. */
    @Version
    @Column(name = "version", nullable = false)
    private Long version;
}
