package com.ags.health.hr.admin.entities;

import com.ags.health.hr.admin.enums.ScopeDimension;
import com.ags.health.hr.admin.enums.ScopeLevel;
import com.ags.health.hr.admin.enums.UserStatus;
import jakarta.persistence.CollectionTable;
import jakarta.persistence.Column;
import jakarta.persistence.ElementCollection;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.FetchType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.JoinTable;
import jakarta.persistence.ManyToMany;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.hibernate.annotations.BatchSize;

import java.time.Instant;
import java.util.HashSet;
import java.util.Set;
import java.util.UUID;
import java.util.stream.Collectors;

/**
 * Admin-module user (recruiters, managers, panel members, admins). Authorisation data only:
 * login identity stays in auth-services (smartie_user). Linked by e-mail; the smartie user id is
 * back-filled the first time the user calls any service.
 */
@Entity
@Table(name = "adm_app_user")
@Getter
@Setter
@NoArgsConstructor
public class AppUser extends CommonEntity {

    @Id
    private UUID id;

    /** Stored as text: the knowledge base is not consistent about UUID vs BIGINT ids on smartie_user. */
    @Column(name = "smartie_user_id", unique = true)
    private String smartieUserId;

    @Column(nullable = false, unique = true)
    private String email;

    @Column(name = "full_name", nullable = false)
    private String fullName;

    @Column(name = "employee_code")
    private String employeeCode;

    @Column(name = "user_type", nullable = false)
    private String userType;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private UserStatus status = UserStatus.ACTIVE;

    /** Explicit visibility for this user; null = widest default scope of the user's roles. */
    @Enumerated(EnumType.STRING)
    @Column(name = "scope_level")
    private ScopeLevel scopeLevel;

    @Column(name = "manager_id")
    private UUID managerId;

    @Column(name = "status_changed_date")
    private Instant statusChangedDate;

    @Column(name = "status_changed_by")
    private String statusChangedBy;

    @Column(name = "status_reason")
    private String statusReason;

    @BatchSize(size = 50)
    @ManyToMany(fetch = FetchType.LAZY)
    @JoinTable(name = "adm_user_role",
            joinColumns = @JoinColumn(name = "user_id"),
            inverseJoinColumns = @JoinColumn(name = "role_id"))
    private Set<Role> roles = new HashSet<>();

    @BatchSize(size = 50)
    @ElementCollection(fetch = FetchType.LAZY)
    @CollectionTable(name = "adm_user_permission", joinColumns = @JoinColumn(name = "user_id"))
    private Set<UserPermissionGrant> permissionGrants = new HashSet<>();

    @BatchSize(size = 50)
    @ElementCollection(fetch = FetchType.LAZY)
    @CollectionTable(name = "adm_user_scope", joinColumns = @JoinColumn(name = "user_id"))
    private Set<UserScope> scopes = new HashSet<>();

    public static AppUser create(String email, String fullName, String userType) {
        AppUser u = new AppUser();
        u.id = UUID.randomUUID();
        u.email = normalizeEmail(email);
        u.fullName = fullName.trim();
        u.userType = userType;
        return u;
    }

    public static String normalizeEmail(String email) {
        return email == null ? null : email.trim().toLowerCase();
    }

    public boolean isActive() {
        return status == UserStatus.ACTIVE;
    }

    public boolean hasRole(String roleCode) {
        return roles.stream().anyMatch(r -> r.getCode().equals(roleCode));
    }

    public Set<String> roleCodes() {
        return roles.stream().map(Role::getCode).collect(Collectors.toSet());
    }

    public Set<String> scopeValues(ScopeDimension dimension) {
        return scopes.stream().filter(s -> s.dimension() == dimension).map(UserScope::value).collect(Collectors.toSet());
    }
}
