package com.ags.health.hr.admin.entities;

import com.ags.health.hr.admin.enums.ConfigValueType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * Enterprise-level setting (tracker #32). Only an active SUPER_ADMIN changes it; every change is audited.
 * Not for credentials: those go to the S2 secret store (tracker #33).
 */
@Entity
@Table(name = "adm_enterprise_config")
@Getter
@Setter
@NoArgsConstructor
public class EnterpriseConfig extends CommonEntity {

    @Id
    @Column(name = "config_key")
    private String key;

    @Column(name = "config_value")
    private String value;

    @Enumerated(EnumType.STRING)
    @Column(name = "value_type", nullable = false)
    private ConfigValueType valueType = ConfigValueType.STRING;

    @Column(nullable = false)
    private String category = "GENERAL";

    private String description;
}
