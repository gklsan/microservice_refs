package com.ags.health.hr.admin.controllers;

import com.ags.health.hr.admin.data.RbacDtos;
import com.ags.health.hr.admin.exceptions.APIException;
import com.ags.health.hr.admin.security.AccessEvaluator;
import com.ags.health.hr.admin.security.CurrentUser;
import com.ags.health.hr.admin.security.EffectiveAccess;
import com.ags.health.hr.admin.security.SecurityUtils;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/** Any logged-in user: "what can I do?" for menus / buttons, and one-off record checks. */
@RestController
@RequestMapping("/rbac")
public class RbacController {

    @GetMapping("/me")
    @PreAuthorize("isAuthenticated()")
    public RbacDtos.Me me() {
        CurrentUser u = SecurityUtils.requireUser();
        EffectiveAccess a = u.access();
        if (a == null) {
            throw APIException.badRequest("NOT_A_USER", "Service calls have no user access profile");
        }
        return new RbacDtos.Me(u.userId(), u.email(), u.name(), u.userType(), a.active(), a.configured(),
                a.roles(), a.permissions(), a.conditionalPermissions(), a.scope());
    }

    @PostMapping("/check")
    @PreAuthorize("isAuthenticated()")
    public RbacDtos.CheckResponse check(@RequestBody RbacDtos.CheckRequest req) {
        AccessEvaluator.Decision d = AccessEvaluator.check(SecurityUtils.requireUser().access(), req.permission(),
                new AccessEvaluator.Target(req.objectType(), req.objectId(), req.ownerId(), req.assigneeIds(),
                        req.lob(), req.location()));
        return new RbacDtos.CheckResponse(d.allowed(), d.reason());
    }
}
