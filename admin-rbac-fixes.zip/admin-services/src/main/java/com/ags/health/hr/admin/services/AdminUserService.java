package com.ags.health.hr.admin.services;

import com.ags.health.hr.admin.config.AdminProperties;
import com.ags.health.hr.admin.data.AdminUserResponse;
import com.ags.health.hr.admin.data.AdminUserSummary;
import com.ags.health.hr.admin.data.AssignRolesRequest;
import com.ags.health.hr.admin.data.CreateAdminUserRequest;
import com.ags.health.hr.admin.data.EffectiveAccessDetail;
import com.ags.health.hr.admin.data.PageResponse;
import com.ags.health.hr.admin.data.UpdateAdminUserRequest;
import com.ags.health.hr.admin.data.UserPermissionGrantRequest;
import com.ags.health.hr.admin.entities.AppUser;
import com.ags.health.hr.admin.entities.Permission;
import com.ags.health.hr.admin.entities.Role;
import com.ags.health.hr.admin.entities.UserPermissionGrant;
import com.ags.health.hr.admin.entities.UserScope;
import com.ags.health.hr.admin.enums.AuditCategory;
import com.ags.health.hr.admin.enums.PermissionEffect;
import com.ags.health.hr.admin.enums.ScopeDimension;
import com.ags.health.hr.admin.enums.ScopeLevel;
import com.ags.health.hr.admin.enums.UserStatus;
import com.ags.health.hr.admin.exceptions.APIException;
import com.ags.health.hr.admin.resources.AppUserRepository;
import com.ags.health.hr.admin.resources.PermissionRepository;
import com.ags.health.hr.admin.resources.RoleRepository;
import com.ags.health.hr.admin.security.SecurityUtils;
import com.ags.health.hr.admin.utils.RoleCodes;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import java.time.Instant;
import java.util.Collection;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;
import java.util.UUID;
import java.util.function.Function;
import java.util.stream.Collectors;

/**
 * Admin user accounts: create, list / search, deactivate / reactivate, roles, data scope and
 * granular user-based permissions. Every change is audited with before / after values.
 */
@Service
@Transactional
@RequiredArgsConstructor
public class AdminUserService {

    private final AppUserRepository users;
    private final RoleRepository roles;
    private final PermissionRepository permissions;
    private final AccessResolverService accessResolver;
    private final AdminGuard guard;
    private final AuditService audit;
    private final AdminProperties properties;

    // ------------------------------------------------------------------ create

    public AdminUserResponse create(CreateAdminUserRequest req) {
        String email = AppUser.normalizeEmail(req.email());
        checkEmailDomain(email);
        users.findByEmail(email).ifPresent(existing -> {
            throw APIException.conflict("USER_EXISTS", "A user with e-mail " + email + " already exists (id "
                    + existing.getId() + ", status " + existing.getStatus() + ")");
        });

        AppUser u = AppUser.create(email, req.fullName(), req.userType().name());
        u.setEmployeeCode(trimToNull(req.employeeCode()));
        u.setRoles(assignableRoles(req.roles(), Set.of()));
        u.setManagerId(validManager(req.managerId(), u.getId()));
        applyScope(u, req.scopeLevel(), req.lobs(), req.locations());
        users.save(u);

        audit.log(AuditCategory.SECURITY, "ADMIN_USER_CREATED", "ADMIN_USER", u.getId(), details(
                "email", email, "roles", new TreeSet<>(u.roleCodes()), "scopeLevel", u.getScopeLevel(),
                "lobs", u.scopeValues(ScopeDimension.LOB), "locations", u.scopeValues(ScopeDimension.LOCATION),
                "managerId", u.getManagerId()));
        return view(u);
    }

    // ------------------------------------------------------------------ read

    @Transactional(readOnly = true)
    public PageResponse<AdminUserSummary> search(String search, UserStatus status, String roleCode, Pageable pageable) {
        String q = StringUtils.hasText(search) ? escapeLike(search.trim().toLowerCase()) : null;
        String role = StringUtils.hasText(roleCode) ? roleCode.trim().toUpperCase() : null;
        return PageResponse.of(users.search(q, status, role, pageable).map(AdminUserSummary::of));
    }

    @Transactional(readOnly = true)
    public AdminUserResponse find(UUID id) {
        return view(get(id));
    }

    @Transactional(readOnly = true)
    public EffectiveAccessDetail effectiveAccess(UUID id) {
        return accessResolver.explain(get(id));
    }

    @Transactional(readOnly = true)
    public List<AdminUserSummary> activeByRole(String roleCode) {
        return users.findByRoleAndStatus(roleCode, UserStatus.ACTIVE).stream().map(AdminUserSummary::of).toList();
    }

    // ------------------------------------------------------------------ update profile + scope

    public AdminUserResponse update(UUID id, UpdateAdminUserRequest req) {
        AppUser u = get(id);
        guard.rejectSelfModification(u);
        checkVersion(u.getVersion(), req.version());
        Map<String, Object> before = snapshot(u);

        u.setFullName(req.fullName().trim());
        u.setEmployeeCode(trimToNull(req.employeeCode()));
        u.setManagerId(validManager(req.managerId(), u.getId()));
        applyScope(u, req.scopeLevel(), req.lobs(), req.locations());

        audit.log(AuditCategory.CONFIG_CHANGE, "ADMIN_USER_UPDATED", "ADMIN_USER", u.getId(),
                details("before", before, "after", snapshot(u)));
        return view(u);
    }

    // ------------------------------------------------------------------ status

    public AdminUserResponse deactivate(UUID id, String reason) {
        if (!StringUtils.hasText(reason)) {
            throw APIException.badRequest("REASON_REQUIRED", "Give a reason for deactivating the user");
        }
        AppUser u = get(id);
        guard.rejectSelfModification(u);
        if (!u.isActive()) {
            return view(u); // idempotent
        }
        guard.rejectRemovingLastSuperAdmin(u, u.hasRole(RoleCodes.SUPER_ADMIN), false);
        long activeReports = users.countByManagerIdAndStatus(u.getId(), UserStatus.ACTIVE);
        setStatus(u, UserStatus.INACTIVE, reason);
        audit.log(AuditCategory.SECURITY, "ADMIN_USER_DEACTIVATED", "ADMIN_USER", u.getId(),
                details("email", u.getEmail(), "reason", reason, "activeDirectReports", activeReports));
        return view(u);
    }

    public AdminUserResponse reactivate(UUID id, String reason) {
        AppUser u = get(id);
        guard.rejectSelfModification(u);
        if (u.isActive()) {
            return view(u); // idempotent
        }
        setStatus(u, UserStatus.ACTIVE, reason);
        audit.log(AuditCategory.SECURITY, "ADMIN_USER_REACTIVATED", "ADMIN_USER", u.getId(),
                details("email", u.getEmail(), "reason", reason, "roles", new TreeSet<>(u.roleCodes())));
        return view(u);
    }

    // ------------------------------------------------------------------ roles

    public AdminUserResponse assignRoles(UUID id, AssignRolesRequest req) {
        AppUser u = get(id);
        guard.rejectSelfModification(u);
        Set<String> requested = req.roles().stream().map(r -> r.trim().toUpperCase()).collect(Collectors.toSet());
        guard.rejectRemovingLastSuperAdmin(u, requested.contains(RoleCodes.SUPER_ADMIN), u.isActive());

        Set<String> before = new TreeSet<>(u.roleCodes());
        u.setRoles(assignableRoles(requested, before));
        Set<String> after = new TreeSet<>(u.roleCodes());
        if (!before.equals(after)) {
            audit.log(AuditCategory.SECURITY, "ADMIN_USER_ROLES_CHANGED", "ADMIN_USER", u.getId(),
                    details("email", u.getEmail(), "before", before, "after", after,
                            "added", diff(after, before), "removed", diff(before, after)));
        }
        return view(u);
    }

    // ------------------------------------------------------------------ granular user-based permissions

    @Transactional(readOnly = true)
    public List<AdminUserResponse.GrantView> grants(UUID id) {
        return view(get(id)).permissionGrants();
    }

    public AdminUserResponse setPermissions(UUID id, UserPermissionGrantRequest req) {
        AppUser u = get(id);
        guard.rejectSelfModification(u);

        Map<String, UserPermissionGrantRequest.Item> byCode = new LinkedHashMap<>();
        for (UserPermissionGrantRequest.Item item : req.grants()) {
            if (byCode.put(item.permission().trim(), item) != null) {
                throw APIException.badRequest("DUPLICATE_PERMISSION",
                        "Permission " + item.permission() + " is listed twice. Keep one ALLOW or one DENY.");
            }
        }
        Map<String, Permission> catalogue = permissions.findByCodeIn(byCode.keySet()).stream()
                .collect(Collectors.toMap(Permission::getCode, Function.identity()));
        Set<String> unknown = new TreeSet<>(byCode.keySet());
        unknown.removeAll(catalogue.keySet());
        if (!unknown.isEmpty()) {
            throw APIException.badRequest("UNKNOWN_PERMISSION", "Unknown permission(s): " + unknown);
        }
        Set<String> privileged = catalogue.values().stream().filter(Permission::isPrivileged)
                .map(Permission::getCode).collect(Collectors.toCollection(TreeSet::new));
        if (!privileged.isEmpty()) {
            throw APIException.badRequest("PRIVILEGED_PERMISSION", "Permission(s) " + privileged
                    + " can only be given through the SUPER_ADMIN role, not as a user-level grant");
        }

        Map<String, UserPermissionGrant> existing = u.getPermissionGrants().stream()
                .collect(Collectors.toMap(UserPermissionGrant::permissionCode, Function.identity()));
        String actor = SecurityUtils.currentActorName();
        Instant now = Instant.now();
        Set<UserPermissionGrant> next = new HashSet<>();
        byCode.forEach((code, item) -> {
            if (item.effect() == PermissionEffect.DENY && item.conditional()) {
                throw APIException.badRequest("INVALID_GRANT", "A DENY can not be conditional: " + code);
            }
            UserPermissionGrant old = existing.get(code);
            boolean unchanged = old != null && old.effect() == item.effect() && old.conditional() == item.conditional()
                    && java.util.Objects.equals(old.expiresAt(), item.expiresAt());
            String reason = trimToNull(item.reason());
            if (unchanged) {
                next.add(java.util.Objects.equals(old.reason(), reason) ? old
                        : new UserPermissionGrant(code, old.effect(), old.conditional(), old.expiresAt(), reason,
                        old.grantedBy(), old.grantedDate()));
                return;
            }
            if (item.expiresAt() != null && !item.expiresAt().isAfter(now)) {
                throw APIException.badRequest("INVALID_GRANT", "Expiry date must be in the future: " + code);
            }
            next.add(new UserPermissionGrant(code, item.effect(), item.conditional(), item.expiresAt(), reason, actor, now));
        });

        Set<String> before = describe(u.getPermissionGrants());
        // new collection instance = Hibernate deletes the user's rows first, then inserts (no PK clash)
        u.setPermissionGrants(next);
        Set<String> after = describe(next);
        if (!before.equals(after)) {
            audit.log(AuditCategory.SECURITY, "ADMIN_USER_PERMISSIONS_CHANGED", "ADMIN_USER", u.getId(),
                    details("email", u.getEmail(), "before", before, "after", after,
                            "added", diff(after, before), "removed", diff(before, after)));
        }
        return view(u);
    }

    // ------------------------------------------------------------------ bootstrap (day one)

    /** Idempotent: makes sure the configured e-mail is an active SUPER_ADMIN. Used at start-up only. */
    public boolean ensureSuperAdmin(String rawEmail) {
        String email = AppUser.normalizeEmail(rawEmail);
        AppUser u = users.findByEmail(email).orElseGet(() -> AppUser.create(email, email, "EMPLOYEE_HR_ADMIN"));
        boolean changed = false;
        if (!u.hasRole(RoleCodes.SUPER_ADMIN)) {
            Set<Role> r = new HashSet<>(u.getRoles());
            r.add(roles.findByCode(RoleCodes.SUPER_ADMIN)
                    .orElseThrow(() -> new IllegalStateException("SUPER_ADMIN role is not seeded")));
            u.setRoles(r);
            changed = true;
        }
        if (!u.isActive()) {
            setStatus(u, UserStatus.ACTIVE, "Bootstrap Super Admin (BOOTSTRAP_SUPER_ADMIN_EMAILS)");
            changed = true;
        }
        if (changed) {
            users.save(u);
            audit.log(AuditCategory.SECURITY, "SUPER_ADMIN_BOOTSTRAPPED", "ADMIN_USER", u.getId(), details("email", email));
        }
        return changed;
    }

    // ------------------------------------------------------------------ helpers

    private AppUser get(UUID id) {
        return users.findWithAccessById(id).orElseThrow(() -> APIException.notFound("User", id));
    }

    private AdminUserResponse view(AppUser u) {
        String managerName = u.getManagerId() == null ? null
                : users.findById(u.getManagerId()).map(AppUser::getFullName).orElse(null);
        return AdminUserResponse.of(u, AccessResolverService.effectiveScope(u), managerName);
    }

    private Set<Role> assignableRoles(Collection<String> codes, Set<String> alreadyHeld) {
        Set<String> wanted = codes.stream().map(c -> c.trim().toUpperCase()).collect(Collectors.toSet());
        List<Role> found = roles.findByCodeIn(wanted);
        Set<String> foundCodes = found.stream().map(Role::getCode).collect(Collectors.toSet());
        Set<String> unknown = new TreeSet<>(wanted);
        unknown.removeAll(foundCodes);
        if (!unknown.isEmpty()) {
            throw APIException.badRequest("UNKNOWN_ROLE", "Unknown role(s): " + unknown);
        }
        Set<String> inactive = found.stream().filter(r -> !r.isActive()).map(Role::getCode)
                .filter(c -> !alreadyHeld.contains(c))
                .collect(Collectors.toCollection(TreeSet::new));
        if (!inactive.isEmpty()) {
            throw APIException.badRequest("ROLE_INACTIVE", "Role(s) " + inactive + " are retired and can not be assigned");
        }
        Set<String> notAssignable = new TreeSet<>(wanted);
        notAssignable.retainAll(RoleCodes.NOT_ASSIGNABLE_BY_ADMIN);
        notAssignable.removeAll(alreadyHeld);
        if (!notAssignable.isEmpty()) {
            throw APIException.badRequest("ROLE_NOT_ASSIGNABLE", "Role(s) " + notAssignable
                    + " are given by registration / vendor onboarding, not from the admin user screen");
        }
        return new HashSet<>(found);
    }

    private UUID validManager(UUID managerId, UUID self) {
        if (managerId == null) {
            return null;
        }
        if (managerId.equals(self)) {
            throw APIException.badRequest("INVALID_MANAGER", "A user can not report to themselves");
        }
        AppUser manager = users.findById(managerId)
                .orElseThrow(() -> APIException.badRequest("INVALID_MANAGER", "Manager not found: " + managerId));
        if (!manager.isActive()) {
            throw APIException.badRequest("INVALID_MANAGER", "Manager " + manager.getFullName() + " is inactive");
        }
        if (users.findChainUpwards(managerId).contains(self.toString())) {
            throw APIException.badRequest("INVALID_MANAGER", "This reporting line would create a loop");
        }
        return managerId;
    }

    private static void applyScope(AppUser u, ScopeLevel level, Set<String> lobs, Set<String> locations) {
        Set<String> cleanLobs = clean(lobs);
        Set<String> cleanLocations = clean(locations);
        if (level == ScopeLevel.LOB && cleanLobs.isEmpty()) {
            throw APIException.badRequest("SCOPE_VALUES_REQUIRED", "Pick at least one LOB for LOB visibility");
        }
        if (level == ScopeLevel.LOCATION && cleanLocations.isEmpty()) {
            throw APIException.badRequest("SCOPE_VALUES_REQUIRED", "Pick at least one location for LOCATION visibility");
        }
        u.setScopeLevel(level);
        Set<UserScope> scopes = new HashSet<>();
        cleanLobs.forEach(v -> scopes.add(new UserScope(ScopeDimension.LOB, v)));
        cleanLocations.forEach(v -> scopes.add(new UserScope(ScopeDimension.LOCATION, v)));
        u.setScopes(scopes);
    }

    private void setStatus(AppUser u, UserStatus status, String reason) {
        u.setStatus(status);
        u.setStatusChangedDate(Instant.now());
        u.setStatusChangedBy(SecurityUtils.currentActorName());
        u.setStatusReason(trimToNull(reason));
    }

    private void checkEmailDomain(String email) {
        List<String> allowed = properties.getUsers().getAllowedEmailDomains().stream()
                .filter(StringUtils::hasText).map(d -> d.trim().toLowerCase()).toList();
        if (!allowed.isEmpty() && allowed.stream().noneMatch(d -> email.endsWith("@" + d))) {
            throw APIException.badRequest("EMAIL_DOMAIN_NOT_ALLOWED", "Only " + allowed + " e-mail addresses can be added");
        }
    }

    static void checkVersion(Long current, Long expected) {
        if (expected != null && !expected.equals(current)) {
            throw APIException.conflict("CONCURRENT_MODIFICATION",
                    "Someone else changed this record. Reload and try again.");
        }
    }

    private static Map<String, Object> snapshot(AppUser u) {
        return details("fullName", u.getFullName(), "employeeCode", u.getEmployeeCode(), "managerId", u.getManagerId(),
                "scopeLevel", u.getScopeLevel(), "lobs", new TreeSet<>(u.scopeValues(ScopeDimension.LOB)),
                "locations", new TreeSet<>(u.scopeValues(ScopeDimension.LOCATION)));
    }

    private static Set<String> describe(Collection<UserPermissionGrant> grants) {
        return grants.stream().map(g -> g.effect() + " " + g.permissionCode() + (g.conditional() ? " (C)" : "")
                        + (g.expiresAt() == null ? "" : " until " + g.expiresAt())
                        + (g.reason() == null ? "" : " reason: " + g.reason()))
                .collect(Collectors.toCollection(TreeSet::new));
    }

    private static Set<String> diff(Set<String> a, Set<String> b) {
        Set<String> d = new TreeSet<>(a);
        d.removeAll(b);
        return d;
    }

    private static Set<String> clean(Set<String> values) {
        return values == null ? Set.of() : values.stream().filter(StringUtils::hasText).map(String::trim)
                .collect(Collectors.toSet());
    }

    private static String escapeLike(String s) {
        return s.replace("!", "!!").replace("%", "!%").replace("_", "!_");
    }

    private static String trimToNull(String s) {
        return StringUtils.hasText(s) ? s.trim() : null;
    }

    /** Map.of() rejects nulls; audit details often contain them. */
    static Map<String, Object> details(Object... kv) {
        Map<String, Object> m = new LinkedHashMap<>();
        for (int i = 0; i < kv.length; i += 2) {
            m.put(String.valueOf(kv[i]), kv[i + 1]);
        }
        return m;
    }
}
