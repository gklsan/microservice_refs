package com.ags.health.hr.admin.enums;

/**
 * Row-level visibility, ordered narrowest to widest (the order is used to pick the widest one).
 * <ul>
 *   <li>NONE     - no records</li>
 *   <li>OWN      - records the user owns or is assigned to</li>
 *   <li>TEAM     - own + everyone reporting to the user (manager hierarchy) - TL</li>
 *   <li>LOB      - own + team + the user's lines of business - Manager</li>
 *   <li>LOCATION - own + team + the user's locations</li>
 *   <li>ALL      - everything - TA Head, Super Admin</li>
 * </ul>
 */
public enum ScopeLevel { NONE, OWN, TEAM, LOB, LOCATION, ALL }
