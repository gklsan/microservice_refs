package com.ags.health.hr.admin.services;

import com.ags.health.hr.admin.entities.AppUser;
import com.ags.health.hr.admin.enums.UserStatus;
import com.ags.health.hr.admin.exceptions.APIException;
import com.ags.health.hr.admin.resources.AppUserRepository;
import com.ags.health.hr.admin.resources.RoleRepository;
import com.ags.health.hr.admin.security.CurrentUser;
import com.ags.health.hr.admin.security.SecurityUtils;
import com.ags.health.hr.admin.utils.RoleCodes;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

/**
 * Safety rules that protect the admin module from locking itself out or being abused.
 * <ul>
 *   <li>Nobody changes their own account (roles, grants, scope, manager, status) - another Super Admin must.</li>
 *   <li>The last active Super Admin can not be deactivated or lose the SUPER_ADMIN role.</li>
 * </ul>
 * Who may call the admin endpoints at all (only an active SUPER_ADMIN) is enforced by @PreAuthorize.
 */
@Component
@RequiredArgsConstructor
public class AdminGuard {

    private final AppUserRepository users;
    private final RoleRepository roles;

    public void rejectSelfModification(AppUser target) {
        CurrentUser caller = SecurityUtils.requireUser();
        boolean sameRecord = caller.access() != null && target.getId().equals(caller.access().adminUserId());
        boolean sameEmail = caller.email() != null && target.getEmail().equalsIgnoreCase(caller.email());
        boolean sameLogin = caller.userId() != null && caller.userId().equals(target.getSmartieUserId());
        if (sameRecord || sameEmail || sameLogin) {
            throw APIException.forbidden("SELF_MODIFICATION_NOT_ALLOWED",
                    "You can not change your own account. Ask another Super Admin.");
        }
    }

    public void rejectRemovingLastSuperAdmin(AppUser target, boolean stillSuperAdminAfterChange, boolean stillActiveAfterChange) {
        boolean isActiveSuperAdminNow = target.isActive() && target.hasRole(RoleCodes.SUPER_ADMIN);
        boolean willBeActiveSuperAdmin = stillSuperAdminAfterChange && stillActiveAfterChange;
        if (!isActiveSuperAdminNow || willBeActiveSuperAdmin) {
            return;
        }
        // Self-changes are blocked, so via the API this only fires when two Super Admins remove each other
        // at the same moment. The row lock makes the second request wait and then see the real count.
        roles.lockByCode(RoleCodes.SUPER_ADMIN);
        if (users.countByRoleAndStatus(RoleCodes.SUPER_ADMIN, UserStatus.ACTIVE) <= 1) {
            throw APIException.conflict("LAST_SUPER_ADMIN",
                    "This is the last active Super Admin. Add another Super Admin first.");
        }
    }
}
