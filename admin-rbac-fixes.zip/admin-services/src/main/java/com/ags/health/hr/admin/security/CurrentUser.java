package com.ags.health.hr.admin.security;

/** Authenticated caller: identity from the verified JWT + access resolved by admin-services. */
public record CurrentUser(String userId, String email, String name, String userType, EffectiveAccess access) {

    public static final String SYSTEM_ID = "00000000-0000-0000-0000-000000000000";

    public static CurrentUser system(String caller) {
        return new CurrentUser(SYSTEM_ID, "system@" + caller, caller, "SYSTEM", null);
    }

    public boolean isSystem() {
        return SYSTEM_ID.equals(userId);
    }
}
