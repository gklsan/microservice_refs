package com.ags.health.hr.admin.security;

import java.util.Set;
import java.util.UUID;

/**
 * What a user can do right now. Computed live on every call - nothing is embedded in the JWT,
 * so a role, grant or status change applies on the next request (other services: after their cache TTL).
 *
 * @param userId                 smartie user id (JWT userId claim)
 * @param adminUserId            adm_app_user.id, null when the user has no admin record (fallback roles)
 * @param configured             true = admin record found, false = fallback roles of the userType
 * @param permissions            every granted permission code (conditional ones included)
 * @param conditionalPermissions subset of permissions that are only valid on records the user owns or is
 *                               assigned to ("C" in the matrix) - see {@link AccessEvaluator}
 */
public record EffectiveAccess(String userId,
                              UUID adminUserId,
                              String email,
                              boolean active,
                              boolean configured,
                              Set<String> roles,
                              Set<String> permissions,
                              Set<String> conditionalPermissions,
                              DataScope scope) {

    public EffectiveAccess {
        roles = roles == null ? Set.of() : Set.copyOf(roles);
        permissions = permissions == null ? Set.of() : Set.copyOf(permissions);
        conditionalPermissions = conditionalPermissions == null ? Set.of() : Set.copyOf(conditionalPermissions);
        scope = scope == null ? DataScope.none(userId) : scope;
    }

    public boolean has(String permission) {
        return active && permissions.contains(permission);
    }

    public boolean isConditional(String permission) {
        return conditionalPermissions.contains(permission);
    }

    public boolean hasRole(String role) {
        return active && roles.contains(role);
    }
}
