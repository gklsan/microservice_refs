package com.ags.health.hr.admin.services;

import com.ags.health.hr.admin.config.AdminProperties;
import com.ags.health.hr.admin.enums.UserStatus;
import com.ags.health.hr.admin.resources.AppUserRepository;
import com.ags.health.hr.admin.utils.RoleCodes;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.stereotype.Component;

/**
 * Day one: somebody must be able to manage roles. Every start makes sure each e-mail in
 * BOOTSTRAP_SUPER_ADMIN_EMAILS is an active SUPER_ADMIN (idempotent, audited when it changes something).
 * It is also the break-glass path if every Super Admin was deactivated directly in the database.
 */
@Slf4j
@Component
@RequiredArgsConstructor
public class BootstrapSuperAdminRunner implements ApplicationRunner {

    private final AdminProperties properties;
    private final AdminUserService adminUserService;
    private final AppUserRepository users;

    @Override
    public void run(ApplicationArguments args) {
        properties.getBootstrap().getSuperAdminEmails().stream()
                .filter(e -> e != null && !e.isBlank())
                .forEach(email -> {
                    try {
                        if (adminUserService.ensureSuperAdmin(email)) {
                            log.info("Bootstrap Super Admin ensured: {}", email);
                        }
                    } catch (RuntimeException ex) {
                        log.error("Could not bootstrap Super Admin {}: {}", email, ex.getMessage());
                    }
                });
        if (users.countByRoleAndStatus(RoleCodes.SUPER_ADMIN, UserStatus.ACTIVE) == 0) {
            log.warn("No active SUPER_ADMIN exists. Set BOOTSTRAP_SUPER_ADMIN_EMAILS and restart, "
                    + "otherwise nobody can manage users or roles.");
        }
    }
}
