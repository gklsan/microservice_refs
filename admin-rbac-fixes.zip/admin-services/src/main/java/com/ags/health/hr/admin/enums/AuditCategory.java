package com.ags.health.hr.admin.enums;

public enum AuditCategory { ACTIVITY, APPROVAL, WORKFLOW_TRANSITION, CONFIG_CHANGE, SECURITY, NOTIFICATION }
