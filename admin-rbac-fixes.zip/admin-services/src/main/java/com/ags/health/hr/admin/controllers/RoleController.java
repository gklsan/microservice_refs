package com.ags.health.hr.admin.controllers;

import com.ags.health.hr.admin.data.RoleRequests;
import com.ags.health.hr.admin.data.RoleResponses;
import com.ags.health.hr.admin.services.RoleService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.Map;

/**
 * Roles, permission catalogue and the role x permission matrix (tracker #1-3 default permission sets per object,
 * #25 matrix, S2 #37 role creation). Changes: active SUPER_ADMIN only.
 */
@RestController
@RequestMapping("/admin")
@RequiredArgsConstructor
public class RoleController {

    private final RoleService service;

    @GetMapping("/roles")
    @PreAuthorize("hasAuthority('ROLE:VIEW')")
    public List<RoleResponses.RoleView> roles(@RequestParam(defaultValue = "true") boolean includeInactive) {
        return service.list(includeInactive);
    }

    @GetMapping("/roles/{code}")
    @PreAuthorize("hasAuthority('ROLE:VIEW')")
    public RoleResponses.RoleView role(@PathVariable String code) {
        return service.get(code);
    }

    @PostMapping("/roles")
    @PreAuthorize("hasRole('SUPER_ADMIN') and hasAuthority('ROLE:MANAGE')")
    public ResponseEntity<RoleResponses.RoleView> create(@Valid @RequestBody RoleRequests.CreateRole req) {
        return new ResponseEntity<>(service.create(req), HttpStatus.CREATED);
    }

    @PutMapping("/roles/{code}")
    @PreAuthorize("hasRole('SUPER_ADMIN') and hasAuthority('ROLE:MANAGE')")
    public RoleResponses.RoleView update(@PathVariable String code, @Valid @RequestBody RoleRequests.UpdateRole req) {
        return service.update(code, req);
    }

    @PostMapping("/roles/{code}/reset-defaults")
    @PreAuthorize("hasRole('SUPER_ADMIN') and hasAuthority('ROLE:MANAGE')")
    public RoleResponses.RoleView reset(@PathVariable String code) {
        return service.resetToDefaults(code);
    }

    @GetMapping("/permissions")
    @PreAuthorize("hasAuthority('ROLE:VIEW')")
    public List<RoleResponses.PermissionView> permissions() {
        return service.catalogue();
    }

    @GetMapping("/permission-matrix")
    @PreAuthorize("hasAuthority('ROLE:VIEW')")
    public RoleResponses.Matrix matrix() {
        return service.matrix();
    }

    @PutMapping("/permission-matrix")
    @PreAuthorize("hasRole('SUPER_ADMIN') and hasAuthority('ROLE:MANAGE')")
    public RoleResponses.Matrix saveMatrix(@Valid @RequestBody RoleRequests.MatrixUpdate req) {
        return service.updateMatrix(req);
    }

    @GetMapping("/permission-matrix/defaults")
    @PreAuthorize("hasAuthority('ROLE:VIEW')")
    public Map<String, List<RoleRequests.PermissionItem>> defaults(@RequestParam(required = false) String objectType) {
        return service.defaults(objectType);
    }
}
