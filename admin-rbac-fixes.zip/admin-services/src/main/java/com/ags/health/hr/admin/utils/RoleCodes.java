package com.ags.health.hr.admin.utils;

import java.util.Set;

/** Role and permission codes the code itself depends on. Everything else is data. */
public final class RoleCodes {

    public static final String SUPER_ADMIN = "SUPER_ADMIN";
    public static final String CANDIDATE = "CANDIDATE";
    public static final String VENDOR = "VENDOR";

    public static final String TA_HEAD = "TA_HEAD";

    public static final String USER_VIEW = "USER:VIEW";
    public static final String USER_MANAGE = "USER:MANAGE";
    public static final String ROLE_VIEW = "ROLE:VIEW";
    public static final String ROLE_MANAGE = "ROLE:MANAGE";
    public static final String CONFIG_VIEW = "CONFIG:VIEW";
    public static final String CONFIG_MANAGE = "CONFIG:MANAGE";

    /** SUPER_ADMIN can never lose these - otherwise nobody could manage users, roles or configuration any more. */
    public static final Set<String> SUPER_ADMIN_LOCKED =
            Set.of(USER_VIEW, USER_MANAGE, ROLE_VIEW, ROLE_MANAGE, CONFIG_VIEW, CONFIG_MANAGE);

    /** Codes used internally by service-to-service calls; can not be created as roles. */
    public static final Set<String> RESERVED = Set.of("INTERNAL", "SYSTEM");

    /** Roles an admin can not give to internal staff from the admin user screen. */
    public static final Set<String> NOT_ASSIGNABLE_BY_ADMIN = Set.of(CANDIDATE, VENDOR);

    private RoleCodes() {
    }
}
