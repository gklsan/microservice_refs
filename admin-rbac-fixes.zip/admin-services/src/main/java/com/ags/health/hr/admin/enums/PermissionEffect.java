package com.ags.health.hr.admin.enums;

/** User-level override on top of role permissions. DENY always wins over any ALLOW. */
public enum PermissionEffect { ALLOW, DENY }
