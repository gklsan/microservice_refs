package com.ags.health.hr.admin.data;

import com.ags.health.hr.admin.enums.ScopeLevel;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;

import java.util.Set;
import java.util.UUID;

/**
 * Profile + data scope. E-mail is the link to the login identity and can not change; roles and
 * permission grants have their own endpoints (separate audit events, separate UI sections).
 *
 * @param version optional - send the version you loaded to get a 409 instead of overwriting someone else's edit
 */
public record UpdateAdminUserRequest(
        @NotBlank @Size(max = 200) String fullName,
        @Size(max = 50) String employeeCode,
        UUID managerId,
        ScopeLevel scopeLevel,
        Set<@NotBlank @Size(max = 100) String> lobs,
        Set<@NotBlank @Size(max = 100) String> locations,
        Long version) {
}
