package com.ags.health.hr.admin.entities;

import jakarta.persistence.Column;
import jakarta.persistence.Embeddable;

/**
 * One cell of the role x permission matrix. conditional = "C" (owner / assignee only), false = "A".
 * Stored as an element collection: a full replace is a delete-by-role followed by inserts, in that order,
 * so keeping a permission while flipping its flag never hits the primary key.
 */
@Embeddable
public record RolePermission(@Column(name = "permission_code", nullable = false) String permissionCode,
                             @Column(name = "conditional", nullable = false) boolean conditional) {
}
