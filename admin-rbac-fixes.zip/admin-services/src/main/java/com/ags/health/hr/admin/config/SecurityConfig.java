package com.ags.health.hr.admin.config;

import com.ags.health.hr.admin.security.CorrelationIdFilter;
import com.ags.health.hr.admin.security.InternalApiKeyFilter;
import com.ags.health.hr.admin.security.JwtAuthFilter;
import com.ags.health.hr.admin.security.ProblemResponseWriter;
import com.ags.health.hr.admin.services.AccessResolverService;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;
import org.springframework.security.web.authentication.www.BasicAuthenticationFilter;
import org.springframework.security.web.context.SecurityContextHolderFilter;

/**
 * Stateless. Login / registration / public job pages are NOT here - they stay in auth-services, which the
 * gateway leaves open. Everything in admin-services needs a verified JWT, except health checks, and
 * /internal/** needs the service key.
 */
@Configuration
@EnableMethodSecurity
public class SecurityConfig {

    private static final String[] PUBLIC = {"/actuator/health/**", "/actuator/info", "/error"};
    private static final String[] SWAGGER = {"/swagger-ui.html", "/swagger-ui/**", "/v3/api-docs/**", "/openapi.yaml"};

    @Bean
    public ProblemResponseWriter problemResponseWriter(ObjectMapper mapper) {
        return new ProblemResponseWriter(mapper);
    }

    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http, AdminProperties props,
                                                   AccessResolverService accessResolver,
                                                   ProblemResponseWriter problems,
                                                   @Value("${springdoc.swagger-ui.enabled:true}") boolean swaggerEnabled)
            throws Exception {
        JwtAuthFilter jwtFilter = new JwtAuthFilter(props.getSecurity().getJwtSecret(), accessResolver, problems);
        InternalApiKeyFilter internalFilter = new InternalApiKeyFilter(props.getSecurity().getInternalApiKey());

        http.csrf(c -> c.disable())
            .cors(c -> c.disable())   // CORS is handled once, at the gateway
            .httpBasic(b -> b.disable())
            .formLogin(f -> f.disable())
            .sessionManagement(s -> s.sessionCreationPolicy(SessionCreationPolicy.STATELESS))
            .authorizeHttpRequests(auth -> auth
                    .requestMatchers(HttpMethod.OPTIONS, "/**").permitAll()
                    .requestMatchers(PUBLIC).permitAll()
                    .requestMatchers(swaggerEnabled ? SWAGGER : new String[]{"/__swagger-disabled__"}).permitAll()
                    .requestMatchers("/internal/**").hasRole("INTERNAL")
                    .anyRequest().authenticated())
            .exceptionHandling(e -> e
                    .authenticationEntryPoint(problems.entryPoint())
                    .accessDeniedHandler(problems.accessDeniedHandler()))
            .addFilterBefore(new CorrelationIdFilter(), SecurityContextHolderFilter.class)
            // internal key first, then the user JWT (both before the unused Basic auth slot)
            .addFilterBefore(internalFilter, UsernamePasswordAuthenticationFilter.class)
            .addFilterBefore(jwtFilter, BasicAuthenticationFilter.class);
        return http.build();
    }
}
