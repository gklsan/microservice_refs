package com.ags.health.hr.admin.entities;

import com.ags.health.hr.admin.enums.PermissionEffect;
import jakarta.persistence.Column;
import jakarta.persistence.Embeddable;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;

import java.time.Instant;

/** Granular user-based permission: ALLOW adds to the role permissions, DENY removes (deny wins). */
@Embeddable
public record UserPermissionGrant(
        @Column(name = "permission_code", nullable = false) String permissionCode,
        @Enumerated(EnumType.STRING) @Column(name = "effect", nullable = false) PermissionEffect effect,
        @Column(name = "conditional", nullable = false) boolean conditional,
        @Column(name = "expires_at") Instant expiresAt,
        @Column(name = "reason") String reason,
        @Column(name = "granted_by") String grantedBy,
        @Column(name = "granted_date", nullable = false) Instant grantedDate) {

    public boolean isLive(Instant now) {
        return expiresAt == null || expiresAt.isAfter(now);
    }
}
