package com.ags.health.hr.admin.data;

import com.ags.health.hr.admin.security.DataScope;

import java.util.Set;

public final class RbacDtos {

    private RbacDtos() {
    }

    /** What the UI needs after login to show / hide menus and buttons. */
    public record Me(String userId, String email, String name, String userType, boolean active, boolean configured,
                     Set<String> roles, Set<String> permissions, Set<String> conditionalPermissions, DataScope scope) {
    }

    public record CheckRequest(String permission, String objectType, String objectId, String ownerId,
                               Set<String> assigneeIds, String lob, String location) {
    }

    public record CheckResponse(boolean allowed, String reason) {
    }
}
