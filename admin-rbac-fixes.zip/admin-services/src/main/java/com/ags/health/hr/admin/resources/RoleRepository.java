package com.ags.health.hr.admin.resources;

import com.ags.health.hr.admin.entities.Role;
import jakarta.persistence.LockModeType;
import org.springframework.data.jpa.repository.EntityGraph;
import org.springframework.data.jpa.repository.Lock;
import org.springframework.data.repository.query.Param;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.Collection;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

public interface RoleRepository extends JpaRepository<Role, UUID> {

    @EntityGraph(attributePaths = "permissions")
    Optional<Role> findByCode(String code);

    @EntityGraph(attributePaths = "permissions")
    List<Role> findByCodeIn(Collection<String> codes);

    @EntityGraph(attributePaths = "permissions")
    List<Role> findAllByOrderByCodeAsc();

    /** Row lock on a role - serialises "remove a Super Admin" so two admins can not remove each other at once. */
    @Lock(LockModeType.PESSIMISTIC_WRITE)
    @Query("select r from Role r where r.code = :code")
    Optional<Role> lockByCode(@Param("code") String code);

    /** [roleCode, active user count] - shown on the role list ("used by N users"). */
    @Query(value = """
            SELECT r.code, COUNT(u.id)
            FROM adm_role r
            LEFT JOIN adm_user_role ur ON ur.role_id = r.id
            LEFT JOIN adm_app_user u ON u.id = ur.user_id AND u.status = 'ACTIVE'
            GROUP BY r.code
            """, nativeQuery = true)
    List<Object[]> countActiveUsersPerRole();
}
