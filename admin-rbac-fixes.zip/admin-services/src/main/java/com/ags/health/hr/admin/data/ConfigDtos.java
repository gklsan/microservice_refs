package com.ags.health.hr.admin.data;

import com.ags.health.hr.admin.entities.EnterpriseConfig;
import com.ags.health.hr.admin.enums.ConfigValueType;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;

import java.time.Instant;

public final class ConfigDtos {

    private ConfigDtos() {
    }

    public record Create(@NotBlank @Pattern(regexp = "[a-z0-9][a-z0-9.\\-]{2,149}") String key,
                         @NotNull @Size(max = 10000) String value,
                         @NotNull ConfigValueType valueType,
                         @NotBlank @Pattern(regexp = "[A-Z][A-Z0-9_]{1,59}") String category,
                         @Size(max = 500) String description) {
    }

    /** version optional - send what you loaded to get a 409 instead of overwriting another admin's change. */
    public record Update(@NotNull @Size(max = 10000) String value,
                        @Size(max = 500) String description,
                        Long version) {
    }

    public record View(String key, String value, ConfigValueType valueType, String category, String description,
                       Instant updatedDate, String updatedBy, Long version) {

        public static View of(EnterpriseConfig c) {
            return new View(c.getKey(), c.getValue(), c.getValueType(), c.getCategory(), c.getDescription(),
                    c.getUpdatedDate() != null ? c.getUpdatedDate() : c.getCreatedDate(),
                    c.getUpdatedBy() != null ? c.getUpdatedBy() : c.getCreatedBy(), c.getVersion());
        }
    }
}
