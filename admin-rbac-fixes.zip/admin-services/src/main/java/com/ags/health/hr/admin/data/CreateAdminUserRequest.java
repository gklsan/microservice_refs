package com.ags.health.hr.admin.data;

import com.ags.health.hr.admin.enums.ScopeLevel;
import com.ags.health.hr.admin.enums.UserType;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

import java.util.Set;
import java.util.UUID;

/**
 * Admin user account creation. The login identity is NOT created here: the person signs in through
 * auth-services / Azure AD as today and is matched on e-mail.
 *
 * @param scopeLevel optional explicit visibility (e.g. RECRUITMENT_MANAGER as TL = TEAM, Manager = LOB,
 *                   TA Head = ALL). Null = the widest default of the chosen roles.
 * @param lobs       required when scopeLevel = LOB
 * @param locations  required when scopeLevel = LOCATION, optional narrowing for LOB
 */
public record CreateAdminUserRequest(
        @NotBlank @Email @Size(max = 254) String email,
        @NotBlank @Size(max = 200) String fullName,
        @Size(max = 50) String employeeCode,
        @NotNull UserType userType,
        @NotEmpty @Size(max = 10) Set<@NotBlank String> roles,
        UUID managerId,
        ScopeLevel scopeLevel,
        Set<@NotBlank @Size(max = 100) String> lobs,
        Set<@NotBlank @Size(max = 100) String> locations) {
}
