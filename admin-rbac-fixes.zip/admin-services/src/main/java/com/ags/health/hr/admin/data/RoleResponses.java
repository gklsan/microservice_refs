package com.ags.health.hr.admin.data;

import com.ags.health.hr.admin.entities.Permission;
import com.ags.health.hr.admin.entities.Role;
import com.ags.health.hr.admin.entities.RolePermission;
import com.ags.health.hr.admin.enums.ScopeLevel;

import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.UUID;

public final class RoleResponses {

    private RoleResponses() {
    }

    public record RoleView(UUID id, String code, String legacyCode, String name, String description,
                           ScopeLevel defaultScope, boolean systemRole, boolean active, long activeUserCount,
                           List<RoleRequests.PermissionItem> permissions, Long version) {

        public static RoleView of(Role r, long activeUserCount) {
            return new RoleView(r.getId(), r.getCode(), r.getLegacyCode(), r.getName(), r.getDescription(),
                    r.getDefaultScope(), r.isSystemRole(), r.isActive(), activeUserCount,
                    r.getPermissions().stream().sorted(Comparator.comparing(RolePermission::permissionCode))
                            .map(p -> new RoleRequests.PermissionItem(p.permissionCode(), p.conditional())).toList(),
                    r.getVersion());
        }
    }

    public record PermissionView(String code, String objectType, String action, String module, String description,
                                 boolean privileged) {

        public static PermissionView of(Permission p) {
            return new PermissionView(p.getCode(), p.getObjectType(), p.getAction(), p.getModule(), p.getDescription(),
                    p.isPrivileged());
        }
    }

    /**
     * Role x permission grid. grants: roleCode -> (permissionCode -> "A" | "C"). Missing = not granted.
     */
    public record Matrix(List<RoleView> roles, List<PermissionView> permissions,
                         Map<String, Map<String, String>> grants) {
    }
}
