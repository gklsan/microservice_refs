package com.ags.health.hr.admin.services;

import com.ags.health.hr.admin.data.ConfigDtos;
import com.ags.health.hr.admin.entities.EnterpriseConfig;
import com.ags.health.hr.admin.enums.AuditCategory;
import com.ags.health.hr.admin.enums.ConfigValueType;
import com.ags.health.hr.admin.exceptions.APIException;
import com.ags.health.hr.admin.resources.EnterpriseConfigRepository;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import java.math.BigDecimal;
import java.util.List;
import java.util.regex.Pattern;

/**
 * Enterprise-level configuration (tracker #32 "Restrict enterprise configuration to Admin", S2 #40 screen).
 * Writes are limited to an active SUPER_ADMIN at the controller; values are type-checked so services that
 * read them never break at runtime; every change is audited with before / after.
 */
@Service
@Transactional
@RequiredArgsConstructor
public class ConfigService {

    /** Credentials must never land in a plain table - they go to the S2 secret store (tracker #33). */
    private static final Pattern SECRET_LIKE =
            Pattern.compile("(?i).*(password|passwd|secret|token|api[-_.]?key|credential|private[-_.]?key).*");

    private final EnterpriseConfigRepository repo;
    private final ObjectMapper mapper;
    private final AuditService audit;

    @Transactional(readOnly = true)
    public List<ConfigDtos.View> list(String category) {
        List<EnterpriseConfig> rows = StringUtils.hasText(category)
                ? repo.findByCategoryOrderByKeyAsc(category.trim().toUpperCase())
                : repo.findAllByOrderByCategoryAscKeyAsc();
        return rows.stream().map(ConfigDtos.View::of).toList();
    }

    @Transactional(readOnly = true)
    public ConfigDtos.View get(String key) {
        return ConfigDtos.View.of(find(key));
    }

    public ConfigDtos.View create(ConfigDtos.Create req) {
        if (SECRET_LIKE.matcher(req.key()).matches()) {
            throw APIException.badRequest("USE_SECRET_STORE",
                    "Credentials and keys are not stored as enterprise configuration. Use the secret store.");
        }
        if (repo.existsById(req.key())) {
            throw APIException.conflict("CONFIG_EXISTS", "Configuration already exists: " + req.key());
        }
        validate(req.valueType(), req.value());
        EnterpriseConfig c = new EnterpriseConfig();
        c.setKey(req.key());
        c.setValue(req.value().trim());
        c.setValueType(req.valueType());
        c.setCategory(req.category());
        c.setDescription(req.description());
        repo.save(c);
        audit.log(AuditCategory.CONFIG_CHANGE, "ENTERPRISE_CONFIG_CREATED", "CONFIG", c.getKey(),
                AdminUserService.details("value", c.getValue(), "valueType", c.getValueType(), "category", c.getCategory()));
        return ConfigDtos.View.of(c);
    }

    public ConfigDtos.View update(String key, ConfigDtos.Update req) {
        EnterpriseConfig c = find(key);
        AdminUserService.checkVersion(c.getVersion(), req.version());
        validate(c.getValueType(), req.value());
        String before = c.getValue();
        String descriptionBefore = c.getDescription();
        c.setValue(req.value().trim());
        if (req.description() != null) {
            c.setDescription(req.description());
        }
        boolean valueChanged = !java.util.Objects.equals(before, c.getValue());
        boolean descriptionChanged = !java.util.Objects.equals(descriptionBefore, c.getDescription());
        if (valueChanged || descriptionChanged) {
            audit.log(AuditCategory.CONFIG_CHANGE, "ENTERPRISE_CONFIG_UPDATED", "CONFIG", c.getKey(),
                    AdminUserService.details("before", before, "after", c.getValue(),
                            "descriptionBefore", descriptionBefore, "descriptionAfter", c.getDescription()));
        }
        return ConfigDtos.View.of(c);
    }

    private EnterpriseConfig find(String key) {
        return repo.findById(key).orElseThrow(() -> APIException.notFound("Configuration", key));
    }

    void validate(ConfigValueType type, String value) {
        try {
            switch (type) {
                case NUMBER -> new BigDecimal(value.trim());
                case BOOLEAN -> {
                    if (!"true".equalsIgnoreCase(value.trim()) && !"false".equalsIgnoreCase(value.trim())) {
                        throw new IllegalArgumentException("expected true or false");
                    }
                }
                case JSON -> mapper.readTree(value);
                case LIST -> {
                    JsonNode node = mapper.readTree(value);
                    if (!node.isArray()) {
                        throw new IllegalArgumentException("expected a JSON array, e.g. [7,30,180]");
                    }
                }
                case STRING -> {
                }
            }
        } catch (Exception e) {
            throw APIException.badRequest("INVALID_CONFIG_VALUE", "Value is not a valid " + type + ": " + e.getMessage());
        }
    }
}
