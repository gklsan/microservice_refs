package com.ags.health.hr.admin.enums;

/**
 * Legacy auth-services user type (smartie_user.user_type). Admin users can only be internal staff:
 * candidates self-register and vendors are onboarded by vendor-services.
 */
public enum UserType {
    EMPLOYEE_HR, EMPLOYEE_HR_ADMIN, EMPLOYEE_NON_HR;
}
