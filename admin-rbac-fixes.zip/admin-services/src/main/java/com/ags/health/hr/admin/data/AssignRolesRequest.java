package com.ags.health.hr.admin.data;

import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

import java.util.Set;

/**
 * Full replace of the user's roles. Idempotent: sending the same set twice changes nothing,
 * duplicates collapse, and "revoking" a role the user does not have is simply not listing it.
 * A user can hold several roles (e.g. EMPLOYEE + INTERVIEWER for a panel member).
 */
public record AssignRolesRequest(@NotNull @NotEmpty @Size(max = 10) Set<@NotNull String> roles) {
}
