package com.ags.health.hr.admin.data;

import com.ags.health.hr.admin.security.EffectiveAccess;

import java.util.List;

/**
 * "Why can this user do X?" - every permission with the sources that grant or deny it.
 * Shown next to the grant editor so an admin sees what a DENY is overriding.
 *
 * @param state GRANTED | CONDITIONAL | DENIED
 */
public record EffectiveAccessDetail(EffectiveAccess access, List<Line> lines) {

    public record Line(String permission, String module, String state, List<String> sources) {
    }
}
