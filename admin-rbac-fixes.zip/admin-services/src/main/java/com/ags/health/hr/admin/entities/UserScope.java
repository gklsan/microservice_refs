package com.ags.health.hr.admin.entities;

import com.ags.health.hr.admin.enums.ScopeDimension;
import jakarta.persistence.Column;
import jakarta.persistence.Embeddable;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;

@Embeddable
public record UserScope(@Enumerated(EnumType.STRING) @Column(name = "dimension", nullable = false) ScopeDimension dimension,
                        @Column(name = "scope_value", nullable = false) String value) {
}
