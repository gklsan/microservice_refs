package com.ags.health.hr.admin.security;

import com.ags.health.hr.admin.exceptions.APIException;
import org.springframework.http.HttpStatus;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;

import java.util.Optional;

/** The caller is always taken from the SecurityContext - never from a request body or parameter. */
public final class SecurityUtils {

    private SecurityUtils() {
    }

    public static Optional<CurrentUser> currentUser() {
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        if (auth != null && auth.getPrincipal() instanceof CurrentUser user) {
            return Optional.of(user);
        }
        return Optional.empty();
    }

    public static CurrentUser requireUser() {
        return currentUser().orElseThrow(() ->
                new APIException(HttpStatus.UNAUTHORIZED, "UNAUTHORIZED", "Not logged in"));
    }

    /** Value written into created_by / updated_by and audit rows. */
    public static String currentActorName() {
        return currentUser().map(u -> u.email() != null ? u.email() : u.userId()).orElse("system");
    }
}
