package com.ags.health.hr.admin.config;

import com.ags.health.hr.admin.security.SecurityUtils;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.auditing.DateTimeProvider;
import org.springframework.data.domain.AuditorAware;
import org.springframework.data.jpa.repository.config.EnableJpaAuditing;

import java.time.Instant;
import java.util.Optional;

/** Fills createdBy / updatedBy / createdDate / updatedDate from the caller in the SecurityContext. */
@Configuration
@EnableJpaAuditing(auditorAwareRef = "auditorAware", dateTimeProviderRef = "auditDateTimeProvider")
public class JpaAuditConfig {

    @Bean
    public AuditorAware<String> auditorAware() {
        return () -> Optional.of(SecurityUtils.currentActorName());
    }

    @Bean
    public DateTimeProvider auditDateTimeProvider() {
        return () -> Optional.of(Instant.now());
    }
}
