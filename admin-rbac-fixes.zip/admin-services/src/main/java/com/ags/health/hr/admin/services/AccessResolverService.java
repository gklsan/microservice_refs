package com.ags.health.hr.admin.services;

import com.ags.health.hr.admin.config.AdminProperties;
import com.ags.health.hr.admin.data.EffectiveAccessDetail;
import com.ags.health.hr.admin.entities.AppUser;
import com.ags.health.hr.admin.entities.Permission;
import com.ags.health.hr.admin.entities.Role;
import com.ags.health.hr.admin.entities.RolePermission;
import com.ags.health.hr.admin.entities.UserPermissionGrant;
import com.ags.health.hr.admin.enums.PermissionEffect;
import com.ags.health.hr.admin.enums.ScopeDimension;
import com.ags.health.hr.admin.enums.ScopeLevel;
import com.ags.health.hr.admin.resources.AppUserRepository;
import com.ags.health.hr.admin.resources.PermissionRepository;
import com.ags.health.hr.admin.resources.RoleRepository;
import com.ags.health.hr.admin.security.DataScope;
import com.ags.health.hr.admin.security.EffectiveAccess;
import com.ags.health.hr.admin.utils.RoleCodes;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import java.time.Instant;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Comparator;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.TreeMap;
import java.util.function.Function;
import java.util.stream.Collectors;

/**
 * The permission framework. Computed live, never stored in the JWT:
 * <pre>
 * inactive user   -> no roles, no permissions (login identity still valid, nothing is allowed)
 * roles           -> the user's ACTIVE roles (a retired role grants nothing from the next request)
 * permissions     -> union of role permissions  + live user ALLOW  - live user DENY  (deny wins)
 * conditional     -> a permission is conditional only if every source that grants it is conditional
 * scope level     -> user's explicit scope_level, else the widest default_scope of the active roles
 * team            -> all direct + indirect reports (manager hierarchy)
 * no admin record -> fallback roles of the legacy userType (new registrations); never SUPER_ADMIN
 * </pre>
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class AccessResolverService {

    private final AppUserRepository users;
    private final RoleRepository roles;
    private final PermissionRepository permissions;
    private final AdminProperties properties;

    @Transactional
    public EffectiveAccess resolve(String rawUserId, String rawEmail, String userType) {
        String userId = StringUtils.hasText(rawUserId) ? rawUserId.trim() : null;
        String email = AppUser.normalizeEmail(StringUtils.hasText(rawEmail) ? rawEmail : null);

        Optional<AppUser> found = find(userId, email);
        if (found.isEmpty()) {
            return fallback(userId, email, userType);
        }
        AppUser user = found.get();
        linkLogin(user, userId);
        String effectiveId = user.getSmartieUserId() != null ? user.getSmartieUserId() : userId;
        return compute(user, effectiveId);
    }

    @Transactional(readOnly = true)
    public EffectiveAccess forAdminUser(AppUser user) {
        return compute(user, user.getSmartieUserId());
    }

    /** Line-by-line explanation for the admin screen: which role or grant gives / removes each permission. */
    @Transactional(readOnly = true)
    public EffectiveAccessDetail explain(AppUser user) {
        EffectiveAccess access = forAdminUser(user);
        Map<String, Permission> catalogue = permissions.findAllByOrderBySortOrderAsc().stream()
                .collect(Collectors.toMap(Permission::getCode, Function.identity(), (a, b) -> a, LinkedHashMap::new));
        Map<String, List<String>> sources = new TreeMap<>();
        Instant now = Instant.now();
        for (Role r : user.getRoles()) {
            for (RolePermission rp : r.getPermissions()) {
                sources.computeIfAbsent(rp.permissionCode(), k -> new ArrayList<>())
                        .add("ROLE " + r.getCode() + (rp.conditional() ? " (C)" : "") + (r.isActive() ? "" : " [role inactive]"));
            }
        }
        for (UserPermissionGrant g : user.getPermissionGrants()) {
            sources.computeIfAbsent(g.permissionCode(), k -> new ArrayList<>())
                    .add("USER " + g.effect() + (g.conditional() ? " (C)" : "") + (g.isLive(now) ? "" : " [expired]"));
        }
        List<EffectiveAccessDetail.Line> lines = new ArrayList<>();
        sources.forEach((code, src) -> {
            String state = access.permissions().contains(code)
                    ? (access.isConditional(code) ? "CONDITIONAL" : "GRANTED")
                    : "DENIED";
            Permission p = catalogue.get(code);
            lines.add(new EffectiveAccessDetail.Line(code, p == null ? null : p.getModule(), state, src));
        });
        lines.sort(Comparator.comparingInt(l -> catalogue.containsKey(l.permission())
                ? catalogue.get(l.permission()).getSortOrder() : Integer.MAX_VALUE));
        return new EffectiveAccessDetail(access, lines);
    }

    /** Scope actually applied to a user: explicit value, else the widest default of the active roles. */
    public static ScopeLevel effectiveScope(AppUser user) {
        if (user.getScopeLevel() != null) {
            return user.getScopeLevel();
        }
        return user.getRoles().stream().filter(Role::isActive).map(Role::getDefaultScope)
                .max(Comparator.naturalOrder()).orElse(ScopeLevel.NONE);
    }

    private Optional<AppUser> find(String userId, String email) {
        Optional<AppUser> user = userId == null ? Optional.empty() : users.findWithAccessBySmartieUserId(userId);
        if (user.isEmpty() && email != null) {
            user = users.findWithAccessByEmail(email);
        }
        return user;
    }

    /**
     * First request after the admin created the account: remember the smartie user id.
     * find() already looked this id up and found nothing, so it is not linked to another record.
     */
    private void linkLogin(AppUser user, String userId) {
        if (userId == null) {
            return;
        }
        if (user.getSmartieUserId() == null) {
            user.setSmartieUserId(userId);
        } else if (!user.getSmartieUserId().equals(userId)) {
            log.warn("Admin user {} is linked to smartie user {} but the token carries {}", user.getId(),
                    user.getSmartieUserId(), userId);
        }
    }

    private EffectiveAccess compute(AppUser user, String userId) {
        if (!user.isActive()) {
            return new EffectiveAccess(userId, user.getId(), user.getEmail(), false, true,
                    Set.of(), Set.of(), Set.of(), DataScope.none(userId));
        }
        List<Role> activeRoles = user.getRoles().stream().filter(Role::isActive).toList();
        Map<String, Boolean> granted = rolePermissions(activeRoles); // code -> conditional

        Instant now = Instant.now();
        Set<String> deny = new HashSet<>();
        for (UserPermissionGrant g : user.getPermissionGrants()) {
            if (!g.isLive(now)) {
                continue;
            }
            if (g.effect() == PermissionEffect.DENY) {
                deny.add(g.permissionCode());
            } else {
                granted.merge(g.permissionCode(), g.conditional(), (a, b) -> a && b);
            }
        }
        deny.forEach(granted::remove);

        ScopeLevel level = effectiveScope(user);
        Set<String> team = switch (level) {
            case TEAM, LOB, LOCATION -> new HashSet<>(users.findTeamSmartieUserIds(user.getId()));
            default -> Set.of();
        };
        DataScope scope = new DataScope(level, userId, team,
                user.scopeValues(ScopeDimension.LOB), user.scopeValues(ScopeDimension.LOCATION));

        return new EffectiveAccess(userId, user.getId(), user.getEmail(), true, true,
                activeRoles.stream().map(Role::getCode).collect(Collectors.toSet()),
                granted.keySet(),
                granted.entrySet().stream().filter(Map.Entry::getValue).map(Map.Entry::getKey).collect(Collectors.toSet()),
                scope);
    }

    private EffectiveAccess fallback(String userId, String email, String userType) {
        List<String> codes = properties.getAccess().getFallbackRolesByUserType()
                .getOrDefault(userType == null ? "" : userType, List.of()).stream()
                .filter(c -> !RoleCodes.SUPER_ADMIN.equals(c))
                .toList();
        List<Role> fallbackRoles = codes.isEmpty() ? List.of()
                : roles.findByCodeIn(codes).stream().filter(Role::isActive).toList();
        Map<String, Boolean> granted = rolePermissions(fallbackRoles);
        ScopeLevel level = fallbackRoles.stream().map(Role::getDefaultScope).max(Comparator.naturalOrder())
                .orElse(ScopeLevel.NONE);
        return new EffectiveAccess(userId, null, email, true, false,
                fallbackRoles.stream().map(Role::getCode).collect(Collectors.toSet()),
                granted.keySet(),
                granted.entrySet().stream().filter(Map.Entry::getValue).map(Map.Entry::getKey).collect(Collectors.toSet()),
                new DataScope(level, userId, Set.of(), Set.of(), Set.of()));
    }

    /** Union over roles; unconditional wins when two roles grant the same permission. */
    private static Map<String, Boolean> rolePermissions(Collection<Role> activeRoles) {
        Map<String, Boolean> granted = new java.util.HashMap<>();
        for (Role r : activeRoles) {
            for (RolePermission rp : r.getPermissions()) {
                granted.merge(rp.permissionCode(), rp.conditional(), (a, b) -> a && b);
            }
        }
        return granted;
    }
}
