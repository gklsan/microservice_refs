package com.ags.health.hr.admin.data;

import jakarta.validation.constraints.Size;

/** Reason is mandatory for deactivation (checked in the service), optional for reactivation. */
public record StatusChangeRequest(@Size(max = 1000) String reason) {
}
