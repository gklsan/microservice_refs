package com.ags.health.hr.admin.exceptions;

import lombok.Getter;
import org.springframework.http.HttpStatus;

/**
 * Business error with an explicit HTTP status and a stable machine-readable code.
 * Unlike the other services' APIException, the status is not guessed from the message text.
 */
@Getter
public class APIException extends RuntimeException {

    private final HttpStatus status;
    private final String code;

    public APIException(HttpStatus status, String code, String message) {
        super(message);
        this.status = status;
        this.code = code;
    }

    public static APIException badRequest(String code, String message) {
        return new APIException(HttpStatus.BAD_REQUEST, code, message);
    }

    public static APIException notFound(String what, Object id) {
        return new APIException(HttpStatus.NOT_FOUND, "NOT_FOUND", what + " not found: " + id);
    }

    public static APIException conflict(String code, String message) {
        return new APIException(HttpStatus.CONFLICT, code, message);
    }

    public static APIException forbidden(String code, String message) {
        return new APIException(HttpStatus.FORBIDDEN, code, message);
    }
}
