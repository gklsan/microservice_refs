package com.ags.health.hr.admin.enums;

public enum ScopeDimension { LOB, LOCATION }
