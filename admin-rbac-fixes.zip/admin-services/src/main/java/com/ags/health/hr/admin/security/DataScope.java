package com.ags.health.hr.admin.security;

import com.ags.health.hr.admin.enums.ScopeLevel;

import java.util.Collections;
import java.util.Map;
import java.util.Set;

/**
 * Which records a user may see (BRD 4.3 "see only my team / my LOB / my location").
 * Same JSON shape as the reference digihire-platform-starter DataScope, so either client can read it.
 *
 * @param level         widest visibility of the user
 * @param userId        smartie user id - owner match
 * @param teamUserIds   smartie user ids of everyone reporting (directly or indirectly) to the user
 * @param lobs          lines of business assigned to the user
 * @param locations     locations assigned to the user
 * @param sharedObjects records shared with the user through an approved override, by object type
 *                      (e.g. CANDIDATE -> ids). Always empty until tracker #6 / #8 fill it.
 */
public record DataScope(ScopeLevel level, String userId, Set<String> teamUserIds, Set<String> lobs,
                        Set<String> locations, Map<String, Set<String>> sharedObjects) {

    public DataScope {
        level = level == null ? ScopeLevel.NONE : level;
        teamUserIds = teamUserIds == null ? Set.of() : Set.copyOf(teamUserIds);
        lobs = lobs == null ? Set.of() : Set.copyOf(lobs);
        locations = locations == null ? Set.of() : Set.copyOf(locations);
        sharedObjects = sharedObjects == null ? Map.of() : Map.copyOf(sharedObjects);
    }

    public DataScope(ScopeLevel level, String userId, Set<String> teamUserIds, Set<String> lobs, Set<String> locations) {
        this(level, userId, teamUserIds, lobs, locations, Map.of());
    }

    public static DataScope none(String userId) {
        return new DataScope(ScopeLevel.NONE, userId, Set.of(), Set.of(), Set.of(), Map.of());
    }

    public Set<String> sharedIds(String objectType) {
        return objectType == null ? Collections.emptySet() : sharedObjects.getOrDefault(objectType, Collections.emptySet());
    }
}
