package com.ags.health.hr.admin.entities;

import com.ags.health.hr.admin.enums.ScopeLevel;
import jakarta.persistence.CollectionTable;
import jakarta.persistence.Column;
import jakarta.persistence.ElementCollection;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.FetchType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.hibernate.annotations.BatchSize;

import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

@Entity
@Table(name = "adm_role")
@Getter
@Setter
@NoArgsConstructor
public class Role extends CommonEntity {

    @Id
    private UUID id;

    @Column(nullable = false, unique = true, updatable = false)
    private String code;

    @Column(name = "legacy_code", updatable = false)
    private String legacyCode;

    @Column(nullable = false)
    private String name;

    private String description;

    @Enumerated(EnumType.STRING)
    @Column(name = "default_scope", nullable = false)
    private ScopeLevel defaultScope = ScopeLevel.OWN;

    @Column(name = "system_role", nullable = false, updatable = false)
    private boolean systemRole;

    @Column(nullable = false)
    private boolean active = true;

    @BatchSize(size = 50)
    @ElementCollection(fetch = FetchType.LAZY)
    @CollectionTable(name = "adm_role_permission", joinColumns = @JoinColumn(name = "role_id"))
    private Set<RolePermission> permissions = new HashSet<>();

    public static Role create(String code, String name) {
        Role r = new Role();
        r.id = UUID.randomUUID();
        r.code = code;
        r.name = name;
        return r;
    }
}
