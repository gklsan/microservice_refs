package com.ags.health.hr.admin.data;

import com.ags.health.hr.admin.entities.AppUser;
import com.ags.health.hr.admin.enums.UserStatus;

import java.time.Instant;
import java.util.Set;
import java.util.TreeSet;
import java.util.UUID;

/** One row of the admin user list. */
public record AdminUserSummary(UUID id, String email, String fullName, String employeeCode, UserStatus status,
                               Set<String> roles, int grantCount, boolean loginLinked, Instant updatedDate) {

    public static AdminUserSummary of(AppUser u) {
        return new AdminUserSummary(u.getId(), u.getEmail(), u.getFullName(), u.getEmployeeCode(), u.getStatus(),
                new TreeSet<>(u.roleCodes()), u.getPermissionGrants().size(), u.getSmartieUserId() != null,
                u.getUpdatedDate() != null ? u.getUpdatedDate() : u.getCreatedDate());
    }
}
