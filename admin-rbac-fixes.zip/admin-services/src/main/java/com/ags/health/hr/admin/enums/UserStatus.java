package com.ags.health.hr.admin.enums;

public enum UserStatus { ACTIVE, INACTIVE }
