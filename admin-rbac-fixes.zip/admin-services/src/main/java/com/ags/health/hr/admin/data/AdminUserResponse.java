package com.ags.health.hr.admin.data;

import com.ags.health.hr.admin.entities.AppUser;
import com.ags.health.hr.admin.entities.Role;
import com.ags.health.hr.admin.entities.UserPermissionGrant;
import com.ags.health.hr.admin.enums.PermissionEffect;
import com.ags.health.hr.admin.enums.ScopeDimension;
import com.ags.health.hr.admin.enums.ScopeLevel;
import com.ags.health.hr.admin.enums.UserStatus;

import java.time.Instant;
import java.util.Comparator;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;
import java.util.UUID;

/** Full admin user record (detail screen). */
public record AdminUserResponse(UUID id, String smartieUserId, String email, String fullName, String employeeCode,
                                String userType, UserStatus status, List<RoleRef> roles,
                                ScopeLevel scopeLevel, ScopeLevel effectiveScopeLevel,
                                Set<String> lobs, Set<String> locations,
                                UUID managerId, String managerName,
                                List<GrantView> permissionGrants,
                                boolean loginLinked,
                                Instant statusChangedDate, String statusChangedBy, String statusReason,
                                Instant createdDate, String createdBy, Instant updatedDate, String updatedBy,
                                Long version) {

    public record RoleRef(String code, String name, boolean active) {
    }

    public record GrantView(String permission, PermissionEffect effect, boolean conditional, Instant expiresAt,
                            boolean expired, String reason, String grantedBy, Instant grantedDate) {
    }

    public static AdminUserResponse of(AppUser u, ScopeLevel effectiveScope, String managerName) {
        Instant now = Instant.now();
        return new AdminUserResponse(u.getId(), u.getSmartieUserId(), u.getEmail(), u.getFullName(), u.getEmployeeCode(),
                u.getUserType(), u.getStatus(),
                u.getRoles().stream().sorted(Comparator.comparing(Role::getCode))
                        .map(r -> new RoleRef(r.getCode(), r.getName(), r.isActive())).toList(),
                u.getScopeLevel(), effectiveScope,
                new TreeSet<>(u.scopeValues(ScopeDimension.LOB)), new TreeSet<>(u.scopeValues(ScopeDimension.LOCATION)),
                u.getManagerId(), managerName,
                u.getPermissionGrants().stream().sorted(Comparator.comparing(UserPermissionGrant::permissionCode))
                        .map(g -> new GrantView(g.permissionCode(), g.effect(), g.conditional(), g.expiresAt(),
                                !g.isLive(now), g.reason(), g.grantedBy(), g.grantedDate())).toList(),
                u.getSmartieUserId() != null,
                u.getStatusChangedDate(), u.getStatusChangedBy(), u.getStatusReason(),
                u.getCreatedDate(), u.getCreatedBy(), u.getUpdatedDate(), u.getUpdatedBy(), u.getVersion());
    }
}
