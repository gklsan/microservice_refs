package com.ags.health.hr.admin;

import com.ags.health.hr.admin.config.DatabaseUrlGuard;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.security.servlet.UserDetailsServiceAutoConfiguration;
import org.springframework.boot.context.properties.ConfigurationPropertiesScan;

// no in-memory default user / "Using generated security password": every caller is authenticated by JWT or X-Internal-Key
@SpringBootApplication(exclude = UserDetailsServiceAutoConfiguration.class)
@ConfigurationPropertiesScan
public class AdminServicesApplication {

    public static void main(String[] args) {
        SpringApplication app = new SpringApplication(AdminServicesApplication.class);
        app.addListeners(new DatabaseUrlGuard());
        app.run(args);
    }
}
