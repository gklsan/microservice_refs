package com.ags.health.hr.admin.controllers;

import com.ags.health.hr.admin.data.AdminUserResponse;
import com.ags.health.hr.admin.data.AdminUserSummary;
import com.ags.health.hr.admin.data.AssignRolesRequest;
import com.ags.health.hr.admin.data.CreateAdminUserRequest;
import com.ags.health.hr.admin.data.EffectiveAccessDetail;
import com.ags.health.hr.admin.data.PageResponse;
import com.ags.health.hr.admin.data.StatusChangeRequest;
import com.ags.health.hr.admin.data.UpdateAdminUserRequest;
import com.ags.health.hr.admin.data.UserPermissionGrantRequest;
import com.ags.health.hr.admin.enums.UserStatus;
import com.ags.health.hr.admin.exceptions.APIException;
import com.ags.health.hr.admin.services.AdminUserService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * Admin user accounts: creation, list / search / deactivate / reactivate, roles, and granular
 * user-based permissions. Reading needs USER:VIEW; every change needs an active SUPER_ADMIN.
 */
@RestController
@RequestMapping("/admin/users")
@RequiredArgsConstructor
public class AdminUserController {

    private static final Map<String, String> SORTABLE = Map.of(
            "fullName", "fullName", "email", "email", "status", "status", "updatedDate", "updatedDate");

    private final AdminUserService service;

    @PostMapping
    @PreAuthorize("hasRole('SUPER_ADMIN') and hasAuthority('USER:MANAGE')")
    public ResponseEntity<AdminUserResponse> create(@Valid @RequestBody CreateAdminUserRequest req) {
        return new ResponseEntity<>(service.create(req), HttpStatus.CREATED);
    }

    @GetMapping
    @PreAuthorize("hasAuthority('USER:VIEW')")
    public PageResponse<AdminUserSummary> search(@RequestParam(required = false) String search,
                                                 @RequestParam(required = false) UserStatus status,
                                                 @RequestParam(required = false) String role,
                                                 @RequestParam(defaultValue = "0") int page,
                                                 @RequestParam(defaultValue = "20") int size,
                                                 @RequestParam(defaultValue = "fullName") String sort,
                                                 @RequestParam(defaultValue = "ASC") Sort.Direction direction) {
        String property = SORTABLE.get(sort);
        if (property == null) {
            throw APIException.badRequest("INVALID_SORT", "Sort by one of " + SORTABLE.keySet());
        }
        PageRequest pageable = PageRequest.of(Math.max(page, 0), Math.min(Math.max(size, 1), 100),
                Sort.by(direction, property).and(Sort.by("id")));
        return service.search(search, status, role, pageable);
    }

    @GetMapping("/{id}")
    @PreAuthorize("hasAuthority('USER:VIEW')")
    public AdminUserResponse get(@PathVariable UUID id) {
        return service.find(id);
    }

    @PutMapping("/{id}")
    @PreAuthorize("hasRole('SUPER_ADMIN') and hasAuthority('USER:MANAGE')")
    public AdminUserResponse update(@PathVariable UUID id, @Valid @RequestBody UpdateAdminUserRequest req) {
        return service.update(id, req);
    }

    /** User keeps the login (auth-services) but loses every role and permission on the next request. */
    @PatchMapping("/{id}/deactivate")
    @PreAuthorize("hasRole('SUPER_ADMIN') and hasAuthority('USER:MANAGE')")
    public AdminUserResponse deactivate(@PathVariable UUID id, @Valid @RequestBody StatusChangeRequest req) {
        return service.deactivate(id, req.reason());
    }

    @PatchMapping("/{id}/reactivate")
    @PreAuthorize("hasRole('SUPER_ADMIN') and hasAuthority('USER:MANAGE')")
    public AdminUserResponse reactivate(@PathVariable UUID id,
                                        @Valid @RequestBody(required = false) StatusChangeRequest req) {
        return service.reactivate(id, req == null ? null : req.reason());
    }

    @PutMapping("/{id}/roles")
    @PreAuthorize("hasRole('SUPER_ADMIN') and hasAuthority('USER:MANAGE')")
    public AdminUserResponse roles(@PathVariable UUID id, @Valid @RequestBody AssignRolesRequest req) {
        return service.assignRoles(id, req);
    }

    @GetMapping("/{id}/permissions")
    @PreAuthorize("hasAuthority('USER:VIEW')")
    public List<AdminUserResponse.GrantView> permissions(@PathVariable UUID id) {
        return service.grants(id);
    }

    @PutMapping("/{id}/permissions")
    @PreAuthorize("hasRole('SUPER_ADMIN') and hasAuthority('USER:MANAGE')")
    public AdminUserResponse setPermissions(@PathVariable UUID id, @Valid @RequestBody UserPermissionGrantRequest req) {
        return service.setPermissions(id, req);
    }

    /** Every permission the user ends up with and which role / grant gives or removes it. */
    @GetMapping("/{id}/effective-access")
    @PreAuthorize("hasAuthority('USER:VIEW')")
    public EffectiveAccessDetail effectiveAccess(@PathVariable UUID id) {
        return service.effectiveAccess(id);
    }
}
