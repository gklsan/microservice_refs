package com.ags.health.hr.admin.resources;

import com.ags.health.hr.admin.entities.EnterpriseConfig;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface EnterpriseConfigRepository extends JpaRepository<EnterpriseConfig, String> {

    List<EnterpriseConfig> findAllByOrderByCategoryAscKeyAsc();

    List<EnterpriseConfig> findByCategoryOrderByKeyAsc(String category);
}
