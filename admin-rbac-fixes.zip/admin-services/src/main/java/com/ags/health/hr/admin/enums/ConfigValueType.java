package com.ags.health.hr.admin.enums;

/** How an enterprise configuration value is validated and rendered (number input, toggle, JSON editor, tag list). */
public enum ConfigValueType { STRING, NUMBER, BOOLEAN, JSON, LIST }
