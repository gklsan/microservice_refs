package com.ags.health.hr.admin.security;

import com.ags.health.hr.admin.exceptions.APIExceptionHandler;
import com.fasterxml.jackson.databind.ObjectMapper;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.security.web.AuthenticationEntryPoint;
import org.springframework.security.web.access.AccessDeniedHandler;

import java.io.IOException;

/** 401 / 403 raised by the filter chain get the same ProblemDetail body as controller errors. */
public class ProblemResponseWriter {

    private final ObjectMapper mapper;

    public ProblemResponseWriter(ObjectMapper mapper) {
        this.mapper = mapper;
    }

    public void write(HttpServletResponse response, HttpStatus status, String code, String detail) throws IOException {
        response.setStatus(status.value());
        response.setContentType(MediaType.APPLICATION_PROBLEM_JSON_VALUE);
        mapper.writeValue(response.getOutputStream(), APIExceptionHandler.problem(status, code, detail));
    }

    public AuthenticationEntryPoint entryPoint() {
        return (req, res, ex) -> write(res, HttpStatus.UNAUTHORIZED, "UNAUTHORIZED", "Login required");
    }

    public AccessDeniedHandler accessDeniedHandler() {
        return (req, res, ex) -> write(res, HttpStatus.FORBIDDEN, "ACCESS_DENIED", "You do not have permission for this action");
    }
}
