package com.ags.health.hr.admin.entities;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.Immutable;

/**
 * Catalogue entry OBJECT:ACTION. Read-only: seeded by db/data-admin.sql together with the code that checks it.
 * A permission nobody's code checks does nothing, so there is deliberately no "create permission" API.
 */
@Entity
@Immutable
@Table(name = "adm_permission")
@Getter
@NoArgsConstructor
public class Permission {

    @Id
    private String code;

    @Column(name = "object_type", nullable = false)
    private String objectType;

    @Column(nullable = false)
    private String action;

    @Column(nullable = false)
    private String module;

    private String description;

    /** Only reachable through the SUPER_ADMIN role; never through a user-level grant or another role. */
    @Column(nullable = false)
    private boolean privileged;

    @Column(name = "sort_order", nullable = false)
    private int sortOrder;

    public Permission(String code, String module, boolean privileged) {
        this.code = code;
        this.objectType = code.substring(0, code.indexOf(':'));
        this.action = code.substring(code.indexOf(':') + 1);
        this.module = module;
        this.privileged = privileged;
    }
}
