package com.ags.health.hr.admin.resources;

import com.ags.health.hr.admin.entities.Permission;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Collection;
import java.util.List;

public interface PermissionRepository extends JpaRepository<Permission, String> {

    List<Permission> findAllByOrderBySortOrderAsc();

    List<Permission> findByCodeIn(Collection<String> codes);
}
