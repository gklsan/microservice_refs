import { Directive, Input, OnChanges, OnDestroy, OnInit, TemplateRef, ViewContainerRef } from '@angular/core';
import { Subscription } from 'rxjs';
import { RbacService } from '../services/rbac.service';

/**
 * Shows the element only when the user has the permission (and the role, if given).
 *   <button *appHasPermission="'USER:MANAGE'; role: 'SUPER_ADMIN'">Add user</button>
 *   <a *appHasPermission="['USER:VIEW', 'ROLE:VIEW']">Admin</a>   (any of the list)
 */
@Directive({ selector: '[appHasPermission]' })
export class HasPermissionDirective implements OnInit, OnChanges, OnDestroy {
  @Input('appHasPermission') permission: string | string[] = [];
  @Input('appHasPermissionRole') role?: string;

  private shown = false;
  private sub?: Subscription;

  constructor(private tpl: TemplateRef<unknown>, private vcr: ViewContainerRef, private rbac: RbacService) {}

  ngOnInit(): void {
    this.sub = this.rbac.me$.subscribe(() => this.render());
    void this.rbac.ensureLoaded();
  }

  ngOnChanges(): void {
    if (this.sub) {
      this.render();
    }
  }

  ngOnDestroy(): void {
    this.sub?.unsubscribe();
  }

  private render(): void {
    const list = Array.isArray(this.permission) ? this.permission : [this.permission];
    const ok = (list.length === 0 || list.some((p) => this.rbac.has(p))) && (!this.role || this.rbac.hasRole(this.role));
    if (ok && !this.shown) {
      this.vcr.createEmbeddedView(this.tpl);
      this.shown = true;
    } else if (!ok && this.shown) {
      this.vcr.clear();
      this.shown = false;
    }
  }
}
