// Contracts of admin-services (/admin-services). Keep in sync with static/openapi.yaml.

export type UserStatus = 'ACTIVE' | 'INACTIVE';
export type ScopeLevel = 'NONE' | 'OWN' | 'TEAM' | 'LOB' | 'LOCATION' | 'ALL';
export type UserType = 'EMPLOYEE_HR' | 'EMPLOYEE_HR_ADMIN' | 'EMPLOYEE_NON_HR';
export type PermissionEffect = 'ALLOW' | 'DENY';
export type CellValue = 'A' | 'C';

export interface DataScope {
  level: ScopeLevel;
  userId?: string;
  teamUserIds: string[];
  lobs: string[];
  locations: string[];
  sharedObjects?: Record<string, string[]>;
}

export interface Me {
  userId?: string;
  email?: string;
  name?: string;
  userType?: string;
  active: boolean;
  configured: boolean;
  roles: string[];
  permissions: string[];
  conditionalPermissions: string[];
  scope: DataScope;
}

export interface PageResponse<T> {
  content: T[];
  page: number;
  size: number;
  totalElements: number;
  totalPages: number;
}

export interface AdminUserSummary {
  id: string;
  email: string;
  fullName: string;
  employeeCode?: string;
  status: UserStatus;
  roles: string[];
  grantCount: number;
  loginLinked: boolean;
  updatedDate?: string;
}

export interface RoleRef {
  code: string;
  name: string;
  active: boolean;
}

export interface GrantView {
  permission: string;
  effect: PermissionEffect;
  conditional: boolean;
  expiresAt?: string;
  expired: boolean;
  reason?: string;
  grantedBy?: string;
  grantedDate?: string;
}

export interface AdminUser {
  id: string;
  smartieUserId?: string;
  email: string;
  fullName: string;
  employeeCode?: string;
  userType: string;
  status: UserStatus;
  roles: RoleRef[];
  scopeLevel?: ScopeLevel;
  effectiveScopeLevel: ScopeLevel;
  lobs: string[];
  locations: string[];
  managerId?: string;
  managerName?: string;
  permissionGrants: GrantView[];
  loginLinked: boolean;
  statusChangedDate?: string;
  statusChangedBy?: string;
  statusReason?: string;
  createdDate?: string;
  createdBy?: string;
  updatedDate?: string;
  updatedBy?: string;
  version?: number;
}

export interface CreateAdminUserRequest {
  email: string;
  fullName: string;
  employeeCode?: string;
  userType: UserType;
  roles: string[];
  managerId?: string | null;
  scopeLevel?: ScopeLevel | null;
  lobs?: string[];
  locations?: string[];
}

export interface UpdateAdminUserRequest {
  fullName: string;
  employeeCode?: string;
  managerId?: string | null;
  scopeLevel?: ScopeLevel | null;
  lobs?: string[];
  locations?: string[];
  version?: number;
}

export interface GrantItem {
  permission: string;
  effect: PermissionEffect;
  conditional: boolean;
  expiresAt?: string | null;
  reason?: string | null;
}

export interface EffectiveAccess {
  userId?: string;
  adminUserId?: string;
  email?: string;
  active: boolean;
  configured: boolean;
  roles: string[];
  permissions: string[];
  conditionalPermissions: string[];
  scope: DataScope;
}

export interface EffectiveAccessLine {
  permission: string;
  module?: string;
  state: 'GRANTED' | 'CONDITIONAL' | 'DENIED';
  sources: string[];
}

export interface EffectiveAccessDetail {
  access: EffectiveAccess;
  lines: EffectiveAccessLine[];
}

export interface PermissionItem {
  code: string;
  conditional: boolean;
}

export interface RoleView {
  id: string;
  code: string;
  legacyCode?: string;
  name: string;
  description?: string;
  defaultScope: ScopeLevel;
  systemRole: boolean;
  active: boolean;
  activeUserCount: number;
  permissions: PermissionItem[];
  version?: number;
}

export interface PermissionView {
  code: string;
  objectType: string;
  action: string;
  module: string;
  description?: string;
  privileged: boolean;
}

export interface Matrix {
  roles: RoleView[];
  permissions: PermissionView[];
  grants: Record<string, Record<string, CellValue>>;
}

export interface CreateRoleRequest {
  code: string;
  name: string;
  description?: string;
  defaultScope: ScopeLevel;
  permissions: PermissionItem[];
}

export interface UpdateRoleRequest {
  name: string;
  description?: string;
  defaultScope: ScopeLevel;
  active: boolean;
  permissions?: PermissionItem[];
  version?: number;
}

/** RFC 7807 body every admin-services error returns. Branch on `code`. */
export interface ApiProblem {
  status: number;
  title?: string;
  detail?: string;
  code?: string;
  correlationId?: string;
  errors?: { field: string; message: string }[];
}

export const PERMISSIONS = {
  USER_VIEW: 'USER:VIEW',
  USER_MANAGE: 'USER:MANAGE',
  ROLE_VIEW: 'ROLE:VIEW',
  ROLE_MANAGE: 'ROLE:MANAGE',
  CONFIG_VIEW: 'CONFIG:VIEW',
  CONFIG_MANAGE: 'CONFIG:MANAGE',
} as const;

export const SUPER_ADMIN = 'SUPER_ADMIN';

/** Mirrors admin-services RoleCodes: SUPER_ADMIN must keep these, other roles can never hold privileged ones. */
export const SUPER_ADMIN_LOCKED = ['USER:VIEW', 'USER:MANAGE', 'ROLE:VIEW', 'ROLE:MANAGE', 'CONFIG:VIEW', 'CONFIG:MANAGE'];

/** Given by registration / vendor onboarding, never from the admin user screen. */
export const NOT_ASSIGNABLE_ROLES = ['CANDIDATE', 'VENDOR'];

export const SCOPE_LABELS: Record<ScopeLevel, string> = {
  NONE: 'No records',
  OWN: 'Own / assigned records',
  TEAM: 'Own + my team (TL)',
  LOB: 'Selected LOBs (Manager)',
  LOCATION: 'Selected locations',
  ALL: 'Everything (TA Head / Admin)',
};
