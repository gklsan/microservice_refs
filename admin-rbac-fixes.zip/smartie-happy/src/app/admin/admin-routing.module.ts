import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { PERMISSIONS } from './models/admin.models';
import { permissionGuard } from './guards/permission.guard';
import { PermissionMatrixComponent } from './components/permission-matrix/permission-matrix.component';
import { UserDetailComponent } from './components/user-detail/user-detail.component';
import { UserListComponent } from './components/user-list/user-list.component';

// Mounted under the HR portal: /h/admin/users, /h/admin/users/:id, /h/admin/roles
const routes: Routes = [
  { path: '', redirectTo: 'users', pathMatch: 'full' },
  { path: 'users', component: UserListComponent, canActivate: [permissionGuard], data: { permission: PERMISSIONS.USER_VIEW } },
  { path: 'users/:id', component: UserDetailComponent, canActivate: [permissionGuard], data: { permission: PERMISSIONS.USER_VIEW } },
  { path: 'roles', component: PermissionMatrixComponent, canActivate: [permissionGuard], data: { permission: PERMISSIONS.ROLE_VIEW } },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class AdminRoutingModule {}
