import { NgModule } from '@angular/core';
import { HasPermissionDirective } from './directives/has-permission.directive';

/**
 * Import this in any module (e.g. the side-nav module) that needs *appHasPermission, so menus can be
 * gated by admin-services permissions instead of localStorage role.
 */
@NgModule({
  declarations: [HasPermissionDirective],
  exports: [HasPermissionDirective],
})
export class SharedAdminModule {}
