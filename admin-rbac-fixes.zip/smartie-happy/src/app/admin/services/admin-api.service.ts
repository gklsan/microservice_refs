import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { firstValueFrom } from 'rxjs';
import { environment } from '../../../environments/environment';
import {
  AdminUser,
  AdminUserSummary,
  CreateAdminUserRequest,
  CreateRoleRequest,
  EffectiveAccessDetail,
  GrantItem,
  GrantView,
  Matrix,
  PageResponse,
  PermissionItem,
  PermissionView,
  RoleView,
  UpdateAdminUserRequest,
  UpdateRoleRequest,
  UserStatus,
} from '../models/admin.models';

export interface UserSearch {
  search?: string;
  status?: UserStatus | '';
  role?: string;
  page: number;
  size: number;
  sort?: 'fullName' | 'email' | 'status' | 'updatedDate';
  direction?: 'ASC' | 'DESC';
}

/** admin-services client. Promise based, like the other smartie-happy services. */
@Injectable({ providedIn: 'root' })
export class AdminApiService {
  private readonly base = `${environment.API_URL}admin-services`;

  constructor(private http: HttpClient) {}

  // ------------------------------------------------------------ users
  searchUsers(q: UserSearch): Promise<PageResponse<AdminUserSummary>> {
    let params = new HttpParams().set('page', q.page).set('size', q.size);
    if (q.search?.trim()) params = params.set('search', q.search.trim());
    if (q.status) params = params.set('status', q.status);
    if (q.role) params = params.set('role', q.role);
    if (q.sort) params = params.set('sort', q.sort).set('direction', q.direction ?? 'ASC');
    return firstValueFrom(this.http.get<PageResponse<AdminUserSummary>>(`${this.base}/admin/users`, { params }));
  }

  getUser(id: string): Promise<AdminUser> {
    return firstValueFrom(this.http.get<AdminUser>(`${this.base}/admin/users/${id}`));
  }

  createUser(body: CreateAdminUserRequest): Promise<AdminUser> {
    return firstValueFrom(this.http.post<AdminUser>(`${this.base}/admin/users`, body));
  }

  updateUser(id: string, body: UpdateAdminUserRequest): Promise<AdminUser> {
    return firstValueFrom(this.http.put<AdminUser>(`${this.base}/admin/users/${id}`, body));
  }

  deactivate(id: string, reason: string): Promise<AdminUser> {
    return firstValueFrom(this.http.patch<AdminUser>(`${this.base}/admin/users/${id}/deactivate`, { reason }));
  }

  reactivate(id: string, reason?: string): Promise<AdminUser> {
    return firstValueFrom(this.http.patch<AdminUser>(`${this.base}/admin/users/${id}/reactivate`, { reason }));
  }

  assignRoles(id: string, roles: string[]): Promise<AdminUser> {
    return firstValueFrom(this.http.put<AdminUser>(`${this.base}/admin/users/${id}/roles`, { roles }));
  }

  getGrants(id: string): Promise<GrantView[]> {
    return firstValueFrom(this.http.get<GrantView[]>(`${this.base}/admin/users/${id}/permissions`));
  }

  setGrants(id: string, grants: GrantItem[]): Promise<AdminUser> {
    return firstValueFrom(this.http.put<AdminUser>(`${this.base}/admin/users/${id}/permissions`, { grants }));
  }

  effectiveAccess(id: string): Promise<EffectiveAccessDetail> {
    return firstValueFrom(this.http.get<EffectiveAccessDetail>(`${this.base}/admin/users/${id}/effective-access`));
  }

  // ------------------------------------------------------------ roles and matrix
  roles(includeInactive = true): Promise<RoleView[]> {
    const params = new HttpParams().set('includeInactive', includeInactive);
    return firstValueFrom(this.http.get<RoleView[]>(`${this.base}/admin/roles`, { params }));
  }

  permissions(): Promise<PermissionView[]> {
    return firstValueFrom(this.http.get<PermissionView[]>(`${this.base}/admin/permissions`));
  }

  matrix(): Promise<Matrix> {
    return firstValueFrom(this.http.get<Matrix>(`${this.base}/admin/permission-matrix`));
  }

  saveMatrix(grants: Record<string, PermissionItem[]>): Promise<Matrix> {
    return firstValueFrom(this.http.put<Matrix>(`${this.base}/admin/permission-matrix`, { grants }));
  }

  createRole(body: CreateRoleRequest): Promise<RoleView> {
    return firstValueFrom(this.http.post<RoleView>(`${this.base}/admin/roles`, body));
  }

  updateRole(code: string, body: UpdateRoleRequest): Promise<RoleView> {
    return firstValueFrom(this.http.put<RoleView>(`${this.base}/admin/roles/${code}`, body));
  }

  resetRole(code: string): Promise<RoleView> {
    return firstValueFrom(this.http.post<RoleView>(`${this.base}/admin/roles/${code}/reset-defaults`, {}));
  }
}
