import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatAutocompleteModule } from '@angular/material/autocomplete';
import { MatButtonModule } from '@angular/material/button';
import { MatButtonToggleModule } from '@angular/material/button-toggle';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatChipsModule } from '@angular/material/chips';
import { MatNativeDateModule } from '@angular/material/core';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatDialogModule } from '@angular/material/dialog';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatMenuModule } from '@angular/material/menu';
import { MatPaginatorModule } from '@angular/material/paginator';
import { MatProgressBarModule } from '@angular/material/progress-bar';
import { MatSelectModule } from '@angular/material/select';
import { MatSlideToggleModule } from '@angular/material/slide-toggle';
import { MatSnackBarModule } from '@angular/material/snack-bar';
import { MatSortModule } from '@angular/material/sort';
import { MatTableModule } from '@angular/material/table';
import { MatTabsModule } from '@angular/material/tabs';
import { MatTooltipModule } from '@angular/material/tooltip';
import { AdminRoutingModule } from './admin-routing.module';
import { PermissionMatrixComponent } from './components/permission-matrix/permission-matrix.component';
import { RoleFormDialogComponent } from './components/role-form-dialog/role-form-dialog.component';
import { StatusDialogComponent } from './components/status-dialog/status-dialog.component';
import { UserDetailComponent } from './components/user-detail/user-detail.component';
import { UserFormDialogComponent } from './components/user-form-dialog/user-form-dialog.component';
import { UserListComponent } from './components/user-list/user-list.component';
import { UserRolesDialogComponent } from './components/user-roles-dialog/user-roles-dialog.component';
import { SharedAdminModule } from './shared-admin.module';

/** Lazy-loaded admin feature: admin users (tracker #22-24) and the permission matrix (#25). */
@NgModule({
  declarations: [
    UserListComponent,
    UserFormDialogComponent,
    UserRolesDialogComponent,
    StatusDialogComponent,
    UserDetailComponent,
    PermissionMatrixComponent,
    RoleFormDialogComponent,
  ],
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    AdminRoutingModule,
    SharedAdminModule,
    MatAutocompleteModule,
    MatButtonModule,
    MatButtonToggleModule,
    MatCheckboxModule,
    MatChipsModule,
    MatDatepickerModule,
    MatNativeDateModule,
    MatDialogModule,
    MatFormFieldModule,
    MatInputModule,
    MatMenuModule,
    MatPaginatorModule,
    MatProgressBarModule,
    MatSelectModule,
    MatSlideToggleModule,
    MatSnackBarModule,
    MatSortModule,
    MatTableModule,
    MatTabsModule,
    MatTooltipModule,
  ],
})
export class AdminModule {}
