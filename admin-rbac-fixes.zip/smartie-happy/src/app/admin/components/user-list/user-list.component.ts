import { AfterViewInit, Component, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { MatPaginator, PageEvent } from '@angular/material/paginator';
import { MatSnackBar } from '@angular/material/snack-bar';
import { MatSort, Sort } from '@angular/material/sort';
import { Router } from '@angular/router';
import { Subscription, debounceTime, distinctUntilChanged } from 'rxjs';
import { AdminUserSummary, PERMISSIONS, RoleView, UserStatus } from '../../models/admin.models';
import { AdminApiService, UserSearch } from '../../services/admin-api.service';
import { RbacService } from '../../services/rbac.service';
import { errorMessage } from '../../utils/api-error.util';
import { StatusDialogComponent, StatusDialogData } from '../status-dialog/status-dialog.component';
import { UserFormDialogComponent, UserFormDialogData } from '../user-form-dialog/user-form-dialog.component';
import { UserRolesDialogComponent, UserRolesDialogData } from '../user-roles-dialog/user-roles-dialog.component';

/** Tracker #23: admin user list - search, deactivate, reactivate. */
@Component({
  selector: 'app-admin-user-list',
  templateUrl: './user-list.component.html',
  styleUrls: ['./user-list.component.scss'],
})
export class UserListComponent implements OnInit, AfterViewInit, OnDestroy {
  readonly columns = ['fullName', 'employeeCode', 'roles', 'status', 'updatedDate', 'actions'];

  readonly filters = new FormGroup({
    search: new FormControl<string>('', { nonNullable: true }),
    status: new FormControl<UserStatus | ''>('ACTIVE', { nonNullable: true }),
    role: new FormControl<string>('', { nonNullable: true }),
  });

  rows: AdminUserSummary[] = [];
  roles: RoleView[] = [];
  total = 0;
  loading = false;
  error = '';
  query: UserSearch = { page: 0, size: 20, sort: 'fullName', direction: 'ASC', status: 'ACTIVE' };

  @ViewChild(MatPaginator) paginator?: MatPaginator;
  @ViewChild(MatSort) sort?: MatSort;

  private subs: Subscription[] = [];
  private loadSeq = 0;

  constructor(
    private api: AdminApiService,
    public rbac: RbacService,
    private dialog: MatDialog,
    private snack: MatSnackBar,
    private router: Router
  ) {}

  get canManage(): boolean {
    return this.rbac.canManage(PERMISSIONS.USER_MANAGE);
  }

  ngOnInit(): void {
    void this.rbac.ensureLoaded();
    this.subs.push(
      this.filters.controls.search.valueChanges.pipe(debounceTime(300), distinctUntilChanged()).subscribe(() => this.applyFilters()),
      this.filters.controls.status.valueChanges.subscribe(() => this.applyFilters()),
      this.filters.controls.role.valueChanges.subscribe(() => this.applyFilters())
    );
    this.api.roles(false).then((r) => (this.roles = r)).catch(() => (this.roles = []));
    void this.load();
  }

  ngAfterViewInit(): void {
    if (this.sort) {
      this.subs.push(this.sort.sortChange.subscribe((s: Sort) => this.onSort(s)));
    }
  }

  ngOnDestroy(): void {
    this.subs.forEach((s) => s.unsubscribe());
  }

  applyFilters(): void {
    const f = this.filters.getRawValue();
    this.query = { ...this.query, search: f.search, status: f.status, role: f.role, page: 0 };
    if (this.paginator) this.paginator.pageIndex = 0;
    void this.load();
  }

  onPage(e: PageEvent): void {
    this.query = { ...this.query, page: e.pageIndex, size: e.pageSize };
    void this.load();
  }

  onSort(s: Sort): void {
    const map: Record<string, UserSearch['sort']> = {
      fullName: 'fullName',
      status: 'status',
      updatedDate: 'updatedDate',
    };
    this.query = {
      ...this.query,
      sort: map[s.active] ?? 'fullName',
      direction: s.direction === 'desc' ? 'DESC' : 'ASC',
      page: 0,
    };
    if (this.paginator) this.paginator.pageIndex = 0;
    void this.load();
  }

  async load(): Promise<void> {
    const seq = ++this.loadSeq;
    this.loading = true;
    this.error = '';
    try {
      const page = await this.api.searchUsers(this.query);
      if (seq !== this.loadSeq) return;
      this.rows = page.content;
      this.total = page.totalElements;
    } catch (e) {
      if (seq !== this.loadSeq) return;
      this.error = errorMessage(e);
      this.rows = [];
      this.total = 0;
    } finally {
      if (seq === this.loadSeq) this.loading = false;
    }
  }

  open(row: AdminUserSummary): void {
    void this.router.navigate(['/h/admin/users', row.id]);
  }

  create(): void {
    const data: UserFormDialogData = { mode: 'create' };
    this.dialog
      .open(UserFormDialogComponent, { width: '720px', maxWidth: '95vw', data, disableClose: true })
      .afterClosed()
      .subscribe((saved) => {
        if (saved) {
          this.snack.open('User created. They get access the next time they sign in.', 'Close', { duration: 4000 });
          void this.load();
        }
      });
  }

  async edit(row: AdminUserSummary): Promise<void> {
    try {
      const user = await this.api.getUser(row.id);
      const data: UserFormDialogData = { mode: 'edit', user };
      this.dialog
        .open(UserFormDialogComponent, { width: '720px', maxWidth: '95vw', data, disableClose: true })
        .afterClosed()
        .subscribe((saved) => saved && this.afterChange('User updated.'));
    } catch (e) {
      this.snack.open(errorMessage(e), 'Close', { duration: 5000 });
    }
  }

  editRoles(row: AdminUserSummary): void {
    const data: UserRolesDialogData = { userId: row.id, userName: row.fullName, current: row.roles };
    this.dialog
      .open(UserRolesDialogComponent, { width: '560px', maxWidth: '95vw', data, disableClose: true })
      .afterClosed()
      .subscribe((saved) => saved && this.afterChange('Roles updated.'));
  }

  changeStatus(row: AdminUserSummary): void {
    const data: StatusDialogData = {
      userId: row.id,
      userName: row.fullName,
      action: row.status === 'ACTIVE' ? 'deactivate' : 'reactivate',
    };
    this.dialog
      .open(StatusDialogComponent, { width: '480px', maxWidth: '95vw', data, disableClose: true })
      .afterClosed()
      .subscribe((saved) =>
        saved && this.afterChange(data.action === 'deactivate' ? 'User deactivated.' : 'User reactivated.')
      );
  }

  private afterChange(message: string): void {
    this.snack.open(`${message} Other modules pick it up within 2 minutes.`, 'Close', { duration: 4000 });
    void this.load();
  }
}
