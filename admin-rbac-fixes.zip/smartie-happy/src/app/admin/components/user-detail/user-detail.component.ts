import { Component, OnInit } from '@angular/core';
import { FormArray, FormControl, FormGroup, Validators } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { MatSnackBar } from '@angular/material/snack-bar';
import { ActivatedRoute, Router } from '@angular/router';
import {
  AdminUser,
  EffectiveAccessDetail,
  GrantItem,
  PERMISSIONS,
  PermissionEffect,
  PermissionView,
  SCOPE_LABELS,
} from '../../models/admin.models';
import { AdminApiService } from '../../services/admin-api.service';
import { RbacService } from '../../services/rbac.service';
import { errorMessage } from '../../utils/api-error.util';
import { StatusDialogComponent, StatusDialogData } from '../status-dialog/status-dialog.component';
import { UserFormDialogComponent, UserFormDialogData } from '../user-form-dialog/user-form-dialog.component';
import { UserRolesDialogComponent, UserRolesDialogData } from '../user-roles-dialog/user-roles-dialog.component';

type GrantRow = FormGroup<{
  permission: FormControl<string>;
  effect: FormControl<PermissionEffect>;
  conditional: FormControl<boolean>;
  expiresAt: FormControl<Date | null>;
  reason: FormControl<string>;
}>;

interface PermissionGroup {
  module: string;
  permissions: PermissionView[];
}

/** User detail: profile, roles, tracker #24 granular permissions and the effective result with sources. */
@Component({
  selector: 'app-admin-user-detail',
  templateUrl: './user-detail.component.html',
  styleUrls: ['./user-detail.component.scss'],
})
export class UserDetailComponent implements OnInit {
  readonly scopeLabels = SCOPE_LABELS;
  readonly today = new Date();

  user?: AdminUser;
  effective?: EffectiveAccessDetail;
  groups: PermissionGroup[] = [];
  grants = new FormArray<GrantRow>([]);
  private originalExpiry = new WeakMap<GrantRow, string>();
  effectiveFilter = new FormControl('', { nonNullable: true });
  loading = true;
  saving = false;
  error = '';
  grantError = '';

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private api: AdminApiService,
    public rbac: RbacService,
    private dialog: MatDialog,
    private snack: MatSnackBar
  ) {}

  get canManage(): boolean {
    return !!this.user && this.rbac.canManage(PERMISSIONS.USER_MANAGE) && !this.rbac.isSelf(this.user.email);
  }

  get isSelf(): boolean {
    return !!this.user && this.rbac.isSelf(this.user.email);
  }

  get filteredLines() {
    const q = this.effectiveFilter.value.trim().toLowerCase();
    const lines = this.effective?.lines ?? [];
    return q ? lines.filter((l) => l.permission.toLowerCase().includes(q) || (l.module ?? '').toLowerCase().includes(q)) : lines;
  }

  async ngOnInit(): Promise<void> {
    await this.rbac.ensureLoaded();
    try {
      const catalogue = await this.api.permissions();
      const byModule = new Map<string, PermissionView[]>();
      catalogue
        .filter((p) => !p.privileged) // privileged ones only come from the SUPER_ADMIN role
        .forEach((p) => byModule.set(p.module, [...(byModule.get(p.module) ?? []), p]));
      this.groups = [...byModule.entries()].map(([module, permissions]) => ({ module, permissions }));
    } catch {
      this.groups = [];
    }
    await this.reload();
  }

  async reload(): Promise<void> {
    const id = this.route.snapshot.paramMap.get('id')!;
    this.loading = true;
    this.error = '';
    try {
      const [user, effective] = await Promise.all([this.api.getUser(id), this.api.effectiveAccess(id)]);
      this.user = user;
      this.effective = effective;
      this.resetGrants();
    } catch (e) {
      this.error = errorMessage(e);
    } finally {
      this.loading = false;
    }
  }

  // ------------------------------------------------------------ grant editor
  resetGrants(): void {
    this.grants.clear();
    (this.user?.permissionGrants ?? []).forEach((g) => {
      const row = this.row(g.permission, g.effect, g.conditional, g.expiresAt ? new Date(g.expiresAt) : null, g.reason ?? '');
      if (g.expiresAt) this.originalExpiry.set(row, g.expiresAt);
      this.grants.push(row);
    });
    this.grants.markAsPristine();
    if (!this.canManage) this.grants.disable();
  }

  addGrant(): void {
    this.grants.push(this.row('', 'ALLOW', false, null, ''));
    this.grants.markAsDirty();
  }

  removeGrant(i: number): void {
    this.grants.removeAt(i);
    this.grants.markAsDirty();
  }

  private row(permission: string, effect: PermissionEffect, conditional: boolean, expiresAt: Date | null, reason: string): GrantRow {
    const g: GrantRow = new FormGroup({
      permission: new FormControl(permission, { nonNullable: true, validators: [Validators.required] }),
      effect: new FormControl<PermissionEffect>(effect, { nonNullable: true }),
      conditional: new FormControl(conditional, { nonNullable: true }),
      expiresAt: new FormControl<Date | null>(expiresAt),
      reason: new FormControl(reason, { nonNullable: true, validators: [Validators.maxLength(500)] }),
    });
    g.controls.effect.valueChanges.subscribe((e) => {
      if (e === 'DENY') g.controls.conditional.setValue(false);
      e === 'DENY' ? g.controls.conditional.disable() : g.controls.conditional.enable();
    });
    if (effect === 'DENY') g.controls.conditional.disable();
    return g;
  }

  async saveGrants(): Promise<void> {
    this.grantError = '';
    if (!this.user) return;
    if (this.grants.invalid) {
      this.grants.markAllAsTouched();
      this.grantError = 'Pick a permission on every row, or remove the empty row.';
      return;
    }
    const items: GrantItem[] = this.grants.controls.map((row) => {
      const g = row.getRawValue();
      return {
        permission: g.permission,
        effect: g.effect,
        conditional: g.effect === 'ALLOW' && g.conditional,
        expiresAt: this.expiryOf(row, g.expiresAt),
        reason: g.reason.trim() || null,
      };
    });
    const codes = items.map((i) => i.permission);
    const dup = codes.find((c, i) => codes.indexOf(c) !== i);
    if (dup) {
      this.grantError = `${dup} is listed twice. Keep one ALLOW or one DENY.`;
      return;
    }
    this.saving = true;
    try {
      await this.api.setGrants(this.user.id, items);
      this.snack.open('Permissions saved. Other modules pick it up within 2 minutes.', 'Close', { duration: 4000 });
      await this.reload();
    } catch (e) {
      this.grantError = errorMessage(e);
    } finally {
      this.saving = false;
    }
  }

  isExpired(row: GrantRow): boolean {
    const original = this.originalExpiry.get(row);
    const picked = row.controls.expiresAt.value;
    return !!original && !!picked && sameDay(new Date(original), picked) && new Date(original).getTime() <= Date.now();
  }

  private expiryOf(row: GrantRow, picked: Date | null): string | null {
    if (!picked) return null;
    const original = this.originalExpiry.get(row);
    if (original && sameDay(new Date(original), picked)) return original;
    return endOfDay(picked).toISOString();
  }

  // ------------------------------------------------------------ header actions
  edit(): void {
    const data: UserFormDialogData = { mode: 'edit', user: this.user };
    this.dialog
      .open(UserFormDialogComponent, { width: '720px', maxWidth: '95vw', data, disableClose: true })
      .afterClosed()
      .subscribe((saved) => saved && this.reload());
  }

  editRoles(): void {
    if (!this.user) return;
    const data: UserRolesDialogData = { userId: this.user.id, userName: this.user.fullName, current: this.user.roles.map((r) => r.code) };
    this.dialog
      .open(UserRolesDialogComponent, { width: '560px', maxWidth: '95vw', data, disableClose: true })
      .afterClosed()
      .subscribe((saved) => saved && this.reload());
  }

  changeStatus(): void {
    if (!this.user) return;
    const data: StatusDialogData = {
      userId: this.user.id,
      userName: this.user.fullName,
      action: this.user.status === 'ACTIVE' ? 'deactivate' : 'reactivate',
    };
    this.dialog
      .open(StatusDialogComponent, { width: '480px', maxWidth: '95vw', data, disableClose: true })
      .afterClosed()
      .subscribe((saved) => saved && this.reload());
  }

  back(): void {
    void this.router.navigate(['/h/admin/users']);
  }
}

function sameDay(a: Date, b: Date): boolean {
  return a.getFullYear() === b.getFullYear() && a.getMonth() === b.getMonth() && a.getDate() === b.getDate();
}

function endOfDay(d: Date): Date {
  const x = new Date(d);
  x.setHours(23, 59, 59, 0);
  return x;
}
