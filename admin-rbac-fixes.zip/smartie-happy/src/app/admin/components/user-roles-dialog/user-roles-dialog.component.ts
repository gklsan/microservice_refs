import { Component, Inject, OnInit } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { AdminUser, NOT_ASSIGNABLE_ROLES, RoleView } from '../../models/admin.models';
import { AdminApiService } from '../../services/admin-api.service';
import { errorMessage } from '../../utils/api-error.util';

export interface UserRolesDialogData {
  userId: string;
  userName: string;
  current: string[];
}

/** Full replace of a user's roles (PUT /admin/users/{id}/roles). */
@Component({
  selector: 'app-admin-user-roles-dialog',
  templateUrl: './user-roles-dialog.component.html',
  styleUrls: ['./user-roles-dialog.component.scss'],
})
export class UserRolesDialogComponent implements OnInit {
  roles: RoleView[] = [];
  selected = new Set<string>();
  saving = false;
  error = '';

  constructor(
    @Inject(MAT_DIALOG_DATA) public data: UserRolesDialogData,
    private ref: MatDialogRef<UserRolesDialogComponent, AdminUser | undefined>,
    private api: AdminApiService
  ) {}

  ngOnInit(): void {
    this.selected = new Set(this.data.current);
    this.api
      .roles(true)
      .then((r) => (this.roles = r))
      .catch((e) => (this.error = errorMessage(e)));
  }

  assignable(r: RoleView): boolean {
    // retired roles stay visible (and removable) if the user still has them, but can not be added
    return !NOT_ASSIGNABLE_ROLES.includes(r.code) && (r.active || this.data.current.includes(r.code));
  }

  toggle(code: string, on: boolean): void {
    on ? this.selected.add(code) : this.selected.delete(code);
  }

  async save(): Promise<void> {
    if (this.selected.size === 0) {
      this.error = 'Keep at least one role. To remove all access, deactivate the user instead.';
      return;
    }
    this.saving = true;
    this.error = '';
    try {
      this.ref.close(await this.api.assignRoles(this.data.userId, [...this.selected]));
    } catch (e) {
      this.error = errorMessage(e);
    } finally {
      this.saving = false;
    }
  }

  cancel(): void {
    this.ref.close(undefined);
  }
}
