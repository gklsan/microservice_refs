import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { MatSnackBar } from '@angular/material/snack-bar';
import {
  CellValue,
  Matrix,
  PERMISSIONS,
  PermissionItem,
  PermissionView,
  RoleView,
  SUPER_ADMIN,
  SUPER_ADMIN_LOCKED,
} from '../../models/admin.models';
import { AdminApiService } from '../../services/admin-api.service';
import { RbacService } from '../../services/rbac.service';
import { errorMessage } from '../../utils/api-error.util';
import { RoleFormDialogComponent, RoleFormDialogData } from '../role-form-dialog/role-form-dialog.component';

interface ModuleRows {
  module: string;
  permissions: PermissionView[];
}

/**
 * Tracker #25 role-to-permission mapping matrix (+ #1-3 default sets via "Reset to defaults").
 * Click a cell: empty -> A (allow) -> C (own records only) -> empty. Only changed roles are sent.
 */
@Component({
  selector: 'app-admin-permission-matrix',
  templateUrl: './permission-matrix.component.html',
  styleUrls: ['./permission-matrix.component.scss'],
})
export class PermissionMatrixComponent implements OnInit {
  matrix?: Matrix;
  modules: ModuleRows[] = [];
  cells: Record<string, Record<string, CellValue>> = {};
  dirty = new Set<string>();
  showInactive = false;
  loading = true;
  saving = false;
  error = '';

  constructor(
    private api: AdminApiService,
    public rbac: RbacService,
    private dialog: MatDialog,
    private snack: MatSnackBar
  ) {}

  get canEdit(): boolean {
    return this.rbac.canManage(PERMISSIONS.ROLE_MANAGE);
  }

  get visibleRoles(): RoleView[] {
    return (this.matrix?.roles ?? []).filter((r) => this.showInactive || r.active);
  }

  async ngOnInit(): Promise<void> {
    await this.rbac.ensureLoaded();
    await this.load();
  }

  async load(): Promise<void> {
    this.loading = true;
    this.error = '';
    try {
      this.apply(await this.api.matrix());
    } catch (e) {
      this.error = errorMessage(e);
    } finally {
      this.loading = false;
    }
  }

  private apply(m: Matrix): void {
    this.matrix = m;
    this.cells = {};
    m.roles.forEach((r) => (this.cells[r.code] = { ...(m.grants[r.code] ?? {}) }));
    const byModule = new Map<string, PermissionView[]>();
    m.permissions.forEach((p) => byModule.set(p.module, [...(byModule.get(p.module) ?? []), p]));
    this.modules = [...byModule.entries()].map(([module, permissions]) => ({ module, permissions }));
    this.dirty.clear();
  }

  value(role: string, perm: string): CellValue | '' {
    return this.cells[role]?.[perm] ?? '';
  }

  /** Mirrors the server rules so the admin sees them before saving. */
  locked(role: RoleView, p: PermissionView): string | null {
    if (role.code === SUPER_ADMIN && SUPER_ADMIN_LOCKED.includes(p.code)) {
      return 'Super Admin must keep this permission';
    }
    if (role.code !== SUPER_ADMIN && p.privileged) {
      return 'Only the Super Admin role can hold this';
    }
    return null;
  }

  cycle(role: RoleView, p: PermissionView): void {
    if (!this.canEdit || this.locked(role, p)) return;
    const current = this.value(role.code, p.code);
    const next: CellValue | '' = current === '' ? 'A' : current === 'A' ? 'C' : '';
    if (next) {
      this.cells[role.code][p.code] = next;
    } else {
      delete this.cells[role.code][p.code];
    }
    this.dirty.add(role.code);
  }

  async save(): Promise<void> {
    const grants: Record<string, PermissionItem[]> = {};
    this.dirty.forEach((role) => {
      grants[role] = Object.entries(this.cells[role]).map(([code, v]) => ({ code, conditional: v === 'C' }));
    });
    this.saving = true;
    this.error = '';
    try {
      this.apply(await this.api.saveMatrix(grants));
      this.snack.open('Matrix saved. Other modules pick it up within 2 minutes.', 'Close', { duration: 4000 });
    } catch (e) {
      this.error = errorMessage(e);
    } finally {
      this.saving = false;
    }
  }

  discard(): void {
    if (this.matrix) this.apply(this.matrix);
  }

  async reset(role: RoleView): Promise<void> {
    if (this.blockedByUnsavedChanges()) return;
    try {
      await this.api.resetRole(role.code);
      this.snack.open(`${role.name} restored to the default permission set.`, 'Close', { duration: 4000 });
      await this.load();
    } catch (e) {
      this.snack.open(errorMessage(e), 'Close', { duration: 5000 });
    }
  }

  openRole(role?: RoleView): void {
    if (this.blockedByUnsavedChanges()) return;
    const data: RoleFormDialogData = { role };
    this.dialog
      .open(RoleFormDialogComponent, { width: '560px', maxWidth: '95vw', data, disableClose: true })
      .afterClosed()
      .subscribe((saved) => saved && this.load());
  }

  private blockedByUnsavedChanges(): boolean {
    if (this.dirty.size === 0) return false;
    this.snack.open('Save or discard the matrix changes first.', 'Close', { duration: 4000 });
    return true;
  }
}
