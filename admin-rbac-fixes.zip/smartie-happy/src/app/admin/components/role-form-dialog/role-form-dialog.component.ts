import { Component, Inject } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { RoleView, SCOPE_LABELS, ScopeLevel, SUPER_ADMIN } from '../../models/admin.models';
import { AdminApiService } from '../../services/admin-api.service';
import { errorMessage } from '../../utils/api-error.util';

export interface RoleFormDialogData {
  role?: RoleView;
}

/** Create a role (S2 #37) or change its name / default visibility / retire it. Permissions are set in the matrix. */
@Component({
  selector: 'app-admin-role-form-dialog',
  templateUrl: './role-form-dialog.component.html',
})
export class RoleFormDialogComponent {
  readonly scopes = (['OWN', 'TEAM', 'LOB', 'LOCATION', 'ALL'] as ScopeLevel[]).map((s) => ({ value: s, label: SCOPE_LABELS[s] }));
  readonly form = new FormGroup({
    code: new FormControl('', { nonNullable: true, validators: [Validators.required, Validators.pattern(/^[A-Z][A-Z0-9_]{1,49}$/)] }),
    name: new FormControl('', { nonNullable: true, validators: [Validators.required, Validators.maxLength(100)] }),
    description: new FormControl('', { nonNullable: true, validators: [Validators.maxLength(500)] }),
    defaultScope: new FormControl<ScopeLevel>('OWN', { nonNullable: true }),
    active: new FormControl(true, { nonNullable: true }),
  });
  saving = false;
  error = '';

  constructor(
    @Inject(MAT_DIALOG_DATA) public data: RoleFormDialogData,
    private ref: MatDialogRef<RoleFormDialogComponent, RoleView | undefined>,
    private api: AdminApiService
  ) {
    const r = data.role;
    if (r) {
      this.form.patchValue({ code: r.code, name: r.name, description: r.description ?? '', defaultScope: r.defaultScope, active: r.active });
      this.form.controls.code.disable();
      if (r.code === SUPER_ADMIN) this.form.controls.active.disable();
    }
  }

  get isEdit(): boolean {
    return !!this.data.role;
  }

  upperCode(): void {
    const c = this.form.controls.code;
    c.setValue(c.value.toUpperCase().replace(/[^A-Z0-9_]/g, '_'), { emitEvent: false });
  }

  async save(): Promise<void> {
    if (this.form.invalid) {
      this.form.markAllAsTouched();
      return;
    }
    const v = this.form.getRawValue();
    this.saving = true;
    this.error = '';
    try {
      const saved = this.isEdit
        ? await this.api.updateRole(v.code, {
            name: v.name.trim(),
            description: v.description.trim() || undefined,
            defaultScope: v.defaultScope,
            active: v.active,
            version: this.data.role!.version,
          })
        : await this.api.createRole({
            code: v.code,
            name: v.name.trim(),
            description: v.description.trim() || undefined,
            defaultScope: v.defaultScope,
            permissions: [],
          });
      this.ref.close(saved);
    } catch (e) {
      this.error = errorMessage(e);
    } finally {
      this.saving = false;
    }
  }

  cancel(): void {
    this.ref.close(undefined);
  }
}
