import { COMMA, ENTER } from '@angular/cdk/keycodes';
import { Component, Inject, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { MatChipInputEvent } from '@angular/material/chips';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { debounceTime, distinctUntilChanged, switchMap, from, of, Observable, map, catchError } from 'rxjs';
import {
  AdminUser,
  AdminUserSummary,
  NOT_ASSIGNABLE_ROLES,
  RoleView,
  SCOPE_LABELS,
  ScopeLevel,
  UserType,
} from '../../models/admin.models';
import { AdminApiService } from '../../services/admin-api.service';
import { errorMessage, problemOf } from '../../utils/api-error.util';

export interface UserFormDialogData {
  mode: 'create' | 'edit';
  user?: AdminUser;
}

/** Tracker #22: admin user account creation (also used to edit profile, manager and visibility). */
@Component({
  selector: 'app-admin-user-form-dialog',
  templateUrl: './user-form-dialog.component.html',
  styleUrls: ['./user-form-dialog.component.scss'],
})
export class UserFormDialogComponent implements OnInit {
  readonly separators = [ENTER, COMMA];
  readonly scopeOptions: { value: ScopeLevel | null; label: string }[] = [
    { value: null, label: 'Role default' },
    ...(['OWN', 'TEAM', 'LOB', 'LOCATION', 'ALL'] as ScopeLevel[]).map((s) => ({ value: s, label: SCOPE_LABELS[s] })),
  ];
  readonly userTypes: { value: UserType; label: string }[] = [
    { value: 'EMPLOYEE_HR', label: 'HR employee' },
    { value: 'EMPLOYEE_HR_ADMIN', label: 'HR admin' },
    { value: 'EMPLOYEE_NON_HR', label: 'Non-HR employee (e.g. panel member)' },
  ];

  readonly form = new FormGroup({
    email: new FormControl('', { nonNullable: true, validators: [Validators.required, Validators.email, Validators.maxLength(254)] }),
    fullName: new FormControl('', { nonNullable: true, validators: [Validators.required, Validators.maxLength(200)] }),
    employeeCode: new FormControl('', { nonNullable: true, validators: [Validators.maxLength(50)] }),
    userType: new FormControl<UserType>('EMPLOYEE_HR', { nonNullable: true, validators: [Validators.required] }),
    roles: new FormControl<string[]>([], { nonNullable: true, validators: [Validators.required] }),
    scopeLevel: new FormControl<ScopeLevel | null>(null),
    manager: new FormControl<AdminUserSummary | string | null>(null),
  });

  lobs: string[] = [];
  locations: string[] = [];
  roles: RoleView[] = [];
  managerOptions$: Observable<AdminUserSummary[]> = of([]);
  saving = false;
  error = '';

  constructor(
    @Inject(MAT_DIALOG_DATA) public data: UserFormDialogData,
    private ref: MatDialogRef<UserFormDialogComponent, AdminUser | undefined>,
    private api: AdminApiService
  ) {}

  get isEdit(): boolean {
    return this.data.mode === 'edit';
  }

  get needsLobs(): boolean {
    return this.form.controls.scopeLevel.value === 'LOB';
  }

  get needsLocations(): boolean {
    return this.form.controls.scopeLevel.value === 'LOCATION';
  }

  ngOnInit(): void {
    this.api
      .roles(false)
      .then((r) => (this.roles = r.filter((x) => !NOT_ASSIGNABLE_ROLES.includes(x.code))))
      .catch(() => (this.roles = []));

    const u = this.data.user;
    if (u) {
      this.form.patchValue({
        email: u.email,
        fullName: u.fullName,
        employeeCode: u.employeeCode ?? '',
        userType: (u.userType as UserType) ?? 'EMPLOYEE_HR',
        roles: u.roles.map((r) => r.code),
        scopeLevel: u.scopeLevel ?? null,
        manager: u.managerId ? ({ id: u.managerId, fullName: u.managerName ?? u.managerId } as AdminUserSummary) : null,
      });
      this.lobs = [...u.lobs];
      this.locations = [...u.locations];
      this.form.controls.email.disable();
      this.form.controls.userType.disable();
      this.form.controls.roles.disable(); // roles have their own dialog and audit event
    }

    this.managerOptions$ = this.form.controls.manager.valueChanges.pipe(
      debounceTime(300),
      map((v) => (typeof v === 'string' ? v : '')),
      distinctUntilChanged(),
      switchMap((q) =>
        q.trim().length < 2
          ? of([])
          : from(this.api.searchUsers({ search: q, status: 'ACTIVE', page: 0, size: 10 })).pipe(
              map((p) => p.content.filter((x) => x.id !== u?.id)),
              catchError(() => of([]))
            )
      )
    );
  }

  managerLabel(m: AdminUserSummary | string | null): string {
    return !m ? '' : typeof m === 'string' ? m : m.fullName;
  }

  addValue(list: 'lobs' | 'locations', event: MatChipInputEvent): void {
    const value = (event.value || '').trim().toUpperCase();
    if (value && !this[list].includes(value)) {
      this[list] = [...this[list], value];
    }
    event.chipInput.clear();
  }

  removeValue(list: 'lobs' | 'locations', value: string): void {
    this[list] = this[list].filter((v) => v !== value);
  }

  async save(): Promise<void> {
    this.error = '';
    if (this.form.invalid) {
      this.form.markAllAsTouched();
      return;
    }
    if (this.needsLobs && this.lobs.length === 0) {
      this.error = 'Add at least one LOB for LOB visibility.';
      return;
    }
    if (this.needsLocations && this.locations.length === 0) {
      this.error = 'Add at least one location for LOCATION visibility.';
      return;
    }
    const v = this.form.getRawValue();
    const manager = v.manager && typeof v.manager !== 'string' ? v.manager.id : null;
    if (typeof v.manager === 'string' && v.manager.trim()) {
      this.error = 'Pick the manager from the list, or clear the field.';
      return;
    }
    this.saving = true;
    try {
      const saved = this.isEdit
        ? await this.api.updateUser(this.data.user!.id, {
            fullName: v.fullName.trim(),
            employeeCode: v.employeeCode.trim() || undefined,
            managerId: manager,
            scopeLevel: v.scopeLevel,
            lobs: this.lobs,
            locations: this.locations,
            version: this.data.user!.version,
          })
        : await this.api.createUser({
            email: v.email.trim().toLowerCase(),
            fullName: v.fullName.trim(),
            employeeCode: v.employeeCode.trim() || undefined,
            userType: v.userType,
            roles: v.roles,
            managerId: manager,
            scopeLevel: v.scopeLevel,
            lobs: this.lobs,
            locations: this.locations,
          });
      this.ref.close(saved);
    } catch (e) {
      const p = problemOf(e);
      if (p.code === 'USER_EXISTS') {
        this.form.controls.email.setErrors({ exists: true });
      }
      this.error = errorMessage(e);
    } finally {
      this.saving = false;
    }
  }

  cancel(): void {
    this.ref.close(undefined);
  }
}
