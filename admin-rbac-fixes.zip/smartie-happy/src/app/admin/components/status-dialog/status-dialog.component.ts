import { Component, Inject } from '@angular/core';
import { FormControl, Validators } from '@angular/forms';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { AdminUser } from '../../models/admin.models';
import { AdminApiService } from '../../services/admin-api.service';
import { errorMessage } from '../../utils/api-error.util';

export interface StatusDialogData {
  userId: string;
  userName: string;
  action: 'deactivate' | 'reactivate';
}

/** Deactivate (reason required) / reactivate. The login stays; roles and permissions stop on the next request. */
@Component({
  selector: 'app-admin-status-dialog',
  templateUrl: './status-dialog.component.html',
})
export class StatusDialogComponent {
  readonly reason = new FormControl('', { nonNullable: true, validators: [Validators.maxLength(1000)] });
  saving = false;
  error = '';

  constructor(
    @Inject(MAT_DIALOG_DATA) public data: StatusDialogData,
    private ref: MatDialogRef<StatusDialogComponent, AdminUser | undefined>,
    private api: AdminApiService
  ) {
    if (data.action === 'deactivate') {
      this.reason.addValidators(Validators.required);
    }
  }

  async confirm(): Promise<void> {
    if (this.reason.invalid) {
      this.reason.markAsTouched();
      return;
    }
    this.saving = true;
    this.error = '';
    try {
      const r = this.reason.value.trim();
      const saved =
        this.data.action === 'deactivate'
          ? await this.api.deactivate(this.data.userId, r)
          : await this.api.reactivate(this.data.userId, r || undefined);
      this.ref.close(saved);
    } catch (e) {
      this.error = errorMessage(e);
    } finally {
      this.saving = false;
    }
  }

  cancel(): void {
    this.ref.close(undefined);
  }
}
