import { inject } from '@angular/core';
import { ActivatedRouteSnapshot, CanActivateFn, Router } from '@angular/router';
import { MatSnackBar } from '@angular/material/snack-bar';
import { RbacService } from '../services/rbac.service';

/**
 * Route guard driven by admin-services permissions, not by localStorage role.
 * Route data: { permission: 'USER:VIEW' } and optionally { role: 'SUPER_ADMIN' }.
 * The API enforces the same rules - this only keeps people off screens they can not use.
 */
export const permissionGuard: CanActivateFn = async (route: ActivatedRouteSnapshot) => {
  const rbac = inject(RbacService);
  const router = inject(Router);
  const snack = inject(MatSnackBar);
  await rbac.ensureLoaded();
  const permission = route.data['permission'] as string | undefined;
  const role = route.data['role'] as string | undefined;
  const ok = (!permission || rbac.has(permission)) && (!role || rbac.hasRole(role));
  if (ok) {
    return true;
  }
  snack.open('You do not have access to this screen.', 'Close', { duration: 4000 });
  return router.createUrlTree(['/h/candidate-list']);
};
