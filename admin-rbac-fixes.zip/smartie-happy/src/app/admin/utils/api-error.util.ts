import { HttpErrorResponse } from '@angular/common/http';
import { ApiProblem } from '../models/admin.models';

/** Friendly text per admin-services error code. Unknown codes fall back to the server's `detail`. */
const MESSAGES: Record<string, string> = {
  UNAUTHORIZED: 'Your session has ended. Please log in again.',
  INVALID_TOKEN: 'Your session has ended. Please log in again.',
  ACCESS_DENIED: 'You do not have permission for this action.',
  SELF_MODIFICATION_NOT_ALLOWED: 'You can not change your own account. Ask another Super Admin.',
  LAST_SUPER_ADMIN: 'This is the last active Super Admin. Add another Super Admin first.',
  SUPER_ADMIN_ROLE_LOCKED: 'The Super Admin role must keep its user, role and configuration permissions.',
  PRIVILEGED_PERMISSION: 'That permission can only come from the Super Admin role.',
  USER_EXISTS: 'A user with this e-mail already exists.',
  CONCURRENT_MODIFICATION: 'Someone else changed this record. Reload and try again.',
  REASON_REQUIRED: 'Please give a reason.',
  ROLE_NOT_ASSIGNABLE: 'Candidate and Vendor roles come from registration / vendor onboarding.',
  ROLE_INACTIVE: 'That role is retired and can not be assigned.',
  SCOPE_VALUES_REQUIRED: 'Pick at least one value for the chosen visibility.',
  INVALID_MANAGER: '',
  EMAIL_DOMAIN_NOT_ALLOWED: '',
  DUPLICATE_PERMISSION: '',
  UNKNOWN_PERMISSION: '',
  UNKNOWN_ROLE: '',
  ROLE_EXISTS: 'A role with this code already exists.',
  RESERVED_ROLE: 'That role code is reserved.',
  NO_DEFAULTS: 'This role has no factory defaults (custom role).',
};

export function problemOf(error: unknown): ApiProblem {
  if (error instanceof HttpErrorResponse) {
    const body = error.error;
    if (body && typeof body === 'object') {
      return { status: error.status, ...(body as Partial<ApiProblem>) } as ApiProblem;
    }
    return { status: error.status, detail: error.message, code: error.status === 0 ? 'NETWORK' : undefined };
  }
  return { status: 0, detail: String(error) };
}

export function errorMessage(error: unknown): string {
  const p = problemOf(error);
  if (p.code === 'NETWORK') {
    return 'admin-services can not be reached. Try again in a moment.';
  }
  if (p.code === 'VALIDATION_FAILED' && p.errors?.length) {
    return p.errors.map((e) => `${e.field}: ${e.message}`).join(', ');
  }
  const mapped = p.code ? MESSAGES[p.code] : undefined;
  const text = mapped || p.detail || 'Something went wrong.';
  return p.correlationId && p.status >= 500 ? `${text} (ref ${p.correlationId})` : text;
}
