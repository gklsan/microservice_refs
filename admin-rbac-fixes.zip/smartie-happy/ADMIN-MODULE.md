# smartie-happy - admin module (Phase 5 S1: tracker #22-25)

Angular 16 + Angular Material, NgModule style like the rest of smartie-happy. Copy `src/app/admin/` into the app.
Compiled with `strict` and `strictTemplates` on Angular 16.1 / Material 16.1 and smoke-tested against a mock
admin-services (no console errors).

## Screens

| Route | Guard | Tracker |
|---|---|---|
| `/h/admin/users` | `USER:VIEW` | #23 list, search, status / role filter, deactivate, reactivate; #22 "Add user" |
| `/h/admin/users/:id` | `USER:VIEW` | details, roles, #24 granular permissions (ALLOW / DENY, own-records-only, expiry), effective access with sources |
| `/h/admin/roles` | `ROLE:VIEW` | #25 role x permission matrix, #1-3 reset to default sets, new / edit / retire role |

Write buttons show only for an active Super Admin (`SUPER_ADMIN` + `USER:MANAGE` / `ROLE:MANAGE`), never on the
logged-in admin's own row. The API enforces the same rules; the UI just avoids dead clicks.

## Wire it in (4 small edits)

1. Lazy route in `hr/hr-routing.module.ts` (children of the `/h/` layout):

```ts
{ path: 'admin', loadChildren: () => import('../admin/admin.module').then((m) => m.AdminModule) },
```

2. Side nav (`common-modules/navigation`, the SideNavComponent's module): import `SharedAdminModule`, then add below Archive:

```html
<a routerLink="/h/admin/users" routerLinkActive="active" *appHasPermission="'USER:VIEW'">Admin users</a>
<a routerLink="/h/admin/roles" routerLinkActive="active" *appHasPermission="'ROLE:VIEW'">Roles & permissions</a>
```

3. Load / clear access with the session in `shared/services/auth.service.ts`:

```ts
// after a successful login / verify
this.rbacService.refresh();
// in logout()
this.rbacService.clear();
```

4. Nothing else: services call `${environment.API_URL}admin-services/...`, and the existing `HeaderInterceptor`
   already sends `withCredentials: true`, so the gateway turns the `token` cookie into the Bearer header.
   The gateway needs the `admin-services` route (see admin-services `docs/SETUP.md`).

## Notes

- `permissionGuard` and `*appHasPermission` read `GET /rbac/me`, not `localStorage.role`. Use them for any
  other screen that must follow the admin matrix.
- Errors: admin-services returns RFC 7807 with a `code`; `utils/api-error.util.ts` maps codes to messages.
  4xx are shown inside the dialog / page. Your `HeaderInterceptor` still handles 401 (logout) and 500.
- `ResponseInterceptor` adds `responseStatus` to response bodies. The admin code ignores it.
- Material icons are not used, so no icon font / registry changes are needed.
