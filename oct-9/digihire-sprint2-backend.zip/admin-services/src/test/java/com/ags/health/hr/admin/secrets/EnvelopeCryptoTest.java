package com.ags.health.hr.admin.secrets;

import com.ags.health.hr.admin.exceptions.APIException;
import org.junit.jupiter.api.Test;

import java.util.Base64;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

class EnvelopeCryptoTest {

    private static final String K1 = Base64.getEncoder().encodeToString(new byte[32]);
    private static final String K2 = Base64.getEncoder().encodeToString(key(7));

    private static byte[] key(int first) {
        byte[] b = new byte[32];
        b[0] = (byte) first;
        return b;
    }

    @Test
    void sealsWithRandomDataKeyAndOpens() {
        EnvelopeCrypto crypto = new EnvelopeCrypto(new LocalKeyEncryptionKeyProvider("k1:" + K1, "k1"));
        StoredSecret a = crypto.seal("versant.pw", "hello-secret");
        StoredSecret b = crypto.seal("versant.pw", "hello-secret");
        assertThat(a.ciphertext()).doesNotContain("hello");
        assertThat(a.ciphertext()).isNotEqualTo(b.ciphertext());
        assertThat(a.kekId()).isEqualTo("k1");
        assertThat(crypto.open("versant.pw", a)).isEqualTo("hello-secret");
    }

    @Test
    void valueIsBoundToItsNameAndTamperingIsDetected() {
        EnvelopeCrypto crypto = new EnvelopeCrypto(new LocalKeyEncryptionKeyProvider("k1:" + K1, "k1"));
        StoredSecret s = crypto.seal("versant.pw", "hello-secret");
        assertThatThrownBy(() -> crypto.open("shl.pw", s)).isInstanceOf(APIException.class);
        byte[] raw = Base64.getDecoder().decode(s.ciphertext());
        raw[raw.length - 1] ^= 1;
        StoredSecret tampered = new StoredSecret(Base64.getEncoder().encodeToString(raw), s.wrappedDek(), s.kekId(), null);
        assertThatThrownBy(() -> crypto.open("versant.pw", tampered)).isInstanceOf(APIException.class);
    }

    @Test
    void rewrapMovesTheDataKeyToTheActiveMasterKey() {
        StoredSecret s = new EnvelopeCrypto(new LocalKeyEncryptionKeyProvider("k1:" + K1, "k1")).seal("x.y", "v-123");
        EnvelopeCrypto rotated = new EnvelopeCrypto(new LocalKeyEncryptionKeyProvider("k1:" + K1 + ",k2:" + K2, "k2"));
        StoredSecret r = rotated.rewrap("x.y", s);
        assertThat(r.kekId()).isEqualTo("k2");
        assertThat(r.ciphertext()).isEqualTo(s.ciphertext());
        assertThat(rotated.open("x.y", r)).isEqualTo("v-123");
        assertThat(rotated.rewrap("x.y", r)).isSameAs(r);
    }

    @Test
    void badKeyConfigurationFailsFastAndMissingKeysAreAllowed() {
        assertThatThrownBy(() -> new LocalKeyEncryptionKeyProvider("k1:abc", "k1")).isInstanceOf(IllegalStateException.class);
        assertThatThrownBy(() -> new LocalKeyEncryptionKeyProvider("k1:" + K1, "k9")).isInstanceOf(IllegalStateException.class);
        assertThat(new LocalKeyEncryptionKeyProvider(null, null).isConfigured()).isFalse();
        assertThatThrownBy(() -> new LocalKeyEncryptionKeyProvider(null, null).active())
                .isInstanceOf(APIException.class).hasMessageContaining("SECRETS_MASTER_KEYS");
    }
}
