package com.ags.health.hr.admin.controllers;

import org.junit.jupiter.api.Test;
import org.springframework.core.annotation.AnnotatedElementUtils;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * Guard test (from the architect's proposal): every endpoint declares @PreAuthorize, every write under
 * /admin requires an active SUPER_ADMIN, and /internal requires the service key. A new endpoint without
 * a rule fails the build instead of shipping open.
 */
class EndpointSecurityTest {

    private static final List<Class<?>> CONTROLLERS = List.of(
            AdminUserController.class, RoleController.class, ConfigController.class, RbacController.class, InternalController.class,
            SecretController.class, ApprovalFlowController.class);

    @Test
    void everyEndpointIsProtectedCorrectly() {
        List<String> problems = new ArrayList<>();
        for (Class<?> c : CONTROLLERS) {
            assertThat(c.isAnnotationPresent(RestController.class)).isTrue();
            String base = c.getAnnotation(RequestMapping.class).value()[0];
            for (Method m : c.getDeclaredMethods()) {
                RequestMapping mapping = AnnotatedElementUtils.findMergedAnnotation(m, RequestMapping.class);
                if (mapping == null) {
                    continue;
                }
                String name = c.getSimpleName() + "." + m.getName();
                PreAuthorize rule = m.getAnnotation(PreAuthorize.class);
                if (rule == null) {
                    problems.add(name + " has no @PreAuthorize");
                    continue;
                }
                boolean read = m.isAnnotationPresent(GetMapping.class);
                if (base.startsWith("/internal") && !rule.value().contains("hasRole('INTERNAL')")) {
                    problems.add(name + " must require hasRole('INTERNAL')");
                }
                if (base.startsWith("/admin") && !read && !rule.value().contains("hasRole('SUPER_ADMIN')")) {
                    problems.add(name + " changes data but does not require hasRole('SUPER_ADMIN')");
                }
            }
        }
        assertThat(problems).isEmpty();
    }
}
