package com.ags.health.hr.admin;

import com.fasterxml.jackson.databind.ObjectMapper;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import io.jsonwebtoken.io.Decoders;
import io.jsonwebtoken.security.Keys;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockHttpServletRequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import static org.assertj.core.api.Assertions.assertThat;

@SpringBootTest(properties = {
        "eureka.client.enabled=false",
        "spring.sql.init.mode=always",
        "spring.datasource.url=jdbc:h2:mem:authdb_matrix;DB_CLOSE_DELAY=-1;DB_CLOSE_ON_EXIT=FALSE",
        "spring.datasource.driver-class-name=org.h2.Driver",
        "spring.datasource.username=sa",
        "spring.datasource.password=",
        "spring.jpa.properties.hibernate.dialect=org.hibernate.dialect.H2Dialect",
        "admin.users.allowed-email-domains=agshealth.com",
        "admin.security.jwt-secret=" + AdminRoleMatrixTest.SECRET,
        "admin.security.internal-api-key=matrix-internal-key",
        "admin.bootstrap.super-admin-emails=" + AdminRoleMatrixTest.ADMIN,
        "admin.secrets.master-keys=k1:MDEyMzQ1Njc4OWFiY2RlZjAxMjM0NTY3ODlhYmNkZWY=",
        "admin.secrets.active-key-id=k1"
})
@AutoConfigureMockMvc
class AdminRoleMatrixTest {

    static final String SECRET = "c2VjcmV0LWtleS1mb3ItdGVzdHMtb25seS0zMi1ieXRlcy1sb25nISE=";
    static final String ADMIN = "matrix.admin@agshealth.com";

    private static final Map<String, String> STAFF = Map.of(
            "RECRUITER", "matrix.rec@agshealth.com",
            "RECRUITMENT_MANAGER", "matrix.rm@agshealth.com",
            "TA_HEAD", "matrix.tah@agshealth.com",
            "INTERVIEWER", "matrix.int@agshealth.com",
            "EMPLOYEE", "matrix.emp@agshealth.com");

    @Autowired
    MockMvc mvc;
    @Autowired
    ObjectMapper mapper;

    @Test
    void everyRoleGetsExactlyTheAccessOfTheMatrix() throws Exception {
        Map<String, String> tokens = tokens();
        List<String> problems = new ArrayList<>();
        try (InputStream in = getClass().getResourceAsStream("/admin-role-matrix.csv")) {
            assertThat(in).as("admin-role-matrix.csv on the test classpath").isNotNull();
            BufferedReader reader = new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8));
            String[] header = reader.readLine().split("\\|", -1);
            String line;
            while ((line = reader.readLine()) != null) {
                if (line.isBlank()) {
                    continue;
                }
                String[] f = line.split("\\|", -1);
                List<Integer> order = new ArrayList<>();
                for (int i = 3; i < header.length; i++) {
                    if (!"Y".equals(f[i])) {
                        order.add(i);
                    }
                }
                for (int i = 3; i < header.length; i++) {
                    if ("Y".equals(f[i])) {
                        order.add(i);
                    }
                }
                for (int i : order) {
                    String role = header[i];
                    boolean allowed = "Y".equals(f[i]);
                    MockHttpServletRequestBuilder req = MockMvcRequestBuilders.request(HttpMethod.valueOf(f[0]), f[1])
                            .header("Authorization", tokens.get(role));
                    if (!f[2].isBlank()) {
                        req.contentType(MediaType.APPLICATION_JSON).content(f[2]);
                    }
                    MockHttpServletResponse res = mvc.perform(req).andReturn().getResponse();
                    int status = res.getStatus();
                    if (allowed && (status == 401 || status == 403 || status >= 500)) {
                        problems.add(role + " " + f[0] + " " + f[1] + " expected access, got " + status + " " + res.getContentAsString());
                    }
                    if (!allowed && status != 403) {
                        problems.add(role + " " + f[0] + " " + f[1] + " expected 403, got " + status + " " + res.getContentAsString());
                    }
                }
            }
        }
        assertThat(problems).isEmpty();
    }

    private Map<String, String> tokens() throws Exception {
        Map<String, String> tokens = new LinkedHashMap<>();
        String admin = token("matrix-sa", ADMIN, "EMPLOYEE_HR_ADMIN");
        tokens.put("SUPER_ADMIN", admin);
        for (Map.Entry<String, String> e : STAFF.entrySet()) {
            int status = mvc.perform(MockMvcRequestBuilders.post("/admin/users").header("Authorization", admin)
                            .contentType(MediaType.APPLICATION_JSON)
                            .content(mapper.writeValueAsString(Map.of("email", e.getValue(), "fullName", e.getKey(),
                                    "userType", "EMPLOYEE_HR", "roles", List.of(e.getKey())))))
                    .andReturn().getResponse().getStatus();
            assertThat(status).as("create %s", e.getValue()).isEqualTo(201);
            tokens.put(e.getKey(), token("matrix-" + e.getKey(), e.getValue(), "EMPLOYEE_HR"));
        }
        tokens.put("CANDIDATE", token("matrix-cand", "cand@example.com", "CANDIDATE"));
        tokens.put("VENDOR", token("matrix-ven", "vendor@example.com", "VENDOR"));
        return tokens;
    }

    private static String token(String userId, String email, String userType) {
        return "Bearer " + Jwts.builder()
                .setSubject(email)
                .addClaims(Map.of("userId", userId, "email", email, "userType", userType, "userName", email))
                .setIssuedAt(new Date())
                .setExpiration(new Date(System.currentTimeMillis() + 3_600_000))
                .signWith(Keys.hmacShaKeyFor(Decoders.BASE64.decode(SECRET)), SignatureAlgorithm.HS256)
                .compact();
    }
}
