package com.ags.health.hr.admin.config;

import lombok.Getter;
import lombok.Setter;
import org.springframework.boot.context.properties.ConfigurationProperties;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** Everything under {@code admin.*} in application.yml. Secrets come from environment variables only. */
@Getter
@Setter
@ConfigurationProperties(prefix = "admin")
public class AdminProperties {

    private Security security = new Security();
    private Bootstrap bootstrap = new Bootstrap();
    private Users users = new Users();
    private Access access = new Access();
    private Secrets secrets = new Secrets();

    @Getter
    @Setter
    public static class Security {
        /** Base64 encoded HS256 secret shared with auth-services and the gateway (env JWT_SECRET). */
        private String jwtSecret;
        /** Service-to-service key for /internal/** (env INTERNAL_API_KEY). */
        private String internalApiKey;
        private String internalServiceKeys;
        private boolean requireHttps;
        private boolean requireDbTls;
    }

    @Getter
    @Setter
    public static class Bootstrap {
        private List<String> superAdminEmails = new ArrayList<>();
    }

    @Getter
    @Setter
    public static class Users {
        private List<String> allowedEmailDomains = new ArrayList<>();
    }

    @Getter
    @Setter
    public static class Access {
        private Map<String, List<String>> fallbackRolesByUserType = new LinkedHashMap<>();
    }

    @Getter
    @Setter
    public static class Secrets {
        private String defaultBackend = "DB";
        private String activeKeyId;
        private String masterKeys;
        private boolean requireServiceKey;
        private Aws aws = new Aws();
    }

    @Getter
    @Setter
    public static class Aws {
        private boolean enabled;
        private String region = "ap-south-1";
        private String prefix = "digihire/";
    }
}
