package com.ags.health.hr.admin.data;

import com.ags.health.hr.admin.entities.Secret;
import com.ags.health.hr.admin.enums.SecretBackendType;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;

import java.time.Instant;
import java.util.List;
import java.util.UUID;

public final class SecretDtos {

    public static final String NAME_PATTERN = "[a-z0-9][a-z0-9._\\-]{2,149}";
    public static final String SERVICE_PATTERN = "[a-z0-9][a-z0-9\\-]{1,99}";

    private SecretDtos() {
    }

    public record Create(@NotBlank @Pattern(regexp = NAME_PATTERN) String name,
                         @NotBlank @Pattern(regexp = "[A-Z][A-Z0-9_]{1,59}") String integration,
                         @Size(max = 500) String description,
                         @NotNull @Size(min = 1, max = 4096) String value,
                         SecretBackendType backend,
                         @NotNull @Size(max = 20) List<@NotBlank @Pattern(regexp = SERVICE_PATTERN) String> allowedServices,
                         @Min(1) @Max(3650) Integer rotationDays) {
    }

    public record Update(@Size(max = 500) String description,
                         @Size(min = 1, max = 4096) String value,
                         @Size(max = 20) List<@NotBlank @Pattern(regexp = SERVICE_PATTERN) String> allowedServices,
                         @Min(0) @Max(3650) Integer rotationDays,
                         @NotNull Boolean active,
                         Long version) {
    }

    public record Reveal(@NotBlank @Size(max = 500) String reason) {
    }

    public record View(String name, String integration, String description, SecretBackendType backend, String valueHint,
                       List<String> allowedServices, Integer rotationDays, Instant lastRotatedAt, boolean rotationDue,
                       boolean active, Instant createdDate, String createdBy, Instant updatedDate, String updatedBy,
                       Long version) {

        public static View of(Secret s, Instant now) {
            return new View(s.getName(), s.getIntegration(), s.getDescription(), s.getBackend(), s.getValueHint(),
                    s.allowedServiceList(), s.getRotationDays(), s.getLastRotatedAt(), s.isRotationDue(now), s.isActive(),
                    s.getCreatedDate(), s.getCreatedBy(), s.getUpdatedDate(), s.getUpdatedBy(), s.getVersion());
        }
    }

    public record Revealed(String name, String value, Instant revealedAt) {
    }

    public record ServiceValue(String name, String value, Instant lastRotatedAt) {
    }

    public record AccessLogEntry(UUID id, String secretName, String action, String outcome, String actorId,
                                 String actorEmail, String callerService, String reason, String clientIp,
                                 String correlationId, Instant occurredAt) {
    }

    public record RotationResult(int rewrapped, int skipped, String activeKeyId) {
    }
}
