package com.ags.health.hr.admin.enums;

public enum SecretAccessAction { CREATE, UPDATE, ROTATE_VALUE, REWRAP, REVEAL, READ_INTERNAL, DISABLE, ENABLE }
