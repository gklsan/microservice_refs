package com.ags.health.hr.admin.secrets;

import com.ags.health.hr.admin.exceptions.APIException;
import org.springframework.http.HttpStatus;

import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;
import java.security.GeneralSecurityException;
import java.security.SecureRandom;
import java.util.Arrays;
import java.util.Base64;

public class EnvelopeCrypto {

    private static final String ALGORITHM = "AES/GCM/NoPadding";
    private static final int IV_BYTES = 12;
    private static final int TAG_BITS = 128;
    private static final int DEK_BYTES = 32;

    private final KeyEncryptionKeyProvider keks;
    private final SecureRandom random = new SecureRandom();

    public EnvelopeCrypto(KeyEncryptionKeyProvider keks) {
        this.keks = keks;
    }

    public boolean isConfigured() {
        return keks.isConfigured();
    }

    public StoredSecret seal(String name, String value) {
        KeyEncryptionKeyProvider.Kek kek = keks.active();
        byte[] dek = new byte[DEK_BYTES];
        random.nextBytes(dek);
        byte[] plain = value.getBytes(StandardCharsets.UTF_8);
        try {
            String ciphertext = encrypt(new SecretKeySpec(dek, "AES"), plain, aad("value", name));
            String wrapped = encrypt(kek.key(), dek, aad("dek", name));
            return new StoredSecret(ciphertext, wrapped, kek.id(), null);
        } finally {
            Arrays.fill(dek, (byte) 0);
            Arrays.fill(plain, (byte) 0);
        }
    }

    public String open(String name, StoredSecret stored) {
        byte[] dek = decrypt(keks.byId(stored.kekId()).key(), stored.wrappedDek(), aad("dek", name));
        try {
            byte[] plain = decrypt(new SecretKeySpec(dek, "AES"), stored.ciphertext(), aad("value", name));
            try {
                return new String(plain, StandardCharsets.UTF_8);
            } finally {
                Arrays.fill(plain, (byte) 0);
            }
        } finally {
            Arrays.fill(dek, (byte) 0);
        }
    }

    public StoredSecret rewrap(String name, StoredSecret stored) {
        KeyEncryptionKeyProvider.Kek active = keks.active();
        if (active.id().equals(stored.kekId())) {
            return stored;
        }
        byte[] dek = decrypt(keks.byId(stored.kekId()).key(), stored.wrappedDek(), aad("dek", name));
        try {
            return new StoredSecret(stored.ciphertext(), encrypt(active.key(), dek, aad("dek", name)), active.id(),
                    stored.externalRef());
        } finally {
            Arrays.fill(dek, (byte) 0);
        }
    }

    private String encrypt(SecretKey key, byte[] plain, byte[] aad) {
        byte[] iv = new byte[IV_BYTES];
        random.nextBytes(iv);
        try {
            Cipher cipher = Cipher.getInstance(ALGORITHM);
            cipher.init(Cipher.ENCRYPT_MODE, key, new GCMParameterSpec(TAG_BITS, iv));
            cipher.updateAAD(aad);
            byte[] sealed = cipher.doFinal(plain);
            return Base64.getEncoder().encodeToString(ByteBuffer.allocate(iv.length + sealed.length).put(iv).put(sealed).array());
        } catch (GeneralSecurityException e) {
            throw new IllegalStateException("AES-GCM encryption failed", e);
        }
    }

    private byte[] decrypt(SecretKey key, String encoded, byte[] aad) {
        if (encoded == null) {
            throw corrupted();
        }
        byte[] all;
        try {
            all = Base64.getDecoder().decode(encoded);
        } catch (IllegalArgumentException e) {
            throw corrupted();
        }
        if (all.length <= IV_BYTES) {
            throw corrupted();
        }
        try {
            Cipher cipher = Cipher.getInstance(ALGORITHM);
            cipher.init(Cipher.DECRYPT_MODE, key, new GCMParameterSpec(TAG_BITS, all, 0, IV_BYTES));
            cipher.updateAAD(aad);
            return cipher.doFinal(all, IV_BYTES, all.length - IV_BYTES);
        } catch (GeneralSecurityException e) {
            throw corrupted();
        }
    }

    private static byte[] aad(String purpose, String name) {
        return (purpose + ":" + name).getBytes(StandardCharsets.UTF_8);
    }

    private static APIException corrupted() {
        return new APIException(HttpStatus.INTERNAL_SERVER_ERROR, "SECRET_UNREADABLE",
                "The stored secret can not be decrypted. Check SECRETS_MASTER_KEYS.");
    }
}
