package com.ags.health.hr.admin.secrets;

import javax.crypto.SecretKey;

public interface KeyEncryptionKeyProvider {

    record Kek(String id, SecretKey key) {
    }

    boolean isConfigured();

    Kek active();

    Kek byId(String id);
}
