package com.ags.health.hr.admin.resources;

import com.ags.health.hr.admin.entities.ApprovalFlow;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface ApprovalFlowRepository extends JpaRepository<ApprovalFlow, String> {

    List<ApprovalFlow> findAllByOrderByCodeAsc();
}
