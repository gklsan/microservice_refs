package com.ags.health.hr.admin.secrets;

import com.ags.health.hr.admin.enums.SecretBackendType;
import com.ags.health.hr.admin.exceptions.APIException;

import java.util.EnumMap;
import java.util.List;
import java.util.Map;

public class SecretBackends {

    private final Map<SecretBackendType, SecretBackend> byType = new EnumMap<>(SecretBackendType.class);
    private final SecretBackendType defaultType;

    public SecretBackends(List<SecretBackend> backends, SecretBackendType defaultType) {
        backends.forEach(b -> byType.put(b.type(), b));
        this.defaultType = defaultType;
    }

    public SecretBackendType defaultType() {
        return defaultType;
    }

    public SecretBackend get(SecretBackendType type) {
        SecretBackend backend = byType.get(type == null ? defaultType : type);
        if (backend == null) {
            throw APIException.badRequest("SECRET_BACKEND_DISABLED", "Secret backend " + type + " is not enabled");
        }
        return backend;
    }
}
