package com.ags.health.hr.admin.entities;

import jakarta.persistence.CollectionTable;
import jakarta.persistence.Column;
import jakarta.persistence.ElementCollection;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

@Entity
@Table(name = "adm_approval_flow")
@Getter
@Setter
@NoArgsConstructor
public class ApprovalFlow extends CommonEntity {

    @Id
    private String code;

    @Column(nullable = false)
    private String name;

    private String description;

    @Column(nullable = false)
    private boolean active = true;

    @ElementCollection(fetch = FetchType.EAGER)
    @CollectionTable(name = "adm_approval_level", joinColumns = @JoinColumn(name = "flow_code"))
    private Set<ApprovalLevel> levels = new HashSet<>();

    public List<ApprovalLevel> orderedLevels() {
        return levels.stream().sorted(Comparator.comparingInt(ApprovalLevel::levelNo)).toList();
    }
}
