package com.ags.health.hr.admin.controllers;

import com.ags.health.hr.admin.data.ApprovalDtos;
import com.ags.health.hr.admin.services.ApprovalFlowService;
import com.ags.health.hr.admin.services.ApprovalResolverService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.UUID;

@RestController
@RequestMapping("/admin/approvals")
@RequiredArgsConstructor
public class ApprovalFlowController {

    private final ApprovalFlowService service;
    private final ApprovalResolverService resolver;

    @GetMapping("/flows")
    @PreAuthorize("hasAuthority('APPROVAL_FLOW:VIEW')")
    public List<ApprovalDtos.FlowView> flows() {
        return service.list();
    }

    @GetMapping("/flows/{code}")
    @PreAuthorize("hasAuthority('APPROVAL_FLOW:VIEW')")
    public ApprovalDtos.FlowView flow(@PathVariable String code) {
        return service.get(code);
    }

    @PostMapping("/flows")
    @PreAuthorize("hasRole('SUPER_ADMIN') and hasAuthority('APPROVAL_FLOW:MANAGE')")
    public ResponseEntity<ApprovalDtos.FlowView> create(@Valid @RequestBody ApprovalDtos.CreateFlow req) {
        return new ResponseEntity<>(service.create(req), HttpStatus.CREATED);
    }

    @PutMapping("/flows/{code}")
    @PreAuthorize("hasRole('SUPER_ADMIN') and hasAuthority('APPROVAL_FLOW:MANAGE')")
    public ApprovalDtos.FlowView update(@PathVariable String code, @Valid @RequestBody ApprovalDtos.UpdateFlow req) {
        return service.update(code, req);
    }

    @GetMapping("/flows/{code}/preview")
    @PreAuthorize("hasAuthority('APPROVAL_FLOW:VIEW')")
    public ApprovalDtos.Resolution preview(@PathVariable String code,
                                           @RequestParam(required = false) String requesterEmail,
                                           @RequestParam(required = false) String lob,
                                           @RequestParam(required = false) String location) {
        return resolver.resolve(code, null, requesterEmail, lob, location);
    }

    @GetMapping("/approvers")
    @PreAuthorize("hasAuthority('APPROVAL_FLOW:VIEW')")
    public List<ApprovalDtos.AssignmentView> approvers(@RequestParam(required = false) String flowCode,
                                                       @RequestParam(required = false) UUID approverId,
                                                       @RequestParam(required = false) String lob,
                                                       @RequestParam(required = false) String location,
                                                       @RequestParam(defaultValue = "false") boolean activeOnly) {
        return service.assignments(flowCode, approverId, lob, location, activeOnly);
    }

    @PostMapping("/approvers")
    @PreAuthorize("hasRole('SUPER_ADMIN') and hasAuthority('APPROVAL_FLOW:MANAGE')")
    public ResponseEntity<ApprovalDtos.AssignmentView> assign(@Valid @RequestBody ApprovalDtos.AssignmentRequest req) {
        return new ResponseEntity<>(service.createAssignment(req), HttpStatus.CREATED);
    }

    @PutMapping("/approvers/{id}")
    @PreAuthorize("hasRole('SUPER_ADMIN') and hasAuthority('APPROVAL_FLOW:MANAGE')")
    public ApprovalDtos.AssignmentView updateAssignment(@PathVariable UUID id,
                                                        @Valid @RequestBody ApprovalDtos.AssignmentRequest req) {
        return service.updateAssignment(id, req);
    }
}
