package com.ags.health.hr.admin.services;

import com.ags.health.hr.admin.config.AdminProperties;
import com.ags.health.hr.admin.data.SecretDtos;
import com.ags.health.hr.admin.entities.Secret;
import com.ags.health.hr.admin.enums.AuditCategory;
import com.ags.health.hr.admin.enums.SecretAccessAction;
import com.ags.health.hr.admin.exceptions.APIException;
import com.ags.health.hr.admin.resources.SecretRepository;
import com.ags.health.hr.admin.secrets.KeyEncryptionKeyProvider;
import com.ags.health.hr.admin.secrets.SecretBackend;
import com.ags.health.hr.admin.secrets.SecretBackends;
import com.ags.health.hr.admin.secrets.StoredSecret;
import com.ags.health.hr.admin.security.CurrentUser;
import com.ags.health.hr.admin.security.InternalApiKeyFilter;
import com.ags.health.hr.admin.security.SecurityUtils;
import lombok.RequiredArgsConstructor;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import java.nio.charset.StandardCharsets;
import java.time.Instant;
import java.util.List;
import java.util.Objects;

@Service
@Transactional
@RequiredArgsConstructor
public class SecretService {

    private final SecretRepository repo;
    private final SecretBackends backends;
    private final KeyEncryptionKeyProvider keks;
    private final SecretAccessLogService accessLog;
    private final AuditService audit;
    private final AdminProperties properties;

    @Transactional(readOnly = true)
    public List<SecretDtos.View> list(String integration) {
        Instant now = Instant.now();
        List<Secret> rows = StringUtils.hasText(integration)
                ? repo.findByIntegrationOrderByNameAsc(integration.trim().toUpperCase())
                : repo.findAllByOrderByIntegrationAscNameAsc();
        return rows.stream().map(s -> SecretDtos.View.of(s, now)).toList();
    }

    @Transactional(readOnly = true)
    public SecretDtos.View get(String name) {
        return SecretDtos.View.of(find(name), Instant.now());
    }

    public SecretDtos.View create(SecretDtos.Create req) {
        if (repo.existsById(req.name())) {
            throw APIException.conflict("SECRET_EXISTS", "Secret already exists: " + req.name());
        }
        checkSize(req.value());
        SecretBackend backend = backends.get(req.backend());
        Secret s = new Secret();
        s.setName(req.name());
        s.setIntegration(req.integration());
        s.setDescription(trimToNull(req.description()));
        s.setBackend(backend.type());
        s.setAllowedServiceList(req.allowedServices());
        s.setRotationDays(req.rotationDays());
        s.apply(backend.store(req.name(), req.value(), StoredSecret.empty()));
        s.setValueHint(hint(req.value()));
        s.setLastRotatedAt(Instant.now());
        repo.save(s);
        accessLog.record(s.getName(), SecretAccessAction.CREATE, SecretAccessLogService.SUCCESS, null, null);
        audit.log(AuditCategory.SECURITY, "SECRET_CREATED", "SECRET", s.getName(), AdminUserService.details(
                "integration", s.getIntegration(), "backend", s.getBackend(), "allowedServices", s.allowedServiceList(),
                "rotationDays", s.getRotationDays()));
        return SecretDtos.View.of(s, Instant.now());
    }

    public SecretDtos.View update(String name, SecretDtos.Update req) {
        Secret s = find(name);
        AdminUserService.checkVersion(s.getVersion(), req.version());
        List<String> servicesBefore = s.allowedServiceList();
        boolean activeBefore = s.isActive();
        Integer rotationBefore = s.getRotationDays();
        String descriptionBefore = s.getDescription();

        if (req.description() != null) {
            s.setDescription(trimToNull(req.description()));
        }
        if (req.allowedServices() != null) {
            s.setAllowedServiceList(req.allowedServices());
        }
        if (req.rotationDays() != null) {
            s.setRotationDays(req.rotationDays() == 0 ? null : req.rotationDays());
        }
        s.setActive(req.active());

        boolean rotated = false;
        if (req.value() != null) {
            checkSize(req.value());
            SecretBackend backend = backends.get(s.getBackend());
            s.apply(backend.store(s.getName(), req.value(), s.stored()));
            s.setValueHint(hint(req.value()));
            s.setLastRotatedAt(Instant.now());
            rotated = true;
            accessLog.record(s.getName(), SecretAccessAction.ROTATE_VALUE, SecretAccessLogService.SUCCESS, null, null);
        }
        if (activeBefore != s.isActive()) {
            accessLog.record(s.getName(), s.isActive() ? SecretAccessAction.ENABLE : SecretAccessAction.DISABLE,
                    SecretAccessLogService.SUCCESS, null, null);
        }
        boolean metaChanged = !Objects.equals(servicesBefore, s.allowedServiceList())
                || !Objects.equals(rotationBefore, s.getRotationDays())
                || !Objects.equals(descriptionBefore, s.getDescription());
        if (metaChanged) {
            accessLog.record(s.getName(), SecretAccessAction.UPDATE, SecretAccessLogService.SUCCESS, null, null);
        }
        if (rotated || metaChanged || activeBefore != s.isActive()) {
            audit.log(AuditCategory.SECURITY, rotated ? "SECRET_ROTATED" : "SECRET_UPDATED", "SECRET", s.getName(),
                    AdminUserService.details("valueChanged", rotated, "activeBefore", activeBefore, "active", s.isActive(),
                            "allowedServicesBefore", servicesBefore, "allowedServices", s.allowedServiceList(),
                            "rotationDaysBefore", rotationBefore, "rotationDays", s.getRotationDays()));
        }
        return SecretDtos.View.of(s, Instant.now());
    }

    public SecretDtos.Revealed reveal(String name, String reason) {
        if (!StringUtils.hasText(reason)) {
            throw APIException.badRequest("REASON_REQUIRED", "Give a reason for revealing the secret");
        }
        Secret s = find(name);
        if (!s.isActive()) {
            accessLog.record(name, SecretAccessAction.REVEAL, SecretAccessLogService.DENIED, null, reason);
            throw APIException.conflict("SECRET_INACTIVE", "Secret " + name + " is disabled");
        }
        String value = backends.get(s.getBackend()).load(s.getName(), s.stored());
        accessLog.record(name, SecretAccessAction.REVEAL, SecretAccessLogService.SUCCESS, null, reason);
        audit.log(AuditCategory.SECURITY, "SECRET_REVEALED", "SECRET", name, AdminUserService.details("reason", reason.trim()));
        return new SecretDtos.Revealed(name, value, Instant.now());
    }

    @Transactional(readOnly = true)
    public SecretDtos.ServiceValue readForService(String name) {
        CurrentUser caller = SecurityUtils.requireUser();
        String verified = verifiedService();
        String service = verified != null ? verified : caller.name();
        Secret s = repo.findById(name).orElse(null);
        if (s == null) {
            accessLog.record(name, SecretAccessAction.READ_INTERNAL, SecretAccessLogService.DENIED, service, "UNKNOWN_SECRET");
            throw APIException.notFound("Secret", name);
        }
        if (properties.getSecrets().isRequireServiceKey() && verified == null) {
            accessLog.record(name, SecretAccessAction.READ_INTERNAL, SecretAccessLogService.DENIED, service, "SERVICE_KEY_REQUIRED");
            throw APIException.forbidden("SECRET_ACCESS_DENIED", "Secrets are only released to callers with their own service key");
        }
        if (service == null || !s.allowedServiceList().contains(service)) {
            accessLog.record(name, SecretAccessAction.READ_INTERNAL, SecretAccessLogService.DENIED, service, "SERVICE_NOT_ALLOWED");
            throw APIException.forbidden("SECRET_ACCESS_DENIED", "Service " + service + " may not read secret " + name);
        }
        if (!s.isActive()) {
            accessLog.record(name, SecretAccessAction.READ_INTERNAL, SecretAccessLogService.DENIED, service, "SECRET_INACTIVE");
            throw APIException.conflict("SECRET_INACTIVE", "Secret " + name + " is disabled");
        }
        String value = backends.get(s.getBackend()).load(s.getName(), s.stored());
        accessLog.record(name, SecretAccessAction.READ_INTERNAL, SecretAccessLogService.SUCCESS, service, null);
        return new SecretDtos.ServiceValue(name, value, s.getLastRotatedAt());
    }

    public SecretDtos.RotationResult rotateMasterKey() {
        String activeId = keks.active().id();
        int rewrapped = 0;
        int skipped = 0;
        for (Secret s : repo.findAll()) {
            SecretBackend backend = backends.get(s.getBackend());
            if (!backend.supportsRewrap() || activeId.equals(s.getKekId())) {
                skipped++;
                continue;
            }
            s.apply(backend.rewrap(s.getName(), s.stored()));
            rewrapped++;
            accessLog.record(s.getName(), SecretAccessAction.REWRAP, SecretAccessLogService.SUCCESS, null, "key " + activeId);
        }
        audit.log(AuditCategory.SECURITY, "SECRET_MASTER_KEY_ROTATED", "SECRET", "*",
                AdminUserService.details("activeKeyId", activeId, "rewrapped", rewrapped, "skipped", skipped));
        return new SecretDtos.RotationResult(rewrapped, skipped, activeId);
    }

    private Secret find(String name) {
        return repo.findById(name).orElseThrow(() -> APIException.notFound("Secret", name));
    }

    private static void checkSize(String value) {
        if (value.getBytes(StandardCharsets.UTF_8).length > 4096) {
            throw APIException.badRequest("SECRET_TOO_LARGE", "Secret values are limited to 4096 bytes");
        }
        if (value.isBlank()) {
            throw APIException.badRequest("SECRET_EMPTY", "Secret value can not be blank");
        }
    }

    static String hint(String value) {
        return value.length() >= 12 ? "****" + value.substring(value.length() - 4) : "****";
    }

    private static String verifiedService() {
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        if (auth == null) {
            return null;
        }
        for (GrantedAuthority a : auth.getAuthorities()) {
            String v = a.getAuthority();
            if (v != null && v.startsWith(InternalApiKeyFilter.SERVICE_AUTHORITY_PREFIX)) {
                return v.substring(InternalApiKeyFilter.SERVICE_AUTHORITY_PREFIX.length());
            }
        }
        return null;
    }

    private static String trimToNull(String s) {
        return StringUtils.hasText(s) ? s.trim() : null;
    }
}
