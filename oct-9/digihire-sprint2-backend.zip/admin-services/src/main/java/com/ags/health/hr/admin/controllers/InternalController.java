package com.ags.health.hr.admin.controllers;

import com.ags.health.hr.admin.data.AdminUserSummary;
import com.ags.health.hr.admin.data.ApprovalDtos;
import com.ags.health.hr.admin.data.SecretDtos;
import com.ags.health.hr.admin.services.ApprovalResolverService;
import com.ags.health.hr.admin.services.SecretService;
import org.springframework.http.CacheControl;
import org.springframework.http.ResponseEntity;
import com.ags.health.hr.admin.security.EffectiveAccess;
import com.ags.health.hr.admin.services.AccessResolverService;
import com.ags.health.hr.admin.data.ConfigDtos;
import com.ags.health.hr.admin.services.AdminUserService;
import com.ags.health.hr.admin.services.ConfigService;
import lombok.RequiredArgsConstructor;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/**
 * Service-to-service API (X-Internal-Key). Must NOT be routed by the gateway.
 * Other services call /internal/rbac/effective and cache the answer for up to 2 minutes.
 */
@RestController
@RequestMapping("/internal")
@RequiredArgsConstructor
public class InternalController {

    private final AccessResolverService accessResolver;
    private final AdminUserService adminUserService;
    private final ConfigService configService;
    private final SecretService secretService;
    private final ApprovalResolverService approvalResolver;

    @GetMapping("/rbac/effective")
    @PreAuthorize("hasRole('INTERNAL')")
    public EffectiveAccess effective(@RequestParam(required = false) String userId,
                                     @RequestParam(required = false) String email,
                                     @RequestParam(required = false) String userType) {
        return accessResolver.resolve(userId, email, userType);
    }

    /** Enterprise configuration for other services (cooling periods, validity days ...). */
    @GetMapping("/config")
    @PreAuthorize("hasRole('INTERNAL')")
    public List<ConfigDtos.View> config(@RequestParam(required = false) String category) {
        return configService.list(category);
    }

    @GetMapping("/config/{key}")
    @PreAuthorize("hasRole('INTERNAL')")
    public ConfigDtos.View configValue(@PathVariable String key) {
        return configService.get(key);
    }

    /** e.g. notification-services resolving e-mail recipients by role. */
    @GetMapping("/users/by-role/{roleCode}")
    @PreAuthorize("hasRole('INTERNAL')")
    public List<AdminUserSummary> usersByRole(@PathVariable String roleCode) {
        return adminUserService.activeByRole(roleCode.toUpperCase());
    }

    @GetMapping("/secrets/{name}")
    @PreAuthorize("hasRole('INTERNAL')")
    public ResponseEntity<SecretDtos.ServiceValue> secret(@PathVariable String name) {
        return ResponseEntity.ok().cacheControl(CacheControl.noStore()).body(secretService.readForService(name));
    }

    @GetMapping("/approvals/{flowCode}/resolve")
    @PreAuthorize("hasRole('INTERNAL')")
    public ApprovalDtos.Resolution resolveApprovers(@PathVariable String flowCode,
                                                    @RequestParam(required = false) String requesterId,
                                                    @RequestParam(required = false) String requesterEmail,
                                                    @RequestParam(required = false) String lob,
                                                    @RequestParam(required = false) String location) {
        return approvalResolver.resolve(flowCode, requesterId, requesterEmail, lob, location);
    }

    @GetMapping("/approvals/{flowCode}/can-approve")
    @PreAuthorize("hasRole('INTERNAL')")
    public ApprovalDtos.CanApprove canApprove(@PathVariable String flowCode,
                                              @RequestParam int level,
                                              @RequestParam(required = false) String approverId,
                                              @RequestParam(required = false) String approverEmail,
                                              @RequestParam(required = false) String requesterId,
                                              @RequestParam(required = false) String requesterEmail,
                                              @RequestParam(required = false) String lob,
                                              @RequestParam(required = false) String location) {
        return approvalResolver.canApprove(flowCode, level, approverId, approverEmail, requesterId, requesterEmail, lob, location);
    }
}
