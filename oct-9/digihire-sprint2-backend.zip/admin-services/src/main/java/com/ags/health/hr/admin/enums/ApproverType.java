package com.ags.health.hr.admin.enums;

public enum ApproverType { ROLE, USER, REPORTING_MANAGER, HIERARCHY }
