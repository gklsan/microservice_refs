package com.ags.health.hr.admin.config;

import org.springframework.boot.context.event.ApplicationEnvironmentPreparedEvent;
import org.springframework.context.ApplicationListener;

import java.util.Locale;

/**
 * admin-services shares the auth-services database (DB_URL): H2 authdb locally, PostgreSQL smartiedb on UAT / prod.
 * The adm_* scripts are written for exactly those two engines (H2 with or without MODE=PostgreSQL).
 * Anything else fails at start-up with a clear message instead of a cryptic SQL error half-way through the scripts.
 */
public class DatabaseUrlGuard implements ApplicationListener<ApplicationEnvironmentPreparedEvent> {

    @Override
    public void onApplicationEvent(ApplicationEnvironmentPreparedEvent event) {
        String url = event.getEnvironment().getProperty("spring.datasource.url", "");
        String lower = url.toLowerCase(Locale.ROOT);
        if (!lower.startsWith("jdbc:postgresql:") && !lower.startsWith("jdbc:h2:")) {
            throw new IllegalStateException("admin-services supports PostgreSQL 13+ and H2 2.x only, but DB_URL is '"
                    + url.replaceAll("(?i)password=[^;&]*", "password=***") + "'.");
        }
        boolean requireTls = Boolean.parseBoolean(event.getEnvironment().getProperty("admin.security.require-db-tls", "false"));
        if (requireTls && lower.startsWith("jdbc:postgresql:")
                && !lower.matches(".*[?&]sslmode=(require|verify-ca|verify-full).*")) {
            throw new IllegalStateException("ADMIN_REQUIRE_DB_TLS=true but DB_URL has no sslmode=require / verify-ca / verify-full");
        }
    }
}
