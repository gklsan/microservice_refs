package com.ags.health.hr.admin.services;

import com.ags.health.hr.admin.data.PageResponse;
import com.ags.health.hr.admin.data.SecretDtos;
import com.ags.health.hr.admin.enums.SecretAccessAction;
import com.ags.health.hr.admin.security.CorrelationIdFilter;
import com.ags.health.hr.admin.security.CurrentUser;
import com.ags.health.hr.admin.security.SecurityUtils;
import lombok.RequiredArgsConstructor;
import org.slf4j.MDC;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

@Service
@RequiredArgsConstructor
public class SecretAccessLogService {

    public static final String SUCCESS = "SUCCESS";
    public static final String DENIED = "DENIED";

    private static final RowMapper<SecretDtos.AccessLogEntry> ROW = (rs, i) -> {
        Timestamp at = rs.getTimestamp("occurred_at");
        return new SecretDtos.AccessLogEntry(rs.getObject("id", UUID.class), rs.getString("secret_name"),
                rs.getString("action"), rs.getString("outcome"), rs.getString("actor_id"), rs.getString("actor_email"),
                rs.getString("caller_service"), rs.getString("reason"), rs.getString("client_ip"),
                rs.getString("correlation_id"), at == null ? null : at.toInstant());
    };

    private final JdbcTemplate jdbc;

    @Transactional(propagation = Propagation.REQUIRES_NEW)
    public void record(String secretName, SecretAccessAction action, String outcome, String callerService, String reason) {
        CurrentUser actor = SecurityUtils.currentUser().orElse(null);
        jdbc.update("INSERT INTO adm_secret_access_log (id, secret_name, action, outcome, actor_id, actor_email, caller_service, "
                        + "reason, client_ip, correlation_id, occurred_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
                UUID.randomUUID(), secretName, action.name(), outcome,
                actor == null ? null : actor.userId(), actor == null || actor.isSystem() ? null : actor.email(),
                callerService, truncate(reason, 500), clientIp(), MDC.get(CorrelationIdFilter.MDC_KEY),
                Timestamp.from(java.time.Instant.now()));
    }

    @Transactional(readOnly = true)
    public PageResponse<SecretDtos.AccessLogEntry> find(String secretName, Pageable pageable) {
        List<Object> args = new ArrayList<>();
        String where = "";
        if (secretName != null) {
            where = " WHERE secret_name = ?";
            args.add(secretName);
        }
        Long total = jdbc.queryForObject("SELECT count(*) FROM adm_secret_access_log" + where, Long.class, args.toArray());
        List<Object> pageArgs = new ArrayList<>(args);
        pageArgs.add(pageable.getPageSize());
        pageArgs.add(pageable.getOffset());
        List<SecretDtos.AccessLogEntry> rows = jdbc.query("SELECT id, secret_name, action, outcome, actor_id, actor_email, "
                        + "caller_service, reason, client_ip, correlation_id, occurred_at FROM adm_secret_access_log" + where
                        + " ORDER BY occurred_at DESC, id LIMIT ? OFFSET ?", ROW, pageArgs.toArray());
        return PageResponse.of(new PageImpl<>(rows, pageable, total == null ? 0 : total));
    }

    private static String truncate(String s, int max) {
        return s == null || s.length() <= max ? s : s.substring(0, max);
    }

    private static String clientIp() {
        if (RequestContextHolder.getRequestAttributes() instanceof ServletRequestAttributes attrs) {
            return attrs.getRequest().getRemoteAddr();
        }
        return null;
    }
}
