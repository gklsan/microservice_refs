package com.ags.health.hr.admin.secrets;

import com.ags.health.hr.admin.exceptions.APIException;
import org.springframework.http.HttpStatus;

import javax.crypto.spec.SecretKeySpec;
import java.util.Base64;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;

public class LocalKeyEncryptionKeyProvider implements KeyEncryptionKeyProvider {

    private final Map<String, Kek> keys;
    private final String activeId;

    public LocalKeyEncryptionKeyProvider(String masterKeys, String activeKeyId) {
        Map<String, Kek> parsed = new LinkedHashMap<>();
        if (masterKeys != null && !masterKeys.isBlank()) {
            for (String entry : masterKeys.split(",")) {
                String trimmed = entry.trim();
                if (trimmed.isEmpty()) {
                    continue;
                }
                int sep = trimmed.indexOf(':');
                if (sep <= 0 || sep == trimmed.length() - 1) {
                    throw new IllegalStateException("SECRETS_MASTER_KEYS entries must look like keyId:base64Key");
                }
                String id = trimmed.substring(0, sep).trim();
                byte[] raw;
                try {
                    raw = Base64.getDecoder().decode(trimmed.substring(sep + 1).trim());
                } catch (IllegalArgumentException e) {
                    throw new IllegalStateException("Master key " + id + " is not valid Base64", e);
                }
                if (raw.length != 32) {
                    throw new IllegalStateException("Master key " + id + " must be 32 bytes (AES-256), got " + raw.length);
                }
                if (parsed.put(id, new Kek(id, new SecretKeySpec(raw, "AES"))) != null) {
                    throw new IllegalStateException("Master key id " + id + " is listed twice");
                }
            }
        }
        this.keys = Collections.unmodifiableMap(parsed);
        if (!keys.isEmpty()) {
            String chosen = activeKeyId == null || activeKeyId.isBlank() ? null : activeKeyId.trim();
            if (chosen == null) {
                throw new IllegalStateException("SECRETS_ACTIVE_KEY_ID must name one of the SECRETS_MASTER_KEYS ids");
            }
            if (!keys.containsKey(chosen)) {
                throw new IllegalStateException("SECRETS_ACTIVE_KEY_ID " + chosen + " is not in SECRETS_MASTER_KEYS");
            }
            this.activeId = chosen;
        } else {
            this.activeId = null;
        }
    }

    @Override
    public boolean isConfigured() {
        return activeId != null;
    }

    @Override
    public Kek active() {
        if (activeId == null) {
            throw notConfigured();
        }
        return keys.get(activeId);
    }

    @Override
    public Kek byId(String id) {
        Kek kek = id == null ? null : keys.get(id);
        if (kek == null) {
            throw new APIException(HttpStatus.INTERNAL_SERVER_ERROR, "SECRET_KEY_MISSING",
                    "Master key " + id + " is no longer configured. Add it back to SECRETS_MASTER_KEYS and rotate.");
        }
        return kek;
    }

    private static APIException notConfigured() {
        return new APIException(HttpStatus.SERVICE_UNAVAILABLE, "SECRET_STORE_NOT_CONFIGURED",
                "The secret store has no master key. Set SECRETS_MASTER_KEYS and SECRETS_ACTIVE_KEY_ID.");
    }
}
