package com.ags.health.hr.admin.entities;

import com.ags.health.hr.admin.enums.SecretBackendType;
import com.ags.health.hr.admin.secrets.StoredSecret;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.Duration;
import java.time.Instant;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;
import java.util.stream.Collectors;

@Entity
@Table(name = "adm_secret")
@Getter
@Setter
@NoArgsConstructor
public class Secret extends CommonEntity {

    @Id
    private String name;

    @Column(nullable = false)
    private String integration;

    private String description;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private SecretBackendType backend = SecretBackendType.DB;

    @Column(name = "external_ref")
    private String externalRef;

    private String ciphertext;

    @Column(name = "wrapped_dek")
    private String wrappedDek;

    @Column(name = "kek_id")
    private String kekId;

    @Column(name = "value_hint")
    private String valueHint;

    @Column(name = "allowed_services")
    private String allowedServices;

    @Column(name = "rotation_days")
    private Integer rotationDays;

    @Column(name = "last_rotated_at")
    private Instant lastRotatedAt;

    @Column(nullable = false)
    private boolean active = true;

    public StoredSecret stored() {
        return new StoredSecret(ciphertext, wrappedDek, kekId, externalRef);
    }

    public void apply(StoredSecret s) {
        this.ciphertext = s.ciphertext();
        this.wrappedDek = s.wrappedDek();
        this.kekId = s.kekId();
        this.externalRef = s.externalRef();
    }

    public List<String> allowedServiceList() {
        if (allowedServices == null || allowedServices.isBlank()) {
            return List.of();
        }
        return Arrays.stream(allowedServices.split(",")).map(String::trim).filter(v -> !v.isEmpty()).sorted().toList();
    }

    public void setAllowedServiceList(Collection<String> services) {
        this.allowedServices = services == null ? null
                : services.stream().map(String::trim).filter(v -> !v.isEmpty()).distinct().sorted()
                .collect(Collectors.joining(","));
    }

    public boolean isRotationDue(Instant now) {
        if (rotationDays == null || rotationDays <= 0) {
            return false;
        }
        Instant base = lastRotatedAt != null ? lastRotatedAt : getCreatedDate();
        return base != null && base.plus(Duration.ofDays(rotationDays)).isBefore(now);
    }
}
