package com.ags.health.hr.admin.data;

import com.ags.health.hr.admin.entities.ApprovalFlow;
import com.ags.health.hr.admin.entities.ApprovalLevel;
import com.ags.health.hr.admin.enums.ApproverType;
import jakarta.validation.Valid;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;

import java.time.Instant;
import java.time.LocalDate;
import java.util.List;
import java.util.UUID;

public final class ApprovalDtos {

    public static final String FLOW_CODE = "[A-Z][A-Z0-9_]{2,59}";
    public static final String ROLE_CODE = "[A-Z][A-Z0-9_]{1,49}";

    private ApprovalDtos() {
    }

    public record LevelItem(@Min(1) @Max(10) int levelNo,
                            @NotBlank @Size(max = 100) String name,
                            @NotNull ApproverType approverType,
                            @Size(max = 100) String approverValue,
                            @Pattern(regexp = ROLE_CODE) String fallbackRole,
                            @Min(1) @Max(10) Integer minApprovals,
                            @Min(1) @Max(720) Integer slaHours) {

        public static LevelItem of(ApprovalLevel l) {
            return new LevelItem(l.levelNo(), l.name(), l.approverType(), l.approverValue(), l.fallbackRole(),
                    l.minApprovals(), l.slaHours());
        }
    }

    public record CreateFlow(@NotBlank @Pattern(regexp = FLOW_CODE) String code,
                             @NotBlank @Size(max = 150) String name,
                             @Size(max = 500) String description,
                             @NotNull @Size(min = 1, max = 10) List<@Valid @NotNull LevelItem> levels) {
    }

    public record UpdateFlow(@NotBlank @Size(max = 150) String name,
                             @Size(max = 500) String description,
                             @NotNull Boolean active,
                             @NotNull @Size(min = 1, max = 10) List<@Valid @NotNull LevelItem> levels,
                             Long version) {
    }

    public record FlowView(String code, String name, String description, boolean active, List<LevelItem> levels,
                           Instant updatedDate, String updatedBy, Long version) {

        public static FlowView of(ApprovalFlow f) {
            return new FlowView(f.getCode(), f.getName(), f.getDescription(), f.isActive(),
                    f.orderedLevels().stream().map(LevelItem::of).toList(),
                    f.getUpdatedDate() != null ? f.getUpdatedDate() : f.getCreatedDate(),
                    f.getUpdatedBy() != null ? f.getUpdatedBy() : f.getCreatedBy(), f.getVersion());
        }
    }

    public record AssignmentRequest(@Pattern(regexp = FLOW_CODE) String flowCode,
                                    @Min(1) @Max(10) int levelNo,
                                    @Size(max = 100) String lob,
                                    @Size(max = 100) String location,
                                    @NotNull UUID approverId,
                                    UUID delegateId,
                                    LocalDate validFrom,
                                    LocalDate validTo,
                                    Boolean active,
                                    Long version) {
    }

    public record AssignmentView(UUID id, String flowCode, int levelNo, String lob, String location,
                                 UUID approverId, String approverName, String approverEmail,
                                 UUID delegateId, String delegateName,
                                 LocalDate validFrom, LocalDate validTo, boolean active, Long version) {
    }

    public record ApproverRef(UUID adminUserId, String smartieUserId, String email, String fullName, boolean delegate) {
    }

    public record ResolvedLevel(int levelNo, String name, ApproverType approverType, int minApprovals, Integer slaHours,
                                boolean fallbackUsed, boolean unresolved, List<ApproverRef> approvers) {
    }

    public record Resolution(String flowCode, String flowName, boolean active, UUID requesterAdminId,
                             String requesterEmail, String lob, String location, List<ResolvedLevel> levels) {
    }

    public record CanApprove(boolean allowed, String reason, int levelNo, int totalLevels, int minApprovals) {
    }
}
