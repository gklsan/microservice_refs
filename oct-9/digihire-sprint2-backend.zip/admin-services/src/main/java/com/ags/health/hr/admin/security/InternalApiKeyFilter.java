package com.ags.health.hr.admin.security;

import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.filter.OncePerRequestFilter;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Service-to-service calls (other services asking "what can this user do?") send X-Internal-Key.
 * A match grants ROLE_INTERNAL only, which is all /internal/** accepts. Constant-time comparison.
 */
public class InternalApiKeyFilter extends OncePerRequestFilter {

    public static final String HEADER = "X-Internal-Key";
    public static final String CALLER_HEADER = "X-Caller-Service";
    public static final String SERVICE_AUTHORITY_PREFIX = "SERVICE:";

    private final byte[] expected;
    private final Map<String, byte[]> serviceKeys;

    public InternalApiKeyFilter(String internalApiKey) {
        this(internalApiKey, null);
    }

    public InternalApiKeyFilter(String internalApiKey, String serviceKeys) {
        this.expected = internalApiKey == null || internalApiKey.isBlank()
                ? null : internalApiKey.getBytes(StandardCharsets.UTF_8);
        this.serviceKeys = parse(serviceKeys);
    }

    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain chain)
            throws ServletException, IOException {
        String provided = request.getHeader(HEADER);
        if (provided != null) {
            byte[] given = provided.getBytes(StandardCharsets.UTF_8);
            String verifiedService = null;
            for (Map.Entry<String, byte[]> e : serviceKeys.entrySet()) {
                if (MessageDigest.isEqual(e.getValue(), given)) {
                    verifiedService = e.getKey();
                }
            }
            List<GrantedAuthority> authorities = new ArrayList<>();
            String caller = null;
            if (verifiedService != null) {
                caller = verifiedService;
                authorities.add(new SimpleGrantedAuthority("ROLE_INTERNAL"));
                authorities.add(new SimpleGrantedAuthority(SERVICE_AUTHORITY_PREFIX + verifiedService));
            } else if (expected != null && MessageDigest.isEqual(expected, given)) {
                String declared = request.getHeader(CALLER_HEADER);
                caller = declared == null || declared.isBlank() ? "internal" : declared.trim();
                authorities.add(new SimpleGrantedAuthority("ROLE_INTERNAL"));
            }
            if (!authorities.isEmpty()) {
                SecurityContextHolder.getContext().setAuthentication(
                        new SmartieAuthentication(CurrentUser.system(caller), authorities));
            }
        }
        chain.doFilter(request, response);
    }

    private static Map<String, byte[]> parse(String spec) {
        Map<String, byte[]> keys = new LinkedHashMap<>();
        if (spec == null || spec.isBlank()) {
            return Collections.emptyMap();
        }
        for (String entry : spec.split(",")) {
            String trimmed = entry.trim();
            if (trimmed.isEmpty()) {
                continue;
            }
            int sep = trimmed.indexOf('=');
            if (sep <= 0 || sep == trimmed.length() - 1) {
                throw new IllegalStateException("INTERNAL_SERVICE_KEYS entries must look like service-name=key");
            }
            String service = trimmed.substring(0, sep).trim();
            String key = trimmed.substring(sep + 1).trim();
            if (key.length() < 24) {
                throw new IllegalStateException("INTERNAL_SERVICE_KEYS key for " + service + " must be at least 24 characters");
            }
            keys.put(service, key.getBytes(StandardCharsets.UTF_8));
        }
        return Collections.unmodifiableMap(keys);
    }
}
