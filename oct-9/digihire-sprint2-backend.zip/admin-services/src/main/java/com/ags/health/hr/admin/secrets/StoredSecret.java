package com.ags.health.hr.admin.secrets;

public record StoredSecret(String ciphertext, String wrappedDek, String kekId, String externalRef) {

    public static StoredSecret empty() {
        return new StoredSecret(null, null, null, null);
    }
}
