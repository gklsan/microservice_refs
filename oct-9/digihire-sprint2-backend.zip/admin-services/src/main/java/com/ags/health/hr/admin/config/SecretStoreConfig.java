package com.ags.health.hr.admin.config;

import com.ags.health.hr.admin.enums.SecretBackendType;
import com.ags.health.hr.admin.secrets.AwsSecretsManagerSecretBackend;
import com.ags.health.hr.admin.secrets.DbEnvelopeSecretBackend;
import com.ags.health.hr.admin.secrets.EnvelopeCrypto;
import com.ags.health.hr.admin.secrets.KeyEncryptionKeyProvider;
import com.ags.health.hr.admin.secrets.LocalKeyEncryptionKeyProvider;
import com.ags.health.hr.admin.secrets.SecretBackend;
import com.ags.health.hr.admin.secrets.SecretBackends;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.List;
import java.util.Locale;

@Configuration
public class SecretStoreConfig {

    @Bean
    @ConditionalOnMissingBean(KeyEncryptionKeyProvider.class)
    public KeyEncryptionKeyProvider keyEncryptionKeyProvider(AdminProperties props) {
        return new LocalKeyEncryptionKeyProvider(props.getSecrets().getMasterKeys(), props.getSecrets().getActiveKeyId());
    }

    @Bean
    public EnvelopeCrypto envelopeCrypto(KeyEncryptionKeyProvider keks) {
        return new EnvelopeCrypto(keks);
    }

    @Bean
    public DbEnvelopeSecretBackend dbEnvelopeSecretBackend(EnvelopeCrypto crypto) {
        return new DbEnvelopeSecretBackend(crypto);
    }

    @Bean(destroyMethod = "close")
    @ConditionalOnProperty(prefix = "admin.secrets.aws", name = "enabled", havingValue = "true")
    public AwsSecretsManagerSecretBackend awsSecretsManagerSecretBackend(AdminProperties props) {
        return new AwsSecretsManagerSecretBackend(props.getSecrets().getAws().getRegion(), props.getSecrets().getAws().getPrefix());
    }

    @Bean
    public SecretBackends secretBackends(List<SecretBackend> backends, AdminProperties props) {
        String configured = props.getSecrets().getDefaultBackend();
        SecretBackendType type = configured == null || configured.isBlank()
                ? SecretBackendType.DB : SecretBackendType.valueOf(configured.trim().toUpperCase(Locale.ROOT));
        if (backends.stream().noneMatch(b -> b.type() == type)) {
            throw new IllegalStateException("SECRETS_DEFAULT_BACKEND=" + type + " but that backend is not enabled");
        }
        return new SecretBackends(backends, type);
    }
}
