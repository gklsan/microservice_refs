package com.ags.health.hr.admin.secrets;

import com.ags.health.hr.admin.enums.SecretBackendType;
import com.ags.health.hr.admin.exceptions.APIException;
import org.springframework.http.HttpStatus;
import software.amazon.awssdk.core.exception.SdkException;
import software.amazon.awssdk.regions.Region;
import software.amazon.awssdk.services.secretsmanager.SecretsManagerClient;
import software.amazon.awssdk.services.secretsmanager.model.CreateSecretRequest;
import software.amazon.awssdk.services.secretsmanager.model.GetSecretValueRequest;
import software.amazon.awssdk.services.secretsmanager.model.PutSecretValueRequest;
import software.amazon.awssdk.services.secretsmanager.model.ResourceExistsException;

public class AwsSecretsManagerSecretBackend implements SecretBackend, AutoCloseable {

    private final SecretsManagerClient client;
    private final String prefix;

    public AwsSecretsManagerSecretBackend(String region, String prefix) {
        this(SecretsManagerClient.builder().region(Region.of(region)).build(), prefix);
    }

    public AwsSecretsManagerSecretBackend(SecretsManagerClient client, String prefix) {
        this.client = client;
        this.prefix = prefix == null ? "" : prefix;
    }

    @Override
    public SecretBackendType type() {
        return SecretBackendType.AWS;
    }

    @Override
    public StoredSecret store(String name, String value, StoredSecret current) {
        try {
            if (current != null && current.externalRef() != null) {
                client.putSecretValue(PutSecretValueRequest.builder().secretId(current.externalRef()).secretString(value).build());
                return new StoredSecret(null, null, null, current.externalRef());
            }
            String id = prefix + name;
            try {
                client.createSecret(CreateSecretRequest.builder().name(id).secretString(value).build());
            } catch (ResourceExistsException exists) {
                client.putSecretValue(PutSecretValueRequest.builder().secretId(id).secretString(value).build());
            }
            return new StoredSecret(null, null, null, id);
        } catch (SdkException e) {
            throw unavailable(e);
        }
    }

    @Override
    public String load(String name, StoredSecret stored) {
        try {
            return client.getSecretValue(GetSecretValueRequest.builder().secretId(stored.externalRef()).build()).secretString();
        } catch (SdkException e) {
            throw unavailable(e);
        }
    }

    @Override
    public void close() {
        client.close();
    }

    private static APIException unavailable(SdkException e) {
        return new APIException(HttpStatus.BAD_GATEWAY, "SECRET_BACKEND_UNAVAILABLE",
                "AWS Secrets Manager call failed: " + e.getClass().getSimpleName());
    }
}
