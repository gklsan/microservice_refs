package com.ags.health.hr.admin.controllers;

import com.ags.health.hr.admin.data.PageResponse;
import com.ags.health.hr.admin.data.SecretDtos;
import com.ags.health.hr.admin.services.SecretAccessLogService;
import com.ags.health.hr.admin.services.SecretService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.PageRequest;
import org.springframework.http.CacheControl;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/admin/secrets")
@RequiredArgsConstructor
public class SecretController {

    private final SecretService service;
    private final SecretAccessLogService accessLog;

    @GetMapping
    @PreAuthorize("hasAuthority('SECRET:VIEW')")
    public List<SecretDtos.View> list(@RequestParam(required = false) String integration) {
        return service.list(integration);
    }

    @GetMapping("/{name}")
    @PreAuthorize("hasAuthority('SECRET:VIEW')")
    public SecretDtos.View get(@PathVariable String name) {
        return service.get(name);
    }

    @PostMapping
    @PreAuthorize("hasRole('SUPER_ADMIN') and hasAuthority('SECRET:MANAGE')")
    public ResponseEntity<SecretDtos.View> create(@Valid @RequestBody SecretDtos.Create req) {
        return new ResponseEntity<>(service.create(req), HttpStatus.CREATED);
    }

    @PutMapping("/{name}")
    @PreAuthorize("hasRole('SUPER_ADMIN') and hasAuthority('SECRET:MANAGE')")
    public SecretDtos.View update(@PathVariable String name, @Valid @RequestBody SecretDtos.Update req) {
        return service.update(name, req);
    }

    @PostMapping("/{name}/reveal")
    @PreAuthorize("hasRole('SUPER_ADMIN') and hasAuthority('SECRET:REVEAL')")
    public ResponseEntity<SecretDtos.Revealed> reveal(@PathVariable String name, @Valid @RequestBody SecretDtos.Reveal req) {
        return ResponseEntity.ok().cacheControl(CacheControl.noStore()).body(service.reveal(name, req.reason()));
    }

    @PostMapping("/rotate-master-key")
    @PreAuthorize("hasRole('SUPER_ADMIN') and hasAuthority('SECRET:MANAGE')")
    public SecretDtos.RotationResult rotateMasterKey() {
        return service.rotateMasterKey();
    }

    @GetMapping("/access-log")
    @PreAuthorize("hasAuthority('SECRET:VIEW')")
    public PageResponse<SecretDtos.AccessLogEntry> accessLog(@RequestParam(defaultValue = "0") int page,
                                                             @RequestParam(defaultValue = "50") int size) {
        return accessLog.find(null, PageRequest.of(Math.max(page, 0), Math.min(Math.max(size, 1), 200)));
    }

    @GetMapping("/{name}/access-log")
    @PreAuthorize("hasAuthority('SECRET:VIEW')")
    public PageResponse<SecretDtos.AccessLogEntry> accessLog(@PathVariable String name,
                                                             @RequestParam(defaultValue = "0") int page,
                                                             @RequestParam(defaultValue = "50") int size) {
        return accessLog.find(name, PageRequest.of(Math.max(page, 0), Math.min(Math.max(size, 1), 200)));
    }
}
