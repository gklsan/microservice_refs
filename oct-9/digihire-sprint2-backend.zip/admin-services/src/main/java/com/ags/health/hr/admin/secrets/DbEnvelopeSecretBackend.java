package com.ags.health.hr.admin.secrets;

import com.ags.health.hr.admin.enums.SecretBackendType;

public class DbEnvelopeSecretBackend implements SecretBackend {

    private final EnvelopeCrypto crypto;

    public DbEnvelopeSecretBackend(EnvelopeCrypto crypto) {
        this.crypto = crypto;
    }

    @Override
    public SecretBackendType type() {
        return SecretBackendType.DB;
    }

    @Override
    public StoredSecret store(String name, String value, StoredSecret current) {
        return crypto.seal(name, value);
    }

    @Override
    public String load(String name, StoredSecret stored) {
        return crypto.open(name, stored);
    }

    @Override
    public boolean supportsRewrap() {
        return true;
    }

    @Override
    public StoredSecret rewrap(String name, StoredSecret stored) {
        return crypto.rewrap(name, stored);
    }
}
