package com.ags.health.hr.admin.entities;

import com.ags.health.hr.admin.enums.ApproverType;
import jakarta.persistence.Column;
import jakarta.persistence.Embeddable;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;

@Embeddable
public record ApprovalLevel(@Column(name = "level_no", nullable = false) int levelNo,
                            @Column(name = "name", nullable = false) String name,
                            @Enumerated(EnumType.STRING) @Column(name = "approver_type", nullable = false) ApproverType approverType,
                            @Column(name = "approver_value") String approverValue,
                            @Column(name = "fallback_role") String fallbackRole,
                            @Column(name = "min_approvals", nullable = false) int minApprovals,
                            @Column(name = "sla_hours") Integer slaHours) {
}
