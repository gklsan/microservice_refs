package com.ags.health.hr.admin.services;

import com.ags.health.hr.admin.data.ApprovalDtos;
import com.ags.health.hr.admin.entities.AppUser;
import com.ags.health.hr.admin.entities.ApprovalFlow;
import com.ags.health.hr.admin.entities.ApprovalLevel;
import com.ags.health.hr.admin.entities.ApproverAssignment;
import com.ags.health.hr.admin.entities.Role;
import com.ags.health.hr.admin.enums.ScopeDimension;
import com.ags.health.hr.admin.enums.UserStatus;
import com.ags.health.hr.admin.exceptions.APIException;
import com.ags.health.hr.admin.resources.AppUserRepository;
import com.ags.health.hr.admin.resources.ApprovalFlowRepository;
import com.ags.health.hr.admin.resources.ApproverAssignmentRepository;
import com.ags.health.hr.admin.resources.RoleRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import java.time.LocalDate;
import java.time.ZoneOffset;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;

@Service
@Transactional(readOnly = true)
@RequiredArgsConstructor
public class ApprovalResolverService {

    private static final int MAX_MANAGER_DEPTH = 5;

    private final ApprovalFlowRepository flows;
    private final ApproverAssignmentRepository assignments;
    private final AppUserRepository users;
    private final RoleRepository roles;

    public ApprovalDtos.Resolution resolve(String flowCode, String requesterId, String requesterEmail,
                                           String lob, String location) {
        ApprovalFlow flow = flow(flowCode);
        AppUser requester = findUser(requesterId, requesterEmail).orElse(null);
        String l = norm(lob);
        String loc = norm(location);
        LocalDate today = LocalDate.now(ZoneOffset.UTC);
        List<ApprovalDtos.ResolvedLevel> levels = flow.orderedLevels().stream()
                .map(level -> resolveLevel(flow.getCode(), level, requester, l, loc, today))
                .toList();
        return new ApprovalDtos.Resolution(flow.getCode(), flow.getName(), flow.isActive(),
                requester == null ? null : requester.getId(),
                requester != null ? requester.getEmail() : AppUser.normalizeEmail(requesterEmail), l, loc, levels);
    }

    public ApprovalDtos.CanApprove canApprove(String flowCode, int levelNo, String approverId, String approverEmail,
                                              String requesterId, String requesterEmail, String lob, String location) {
        ApprovalDtos.Resolution r = resolve(flowCode, requesterId, requesterEmail, lob, location);
        int total = r.levels().size();
        if (!r.active()) {
            return new ApprovalDtos.CanApprove(false, "FLOW_INACTIVE", levelNo, total, 0);
        }
        ApprovalDtos.ResolvedLevel level = r.levels().stream().filter(x -> x.levelNo() == levelNo).findFirst().orElse(null);
        if (level == null) {
            return new ApprovalDtos.CanApprove(false, "UNKNOWN_LEVEL", levelNo, total, 0);
        }
        AppUser approver = findUser(approverId, approverEmail).orElse(null);
        if (approver == null) {
            return new ApprovalDtos.CanApprove(false, "APPROVER_UNKNOWN", levelNo, total, level.minApprovals());
        }
        if (!approver.isActive()) {
            return new ApprovalDtos.CanApprove(false, "APPROVER_INACTIVE", levelNo, total, level.minApprovals());
        }
        if (approver.getId().equals(r.requesterAdminId())
                || (r.requesterEmail() != null && r.requesterEmail().equalsIgnoreCase(approver.getEmail()))) {
            return new ApprovalDtos.CanApprove(false, "SELF_APPROVAL", levelNo, total, level.minApprovals());
        }
        boolean listed = level.approvers().stream().anyMatch(a -> a.adminUserId().equals(approver.getId()));
        String reason = listed ? "IN_APPROVER_LIST" : level.unresolved() ? "LEVEL_UNRESOLVED" : "NOT_AN_APPROVER";
        return new ApprovalDtos.CanApprove(listed, reason, levelNo, total, level.minApprovals());
    }

    ApprovalFlow flow(String code) {
        String c = code == null ? null : code.trim().toUpperCase(Locale.ROOT);
        return flows.findById(c).orElseThrow(() -> APIException.notFound("Approval flow", code));
    }

    private ApprovalDtos.ResolvedLevel resolveLevel(String flowCode, ApprovalLevel level, AppUser requester,
                                                    String lob, String location, LocalDate today) {
        Map<UUID, ApprovalDtos.ApproverRef> found = new LinkedHashMap<>();
        switch (level.approverType()) {
            case ROLE -> roleUsers(level.approverValue(), lob, location).forEach(u -> add(found, u, false));
            case USER -> parseUuid(level.approverValue()).flatMap(users::findById).filter(AppUser::isActive)
                    .ifPresent(u -> add(found, u, false));
            case REPORTING_MANAGER -> manager(requester, depth(level.approverValue())).ifPresent(u -> add(found, u, false));
            case HIERARCHY -> hierarchy(flowCode, level.levelNo(), lob, location, today, found);
        }
        if (requester != null) {
            found.remove(requester.getId());
        }
        boolean fallbackUsed = false;
        if (found.isEmpty() && StringUtils.hasText(level.fallbackRole())) {
            roleUsers(level.fallbackRole(), lob, location).forEach(u -> add(found, u, false));
            if (requester != null) {
                found.remove(requester.getId());
            }
            fallbackUsed = !found.isEmpty();
        }
        return new ApprovalDtos.ResolvedLevel(level.levelNo(), level.name(), level.approverType(), level.minApprovals(),
                level.slaHours(), fallbackUsed, found.isEmpty(), new ArrayList<>(found.values()));
    }

    private List<AppUser> roleUsers(String roleCode, String lob, String location) {
        if (!StringUtils.hasText(roleCode)) {
            return List.of();
        }
        String code = roleCode.trim().toUpperCase(Locale.ROOT);
        boolean active = roles.findByCode(code).map(Role::isActive).orElse(false);
        if (!active) {
            return List.of();
        }
        return users.findByRoleAndStatus(code, UserStatus.ACTIVE).stream()
                .filter(u -> inScope(u.scopeValues(ScopeDimension.LOB), lob))
                .filter(u -> inScope(u.scopeValues(ScopeDimension.LOCATION), location))
                .toList();
    }

    private Optional<AppUser> manager(AppUser requester, int depth) {
        AppUser current = requester;
        for (int i = 0; i < depth; i++) {
            if (current == null || current.getManagerId() == null) {
                return Optional.empty();
            }
            current = users.findById(current.getManagerId()).orElse(null);
        }
        return Optional.ofNullable(current).filter(AppUser::isActive);
    }

    private void hierarchy(String flowCode, int levelNo, String lob, String location, LocalDate today,
                           Map<UUID, ApprovalDtos.ApproverRef> found) {
        List<ApproverAssignment> candidates = assignments.findByLevelNoAndActiveTrue(levelNo).stream()
                .filter(a -> a.isValidOn(today))
                .filter(a -> a.getLob() == null || a.getLob().equalsIgnoreCase(lob == null ? "" : lob))
                .filter(a -> a.getLocation() == null || a.getLocation().equalsIgnoreCase(location == null ? "" : location))
                .toList();
        List<ApproverAssignment> specific = candidates.stream().filter(a -> flowCode.equals(a.getFlowCode())).toList();
        List<ApproverAssignment> pool = !specific.isEmpty() ? specific
                : candidates.stream().filter(a -> a.getFlowCode() == null).toList();
        int best = pool.stream().mapToInt(ApprovalResolverService::specificity).max().orElse(-1);
        for (ApproverAssignment a : pool) {
            if (specificity(a) != best) {
                continue;
            }
            users.findById(a.getApproverId()).filter(AppUser::isActive).ifPresent(u -> add(found, u, false));
            if (a.getDelegateId() != null) {
                users.findById(a.getDelegateId()).filter(AppUser::isActive).ifPresent(u -> add(found, u, true));
            }
        }
    }

    private static int specificity(ApproverAssignment a) {
        return (a.getLob() != null ? 2 : 0) + (a.getLocation() != null ? 1 : 0);
    }

    private static void add(Map<UUID, ApprovalDtos.ApproverRef> found, AppUser u, boolean delegate) {
        found.putIfAbsent(u.getId(), new ApprovalDtos.ApproverRef(u.getId(), u.getSmartieUserId(), u.getEmail(),
                u.getFullName(), delegate));
    }

    private static boolean inScope(Set<String> values, String wanted) {
        return wanted == null || values.isEmpty() || values.stream().anyMatch(v -> v.equalsIgnoreCase(wanted));
    }

    private Optional<AppUser> findUser(String smartieUserId, String email) {
        Optional<AppUser> u = StringUtils.hasText(smartieUserId)
                ? users.findWithAccessBySmartieUserId(smartieUserId.trim()) : Optional.empty();
        if (u.isEmpty() && StringUtils.hasText(email)) {
            u = users.findWithAccessByEmail(AppUser.normalizeEmail(email));
        }
        return u;
    }

    static int depth(String value) {
        if (!StringUtils.hasText(value)) {
            return 1;
        }
        try {
            return Math.max(1, Math.min(MAX_MANAGER_DEPTH, Integer.parseInt(value.trim())));
        } catch (NumberFormatException e) {
            return 1;
        }
    }

    private static Optional<UUID> parseUuid(String value) {
        try {
            return value == null ? Optional.empty() : Optional.of(UUID.fromString(value.trim()));
        } catch (IllegalArgumentException e) {
            return Optional.empty();
        }
    }

    static String norm(String v) {
        return StringUtils.hasText(v) ? v.trim().toUpperCase(Locale.ROOT) : null;
    }
}
