package com.ags.health.hr.admin.controllers;

import com.ags.health.hr.admin.data.ConfigDtos;
import com.ags.health.hr.admin.services.ConfigService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/** Enterprise configuration. Tracker #32: only an active SUPER_ADMIN (BRD 4.1 "Only Admin users may modify ..."). */
@RestController
@RequestMapping("/admin/config")
@RequiredArgsConstructor
public class ConfigController {

    private final ConfigService service;

    @GetMapping
    @PreAuthorize("hasAuthority('CONFIG:VIEW')")
    public List<ConfigDtos.View> list(@RequestParam(required = false) String category) {
        return service.list(category);
    }

    @GetMapping("/{key}")
    @PreAuthorize("hasAuthority('CONFIG:VIEW')")
    public ConfigDtos.View get(@PathVariable String key) {
        return service.get(key);
    }

    @PostMapping
    @PreAuthorize("hasRole('SUPER_ADMIN') and hasAuthority('CONFIG:MANAGE')")
    public ResponseEntity<ConfigDtos.View> create(@Valid @RequestBody ConfigDtos.Create req) {
        return new ResponseEntity<>(service.create(req), HttpStatus.CREATED);
    }

    @PutMapping("/{key}")
    @PreAuthorize("hasRole('SUPER_ADMIN') and hasAuthority('CONFIG:MANAGE')")
    public ConfigDtos.View update(@PathVariable String key, @Valid @RequestBody ConfigDtos.Update req) {
        return service.update(key, req);
    }

    @GetMapping("/{key}/history")
    @PreAuthorize("hasAuthority('CONFIG:VIEW')")
    public List<ConfigDtos.HistoryEntry> history(@PathVariable String key) {
        return service.history(key);
    }
}
