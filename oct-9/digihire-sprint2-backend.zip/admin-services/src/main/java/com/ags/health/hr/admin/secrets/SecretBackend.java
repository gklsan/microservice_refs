package com.ags.health.hr.admin.secrets;

import com.ags.health.hr.admin.enums.SecretBackendType;

public interface SecretBackend {

    SecretBackendType type();

    StoredSecret store(String name, String value, StoredSecret current);

    String load(String name, StoredSecret stored);

    default boolean supportsRewrap() {
        return false;
    }

    default StoredSecret rewrap(String name, StoredSecret stored) {
        return stored;
    }
}
