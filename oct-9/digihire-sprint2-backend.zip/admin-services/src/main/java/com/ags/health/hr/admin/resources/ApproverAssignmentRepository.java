package com.ags.health.hr.admin.resources;

import com.ags.health.hr.admin.entities.ApproverAssignment;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;
import java.util.UUID;

public interface ApproverAssignmentRepository extends JpaRepository<ApproverAssignment, UUID> {

    List<ApproverAssignment> findByLevelNoAndActiveTrue(int levelNo);

    @Query("""
            select a from ApproverAssignment a
            where (:flowCode is null or a.flowCode = :flowCode)
              and (:approverId is null or a.approverId = :approverId or a.delegateId = :approverId)
              and (:lob is null or a.lob = :lob)
              and (:location is null or a.location = :location)
              and (:activeOnly = false or a.active = true)
            order by a.flowCode, a.levelNo, a.lob, a.location
            """)
    List<ApproverAssignment> search(@Param("flowCode") String flowCode, @Param("approverId") UUID approverId,
                                    @Param("lob") String lob, @Param("location") String location,
                                    @Param("activeOnly") boolean activeOnly);
}
