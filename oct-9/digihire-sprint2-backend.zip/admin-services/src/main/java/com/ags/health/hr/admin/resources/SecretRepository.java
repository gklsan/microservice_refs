package com.ags.health.hr.admin.resources;

import com.ags.health.hr.admin.entities.Secret;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface SecretRepository extends JpaRepository<Secret, String> {

    List<Secret> findAllByOrderByIntegrationAscNameAsc();

    List<Secret> findByIntegrationOrderByNameAsc(String integration);
}
