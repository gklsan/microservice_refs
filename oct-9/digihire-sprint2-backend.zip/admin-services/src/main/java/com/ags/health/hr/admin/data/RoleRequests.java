package com.ags.health.hr.admin.data;

import com.ags.health.hr.admin.enums.ScopeLevel;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;

import java.util.List;
import java.util.Map;

/** Role and permission-matrix requests. */
public final class RoleRequests {

    private RoleRequests() {
    }

    /** One matrix cell. conditional = "C", otherwise "A". */
    public record PermissionItem(@NotBlank @Size(max = 80) String code, boolean conditional) {
    }

    public record CreateRole(@NotBlank @Pattern(regexp = "[A-Z][A-Z0-9_]{1,49}") String code,
                             @NotBlank @Size(max = 100) String name,
                             @Size(max = 500) String description,
                             @NotNull ScopeLevel defaultScope,
                             @NotNull List<@Valid @NotNull PermissionItem> permissions,
                             @Pattern(regexp = "[A-Z][A-Z0-9_]{1,49}") String copyFrom) {
    }

    /** Code is immutable. permissions = null keeps the current set; [] removes all. */
    public record UpdateRole(@NotBlank @Size(max = 100) String name,
                             @Size(max = 500) String description,
                             @NotNull ScopeLevel defaultScope,
                             @NotNull Boolean active,
                             List<@Valid @NotNull PermissionItem> permissions,
                             Long version) {
    }

    /** Bulk save of the matrix screen. Only roles present in the map change. */
    public record MatrixUpdate(@NotNull Map<String, List<@Valid @NotNull PermissionItem>> grants) {
    }
}
