package com.ags.health.hr.admin.services;

import com.ags.health.hr.admin.data.RoleRequests;
import com.ags.health.hr.admin.data.RoleResponses;
import com.ags.health.hr.admin.entities.Permission;
import com.ags.health.hr.admin.entities.Role;
import com.ags.health.hr.admin.entities.RolePermission;
import com.ags.health.hr.admin.enums.AuditCategory;
import com.ags.health.hr.admin.exceptions.APIException;
import com.ags.health.hr.admin.resources.PermissionRepository;
import com.ags.health.hr.admin.resources.RoleRepository;
import com.ags.health.hr.admin.utils.RoleCodes;
import lombok.RequiredArgsConstructor;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import java.util.TreeSet;
import java.util.function.Function;
import java.util.stream.Collectors;

/**
 * Roles and the role x permission matrix (BRD 4.1 "Admin should fully control role creation and
 * permission mapping"). Roles are never deleted - they are retired (active = false) and stop granting
 * anything from the next request. Every change is audited with added / removed permissions.
 */
@Service
@Transactional
@RequiredArgsConstructor
public class RoleService {

    private final RoleRepository roles;
    private final PermissionRepository permissions;
    private final JdbcTemplate jdbc;
    private final AuditService audit;

    @Transactional(readOnly = true)
    public List<RoleResponses.RoleView> list(boolean includeInactive) {
        Map<String, Long> counts = userCounts();
        return roles.findAllByOrderByCodeAsc().stream()
                .filter(r -> includeInactive || r.isActive())
                .map(r -> RoleResponses.RoleView.of(r, counts.getOrDefault(r.getCode(), 0L)))
                .toList();
    }

    @Transactional(readOnly = true)
    public RoleResponses.RoleView get(String code) {
        return RoleResponses.RoleView.of(role(code), userCounts().getOrDefault(code, 0L));
    }

    @Transactional(readOnly = true)
    public List<RoleResponses.PermissionView> catalogue() {
        return permissions.findAllByOrderBySortOrderAsc().stream().map(RoleResponses.PermissionView::of).toList();
    }

    public RoleResponses.RoleView create(RoleRequests.CreateRole req) {
        String code = req.code().trim().toUpperCase();
        if (RoleCodes.RESERVED.contains(code)) {
            throw APIException.badRequest("RESERVED_ROLE", "Role code " + code + " is reserved");
        }
        if (roles.findByCode(code).isPresent()) {
            throw APIException.conflict("ROLE_EXISTS", "Role already exists: " + code);
        }
        Role r = Role.create(code, req.name().trim());
        r.setDescription(req.description());
        r.setDefaultScope(req.defaultScope());
        Map<String, Permission> catalogue = catalogueMap();
        List<RoleRequests.PermissionItem> items = new java.util.ArrayList<>(req.permissions());
        if (req.copyFrom() != null) {
            Role source = role(req.copyFrom());
            Set<String> listed = items.stream().map(i -> i.code().trim()).collect(Collectors.toSet());
            source.getPermissions().stream()
                    .filter(p -> !listed.contains(p.permissionCode()))
                    .filter(p -> catalogue.containsKey(p.permissionCode()) && !catalogue.get(p.permissionCode()).isPrivileged())
                    .forEach(p -> items.add(new RoleRequests.PermissionItem(p.permissionCode(), p.conditional())));
        }
        r.setPermissions(toGrants(r, items, catalogue));
        roles.save(r);
        audit.log(AuditCategory.CONFIG_CHANGE, "ROLE_CREATED", "ROLE", code,
                AdminUserService.details("permissions", describe(r.getPermissions()), "defaultScope", r.getDefaultScope(),
                        "copiedFrom", req.copyFrom()));
        return RoleResponses.RoleView.of(r, 0);
    }

    public RoleResponses.RoleView update(String code, RoleRequests.UpdateRole req) {
        Role r = role(code);
        AdminUserService.checkVersion(r.getVersion(), req.version());
        if (RoleCodes.SUPER_ADMIN.equals(r.getCode()) && !req.active()) {
            throw APIException.badRequest("SUPER_ADMIN_ROLE_LOCKED", "The SUPER_ADMIN role can not be retired");
        }
        Set<String> before = describe(r.getPermissions());
        Map<String, Object> meta = AdminUserService.details("nameBefore", r.getName(), "scopeBefore", r.getDefaultScope(),
                "activeBefore", r.isActive());
        r.setName(req.name().trim());
        r.setDescription(req.description());
        r.setDefaultScope(req.defaultScope());
        r.setActive(req.active());
        if (req.permissions() != null) {
            r.setPermissions(toGrants(r, req.permissions(), catalogueMap()));
        }
        Set<String> after = describe(r.getPermissions());
        meta.putAll(AdminUserService.details("name", r.getName(), "defaultScope", r.getDefaultScope(),
                "active", r.isActive(), "added", diff(after, before), "removed", diff(before, after)));
        audit.log(AuditCategory.CONFIG_CHANGE, r.isActive() ? "ROLE_UPDATED" : "ROLE_RETIRED", "ROLE", r.getCode(), meta);
        return RoleResponses.RoleView.of(r, userCounts().getOrDefault(r.getCode(), 0L));
    }

    @Transactional(readOnly = true)
    public RoleResponses.Matrix matrix() {
        Map<String, Long> counts = userCounts();
        List<Role> all = roles.findAllByOrderByCodeAsc();
        Map<String, Map<String, String>> grants = new LinkedHashMap<>();
        for (Role r : all) {
            Map<String, String> cells = new TreeMap<>();
            r.getPermissions().forEach(p -> cells.put(p.permissionCode(), p.conditional() ? "C" : "A"));
            grants.put(r.getCode(), cells);
        }
        return new RoleResponses.Matrix(
                all.stream().map(r -> RoleResponses.RoleView.of(r, counts.getOrDefault(r.getCode(), 0L))).toList(),
                catalogue(), grants);
    }

    /** Matrix screen save: only roles present in the body change; one audit row with the whole diff. */
    public RoleResponses.Matrix updateMatrix(RoleRequests.MatrixUpdate req) {
        Map<String, Permission> catalogue = catalogueMap();
        Map<String, Object> diff = new TreeMap<>();
        req.grants().forEach((roleCode, items) -> {
            Role r = role(roleCode);
            Set<String> before = describe(r.getPermissions());
            r.setPermissions(toGrants(r, items, catalogue));
            Set<String> after = describe(r.getPermissions());
            if (!before.equals(after)) {
                diff.put(roleCode, Map.of("added", diff(after, before), "removed", diff(before, after)));
            }
        });
        if (!diff.isEmpty()) {
            audit.log(AuditCategory.CONFIG_CHANGE, "PERMISSION_MATRIX_UPDATED", "ROLE_MATRIX", "GLOBAL", diff);
        }
        return matrix();
    }

    /** Factory default permission sets, optionally for one object (JOB, CANDIDATE, APPLICATION ...). */
    @Transactional(readOnly = true)
    public Map<String, List<RoleRequests.PermissionItem>> defaults(String objectType) {
        Map<String, List<RoleRequests.PermissionItem>> result = new TreeMap<>();
        String sql = "SELECT role_code, permission_code, conditional FROM adm_default_role_permission"
                + (objectType == null ? "" : " WHERE permission_code LIKE ?") + " ORDER BY role_code, permission_code";
        Object[] args = objectType == null ? new Object[0] : new Object[]{objectType.trim().toUpperCase() + ":%"};
        jdbc.query(sql, (org.springframework.jdbc.core.RowCallbackHandler) rs ->
                result.computeIfAbsent(rs.getString(1), k -> new java.util.ArrayList<>())
                        .add(new RoleRequests.PermissionItem(rs.getString(2), rs.getBoolean(3))), args);
        return result;
    }

    /** Restore a seeded role to the access-matrix defaults. */
    public RoleResponses.RoleView resetToDefaults(String code) {
        Role r = role(code);
        List<RoleRequests.PermissionItem> defaults = defaults(null).get(r.getCode());
        if (defaults == null || defaults.isEmpty()) {
            throw APIException.badRequest("NO_DEFAULTS", "Role " + code + " has no factory default permission set");
        }
        Set<String> before = describe(r.getPermissions());
        r.setPermissions(toGrants(r, defaults, catalogueMap()));
        Set<String> after = describe(r.getPermissions());
        audit.log(AuditCategory.CONFIG_CHANGE, "ROLE_RESET_TO_DEFAULTS", "ROLE", r.getCode(),
                AdminUserService.details("added", diff(after, before), "removed", diff(before, after)));
        return RoleResponses.RoleView.of(r, userCounts().getOrDefault(r.getCode(), 0L));
    }

    // ------------------------------------------------------------------ rules

    /**
     * Validates one role's permission set:
     * unknown code -> 400; privileged permission on a role other than SUPER_ADMIN -> 400;
     * SUPER_ADMIN losing (or making conditional) a locked permission -> 400.
     */
    private static Set<RolePermission> toGrants(Role role, Collection<RoleRequests.PermissionItem> items,
                                                Map<String, Permission> catalogue) {
        Map<String, Boolean> byCode = new HashMap<>();
        for (RoleRequests.PermissionItem item : items) {
            String code = item.code().trim();
            Permission p = catalogue.get(code);
            if (p == null) {
                throw APIException.badRequest("UNKNOWN_PERMISSION", "Unknown permission: " + code);
            }
            if (p.isPrivileged() && !RoleCodes.SUPER_ADMIN.equals(role.getCode())) {
                throw APIException.badRequest("PRIVILEGED_PERMISSION",
                        code + " can only belong to the SUPER_ADMIN role");
            }
            byCode.merge(code, item.conditional(), (a, b) -> a && b);
        }
        if (RoleCodes.SUPER_ADMIN.equals(role.getCode())) {
            Set<String> missing = new TreeSet<>();
            for (String locked : RoleCodes.SUPER_ADMIN_LOCKED) {
                if (!Boolean.FALSE.equals(byCode.get(locked))) {
                    missing.add(locked);
                }
            }
            if (!missing.isEmpty()) {
                throw APIException.badRequest("SUPER_ADMIN_ROLE_LOCKED",
                        "SUPER_ADMIN must keep " + missing + " (unconditional), or nobody could manage users");
            }
        }
        Set<RolePermission> result = new HashSet<>();
        byCode.forEach((code, conditional) -> result.add(new RolePermission(code, conditional)));
        return result;
    }

    private Map<String, Permission> catalogueMap() {
        return permissions.findAll().stream().collect(Collectors.toMap(Permission::getCode, Function.identity()));
    }

    private Role role(String code) {
        return roles.findByCode(code == null ? null : code.trim().toUpperCase())
                .orElseThrow(() -> APIException.notFound("Role", code));
    }

    private Map<String, Long> userCounts() {
        Map<String, Long> counts = new HashMap<>();
        for (Object[] row : roles.countActiveUsersPerRole()) {
            counts.put((String) row[0], ((Number) row[1]).longValue());
        }
        return counts;
    }

    private static Set<String> describe(Collection<RolePermission> grants) {
        return grants.stream().map(g -> g.permissionCode() + (g.conditional() ? " (C)" : ""))
                .collect(Collectors.toCollection(TreeSet::new));
    }

    private static Set<String> diff(Set<String> a, Set<String> b) {
        Set<String> d = new TreeSet<>(a);
        d.removeAll(b);
        return d;
    }
}
