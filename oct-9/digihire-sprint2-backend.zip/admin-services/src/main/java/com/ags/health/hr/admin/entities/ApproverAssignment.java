package com.ags.health.hr.admin.entities;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDate;
import java.util.UUID;

@Entity
@Table(name = "adm_approver_assignment")
@Getter
@Setter
@NoArgsConstructor
public class ApproverAssignment extends CommonEntity {

    @Id
    private UUID id;

    @Column(name = "flow_code")
    private String flowCode;

    @Column(name = "level_no", nullable = false)
    private int levelNo;

    private String lob;

    private String location;

    @Column(name = "approver_id", nullable = false)
    private UUID approverId;

    @Column(name = "delegate_id")
    private UUID delegateId;

    @Column(name = "valid_from")
    private LocalDate validFrom;

    @Column(name = "valid_to")
    private LocalDate validTo;

    @Column(nullable = false)
    private boolean active = true;

    public boolean isValidOn(LocalDate day) {
        return active && (validFrom == null || !day.isBefore(validFrom)) && (validTo == null || !day.isAfter(validTo));
    }
}
