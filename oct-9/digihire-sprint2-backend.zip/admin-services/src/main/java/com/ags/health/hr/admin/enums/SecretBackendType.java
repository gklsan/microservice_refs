package com.ags.health.hr.admin.enums;

public enum SecretBackendType { DB, AWS }
