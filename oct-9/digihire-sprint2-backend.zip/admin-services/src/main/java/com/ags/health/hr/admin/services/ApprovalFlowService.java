package com.ags.health.hr.admin.services;

import com.ags.health.hr.admin.data.ApprovalDtos;
import com.ags.health.hr.admin.entities.AppUser;
import com.ags.health.hr.admin.entities.ApprovalFlow;
import com.ags.health.hr.admin.entities.ApprovalLevel;
import com.ags.health.hr.admin.entities.ApproverAssignment;
import com.ags.health.hr.admin.enums.ApproverType;
import com.ags.health.hr.admin.enums.AuditCategory;
import com.ags.health.hr.admin.exceptions.APIException;
import com.ags.health.hr.admin.resources.AppUserRepository;
import com.ags.health.hr.admin.resources.ApprovalFlowRepository;
import com.ags.health.hr.admin.resources.ApproverAssignmentRepository;
import com.ags.health.hr.admin.resources.RoleRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.function.Function;
import java.util.stream.Collectors;

@Service
@Transactional
@RequiredArgsConstructor
public class ApprovalFlowService {

    private final ApprovalFlowRepository flows;
    private final ApproverAssignmentRepository assignments;
    private final AppUserRepository users;
    private final RoleRepository roles;
    private final ApprovalResolverService resolver;
    private final AuditService audit;

    @Transactional(readOnly = true)
    public List<ApprovalDtos.FlowView> list() {
        return flows.findAllByOrderByCodeAsc().stream().map(ApprovalDtos.FlowView::of).toList();
    }

    @Transactional(readOnly = true)
    public ApprovalDtos.FlowView get(String code) {
        return ApprovalDtos.FlowView.of(resolver.flow(code));
    }

    public ApprovalDtos.FlowView create(ApprovalDtos.CreateFlow req) {
        String code = req.code().trim().toUpperCase(Locale.ROOT);
        if (flows.existsById(code)) {
            throw APIException.conflict("APPROVAL_FLOW_EXISTS", "Approval flow already exists: " + code);
        }
        ApprovalFlow f = new ApprovalFlow();
        f.setCode(code);
        f.setName(req.name().trim());
        f.setDescription(trimToNull(req.description()));
        f.setLevels(levels(req.levels()));
        flows.save(f);
        audit.log(AuditCategory.CONFIG_CHANGE, "APPROVAL_FLOW_CREATED", "APPROVAL_FLOW", code,
                AdminUserService.details("levels", describe(f.orderedLevels())));
        return ApprovalDtos.FlowView.of(f);
    }

    public ApprovalDtos.FlowView update(String code, ApprovalDtos.UpdateFlow req) {
        ApprovalFlow f = resolver.flow(code);
        AdminUserService.checkVersion(f.getVersion(), req.version());
        List<String> before = describe(f.orderedLevels());
        boolean activeBefore = f.isActive();
        f.setName(req.name().trim());
        f.setDescription(trimToNull(req.description()));
        f.setActive(req.active());
        f.setLevels(levels(req.levels()));
        List<String> after = describe(f.orderedLevels());
        audit.log(AuditCategory.CONFIG_CHANGE, "APPROVAL_FLOW_UPDATED", "APPROVAL_FLOW", f.getCode(),
                AdminUserService.details("levelsBefore", before, "levels", after, "activeBefore", activeBefore,
                        "active", f.isActive()));
        return ApprovalDtos.FlowView.of(f);
    }

    @Transactional(readOnly = true)
    public List<ApprovalDtos.AssignmentView> assignments(String flowCode, UUID approverId, String lob, String location,
                                                         boolean activeOnly) {
        List<ApproverAssignment> rows = assignments.search(normCode(flowCode), approverId,
                ApprovalResolverService.norm(lob), ApprovalResolverService.norm(location), activeOnly);
        return views(rows);
    }

    public ApprovalDtos.AssignmentView createAssignment(ApprovalDtos.AssignmentRequest req) {
        ApproverAssignment a = new ApproverAssignment();
        a.setId(UUID.randomUUID());
        apply(a, req);
        assignments.save(a);
        audit.log(AuditCategory.CONFIG_CHANGE, "APPROVER_ASSIGNED", "APPROVER_ASSIGNMENT", a.getId(), snapshot(a));
        return views(List.of(a)).get(0);
    }

    public ApprovalDtos.AssignmentView updateAssignment(UUID id, ApprovalDtos.AssignmentRequest req) {
        ApproverAssignment a = assignments.findById(id).orElseThrow(() -> APIException.notFound("Approver assignment", id));
        AdminUserService.checkVersion(a.getVersion(), req.version());
        Map<String, Object> before = snapshot(a);
        apply(a, req);
        audit.log(AuditCategory.CONFIG_CHANGE, "APPROVER_ASSIGNMENT_UPDATED", "APPROVER_ASSIGNMENT", a.getId(),
                AdminUserService.details("before", before, "after", snapshot(a)));
        return views(List.of(a)).get(0);
    }

    private void apply(ApproverAssignment a, ApprovalDtos.AssignmentRequest req) {
        String flowCode = normCode(req.flowCode());
        if (flowCode != null) {
            ApprovalFlow f = resolver.flow(flowCode);
            boolean hasLevel = f.getLevels().stream().anyMatch(l -> l.levelNo() == req.levelNo()
                    && l.approverType() == ApproverType.HIERARCHY);
            if (!hasLevel) {
                throw APIException.badRequest("INVALID_ASSIGNMENT",
                        "Flow " + flowCode + " has no HIERARCHY level " + req.levelNo());
            }
        }
        AppUser approver = activeUser(req.approverId(), "Approver");
        if (req.delegateId() != null) {
            if (req.delegateId().equals(req.approverId())) {
                throw APIException.badRequest("INVALID_ASSIGNMENT", "Delegate must be a different person");
            }
            activeUser(req.delegateId(), "Delegate");
        }
        if (req.validFrom() != null && req.validTo() != null && req.validTo().isBefore(req.validFrom())) {
            throw APIException.badRequest("INVALID_ASSIGNMENT", "validTo is before validFrom");
        }
        a.setFlowCode(flowCode);
        a.setLevelNo(req.levelNo());
        a.setLob(ApprovalResolverService.norm(req.lob()));
        a.setLocation(ApprovalResolverService.norm(req.location()));
        a.setApproverId(approver.getId());
        a.setDelegateId(req.delegateId());
        a.setValidFrom(req.validFrom());
        a.setValidTo(req.validTo());
        a.setActive(req.active() == null || req.active());
    }

    private Set<ApprovalLevel> levels(List<ApprovalDtos.LevelItem> items) {
        List<ApprovalDtos.LevelItem> sorted = items.stream().sorted(Comparator.comparingInt(ApprovalDtos.LevelItem::levelNo)).toList();
        Set<ApprovalLevel> out = new HashSet<>();
        for (int i = 0; i < sorted.size(); i++) {
            ApprovalDtos.LevelItem item = sorted.get(i);
            if (item.levelNo() != i + 1) {
                throw APIException.badRequest("INVALID_LEVELS", "Levels must be numbered 1.." + sorted.size() + " without gaps");
            }
            String value = trimToNull(item.approverValue());
            switch (item.approverType()) {
                case ROLE -> {
                    value = requireRole(value, "approverValue");
                }
                case USER -> {
                    UUID id;
                    try {
                        id = UUID.fromString(String.valueOf(value));
                    } catch (IllegalArgumentException e) {
                        throw APIException.badRequest("INVALID_LEVELS", "Level " + item.levelNo() + ": approverValue must be a user id");
                    }
                    activeUser(id, "Level " + item.levelNo() + " approver");
                    value = id.toString();
                }
                case REPORTING_MANAGER -> value = String.valueOf(ApprovalResolverService.depth(value));
                case HIERARCHY -> value = null;
            }
            String fallback = item.fallbackRole() == null ? null : requireRole(item.fallbackRole(), "fallbackRole");
            out.add(new ApprovalLevel(item.levelNo(), item.name().trim(), item.approverType(), value, fallback,
                    item.minApprovals() == null ? 1 : item.minApprovals(), item.slaHours()));
        }
        return out;
    }

    private String requireRole(String code, String field) {
        if (!StringUtils.hasText(code)) {
            throw APIException.badRequest("INVALID_LEVELS", field + " must be a role code");
        }
        String c = code.trim().toUpperCase(Locale.ROOT);
        if (roles.findByCode(c).isEmpty()) {
            throw APIException.badRequest("UNKNOWN_ROLE", "Unknown role: " + c);
        }
        return c;
    }

    private AppUser activeUser(UUID id, String what) {
        AppUser u = users.findById(id).orElseThrow(() -> APIException.badRequest("INVALID_APPROVER", what + " not found: " + id));
        if (!u.isActive()) {
            throw APIException.badRequest("INVALID_APPROVER", what + " " + u.getFullName() + " is inactive");
        }
        return u;
    }

    private List<ApprovalDtos.AssignmentView> views(List<ApproverAssignment> rows) {
        Set<UUID> ids = new HashSet<>();
        rows.forEach(a -> {
            ids.add(a.getApproverId());
            if (a.getDelegateId() != null) {
                ids.add(a.getDelegateId());
            }
        });
        Map<UUID, AppUser> people = ids.isEmpty() ? Map.of()
                : users.findByIdIn(ids).stream().collect(Collectors.toMap(AppUser::getId, Function.identity()));
        List<ApprovalDtos.AssignmentView> out = new ArrayList<>();
        for (ApproverAssignment a : rows) {
            AppUser approver = people.get(a.getApproverId());
            AppUser delegate = a.getDelegateId() == null ? null : people.get(a.getDelegateId());
            out.add(new ApprovalDtos.AssignmentView(a.getId(), a.getFlowCode(), a.getLevelNo(), a.getLob(), a.getLocation(),
                    a.getApproverId(), approver == null ? null : approver.getFullName(),
                    approver == null ? null : approver.getEmail(), a.getDelegateId(),
                    delegate == null ? null : delegate.getFullName(), a.getValidFrom(), a.getValidTo(), a.isActive(),
                    a.getVersion()));
        }
        return out;
    }

    private static Map<String, Object> snapshot(ApproverAssignment a) {
        return AdminUserService.details("flowCode", a.getFlowCode(), "levelNo", a.getLevelNo(), "lob", a.getLob(),
                "location", a.getLocation(), "approverId", a.getApproverId(), "delegateId", a.getDelegateId(),
                "validFrom", a.getValidFrom() == null ? null : a.getValidFrom().toString(),
                "validTo", a.getValidTo() == null ? null : a.getValidTo().toString(), "active", a.isActive());
    }

    private static List<String> describe(List<ApprovalLevel> levels) {
        return levels.stream().map(l -> l.levelNo() + ":" + l.approverType()
                + (l.approverValue() == null ? "" : "=" + l.approverValue())
                + (l.fallbackRole() == null ? "" : " fallback " + l.fallbackRole())
                + " min " + l.minApprovals()).toList();
    }

    private static String normCode(String code) {
        return StringUtils.hasText(code) ? code.trim().toUpperCase(Locale.ROOT) : null;
    }

    private static String trimToNull(String s) {
        return StringUtils.hasText(s) ? s.trim() : null;
    }
}
