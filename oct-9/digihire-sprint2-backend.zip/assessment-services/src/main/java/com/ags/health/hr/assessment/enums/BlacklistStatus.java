package com.ags.health.hr.assessment.enums;

public enum BlacklistStatus { ACTIVE, REMOVAL_PENDING, REMOVED }
