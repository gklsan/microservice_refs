package com.ags.health.hr.assessment.controllers;

import com.ags.health.hr.assessment.data.ApprovalDtos;
import com.ags.health.hr.assessment.data.AttemptDtos;
import com.ags.health.hr.assessment.data.EligibilityDtos;
import com.ags.health.hr.assessment.data.PageResponse;
import com.ags.health.hr.assessment.enums.AttemptStatus;
import com.ags.health.hr.assessment.services.AssessmentService;
import com.ags.health.hr.assessment.services.EligibilityService;
import com.ags.health.hr.assessment.services.RescheduleService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.UUID;

@RestController
@RequestMapping
@RequiredArgsConstructor
public class AssessmentController {

    private final AssessmentService service;
    private final RescheduleService reschedules;
    private final EligibilityService eligibility;

    @PostMapping("/assessments/invite")
    @PreAuthorize("hasAuthority('ASSESSMENT:TRIGGER')")
    public ResponseEntity<AttemptDtos.View> invite(@Valid @RequestBody AttemptDtos.InviteRequest req) {
        return new ResponseEntity<>(service.invite(req), HttpStatus.CREATED);
    }

    @GetMapping("/assessments")
    @PreAuthorize("hasAuthority('ASSESSMENT:VIEW')")
    public PageResponse<AttemptDtos.View> search(@RequestParam(required = false) String candidateId,
                                                 @RequestParam(required = false) String applicationId,
                                                 @RequestParam(required = false) String assessmentCode,
                                                 @RequestParam(required = false) AttemptStatus status,
                                                 @RequestParam(defaultValue = "0") int page,
                                                 @RequestParam(defaultValue = "20") int size) {
        return service.search(candidateId, applicationId, assessmentCode, status,
                PageRequest.of(Math.max(page, 0), Math.min(Math.max(size, 1), 100), Sort.by(Sort.Direction.DESC, "createdDate")));
    }

    @GetMapping("/assessments/{id}")
    @PreAuthorize("hasAuthority('ASSESSMENT:VIEW')")
    public AttemptDtos.View get(@PathVariable UUID id) {
        return service.get(id);
    }

    @PostMapping("/assessments/{id}/results")
    @PreAuthorize("hasAuthority('ASSESSMENT:RESULT_ENTRY')")
    public AttemptDtos.View result(@PathVariable UUID id, @Valid @RequestBody AttemptDtos.ManualResult req) {
        return service.manualResult(id, req);
    }

    @PostMapping("/assessments/{id}/refresh")
    @PreAuthorize("hasAuthority('ASSESSMENT:TRIGGER')")
    public AttemptDtos.View refresh(@PathVariable UUID id) {
        return service.refresh(id);
    }

    @PostMapping("/assessments/{id}/retry")
    @PreAuthorize("hasAuthority('ASSESSMENT:TRIGGER')")
    public AttemptDtos.View retry(@PathVariable UUID id) {
        return service.retry(id);
    }

    @PostMapping("/assessments/{id}/cancel")
    @PreAuthorize("hasAuthority('ASSESSMENT:TRIGGER')")
    public AttemptDtos.View cancel(@PathVariable UUID id, @Valid @RequestBody AttemptDtos.ReasonBody req) {
        return service.cancel(id, req.reason());
    }

    @PostMapping("/assessments/{id}/reschedule-requests")
    @PreAuthorize("hasAuthority('ASSESSMENT:RESCHEDULE_REQUEST')")
    public ResponseEntity<ApprovalDtos.View> reschedule(@PathVariable UUID id, @Valid @RequestBody ApprovalDtos.RescheduleRequest req) {
        return new ResponseEntity<>(reschedules.request(id, req), HttpStatus.CREATED);
    }

    @GetMapping("/candidates/{candidateId}/assessment-summary")
    @PreAuthorize("hasAuthority('ASSESSMENT:VIEW')")
    public AttemptDtos.CandidateSummary summary(@PathVariable String candidateId) {
        return service.summary(candidateId);
    }

    @PostMapping("/eligibility/check")
    @PreAuthorize("hasAnyAuthority('ASSESSMENT:VIEW', 'BLACKLIST:VIEW')")
    public EligibilityDtos.Result eligibility(@Valid @RequestBody EligibilityDtos.Request req) {
        return eligibility.check(req);
    }
}
