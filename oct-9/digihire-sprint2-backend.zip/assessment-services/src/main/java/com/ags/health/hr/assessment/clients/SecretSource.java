package com.ags.health.hr.assessment.clients;

import java.util.Optional;

public interface SecretSource {

    Optional<String> secret(String name);
}
