package com.ags.health.hr.assessment.controllers;

import com.ags.health.hr.assessment.services.AssessmentService;
import jakarta.servlet.http.HttpServletRequest;
import lombok.RequiredArgsConstructor;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;

@RestController
@RequestMapping("/callbacks")
@RequiredArgsConstructor
public class CallbackController {

    private final AssessmentService assessments;

    @PostMapping("/{providerCode}")
    @PreAuthorize("permitAll()")
    public Map<String, Object> receive(@PathVariable String providerCode, @RequestBody String body, HttpServletRequest request) {
        Map<String, String> headers = new LinkedHashMap<>();
        for (String name : Collections.list(request.getHeaderNames())) {
            headers.put(name, request.getHeader(name));
        }
        assessments.handleCallback(providerCode, headers, body);
        return Map.of("received", true);
    }
}
