package com.ags.health.hr.assessment.providers;

import com.ags.health.hr.assessment.clients.JsonHttp;
import com.ags.health.hr.assessment.clients.SecretSource;
import com.ags.health.hr.assessment.config.AssessmentProperties;
import com.ags.health.hr.assessment.enums.ProviderResultStatus;
import com.fasterxml.jackson.databind.JsonNode;

import java.math.BigDecimal;
import java.time.Duration;
import java.time.Instant;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public class VersantProvider implements AssessmentProvider {

    public static final String CODE = "VERSANT";
    private static final String OVERALL = "overall gse score";

    private final AssessmentProperties.Versant props;
    private final JsonHttp http;
    private final SecretSource secrets;
    private final String base;

    private volatile String token;
    private volatile Instant tokenExpiresAt = Instant.EPOCH;

    public VersantProvider(AssessmentProperties.Versant props, JsonHttp http, SecretSource secrets) {
        this.props = props;
        this.http = http;
        this.secrets = secrets;
        String url = props.getBaseUrl() == null ? "" : props.getBaseUrl().trim();
        this.base = url.endsWith("/") ? url.substring(0, url.length() - 1) : url;
    }

    @Override
    public String code() {
        return CODE;
    }

    @Override
    public boolean supportsPolling() {
        return true;
    }

    @Override
    public ProviderInvite invite(InviteContext ctx) {
        Map<String, Object> body = new LinkedHashMap<>();
        body.put("testId", ctx.externalTestId());
        body.put("tests", 1);
        body.put("scale", props.getScale());
        body.put("language", props.getLanguage());
        JsonNode res = authorized("POST", base + "/tins/assign", body);
        JsonNode first = firstElement(res);
        String tin = JsonValues.text(first, "tin");
        if (tin == null) {
            throw new ProviderException("PROVIDER_BAD_RESPONSE", "Versant did not return a TIN");
        }
        return new ProviderInvite(tin, JsonValues.text(first, "takeTestUrl"), ctx.linkExpiresAt());
    }

    @Override
    public List<ProviderResult> fetchResults(List<String> externalRefs) {
        if (externalRefs.isEmpty()) {
            return List.of();
        }
        JsonNode res = authorized("POST", base + "/tins/assigned/status?scale=" + JsonHttp.encode(props.getScale()),
                Map.of("tins", externalRefs));
        JsonNode items = res.isArray() ? res : firstArray(res);
        List<ProviderResult> out = new ArrayList<>();
        if (items == null) {
            return out;
        }
        for (JsonNode item : items) {
            String tin = JsonValues.text(item, "tin");
            if (tin != null) {
                out.add(parse(tin, item));
            }
        }
        return out;
    }

    static ProviderResult parse(String tin, JsonNode item) {
        BigDecimal score = overallScore(item);
        String status = String.valueOf(JsonValues.text(item, "status")).toUpperCase(Locale.ROOT);
        ProviderResultStatus mapped;
        if (score != null || status.contains("SCORED") || status.contains("COMPLETE")) {
            mapped = ProviderResultStatus.COMPLETED;
        } else if (status.contains("PROGRESS") || status.contains("STARTED") && !status.contains("NOT")) {
            mapped = ProviderResultStatus.IN_PROGRESS;
        } else if (status.contains("EXPIRED")) {
            mapped = ProviderResultStatus.EXPIRED;
        } else {
            mapped = ProviderResultStatus.PENDING;
        }
        return new ProviderResult(null, tin, mapped, score, null, JsonValues.instant(item, "startDate"),
                JsonValues.instant(item, "completionDate"), item.toString());
    }

    private static BigDecimal overallScore(JsonNode item) {
        JsonNode parts = JsonValues.at(item, "parts");
        if (parts != null && parts.isArray()) {
            for (JsonNode p : parts) {
                String name = JsonValues.text(p, "name");
                if (name != null && name.toLowerCase(Locale.ROOT).equals(OVERALL)) {
                    return JsonValues.number(p, "score");
                }
            }
        }
        BigDecimal direct = JsonValues.number(item, "overallScore");
        return direct != null ? direct : JsonValues.number(item, "score");
    }

    private JsonNode authorized(String method, String url, Object body) {
        try {
            return http.send(method, url, Map.of("Authorization", "Bearer " + token(false)), body);
        } catch (JsonHttp.HttpFailure e) {
            if (e.status() == 401) {
                return http.send(method, url, Map.of("Authorization", "Bearer " + token(true)), body);
            }
            throw new ProviderException("PROVIDER_UNAVAILABLE", "Versant call failed: " + e.getMessage(), e);
        }
    }

    private synchronized String token(boolean refresh) {
        if (!refresh && token != null && Instant.now().isBefore(tokenExpiresAt)) {
            return token;
        }
        String user = secrets.secret(props.getUsernameSecret()).orElse(props.getUsername());
        String pass = secrets.secret(props.getPasswordSecret()).orElse(props.getPassword());
        if (user == null || user.isBlank() || pass == null || pass.isBlank()) {
            throw new ProviderException("PROVIDER_NOT_CONFIGURED", "Versant credentials are missing in the secret store");
        }
        JsonNode res;
        try {
            res = http.post(base + "/authentication/login", Map.of(), Map.of("username", user, "password", pass));
        } catch (JsonHttp.HttpFailure e) {
            throw new ProviderException("PROVIDER_AUTH_FAILED", "Versant login failed: " + e.status(), e);
        }
        String t = JsonValues.text(res, props.getTokenField());
        if (t == null) {
            t = JsonValues.text(res, "accessToken");
        }
        if (t == null) {
            throw new ProviderException("PROVIDER_AUTH_FAILED", "Versant login returned no token");
        }
        token = t;
        tokenExpiresAt = Instant.now().plus(Duration.ofMinutes(50));
        return t;
    }

    private static JsonNode firstElement(JsonNode res) {
        if (res.isArray()) {
            return res.size() > 0 ? res.get(0) : null;
        }
        JsonNode arr = firstArray(res);
        return arr != null && arr.size() > 0 ? arr.get(0) : res;
    }

    private static JsonNode firstArray(JsonNode res) {
        for (String f : List.of("tins", "data", "items", "results")) {
            JsonNode v = res.get(f);
            if (v != null && v.isArray()) {
                return v;
            }
        }
        return null;
    }
}
