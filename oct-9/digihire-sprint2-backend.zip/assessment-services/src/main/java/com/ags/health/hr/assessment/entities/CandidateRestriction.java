package com.ags.health.hr.assessment.entities;

import com.ags.health.hr.assessment.enums.RestrictionType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.Instant;
import java.util.UUID;

@Entity
@Table(name = "asm_candidate_restriction")
@Getter
@Setter
@NoArgsConstructor
public class CandidateRestriction extends CommonEntity {

    @Id
    private UUID id;

    @Column(name = "candidate_id", nullable = false)
    private String candidateId;

    @Column(name = "candidate_email")
    private String candidateEmail;

    @Enumerated(EnumType.STRING)
    @Column(name = "restriction_type", nullable = false)
    private RestrictionType restrictionType;

    private String reason;

    @Column(name = "source_application_id")
    private String sourceApplicationId;

    @Column(name = "source_attempt_id")
    private UUID sourceAttemptId;

    @Column(name = "source_role_code")
    private String sourceRoleCode;

    @Column(name = "source_location")
    private String sourceLocation;

    @Column(name = "starts_at", nullable = false)
    private Instant startsAt;

    @Column(name = "ends_at", nullable = false)
    private Instant endsAt;

    @Column(nullable = false)
    private boolean active = true;

    public boolean isInForce(Instant now) {
        return active && !now.isBefore(startsAt) && now.isBefore(endsAt);
    }
}
