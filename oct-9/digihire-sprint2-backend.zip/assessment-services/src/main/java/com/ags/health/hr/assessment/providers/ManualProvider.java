package com.ags.health.hr.assessment.providers;

public class ManualProvider implements AssessmentProvider {

    public static final String CODE = "MANUAL";

    @Override
    public String code() {
        return CODE;
    }

    @Override
    public boolean acceptsManualResults() {
        return true;
    }

    @Override
    public ProviderInvite invite(InviteContext ctx) {
        Object url = ctx.settings().get("url");
        return new ProviderInvite(ctx.attemptId().toString(), url == null ? null : String.valueOf(url), ctx.linkExpiresAt());
    }
}
