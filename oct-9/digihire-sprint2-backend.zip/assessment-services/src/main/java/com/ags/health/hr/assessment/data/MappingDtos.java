package com.ags.health.hr.assessment.data;

import com.ags.health.hr.assessment.entities.AssessmentMapping;
import com.ags.health.hr.assessment.enums.TriggerEvent;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

import java.util.UUID;

public final class MappingDtos {

    private MappingDtos() {
    }

    public record Request(@Size(max = 100) String lob,
                          @Size(max = 100) String roleCode,
                          @Size(max = 100) String location,
                          @NotBlank @Size(max = 50) String assessmentCode,
                          @Min(1) @Max(20) Integer sequenceNo,
                          @NotNull TriggerEvent triggerEvent,
                          @Size(max = 60) String triggerStage,
                          Boolean mandatory,
                          Boolean active,
                          Long version) {
    }

    public record View(UUID id, String lob, String roleCode, String location, String assessmentCode, int sequenceNo,
                       TriggerEvent triggerEvent, String triggerStage, boolean mandatory, boolean active, Long version) {

        public static View of(AssessmentMapping m) {
            return new View(m.getId(), m.getLob(), m.getRoleCode(), m.getLocation(), m.getAssessmentCode(), m.getSequenceNo(),
                    m.getTriggerEvent(), m.getTriggerStage(), m.isMandatory(), m.isActive(), m.getVersion());
        }
    }
}
