package com.ags.health.hr.assessment.entities;

import com.ags.health.hr.assessment.enums.AttemptStatus;
import com.ags.health.hr.assessment.enums.TriggerSource;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.math.BigDecimal;
import java.time.Instant;
import java.util.UUID;

@Entity
@Table(name = "asm_assessment_attempt")
@Getter
@Setter
@NoArgsConstructor
public class AssessmentAttempt extends CommonEntity {

    @Id
    private UUID id;

    @Column(name = "candidate_id", nullable = false)
    private String candidateId;

    @Column(name = "application_id")
    private String applicationId;

    @Column(name = "candidate_email")
    private String candidateEmail;

    @Column(name = "candidate_name")
    private String candidateName;

    @Column(name = "assessment_code", nullable = false)
    private String assessmentCode;

    @Column(name = "provider_code", nullable = false)
    private String providerCode;

    @Column(name = "cooling_key")
    private String coolingKey;

    @Column(name = "attempt_no", nullable = false)
    private int attemptNo;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private AttemptStatus status;

    @Column(name = "external_ref")
    private String externalRef;

    @Column(name = "test_url")
    private String testUrl;

    @Column(name = "invited_at")
    private Instant invitedAt;

    @Column(name = "link_expires_at")
    private Instant linkExpiresAt;

    @Column(name = "started_at")
    private Instant startedAt;

    @Column(name = "completed_at")
    private Instant completedAt;

    @Column(name = "result_received_at")
    private Instant resultReceivedAt;

    private BigDecimal score;

    private String grade;

    private Boolean passed;

    @Column(name = "valid_until")
    private Instant validUntil;

    @Column(name = "validity_expired_at")
    private Instant validityExpiredAt;

    @Column(name = "cooling_until")
    private Instant coolingUntil;

    @Column(name = "cooling_tier")
    private Integer coolingTier;

    @Column(name = "fresher_reset", nullable = false)
    private boolean fresherReset;

    @Column(name = "reschedule_count", nullable = false)
    private int rescheduleCount;

    @Column(name = "rescheduled_from")
    private UUID rescheduledFrom;

    private String lob;

    @Column(name = "role_code")
    private String roleCode;

    private String location;

    @Enumerated(EnumType.STRING)
    @Column(name = "trigger_source", nullable = false)
    private TriggerSource triggerSource;

    @Column(name = "triggered_by")
    private String triggeredBy;

    @Column(name = "status_reason")
    private String statusReason;

    @Column(name = "raw_result")
    private String rawResult;

    public boolean isScoreValid(Instant now) {
        return Boolean.TRUE.equals(passed) && validUntil != null && validUntil.isAfter(now);
    }
}
