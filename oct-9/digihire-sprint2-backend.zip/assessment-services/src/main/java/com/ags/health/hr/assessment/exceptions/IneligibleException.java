package com.ags.health.hr.assessment.exceptions;

import com.ags.health.hr.assessment.data.EligibilityDtos;
import org.springframework.http.HttpStatus;

import java.util.List;
import java.util.stream.Collectors;

public class IneligibleException extends APIException {

    private final transient List<EligibilityDtos.Reason> reasons;

    public IneligibleException(List<EligibilityDtos.Reason> reasons) {
        super(HttpStatus.CONFLICT, "NOT_ELIGIBLE", "Candidate is not eligible: "
                + reasons.stream().filter(EligibilityDtos.Reason::blocking).map(EligibilityDtos.Reason::code)
                .collect(Collectors.joining(", ")));
        this.reasons = List.copyOf(reasons);
    }

    public List<EligibilityDtos.Reason> getReasons() {
        return reasons;
    }
}
