package com.ags.health.hr.assessment.services;

import com.ags.health.hr.assessment.data.AttemptDtos;
import com.ags.health.hr.assessment.data.EligibilityDtos;
import com.ags.health.hr.assessment.data.EventDtos;
import com.ags.health.hr.assessment.entities.AssessmentDefinition;
import com.ags.health.hr.assessment.entities.AssessmentMapping;
import com.ags.health.hr.assessment.entities.CandidateRestriction;
import com.ags.health.hr.assessment.enums.ApplicationEventType;
import com.ags.health.hr.assessment.enums.AttemptStatus;
import com.ags.health.hr.assessment.enums.EligibilityPurpose;
import com.ags.health.hr.assessment.enums.TriggerEvent;
import com.ags.health.hr.assessment.providers.ProviderRegistry;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Slf4j
@Service
@RequiredArgsConstructor
public class ApplicationEventService {

    private final AssessmentConfigService config;
    private final EligibilityService eligibility;
    private final AssessmentService assessments;
    private final VoiceFresherService voiceFresher;
    private final ProviderRegistry providers;

    public EventDtos.Outcome handle(EventDtos.ApplicationEvent ev) {
        if (ev.eventType() == ApplicationEventType.REJECTED) {
            Optional<CandidateRestriction> r = voiceFresher.onRejection(ev.candidateId(), ev.candidateEmail(), ev.applicationId(),
                    null, ev.roleCode(), ev.location(), ev.reason());
            return new EventDtos.Outcome(ev.eventType().name(), ev.candidateId(), false, r.isPresent(), List.of());
        }
        TriggerEvent trigger = switch (ev.eventType()) {
            case CREATED -> TriggerEvent.APPLICATION_CREATED;
            case WALKED_IN -> TriggerEvent.WALKED_IN;
            default -> TriggerEvent.STAGE_ENTERED;
        };
        List<AssessmentMapping> mappings = config.matching(trigger, AssessmentConfigService.norm(ev.lob()),
                AssessmentConfigService.norm(ev.roleCode()), AssessmentConfigService.norm(ev.location()), ev.stage());
        List<EventDtos.OutcomeItem> items = new ArrayList<>();
        boolean blacklisted = false;
        for (AssessmentMapping m : mappings) {
            try {
                AssessmentDefinition def = config.definitionEntity(m.getAssessmentCode());
                if (!def.isActive()) {
                    items.add(item(m.getAssessmentCode(), "SKIPPED", null, "ASSESSMENT_INACTIVE", "Assessment is not active"));
                    continue;
                }
                if (providers.find(def.getProviderCode()).isEmpty()) {
                    items.add(item(m.getAssessmentCode(), "SKIPPED", null, "PROVIDER_DISABLED", def.getProviderCode() + " is not enabled"));
                    continue;
                }
                EligibilityDtos.Result result = eligibility.check(new EligibilityDtos.Request(ev.candidateId(), ev.candidateEmail(),
                        ev.mobile(), null, def.getCode(), ev.lob(), ev.roleCode(), ev.location(), EligibilityPurpose.ASSESSMENT));
                if (result.has(EligibilityService.BLACKLISTED)) {
                    blacklisted = true;
                    items.add(new EventDtos.OutcomeItem(def.getCode(), "BLOCKED", null, result.reasons()));
                    continue;
                }
                if (!result.eligible()) {
                    String action = result.has(EligibilityService.VALID_SCORE_EXISTS) ? "REUSED_VALID_SCORE" : "SKIPPED";
                    items.add(new EventDtos.OutcomeItem(def.getCode(), action,
                            result.validScore() == null ? null : result.validScore().attemptId(), result.reasons()));
                    continue;
                }
                AttemptDtos.View attempt = assessments.autoInvite(ev, def);
                items.add(new EventDtos.OutcomeItem(def.getCode(), attempt.status() == AttemptStatus.ERROR ? "FAILED" : "INVITED",
                        attempt.id(), List.of()));
            } catch (RuntimeException e) {
                log.warn("Auto-trigger of {} for candidate {} failed: {}", m.getAssessmentCode(), ev.candidateId(), e.getMessage());
                items.add(item(m.getAssessmentCode(), "FAILED", null, "ERROR", e.getMessage()));
            }
        }
        return new EventDtos.Outcome(ev.eventType().name(), ev.candidateId(), blacklisted, false, items);
    }

    private static EventDtos.OutcomeItem item(String code, String action, java.util.UUID attemptId, String reasonCode, String message) {
        return new EventDtos.OutcomeItem(code, action, attemptId,
                List.of(new EligibilityDtos.Reason(reasonCode, message, null, true)));
    }
}
