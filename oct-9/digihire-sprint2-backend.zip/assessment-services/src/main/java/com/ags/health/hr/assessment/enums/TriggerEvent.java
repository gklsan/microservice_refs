package com.ags.health.hr.assessment.enums;

public enum TriggerEvent { APPLICATION_CREATED, WALKED_IN, STAGE_ENTERED }
