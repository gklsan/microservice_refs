package com.ags.health.hr.assessment.services;

import com.ags.health.hr.assessment.clients.SecretSource;
import com.ags.health.hr.assessment.config.AssessmentProperties;
import com.ags.health.hr.assessment.exceptions.APIException;
import com.ags.health.hr.assessment.providers.Hmac;
import com.ags.health.hr.assessment.utils.Masking;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

@Component
@RequiredArgsConstructor
public class IdentityHasher {

    public record Hashes(String email, String mobile, String idProof) {

        public boolean isEmpty() {
            return email == null && mobile == null && idProof == null;
        }
    }

    private final SecretSource secrets;
    private final AssessmentProperties props;

    public Hashes hash(String email, String mobile, String idProof) {
        String e = Masking.normalizeEmail(email);
        String m = Masking.normalizeMobile(mobile);
        String i = Masking.normalizeIdProof(idProof);
        if (e == null && m == null && i == null) {
            return new Hashes(null, null, null);
        }
        String pepper = pepper();
        return new Hashes(e == null ? null : Hmac.sha256Hex(pepper, "email:" + e),
                m == null ? null : Hmac.sha256Hex(pepper, "mobile:" + m),
                i == null ? null : Hmac.sha256Hex(pepper, "id:" + i));
    }

    public boolean isConfigured() {
        return pepperOrNull() != null;
    }

    private String pepperOrNull() {
        String name = props.getBlacklist().getPepperSecretName();
        String fromStore = name == null || name.isBlank() ? null : secrets.secret(name).orElse(null);
        String value = fromStore != null ? fromStore : props.getBlacklist().getPepper();
        return value == null || value.length() < 16 ? null : value;
    }

    private String pepper() {
        String name = props.getBlacklist().getPepperSecretName();
        String value = pepperOrNull();
        if (value == null) {
            throw APIException.unavailable("BLACKLIST_NOT_CONFIGURED",
                    "Blacklist matching key is missing. Add secret " + name + " (16+ characters) in admin-services.");
        }
        return value;
    }
}
