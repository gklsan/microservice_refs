package com.ags.health.hr.assessment.security;

import com.ags.health.hr.assessment.clients.AccessDirectory;
import com.ags.health.hr.assessment.exceptions.APIException;
import io.jsonwebtoken.Claims;
import io.jsonwebtoken.JwtException;
import io.jsonwebtoken.JwtParser;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.io.Decoders;
import io.jsonwebtoken.security.Keys;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.filter.OncePerRequestFilter;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

@Slf4j
public class JwtAuthFilter extends OncePerRequestFilter {

    private final JwtParser parser;
    private final AccessDirectory access;
    private final ProblemResponseWriter problems;

    public JwtAuthFilter(String base64Secret, AccessDirectory access, ProblemResponseWriter problems) {
        if (base64Secret == null || base64Secret.isBlank()) {
            throw new IllegalStateException("assessment.security.jwt-secret (env JWT_SECRET) must be set");
        }
        byte[] key;
        try {
            key = Decoders.BASE64.decode(base64Secret.trim());
        } catch (RuntimeException e) {
            throw new IllegalStateException("JWT_SECRET is not valid Base64", e);
        }
        if (key.length < 32) {
            throw new IllegalStateException("JWT_SECRET must decode to at least 256 bits");
        }
        this.parser = Jwts.parserBuilder().setSigningKey(Keys.hmacShaKeyFor(key)).build();
        this.access = access;
        this.problems = problems;
    }

    @Override
    protected boolean shouldNotFilter(HttpServletRequest request) {
        String path = request.getRequestURI().substring(request.getContextPath().length());
        return path.startsWith("/callbacks/") || path.startsWith("/actuator/health");
    }

    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain chain)
            throws ServletException, IOException {
        String header = request.getHeader(HttpHeaders.AUTHORIZATION);
        if (header == null || SecurityContextHolder.getContext().getAuthentication() != null) {
            chain.doFilter(request, response);
            return;
        }
        String token = header.startsWith("Bearer ") ? header.substring(7).trim() : header.trim();
        Claims claims;
        try {
            claims = parser.parseClaimsJws(token).getBody();
        } catch (JwtException | IllegalArgumentException ex) {
            log.debug("Rejected token: {}", ex.getMessage());
            problems.write(response, HttpStatus.UNAUTHORIZED, "INVALID_TOKEN", "Session expired or token invalid");
            return;
        }
        String userId = claims.get("userId") == null ? null : String.valueOf(claims.get("userId"));
        String email = claims.get("email") != null ? String.valueOf(claims.get("email")) : claims.getSubject();
        String userType = claims.get("userType") == null ? null : String.valueOf(claims.get("userType"));
        String name = claims.get("userName") == null ? null : String.valueOf(claims.get("userName"));

        AccessProfile profile;
        try {
            profile = access.resolve(userId, email, userType);
        } catch (APIException e) {
            problems.write(response, e.getStatus(), e.getCode(), e.getMessage());
            return;
        }
        List<GrantedAuthority> authorities = new ArrayList<>();
        if (profile.active()) {
            profile.roles().forEach(r -> authorities.add(new SimpleGrantedAuthority("ROLE_" + r)));
            profile.permissions().forEach(p -> authorities.add(new SimpleGrantedAuthority(p)));
        }
        CurrentUser user = new CurrentUser(userId != null ? userId : profile.userId(), email, name, userType, profile);
        SecurityContextHolder.getContext().setAuthentication(new SmartieAuthentication(user, authorities));
        chain.doFilter(request, response);
    }
}
