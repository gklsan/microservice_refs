package com.ags.health.hr.assessment.services;

import com.ags.health.hr.assessment.entities.CandidateRestriction;
import com.ags.health.hr.assessment.enums.AuditCategory;
import com.ags.health.hr.assessment.enums.RestrictionType;
import com.ags.health.hr.assessment.resources.CandidateRestrictionRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.Duration;
import java.time.Instant;
import java.util.List;
import java.util.Locale;
import java.util.Optional;
import java.util.UUID;

@Service
@Transactional
@RequiredArgsConstructor
public class VoiceFresherService {

    private final CandidateRestrictionRepository restrictions;
    private final RuleSettings rules;
    private final AuditService audit;
    private final OutboxService outbox;

    public boolean isVoiceFresherRole(String roleCode) {
        return roleCode != null && rules.voiceFresherRoleCodes().contains(roleCode.trim().toUpperCase(Locale.ROOT));
    }

    public boolean isRestrictedLocation(String location) {
        return location != null && rules.voiceFresherLocations().contains(location.trim().toUpperCase(Locale.ROOT));
    }

    public Optional<CandidateRestriction> onRejection(String candidateId, String email, String applicationId, UUID attemptId,
                                                      String roleCode, String location, String reason) {
        if (!isVoiceFresherRole(roleCode) || !isRestrictedLocation(location)) {
            return Optional.empty();
        }
        Instant now = Instant.now();
        Instant until = now.plus(Duration.ofDays(rules.voiceFresherBlockDays()));
        boolean covered = active(candidateId, now).stream().anyMatch(r -> !r.getEndsAt().isBefore(until));
        if (covered) {
            return Optional.empty();
        }
        CandidateRestriction r = new CandidateRestriction();
        r.setId(UUID.randomUUID());
        r.setCandidateId(candidateId);
        r.setCandidateEmail(email);
        r.setRestrictionType(RestrictionType.VOICE_FRESHER);
        r.setReason(reason == null ? "Rejected for a Voice Fresher role in " + location : reason);
        r.setSourceApplicationId(applicationId);
        r.setSourceAttemptId(attemptId);
        r.setSourceRoleCode(roleCode.trim().toUpperCase(Locale.ROOT));
        r.setSourceLocation(location.trim().toUpperCase(Locale.ROOT));
        r.setStartsAt(now);
        r.setEndsAt(until);
        restrictions.save(r);
        audit.log(AuditCategory.WORKFLOW_TRANSITION, "VOICE_FRESHER_RESTRICTION_APPLIED", "CANDIDATE_RESTRICTION", r.getId(),
                candidateId, AuditService.details("roleCode", r.getSourceRoleCode(), "location", r.getSourceLocation(),
                        "until", until.toString(), "applicationId", applicationId, "attemptId", attemptId));
        outbox.publish("CANDIDATE_RESTRICTED", "CANDIDATE_RESTRICTION", r.getId(), candidateId, applicationId,
                AuditService.details("type", RestrictionType.VOICE_FRESHER, "until", until.toString(),
                        "roleCodes", rules.voiceFresherRoleCodes()));
        return Optional.of(r);
    }

    @Transactional(readOnly = true)
    public List<CandidateRestriction> active(String candidateId, Instant now) {
        if (candidateId == null) {
            return List.of();
        }
        return restrictions.findByCandidateIdAndRestrictionTypeAndActiveTrue(candidateId, RestrictionType.VOICE_FRESHER)
                .stream().filter(r -> r.isInForce(now)).toList();
    }

    public int liftForAttempt(UUID attemptId, String reason) {
        List<CandidateRestriction> found = restrictions.findBySourceAttemptIdAndActiveTrue(attemptId);
        for (CandidateRestriction r : found) {
            r.setActive(false);
            audit.log(AuditCategory.WORKFLOW_TRANSITION, "VOICE_FRESHER_RESTRICTION_LIFTED", "CANDIDATE_RESTRICTION", r.getId(),
                    r.getCandidateId(), AuditService.details("attemptId", attemptId, "reason", reason));
        }
        return found.size();
    }
}
