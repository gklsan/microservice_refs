package com.ags.health.hr.assessment.enums;

public enum ProviderResultStatus { PENDING, IN_PROGRESS, COMPLETED, NOT_TAKEN, EXPIRED }
