package com.ags.health.hr.assessment.resources;

import com.ags.health.hr.assessment.entities.BlacklistEntry;
import com.ags.health.hr.assessment.enums.BlacklistStatus;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.Collection;
import java.util.List;
import java.util.UUID;

public interface BlacklistRepository extends JpaRepository<BlacklistEntry, UUID> {

    @Query("""
            select b from BlacklistEntry b
            where b.status in :statuses
              and ((:candidateId is not null and b.candidateId = :candidateId)
                or (:emailHash is not null and b.emailHash = :emailHash)
                or (:mobileHash is not null and b.mobileHash = :mobileHash)
                or (:idProofHash is not null and b.idProofHash = :idProofHash))
            """)
    List<BlacklistEntry> findMatches(@Param("statuses") Collection<BlacklistStatus> statuses,
                                     @Param("candidateId") String candidateId,
                                     @Param("emailHash") String emailHash,
                                     @Param("mobileHash") String mobileHash,
                                     @Param("idProofHash") String idProofHash);

    @Query("""
            select b from BlacklistEntry b
            where (:status is null or b.status = :status)
              and (:reasonCode is null or b.reasonCode = :reasonCode)
              and (:candidateId is null or b.candidateId = :candidateId)
            """)
    Page<BlacklistEntry> search(@Param("status") BlacklistStatus status,
                                @Param("reasonCode") String reasonCode,
                                @Param("candidateId") String candidateId,
                                Pageable pageable);
}
