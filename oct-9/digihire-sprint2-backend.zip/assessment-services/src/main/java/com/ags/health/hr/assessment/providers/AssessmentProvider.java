package com.ags.health.hr.assessment.providers;

import java.util.List;
import java.util.Map;

public interface AssessmentProvider {

    String code();

    default boolean supportsPolling() {
        return false;
    }

    default boolean supportsCallback() {
        return false;
    }

    default boolean acceptsManualResults() {
        return false;
    }

    ProviderInvite invite(InviteContext ctx);

    default List<ProviderResult> fetchResults(List<String> externalRefs) {
        return List.of();
    }

    default void cancel(String externalRef) {
    }

    default ProviderResult parseCallback(Map<String, String> headers, String body) {
        throw new ProviderException("CALLBACK_NOT_SUPPORTED", code() + " does not accept callbacks");
    }
}
