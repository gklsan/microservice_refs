package com.ags.health.hr.assessment.services;

import com.ags.health.hr.assessment.data.EventDtos;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.RequiredArgsConstructor;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.sql.Timestamp;
import java.time.Instant;
import java.util.List;
import java.util.Map;
import java.util.UUID;

@Service
@RequiredArgsConstructor
public class OutboxService {

    private final JdbcTemplate jdbc;
    private final ObjectMapper mapper;

    public void publish(String eventType, String aggregateType, Object aggregateId, String candidateId,
                        String applicationId, Map<String, ?> payload) {
        String json;
        try {
            json = mapper.writeValueAsString(payload);
        } catch (JsonProcessingException e) {
            throw new IllegalStateException("Event payload is not serialisable", e);
        }
        if (json.length() > 8000) {
            json = "{\"truncated\":true,\"eventType\":\"" + eventType + "\"}";
        }
        jdbc.update("INSERT INTO asm_outbox_event (id, event_type, aggregate_type, aggregate_id, candidate_id, application_id, "
                        + "payload, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
                UUID.randomUUID(), eventType, aggregateType, String.valueOf(aggregateId), candidateId, applicationId, json,
                Timestamp.from(Instant.now()));
    }

    @Transactional(readOnly = true)
    public List<EventDtos.OutboxEvent> after(long afterSeq, int limit) {
        return jdbc.query("SELECT seq, id, event_type, aggregate_type, aggregate_id, candidate_id, application_id, payload, "
                + "created_at FROM asm_outbox_event WHERE seq > ? ORDER BY seq LIMIT ?", rows(), afterSeq, Math.max(1, Math.min(limit, 500)));
    }

    @Transactional(readOnly = true)
    public List<EventDtos.OutboxEvent> unpublished(int limit) {
        return jdbc.query("SELECT seq, id, event_type, aggregate_type, aggregate_id, candidate_id, application_id, payload, "
                + "created_at FROM asm_outbox_event WHERE published_at IS NULL ORDER BY seq LIMIT ?", rows(), limit);
    }

    @Transactional
    public void markPublished(List<Long> seqs) {
        for (Long seq : seqs) {
            jdbc.update("UPDATE asm_outbox_event SET published_at = ?, publish_attempts = publish_attempts + 1, last_error = NULL "
                    + "WHERE seq = ?", Timestamp.from(Instant.now()), seq);
        }
    }

    @Transactional
    public void markFailed(List<Long> seqs, String error) {
        String e = error == null ? null : error.length() > 500 ? error.substring(0, 500) : error;
        for (Long seq : seqs) {
            jdbc.update("UPDATE asm_outbox_event SET publish_attempts = publish_attempts + 1, last_error = ? WHERE seq = ?", e, seq);
        }
    }

    private RowMapper<EventDtos.OutboxEvent> rows() {
        return (rs, i) -> {
            Timestamp at = rs.getTimestamp("created_at");
            return new EventDtos.OutboxEvent(rs.getLong("seq"), rs.getObject("id", UUID.class), rs.getString("event_type"),
                    rs.getString("aggregate_type"), rs.getString("aggregate_id"), rs.getString("candidate_id"),
                    rs.getString("application_id"), parse(rs.getString("payload")), at == null ? null : at.toInstant());
        };
    }

    private JsonNode parse(String json) {
        try {
            return mapper.readTree(json);
        } catch (JsonProcessingException e) {
            return null;
        }
    }
}
