package com.ags.health.hr.assessment.enums;

public enum RestrictionType { VOICE_FRESHER }
