package com.ags.health.hr.assessment.clients;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.io.IOException;
import java.net.URI;
import java.net.URLEncoder;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.StringJoiner;

public class JsonHttp {

    public static class HttpFailure extends RuntimeException {

        private final int status;
        private final String body;

        public HttpFailure(int status, String body, String message, Throwable cause) {
            super(message, cause);
            this.status = status;
            this.body = body;
        }

        public int status() {
            return status;
        }

        public String body() {
            return body;
        }
    }

    private final HttpClient client;
    private final ObjectMapper mapper;
    private final Duration timeout;

    public JsonHttp(ObjectMapper mapper, Duration timeout) {
        this(HttpClient.newBuilder().connectTimeout(timeout).followRedirects(HttpClient.Redirect.NEVER).build(), mapper, timeout);
    }

    public JsonHttp(HttpClient client, ObjectMapper mapper, Duration timeout) {
        this.client = client;
        this.mapper = mapper;
        this.timeout = timeout;
    }

    public ObjectMapper mapper() {
        return mapper;
    }

    public JsonNode get(String url, Map<String, String> headers) {
        return send("GET", url, headers, null);
    }

    public JsonNode post(String url, Map<String, String> headers, Object body) {
        return send("POST", url, headers, body);
    }

    public JsonNode send(String method, String url, Map<String, String> headers, Object body) {
        String payload;
        try {
            payload = body == null ? null : body instanceof String s ? s : mapper.writeValueAsString(body);
        } catch (IOException e) {
            throw new HttpFailure(0, null, "Could not serialise request body", e);
        }
        HttpRequest.Builder b = HttpRequest.newBuilder(URI.create(url)).timeout(timeout).header("Accept", "application/json");
        if (headers != null) {
            headers.forEach((k, v) -> {
                if (v != null) {
                    b.header(k, v);
                }
            });
        }
        if (payload != null) {
            b.header("Content-Type", "application/json");
            b.method(method, HttpRequest.BodyPublishers.ofString(payload, StandardCharsets.UTF_8));
        } else {
            b.method(method, HttpRequest.BodyPublishers.noBody());
        }
        HttpResponse<String> res;
        try {
            res = client.send(b.build(), HttpResponse.BodyHandlers.ofString(StandardCharsets.UTF_8));
        } catch (IOException e) {
            throw new HttpFailure(0, null, method + " " + safe(url) + " failed: " + e.getClass().getSimpleName(), e);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            throw new HttpFailure(0, null, method + " " + safe(url) + " interrupted", e);
        }
        if (res.statusCode() < 200 || res.statusCode() >= 300) {
            throw new HttpFailure(res.statusCode(), res.body(), method + " " + safe(url) + " returned " + res.statusCode(), null);
        }
        String text = res.body();
        if (text == null || text.isBlank()) {
            return mapper.createObjectNode();
        }
        try {
            return mapper.readTree(text);
        } catch (IOException e) {
            throw new HttpFailure(res.statusCode(), text, method + " " + safe(url) + " returned non-JSON", e);
        }
    }

    public static String query(String base, Map<String, ?> params) {
        StringJoiner q = new StringJoiner("&");
        Map<String, ?> ordered = params == null ? Map.of() : new LinkedHashMap<>(params);
        ordered.forEach((k, v) -> {
            if (v != null && !String.valueOf(v).isBlank()) {
                q.add(encode(k) + "=" + encode(String.valueOf(v)));
            }
        });
        return q.length() == 0 ? base : base + (base.contains("?") ? "&" : "?") + q;
    }

    public static String encode(String v) {
        return URLEncoder.encode(v, StandardCharsets.UTF_8);
    }

    private static String safe(String url) {
        int q = url.indexOf('?');
        return q < 0 ? url : url.substring(0, q);
    }
}
