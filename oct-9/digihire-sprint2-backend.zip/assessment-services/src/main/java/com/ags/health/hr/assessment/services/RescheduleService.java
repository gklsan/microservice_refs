package com.ags.health.hr.assessment.services;

import com.ags.health.hr.assessment.data.ApprovalDtos;
import com.ags.health.hr.assessment.entities.ApprovalRequest;
import com.ags.health.hr.assessment.entities.AssessmentAttempt;
import com.ags.health.hr.assessment.enums.ApprovalSubjectType;
import com.ags.health.hr.assessment.enums.AttemptStatus;
import com.ags.health.hr.assessment.enums.AuditCategory;
import com.ags.health.hr.assessment.exceptions.APIException;
import com.ags.health.hr.assessment.resources.AssessmentAttemptRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.EnumSet;
import java.util.Set;
import java.util.UUID;

@Service
@Transactional
@RequiredArgsConstructor
public class RescheduleService implements ApprovalSubjectHandler {

    public static final String APPROVE = "ASSESSMENT:RESCHEDULE_APPROVE";
    private static final Set<AttemptStatus> RESCHEDULABLE = EnumSet.of(AttemptStatus.INVITED, AttemptStatus.IN_PROGRESS,
            AttemptStatus.FAILED, AttemptStatus.NOT_TAKEN, AttemptStatus.EXPIRED);

    private final AssessmentService assessments;
    private final AssessmentAttemptRepository attempts;
    private final ApprovalWorkflowService workflow;
    private final RuleSettings rules;
    private final AuditService audit;

    @Override
    public ApprovalSubjectType type() {
        return ApprovalSubjectType.ASSESSMENT_RESCHEDULE;
    }

    @Override
    public String approvePermission() {
        return APPROVE;
    }

    public ApprovalDtos.View request(UUID attemptId, ApprovalDtos.RescheduleRequest req) {
        AssessmentAttempt a = assessments.find(attemptId);
        if (!RESCHEDULABLE.contains(a.getStatus())) {
            throw APIException.conflict("RESCHEDULE_NOT_ALLOWED", "An attempt in status " + a.getStatus() + " can not be rescheduled");
        }
        int max = rules.rescheduleMaxPerAttempt();
        if (a.getRescheduleCount() >= max) {
            throw APIException.conflict("RESCHEDULE_LIMIT_REACHED", "This attempt was already rescheduled " + max + " time(s)");
        }
        boolean newer = attempts.findByCandidateIdAndAssessmentCodeOrderByCreatedDateDesc(a.getCandidateId(), a.getAssessmentCode())
                .stream().anyMatch(x -> !x.getId().equals(a.getId()) && x.getCreatedDate() != null && a.getCreatedDate() != null
                        && x.getCreatedDate().isAfter(a.getCreatedDate()) && x.getStatus() != AttemptStatus.CANCELLED);
        if (newer) {
            throw APIException.conflict("NOT_LATEST_ATTEMPT", "Only the latest attempt can be rescheduled");
        }
        ApprovalRequest r = workflow.create(ApprovalSubjectType.ASSESSMENT_RESCHEDULE, a.getId().toString(), a.getCandidateId(),
                req.reasonCode().name(), req.details(), a.getLob(), a.getLocation());
        audit.log(AuditCategory.APPROVAL, "ASSESSMENT_RESCHEDULE_REQUESTED", "ASSESSMENT_ATTEMPT", a.getId(), a.getCandidateId(),
                AuditService.details("requestId", r.getId(), "reasonCode", req.reasonCode(), "details", req.details(),
                        "attemptStatus", a.getStatus()));
        return workflow.view(r);
    }

    @Override
    public void onApproved(ApprovalRequest request) {
        AssessmentAttempt a = assessments.find(UUID.fromString(request.getSubjectId()));
        if (!RESCHEDULABLE.contains(a.getStatus())) {
            audit.log(AuditCategory.APPROVAL, "ASSESSMENT_RESCHEDULE_SKIPPED", "ASSESSMENT_ATTEMPT", a.getId(), a.getCandidateId(),
                    AuditService.details("requestId", request.getId(), "attemptStatus", a.getStatus()));
            return;
        }
        assessments.closeForReschedule(a, "Technical reschedule approved (" + request.getReasonCode() + ")");
        assessments.inviteReschedule(a);
    }

    @Override
    public void onRejected(ApprovalRequest request) {
        audit.log(AuditCategory.APPROVAL, "ASSESSMENT_RESCHEDULE_DECLINED", "ASSESSMENT_ATTEMPT", request.getSubjectId(),
                request.getCandidateId(), AuditService.details("requestId", request.getId(), "status", request.getStatus()));
    }
}
