package com.ags.health.hr.assessment.data;

import com.ags.health.hr.assessment.entities.ApprovalAction;
import com.ags.health.hr.assessment.entities.ApprovalRequest;
import com.ags.health.hr.assessment.enums.ApprovalDecision;
import com.ags.health.hr.assessment.enums.ApprovalStatus;
import com.ags.health.hr.assessment.enums.ApprovalSubjectType;
import com.ags.health.hr.assessment.enums.RescheduleReason;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

import java.time.Instant;
import java.util.List;
import java.util.UUID;

public final class ApprovalDtos {

    private ApprovalDtos() {
    }

    public record RescheduleRequest(@NotNull RescheduleReason reasonCode, @NotBlank @Size(max = 1000) String details) {
    }

    public record Decision(@Size(max = 1000) String comment) {
    }

    public record ActionView(int levelNo, ApprovalDecision decision, String actorEmail, String actorName, String comment,
                             Instant actedAt) {

        public static ActionView of(ApprovalAction a) {
            return new ActionView(a.getLevelNo(), a.getDecision(), a.getActorEmail(), a.getActorName(), a.getComment(),
                    a.getActedAt());
        }
    }

    public record View(UUID id, ApprovalSubjectType subjectType, String subjectId, String flowCode, ApprovalStatus status,
                       int currentLevel, int totalLevels, String candidateId, String requestedByEmail, String requestedByName,
                       String reasonCode, String reason, String lob, String location, Instant requestedAt, Instant decidedAt,
                       List<ActionView> actions, Long version) {

        public static View of(ApprovalRequest r, List<ApprovalAction> actions) {
            return new View(r.getId(), r.getSubjectType(), r.getSubjectId(), r.getFlowCode(), r.getStatus(), r.getCurrentLevel(),
                    r.getTotalLevels(), r.getCandidateId(), r.getRequestedByEmail(), r.getRequestedByName(), r.getReasonCode(),
                    r.getReason(), r.getLob(), r.getLocation(), r.getRequestedAt(), r.getDecidedAt(),
                    actions.stream().map(ActionView::of).toList(), r.getVersion());
        }
    }
}
