package com.ags.health.hr.assessment.entities;

import com.ags.health.hr.assessment.enums.AssessmentCategory;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.math.BigDecimal;

@Entity
@Table(name = "asm_assessment_definition")
@Getter
@Setter
@NoArgsConstructor
public class AssessmentDefinition extends CommonEntity {

    @Id
    private String code;

    @Column(nullable = false)
    private String name;

    @Column(name = "provider_code", nullable = false)
    private String providerCode;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private AssessmentCategory category = AssessmentCategory.OTHER;

    @Column(name = "external_test_id")
    private String externalTestId;

    @Column(name = "cooling_key")
    private String coolingKey;

    @Column(name = "pass_score")
    private BigDecimal passScore;

    @Column(name = "max_score")
    private BigDecimal maxScore;

    @Column(name = "grade_bands")
    private String gradeBands;

    @Column(name = "validity_days")
    private Integer validityDays;

    @Column(name = "link_validity_days")
    private Integer linkValidityDays;

    private String settings;

    @Column(nullable = false)
    private boolean active = true;
}
