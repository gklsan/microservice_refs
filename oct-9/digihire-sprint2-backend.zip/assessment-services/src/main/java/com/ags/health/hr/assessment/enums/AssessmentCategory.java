package com.ags.health.hr.assessment.enums;

public enum AssessmentCategory { LANGUAGE, COGNITIVE, TYPING, TECHNICAL, OTHER }
