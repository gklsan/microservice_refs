package com.ags.health.hr.assessment.providers;

import com.fasterxml.jackson.databind.JsonNode;

import java.math.BigDecimal;
import java.time.Instant;
import java.time.OffsetDateTime;
import java.time.format.DateTimeParseException;

final class JsonValues {

    private JsonValues() {
    }

    static JsonNode at(JsonNode node, String pointer) {
        if (node == null || pointer == null || pointer.isBlank()) {
            return null;
        }
        JsonNode v = pointer.startsWith("/") ? node.at(pointer) : node.get(pointer);
        return v == null || v.isMissingNode() || v.isNull() ? null : v;
    }

    static String text(JsonNode node, String pointer) {
        JsonNode v = at(node, pointer);
        if (v == null) {
            return null;
        }
        String s = v.asText();
        return s == null || s.isBlank() ? null : s.trim();
    }

    static BigDecimal number(JsonNode node, String pointer) {
        JsonNode v = at(node, pointer);
        if (v == null) {
            return null;
        }
        if (v.isNumber()) {
            return new BigDecimal(v.asText());
        }
        try {
            String s = v.asText().trim();
            return s.isEmpty() ? null : new BigDecimal(s);
        } catch (NumberFormatException e) {
            return null;
        }
    }

    static Instant instant(JsonNode node, String pointer) {
        String s = text(node, pointer);
        if (s == null) {
            return null;
        }
        try {
            return Instant.parse(s);
        } catch (DateTimeParseException e) {
            try {
                return OffsetDateTime.parse(s).toInstant();
            } catch (DateTimeParseException e2) {
                return null;
            }
        }
    }
}
