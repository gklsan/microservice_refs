package com.ags.health.hr.assessment.resources;

import com.ags.health.hr.assessment.entities.AssessmentDefinition;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface AssessmentDefinitionRepository extends JpaRepository<AssessmentDefinition, String> {

    List<AssessmentDefinition> findAllByOrderByCodeAsc();
}
