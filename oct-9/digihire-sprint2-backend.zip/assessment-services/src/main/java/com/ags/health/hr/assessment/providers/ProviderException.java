package com.ags.health.hr.assessment.providers;

public class ProviderException extends RuntimeException {

    private final String code;

    public ProviderException(String code, String message) {
        this(code, message, null);
    }

    public ProviderException(String code, String message, Throwable cause) {
        super(message, cause);
        this.code = code;
    }

    public String code() {
        return code;
    }
}
