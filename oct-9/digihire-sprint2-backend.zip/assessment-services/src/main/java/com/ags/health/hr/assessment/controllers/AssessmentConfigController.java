package com.ags.health.hr.assessment.controllers;

import com.ags.health.hr.assessment.data.DefinitionDtos;
import com.ags.health.hr.assessment.data.MappingDtos;
import com.ags.health.hr.assessment.enums.TriggerEvent;
import com.ags.health.hr.assessment.providers.ProviderRegistry;
import com.ags.health.hr.assessment.services.AssessmentConfigService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.Map;
import java.util.UUID;

@RestController
@RequestMapping("/config")
@RequiredArgsConstructor
public class AssessmentConfigController {

    private final AssessmentConfigService service;
    private final ProviderRegistry providers;

    @GetMapping("/assessments")
    @PreAuthorize("hasAnyAuthority('ASSESSMENT_CONFIG:VIEW', 'ASSESSMENT:VIEW')")
    public List<DefinitionDtos.View> definitions() {
        return service.definitions();
    }

    @GetMapping("/assessments/{code}")
    @PreAuthorize("hasAnyAuthority('ASSESSMENT_CONFIG:VIEW', 'ASSESSMENT:VIEW')")
    public DefinitionDtos.View definition(@PathVariable String code) {
        return service.definition(code);
    }

    @PostMapping("/assessments")
    @PreAuthorize("hasAuthority('ASSESSMENT_CONFIG:MANAGE')")
    public ResponseEntity<DefinitionDtos.View> create(@Valid @RequestBody DefinitionDtos.Upsert req) {
        return new ResponseEntity<>(service.create(req), HttpStatus.CREATED);
    }

    @PutMapping("/assessments/{code}")
    @PreAuthorize("hasAuthority('ASSESSMENT_CONFIG:MANAGE')")
    public DefinitionDtos.View update(@PathVariable String code, @Valid @RequestBody DefinitionDtos.Upsert req) {
        return service.update(code, req);
    }

    @GetMapping("/mappings")
    @PreAuthorize("hasAuthority('ASSESSMENT_CONFIG:VIEW')")
    public List<MappingDtos.View> mappings() {
        return service.mappings();
    }

    @GetMapping("/mappings/preview")
    @PreAuthorize("hasAnyAuthority('ASSESSMENT_CONFIG:VIEW', 'ASSESSMENT:VIEW')")
    public List<MappingDtos.View> preview(@RequestParam TriggerEvent event,
                                          @RequestParam(required = false) String lob,
                                          @RequestParam(required = false) String roleCode,
                                          @RequestParam(required = false) String location,
                                          @RequestParam(required = false) String stage) {
        return service.preview(event, lob, roleCode, location, stage);
    }

    @PostMapping("/mappings")
    @PreAuthorize("hasAuthority('ASSESSMENT_CONFIG:MANAGE')")
    public ResponseEntity<MappingDtos.View> createMapping(@Valid @RequestBody MappingDtos.Request req) {
        return new ResponseEntity<>(service.createMapping(req), HttpStatus.CREATED);
    }

    @PutMapping("/mappings/{id}")
    @PreAuthorize("hasAuthority('ASSESSMENT_CONFIG:MANAGE')")
    public MappingDtos.View updateMapping(@PathVariable UUID id, @Valid @RequestBody MappingDtos.Request req) {
        return service.updateMapping(id, req);
    }

    @GetMapping("/providers")
    @PreAuthorize("hasAuthority('ASSESSMENT_CONFIG:VIEW')")
    public List<Map<String, Object>> providers() {
        return providers.all().stream().map(p -> Map.<String, Object>of("code", p.code(), "polling", p.supportsPolling(),
                "callback", p.supportsCallback(), "manualResults", p.acceptsManualResults())).toList();
    }
}
