package com.ags.health.hr.assessment.enums;

public enum ApplicationEventType { CREATED, WALKED_IN, STAGE_CHANGED, REJECTED }
