package com.ags.health.hr.assessment.entities;

import com.ags.health.hr.assessment.enums.BlacklistStatus;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.Instant;
import java.util.UUID;

@Entity
@Table(name = "asm_blacklist")
@Getter
@Setter
@NoArgsConstructor
public class BlacklistEntry extends CommonEntity {

    @Id
    private UUID id;

    @Column(name = "candidate_id")
    private String candidateId;

    @Column(name = "display_name")
    private String displayName;

    @Column(name = "masked_email")
    private String maskedEmail;

    @Column(name = "masked_mobile")
    private String maskedMobile;

    @Column(name = "email_hash")
    private String emailHash;

    @Column(name = "mobile_hash")
    private String mobileHash;

    @Column(name = "id_proof_hash")
    private String idProofHash;

    @Column(name = "reason_code", nullable = false)
    private String reasonCode;

    private String remarks;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private BlacklistStatus status;

    @Column(name = "blacklisted_by")
    private String blacklistedBy;

    @Column(name = "blacklisted_at", nullable = false)
    private Instant blacklistedAt;

    @Column(name = "removal_request_id")
    private UUID removalRequestId;

    @Column(name = "removed_by")
    private String removedBy;

    @Column(name = "removed_at")
    private Instant removedAt;

    @Column(name = "removal_reason")
    private String removalReason;

    public boolean isBlocking() {
        return status == BlacklistStatus.ACTIVE || status == BlacklistStatus.REMOVAL_PENDING;
    }
}
