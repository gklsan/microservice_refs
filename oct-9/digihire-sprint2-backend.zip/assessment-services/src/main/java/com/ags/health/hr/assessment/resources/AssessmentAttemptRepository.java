package com.ags.health.hr.assessment.resources;

import com.ags.health.hr.assessment.entities.AssessmentAttempt;
import com.ags.health.hr.assessment.enums.AttemptStatus;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.time.Instant;
import java.util.Collection;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

public interface AssessmentAttemptRepository extends JpaRepository<AssessmentAttempt, UUID> {

    List<AssessmentAttempt> findByCandidateIdOrderByCreatedDateDesc(String candidateId);

    List<AssessmentAttempt> findByCandidateIdAndCoolingKeyOrderByCreatedDateAsc(String candidateId, String coolingKey);

    List<AssessmentAttempt> findByCandidateIdAndAssessmentCodeOrderByCreatedDateDesc(String candidateId, String assessmentCode);

    Optional<AssessmentAttempt> findFirstByProviderCodeAndExternalRef(String providerCode, String externalRef);

    List<AssessmentAttempt> findTop200ByProviderCodeAndStatusInOrderByInvitedAtAsc(String providerCode, Collection<AttemptStatus> statuses);

    @Query("select a from AssessmentAttempt a where a.status = :status and a.linkExpiresAt < :now")
    List<AssessmentAttempt> findExpiredLinks(@Param("status") AttemptStatus status, @Param("now") Instant now);

    @Query("select a from AssessmentAttempt a where a.passed = true and a.validUntil < :now and a.validityExpiredAt is null")
    List<AssessmentAttempt> findNewlyExpiredScores(@Param("now") Instant now);

    @Query("""
            select a from AssessmentAttempt a
            where (:candidateId is null or a.candidateId = :candidateId)
              and (:applicationId is null or a.applicationId = :applicationId)
              and (:assessmentCode is null or a.assessmentCode = :assessmentCode)
              and (:status is null or a.status = :status)
            """)
    Page<AssessmentAttempt> search(@Param("candidateId") String candidateId,
                                   @Param("applicationId") String applicationId,
                                   @Param("assessmentCode") String assessmentCode,
                                   @Param("status") AttemptStatus status,
                                   Pageable pageable);
}
