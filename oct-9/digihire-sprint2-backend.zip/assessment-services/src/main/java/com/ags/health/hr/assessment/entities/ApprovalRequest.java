package com.ags.health.hr.assessment.entities;

import com.ags.health.hr.assessment.enums.ApprovalStatus;
import com.ags.health.hr.assessment.enums.ApprovalSubjectType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.Instant;
import java.util.UUID;

@Entity
@Table(name = "asm_approval_request")
@Getter
@Setter
@NoArgsConstructor
public class ApprovalRequest extends CommonEntity {

    @Id
    private UUID id;

    @Enumerated(EnumType.STRING)
    @Column(name = "subject_type", nullable = false)
    private ApprovalSubjectType subjectType;

    @Column(name = "subject_id", nullable = false)
    private String subjectId;

    @Column(name = "flow_code", nullable = false)
    private String flowCode;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private ApprovalStatus status;

    @Column(name = "current_level", nullable = false)
    private int currentLevel;

    @Column(name = "total_levels", nullable = false)
    private int totalLevels;

    @Column(name = "candidate_id")
    private String candidateId;

    @Column(name = "requested_by_id")
    private String requestedById;

    @Column(name = "requested_by_email")
    private String requestedByEmail;

    @Column(name = "requested_by_name")
    private String requestedByName;

    @Column(name = "reason_code")
    private String reasonCode;

    private String reason;

    private String lob;

    private String location;

    @Column(name = "requested_at", nullable = false)
    private Instant requestedAt;

    @Column(name = "decided_at")
    private Instant decidedAt;
}
