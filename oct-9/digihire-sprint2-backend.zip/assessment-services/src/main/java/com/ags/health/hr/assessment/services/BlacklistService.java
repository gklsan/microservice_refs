package com.ags.health.hr.assessment.services;

import com.ags.health.hr.assessment.data.ApprovalDtos;
import com.ags.health.hr.assessment.data.BlacklistDtos;
import com.ags.health.hr.assessment.data.PageResponse;
import com.ags.health.hr.assessment.entities.ApprovalRequest;
import com.ags.health.hr.assessment.entities.BlacklistEntry;
import com.ags.health.hr.assessment.entities.BlacklistReason;
import com.ags.health.hr.assessment.enums.ApprovalSubjectType;
import com.ags.health.hr.assessment.enums.AuditCategory;
import com.ags.health.hr.assessment.enums.BlacklistStatus;
import com.ags.health.hr.assessment.exceptions.APIException;
import com.ags.health.hr.assessment.resources.ApprovalRequestRepository;
import com.ags.health.hr.assessment.resources.BlacklistReasonRepository;
import com.ags.health.hr.assessment.resources.BlacklistRepository;
import com.ags.health.hr.assessment.security.SecurityUtils;
import com.ags.health.hr.assessment.utils.Masking;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Pageable;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import java.sql.Timestamp;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;
import java.util.stream.Collectors;

@Service
@Transactional
@RequiredArgsConstructor
public class BlacklistService implements ApprovalSubjectHandler {

    public static final String REMOVE_APPROVE = "BLACKLIST:REMOVE_APPROVE";
    private static final List<BlacklistStatus> BLOCKING = List.of(BlacklistStatus.ACTIVE, BlacklistStatus.REMOVAL_PENDING);

    private final BlacklistRepository entries;
    private final BlacklistReasonRepository reasons;
    private final ApprovalRequestRepository approvalRequests;
    private final IdentityHasher hasher;
    private final RuleSettings rules;
    private final AuditService audit;
    private final OutboxService outbox;
    private final JdbcTemplate jdbc;
    private final ObjectMapper mapper;
    private final ApprovalWorkflowService workflow;

    @Override
    public ApprovalSubjectType type() {
        return ApprovalSubjectType.BLACKLIST_REMOVAL;
    }

    @Override
    public String approvePermission() {
        return REMOVE_APPROVE;
    }

    public BlacklistDtos.View add(BlacklistDtos.AddRequest req) {
        BlacklistReason reason = reasons.findById(req.reasonCode().trim().toUpperCase(Locale.ROOT))
                .filter(BlacklistReason::isActive)
                .orElseThrow(() -> APIException.badRequest("UNKNOWN_REASON", "Unknown or retired blacklist reason: " + req.reasonCode()));
        if ("OTHER".equals(reason.getCode()) && !StringUtils.hasText(req.remarks())) {
            throw APIException.badRequest("REMARKS_REQUIRED", "Remarks are required when the reason is OTHER");
        }
        IdentityHasher.Hashes h = hasher.hash(req.email(), req.mobile(), req.idProofNumber());
        String candidateId = trim(req.candidateId());
        if (candidateId == null && h.isEmpty()) {
            throw APIException.badRequest("IDENTIFIER_REQUIRED", "Give a candidate id, e-mail, mobile or ID proof number");
        }
        if (!entries.findMatches(BLOCKING, candidateId, h.email(), h.mobile(), h.idProof()).isEmpty()) {
            throw APIException.conflict("ALREADY_BLACKLISTED", "This candidate is already blacklisted");
        }
        BlacklistEntry b = new BlacklistEntry();
        b.setId(UUID.randomUUID());
        b.setCandidateId(candidateId);
        b.setDisplayName(trim(req.candidateName()));
        b.setMaskedEmail(Masking.maskEmail(req.email()));
        b.setMaskedMobile(Masking.maskMobile(req.mobile()));
        b.setEmailHash(h.email());
        b.setMobileHash(h.mobile());
        b.setIdProofHash(h.idProof());
        b.setReasonCode(reason.getCode());
        b.setRemarks(trim(req.remarks()));
        b.setStatus(BlacklistStatus.ACTIVE);
        b.setBlacklistedBy(SecurityUtils.currentActorName());
        b.setBlacklistedAt(Instant.now());
        entries.save(b);
        audit.log(AuditCategory.SECURITY, "CANDIDATE_BLACKLISTED", "BLACKLIST", b.getId(), candidateId, AuditService.details(
                "reasonCode", reason.getCode(), "remarks", b.getRemarks(), "identifiers", identifiers(b)));
        outbox.publish("CANDIDATE_BLACKLISTED", "BLACKLIST", b.getId(), candidateId, null, AuditService.details(
                "blacklistId", b.getId(), "reasonCode", reason.getCode()));
        return BlacklistDtos.View.of(b, reason.getLabel());
    }

    @Transactional(readOnly = true)
    public BlacklistDtos.CheckResult check(String candidateId, String email, String mobile, String idProof) {
        IdentityHasher.Hashes h = hasher.hash(email, mobile, idProof);
        String cid = trim(candidateId);
        if (cid == null && h.isEmpty()) {
            return new BlacklistDtos.CheckResult(false, List.of());
        }
        Map<String, String> labels = labels();
        List<BlacklistDtos.Match> matches = new ArrayList<>();
        for (BlacklistEntry b : entries.findMatches(BLOCKING, cid, h.email(), h.mobile(), h.idProof())) {
            List<String> on = new ArrayList<>();
            if (cid != null && cid.equals(b.getCandidateId())) {
                on.add("CANDIDATE_ID");
            }
            if (h.email() != null && h.email().equals(b.getEmailHash())) {
                on.add("EMAIL");
            }
            if (h.mobile() != null && h.mobile().equals(b.getMobileHash())) {
                on.add("MOBILE");
            }
            if (h.idProof() != null && h.idProof().equals(b.getIdProofHash())) {
                on.add("ID_PROOF");
            }
            matches.add(new BlacklistDtos.Match(b.getId(), b.getReasonCode(), labels.get(b.getReasonCode()), b.getStatus(),
                    b.getBlacklistedAt(), on));
        }
        return new BlacklistDtos.CheckResult(!matches.isEmpty(), matches);
    }

    public BlacklistDtos.Detail requestRemoval(UUID id, String reason) {
        BlacklistEntry b = find(id);
        if (b.getStatus() != BlacklistStatus.ACTIVE) {
            throw APIException.conflict("NOT_ACTIVE", "Only an active blacklist entry can be removed (status " + b.getStatus() + ")");
        }
        if (rules.blacklistRemovalRequiresApproval()) {
            ApprovalRequest r = workflow.create(ApprovalSubjectType.BLACKLIST_REMOVAL, b.getId().toString(), b.getCandidateId(),
                    null, reason, null, null);
            b.setStatus(BlacklistStatus.REMOVAL_PENDING);
            b.setRemovalRequestId(r.getId());
            b.setRemovalReason(reason.trim());
            audit.log(AuditCategory.APPROVAL, "BLACKLIST_REMOVAL_REQUESTED", "BLACKLIST", b.getId(), b.getCandidateId(),
                    AuditService.details("requestId", r.getId(), "reason", reason.trim()));
        } else {
            if (!SecurityUtils.hasAuthority(REMOVE_APPROVE)) {
                throw APIException.forbidden("ACCESS_DENIED", "Removing a blacklist entry needs " + REMOVE_APPROVE);
            }
            b.setRemovalReason(reason.trim());
            remove(b, SecurityUtils.currentActorName());
        }
        return detail(b);
    }

    @Override
    public void onApproved(ApprovalRequest request) {
        BlacklistEntry b = find(UUID.fromString(request.getSubjectId()));
        remove(b, SecurityUtils.currentActorName());
    }

    @Override
    public void onRejected(ApprovalRequest request) {
        BlacklistEntry b = find(UUID.fromString(request.getSubjectId()));
        if (b.getStatus() == BlacklistStatus.REMOVAL_PENDING) {
            b.setStatus(BlacklistStatus.ACTIVE);
            b.setRemovalRequestId(null);
            b.setRemovalReason(null);
            audit.log(AuditCategory.APPROVAL, "BLACKLIST_REMOVAL_DECLINED", "BLACKLIST", b.getId(), b.getCandidateId(),
                    AuditService.details("requestId", request.getId(), "status", request.getStatus()));
        }
    }

    @Transactional(readOnly = true)
    public PageResponse<BlacklistDtos.View> search(BlacklistStatus status, String reasonCode, String candidateId, Pageable pageable) {
        Map<String, String> labels = labels();
        return PageResponse.of(entries.search(status, reasonCode == null ? null : reasonCode.toUpperCase(Locale.ROOT),
                trim(candidateId), pageable).map(b -> BlacklistDtos.View.of(b, labels.get(b.getReasonCode()))));
    }

    @Transactional(readOnly = true)
    public BlacklistDtos.Detail get(UUID id) {
        return detail(find(id));
    }

    @Transactional(readOnly = true)
    public List<BlacklistDtos.ReasonView> reasons() {
        return reasons.findAllByOrderBySortOrderAscCodeAsc().stream().map(BlacklistDtos.ReasonView::of).toList();
    }

    public BlacklistDtos.ReasonView upsertReason(String code, BlacklistDtos.ReasonUpsert req, boolean create) {
        BlacklistReason r;
        if (create) {
            if (reasons.existsById(req.code())) {
                throw APIException.conflict("REASON_EXISTS", "Reason already exists: " + req.code());
            }
            r = new BlacklistReason();
            r.setCode(req.code());
        } else {
            r = reasons.findById(code).orElseThrow(() -> APIException.notFound("Blacklist reason", code));
            if (!r.getCode().equals(req.code())) {
                throw APIException.badRequest("CODE_IMMUTABLE", "Reason code can not change");
            }
            AssessmentConfigService.checkVersion(r.getVersion(), req.version());
        }
        r.setLabel(req.label().trim());
        r.setActive(req.active() == null || req.active());
        r.setSortOrder(req.sortOrder() == null ? 0 : req.sortOrder());
        reasons.save(r);
        audit.log(AuditCategory.CONFIG_CHANGE, create ? "BLACKLIST_REASON_CREATED" : "BLACKLIST_REASON_UPDATED",
                "BLACKLIST_REASON", r.getCode(), null, AuditService.details("label", r.getLabel(), "active", r.isActive()));
        return BlacklistDtos.ReasonView.of(r);
    }

    private void remove(BlacklistEntry b, String actor) {
        b.setStatus(BlacklistStatus.REMOVED);
        b.setRemovedAt(Instant.now());
        b.setRemovedBy(actor);
        audit.log(AuditCategory.SECURITY, "CANDIDATE_UNBLACKLISTED", "BLACKLIST", b.getId(), b.getCandidateId(),
                AuditService.details("reason", b.getRemovalReason(), "requestId", b.getRemovalRequestId()));
        outbox.publish("CANDIDATE_UNBLACKLISTED", "BLACKLIST", b.getId(), b.getCandidateId(), null,
                AuditService.details("blacklistId", b.getId()));
    }

    private BlacklistDtos.Detail detail(BlacklistEntry b) {
        ApprovalDtos.View removal = b.getRemovalRequestId() == null ? null
                : approvalRequests.findById(b.getRemovalRequestId()).map(workflow::view).orElse(null);
        String label = reasons.findById(b.getReasonCode()).map(BlacklistReason::getLabel).orElse(null);
        return new BlacklistDtos.Detail(BlacklistDtos.View.of(b, label), removal, history(b.getId()));
    }

    private List<BlacklistDtos.HistoryEntry> history(UUID id) {
        return jdbc.query("SELECT occurred_at, action, actor_email, actor_name, CAST(details AS VARCHAR(8000)) AS details_text "
                        + "FROM adm_audit_log WHERE entity_type = 'BLACKLIST' AND entity_id = ? ORDER BY occurred_at DESC LIMIT 100",
                (rs, i) -> {
                    Timestamp at = rs.getTimestamp("occurred_at");
                    return new BlacklistDtos.HistoryEntry(at == null ? null : at.toInstant(), rs.getString("action"),
                            rs.getString("actor_email"), rs.getString("actor_name"), parse(rs.getString("details_text")));
                }, id.toString());
    }

    private Object parse(String json) {
        if (json == null) {
            return null;
        }
        try {
            var node = mapper.readTree(json);
            return node.isTextual() ? mapper.readTree(node.asText()) : node;
        } catch (Exception e) {
            return json;
        }
    }

    private Map<String, String> labels() {
        return reasons.findAll().stream().collect(Collectors.toMap(BlacklistReason::getCode, BlacklistReason::getLabel,
                (a, b) -> a));
    }

    private BlacklistEntry find(UUID id) {
        return entries.findById(id).orElseThrow(() -> APIException.notFound("Blacklist entry", id));
    }

    private static List<String> identifiers(BlacklistEntry b) {
        List<String> ids = new ArrayList<>();
        if (b.getCandidateId() != null) {
            ids.add("CANDIDATE_ID");
        }
        if (b.getEmailHash() != null) {
            ids.add("EMAIL");
        }
        if (b.getMobileHash() != null) {
            ids.add("MOBILE");
        }
        if (b.getIdProofHash() != null) {
            ids.add("ID_PROOF");
        }
        return ids;
    }

    private static String trim(String s) {
        return StringUtils.hasText(s) ? s.trim() : null;
    }
}
