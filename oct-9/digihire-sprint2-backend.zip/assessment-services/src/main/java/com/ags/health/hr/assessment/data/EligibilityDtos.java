package com.ags.health.hr.assessment.data;

import com.ags.health.hr.assessment.enums.EligibilityPurpose;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

import java.math.BigDecimal;
import java.time.Instant;
import java.util.List;
import java.util.UUID;

public final class EligibilityDtos {

    private EligibilityDtos() {
    }

    public record Request(@Size(max = 64) String candidateId,
                          @Size(max = 254) String email,
                          @Size(max = 20) String mobile,
                          @Size(max = 40) String idProofNumber,
                          @Size(max = 50) String assessmentCode,
                          @Size(max = 100) String lob,
                          @Size(max = 100) String roleCode,
                          @Size(max = 100) String location,
                          @NotNull EligibilityPurpose purpose) {
    }

    public record Reason(String code, String message, Instant until, boolean blocking) {
    }

    public record ValidScore(UUID attemptId, String assessmentCode, BigDecimal score, String grade, Instant completedAt,
                             Instant validUntil) {
    }

    public record Result(boolean eligible, List<Reason> reasons, ValidScore validScore) {

        public boolean has(String code) {
            return reasons.stream().anyMatch(r -> r.code().equals(code));
        }
    }
}
