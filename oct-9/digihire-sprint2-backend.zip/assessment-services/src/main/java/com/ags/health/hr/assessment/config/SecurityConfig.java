package com.ags.health.hr.assessment.config;

import com.ags.health.hr.assessment.clients.AccessDirectory;
import com.ags.health.hr.assessment.security.CorrelationIdFilter;
import com.ags.health.hr.assessment.security.InternalApiKeyFilter;
import com.ags.health.hr.assessment.security.JwtAuthFilter;
import com.ags.health.hr.assessment.security.ProblemResponseWriter;
import com.ags.health.hr.assessment.security.TransportSecurityFilter;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;
import org.springframework.security.web.authentication.www.BasicAuthenticationFilter;
import org.springframework.security.web.context.SecurityContextHolderFilter;

@Configuration
@EnableMethodSecurity
public class SecurityConfig {

    private static final String[] PUBLIC = {"/actuator/health/**", "/actuator/info", "/error", "/callbacks/**"};
    private static final String[] SWAGGER = {"/swagger-ui.html", "/swagger-ui/**", "/v3/api-docs/**"};

    @Bean
    public ProblemResponseWriter problemResponseWriter(ObjectMapper mapper) {
        return new ProblemResponseWriter(mapper);
    }

    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http, AssessmentProperties props, AccessDirectory access,
                                                   ProblemResponseWriter problems,
                                                   @Value("${springdoc.swagger-ui.enabled:true}") boolean swaggerEnabled)
            throws Exception {
        JwtAuthFilter jwtFilter = new JwtAuthFilter(props.getSecurity().getJwtSecret(), access, problems);
        InternalApiKeyFilter internalFilter = new InternalApiKeyFilter(props.getSecurity().getInternalApiKey());
        TransportSecurityFilter transportFilter = new TransportSecurityFilter(props.getSecurity().isRequireHttps(), problems);

        http.csrf(c -> c.disable())
            .cors(c -> c.disable())
            .httpBasic(b -> b.disable())
            .formLogin(f -> f.disable())
            .sessionManagement(s -> s.sessionCreationPolicy(SessionCreationPolicy.STATELESS))
            .authorizeHttpRequests(auth -> auth
                    .requestMatchers(HttpMethod.OPTIONS, "/**").permitAll()
                    .requestMatchers(PUBLIC).permitAll()
                    .requestMatchers(swaggerEnabled ? SWAGGER : new String[]{"/__swagger-disabled__"}).permitAll()
                    .requestMatchers("/internal/**").hasRole("INTERNAL")
                    .anyRequest().authenticated())
            .exceptionHandling(e -> e
                    .authenticationEntryPoint(problems.entryPoint())
                    .accessDeniedHandler(problems.accessDeniedHandler()))
            .addFilterBefore(new CorrelationIdFilter(), SecurityContextHolderFilter.class)
            .addFilterBefore(transportFilter, SecurityContextHolderFilter.class)
            .addFilterBefore(internalFilter, UsernamePasswordAuthenticationFilter.class)
            .addFilterBefore(jwtFilter, BasicAuthenticationFilter.class);
        return http.build();
    }
}
