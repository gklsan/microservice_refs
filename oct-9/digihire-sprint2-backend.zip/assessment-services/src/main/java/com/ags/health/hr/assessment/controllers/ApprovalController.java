package com.ags.health.hr.assessment.controllers;

import com.ags.health.hr.assessment.data.ApprovalDtos;
import com.ags.health.hr.assessment.enums.ApprovalDecision;
import com.ags.health.hr.assessment.enums.ApprovalStatus;
import com.ags.health.hr.assessment.enums.ApprovalSubjectType;
import com.ags.health.hr.assessment.services.ApprovalWorkflowService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.UUID;

@RestController
@RequestMapping("/approvals")
@RequiredArgsConstructor
public class ApprovalController {

    private static final String ANY = "hasAnyAuthority('ASSESSMENT:RESCHEDULE_REQUEST', 'ASSESSMENT:RESCHEDULE_APPROVE', "
            + "'BLACKLIST:REMOVE_REQUEST', 'BLACKLIST:REMOVE_APPROVE')";
    private static final String DECIDE = "hasAnyAuthority('ASSESSMENT:RESCHEDULE_APPROVE', 'BLACKLIST:REMOVE_APPROVE')";
    private static final String REQUEST = "hasAnyAuthority('ASSESSMENT:RESCHEDULE_REQUEST', 'BLACKLIST:REMOVE_REQUEST')";

    private final ApprovalWorkflowService workflow;

    @GetMapping
    @PreAuthorize(ANY)
    public List<ApprovalDtos.View> list(@RequestParam(required = false) ApprovalSubjectType subjectType,
                                        @RequestParam(required = false) ApprovalStatus status,
                                        @RequestParam(required = false) String candidateId,
                                        @RequestParam(defaultValue = "false") boolean mine) {
        return workflow.list(subjectType, status, candidateId, mine);
    }

    @GetMapping("/{id}")
    @PreAuthorize(ANY)
    public ApprovalDtos.View get(@PathVariable UUID id) {
        return workflow.get(id);
    }

    @PostMapping("/{id}/approve")
    @PreAuthorize(DECIDE)
    public ApprovalDtos.View approve(@PathVariable UUID id, @Valid @RequestBody(required = false) ApprovalDtos.Decision req) {
        return workflow.decide(id, ApprovalDecision.APPROVE, req == null ? null : req.comment());
    }

    @PostMapping("/{id}/reject")
    @PreAuthorize(DECIDE)
    public ApprovalDtos.View reject(@PathVariable UUID id, @Valid @RequestBody ApprovalDtos.Decision req) {
        return workflow.decide(id, ApprovalDecision.REJECT, req.comment());
    }

    @PostMapping("/{id}/cancel")
    @PreAuthorize(REQUEST)
    public ApprovalDtos.View cancel(@PathVariable UUID id) {
        return workflow.cancel(id);
    }
}
