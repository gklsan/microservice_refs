package com.ags.health.hr.assessment.clients;

import java.util.List;
import java.util.UUID;

public interface ApprovalDirectory {

    record Approver(UUID adminUserId, String smartieUserId, String email, String fullName, boolean delegate) {
    }

    record ChainLevel(int levelNo, String name, int minApprovals, Integer slaHours, boolean fallbackUsed,
                      boolean unresolved, List<Approver> approvers) {
    }

    record ApprovalChain(String flowCode, String flowName, boolean active, List<ChainLevel> levels) {

        public ChainLevel level(int levelNo) {
            return levels == null ? null : levels.stream().filter(l -> l.levelNo() == levelNo).findFirst().orElse(null);
        }
    }

    record ApprovalCheck(boolean allowed, String reason, int levelNo, int totalLevels, int minApprovals) {
    }

    ApprovalChain resolve(String flowCode, String requesterId, String requesterEmail, String lob, String location);

    ApprovalCheck canApprove(String flowCode, int level, String approverId, String approverEmail,
                             String requesterId, String requesterEmail, String lob, String location);
}
