package com.ags.health.hr.assessment.resources;

import com.ags.health.hr.assessment.entities.CandidateRestriction;
import com.ags.health.hr.assessment.enums.RestrictionType;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.UUID;

public interface CandidateRestrictionRepository extends JpaRepository<CandidateRestriction, UUID> {

    List<CandidateRestriction> findByCandidateIdAndRestrictionTypeAndActiveTrue(String candidateId, RestrictionType type);

    List<CandidateRestriction> findByCandidateIdOrderByStartsAtDesc(String candidateId);

    List<CandidateRestriction> findBySourceAttemptIdAndActiveTrue(UUID sourceAttemptId);
}
