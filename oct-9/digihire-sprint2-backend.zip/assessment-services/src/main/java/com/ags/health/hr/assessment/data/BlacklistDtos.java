package com.ags.health.hr.assessment.data;

import com.ags.health.hr.assessment.entities.BlacklistEntry;
import com.ags.health.hr.assessment.entities.BlacklistReason;
import com.ags.health.hr.assessment.enums.BlacklistStatus;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;

import java.time.Instant;
import java.util.List;
import java.util.UUID;

public final class BlacklistDtos {

    private BlacklistDtos() {
    }

    public record AddRequest(@Size(max = 64) String candidateId,
                             @Size(max = 200) String candidateName,
                             @Email @Size(max = 254) String email,
                             @Size(max = 20) String mobile,
                             @Size(max = 40) String idProofNumber,
                             @NotBlank @Size(max = 40) String reasonCode,
                             @Size(max = 1000) String remarks) {
    }

    public record CheckRequest(@Size(max = 64) String candidateId,
                               @Size(max = 254) String email,
                               @Size(max = 20) String mobile,
                               @Size(max = 40) String idProofNumber) {
    }

    public record Match(UUID id, String reasonCode, String reasonLabel, BlacklistStatus status, Instant since,
                        List<String> matchedOn) {
    }

    public record CheckResult(boolean blacklisted, List<Match> matches) {
    }

    public record RemovalRequest(@NotBlank @Size(max = 1000) String reason) {
    }

    public record ReasonUpsert(@NotBlank @Pattern(regexp = "[A-Z][A-Z0-9_]{1,39}") String code,
                               @NotBlank @Size(max = 200) String label,
                               Boolean active,
                               @Min(0) @Max(10000) Integer sortOrder,
                               Long version) {
    }

    public record ReasonView(String code, String label, boolean active, int sortOrder, Long version) {

        public static ReasonView of(BlacklistReason r) {
            return new ReasonView(r.getCode(), r.getLabel(), r.isActive(), r.getSortOrder(), r.getVersion());
        }
    }

    public record View(UUID id, String candidateId, String displayName, String maskedEmail, String maskedMobile,
                       boolean idProofOnFile, String reasonCode, String reasonLabel, String remarks, BlacklistStatus status,
                       String blacklistedBy, Instant blacklistedAt, UUID removalRequestId, String removedBy,
                       Instant removedAt, String removalReason, Long version) {

        public static View of(BlacklistEntry b, String reasonLabel) {
            return new View(b.getId(), b.getCandidateId(), b.getDisplayName(), b.getMaskedEmail(), b.getMaskedMobile(),
                    b.getIdProofHash() != null, b.getReasonCode(), reasonLabel, b.getRemarks(), b.getStatus(),
                    b.getBlacklistedBy(), b.getBlacklistedAt(), b.getRemovalRequestId(), b.getRemovedBy(), b.getRemovedAt(),
                    b.getRemovalReason(), b.getVersion());
        }
    }

    public record HistoryEntry(Instant occurredAt, String action, String actorEmail, String actorName, Object details) {
    }

    public record Detail(View entry, ApprovalDtos.View removalRequest, List<HistoryEntry> history) {
    }
}
