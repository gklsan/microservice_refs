package com.ags.health.hr.assessment.services;

import com.ags.health.hr.assessment.clients.ApprovalDirectory;
import com.ags.health.hr.assessment.data.ApprovalDtos;
import com.ags.health.hr.assessment.entities.ApprovalAction;
import com.ags.health.hr.assessment.entities.ApprovalRequest;
import com.ags.health.hr.assessment.enums.ApprovalDecision;
import com.ags.health.hr.assessment.enums.ApprovalStatus;
import com.ags.health.hr.assessment.enums.ApprovalSubjectType;
import com.ags.health.hr.assessment.enums.AuditCategory;
import com.ags.health.hr.assessment.exceptions.APIException;
import com.ags.health.hr.assessment.resources.ApprovalActionRepository;
import com.ags.health.hr.assessment.resources.ApprovalRequestRepository;
import com.ags.health.hr.assessment.security.CurrentUser;
import com.ags.health.hr.assessment.security.SecurityUtils;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.ObjectProvider;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

@Service
@Transactional
@RequiredArgsConstructor
public class ApprovalWorkflowService {

    private final ApprovalRequestRepository requests;
    private final ApprovalActionRepository actions;
    private final ApprovalDirectory directory;
    private final ObjectProvider<ApprovalSubjectHandler> handlers;
    private final AuditService audit;
    private final OutboxService outbox;

    public ApprovalRequest create(ApprovalSubjectType type, String subjectId, String candidateId, String reasonCode,
                                  String reason, String lob, String location) {
        CurrentUser requester = SecurityUtils.requireUser();
        if (!requests.findBySubjectTypeAndSubjectIdAndStatus(type, subjectId, ApprovalStatus.PENDING).isEmpty()) {
            throw APIException.conflict("APPROVAL_ALREADY_PENDING", "An approval request is already pending for this record");
        }
        ApprovalDirectory.ApprovalChain chain = directory.resolve(type.name(), requester.userId(), requester.email(), lob, location);
        if (chain == null || !chain.active() || chain.levels() == null || chain.levels().isEmpty()) {
            throw APIException.conflict("APPROVAL_FLOW_INACTIVE", "Approval flow " + type.name() + " is not active in admin-services");
        }
        ApprovalDirectory.ChainLevel first = chain.level(1);
        if (first == null || first.unresolved()) {
            throw APIException.conflict("NO_APPROVER", "No approver is configured for " + type.name()
                    + ". Ask an admin to set the approval hierarchy for this LOB / location.");
        }
        ApprovalRequest r = new ApprovalRequest();
        r.setId(UUID.randomUUID());
        r.setSubjectType(type);
        r.setSubjectId(subjectId);
        r.setFlowCode(type.name());
        r.setStatus(ApprovalStatus.PENDING);
        r.setCurrentLevel(1);
        r.setTotalLevels(chain.levels().size());
        r.setCandidateId(candidateId);
        r.setRequestedById(requester.userId());
        r.setRequestedByEmail(requester.email());
        r.setRequestedByName(requester.displayName());
        r.setReasonCode(reasonCode);
        r.setReason(reason == null ? null : reason.trim());
        r.setLob(lob);
        r.setLocation(location);
        r.setRequestedAt(Instant.now());
        requests.save(r);
        audit.log(AuditCategory.APPROVAL, "APPROVAL_REQUESTED", type.name(), subjectId, candidateId, AuditService.details(
                "requestId", r.getId(), "reasonCode", reasonCode, "reason", r.getReason(), "levels", r.getTotalLevels()));
        outbox.publish("APPROVAL_REQUESTED", "APPROVAL", r.getId(), candidateId, null, AuditService.details(
                "requestId", r.getId(), "subjectType", type, "subjectId", subjectId, "level", 1,
                "approvers", first.approvers().stream().map(ApprovalDirectory.Approver::email).toList(),
                "requestedBy", requester.email(), "reason", r.getReason()));
        return r;
    }

    public ApprovalDtos.View decide(UUID id, ApprovalDecision decision, String comment) {
        ApprovalRequest r = find(id);
        if (r.getStatus() != ApprovalStatus.PENDING) {
            throw APIException.conflict("APPROVAL_CLOSED", "This request is already " + r.getStatus());
        }
        ApprovalSubjectHandler handler = handler(r.getSubjectType());
        if (!SecurityUtils.hasAuthority(handler.approvePermission())) {
            throw APIException.forbidden("ACCESS_DENIED", "You need " + handler.approvePermission() + " to decide this request");
        }
        CurrentUser actor = SecurityUtils.requireUser();
        if (isRequester(r, actor)) {
            throw APIException.forbidden("SELF_APPROVAL", "You can not approve your own request");
        }
        if (decision == ApprovalDecision.REJECT && !StringUtils.hasText(comment)) {
            throw APIException.badRequest("REASON_REQUIRED", "Give a reason for rejecting");
        }
        boolean alreadyActed = actions.findByRequestIdOrderByActedAtAsc(r.getId()).stream()
                .anyMatch(a -> a.getLevelNo() == r.getCurrentLevel() && sameActor(a, actor));
        if (alreadyActed) {
            throw APIException.conflict("ALREADY_DECIDED", "You already decided this level");
        }
        ApprovalDirectory.ApprovalCheck check = directory.canApprove(r.getFlowCode(), r.getCurrentLevel(), actor.userId(),
                actor.email(), r.getRequestedById(), r.getRequestedByEmail(), r.getLob(), r.getLocation());
        if (check == null || !check.allowed()) {
            throw APIException.forbidden("NOT_AN_APPROVER", "You are not an approver for level " + r.getCurrentLevel()
                    + (check == null ? "" : " (" + check.reason() + ")"));
        }

        ApprovalAction a = new ApprovalAction();
        a.setId(UUID.randomUUID());
        a.setRequestId(r.getId());
        a.setLevelNo(r.getCurrentLevel());
        a.setDecision(decision);
        a.setActorId(actor.userId());
        a.setActorEmail(actor.email());
        a.setActorName(actor.displayName());
        a.setComment(comment == null ? null : comment.trim());
        a.setActedAt(Instant.now());
        actions.save(a);
        audit.log(AuditCategory.APPROVAL, "APPROVAL_" + decision.name(), r.getSubjectType().name(), r.getSubjectId(),
                r.getCandidateId(), AuditService.details("requestId", r.getId(), "level", r.getCurrentLevel(),
                        "comment", a.getComment()));

        if (decision == ApprovalDecision.REJECT) {
            close(r, ApprovalStatus.REJECTED);
            handler.onRejected(r);
        } else {
            long approvals = actions.findByRequestIdOrderByActedAtAsc(r.getId()).stream()
                    .filter(x -> x.getLevelNo() == r.getCurrentLevel() && x.getDecision() == ApprovalDecision.APPROVE).count();
            if (approvals >= Math.max(1, check.minApprovals())) {
                if (r.getCurrentLevel() >= r.getTotalLevels()) {
                    close(r, ApprovalStatus.APPROVED);
                    handler.onApproved(r);
                } else {
                    r.setCurrentLevel(r.getCurrentLevel() + 1);
                    outbox.publish("APPROVAL_LEVEL_ADVANCED", "APPROVAL", r.getId(), r.getCandidateId(), null,
                            AuditService.details("requestId", r.getId(), "subjectType", r.getSubjectType(),
                                    "subjectId", r.getSubjectId(), "level", r.getCurrentLevel()));
                }
            }
        }
        return view(r);
    }

    public ApprovalDtos.View cancel(UUID id) {
        ApprovalRequest r = find(id);
        if (r.getStatus() != ApprovalStatus.PENDING) {
            throw APIException.conflict("APPROVAL_CLOSED", "This request is already " + r.getStatus());
        }
        CurrentUser actor = SecurityUtils.requireUser();
        if (!isRequester(r, actor)) {
            throw APIException.forbidden("NOT_REQUESTER", "Only the requester can cancel this request");
        }
        close(r, ApprovalStatus.CANCELLED);
        audit.log(AuditCategory.APPROVAL, "APPROVAL_CANCELLED", r.getSubjectType().name(), r.getSubjectId(), r.getCandidateId(),
                AuditService.details("requestId", r.getId()));
        handler(r.getSubjectType()).onCancelled(r);
        return view(r);
    }

    @Transactional(readOnly = true)
    public ApprovalDtos.View get(UUID id) {
        return view(find(id));
    }

    @Transactional(readOnly = true)
    public List<ApprovalDtos.View> list(ApprovalSubjectType type, ApprovalStatus status, String candidateId, boolean mine) {
        List<ApprovalRequest> rows = requests.search(type, status, candidateId);
        if (!mine) {
            return rows.stream().map(this::view).toList();
        }
        CurrentUser me = SecurityUtils.requireUser();
        List<ApprovalDtos.View> out = new ArrayList<>();
        for (ApprovalRequest r : rows) {
            if (r.getStatus() != ApprovalStatus.PENDING || isRequester(r, me)) {
                continue;
            }
            if (!SecurityUtils.hasAuthority(handler(r.getSubjectType()).approvePermission())) {
                continue;
            }
            ApprovalDirectory.ApprovalCheck check = directory.canApprove(r.getFlowCode(), r.getCurrentLevel(), me.userId(),
                    me.email(), r.getRequestedById(), r.getRequestedByEmail(), r.getLob(), r.getLocation());
            if (check != null && check.allowed()) {
                out.add(view(r));
            }
        }
        return out;
    }

    @Transactional(readOnly = true)
    public ApprovalDtos.View view(ApprovalRequest r) {
        return ApprovalDtos.View.of(r, actions.findByRequestIdOrderByActedAtAsc(r.getId()));
    }

    private void close(ApprovalRequest r, ApprovalStatus status) {
        r.setStatus(status);
        r.setDecidedAt(Instant.now());
        outbox.publish("APPROVAL_" + status.name(), "APPROVAL", r.getId(), r.getCandidateId(), null, AuditService.details(
                "requestId", r.getId(), "subjectType", r.getSubjectType(), "subjectId", r.getSubjectId(),
                "requestedBy", r.getRequestedByEmail()));
    }

    private ApprovalRequest find(UUID id) {
        return requests.findById(id).orElseThrow(() -> APIException.notFound("Approval request", id));
    }

    private ApprovalSubjectHandler handler(ApprovalSubjectType type) {
        return handlers.orderedStream().filter(h -> h.type() == type).findFirst()
                .orElseThrow(() -> new IllegalStateException("No handler for " + type));
    }

    private static boolean isRequester(ApprovalRequest r, CurrentUser u) {
        return (u.email() != null && u.email().equalsIgnoreCase(r.getRequestedByEmail()))
                || (u.userId() != null && u.userId().equals(r.getRequestedById()));
    }

    private static boolean sameActor(ApprovalAction a, CurrentUser u) {
        return (u.email() != null && u.email().equalsIgnoreCase(a.getActorEmail()))
                || (u.userId() != null && u.userId().equals(a.getActorId()));
    }
}
