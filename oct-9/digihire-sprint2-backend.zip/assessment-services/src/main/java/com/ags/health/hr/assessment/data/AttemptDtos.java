package com.ags.health.hr.assessment.data;

import com.ags.health.hr.assessment.entities.AssessmentAttempt;
import com.ags.health.hr.assessment.entities.CandidateRestriction;
import com.ags.health.hr.assessment.enums.AttemptStatus;
import com.ags.health.hr.assessment.enums.RestrictionType;
import com.ags.health.hr.assessment.enums.TriggerSource;
import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

import java.math.BigDecimal;
import java.time.Instant;
import java.util.List;
import java.util.UUID;

public final class AttemptDtos {

    private AttemptDtos() {
    }

    public record InviteRequest(@NotBlank @Size(max = 64) String candidateId,
                                @Size(max = 64) String applicationId,
                                @Email @Size(max = 254) String candidateEmail,
                                @Size(max = 200) String candidateName,
                                @Size(max = 20) String mobile,
                                @NotBlank @Size(max = 50) String assessmentCode,
                                @Size(max = 100) String lob,
                                @Size(max = 100) String roleCode,
                                @Size(max = 100) String location) {
    }

    public record ManualResult(@NotNull @DecimalMin("0") BigDecimal score,
                               @Size(max = 20) String grade,
                               Instant completedAt,
                               @Size(max = 500) String remarks) {
    }

    public record ReasonBody(@NotBlank @Size(max = 500) String reason) {
    }

    public record View(UUID id, String candidateId, String applicationId, String candidateName, String assessmentCode,
                       String providerCode, int attemptNo, AttemptStatus status, String testUrl, Instant invitedAt,
                       Instant linkExpiresAt, Instant startedAt, Instant completedAt, Instant resultReceivedAt,
                       BigDecimal score, String grade, Boolean passed, Instant validUntil, boolean scoreValid,
                       Instant coolingUntil, Integer coolingTier, boolean reapplyAsFresher, int rescheduleCount,
                       UUID rescheduledFrom, String lob, String roleCode, String location, TriggerSource triggerSource,
                       String triggeredBy, String statusReason, Instant createdDate, Instant updatedDate, Long version) {

        public static View of(AssessmentAttempt a, Instant now) {
            return new View(a.getId(), a.getCandidateId(), a.getApplicationId(), a.getCandidateName(), a.getAssessmentCode(),
                    a.getProviderCode(), a.getAttemptNo(), a.getStatus(), a.getTestUrl(), a.getInvitedAt(), a.getLinkExpiresAt(),
                    a.getStartedAt(), a.getCompletedAt(), a.getResultReceivedAt(), a.getScore(), a.getGrade(), a.getPassed(),
                    a.getValidUntil(), a.isScoreValid(now), a.getCoolingUntil(), a.getCoolingTier(), a.isFresherReset(),
                    a.getRescheduleCount(), a.getRescheduledFrom(), a.getLob(), a.getRoleCode(), a.getLocation(),
                    a.getTriggerSource(), a.getTriggeredBy(), a.getStatusReason(), a.getCreatedDate(), a.getUpdatedDate(),
                    a.getVersion());
        }
    }

    public record CoolingView(String coolingKey, Instant until, Integer tier, boolean reapplyAsFresher, UUID attemptId) {
    }

    public record RestrictionView(UUID id, RestrictionType type, String reason, String sourceRoleCode, String sourceLocation,
                                  Instant startsAt, Instant endsAt, boolean inForce) {

        public static RestrictionView of(CandidateRestriction r, Instant now) {
            return new RestrictionView(r.getId(), r.getRestrictionType(), r.getReason(), r.getSourceRoleCode(),
                    r.getSourceLocation(), r.getStartsAt(), r.getEndsAt(), r.isInForce(now));
        }
    }

    public record CandidateSummary(String candidateId, boolean blacklisted, List<View> attempts, List<View> validScores,
                                   List<CoolingView> cooling, List<RestrictionView> restrictions) {
    }
}
