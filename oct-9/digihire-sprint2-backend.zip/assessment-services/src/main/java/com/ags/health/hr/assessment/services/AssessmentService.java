package com.ags.health.hr.assessment.services;

import com.ags.health.hr.assessment.config.AssessmentProperties;
import com.ags.health.hr.assessment.data.AttemptDtos;
import com.ags.health.hr.assessment.data.EligibilityDtos;
import com.ags.health.hr.assessment.data.EventDtos;
import com.ags.health.hr.assessment.data.PageResponse;
import com.ags.health.hr.assessment.entities.AssessmentAttempt;
import com.ags.health.hr.assessment.entities.AssessmentDefinition;
import com.ags.health.hr.assessment.enums.AttemptStatus;
import com.ags.health.hr.assessment.enums.AuditCategory;
import com.ags.health.hr.assessment.enums.EligibilityPurpose;
import com.ags.health.hr.assessment.enums.TriggerSource;
import com.ags.health.hr.assessment.exceptions.APIException;
import com.ags.health.hr.assessment.exceptions.IneligibleException;
import com.ags.health.hr.assessment.providers.AssessmentProvider;
import com.ags.health.hr.assessment.providers.InviteContext;
import com.ags.health.hr.assessment.providers.ProviderException;
import com.ags.health.hr.assessment.providers.ProviderInvite;
import com.ags.health.hr.assessment.providers.ProviderRegistry;
import com.ags.health.hr.assessment.providers.ProviderResult;
import com.ags.health.hr.assessment.enums.ProviderResultStatus;
import com.ags.health.hr.assessment.resources.AssessmentAttemptRepository;
import com.ags.health.hr.assessment.resources.CandidateRestrictionRepository;
import com.ags.health.hr.assessment.security.SecurityUtils;
import com.ags.health.hr.assessment.utils.CoolingPolicy;
import com.ags.health.hr.assessment.utils.GradingPolicy;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import java.math.BigDecimal;
import java.time.Duration;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.EnumSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

@Slf4j
@Service
@Transactional
@RequiredArgsConstructor
public class AssessmentService {

    private static final Set<AttemptStatus> COUNTED = EnumSet.of(AttemptStatus.COMPLETED, AttemptStatus.FAILED,
            AttemptStatus.NOT_TAKEN, AttemptStatus.EXPIRED);
    private static final Set<AttemptStatus> RESULT_ACCEPTING = EnumSet.of(AttemptStatus.INVITED, AttemptStatus.IN_PROGRESS,
            AttemptStatus.EXPIRED);

    private final AssessmentAttemptRepository attempts;
    private final CandidateRestrictionRepository restrictions;
    private final AssessmentConfigService config;
    private final EligibilityService eligibility;
    private final VoiceFresherService voiceFresher;
    private final BlacklistService blacklist;
    private final ProviderRegistry providers;
    private final RuleSettings rules;
    private final AuditService audit;
    private final OutboxService outbox;
    private final AssessmentProperties props;

    public AttemptDtos.View invite(AttemptDtos.InviteRequest req) {
        AssessmentDefinition def = activeDefinition(req.assessmentCode());
        AssessmentProvider provider = providers.get(def.getProviderCode());
        EligibilityDtos.Result result = eligibility.check(new EligibilityDtos.Request(req.candidateId(), req.candidateEmail(),
                req.mobile(), null, def.getCode(), req.lob(), req.roleCode(), req.location(), EligibilityPurpose.ASSESSMENT));
        if (!result.eligible()) {
            audit.logDetached(AuditCategory.ACTIVITY, "ASSESSMENT_INVITE_BLOCKED", "ASSESSMENT_ATTEMPT", null, req.candidateId(),
                    "DENIED", null, AuditService.details("assessment", def.getCode(), "reasons", result.reasons()));
            throw new IneligibleException(result.reasons());
        }
        AssessmentAttempt a = newAttempt(def, req.candidateId(), req.applicationId(), req.candidateEmail(), req.candidateName(),
                req.lob(), req.roleCode(), req.location(), TriggerSource.MANUAL, nextAttemptNo(req.candidateId(), def.getCode()));
        send(a, def, provider);
        return AttemptDtos.View.of(a, Instant.now());
    }

    public AttemptDtos.View autoInvite(EventDtos.ApplicationEvent ev, AssessmentDefinition def) {
        AssessmentProvider provider = providers.get(def.getProviderCode());
        AssessmentAttempt a = newAttempt(def, ev.candidateId(), ev.applicationId(), ev.candidateEmail(), ev.candidateName(),
                ev.lob(), ev.roleCode(), ev.location(), TriggerSource.AUTO, nextAttemptNo(ev.candidateId(), def.getCode()));
        send(a, def, provider);
        return AttemptDtos.View.of(a, Instant.now());
    }

    public AttemptDtos.View inviteReschedule(AssessmentAttempt original) {
        AssessmentDefinition def = config.definitionEntity(original.getAssessmentCode());
        AssessmentProvider provider = providers.get(def.getProviderCode());
        if (blacklist.check(original.getCandidateId(), null, null, null).blacklisted()) {
            throw APIException.conflict("NOT_ELIGIBLE", "Candidate was blacklisted after the reschedule request");
        }
        AssessmentAttempt a = newAttempt(def, original.getCandidateId(), original.getApplicationId(), original.getCandidateEmail(),
                original.getCandidateName(), original.getLob(), original.getRoleCode(), original.getLocation(),
                TriggerSource.RESCHEDULE, original.getAttemptNo());
        a.setRescheduleCount(original.getRescheduleCount() + 1);
        a.setRescheduledFrom(original.getId());
        send(a, def, provider);
        return AttemptDtos.View.of(a, Instant.now());
    }

    public AttemptDtos.View retry(UUID id) {
        AssessmentAttempt a = find(id);
        if (a.getStatus() != AttemptStatus.ERROR) {
            throw APIException.conflict("RETRY_NOT_ALLOWED", "Only attempts whose invite failed can be retried");
        }
        AssessmentDefinition def = activeDefinition(a.getAssessmentCode());
        a.setLinkExpiresAt(Instant.now().plus(Duration.ofDays(linkValidityDays(def))));
        send(a, def, providers.get(def.getProviderCode()));
        return AttemptDtos.View.of(a, Instant.now());
    }

    public AttemptDtos.View manualResult(UUID id, AttemptDtos.ManualResult req) {
        AssessmentAttempt a = find(id);
        AssessmentProvider provider = providers.get(a.getProviderCode());
        if (!provider.acceptsManualResults()) {
            throw APIException.conflict("MANUAL_RESULT_NOT_ALLOWED", a.getProviderCode() + " results come from the provider");
        }
        if (!RESULT_ACCEPTING.contains(a.getStatus())) {
            throw APIException.conflict("ATTEMPT_CLOSED", "Attempt is already " + a.getStatus());
        }
        Instant done = req.completedAt() == null ? Instant.now() : req.completedAt();
        if (done.isAfter(Instant.now().plus(Duration.ofMinutes(5)))) {
            throw APIException.badRequest("INVALID_COMPLETED_AT", "completedAt is in the future");
        }
        complete(a, req.score(), trim(req.grade()), done, req.remarks(), "MANUAL");
        return AttemptDtos.View.of(a, Instant.now());
    }

    public AttemptDtos.View refresh(UUID id) {
        AssessmentAttempt a = find(id);
        AssessmentProvider provider = providers.get(a.getProviderCode());
        if (!provider.supportsPolling() || a.getExternalRef() == null) {
            throw APIException.conflict("REFRESH_NOT_SUPPORTED", a.getProviderCode() + " results can not be polled");
        }
        List<ProviderResult> results;
        try {
            results = provider.fetchResults(List.of(a.getExternalRef()));
        } catch (RuntimeException e) {
            throw new APIException(HttpStatus.BAD_GATEWAY, "PROVIDER_UNAVAILABLE", a.getProviderCode() + " did not answer: " + e.getMessage());
        }
        results.stream().filter(r -> a.getExternalRef().equals(r.externalRef())).findFirst().ifPresent(r -> apply(a, r, "REFRESH"));
        return AttemptDtos.View.of(a, Instant.now());
    }

    public AttemptDtos.View cancel(UUID id, String reason) {
        AssessmentAttempt a = find(id);
        if (!a.getStatus().isOpen() && a.getStatus() != AttemptStatus.ERROR) {
            throw APIException.conflict("ATTEMPT_CLOSED", "Attempt is already " + a.getStatus());
        }
        cancelAtProvider(a);
        a.setStatus(AttemptStatus.CANCELLED);
        a.setStatusReason(trim(reason));
        audit.log(AuditCategory.WORKFLOW_TRANSITION, "ASSESSMENT_CANCELLED", "ASSESSMENT_ATTEMPT", a.getId(), a.getCandidateId(),
                AuditService.details("reason", a.getStatusReason()));
        event("ASSESSMENT_CANCELLED", a);
        return AttemptDtos.View.of(a, Instant.now());
    }

    public boolean recordProviderResult(String providerCode, ProviderResult r) {
        AssessmentAttempt a = r.attemptId() != null ? attempts.findById(r.attemptId()).orElse(null) : null;
        if (a == null && r.externalRef() != null) {
            a = attempts.findFirstByProviderCodeAndExternalRef(providerCode, r.externalRef()).orElse(null);
        }
        if (a == null) {
            log.warn("{} result for unknown attempt {} / {}", providerCode, r.attemptId(), r.externalRef());
            return false;
        }
        if (!a.getProviderCode().equalsIgnoreCase(providerCode)) {
            log.warn("{} result references attempt {} owned by {}", providerCode, a.getId(), a.getProviderCode());
            return false;
        }
        return apply(a, r, "PROVIDER");
    }

    public void handleCallback(String providerCode, Map<String, String> headers, String body) {
        AssessmentProvider provider = providers.get(providerCode);
        ProviderResult r;
        try {
            r = provider.parseCallback(headers, body);
        } catch (ProviderException e) {
            audit.logDetached(AuditCategory.SECURITY, "ASSESSMENT_CALLBACK_REJECTED", "PROVIDER", provider.code(), null, "DENIED",
                    e.getMessage(), AuditService.details("code", e.code()));
            HttpStatus status = "INVALID_SIGNATURE".equals(e.code()) ? HttpStatus.UNAUTHORIZED : HttpStatus.BAD_REQUEST;
            throw new APIException(status, e.code(), e.getMessage());
        }
        if (!recordProviderResult(provider.code(), r)) {
            throw APIException.notFound("Assessment attempt", r.attemptId() != null ? r.attemptId() : r.externalRef());
        }
    }

    @Transactional(readOnly = true)
    public List<String> openRefs(String providerCode) {
        return attempts.findTop200ByProviderCodeAndStatusInOrderByInvitedAtAsc(providerCode,
                        EnumSet.of(AttemptStatus.INVITED, AttemptStatus.IN_PROGRESS)).stream()
                .map(AssessmentAttempt::getExternalRef).filter(StringUtils::hasText).toList();
    }

    public int expireLinks() {
        Instant now = Instant.now();
        List<AssessmentAttempt> expired = attempts.findExpiredLinks(AttemptStatus.INVITED, now);
        for (AssessmentAttempt a : expired) {
            a.setStatus(AttemptStatus.EXPIRED);
            a.setStatusReason("Link expired before the candidate started");
            audit.log(AuditCategory.WORKFLOW_TRANSITION, "ASSESSMENT_LINK_EXPIRED", "ASSESSMENT_ATTEMPT", a.getId(),
                    a.getCandidateId(), AuditService.details("expiredAt", a.getLinkExpiresAt().toString()));
            event("ASSESSMENT_LINK_EXPIRED", a);
        }
        return expired.size();
    }

    public int expireScores() {
        Instant now = Instant.now();
        List<AssessmentAttempt> expired = attempts.findNewlyExpiredScores(now);
        for (AssessmentAttempt a : expired) {
            a.setValidityExpiredAt(now);
            audit.log(AuditCategory.WORKFLOW_TRANSITION, "ASSESSMENT_SCORE_VALIDITY_EXPIRED", "ASSESSMENT_ATTEMPT", a.getId(),
                    a.getCandidateId(), AuditService.details("assessment", a.getAssessmentCode(), "completedAt",
                            String.valueOf(a.getCompletedAt()), "validUntil", String.valueOf(a.getValidUntil())));
            Map<String, Object> payload = payload(a);
            payload.put("action", "MOVE_TO_FRESHER_PIPELINE");
            outbox.publish("ASSESSMENT_SCORE_EXPIRED", "ASSESSMENT_ATTEMPT", a.getId(), a.getCandidateId(), a.getApplicationId(), payload);
        }
        return expired.size();
    }

    @Transactional(readOnly = true)
    public PageResponse<AttemptDtos.View> search(String candidateId, String applicationId, String assessmentCode,
                                                 AttemptStatus status, Pageable pageable) {
        Instant now = Instant.now();
        return PageResponse.of(attempts.search(trim(candidateId), trim(applicationId),
                assessmentCode == null ? null : assessmentCode.trim().toUpperCase(), status, pageable)
                .map(a -> AttemptDtos.View.of(a, now)));
    }

    @Transactional(readOnly = true)
    public AttemptDtos.View get(UUID id) {
        return AttemptDtos.View.of(find(id), Instant.now());
    }

    @Transactional(readOnly = true)
    public AttemptDtos.CandidateSummary summary(String candidateId) {
        Instant now = Instant.now();
        List<AssessmentAttempt> all = attempts.findByCandidateIdOrderByCreatedDateDesc(candidateId);
        List<AttemptDtos.View> views = all.stream().map(a -> AttemptDtos.View.of(a, now)).toList();
        Map<String, AttemptDtos.CoolingView> cooling = new LinkedHashMap<>();
        all.stream().filter(a -> a.getCoolingKey() != null && a.getCoolingUntil() != null && a.getCoolingUntil().isAfter(now))
                .sorted(Comparator.comparing(AssessmentAttempt::getCoolingUntil).reversed())
                .forEach(a -> cooling.putIfAbsent(a.getCoolingKey(), new AttemptDtos.CoolingView(a.getCoolingKey(),
                        a.getCoolingUntil(), a.getCoolingTier(), a.isFresherReset(), a.getId())));
        return new AttemptDtos.CandidateSummary(candidateId, blacklist.check(candidateId, null, null, null).blacklisted(), views,
                views.stream().filter(AttemptDtos.View::scoreValid).toList(), new ArrayList<>(cooling.values()),
                restrictions.findByCandidateIdOrderByStartsAtDesc(candidateId).stream()
                        .map(r -> AttemptDtos.RestrictionView.of(r, now)).toList());
    }

    @Transactional(readOnly = true)
    public List<AttemptDtos.View> validScores(String candidateId) {
        Instant now = Instant.now();
        return attempts.findByCandidateIdOrderByCreatedDateDesc(candidateId).stream().filter(a -> a.isScoreValid(now))
                .map(a -> AttemptDtos.View.of(a, now)).toList();
    }

    public AssessmentAttempt find(UUID id) {
        return attempts.findById(id).orElseThrow(() -> APIException.notFound("Assessment attempt", id));
    }

    private boolean apply(AssessmentAttempt a, ProviderResult r, String source) {
        if (!RESULT_ACCEPTING.contains(a.getStatus())) {
            return false;
        }
        Instant now = Instant.now();
        ProviderResultStatus status = r.status() == null ? ProviderResultStatus.PENDING : r.status();
        switch (status) {
            case PENDING -> {
                return false;
            }
            case IN_PROGRESS -> {
                if (a.getStatus() != AttemptStatus.INVITED) {
                    return false;
                }
                a.setStatus(AttemptStatus.IN_PROGRESS);
                a.setStartedAt(r.startedAt() != null ? r.startedAt() : now);
                event("ASSESSMENT_STARTED", a);
                return true;
            }
            case NOT_TAKEN -> {
                a.setStatus(AttemptStatus.NOT_TAKEN);
                a.setResultReceivedAt(now);
                a.setRawResult(truncate(r.raw(), 8000));
                audit.log(AuditCategory.WORKFLOW_TRANSITION, "ASSESSMENT_NOT_TAKEN", "ASSESSMENT_ATTEMPT", a.getId(),
                        a.getCandidateId(), AuditService.details("source", source));
                event("ASSESSMENT_NOT_TAKEN", a);
                return true;
            }
            case EXPIRED -> {
                if (a.getStatus() == AttemptStatus.EXPIRED) {
                    return false;
                }
                a.setStatus(AttemptStatus.EXPIRED);
                a.setStatusReason("Provider reported the link expired");
                event("ASSESSMENT_LINK_EXPIRED", a);
                return true;
            }
            case COMPLETED -> {
                if (r.startedAt() != null && a.getStartedAt() == null) {
                    a.setStartedAt(r.startedAt());
                }
                complete(a, r.score(), r.grade(), r.completedAt() != null ? r.completedAt() : now, r.raw(), source);
                return true;
            }
            default -> {
                return false;
            }
        }
    }

    private void complete(AssessmentAttempt a, BigDecimal score, String grade, Instant done, String raw, String source) {
        AssessmentDefinition def = config.definitionEntity(a.getAssessmentCode());
        GradingPolicy.Outcome outcome = GradingPolicy.grade(score, def.getPassScore(), config.bands(def), grade);
        Instant now = Instant.now();
        a.setScore(score);
        a.setGrade(outcome.grade());
        a.setPassed(outcome.passed());
        a.setCompletedAt(done);
        a.setResultReceivedAt(now);
        a.setRawResult(truncate(raw, 8000));
        if (outcome.passed()) {
            a.setStatus(AttemptStatus.COMPLETED);
            a.setValidUntil(done.plus(Duration.ofDays(validityDays(def))));
        } else {
            a.setStatus(AttemptStatus.FAILED);
            applyCooling(a);
            voiceFresher.onRejection(a.getCandidateId(), a.getCandidateEmail(), a.getApplicationId(), a.getId(), a.getRoleCode(),
                    a.getLocation(), "Failed " + a.getAssessmentCode());
        }
        audit.log(AuditCategory.WORKFLOW_TRANSITION, "ASSESSMENT_RESULT_RECORDED", "ASSESSMENT_ATTEMPT", a.getId(),
                a.getCandidateId(), AuditService.details("assessment", a.getAssessmentCode(), "source", source,
                        "score", score, "grade", a.getGrade(), "passed", a.getPassed(),
                        "validUntil", a.getValidUntil() == null ? null : a.getValidUntil().toString(),
                        "coolingUntil", a.getCoolingUntil() == null ? null : a.getCoolingUntil().toString(),
                        "coolingTier", a.getCoolingTier(), "reapplyAsFresher", a.isFresherReset()));
        event(outcome.passed() ? "ASSESSMENT_COMPLETED" : "ASSESSMENT_FAILED", a);
    }

    private void applyCooling(AssessmentAttempt a) {
        if (a.getCoolingKey() == null) {
            return;
        }
        List<AssessmentAttempt> history = attempts.findByCandidateIdAndCoolingKeyOrderByCreatedDateAsc(a.getCandidateId(),
                a.getCoolingKey());
        if (history.stream().noneMatch(x -> x.getId().equals(a.getId()))) {
            history = new ArrayList<>(history);
            history.add(a);
        }
        int failures = CoolingPolicy.failuresInCurrentCycle(history);
        CoolingPolicy.decide(rules.coolingDays(a.getCoolingKey()), failures).ifPresent(d -> {
            a.setCoolingTier(d.tier());
            a.setCoolingUntil(a.getCompletedAt().plus(Duration.ofDays(d.days())));
            a.setFresherReset(d.fresherReset());
        });
    }

    private AssessmentAttempt newAttempt(AssessmentDefinition def, String candidateId, String applicationId, String email,
                                         String name, String lob, String roleCode, String location, TriggerSource source,
                                         int attemptNo) {
        AssessmentAttempt a = new AssessmentAttempt();
        a.setId(UUID.randomUUID());
        a.setCandidateId(candidateId.trim());
        a.setApplicationId(trim(applicationId));
        a.setCandidateEmail(email == null ? null : email.trim().toLowerCase());
        a.setCandidateName(trim(name));
        a.setAssessmentCode(def.getCode());
        a.setProviderCode(def.getProviderCode());
        a.setCoolingKey(def.getCoolingKey());
        a.setAttemptNo(attemptNo);
        a.setStatus(AttemptStatus.INVITED);
        a.setLob(AssessmentConfigService.norm(lob));
        a.setRoleCode(AssessmentConfigService.norm(roleCode));
        a.setLocation(AssessmentConfigService.norm(location));
        a.setTriggerSource(source);
        a.setTriggeredBy(SecurityUtils.currentActorName());
        a.setLinkExpiresAt(Instant.now().plus(Duration.ofDays(linkValidityDays(def))));
        attempts.save(a);
        return a;
    }

    private void send(AssessmentAttempt a, AssessmentDefinition def, AssessmentProvider provider) {
        try {
            ProviderInvite invite = provider.invite(new InviteContext(a.getId(), a.getCandidateId(), a.getCandidateEmail(),
                    a.getCandidateName(), def.getExternalTestId(), config.settings(def), a.getLinkExpiresAt(), callbackUrl(provider)));
            a.setExternalRef(invite.externalRef());
            a.setTestUrl(invite.testUrl());
            a.setInvitedAt(Instant.now());
            if (invite.expiresAt() != null) {
                a.setLinkExpiresAt(invite.expiresAt());
            }
            a.setStatus(AttemptStatus.INVITED);
            a.setStatusReason(null);
            audit.log(AuditCategory.WORKFLOW_TRANSITION, "ASSESSMENT_INVITED", "ASSESSMENT_ATTEMPT", a.getId(), a.getCandidateId(),
                    AuditService.details("assessment", a.getAssessmentCode(), "provider", a.getProviderCode(),
                            "attemptNo", a.getAttemptNo(), "trigger", a.getTriggerSource(), "externalRef", a.getExternalRef(),
                            "linkExpiresAt", a.getLinkExpiresAt().toString(), "rescheduledFrom", a.getRescheduledFrom()));
            Map<String, Object> payload = payload(a);
            payload.put("testUrl", a.getTestUrl());
            payload.put("candidateEmail", a.getCandidateEmail());
            payload.put("candidateName", a.getCandidateName());
            payload.put("linkExpiresAt", a.getLinkExpiresAt().toString());
            outbox.publish("ASSESSMENT_INVITED", "ASSESSMENT_ATTEMPT", a.getId(), a.getCandidateId(), a.getApplicationId(), payload);
        } catch (RuntimeException e) {
            String code = e instanceof ProviderException pe ? pe.code() : "PROVIDER_ERROR";
            log.warn("Invite for attempt {} via {} failed: {}", a.getId(), provider.code(), e.getMessage());
            a.setStatus(AttemptStatus.ERROR);
            a.setStatusReason(truncate(code + ": " + e.getMessage(), 500));
            audit.log(AuditCategory.WORKFLOW_TRANSITION, "ASSESSMENT_INVITE_FAILED", "ASSESSMENT_ATTEMPT", a.getId(),
                    a.getCandidateId(), "FAILURE", a.getStatusReason(), AuditService.details("provider", provider.code(), "code", code));
            event("ASSESSMENT_INVITE_FAILED", a);
        }
    }

    private void cancelAtProvider(AssessmentAttempt a) {
        if (a.getExternalRef() == null) {
            return;
        }
        providers.find(a.getProviderCode()).ifPresent(p -> {
            try {
                p.cancel(a.getExternalRef());
            } catch (RuntimeException e) {
                log.warn("Provider cancel for {} failed: {}", a.getId(), e.getMessage());
            }
        });
    }

    public void closeForReschedule(AssessmentAttempt a, String reason) {
        if (a.getStatus().isOpen()) {
            cancelAtProvider(a);
        }
        boolean wasFailed = a.getStatus() == AttemptStatus.FAILED;
        a.setStatus(AttemptStatus.RESCHEDULED);
        a.setStatusReason(reason);
        if (wasFailed) {
            a.setPassed(null);
            a.setCoolingUntil(null);
            a.setCoolingTier(null);
            a.setFresherReset(false);
            voiceFresher.liftForAttempt(a.getId(), reason);
        }
        audit.log(AuditCategory.WORKFLOW_TRANSITION, "ASSESSMENT_RESCHEDULED", "ASSESSMENT_ATTEMPT", a.getId(), a.getCandidateId(),
                AuditService.details("reason", reason, "coolingCleared", wasFailed));
        event("ASSESSMENT_RESCHEDULED", a);
    }

    private void event(String type, AssessmentAttempt a) {
        outbox.publish(type, "ASSESSMENT_ATTEMPT", a.getId(), a.getCandidateId(), a.getApplicationId(), payload(a));
    }

    private Map<String, Object> payload(AssessmentAttempt a) {
        return AuditService.details("attemptId", a.getId(), "candidateId", a.getCandidateId(),
                "applicationId", a.getApplicationId(), "assessmentCode", a.getAssessmentCode(), "provider", a.getProviderCode(),
                "attemptNo", a.getAttemptNo(), "status", a.getStatus(), "score", a.getScore(), "grade", a.getGrade(),
                "passed", a.getPassed(), "validUntil", a.getValidUntil() == null ? null : a.getValidUntil().toString(),
                "coolingUntil", a.getCoolingUntil() == null ? null : a.getCoolingUntil().toString(),
                "reapplyAsFresher", a.isFresherReset(), "lob", a.getLob(), "roleCode", a.getRoleCode(),
                "location", a.getLocation());
    }

    private int nextAttemptNo(String candidateId, String code) {
        return 1 + (int) attempts.findByCandidateIdAndAssessmentCodeOrderByCreatedDateDesc(candidateId.trim(), code).stream()
                .filter(x -> COUNTED.contains(x.getStatus())).count();
    }

    private AssessmentDefinition activeDefinition(String code) {
        AssessmentDefinition def = config.definitionEntity(code);
        if (!def.isActive()) {
            throw APIException.conflict("ASSESSMENT_INACTIVE", "Assessment " + def.getCode() + " is not active");
        }
        return def;
    }

    private int validityDays(AssessmentDefinition def) {
        return def.getValidityDays() != null ? def.getValidityDays() : rules.scoreValidityDays();
    }

    private int linkValidityDays(AssessmentDefinition def) {
        return def.getLinkValidityDays() != null ? def.getLinkValidityDays() : rules.linkValidityDays();
    }

    private String callbackUrl(AssessmentProvider provider) {
        String base = props.getCallbacks().getPublicBaseUrl();
        if (!provider.supportsCallback() || base == null || base.isBlank()) {
            return null;
        }
        return (base.endsWith("/") ? base.substring(0, base.length() - 1) : base) + "/callbacks/" + provider.code();
    }

    private static String trim(String s) {
        return StringUtils.hasText(s) ? s.trim() : null;
    }

    private static String truncate(String s, int max) {
        return s == null || s.length() <= max ? s : s.substring(0, max);
    }
}
