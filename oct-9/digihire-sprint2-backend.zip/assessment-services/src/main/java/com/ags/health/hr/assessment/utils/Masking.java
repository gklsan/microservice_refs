package com.ags.health.hr.assessment.utils;

import java.util.Locale;

public final class Masking {

    private Masking() {
    }

    public static String normalizeEmail(String email) {
        return email == null || email.isBlank() ? null : email.trim().toLowerCase(Locale.ROOT);
    }

    public static String normalizeMobile(String mobile) {
        if (mobile == null) {
            return null;
        }
        String digits = mobile.replaceAll("\\D", "");
        if (digits.isEmpty()) {
            return null;
        }
        return digits.length() > 10 ? digits.substring(digits.length() - 10) : digits;
    }

    public static String normalizeIdProof(String id) {
        if (id == null) {
            return null;
        }
        String v = id.replaceAll("[^A-Za-z0-9]", "").toUpperCase(Locale.ROOT);
        return v.isEmpty() ? null : v;
    }

    public static String maskEmail(String email) {
        String e = normalizeEmail(email);
        if (e == null) {
            return null;
        }
        int at = e.indexOf('@');
        if (at <= 0) {
            return "***";
        }
        return e.charAt(0) + "***" + e.substring(at);
    }

    public static String maskMobile(String mobile) {
        String m = normalizeMobile(mobile);
        if (m == null) {
            return null;
        }
        return m.length() <= 4 ? "****" : "******" + m.substring(m.length() - 4);
    }
}
