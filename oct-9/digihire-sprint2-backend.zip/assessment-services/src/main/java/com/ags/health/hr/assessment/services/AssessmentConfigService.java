package com.ags.health.hr.assessment.services;

import com.ags.health.hr.assessment.data.DefinitionDtos;
import com.ags.health.hr.assessment.data.MappingDtos;
import com.ags.health.hr.assessment.entities.AssessmentDefinition;
import com.ags.health.hr.assessment.entities.AssessmentMapping;
import com.ags.health.hr.assessment.enums.AuditCategory;
import com.ags.health.hr.assessment.enums.TriggerEvent;
import com.ags.health.hr.assessment.exceptions.APIException;
import com.ags.health.hr.assessment.providers.ProviderRegistry;
import com.ags.health.hr.assessment.resources.AssessmentDefinitionRepository;
import com.ags.health.hr.assessment.resources.AssessmentMappingRepository;
import com.ags.health.hr.assessment.utils.GradingPolicy;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;
import java.util.UUID;

@Service
@Transactional
@RequiredArgsConstructor
public class AssessmentConfigService {

    private final AssessmentDefinitionRepository definitions;
    private final AssessmentMappingRepository mappings;
    private final ProviderRegistry providers;
    private final AuditService audit;
    private final ObjectMapper mapper;

    @Transactional(readOnly = true)
    public List<DefinitionDtos.View> definitions() {
        return definitions.findAllByOrderByCodeAsc().stream().map(this::view).toList();
    }

    @Transactional(readOnly = true)
    public DefinitionDtos.View definition(String code) {
        return view(definitionEntity(code));
    }

    @Transactional(readOnly = true)
    public AssessmentDefinition definitionEntity(String code) {
        String c = code == null ? null : code.trim().toUpperCase(Locale.ROOT);
        return definitions.findById(c).orElseThrow(() -> APIException.notFound("Assessment", code));
    }

    public DefinitionDtos.View create(DefinitionDtos.Upsert req) {
        if (definitions.existsById(req.code())) {
            throw APIException.conflict("ASSESSMENT_EXISTS", "Assessment already exists: " + req.code());
        }
        AssessmentDefinition d = new AssessmentDefinition();
        d.setCode(req.code());
        apply(d, req);
        definitions.save(d);
        audit.log(AuditCategory.CONFIG_CHANGE, "ASSESSMENT_DEFINITION_CREATED", "ASSESSMENT_DEFINITION", d.getCode(), null,
                snapshot(d));
        return view(d);
    }

    public DefinitionDtos.View update(String code, DefinitionDtos.Upsert req) {
        AssessmentDefinition d = definitionEntity(code);
        if (!d.getCode().equals(req.code())) {
            throw APIException.badRequest("CODE_IMMUTABLE", "Assessment code can not change");
        }
        checkVersion(d.getVersion(), req.version());
        Map<String, Object> before = snapshot(d);
        apply(d, req);
        audit.log(AuditCategory.CONFIG_CHANGE, "ASSESSMENT_DEFINITION_UPDATED", "ASSESSMENT_DEFINITION", d.getCode(), null,
                AuditService.details("before", before, "after", snapshot(d)));
        return view(d);
    }

    @Transactional(readOnly = true)
    public List<MappingDtos.View> mappings() {
        return mappings.findAllByOrderByLobAscRoleCodeAscSequenceNoAsc().stream().map(MappingDtos.View::of).toList();
    }

    public MappingDtos.View createMapping(MappingDtos.Request req) {
        AssessmentMapping m = new AssessmentMapping();
        m.setId(UUID.randomUUID());
        apply(m, req);
        mappings.save(m);
        audit.log(AuditCategory.CONFIG_CHANGE, "ASSESSMENT_MAPPING_CREATED", "ASSESSMENT_MAPPING", m.getId(), null, snapshot(m));
        return MappingDtos.View.of(m);
    }

    public MappingDtos.View updateMapping(UUID id, MappingDtos.Request req) {
        AssessmentMapping m = mappings.findById(id).orElseThrow(() -> APIException.notFound("Assessment mapping", id));
        checkVersion(m.getVersion(), req.version());
        Map<String, Object> before = snapshot(m);
        apply(m, req);
        audit.log(AuditCategory.CONFIG_CHANGE, "ASSESSMENT_MAPPING_UPDATED", "ASSESSMENT_MAPPING", m.getId(), null,
                AuditService.details("before", before, "after", snapshot(m)));
        return MappingDtos.View.of(m);
    }

    @Transactional(readOnly = true)
    public List<AssessmentMapping> matching(TriggerEvent event, String lob, String roleCode, String location, String stage) {
        Map<String, AssessmentMapping> best = new LinkedHashMap<>();
        for (AssessmentMapping m : mappings.findByTriggerEventAndActiveTrue(event)) {
            if (!m.matches(lob, roleCode, location)) {
                continue;
            }
            if (event == TriggerEvent.STAGE_ENTERED
                    && (m.getTriggerStage() == null || stage == null || !m.getTriggerStage().equalsIgnoreCase(stage))) {
                continue;
            }
            AssessmentMapping current = best.get(m.getAssessmentCode());
            if (current == null || m.specificity() > current.specificity()) {
                best.put(m.getAssessmentCode(), m);
            }
        }
        return best.values().stream().sorted(Comparator.comparingInt(AssessmentMapping::getSequenceNo)).toList();
    }

    @Transactional(readOnly = true)
    public List<MappingDtos.View> preview(TriggerEvent event, String lob, String roleCode, String location, String stage) {
        return matching(event, norm(lob), norm(roleCode), norm(location), stage).stream().map(MappingDtos.View::of).toList();
    }

    public List<GradingPolicy.Band> bands(AssessmentDefinition d) {
        try {
            return GradingPolicy.parseBands(mapper, d.getGradeBands());
        } catch (IllegalArgumentException e) {
            return List.of();
        }
    }

    public Map<String, Object> settings(AssessmentDefinition d) {
        if (!StringUtils.hasText(d.getSettings())) {
            return Map.of();
        }
        try {
            return mapper.readValue(d.getSettings(), new TypeReference<Map<String, Object>>() {
            });
        } catch (JsonProcessingException e) {
            return Map.of();
        }
    }

    private void apply(AssessmentDefinition d, DefinitionDtos.Upsert req) {
        String provider = req.providerCode().toUpperCase(Locale.ROOT);
        boolean active = req.active() == null || req.active();
        if (active && providers.find(provider).isEmpty()) {
            throw APIException.badRequest("PROVIDER_DISABLED", "Provider " + provider + " is not enabled. Save the assessment as inactive "
                    + "or enable the provider first.");
        }
        if (req.maxScore() != null && req.passScore() != null && req.passScore().compareTo(req.maxScore()) > 0) {
            throw APIException.badRequest("INVALID_PASS_SCORE", "passScore is above maxScore");
        }
        d.setName(req.name().trim());
        d.setProviderCode(provider);
        d.setCategory(req.category());
        d.setExternalTestId(trim(req.externalTestId()));
        d.setCoolingKey(req.coolingKey());
        d.setPassScore(req.passScore());
        d.setMaxScore(req.maxScore());
        d.setValidityDays(req.validityDays());
        d.setLinkValidityDays(req.linkValidityDays());
        d.setActive(active);
        try {
            d.setGradeBands(req.gradeBands() == null || req.gradeBands().isEmpty() ? null : mapper.writeValueAsString(req.gradeBands()));
            d.setSettings(req.settings() == null || req.settings().isEmpty() ? null : mapper.writeValueAsString(req.settings()));
        } catch (JsonProcessingException e) {
            throw APIException.badRequest("VALIDATION_FAILED", "gradeBands / settings could not be stored");
        }
        if (d.getSettings() != null && d.getSettings().length() > 4000) {
            throw APIException.badRequest("VALIDATION_FAILED", "settings are limited to 4000 characters");
        }
    }

    private void apply(AssessmentMapping m, MappingDtos.Request req) {
        AssessmentDefinition d = definitionEntity(req.assessmentCode());
        if (req.triggerEvent() == TriggerEvent.STAGE_ENTERED && !StringUtils.hasText(req.triggerStage())) {
            throw APIException.badRequest("TRIGGER_STAGE_REQUIRED", "STAGE_ENTERED mappings need a triggerStage");
        }
        m.setLob(norm(req.lob()));
        m.setRoleCode(norm(req.roleCode()));
        m.setLocation(norm(req.location()));
        m.setAssessmentCode(d.getCode());
        m.setSequenceNo(req.sequenceNo() == null ? 1 : req.sequenceNo());
        m.setTriggerEvent(req.triggerEvent());
        m.setTriggerStage(req.triggerEvent() == TriggerEvent.STAGE_ENTERED ? req.triggerStage().trim().toUpperCase(Locale.ROOT) : null);
        m.setMandatory(req.mandatory() == null || req.mandatory());
        m.setActive(req.active() == null || req.active());
    }

    private DefinitionDtos.View view(AssessmentDefinition d) {
        JsonNode settings = null;
        if (StringUtils.hasText(d.getSettings())) {
            try {
                settings = mapper.readTree(d.getSettings());
            } catch (JsonProcessingException ignored) {
                settings = null;
            }
        }
        return DefinitionDtos.view(d, bands(d), settings);
    }

    private static Map<String, Object> snapshot(AssessmentDefinition d) {
        return AuditService.details("name", d.getName(), "provider", d.getProviderCode(), "externalTestId", d.getExternalTestId(),
                "coolingKey", d.getCoolingKey(), "passScore", d.getPassScore(), "gradeBands", d.getGradeBands(),
                "validityDays", d.getValidityDays(), "linkValidityDays", d.getLinkValidityDays(), "active", d.isActive());
    }

    private static Map<String, Object> snapshot(AssessmentMapping m) {
        return AuditService.details("lob", m.getLob(), "roleCode", m.getRoleCode(), "location", m.getLocation(),
                "assessment", m.getAssessmentCode(), "event", m.getTriggerEvent(), "stage", m.getTriggerStage(),
                "sequence", m.getSequenceNo(), "active", m.isActive());
    }

    static void checkVersion(Long current, Long expected) {
        if (expected != null && !Objects.equals(expected, current)) {
            throw APIException.conflict("CONCURRENT_MODIFICATION", "Someone else changed this record. Reload and try again.");
        }
    }

    static String norm(String v) {
        return StringUtils.hasText(v) ? v.trim().toUpperCase(Locale.ROOT) : null;
    }

    private static String trim(String v) {
        return StringUtils.hasText(v) ? v.trim() : null;
    }
}
