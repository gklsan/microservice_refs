package com.ags.health.hr.assessment.services;

import com.ags.health.hr.assessment.entities.ApprovalRequest;
import com.ags.health.hr.assessment.enums.ApprovalSubjectType;

public interface ApprovalSubjectHandler {

    ApprovalSubjectType type();

    String approvePermission();

    void onApproved(ApprovalRequest request);

    void onRejected(ApprovalRequest request);

    default void onCancelled(ApprovalRequest request) {
        onRejected(request);
    }
}
