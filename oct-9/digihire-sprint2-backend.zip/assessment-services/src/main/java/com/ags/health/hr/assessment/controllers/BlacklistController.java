package com.ags.health.hr.assessment.controllers;

import com.ags.health.hr.assessment.data.BlacklistDtos;
import com.ags.health.hr.assessment.data.PageResponse;
import com.ags.health.hr.assessment.enums.BlacklistStatus;
import com.ags.health.hr.assessment.services.BlacklistService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.UUID;

@RestController
@RequestMapping
@RequiredArgsConstructor
public class BlacklistController {

    private final BlacklistService service;

    @GetMapping("/blacklist")
    @PreAuthorize("hasAuthority('BLACKLIST:VIEW')")
    public PageResponse<BlacklistDtos.View> search(@RequestParam(required = false) BlacklistStatus status,
                                                   @RequestParam(required = false) String reasonCode,
                                                   @RequestParam(required = false) String candidateId,
                                                   @RequestParam(defaultValue = "0") int page,
                                                   @RequestParam(defaultValue = "20") int size) {
        return service.search(status, reasonCode, candidateId,
                PageRequest.of(Math.max(page, 0), Math.min(Math.max(size, 1), 100), Sort.by(Sort.Direction.DESC, "blacklistedAt")));
    }

    @GetMapping("/blacklist/{id}")
    @PreAuthorize("hasAuthority('BLACKLIST:VIEW')")
    public BlacklistDtos.Detail get(@PathVariable UUID id) {
        return service.get(id);
    }

    @PostMapping("/blacklist")
    @PreAuthorize("hasAuthority('BLACKLIST:CREATE')")
    public ResponseEntity<BlacklistDtos.View> add(@Valid @RequestBody BlacklistDtos.AddRequest req) {
        return new ResponseEntity<>(service.add(req), HttpStatus.CREATED);
    }

    @PostMapping("/blacklist/check")
    @PreAuthorize("hasAuthority('BLACKLIST:VIEW')")
    public BlacklistDtos.CheckResult check(@Valid @RequestBody BlacklistDtos.CheckRequest req) {
        return service.check(req.candidateId(), req.email(), req.mobile(), req.idProofNumber());
    }

    @PostMapping("/blacklist/{id}/removal-requests")
    @PreAuthorize("hasAuthority('BLACKLIST:REMOVE_REQUEST')")
    public ResponseEntity<BlacklistDtos.Detail> requestRemoval(@PathVariable UUID id,
                                                               @Valid @RequestBody BlacklistDtos.RemovalRequest req) {
        return new ResponseEntity<>(service.requestRemoval(id, req.reason()), HttpStatus.CREATED);
    }

    @GetMapping("/blacklist-reasons")
    @PreAuthorize("isAuthenticated()")
    public List<BlacklistDtos.ReasonView> reasons() {
        return service.reasons();
    }

    @PostMapping("/blacklist-reasons")
    @PreAuthorize("hasAuthority('BLACKLIST_REASON:MANAGE')")
    public ResponseEntity<BlacklistDtos.ReasonView> createReason(@Valid @RequestBody BlacklistDtos.ReasonUpsert req) {
        return new ResponseEntity<>(service.upsertReason(req.code(), req, true), HttpStatus.CREATED);
    }

    @PutMapping("/blacklist-reasons/{code}")
    @PreAuthorize("hasAuthority('BLACKLIST_REASON:MANAGE')")
    public BlacklistDtos.ReasonView updateReason(@PathVariable String code, @Valid @RequestBody BlacklistDtos.ReasonUpsert req) {
        return service.upsertReason(code, req, false);
    }
}
