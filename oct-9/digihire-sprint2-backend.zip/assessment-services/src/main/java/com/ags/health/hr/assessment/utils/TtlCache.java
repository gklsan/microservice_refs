package com.ags.health.hr.assessment.utils;

import java.time.Clock;
import java.time.Duration;
import java.time.Instant;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Function;

public class TtlCache<K, V> {

    private record Entry<V>(V value, Instant expiresAt) {
    }

    private final Map<K, Entry<V>> entries = new ConcurrentHashMap<>();
    private final Duration ttl;
    private final Clock clock;
    private final int maxEntries;

    public TtlCache(Duration ttl, int maxEntries) {
        this(ttl, maxEntries, Clock.systemUTC());
    }

    public TtlCache(Duration ttl, int maxEntries, Clock clock) {
        this.ttl = ttl;
        this.maxEntries = maxEntries;
        this.clock = clock;
    }

    public V get(K key, Function<K, V> loader) {
        Instant now = clock.instant();
        Entry<V> e = entries.get(key);
        if (e != null && e.expiresAt().isAfter(now)) {
            return e.value();
        }
        V value = loader.apply(key);
        if (ttl.isZero() || ttl.isNegative()) {
            return value;
        }
        if (entries.size() >= maxEntries) {
            entries.entrySet().removeIf(x -> !x.getValue().expiresAt().isAfter(now));
            if (entries.size() >= maxEntries) {
                entries.clear();
            }
        }
        entries.put(key, new Entry<>(value, now.plus(ttl)));
        return value;
    }

    public void invalidate(K key) {
        entries.remove(key);
    }

    public void clear() {
        entries.clear();
    }
}
