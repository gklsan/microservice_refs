package com.ags.health.hr.assessment.entities;

import com.ags.health.hr.assessment.enums.TriggerEvent;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.UUID;

@Entity
@Table(name = "asm_assessment_mapping")
@Getter
@Setter
@NoArgsConstructor
public class AssessmentMapping extends CommonEntity {

    @Id
    private UUID id;

    private String lob;

    @Column(name = "role_code")
    private String roleCode;

    private String location;

    @Column(name = "assessment_code", nullable = false)
    private String assessmentCode;

    @Column(name = "sequence_no", nullable = false)
    private int sequenceNo = 1;

    @Enumerated(EnumType.STRING)
    @Column(name = "trigger_event", nullable = false)
    private TriggerEvent triggerEvent;

    @Column(name = "trigger_stage")
    private String triggerStage;

    @Column(nullable = false)
    private boolean mandatory = true;

    @Column(nullable = false)
    private boolean active = true;

    public int specificity() {
        return (roleCode != null ? 4 : 0) + (lob != null ? 2 : 0) + (location != null ? 1 : 0);
    }

    public boolean matches(String lob, String roleCode, String location) {
        return (this.lob == null || this.lob.equalsIgnoreCase(lob == null ? "" : lob))
                && (this.roleCode == null || this.roleCode.equalsIgnoreCase(roleCode == null ? "" : roleCode))
                && (this.location == null || this.location.equalsIgnoreCase(location == null ? "" : location));
    }
}
