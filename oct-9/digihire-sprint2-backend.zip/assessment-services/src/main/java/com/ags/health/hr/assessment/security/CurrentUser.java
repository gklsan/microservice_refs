package com.ags.health.hr.assessment.security;

public record CurrentUser(String userId, String email, String name, String userType, AccessProfile access) {

    public static final String SYSTEM_ID = "00000000-0000-0000-0000-000000000000";

    public static CurrentUser system(String caller) {
        return new CurrentUser(SYSTEM_ID, "system@" + caller, caller, "SYSTEM", null);
    }

    public boolean isSystem() {
        return SYSTEM_ID.equals(userId);
    }

    public String displayName() {
        return name != null ? name : email;
    }
}
