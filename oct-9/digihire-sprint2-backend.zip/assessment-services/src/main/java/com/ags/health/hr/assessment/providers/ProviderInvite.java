package com.ags.health.hr.assessment.providers;

import java.time.Instant;

public record ProviderInvite(String externalRef, String testUrl, Instant expiresAt) {
}
