package com.ags.health.hr.assessment.providers;

import java.time.Instant;
import java.util.Map;
import java.util.UUID;

public record InviteContext(UUID attemptId, String candidateId, String candidateEmail, String candidateName,
                            String externalTestId, Map<String, Object> settings, Instant linkExpiresAt, String callbackUrl) {

    public InviteContext {
        settings = settings == null ? Map.of() : settings;
    }
}
