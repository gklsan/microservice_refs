package com.ags.health.hr.assessment.controllers;

import com.ags.health.hr.assessment.data.AttemptDtos;
import com.ags.health.hr.assessment.data.BlacklistDtos;
import com.ags.health.hr.assessment.data.EligibilityDtos;
import com.ags.health.hr.assessment.data.EventDtos;
import com.ags.health.hr.assessment.services.ApplicationEventService;
import com.ags.health.hr.assessment.services.AssessmentService;
import com.ags.health.hr.assessment.services.BlacklistService;
import com.ags.health.hr.assessment.services.EligibilityService;
import com.ags.health.hr.assessment.services.OutboxService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/internal")
@RequiredArgsConstructor
public class InternalController {

    private final ApplicationEventService events;
    private final EligibilityService eligibility;
    private final BlacklistService blacklist;
    private final AssessmentService assessments;
    private final OutboxService outbox;

    @PostMapping("/events/application")
    @PreAuthorize("hasRole('INTERNAL')")
    public EventDtos.Outcome applicationEvent(@Valid @RequestBody EventDtos.ApplicationEvent event) {
        return events.handle(event);
    }

    @PostMapping("/eligibility/check")
    @PreAuthorize("hasRole('INTERNAL')")
    public EligibilityDtos.Result eligibility(@Valid @RequestBody EligibilityDtos.Request req) {
        return eligibility.check(req);
    }

    @PostMapping("/blacklist/check")
    @PreAuthorize("hasRole('INTERNAL')")
    public BlacklistDtos.CheckResult blacklist(@Valid @RequestBody BlacklistDtos.CheckRequest req) {
        return blacklist.check(req.candidateId(), req.email(), req.mobile(), req.idProofNumber());
    }

    @GetMapping("/candidates/{candidateId}/valid-scores")
    @PreAuthorize("hasRole('INTERNAL')")
    public List<AttemptDtos.View> validScores(@PathVariable String candidateId) {
        return assessments.validScores(candidateId);
    }

    @GetMapping("/candidates/{candidateId}/assessment-summary")
    @PreAuthorize("hasRole('INTERNAL')")
    public AttemptDtos.CandidateSummary summary(@PathVariable String candidateId) {
        return assessments.summary(candidateId);
    }

    @GetMapping("/events")
    @PreAuthorize("hasRole('INTERNAL')")
    public List<EventDtos.OutboxEvent> events(@RequestParam(defaultValue = "0") long afterSeq,
                                              @RequestParam(defaultValue = "100") int limit) {
        return outbox.after(afterSeq, limit);
    }
}
