package com.ags.health.hr.assessment.enums;

public enum ApprovalStatus { PENDING, APPROVED, REJECTED, CANCELLED }
