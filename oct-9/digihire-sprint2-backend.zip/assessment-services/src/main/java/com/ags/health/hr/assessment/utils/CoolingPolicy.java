package com.ags.health.hr.assessment.utils;

import com.ags.health.hr.assessment.entities.AssessmentAttempt;
import com.ags.health.hr.assessment.enums.AttemptStatus;

import java.util.List;
import java.util.Optional;

public final class CoolingPolicy {

    public record Decision(int tier, int days, boolean fresherReset) {
    }

    private CoolingPolicy() {
    }

    public static Optional<Decision> decide(List<Integer> tiers, int failureNumber) {
        if (tiers == null || tiers.isEmpty() || failureNumber < 1) {
            return Optional.empty();
        }
        int index = Math.min(failureNumber, tiers.size()) - 1;
        Integer days = tiers.get(index);
        if (days == null || days <= 0) {
            return Optional.empty();
        }
        return Optional.of(new Decision(index + 1, days, failureNumber >= tiers.size()));
    }

    public static int failuresInCurrentCycle(List<AssessmentAttempt> attemptsOldestFirst) {
        int failures = 0;
        for (AssessmentAttempt a : attemptsOldestFirst) {
            if (a.getStatus() == AttemptStatus.FAILED) {
                failures++;
            }
            if (a.isFresherReset()) {
                failures = 0;
            }
        }
        return failures;
    }
}
