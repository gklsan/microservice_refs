package com.ags.health.hr.assessment.resources;

import com.ags.health.hr.assessment.entities.AssessmentMapping;
import com.ags.health.hr.assessment.enums.TriggerEvent;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.UUID;

public interface AssessmentMappingRepository extends JpaRepository<AssessmentMapping, UUID> {

    List<AssessmentMapping> findByTriggerEventAndActiveTrue(TriggerEvent event);

    List<AssessmentMapping> findAllByOrderByLobAscRoleCodeAscSequenceNoAsc();
}
