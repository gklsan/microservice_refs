package com.ags.health.hr.assessment.providers;

import com.ags.health.hr.assessment.exceptions.APIException;

import java.util.Collection;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Optional;

public class ProviderRegistry {

    private final Map<String, AssessmentProvider> providers = new LinkedHashMap<>();

    public ProviderRegistry(List<AssessmentProvider> list) {
        list.forEach(p -> providers.put(p.code().toUpperCase(Locale.ROOT), p));
    }

    public Optional<AssessmentProvider> find(String code) {
        return code == null ? Optional.empty() : Optional.ofNullable(providers.get(code.toUpperCase(Locale.ROOT)));
    }

    public AssessmentProvider get(String code) {
        return find(code).orElseThrow(() -> APIException.conflict("PROVIDER_DISABLED",
                "Assessment provider " + code + " is not enabled in assessment-services"));
    }

    public Collection<AssessmentProvider> all() {
        return Collections.unmodifiableCollection(providers.values());
    }
}
