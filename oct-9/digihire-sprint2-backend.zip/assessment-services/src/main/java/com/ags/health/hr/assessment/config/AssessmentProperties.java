package com.ags.health.hr.assessment.config;

import lombok.Getter;
import lombok.Setter;
import org.springframework.boot.context.properties.ConfigurationProperties;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

@Getter
@Setter
@ConfigurationProperties(prefix = "assessment")
public class AssessmentProperties {

    private Security security = new Security();
    private Admin admin = new Admin();
    private Rules rules = new Rules();
    private Blacklist blacklist = new Blacklist();
    private Jobs jobs = new Jobs();
    private Events events = new Events();
    private Callbacks callbacks = new Callbacks();
    private Providers providers = new Providers();

    @Getter
    @Setter
    public static class Security {
        private String jwtSecret;
        private String internalApiKey;
        private boolean requireHttps;
    }

    @Getter
    @Setter
    public static class Admin {
        private String baseUrl;
        private String internalKey;
        private String callerName = "assessment-services";
        private int timeoutSeconds = 5;
        private int accessCacheSeconds = 120;
        private int configCacheSeconds = 300;
        private int secretCacheSeconds = 300;
    }

    @Getter
    @Setter
    public static class Rules {
        private int scoreValidityDays = 60;
        private int linkValidityDays = 7;
        private int rescheduleMaxPerAttempt = 2;
        private int voiceFresherBlockDays = 180;
        private List<String> voiceFresherLocations = new ArrayList<>();
        private List<String> voiceFresherRoleCodes = new ArrayList<>();
        private boolean blacklistRemovalRequiresApproval = true;
        private Map<String, List<Integer>> coolingDays = new LinkedHashMap<>();
    }

    @Getter
    @Setter
    public static class Blacklist {
        private String pepperSecretName;
        private String pepper;
    }

    @Getter
    @Setter
    public static class Jobs {
        private boolean enabled = true;
        private String pollCron;
        private String expiryCron;
        private String validityCron;
        private String publishCron;
        private String zone = "Asia/Kolkata";
    }

    @Getter
    @Setter
    public static class Events {
        private String webhookUrl;
        private String webhookKey;
        private int batchSize = 100;
    }

    @Getter
    @Setter
    public static class Callbacks {
        private String publicBaseUrl;
    }

    @Getter
    @Setter
    public static class Providers {
        private Versant versant = new Versant();
        private Map<String, Rest> rest = new LinkedHashMap<>();
    }

    @Getter
    @Setter
    public static class Versant {
        private boolean enabled;
        private String baseUrl;
        private String usernameSecret;
        private String passwordSecret;
        private String username;
        private String password;
        private String scale = "GSE";
        private String language = "ENG";
        private String tokenField = "token";
    }

    @Getter
    @Setter
    public static class Rest {
        private boolean enabled;
        private String inviteUrl;
        private String inviteBody;
        private String authHeader;
        private String authValueTemplate;
        private String authSecret;
        private String refPointer = "/id";
        private String linkPointer = "/url";
        private String resultUrl;
        private String statusPointer = "/status";
        private String scorePointer = "/score";
        private String completedAtPointer;
        private List<String> completedValues = new ArrayList<>();
        private List<String> inProgressValues = new ArrayList<>();
        private List<String> notTakenValues = new ArrayList<>();
        private String callbackRefPointer;
        private String callbackSecret;
        private String callbackSignatureHeader = "X-Signature";
    }
}
