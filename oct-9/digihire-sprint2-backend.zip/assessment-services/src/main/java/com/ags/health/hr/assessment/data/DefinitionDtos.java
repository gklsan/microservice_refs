package com.ags.health.hr.assessment.data;

import com.ags.health.hr.assessment.entities.AssessmentDefinition;
import com.ags.health.hr.assessment.enums.AssessmentCategory;
import com.ags.health.hr.assessment.utils.GradingPolicy;
import com.fasterxml.jackson.databind.JsonNode;
import jakarta.validation.Valid;
import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;

import java.math.BigDecimal;
import java.time.Instant;
import java.util.List;
import java.util.Map;

public final class DefinitionDtos {

    public static final String CODE = "[A-Z][A-Z0-9_]{1,49}";

    private DefinitionDtos() {
    }

    public record BandItem(@NotNull @DecimalMin("0") BigDecimal min, @NotBlank @Size(max = 20) String grade) {
    }

    public record Upsert(@NotBlank @Pattern(regexp = CODE) String code,
                         @NotBlank @Size(max = 150) String name,
                         @NotBlank @Pattern(regexp = "[A-Z][A-Z0-9_]{1,29}") String providerCode,
                         @NotNull AssessmentCategory category,
                         @Size(max = 100) String externalTestId,
                         @Pattern(regexp = "[A-Z][A-Z0-9_]{1,29}") String coolingKey,
                         @DecimalMin("0") BigDecimal passScore,
                         @DecimalMin("0") BigDecimal maxScore,
                         @Size(max = 20) List<@Valid @NotNull BandItem> gradeBands,
                         @Min(1) @Max(3650) Integer validityDays,
                         @Min(1) @Max(90) Integer linkValidityDays,
                         Map<String, Object> settings,
                         Boolean active,
                         Long version) {
    }

    public record View(String code, String name, String providerCode, AssessmentCategory category, String externalTestId,
                       String coolingKey, BigDecimal passScore, BigDecimal maxScore, List<GradingPolicy.Band> gradeBands,
                       Integer validityDays, Integer linkValidityDays, JsonNode settings, boolean active,
                       Instant updatedDate, String updatedBy, Long version) {
    }

    public static View view(AssessmentDefinition d, List<GradingPolicy.Band> bands, JsonNode settings) {
        return new View(d.getCode(), d.getName(), d.getProviderCode(), d.getCategory(), d.getExternalTestId(), d.getCoolingKey(),
                d.getPassScore(), d.getMaxScore(), bands, d.getValidityDays(), d.getLinkValidityDays(), settings, d.isActive(),
                d.getUpdatedDate() != null ? d.getUpdatedDate() : d.getCreatedDate(),
                d.getUpdatedBy() != null ? d.getUpdatedBy() : d.getCreatedBy(), d.getVersion());
    }
}
