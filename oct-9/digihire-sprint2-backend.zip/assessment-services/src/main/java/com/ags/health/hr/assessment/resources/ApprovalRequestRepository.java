package com.ags.health.hr.assessment.resources;

import com.ags.health.hr.assessment.entities.ApprovalRequest;
import com.ags.health.hr.assessment.enums.ApprovalStatus;
import com.ags.health.hr.assessment.enums.ApprovalSubjectType;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;
import java.util.UUID;

public interface ApprovalRequestRepository extends JpaRepository<ApprovalRequest, UUID> {

    List<ApprovalRequest> findBySubjectTypeAndSubjectIdAndStatus(ApprovalSubjectType type, String subjectId, ApprovalStatus status);

    @Query("""
            select r from ApprovalRequest r
            where (:subjectType is null or r.subjectType = :subjectType)
              and (:status is null or r.status = :status)
              and (:candidateId is null or r.candidateId = :candidateId)
            order by r.requestedAt desc
            """)
    List<ApprovalRequest> search(@Param("subjectType") ApprovalSubjectType subjectType,
                                 @Param("status") ApprovalStatus status,
                                 @Param("candidateId") String candidateId);
}
