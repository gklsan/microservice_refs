package com.ags.health.hr.assessment.services;

import com.ags.health.hr.assessment.data.BlacklistDtos;
import com.ags.health.hr.assessment.data.EligibilityDtos;
import com.ags.health.hr.assessment.entities.AssessmentAttempt;
import com.ags.health.hr.assessment.entities.AssessmentDefinition;
import com.ags.health.hr.assessment.entities.CandidateRestriction;
import com.ags.health.hr.assessment.enums.EligibilityPurpose;
import com.ags.health.hr.assessment.resources.AssessmentAttemptRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.Instant;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;

@Slf4j
@Service
@Transactional(readOnly = true)
@RequiredArgsConstructor
public class EligibilityService {

    public static final String BLACKLISTED = "BLACKLISTED";
    public static final String VOICE_FRESHER_RESTRICTED = "VOICE_FRESHER_RESTRICTED";
    public static final String COOLING_PERIOD = "COOLING_PERIOD";
    public static final String VALID_SCORE_EXISTS = "VALID_SCORE_EXISTS";
    public static final String ATTEMPT_IN_PROGRESS = "ATTEMPT_IN_PROGRESS";
    public static final String REAPPLY_AS_FRESHER = "REAPPLY_AS_FRESHER";

    private final BlacklistService blacklist;
    private final VoiceFresherService voiceFresher;
    private final AssessmentAttemptRepository attempts;
    private final AssessmentConfigService config;
    private final IdentityHasher hasher;

    public EligibilityDtos.Result check(EligibilityDtos.Request req) {
        Instant now = Instant.now();
        List<EligibilityDtos.Reason> reasons = new ArrayList<>();
        EligibilityDtos.ValidScore validScore = null;

        BlacklistDtos.CheckResult bl;
        if (hasher.isConfigured()) {
            bl = blacklist.check(req.candidateId(), req.email(), req.mobile(), req.idProofNumber());
        } else {
            log.warn("Blacklist matching key missing: checking by candidate id only");
            bl = blacklist.check(req.candidateId(), null, null, null);
        }
        if (bl.blacklisted()) {
            reasons.add(new EligibilityDtos.Reason(BLACKLISTED, "Candidate is blacklisted ("
                    + bl.matches().get(0).reasonLabel() + ")", null, true));
        }

        if (voiceFresher.isVoiceFresherRole(req.roleCode())) {
            voiceFresher.active(req.candidateId(), now).stream()
                    .max(Comparator.comparing(CandidateRestriction::getEndsAt))
                    .ifPresent(r -> reasons.add(new EligibilityDtos.Reason(VOICE_FRESHER_RESTRICTED,
                            "Rejected for a Voice Fresher role in " + r.getSourceLocation()
                                    + "; Voice Fresher roles are blocked until the date shown", r.getEndsAt(), true)));
        }

        if (req.candidateId() != null) {
            if (req.purpose() == EligibilityPurpose.ASSESSMENT && req.assessmentCode() != null) {
                AssessmentDefinition def = config.definitionEntity(req.assessmentCode());
                List<AssessmentAttempt> sameTest = attempts.findByCandidateIdAndAssessmentCodeOrderByCreatedDateDesc(
                        req.candidateId(), def.getCode());
                if (sameTest.stream().anyMatch(a -> a.getStatus().isOpen())) {
                    reasons.add(new EligibilityDtos.Reason(ATTEMPT_IN_PROGRESS, "An attempt is already open for " + def.getCode(),
                            null, true));
                }
                Optional<AssessmentAttempt> valid = sameTest.stream().filter(a -> a.isScoreValid(now)).findFirst();
                if (valid.isPresent()) {
                    AssessmentAttempt a = valid.get();
                    validScore = new EligibilityDtos.ValidScore(a.getId(), a.getAssessmentCode(), a.getScore(), a.getGrade(),
                            a.getCompletedAt(), a.getValidUntil());
                    reasons.add(new EligibilityDtos.Reason(VALID_SCORE_EXISTS, "A passing score is still valid; reuse it",
                            a.getValidUntil(), true));
                }
                cooling(req.candidateId(), def.getCoolingKey(), now).ifPresent(reasons::add);
                fresher(req.candidateId(), def.getCoolingKey()).ifPresent(reasons::add);
            } else {
                attempts.findByCandidateIdOrderByCreatedDateDesc(req.candidateId()).stream()
                        .filter(a -> a.getCoolingUntil() != null && a.getCoolingUntil().isAfter(now))
                        .max(Comparator.comparing(AssessmentAttempt::getCoolingUntil))
                        .ifPresent(a -> reasons.add(new EligibilityDtos.Reason(COOLING_PERIOD,
                                "Cooling period after a failed " + a.getAssessmentCode(), a.getCoolingUntil(), false)));
            }
        }
        boolean eligible = reasons.stream().noneMatch(EligibilityDtos.Reason::blocking);
        return new EligibilityDtos.Result(eligible, reasons, validScore);
    }

    private Optional<EligibilityDtos.Reason> cooling(String candidateId, String coolingKey, Instant now) {
        if (coolingKey == null) {
            return Optional.empty();
        }
        return attempts.findByCandidateIdAndCoolingKeyOrderByCreatedDateAsc(candidateId, coolingKey).stream()
                .filter(a -> a.getCoolingUntil() != null && a.getCoolingUntil().isAfter(now))
                .max(Comparator.comparing(AssessmentAttempt::getCoolingUntil))
                .map(a -> new EligibilityDtos.Reason(COOLING_PERIOD, "Cooling period " + a.getCoolingTier() + " for "
                        + coolingKey + " after a failed attempt", a.getCoolingUntil(), true));
    }

    private Optional<EligibilityDtos.Reason> fresher(String candidateId, String coolingKey) {
        if (coolingKey == null) {
            return Optional.empty();
        }
        List<AssessmentAttempt> history = attempts.findByCandidateIdAndCoolingKeyOrderByCreatedDateAsc(candidateId, coolingKey);
        if (history.isEmpty()) {
            return Optional.empty();
        }
        AssessmentAttempt last = history.get(history.size() - 1);
        return last.isFresherReset()
                ? Optional.of(new EligibilityDtos.Reason(REAPPLY_AS_FRESHER, "Cooling cycle finished; candidate re-applies as a fresher",
                last.getCoolingUntil(), false))
                : Optional.empty();
    }
}
