package com.ags.health.hr.assessment.services;

import com.ags.health.hr.assessment.clients.ConfigSource;
import com.ags.health.hr.assessment.config.AssessmentProperties;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Optional;

@Slf4j
@Component
@RequiredArgsConstructor
public class RuleSettings {

    private final ConfigSource config;
    private final AssessmentProperties props;
    private final ObjectMapper mapper;

    public int scoreValidityDays() {
        return intValue("assessment.score-validity-days", props.getRules().getScoreValidityDays());
    }

    public int linkValidityDays() {
        return intValue("assessment.invite.link-validity-days", props.getRules().getLinkValidityDays());
    }

    public int rescheduleMaxPerAttempt() {
        return intValue("assessment.reschedule.max-per-attempt", props.getRules().getRescheduleMaxPerAttempt());
    }

    public int voiceFresherBlockDays() {
        return intValue("voice-fresher.chennai-reject-block-days", props.getRules().getVoiceFresherBlockDays());
    }

    public List<String> voiceFresherLocations() {
        return upper(stringList("voice-fresher.restricted-locations").orElse(props.getRules().getVoiceFresherLocations()));
    }

    public List<String> voiceFresherRoleCodes() {
        return upper(stringList("voice-fresher.role-codes").orElse(props.getRules().getVoiceFresherRoleCodes()));
    }

    public boolean blacklistRemovalRequiresApproval() {
        return config.value("blacklist.removal.requires-approval").map(v -> Boolean.parseBoolean(v.trim()))
                .orElse(props.getRules().isBlacklistRemovalRequiresApproval());
    }

    public List<Integer> coolingDays(String coolingKey) {
        if (coolingKey == null || coolingKey.isBlank()) {
            return List.of();
        }
        String key = coolingKey.trim();
        Optional<String> raw = config.value("assessment.cooling-days." + key.toLowerCase(Locale.ROOT));
        if (raw.isPresent()) {
            try {
                JsonNode node = mapper.readTree(raw.get());
                List<Integer> out = new ArrayList<>();
                node.forEach(n -> out.add(n.asInt()));
                return out;
            } catch (Exception e) {
                log.warn("Config assessment.cooling-days.{} is not a JSON list: {}", key, raw.get());
            }
        }
        List<Integer> fallback = props.getRules().getCoolingDays().get(key.toUpperCase(Locale.ROOT));
        return fallback == null ? List.of() : fallback;
    }

    private int intValue(String key, int fallback) {
        return config.value(key).map(v -> {
            try {
                return Integer.parseInt(v.trim());
            } catch (NumberFormatException e) {
                log.warn("Config {} is not a number: {}", key, v);
                return fallback;
            }
        }).orElse(fallback);
    }

    private Optional<List<String>> stringList(String key) {
        return config.value(key).map(v -> {
            try {
                JsonNode node = mapper.readTree(v);
                List<String> out = new ArrayList<>();
                node.forEach(n -> out.add(n.asText()));
                return out;
            } catch (Exception e) {
                log.warn("Config {} is not a JSON list: {}", key, v);
                return null;
            }
        });
    }

    private static List<String> upper(List<String> values) {
        return values == null ? List.of() : values.stream().filter(v -> v != null && !v.isBlank())
                .map(v -> v.trim().toUpperCase(Locale.ROOT)).toList();
    }
}
