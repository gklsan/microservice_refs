package com.ags.health.hr.assessment.security;

import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.http.HttpStatus;
import org.springframework.web.filter.OncePerRequestFilter;

import java.io.IOException;

public class TransportSecurityFilter extends OncePerRequestFilter {

    private final boolean requireHttps;
    private final ProblemResponseWriter problems;

    public TransportSecurityFilter(boolean requireHttps, ProblemResponseWriter problems) {
        this.requireHttps = requireHttps;
        this.problems = problems;
    }

    @Override
    protected boolean shouldNotFilter(HttpServletRequest request) {
        String path = request.getRequestURI().substring(request.getContextPath().length());
        return !requireHttps || path.startsWith("/actuator/health");
    }

    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain chain)
            throws ServletException, IOException {
        if (!request.isSecure()) {
            problems.write(response, HttpStatus.FORBIDDEN, "HTTPS_REQUIRED", "This service only accepts HTTPS requests");
            return;
        }
        response.setHeader("Strict-Transport-Security", "max-age=31536000; includeSubDomains");
        chain.doFilter(request, response);
    }
}
