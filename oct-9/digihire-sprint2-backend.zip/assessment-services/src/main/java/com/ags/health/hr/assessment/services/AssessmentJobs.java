package com.ags.health.hr.assessment.services;

import com.ags.health.hr.assessment.config.AssessmentProperties;
import com.ags.health.hr.assessment.providers.AssessmentProvider;
import com.ags.health.hr.assessment.providers.ProviderRegistry;
import com.ags.health.hr.assessment.providers.ProviderResult;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.util.List;

@Slf4j
@Component
@RequiredArgsConstructor
public class AssessmentJobs {

    private static final int CHUNK = 50;

    private final ProviderRegistry providers;
    private final AssessmentService assessments;
    private final AssessmentProperties props;

    @Scheduled(cron = "${assessment.jobs.poll-cron}", zone = "${assessment.jobs.zone}")
    public void pollResults() {
        if (!props.getJobs().isEnabled()) {
            return;
        }
        for (AssessmentProvider provider : providers.all()) {
            if (provider.supportsPolling()) {
                pollProvider(provider);
            }
        }
    }

    public int pollProvider(AssessmentProvider provider) {
        List<String> refs = assessments.openRefs(provider.code());
        int changed = 0;
        for (int i = 0; i < refs.size(); i += CHUNK) {
            List<String> chunk = refs.subList(i, Math.min(refs.size(), i + CHUNK));
            List<ProviderResult> results;
            try {
                results = provider.fetchResults(chunk);
            } catch (RuntimeException e) {
                log.warn("{} result polling failed: {}", provider.code(), e.getMessage());
                return changed;
            }
            for (ProviderResult r : results) {
                try {
                    if (assessments.recordProviderResult(provider.code(), r)) {
                        changed++;
                    }
                } catch (RuntimeException e) {
                    log.warn("{} result for {} not recorded: {}", provider.code(), r.externalRef(), e.getMessage());
                }
            }
        }
        if (changed > 0) {
            log.info("{}: {} assessment attempt(s) updated from provider results", provider.code(), changed);
        }
        return changed;
    }

    @Scheduled(cron = "${assessment.jobs.expiry-cron}", zone = "${assessment.jobs.zone}")
    public void expireLinks() {
        if (props.getJobs().isEnabled()) {
            int n = assessments.expireLinks();
            if (n > 0) {
                log.info("{} assessment link(s) expired", n);
            }
        }
    }

    @Scheduled(cron = "${assessment.jobs.validity-cron}", zone = "${assessment.jobs.zone}")
    public void expireScores() {
        if (props.getJobs().isEnabled()) {
            int n = assessments.expireScores();
            if (n > 0) {
                log.info("{} assessment score(s) passed their validity date", n);
            }
        }
    }
}
