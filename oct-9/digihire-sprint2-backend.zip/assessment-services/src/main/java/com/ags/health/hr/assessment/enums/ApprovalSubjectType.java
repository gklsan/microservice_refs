package com.ags.health.hr.assessment.enums;

public enum ApprovalSubjectType { ASSESSMENT_RESCHEDULE, BLACKLIST_REMOVAL }
