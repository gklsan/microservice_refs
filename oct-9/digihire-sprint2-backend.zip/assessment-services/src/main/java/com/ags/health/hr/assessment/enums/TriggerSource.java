package com.ags.health.hr.assessment.enums;

public enum TriggerSource { AUTO, MANUAL, RESCHEDULE }
