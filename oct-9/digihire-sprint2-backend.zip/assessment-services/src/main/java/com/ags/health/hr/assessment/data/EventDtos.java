package com.ags.health.hr.assessment.data;

import com.ags.health.hr.assessment.enums.ApplicationEventType;
import com.fasterxml.jackson.databind.JsonNode;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

import java.time.Instant;
import java.util.List;
import java.util.UUID;

public final class EventDtos {

    private EventDtos() {
    }

    public record ApplicationEvent(@NotNull ApplicationEventType eventType,
                                   @NotBlank @Size(max = 64) String candidateId,
                                   @Size(max = 64) String applicationId,
                                   @Email @Size(max = 254) String candidateEmail,
                                   @Size(max = 200) String candidateName,
                                   @Size(max = 20) String mobile,
                                   @Size(max = 100) String lob,
                                   @Size(max = 100) String roleCode,
                                   @Size(max = 100) String location,
                                   @Size(max = 60) String stage,
                                   @Size(max = 500) String reason) {
    }

    public record OutcomeItem(String assessmentCode, String action, UUID attemptId, List<EligibilityDtos.Reason> reasons) {
    }

    public record Outcome(String eventType, String candidateId, boolean blacklisted, boolean restrictionApplied,
                          List<OutcomeItem> items) {
    }

    public record OutboxEvent(long seq, UUID id, String eventType, String aggregateType, String aggregateId,
                              String candidateId, String applicationId, JsonNode payload, Instant createdAt) {
    }
}
