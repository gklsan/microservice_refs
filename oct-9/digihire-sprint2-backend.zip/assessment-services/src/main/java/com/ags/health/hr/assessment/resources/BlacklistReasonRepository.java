package com.ags.health.hr.assessment.resources;

import com.ags.health.hr.assessment.entities.BlacklistReason;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface BlacklistReasonRepository extends JpaRepository<BlacklistReason, String> {

    List<BlacklistReason> findAllByOrderBySortOrderAscCodeAsc();
}
