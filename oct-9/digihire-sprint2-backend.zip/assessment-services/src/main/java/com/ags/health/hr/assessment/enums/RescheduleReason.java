package com.ags.health.hr.assessment.enums;

public enum RescheduleReason { TECHNICAL_ISSUE, NETWORK_FAILURE, SYSTEM_CRASH, PROVIDER_OUTAGE, POWER_FAILURE, OTHER_TECHNICAL }
