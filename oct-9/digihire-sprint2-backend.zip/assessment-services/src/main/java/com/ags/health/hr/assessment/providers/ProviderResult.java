package com.ags.health.hr.assessment.providers;

import com.ags.health.hr.assessment.enums.ProviderResultStatus;

import java.math.BigDecimal;
import java.time.Instant;
import java.util.UUID;

public record ProviderResult(UUID attemptId, String externalRef, ProviderResultStatus status, BigDecimal score,
                             String grade, Instant startedAt, Instant completedAt, String raw) {
}
