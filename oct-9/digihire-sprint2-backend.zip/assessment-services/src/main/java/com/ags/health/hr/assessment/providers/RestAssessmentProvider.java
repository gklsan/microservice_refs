package com.ags.health.hr.assessment.providers;

import com.ags.health.hr.assessment.clients.JsonHttp;
import com.ags.health.hr.assessment.clients.SecretSource;
import com.ags.health.hr.assessment.config.AssessmentProperties;
import com.ags.health.hr.assessment.enums.ProviderResultStatus;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;

public class RestAssessmentProvider implements AssessmentProvider {

    private final String code;
    private final AssessmentProperties.Rest props;
    private final JsonHttp http;
    private final ObjectMapper mapper;
    private final SecretSource secrets;

    public RestAssessmentProvider(String code, AssessmentProperties.Rest props, JsonHttp http, SecretSource secrets) {
        this.code = code;
        this.props = props;
        this.http = http;
        this.mapper = http.mapper();
        this.secrets = secrets;
    }

    @Override
    public String code() {
        return code;
    }

    @Override
    public boolean supportsPolling() {
        return props.getResultUrl() != null && !props.getResultUrl().isBlank();
    }

    @Override
    public boolean supportsCallback() {
        return props.getCallbackSecret() != null && !props.getCallbackSecret().isBlank();
    }

    @Override
    public ProviderInvite invite(InviteContext ctx) {
        if (props.getInviteUrl() == null || props.getInviteUrl().isBlank()) {
            throw new ProviderException("PROVIDER_NOT_CONFIGURED", code + " invite URL is not configured");
        }
        Map<String, String> vars = new LinkedHashMap<>();
        vars.put("attemptId", ctx.attemptId().toString());
        vars.put("candidateId", ctx.candidateId());
        vars.put("candidateEmail", ctx.candidateEmail());
        vars.put("candidateName", ctx.candidateName());
        vars.put("testId", ctx.externalTestId());
        vars.put("callbackUrl", ctx.callbackUrl());
        vars.put("expiresAt", ctx.linkExpiresAt() == null ? null : ctx.linkExpiresAt().toString());
        String body = render(props.getInviteBody(), vars, true);
        JsonNode res;
        try {
            res = http.post(props.getInviteUrl(), authHeaders(), body);
        } catch (JsonHttp.HttpFailure e) {
            throw new ProviderException("PROVIDER_UNAVAILABLE", code + " invite failed: " + e.getMessage(), e);
        }
        String ref = JsonValues.text(res, props.getRefPointer());
        if (ref == null) {
            throw new ProviderException("PROVIDER_BAD_RESPONSE", code + " did not return a reference at " + props.getRefPointer());
        }
        return new ProviderInvite(ref, JsonValues.text(res, props.getLinkPointer()), ctx.linkExpiresAt());
    }

    @Override
    public List<ProviderResult> fetchResults(List<String> externalRefs) {
        List<ProviderResult> out = new ArrayList<>();
        if (!supportsPolling()) {
            return out;
        }
        for (String ref : externalRefs) {
            try {
                JsonNode res = http.get(props.getResultUrl().replace("{{ref}}", JsonHttp.encode(ref)), authHeaders());
                out.add(parse(null, ref, res));
            } catch (JsonHttp.HttpFailure e) {
                if (e.status() != 404) {
                    throw new ProviderException("PROVIDER_UNAVAILABLE", code + " result lookup failed: " + e.getMessage(), e);
                }
            }
        }
        return out;
    }

    @Override
    public ProviderResult parseCallback(Map<String, String> headers, String body) {
        if (!supportsCallback()) {
            return AssessmentProvider.super.parseCallback(headers, body);
        }
        String key = secrets.secret(props.getCallbackSecret())
                .orElseThrow(() -> new ProviderException("PROVIDER_NOT_CONFIGURED", code + " callback key missing"));
        String signature = header(headers, props.getCallbackSignatureHeader());
        if (!Hmac.verify(key, body, signature)) {
            throw new ProviderException("INVALID_SIGNATURE", code + " callback signature does not match");
        }
        JsonNode node;
        try {
            node = mapper.readTree(body);
        } catch (JsonProcessingException e) {
            throw new ProviderException("PROVIDER_BAD_RESPONSE", code + " callback is not JSON");
        }
        UUID attemptId = null;
        String reference = JsonValues.text(node, props.getCallbackRefPointer());
        if (reference != null) {
            try {
                attemptId = UUID.fromString(reference);
            } catch (IllegalArgumentException ignored) {
                attemptId = null;
            }
        }
        String ref = JsonValues.text(node, props.getRefPointer());
        return parse(attemptId, ref, node);
    }

    ProviderResult parse(UUID attemptId, String ref, JsonNode node) {
        String status = JsonValues.text(node, props.getStatusPointer());
        ProviderResultStatus mapped = ProviderResultStatus.PENDING;
        if (status != null) {
            String s = status.toUpperCase(Locale.ROOT);
            if (contains(props.getCompletedValues(), s)) {
                mapped = ProviderResultStatus.COMPLETED;
            } else if (contains(props.getInProgressValues(), s)) {
                mapped = ProviderResultStatus.IN_PROGRESS;
            } else if (contains(props.getNotTakenValues(), s)) {
                mapped = ProviderResultStatus.NOT_TAKEN;
            }
        }
        return new ProviderResult(attemptId, ref, mapped, JsonValues.number(node, props.getScorePointer()), null, null,
                JsonValues.instant(node, props.getCompletedAtPointer()), node.toString());
    }

    private Map<String, String> authHeaders() {
        Map<String, String> h = new LinkedHashMap<>();
        if (props.getAuthHeader() != null && !props.getAuthHeader().isBlank()) {
            String secret = props.getAuthSecret() == null ? "" : secrets.secret(props.getAuthSecret())
                    .orElseThrow(() -> new ProviderException("PROVIDER_NOT_CONFIGURED", code + " API credential missing"));
            Map<String, String> vars = Map.of("secret", secret);
            h.put(props.getAuthHeader(), render(props.getAuthValueTemplate() == null ? "{{secret}}" : props.getAuthValueTemplate(), vars, false));
        }
        return h;
    }

    String render(String template, Map<String, String> vars, boolean jsonEscape) {
        if (template == null) {
            return null;
        }
        String out = template;
        for (Map.Entry<String, String> e : vars.entrySet()) {
            String v = e.getValue() == null ? "" : e.getValue();
            out = out.replace("{{" + e.getKey() + "}}", jsonEscape ? escape(v) : v);
        }
        return out;
    }

    private String escape(String v) {
        try {
            String quoted = mapper.writeValueAsString(v);
            return quoted.substring(1, quoted.length() - 1);
        } catch (JsonProcessingException e) {
            throw new IllegalStateException(e);
        }
    }

    private static boolean contains(List<String> values, String s) {
        return values != null && values.stream().anyMatch(v -> v.equalsIgnoreCase(s));
    }

    private static String header(Map<String, String> headers, String name) {
        if (headers == null || name == null) {
            return null;
        }
        for (Map.Entry<String, String> e : headers.entrySet()) {
            if (e.getKey() != null && e.getKey().equalsIgnoreCase(name)) {
                return e.getValue();
            }
        }
        return null;
    }
}
