package com.ags.health.hr.assessment.config;

import com.ags.health.hr.assessment.clients.AdminServicesClient;
import com.ags.health.hr.assessment.clients.JsonHttp;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.time.Duration;

@Configuration
public class ClientConfig {

    @Bean
    public JsonHttp jsonHttp(ObjectMapper mapper, AssessmentProperties props) {
        return new JsonHttp(mapper, Duration.ofSeconds(Math.max(1, props.getAdmin().getTimeoutSeconds())));
    }

    @Bean
    public AdminServicesClient adminServicesClient(AssessmentProperties props, JsonHttp http) {
        return new AdminServicesClient(props.getAdmin(), http);
    }
}
