package com.ags.health.hr.assessment.enums;

public enum AttemptStatus {
    INVITED, IN_PROGRESS, COMPLETED, FAILED, NOT_TAKEN, EXPIRED, CANCELLED, RESCHEDULED, ERROR;

    public boolean isOpen() {
        return this == INVITED || this == IN_PROGRESS;
    }
}
