package com.ags.health.hr.assessment.enums;

public enum ApprovalDecision { APPROVE, REJECT }
