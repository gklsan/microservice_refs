package com.ags.health.hr.assessment.providers;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
import java.nio.charset.StandardCharsets;
import java.security.GeneralSecurityException;
import java.security.MessageDigest;
import java.util.Base64;
import java.util.HexFormat;
import java.util.Locale;

public final class Hmac {

    private Hmac() {
    }

    public static byte[] sha256(byte[] key, byte[] data) {
        try {
            Mac mac = Mac.getInstance("HmacSHA256");
            mac.init(new SecretKeySpec(key, "HmacSHA256"));
            return mac.doFinal(data);
        } catch (GeneralSecurityException e) {
            throw new IllegalStateException("HmacSHA256 unavailable", e);
        }
    }

    public static String sha256Hex(String key, String data) {
        return HexFormat.of().formatHex(sha256(key.getBytes(StandardCharsets.UTF_8), data.getBytes(StandardCharsets.UTF_8)));
    }

    public static boolean verify(String key, String body, String signatureHeader) {
        if (key == null || key.isBlank() || signatureHeader == null || signatureHeader.isBlank()) {
            return false;
        }
        String given = signatureHeader.trim();
        if (given.toLowerCase(Locale.ROOT).startsWith("sha256=")) {
            given = given.substring(7);
        }
        byte[] expected = sha256(key.getBytes(StandardCharsets.UTF_8), body.getBytes(StandardCharsets.UTF_8));
        byte[] provided = decode(given);
        return provided != null && MessageDigest.isEqual(expected, provided);
    }

    private static byte[] decode(String value) {
        try {
            if (value.matches("[0-9a-fA-F]{64}")) {
                return HexFormat.of().parseHex(value);
            }
            return Base64.getDecoder().decode(value);
        } catch (IllegalArgumentException e) {
            return null;
        }
    }
}
