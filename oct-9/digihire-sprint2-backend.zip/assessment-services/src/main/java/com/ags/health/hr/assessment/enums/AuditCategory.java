package com.ags.health.hr.assessment.enums;

public enum AuditCategory { ACTIVITY, APPROVAL, WORKFLOW_TRANSITION, CONFIG_CHANGE, SECURITY, NOTIFICATION }
