package com.ags.health.hr.assessment.clients;

import com.ags.health.hr.assessment.config.AssessmentProperties;
import com.ags.health.hr.assessment.exceptions.APIException;
import com.ags.health.hr.assessment.security.AccessProfile;
import com.ags.health.hr.assessment.utils.TtlCache;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;

import java.time.Duration;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Optional;

@Slf4j
public class AdminServicesClient implements AccessDirectory, ConfigSource, SecretSource, ApprovalDirectory {

    private final JsonHttp http;
    private final ObjectMapper mapper;
    private final String base;
    private final Map<String, String> headers;
    private final TtlCache<String, AccessProfile> accessCache;
    private final TtlCache<String, Optional<String>> configCache;
    private final TtlCache<String, Optional<String>> secretCache;

    public AdminServicesClient(AssessmentProperties.Admin props, JsonHttp http) {
        this.http = http;
        this.mapper = http.mapper();
        String url = props.getBaseUrl() == null ? "" : props.getBaseUrl().trim();
        this.base = url.endsWith("/") ? url.substring(0, url.length() - 1) : url;
        Map<String, String> h = new LinkedHashMap<>();
        h.put("X-Internal-Key", props.getInternalKey());
        h.put("X-Caller-Service", props.getCallerName());
        this.headers = Map.copyOf(h.entrySet().stream().filter(e -> e.getValue() != null)
                .collect(java.util.stream.Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue)));
        this.accessCache = new TtlCache<>(Duration.ofSeconds(props.getAccessCacheSeconds()), 10_000);
        this.configCache = new TtlCache<>(Duration.ofSeconds(props.getConfigCacheSeconds()), 1_000);
        this.secretCache = new TtlCache<>(Duration.ofSeconds(props.getSecretCacheSeconds()), 200);
    }

    @Override
    public AccessProfile resolve(String userId, String email, String userType) {
        String key = userId + "|" + email + "|" + userType;
        return accessCache.get(key, k -> {
            try {
                JsonNode node = http.get(JsonHttp.query(base + "/internal/rbac/effective",
                        params("userId", userId, "email", email, "userType", userType)), headers);
                return mapper.treeToValue(node, AccessProfile.class);
            } catch (Exception e) {
                log.warn("admin-services access lookup failed: {}", e.getMessage());
                throw APIException.unavailable("ACCESS_SERVICE_UNAVAILABLE", "Access rules can not be loaded right now. Try again shortly.");
            }
        });
    }

    @Override
    public Optional<String> value(String key) {
        return configCache.get(key, k -> {
            try {
                JsonNode node = http.get(base + "/internal/config/" + JsonHttp.encode(k), headers);
                JsonNode v = node.get("value");
                return v == null || v.isNull() ? Optional.<String>empty() : Optional.of(v.asText());
            } catch (JsonHttp.HttpFailure e) {
                if (e.status() != 404) {
                    log.warn("admin-services config {} unavailable: {}", k, e.getMessage());
                }
                return Optional.<String>empty();
            }
        });
    }

    @Override
    public Optional<String> secret(String name) {
        Optional<String> cached = secretCache.get(name, n -> {
            try {
                JsonNode node = http.get(base + "/internal/secrets/" + JsonHttp.encode(n), headers);
                JsonNode v = node.get("value");
                return v == null || v.isNull() ? Optional.<String>empty() : Optional.of(v.asText());
            } catch (JsonHttp.HttpFailure e) {
                log.warn("admin-services secret {} unavailable: {} ({})", n, e.status(), e.getMessage());
                return Optional.<String>empty();
            }
        });
        if (cached.isEmpty()) {
            secretCache.invalidate(name);
        }
        return cached;
    }

    @Override
    public ApprovalChain resolve(String flowCode, String requesterId, String requesterEmail, String lob, String location) {
        try {
            JsonNode node = http.get(JsonHttp.query(base + "/internal/approvals/" + JsonHttp.encode(flowCode) + "/resolve",
                    params("requesterId", requesterId, "requesterEmail", requesterEmail, "lob", lob, "location", location)), headers);
            return mapper.treeToValue(node, ApprovalChain.class);
        } catch (Exception e) {
            throw unavailable(e);
        }
    }

    @Override
    public ApprovalCheck canApprove(String flowCode, int level, String approverId, String approverEmail,
                                    String requesterId, String requesterEmail, String lob, String location) {
        try {
            JsonNode node = http.get(JsonHttp.query(base + "/internal/approvals/" + JsonHttp.encode(flowCode) + "/can-approve",
                    params("level", level, "approverId", approverId, "approverEmail", approverEmail,
                            "requesterId", requesterId, "requesterEmail", requesterEmail, "lob", lob, "location", location)), headers);
            return mapper.treeToValue(node, ApprovalCheck.class);
        } catch (Exception e) {
            throw unavailable(e);
        }
    }

    public void evictAccess() {
        accessCache.clear();
    }

    private static APIException unavailable(Exception e) {
        if (e instanceof JsonHttp.HttpFailure f && f.status() == 404) {
            return APIException.badRequest("APPROVAL_FLOW_MISSING", "The approval flow is not configured in admin-services");
        }
        return APIException.unavailable("APPROVAL_SERVICE_UNAVAILABLE", "Approval hierarchy can not be loaded right now");
    }

    private static Map<String, Object> params(Object... kv) {
        Map<String, Object> m = new LinkedHashMap<>();
        for (int i = 0; i < kv.length; i += 2) {
            m.put(String.valueOf(kv[i]), kv[i + 1]);
        }
        return m;
    }
}
