package com.ags.health.hr.assessment.clients;

import com.ags.health.hr.assessment.security.AccessProfile;

public interface AccessDirectory {

    AccessProfile resolve(String userId, String email, String userType);
}
