package com.ags.health.hr.assessment.enums;

public enum EligibilityPurpose { ASSESSMENT, APPLICATION, REGISTRATION }
