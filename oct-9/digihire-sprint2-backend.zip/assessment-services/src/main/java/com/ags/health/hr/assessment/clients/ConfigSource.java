package com.ags.health.hr.assessment.clients;

import java.util.Optional;

public interface ConfigSource {

    Optional<String> value(String key);
}
