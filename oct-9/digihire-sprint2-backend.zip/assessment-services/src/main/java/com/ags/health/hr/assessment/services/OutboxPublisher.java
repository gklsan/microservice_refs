package com.ags.health.hr.assessment.services;

import com.ags.health.hr.assessment.clients.JsonHttp;
import com.ags.health.hr.assessment.config.AssessmentProperties;
import com.ags.health.hr.assessment.data.EventDtos;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

@Slf4j
@Component
@RequiredArgsConstructor
public class OutboxPublisher {

    private final OutboxService outbox;
    private final JsonHttp http;
    private final AssessmentProperties props;

    @Scheduled(cron = "${assessment.jobs.publish-cron}", zone = "${assessment.jobs.zone}")
    public void publish() {
        String url = props.getEvents().getWebhookUrl();
        if (!props.getJobs().isEnabled() || url == null || url.isBlank()) {
            return;
        }
        List<EventDtos.OutboxEvent> batch = outbox.unpublished(Math.max(1, props.getEvents().getBatchSize()));
        if (batch.isEmpty()) {
            return;
        }
        List<Long> seqs = batch.stream().map(EventDtos.OutboxEvent::seq).toList();
        Map<String, String> headers = new LinkedHashMap<>();
        headers.put("X-Internal-Key", props.getEvents().getWebhookKey());
        headers.put("X-Caller-Service", props.getAdmin().getCallerName());
        try {
            http.post(url, headers, batch);
            outbox.markPublished(seqs);
        } catch (RuntimeException e) {
            log.warn("Publishing {} assessment event(s) failed: {}", batch.size(), e.getMessage());
            outbox.markFailed(seqs, e.getMessage());
        }
    }
}
