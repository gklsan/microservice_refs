package com.ags.health.hr.assessment.config;

import com.ags.health.hr.assessment.clients.JsonHttp;
import com.ags.health.hr.assessment.clients.SecretSource;
import com.ags.health.hr.assessment.providers.AssessmentProvider;
import com.ags.health.hr.assessment.providers.ManualProvider;
import com.ags.health.hr.assessment.providers.ProviderRegistry;
import com.ags.health.hr.assessment.providers.RestAssessmentProvider;
import com.ags.health.hr.assessment.providers.VersantProvider;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.ObjectProvider;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

@Configuration
public class ProviderConfig {

    @Bean
    public ProviderRegistry providerRegistry(AssessmentProperties props, ObjectMapper mapper, SecretSource secrets,
                                             ObjectProvider<AssessmentProvider> extra) {
        JsonHttp http = new JsonHttp(mapper, Duration.ofSeconds(20));
        List<AssessmentProvider> providers = new ArrayList<>();
        providers.add(new ManualProvider());
        if (props.getProviders().getVersant().isEnabled()) {
            providers.add(new VersantProvider(props.getProviders().getVersant(), http, secrets));
        }
        props.getProviders().getRest().forEach((code, cfg) -> {
            if (cfg.isEnabled()) {
                providers.add(new RestAssessmentProvider(code.toUpperCase(Locale.ROOT), cfg, http, secrets));
            }
        });
        extra.orderedStream().forEach(providers::add);
        return new ProviderRegistry(providers);
    }
}
