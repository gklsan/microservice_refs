package com.ags.health.hr.assessment.resources;

import com.ags.health.hr.assessment.entities.ApprovalAction;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.UUID;

public interface ApprovalActionRepository extends JpaRepository<ApprovalAction, UUID> {

    List<ApprovalAction> findByRequestIdOrderByActedAtAsc(UUID requestId);
}
