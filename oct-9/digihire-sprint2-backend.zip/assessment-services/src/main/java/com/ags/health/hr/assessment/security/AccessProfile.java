package com.ags.health.hr.assessment.security;

import java.util.Map;
import java.util.Set;
import java.util.UUID;

public record AccessProfile(String userId, UUID adminUserId, String email, boolean active, boolean configured,
                            Set<String> roles, Set<String> permissions, Set<String> conditionalPermissions,
                            Map<String, Object> scope) {

    public AccessProfile {
        roles = roles == null ? Set.of() : Set.copyOf(roles);
        permissions = permissions == null ? Set.of() : Set.copyOf(permissions);
        conditionalPermissions = conditionalPermissions == null ? Set.of() : Set.copyOf(conditionalPermissions);
        scope = scope == null ? Map.of() : scope;
    }

    public boolean has(String permission) {
        return active && permissions.contains(permission);
    }
}
