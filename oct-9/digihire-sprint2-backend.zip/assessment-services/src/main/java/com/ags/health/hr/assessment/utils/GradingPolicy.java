package com.ags.health.hr.assessment.utils;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.math.BigDecimal;
import java.util.Comparator;
import java.util.List;

public final class GradingPolicy {

    public record Band(BigDecimal min, String grade) {
    }

    public record Outcome(boolean passed, String grade) {
    }

    public static final String FAIL_GRADE = "F";

    private GradingPolicy() {
    }

    public static Outcome grade(BigDecimal score, BigDecimal passScore, List<Band> bands, String providerGrade) {
        if (score == null) {
            boolean passed = passScore == null && providerGrade != null && !FAIL_GRADE.equalsIgnoreCase(providerGrade);
            return new Outcome(passed, providerGrade != null ? providerGrade : FAIL_GRADE);
        }
        boolean passed = passScore == null || score.compareTo(passScore) >= 0;
        String grade = providerGrade;
        if (bands != null && !bands.isEmpty()) {
            grade = bands.stream()
                    .filter(b -> b.min() != null && score.compareTo(b.min()) >= 0)
                    .max(Comparator.comparing(Band::min))
                    .map(Band::grade)
                    .orElse(passed ? providerGrade : FAIL_GRADE);
        }
        if (!passed && grade == null) {
            grade = FAIL_GRADE;
        }
        return new Outcome(passed, grade);
    }

    public static List<Band> parseBands(ObjectMapper mapper, String json) {
        if (json == null || json.isBlank()) {
            return List.of();
        }
        try {
            return mapper.readValue(json, new TypeReference<List<Band>>() {
            });
        } catch (Exception e) {
            throw new IllegalArgumentException("gradeBands must be a JSON array of {min, grade}", e);
        }
    }
}
