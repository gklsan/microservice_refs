INSERT INTO asm_assessment_definition (code, name, provider_code, category, external_test_id, cooling_key, pass_score, max_score, grade_bands, validity_days, link_validity_days, active, created_by)
SELECT 'VERSANT_GSE', 'Versant English (GSE)', 'VERSANT', 'LANGUAGE', '144', 'VERSANT', 43, 90, '[{"min":43,"grade":"B1"},{"min":59,"grade":"B2"},{"min":76,"grade":"C1"},{"min":85,"grade":"C2"}]', NULL, 7, TRUE, 'db-seed'
WHERE NOT EXISTS (SELECT 1 FROM asm_schema_change WHERE id = 'assessment-seed-v1')
  AND NOT EXISTS (SELECT 1 FROM asm_assessment_definition WHERE code = 'VERSANT_GSE')@@
INSERT INTO asm_assessment_definition (code, name, provider_code, category, external_test_id, cooling_key, pass_score, max_score, grade_bands, validity_days, link_validity_days, active, created_by)
SELECT 'SHL_COGNITIVE', 'SHL cognitive assessment', 'SHL', 'COGNITIVE', NULL, 'SHL', NULL, 100, NULL, NULL, 7, FALSE, 'db-seed'
WHERE NOT EXISTS (SELECT 1 FROM asm_schema_change WHERE id = 'assessment-seed-v1')
  AND NOT EXISTS (SELECT 1 FROM asm_assessment_definition WHERE code = 'SHL_COGNITIVE')@@
INSERT INTO asm_assessment_definition (code, name, provider_code, category, external_test_id, cooling_key, pass_score, max_score, grade_bands, validity_days, link_validity_days, active, created_by)
SELECT 'TYPING_TEST', 'Typing test', 'MANUAL', 'TYPING', NULL, 'TYPING', NULL, NULL, NULL, NULL, 2, FALSE, 'db-seed'
WHERE NOT EXISTS (SELECT 1 FROM asm_schema_change WHERE id = 'assessment-seed-v1')
  AND NOT EXISTS (SELECT 1 FROM asm_assessment_definition WHERE code = 'TYPING_TEST')@@

INSERT INTO asm_blacklist_reason (code, label, sort_order, created_by) SELECT 'FAKE_DOCUMENTS', 'Forged or fake documents', 10, 'db-seed' WHERE NOT EXISTS (SELECT 1 FROM asm_schema_change WHERE id = 'assessment-seed-v1') AND NOT EXISTS (SELECT 1 FROM asm_blacklist_reason WHERE code = 'FAKE_DOCUMENTS')@@
INSERT INTO asm_blacklist_reason (code, label, sort_order, created_by) SELECT 'ASSESSMENT_MALPRACTICE', 'Malpractice or impersonation in an assessment', 20, 'db-seed' WHERE NOT EXISTS (SELECT 1 FROM asm_schema_change WHERE id = 'assessment-seed-v1') AND NOT EXISTS (SELECT 1 FROM asm_blacklist_reason WHERE code = 'ASSESSMENT_MALPRACTICE')@@
INSERT INTO asm_blacklist_reason (code, label, sort_order, created_by) SELECT 'MISCONDUCT', 'Misconduct during the hiring process', 30, 'db-seed' WHERE NOT EXISTS (SELECT 1 FROM asm_schema_change WHERE id = 'assessment-seed-v1') AND NOT EXISTS (SELECT 1 FROM asm_blacklist_reason WHERE code = 'MISCONDUCT')@@
INSERT INTO asm_blacklist_reason (code, label, sort_order, created_by) SELECT 'OFFER_ABSCONDED', 'Accepted an offer and did not join', 40, 'db-seed' WHERE NOT EXISTS (SELECT 1 FROM asm_schema_change WHERE id = 'assessment-seed-v1') AND NOT EXISTS (SELECT 1 FROM asm_blacklist_reason WHERE code = 'OFFER_ABSCONDED')@@
INSERT INTO asm_blacklist_reason (code, label, sort_order, created_by) SELECT 'OTHER', 'Other (remarks required)', 90, 'db-seed' WHERE NOT EXISTS (SELECT 1 FROM asm_schema_change WHERE id = 'assessment-seed-v1') AND NOT EXISTS (SELECT 1 FROM asm_blacklist_reason WHERE code = 'OTHER')@@

INSERT INTO asm_schema_change (id) SELECT 'assessment-seed-v1' WHERE NOT EXISTS (SELECT 1 FROM asm_schema_change WHERE id = 'assessment-seed-v1')@@
