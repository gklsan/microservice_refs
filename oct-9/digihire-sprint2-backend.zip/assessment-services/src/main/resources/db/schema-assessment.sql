CREATE TABLE IF NOT EXISTS asm_schema_change (
    id          VARCHAR(100) PRIMARY KEY,
    applied_at  TIMESTAMP WITH TIME ZONE  NOT NULL DEFAULT CURRENT_TIMESTAMP
)@@

CREATE TABLE IF NOT EXISTS asm_assessment_definition (
    code                VARCHAR(50)   PRIMARY KEY,
    name                VARCHAR(150)  NOT NULL,
    provider_code       VARCHAR(30)   NOT NULL,
    category            VARCHAR(30)   NOT NULL,
    external_test_id    VARCHAR(100),
    cooling_key         VARCHAR(30),
    pass_score          NUMERIC(8,2),
    max_score           NUMERIC(8,2),
    grade_bands         VARCHAR(2000),
    validity_days       INT,
    link_validity_days  INT,
    settings            VARCHAR(4000),
    active              BOOLEAN       NOT NULL DEFAULT TRUE,
    created_date        TIMESTAMP WITH TIME ZONE  NOT NULL DEFAULT CURRENT_TIMESTAMP,
    created_by          VARCHAR(254),
    updated_date        TIMESTAMP WITH TIME ZONE,
    updated_by          VARCHAR(254),
    version             BIGINT        NOT NULL DEFAULT 0
)@@

CREATE TABLE IF NOT EXISTS asm_assessment_mapping (
    id               UUID          PRIMARY KEY,
    lob              VARCHAR(100),
    role_code        VARCHAR(100),
    location         VARCHAR(100),
    assessment_code  VARCHAR(50)   NOT NULL REFERENCES asm_assessment_definition (code),
    sequence_no      INT           NOT NULL DEFAULT 1,
    trigger_event    VARCHAR(30)   NOT NULL,
    trigger_stage    VARCHAR(60),
    mandatory        BOOLEAN       NOT NULL DEFAULT TRUE,
    active           BOOLEAN       NOT NULL DEFAULT TRUE,
    created_date     TIMESTAMP WITH TIME ZONE  NOT NULL DEFAULT CURRENT_TIMESTAMP,
    created_by       VARCHAR(254),
    updated_date     TIMESTAMP WITH TIME ZONE,
    updated_by       VARCHAR(254),
    version          BIGINT        NOT NULL DEFAULT 0
)@@
CREATE INDEX IF NOT EXISTS ix_asm_mapping_lookup ON asm_assessment_mapping (trigger_event, active)@@

CREATE TABLE IF NOT EXISTS asm_assessment_attempt (
    id                    UUID          PRIMARY KEY,
    candidate_id          VARCHAR(64)   NOT NULL,
    application_id        VARCHAR(64),
    candidate_email       VARCHAR(254),
    candidate_name        VARCHAR(200),
    assessment_code       VARCHAR(50)   NOT NULL REFERENCES asm_assessment_definition (code),
    provider_code         VARCHAR(30)   NOT NULL,
    cooling_key           VARCHAR(30),
    attempt_no            INT           NOT NULL,
    status                VARCHAR(20)   NOT NULL,
    external_ref          VARCHAR(200),
    test_url              VARCHAR(2000),
    invited_at            TIMESTAMP WITH TIME ZONE,
    link_expires_at       TIMESTAMP WITH TIME ZONE,
    started_at            TIMESTAMP WITH TIME ZONE,
    completed_at          TIMESTAMP WITH TIME ZONE,
    result_received_at    TIMESTAMP WITH TIME ZONE,
    score                 NUMERIC(8,2),
    grade                 VARCHAR(20),
    passed                BOOLEAN,
    valid_until           TIMESTAMP WITH TIME ZONE,
    validity_expired_at   TIMESTAMP WITH TIME ZONE,
    cooling_until         TIMESTAMP WITH TIME ZONE,
    cooling_tier          INT,
    fresher_reset         BOOLEAN       NOT NULL DEFAULT FALSE,
    reschedule_count      INT           NOT NULL DEFAULT 0,
    rescheduled_from      UUID,
    lob                   VARCHAR(100),
    role_code             VARCHAR(100),
    location              VARCHAR(100),
    trigger_source        VARCHAR(20)   NOT NULL,
    triggered_by          VARCHAR(254),
    status_reason         VARCHAR(500),
    raw_result            VARCHAR(8000),
    created_date          TIMESTAMP WITH TIME ZONE  NOT NULL DEFAULT CURRENT_TIMESTAMP,
    created_by            VARCHAR(254),
    updated_date          TIMESTAMP WITH TIME ZONE,
    updated_by            VARCHAR(254),
    version               BIGINT        NOT NULL DEFAULT 0
)@@
CREATE INDEX IF NOT EXISTS ix_asm_attempt_candidate ON asm_assessment_attempt (candidate_id, cooling_key, created_date)@@
CREATE INDEX IF NOT EXISTS ix_asm_attempt_application ON asm_assessment_attempt (application_id)@@
CREATE INDEX IF NOT EXISTS ix_asm_attempt_status ON asm_assessment_attempt (status, provider_code)@@
CREATE INDEX IF NOT EXISTS ix_asm_attempt_ref ON asm_assessment_attempt (provider_code, external_ref)@@
CREATE INDEX IF NOT EXISTS ix_asm_attempt_validity ON asm_assessment_attempt (passed, valid_until)@@

CREATE TABLE IF NOT EXISTS asm_candidate_restriction (
    id                     UUID          PRIMARY KEY,
    candidate_id           VARCHAR(64)   NOT NULL,
    candidate_email        VARCHAR(254),
    restriction_type       VARCHAR(30)   NOT NULL,
    reason                 VARCHAR(500),
    source_application_id  VARCHAR(64),
    source_attempt_id      UUID,
    source_role_code       VARCHAR(100),
    source_location        VARCHAR(100),
    starts_at              TIMESTAMP WITH TIME ZONE  NOT NULL,
    ends_at                TIMESTAMP WITH TIME ZONE  NOT NULL,
    active                 BOOLEAN       NOT NULL DEFAULT TRUE,
    created_date           TIMESTAMP WITH TIME ZONE  NOT NULL DEFAULT CURRENT_TIMESTAMP,
    created_by             VARCHAR(254),
    updated_date           TIMESTAMP WITH TIME ZONE,
    updated_by             VARCHAR(254),
    version                BIGINT        NOT NULL DEFAULT 0
)@@
CREATE INDEX IF NOT EXISTS ix_asm_restriction_candidate ON asm_candidate_restriction (candidate_id, restriction_type, ends_at)@@

CREATE TABLE IF NOT EXISTS asm_approval_request (
    id                   UUID          PRIMARY KEY,
    subject_type         VARCHAR(40)   NOT NULL,
    subject_id           VARCHAR(64)   NOT NULL,
    flow_code            VARCHAR(60)   NOT NULL,
    status               VARCHAR(20)   NOT NULL,
    current_level        INT           NOT NULL,
    total_levels         INT           NOT NULL,
    candidate_id         VARCHAR(64),
    requested_by_id      VARCHAR(100),
    requested_by_email   VARCHAR(254),
    requested_by_name    VARCHAR(200),
    reason_code          VARCHAR(40),
    reason               VARCHAR(1000),
    lob                  VARCHAR(100),
    location             VARCHAR(100),
    requested_at         TIMESTAMP WITH TIME ZONE  NOT NULL,
    decided_at           TIMESTAMP WITH TIME ZONE,
    created_date         TIMESTAMP WITH TIME ZONE  NOT NULL DEFAULT CURRENT_TIMESTAMP,
    created_by           VARCHAR(254),
    updated_date         TIMESTAMP WITH TIME ZONE,
    updated_by           VARCHAR(254),
    version              BIGINT        NOT NULL DEFAULT 0
)@@
CREATE INDEX IF NOT EXISTS ix_asm_approval_status ON asm_approval_request (status, subject_type)@@
CREATE INDEX IF NOT EXISTS ix_asm_approval_subject ON asm_approval_request (subject_type, subject_id)@@

CREATE TABLE IF NOT EXISTS asm_approval_action (
    id           UUID          PRIMARY KEY,
    request_id   UUID          NOT NULL REFERENCES asm_approval_request (id),
    level_no     INT           NOT NULL,
    decision     VARCHAR(20)   NOT NULL,
    actor_id     VARCHAR(100),
    actor_email  VARCHAR(254),
    actor_name   VARCHAR(200),
    comment_text VARCHAR(1000),
    acted_at     TIMESTAMP WITH TIME ZONE  NOT NULL
)@@
CREATE INDEX IF NOT EXISTS ix_asm_approval_action_request ON asm_approval_action (request_id, level_no)@@

CREATE TABLE IF NOT EXISTS asm_blacklist_reason (
    code        VARCHAR(40)   PRIMARY KEY,
    label       VARCHAR(200)  NOT NULL,
    active      BOOLEAN       NOT NULL DEFAULT TRUE,
    sort_order  INT           NOT NULL DEFAULT 0,
    created_date  TIMESTAMP WITH TIME ZONE  NOT NULL DEFAULT CURRENT_TIMESTAMP,
    created_by    VARCHAR(254),
    updated_date  TIMESTAMP WITH TIME ZONE,
    updated_by    VARCHAR(254),
    version       BIGINT        NOT NULL DEFAULT 0
)@@

CREATE TABLE IF NOT EXISTS asm_blacklist (
    id                   UUID          PRIMARY KEY,
    candidate_id         VARCHAR(64),
    display_name         VARCHAR(200),
    masked_email         VARCHAR(254),
    masked_mobile        VARCHAR(40),
    email_hash           VARCHAR(64),
    mobile_hash          VARCHAR(64),
    id_proof_hash        VARCHAR(64),
    reason_code          VARCHAR(40)   NOT NULL REFERENCES asm_blacklist_reason (code),
    remarks              VARCHAR(1000),
    status               VARCHAR(20)   NOT NULL,
    blacklisted_by       VARCHAR(254),
    blacklisted_at       TIMESTAMP WITH TIME ZONE  NOT NULL,
    removal_request_id   UUID,
    removed_by           VARCHAR(254),
    removed_at           TIMESTAMP WITH TIME ZONE,
    removal_reason       VARCHAR(1000),
    created_date         TIMESTAMP WITH TIME ZONE  NOT NULL DEFAULT CURRENT_TIMESTAMP,
    created_by           VARCHAR(254),
    updated_date         TIMESTAMP WITH TIME ZONE,
    updated_by           VARCHAR(254),
    version              BIGINT        NOT NULL DEFAULT 0
)@@
CREATE INDEX IF NOT EXISTS ix_asm_blacklist_candidate ON asm_blacklist (candidate_id, status)@@
CREATE INDEX IF NOT EXISTS ix_asm_blacklist_email ON asm_blacklist (email_hash, status)@@
CREATE INDEX IF NOT EXISTS ix_asm_blacklist_mobile ON asm_blacklist (mobile_hash, status)@@
CREATE INDEX IF NOT EXISTS ix_asm_blacklist_idproof ON asm_blacklist (id_proof_hash, status)@@

CREATE TABLE IF NOT EXISTS asm_outbox_event (
    seq             BIGINT        GENERATED BY DEFAULT AS IDENTITY PRIMARY KEY,
    id              UUID          NOT NULL UNIQUE,
    event_type      VARCHAR(60)   NOT NULL,
    aggregate_type  VARCHAR(40)   NOT NULL,
    aggregate_id    VARCHAR(64)   NOT NULL,
    candidate_id    VARCHAR(64),
    application_id  VARCHAR(64),
    payload         VARCHAR(8000) NOT NULL,
    created_at      TIMESTAMP WITH TIME ZONE  NOT NULL DEFAULT CURRENT_TIMESTAMP,
    published_at    TIMESTAMP WITH TIME ZONE,
    publish_attempts INT          NOT NULL DEFAULT 0,
    last_error      VARCHAR(500)
)@@
CREATE INDEX IF NOT EXISTS ix_asm_outbox_unpublished ON asm_outbox_event (published_at, seq)@@

CREATE TABLE IF NOT EXISTS adm_audit_log (
    id              UUID          PRIMARY KEY,
    category        VARCHAR(30)   NOT NULL,
    action          VARCHAR(100)  NOT NULL,
    entity_type     VARCHAR(60),
    entity_id       VARCHAR(100),
    candidate_id    VARCHAR(100),
    actor_id        VARCHAR(100),
    actor_name      VARCHAR(200),
    actor_email     VARCHAR(254),
    actor_roles     VARCHAR(500),
    outcome         VARCHAR(10)   NOT NULL DEFAULT 'SUCCESS',
    description     VARCHAR(2000),
    details         JSON,
    correlation_id  VARCHAR(64),
    service_name    VARCHAR(60),
    client_ip       VARCHAR(64),
    occurred_at     TIMESTAMP WITH TIME ZONE   NOT NULL DEFAULT CURRENT_TIMESTAMP
)@@
CREATE INDEX IF NOT EXISTS ix_adm_audit_occurred ON adm_audit_log (occurred_at DESC)@@
CREATE INDEX IF NOT EXISTS ix_adm_audit_entity   ON adm_audit_log (entity_type, entity_id)@@
CREATE INDEX IF NOT EXISTS ix_adm_audit_candidate ON adm_audit_log (candidate_id, occurred_at DESC)@@
