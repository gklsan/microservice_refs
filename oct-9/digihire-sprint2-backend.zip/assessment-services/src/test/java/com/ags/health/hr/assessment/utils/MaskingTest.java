package com.ags.health.hr.assessment.utils;

import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThat;

class MaskingTest {

    @Test
    void normalisesAndMasksIdentifiers() {
        assertThat(Masking.normalizeEmail("  Priya.R@AGSHealth.com ")).isEqualTo("priya.r@agshealth.com");
        assertThat(Masking.normalizeMobile("+91 98765-43210")).isEqualTo("9876543210");
        assertThat(Masking.normalizeIdProof("abcde 1234-f")).isEqualTo("ABCDE1234F");
        assertThat(Masking.maskEmail("priya.r@agshealth.com")).isEqualTo("p***@agshealth.com");
        assertThat(Masking.maskMobile("9876543210")).isEqualTo("******3210");
        assertThat(Masking.normalizeMobile("abc")).isNull();
    }
}
