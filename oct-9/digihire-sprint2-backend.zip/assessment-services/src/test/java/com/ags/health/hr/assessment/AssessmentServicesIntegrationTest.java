package com.ags.health.hr.assessment;

import com.ags.health.hr.assessment.clients.AdminServicesClient;
import com.ags.health.hr.assessment.clients.ApprovalDirectory;
import com.ags.health.hr.assessment.security.AccessProfile;
import com.ags.health.hr.assessment.services.AssessmentService;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import io.jsonwebtoken.io.Decoders;
import io.jsonwebtoken.security.Keys;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.ResultActions;
import org.springframework.test.web.servlet.request.MockHttpServletRequestBuilder;

import java.sql.Timestamp;
import java.time.Duration;
import java.time.Instant;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;

import static org.assertj.core.api.Assertions.assertThat;
import static org.hamcrest.Matchers.hasItem;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@SpringBootTest(properties = {
        "eureka.client.enabled=false",
        "spring.sql.init.mode=always",
        "spring.datasource.url=jdbc:h2:mem:asm_it;DB_CLOSE_DELAY=-1;DB_CLOSE_ON_EXIT=FALSE",
        "spring.datasource.driver-class-name=org.h2.Driver",
        "spring.datasource.username=sa",
        "spring.datasource.password=",
        "spring.jpa.properties.hibernate.dialect=org.hibernate.dialect.H2Dialect",
        "assessment.security.jwt-secret=" + AssessmentServicesIntegrationTest.SECRET,
        "assessment.security.internal-api-key=" + AssessmentServicesIntegrationTest.INTERNAL_KEY,
        "assessment.jobs.enabled=false",
        "assessment.rules.cooling-days.TYPING=7,30,180",
        "assessment.rules.voice-fresher-role-codes=VOICE_FRESHER_CSR",
        "assessment.blacklist.pepper=test-pepper-0123456789"
})
@AutoConfigureMockMvc
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
class AssessmentServicesIntegrationTest {

    static final String SECRET = "c2VjcmV0LWtleS1mb3ItdGVzdHMtb25seS0zMi1ieXRlcy1sb25nISE=";
    static final String INTERNAL_KEY = "asm-internal-key";

    static final String REC = "rec@agshealth.com";
    static final String RM = "rm@agshealth.com";
    static final String TAH = "tah@agshealth.com";
    static final String ADMIN = "admin@agshealth.com";

    private static final Set<String> RECRUITER = Set.of("ASSESSMENT:VIEW", "ASSESSMENT:TRIGGER", "ASSESSMENT:RESULT_ENTRY",
            "ASSESSMENT:RESCHEDULE_REQUEST", "BLACKLIST:VIEW");
    private static final Set<String> MANAGER = union(RECRUITER, Set.of("ASSESSMENT:RESCHEDULE_APPROVE", "ASSESSMENT_CONFIG:VIEW",
            "BLACKLIST:CREATE", "BLACKLIST:REMOVE_REQUEST"));
    private static final Set<String> TA_HEAD = union(MANAGER, Set.of("BLACKLIST:REMOVE_APPROVE"));
    private static final Set<String> SUPER_ADMIN = Set.of("ASSESSMENT_CONFIG:VIEW", "ASSESSMENT_CONFIG:MANAGE",
            "BLACKLIST_REASON:MANAGE");

    @MockBean
    AdminServicesClient admin;
    @Autowired
    MockMvc mvc;
    @Autowired
    ObjectMapper mapper;
    @Autowired
    JdbcTemplate jdbc;
    @Autowired
    AssessmentService assessments;

    static String firstAttemptId;
    static String blacklistId;

    @BeforeEach
    void stubAdminServices() {
        when(admin.resolve(any(), any(), any())).thenAnswer(inv -> profile(inv.getArgument(1)));
        when(admin.value(any())).thenReturn(Optional.empty());
        when(admin.secret(any())).thenReturn(Optional.empty());
        when(admin.resolve(any(), any(), any(), any(), any())).thenReturn(new ApprovalDirectory.ApprovalChain("FLOW", "Flow", true,
                List.of(new ApprovalDirectory.ChainLevel(1, "Manager", 1, 24, false, false, List.of(
                        new ApprovalDirectory.Approver(UUID.randomUUID(), "rm-1", RM, "Manager", false))))));
        when(admin.canApprove(any(), anyInt(), any(), any(), any(), any(), any(), any())).thenAnswer(inv -> {
            String approverEmail = inv.getArgument(3);
            boolean ok = RM.equals(approverEmail) || TAH.equals(approverEmail);
            int level = inv.getArgument(1);
            return new ApprovalDirectory.ApprovalCheck(ok, ok ? "IN_APPROVER_LIST" : "NOT_AN_APPROVER", level, 1, 1);
        });
    }

    private static AccessProfile profile(String email) {
        Set<String> perms = switch (email) {
            case REC -> RECRUITER;
            case RM -> MANAGER;
            case TAH -> TA_HEAD;
            case ADMIN -> SUPER_ADMIN;
            default -> Set.of();
        };
        return new AccessProfile(email, null, email, true, true, Set.of("ROLE_OF_" + email.substring(0, email.indexOf('@'))),
                perms, Set.of(), Map.of());
    }

    private static Set<String> union(Set<String> a, Set<String> b) {
        Set<String> s = new HashSet<>(a);
        s.addAll(b);
        return Set.copyOf(s);
    }

    static String token(String email) {
        return "Bearer " + Jwts.builder()
                .setSubject(email)
                .addClaims(Map.of("userId", email, "email", email, "userType", "EMPLOYEE_HR", "userName", email))
                .setIssuedAt(new Date())
                .setExpiration(new Date(System.currentTimeMillis() + 3_600_000))
                .signWith(Keys.hmacShaKeyFor(Decoders.BASE64.decode(SECRET)), SignatureAlgorithm.HS256)
                .compact();
    }

    private ResultActions call(MockHttpServletRequestBuilder req, String email, Object body) throws Exception {
        if (email != null) {
            req.header("Authorization", token(email));
        }
        return send(req, body);
    }

    private ResultActions internal(MockHttpServletRequestBuilder req, Object body) throws Exception {
        req.header("X-Internal-Key", INTERNAL_KEY).header("X-Caller-Service", "candidate-services");
        return send(req, body);
    }

    private ResultActions send(MockHttpServletRequestBuilder req, Object body) throws Exception {
        if (body != null) {
            req.contentType(MediaType.APPLICATION_JSON).content(body instanceof String s ? s : mapper.writeValueAsString(body));
        }
        return mvc.perform(req).andDo(r -> {
            if (r.getResponse().getStatus() >= 400) {
                System.out.println("[IT] " + r.getRequest().getMethod() + " " + r.getRequest().getRequestURI() + " -> "
                        + r.getResponse().getStatus() + " " + r.getResponse().getContentAsString());
            }
        });
    }

    private JsonNode json(ResultActions r) throws Exception {
        return mapper.readTree(r.andReturn().getResponse().getContentAsString());
    }

    private static Map<String, Object> invite(String candidateId, String role, String location) {
        return Map.of("candidateId", candidateId, "applicationId", "app-" + candidateId, "candidateEmail", candidateId + "@example.com",
                "candidateName", "Candidate " + candidateId, "assessmentCode", "TYPING_TEST", "lob", "coding",
                "roleCode", role, "location", location);
    }

    @Test
    @Order(1)
    void seedIsLoaded() {
        assertThat(jdbc.queryForObject("SELECT count(*) FROM asm_assessment_definition", Integer.class)).isEqualTo(3);
        assertThat(jdbc.queryForObject("SELECT count(*) FROM asm_blacklist_reason", Integer.class)).isEqualTo(5);
    }

    @Test
    @Order(2)
    void configureTypingTestAndInvite() throws Exception {
        call(put("/config/assessments/TYPING_TEST"), REC, Map.of("code", "TYPING_TEST", "name", "Typing test",
                "providerCode", "MANUAL", "category", "TYPING")).andExpect(status().isForbidden());
        call(put("/config/assessments/TYPING_TEST"), ADMIN, Map.of("code", "TYPING_TEST", "name", "Typing test",
                "providerCode", "MANUAL", "category", "TYPING", "coolingKey", "TYPING", "passScore", 30, "active", true,
                "linkValidityDays", 2)).andExpect(status().isOk()).andExpect(jsonPath("$.active").value(true));

        JsonNode attempt = json(call(post("/assessments/invite"), REC, invite("cand-1", "AR_CALLER", "chennai"))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.status").value("INVITED"))
                .andExpect(jsonPath("$.attemptNo").value(1))
                .andExpect(jsonPath("$.lob").value("CODING")));
        firstAttemptId = attempt.get("id").asText();

        call(post("/assessments/invite"), REC, invite("cand-1", "AR_CALLER", "chennai")).andExpect(status().isConflict())
                .andExpect(jsonPath("$.code").value("NOT_ELIGIBLE"))
                .andExpect(jsonPath("$.reasons[*].code", hasItem("ATTEMPT_IN_PROGRESS")));
    }

    @Test
    @Order(3)
    void failureStartsCoolingAndAnApprovedTechnicalRescheduleClearsIt() throws Exception {
        call(post("/assessments/" + firstAttemptId + "/results"), REC, Map.of("score", 20)).andExpect(status().isOk())
                .andExpect(jsonPath("$.status").value("FAILED"))
                .andExpect(jsonPath("$.grade").value("F"))
                .andExpect(jsonPath("$.coolingTier").value(1));
        call(post("/assessments/invite"), REC, invite("cand-1", "AR_CALLER", "chennai")).andExpect(status().isConflict())
                .andExpect(jsonPath("$.reasons[*].code", hasItem("COOLING_PERIOD")));

        JsonNode request = json(call(post("/assessments/" + firstAttemptId + "/reschedule-requests"), REC,
                Map.of("reasonCode", "SYSTEM_CRASH", "details", "Typing tool froze at minute 3"))
                .andExpect(status().isCreated()).andExpect(jsonPath("$.status").value("PENDING")));
        String requestId = request.get("id").asText();

        call(post("/approvals/" + requestId + "/approve"), REC, Map.of()).andExpect(status().isForbidden());
        call(get("/approvals?mine=true"), RM, null).andExpect(status().isOk())
                .andExpect(jsonPath("$[*].id", hasItem(requestId)));
        call(post("/approvals/" + requestId + "/approve"), RM, Map.of("comment", "Tool outage confirmed"))
                .andExpect(status().isOk()).andExpect(jsonPath("$.status").value("APPROVED"));

        call(get("/assessments/" + firstAttemptId), REC, null).andExpect(jsonPath("$.status").value("RESCHEDULED"))
                .andExpect(jsonPath("$.coolingUntil").doesNotExist());
        call(get("/assessments?candidateId=cand-1"), REC, null).andExpect(jsonPath("$.totalElements").value(2))
                .andExpect(jsonPath("$.content[0].status").value("INVITED"))
                .andExpect(jsonPath("$.content[0].rescheduleCount").value(1))
                .andExpect(jsonPath("$.content[0].rescheduledFrom").value(firstAttemptId));
    }

    @Test
    @Order(4)
    void passingScoreIsValidForSixtyDaysAndIsReused() throws Exception {
        String second = json(call(get("/assessments?candidateId=cand-1"), REC, null)).at("/content/0/id").asText();
        call(post("/assessments/" + second + "/results"), REC, Map.of("score", 35)).andExpect(status().isOk())
                .andExpect(jsonPath("$.status").value("COMPLETED"))
                .andExpect(jsonPath("$.passed").value(true))
                .andExpect(jsonPath("$.scoreValid").value(true));
        call(post("/assessments/invite"), REC, invite("cand-1", "AR_CALLER", "chennai")).andExpect(status().isConflict())
                .andExpect(jsonPath("$.reasons[*].code", hasItem("VALID_SCORE_EXISTS")));
        internal(get("/internal/candidates/cand-1/valid-scores"), null).andExpect(status().isOk())
                .andExpect(jsonPath("$.length()").value(1));
    }

    @Test
    @Order(5)
    void voiceFresherRejectionInChennaiBlocksVoiceFresherRolesEverywhere() throws Exception {
        internal(post("/internal/events/application"), Map.of("eventType", "REJECTED", "candidateId", "cand-2",
                "roleCode", "voice_fresher_csr", "location", "Chennai")).andExpect(status().isOk())
                .andExpect(jsonPath("$.restrictionApplied").value(true));
        internal(post("/internal/eligibility/check"), Map.of("candidateId", "cand-2", "roleCode", "VOICE_FRESHER_CSR",
                "location", "Coimbatore", "purpose", "APPLICATION")).andExpect(jsonPath("$.eligible").value(false))
                .andExpect(jsonPath("$.reasons[0].code").value("VOICE_FRESHER_RESTRICTED"));
        internal(post("/internal/eligibility/check"), Map.of("candidateId", "cand-2", "roleCode", "AR_CALLER",
                "location", "Chennai", "purpose", "APPLICATION")).andExpect(jsonPath("$.eligible").value(true));
        internal(post("/internal/events/application"), Map.of("eventType", "REJECTED", "candidateId", "cand-3",
                "roleCode", "VOICE_FRESHER_CSR", "location", "Pune")).andExpect(jsonPath("$.restrictionApplied").value(false));
    }

    @Test
    @Order(6)
    void blacklistBlocksAndRemovalNeedsApproval() throws Exception {
        Map<String, Object> add = Map.of("candidateId", "cand-4", "candidateName", "Test Person", "email", "bad@example.com",
                "mobile", "+91 98765 43210", "reasonCode", "FAKE_DOCUMENTS", "remarks", "Forged degree certificate");
        call(post("/blacklist"), REC, add).andExpect(status().isForbidden());
        JsonNode entry = json(call(post("/blacklist"), RM, add).andExpect(status().isCreated())
                .andExpect(jsonPath("$.maskedEmail").value("b***@example.com"))
                .andExpect(jsonPath("$.maskedMobile").value("******3210")));
        blacklistId = entry.get("id").asText();
        String stored = jdbc.queryForObject("SELECT email_hash FROM asm_blacklist WHERE id = CAST(? AS UUID)", String.class, blacklistId);
        assertThat(stored).hasSize(64).doesNotContain("bad");

        call(post("/blacklist"), RM, add).andExpect(status().isConflict()).andExpect(jsonPath("$.code").value("ALREADY_BLACKLISTED"));
        internal(post("/internal/blacklist/check"), Map.of("mobile", "9876543210")).andExpect(jsonPath("$.blacklisted").value(true))
                .andExpect(jsonPath("$.matches[0].matchedOn[0]").value("MOBILE"));
        call(post("/assessments/invite"), REC, invite("cand-4", "AR_CALLER", "chennai")).andExpect(status().isConflict())
                .andExpect(jsonPath("$.reasons[*].code", hasItem("BLACKLISTED")));

        JsonNode detail = json(call(post("/blacklist/" + blacklistId + "/removal-requests"), RM,
                Map.of("reason", "Certificate verified with the university")).andExpect(status().isCreated())
                .andExpect(jsonPath("$.entry.status").value("REMOVAL_PENDING"))
                .andExpect(jsonPath("$.removalRequest.status").value("PENDING")));
        String requestId = detail.at("/removalRequest/id").asText();

        call(post("/approvals/" + requestId + "/approve"), RM, Map.of()).andExpect(status().isForbidden());
        call(post("/approvals/" + requestId + "/approve"), TAH, Map.of("comment", "ok")).andExpect(status().isOk())
                .andExpect(jsonPath("$.status").value("APPROVED"));
        call(get("/blacklist/" + blacklistId), RM, null).andExpect(jsonPath("$.entry.status").value("REMOVED"))
                .andExpect(jsonPath("$.history[*].action", hasItem("CANDIDATE_UNBLACKLISTED")));
        internal(post("/internal/blacklist/check"), Map.of("email", "BAD@example.com")).andExpect(jsonPath("$.blacklisted").value(false));
    }

    @Test
    @Order(7)
    void applicationEventsAutoTriggerTheMappedAssessment() throws Exception {
        call(post("/config/mappings"), ADMIN, Map.of("lob", "coding", "assessmentCode", "TYPING_TEST",
                "triggerEvent", "APPLICATION_CREATED")).andExpect(status().isCreated());
        Map<String, Object> created = Map.of("eventType", "CREATED", "candidateId", "cand-5", "applicationId", "app-5",
                "candidateEmail", "cand-5@example.com", "lob", "Coding", "roleCode", "AR_CALLER", "location", "Chennai");
        internal(post("/internal/events/application"), created).andExpect(status().isOk())
                .andExpect(jsonPath("$.items[0].assessmentCode").value("TYPING_TEST"))
                .andExpect(jsonPath("$.items[0].action").value("INVITED"));
        internal(post("/internal/events/application"), created).andExpect(jsonPath("$.items[0].action").value("SKIPPED"));
        internal(post("/internal/events/application"), Map.of("eventType", "CREATED", "candidateId", "cand-6", "lob", "billing"))
                .andExpect(jsonPath("$.items").isEmpty());
    }

    @Test
    @Order(8)
    void expiredScoresRaiseAnEventForTheFresherPipeline() throws Exception {
        int updated = jdbc.update("UPDATE asm_assessment_attempt SET valid_until = ? WHERE candidate_id = 'cand-1' AND status = 'COMPLETED'",
                Timestamp.from(Instant.now().minus(Duration.ofDays(1))));
        assertThat(updated).isEqualTo(1);
        assertThat(assessments.expireScores()).isEqualTo(1);
        assertThat(assessments.expireScores()).isZero();
        internal(get("/internal/events?afterSeq=0&limit=500"), null).andExpect(status().isOk())
                .andExpect(jsonPath("$[*].eventType", hasItem("ASSESSMENT_SCORE_EXPIRED")))
                .andExpect(jsonPath("$[*].eventType", hasItem("ASSESSMENT_INVITED")));
        internal(post("/internal/eligibility/check"), Map.of("candidateId", "cand-1", "assessmentCode", "TYPING_TEST",
                "purpose", "ASSESSMENT")).andExpect(jsonPath("$.eligible").value(true));
    }

    @Test
    @Order(9)
    void everyStepIsInTheCentralAuditLog() {
        List<String> actions = jdbc.queryForList("SELECT action FROM adm_audit_log WHERE service_name = 'assessment-services' "
                + "AND candidate_id = 'cand-1'", String.class);
        assertThat(actions).contains("ASSESSMENT_INVITED", "ASSESSMENT_RESULT_RECORDED", "APPROVAL_REQUESTED", "APPROVAL_APPROVE",
                "ASSESSMENT_RESCHEDULED", "ASSESSMENT_SCORE_VALIDITY_EXPIRED");
        Integer blocked = jdbc.queryForObject("SELECT count(*) FROM adm_audit_log WHERE action = 'ASSESSMENT_INVITE_BLOCKED'",
                Integer.class);
        assertThat(blocked).isGreaterThanOrEqualTo(3);
    }

    @Test
    @Order(10)
    void unauthenticatedCallsAreRejected() throws Exception {
        mvc.perform(get("/assessments")).andExpect(status().isUnauthorized()).andExpect(jsonPath("$.code").value("UNAUTHORIZED"));
        mvc.perform(get("/internal/events")).andExpect(status().isUnauthorized());
        send(post("/callbacks/MANUAL"), "{}").andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.code").value("CALLBACK_NOT_SUPPORTED"));
    }
}
