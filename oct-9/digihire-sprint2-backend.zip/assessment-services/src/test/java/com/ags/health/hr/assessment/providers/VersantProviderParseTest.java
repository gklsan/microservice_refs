package com.ags.health.hr.assessment.providers;

import com.ags.health.hr.assessment.enums.ProviderResultStatus;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.Test;

import java.math.BigDecimal;

import static org.assertj.core.api.Assertions.assertThat;

class VersantProviderParseTest {

    private final ObjectMapper mapper = new ObjectMapper();

    @Test
    void readsOverallGseScoreFromParts() throws Exception {
        ProviderResult r = VersantProvider.parse("TIN-1", mapper.readTree(
                "{\"tin\":\"TIN-1\",\"status\":\"SCORED\",\"parts\":[{\"name\":\"Speaking\",\"score\":50},"
                        + "{\"name\":\"Overall GSE Score\",\"score\":61}],\"completionDate\":\"2026-10-05T10:15:30Z\"}"));
        assertThat(r.status()).isEqualTo(ProviderResultStatus.COMPLETED);
        assertThat(r.score()).isEqualByComparingTo(new BigDecimal("61"));
        assertThat(r.completedAt()).isNotNull();
    }

    @Test
    void mapsProgressNotStartedAndNotScored() throws Exception {
        assertThat(VersantProvider.parse("T", mapper.readTree("{\"status\":\"IN_PROGRESS\"}")).status())
                .isEqualTo(ProviderResultStatus.IN_PROGRESS);
        assertThat(VersantProvider.parse("T", mapper.readTree("{\"status\":\"NOT_STARTED\"}")).status())
                .isEqualTo(ProviderResultStatus.PENDING);
        ProviderResult notScored = VersantProvider.parse("T", mapper.readTree("{\"status\":\"NOT_SCORED\"}"));
        assertThat(notScored.status()).isEqualTo(ProviderResultStatus.COMPLETED);
        assertThat(notScored.score()).isNull();
    }
}
