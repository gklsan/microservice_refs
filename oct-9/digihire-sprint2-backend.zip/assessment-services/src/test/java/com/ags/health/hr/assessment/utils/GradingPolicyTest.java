package com.ags.health.hr.assessment.utils;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.Test;

import java.math.BigDecimal;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;

class GradingPolicyTest {

    private static final List<GradingPolicy.Band> GSE = GradingPolicy.parseBands(new ObjectMapper(),
            "[{\"min\":43,\"grade\":\"B1\"},{\"min\":59,\"grade\":\"B2\"},{\"min\":76,\"grade\":\"C1\"},{\"min\":85,\"grade\":\"C2\"}]");
    private static final BigDecimal PASS = new BigDecimal("43");

    @Test
    void versantGseBandsMatchTheExistingCron() {
        assertThat(GradingPolicy.grade(new BigDecimal("43"), PASS, GSE, null)).isEqualTo(new GradingPolicy.Outcome(true, "B1"));
        assertThat(GradingPolicy.grade(new BigDecimal("58"), PASS, GSE, null).grade()).isEqualTo("B1");
        assertThat(GradingPolicy.grade(new BigDecimal("59"), PASS, GSE, null).grade()).isEqualTo("B2");
        assertThat(GradingPolicy.grade(new BigDecimal("76"), PASS, GSE, null).grade()).isEqualTo("C1");
        assertThat(GradingPolicy.grade(new BigDecimal("90"), PASS, GSE, null).grade()).isEqualTo("C2");
        assertThat(GradingPolicy.grade(new BigDecimal("42.5"), PASS, GSE, null)).isEqualTo(new GradingPolicy.Outcome(false, "F"));
    }

    @Test
    void notScoredFailsWhenThereIsAPassMark() {
        assertThat(GradingPolicy.grade(null, PASS, GSE, null)).isEqualTo(new GradingPolicy.Outcome(false, "F"));
    }

    @Test
    void noPassMarkMeansInformationalScore() {
        assertThat(GradingPolicy.grade(new BigDecimal("12"), null, List.of(), null).passed()).isTrue();
    }
}
