package com.ags.health.hr.assessment.utils;

import com.ags.health.hr.assessment.entities.AssessmentAttempt;
import com.ags.health.hr.assessment.enums.AttemptStatus;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;

class CoolingPolicyTest {

    private static final List<Integer> SHL = List.of(7, 30, 180);
    private static final List<Integer> VERSANT = List.of(15, 45, 180);

    @Test
    void shlTiersFollowTheBrd() {
        assertThat(CoolingPolicy.decide(SHL, 1)).contains(new CoolingPolicy.Decision(1, 7, false));
        assertThat(CoolingPolicy.decide(SHL, 2)).contains(new CoolingPolicy.Decision(2, 30, false));
        assertThat(CoolingPolicy.decide(SHL, 3)).contains(new CoolingPolicy.Decision(3, 180, true));
        assertThat(CoolingPolicy.decide(SHL, 7)).contains(new CoolingPolicy.Decision(3, 180, true));
    }

    @Test
    void versantTiersFollowTheBrd() {
        assertThat(CoolingPolicy.decide(VERSANT, 1).orElseThrow().days()).isEqualTo(15);
        assertThat(CoolingPolicy.decide(VERSANT, 2).orElseThrow().days()).isEqualTo(45);
        assertThat(CoolingPolicy.decide(VERSANT, 3).orElseThrow().fresherReset()).isTrue();
    }

    @Test
    void noRulesMeansNoCooling() {
        assertThat(CoolingPolicy.decide(List.of(), 1)).isEmpty();
        assertThat(CoolingPolicy.decide(null, 1)).isEmpty();
        assertThat(CoolingPolicy.decide(SHL, 0)).isEmpty();
    }

    @Test
    void failuresAreCountedPerCycleAndRescheduledOrPassedAttemptsDoNotCount() {
        List<AssessmentAttempt> history = new ArrayList<>();
        history.add(attempt(AttemptStatus.FAILED, false));
        history.add(attempt(AttemptStatus.RESCHEDULED, false));
        history.add(attempt(AttemptStatus.COMPLETED, false));
        history.add(attempt(AttemptStatus.FAILED, false));
        assertThat(CoolingPolicy.failuresInCurrentCycle(history)).isEqualTo(2);
        history.add(attempt(AttemptStatus.FAILED, true));
        assertThat(CoolingPolicy.failuresInCurrentCycle(history)).isZero();
        history.add(attempt(AttemptStatus.FAILED, false));
        assertThat(CoolingPolicy.failuresInCurrentCycle(history)).isEqualTo(1);
    }

    private static AssessmentAttempt attempt(AttemptStatus status, boolean fresherReset) {
        AssessmentAttempt a = new AssessmentAttempt();
        a.setStatus(status);
        a.setFresherReset(fresherReset);
        return a;
    }
}
