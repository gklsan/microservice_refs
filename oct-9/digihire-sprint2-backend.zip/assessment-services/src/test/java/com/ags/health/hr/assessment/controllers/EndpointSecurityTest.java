package com.ags.health.hr.assessment.controllers;

import org.junit.jupiter.api.Test;
import org.springframework.core.annotation.AnnotatedElementUtils;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;

class EndpointSecurityTest {

    private static final List<Class<?>> CONTROLLERS = List.of(AssessmentConfigController.class, AssessmentController.class,
            ApprovalController.class, BlacklistController.class, InternalController.class, CallbackController.class);

    @Test
    void everyEndpointDeclaresItsRule() {
        List<String> problems = new ArrayList<>();
        for (Class<?> c : CONTROLLERS) {
            assertThat(c.isAnnotationPresent(RestController.class)).isTrue();
            RequestMapping base = c.getAnnotation(RequestMapping.class);
            String prefix = base == null || base.value().length == 0 ? "" : base.value()[0];
            for (Method m : c.getDeclaredMethods()) {
                if (AnnotatedElementUtils.findMergedAnnotation(m, RequestMapping.class) == null) {
                    continue;
                }
                PreAuthorize rule = m.getAnnotation(PreAuthorize.class);
                String name = c.getSimpleName() + "." + m.getName();
                if (rule == null) {
                    problems.add(name + " has no @PreAuthorize");
                    continue;
                }
                if (prefix.startsWith("/internal") && !rule.value().contains("hasRole('INTERNAL')")) {
                    problems.add(name + " must require hasRole('INTERNAL')");
                }
                if (rule.value().contains("permitAll") && !prefix.startsWith("/callbacks")) {
                    problems.add(name + " is open but is not a provider callback");
                }
            }
        }
        assertThat(problems).isEmpty();
    }
}
