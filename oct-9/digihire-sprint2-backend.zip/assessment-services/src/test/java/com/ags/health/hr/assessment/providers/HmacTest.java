package com.ags.health.hr.assessment.providers;

import org.junit.jupiter.api.Test;

import java.nio.charset.StandardCharsets;
import java.util.Base64;

import static org.assertj.core.api.Assertions.assertThat;

class HmacTest {

    @Test
    void acceptsHexPrefixedAndBase64SignaturesAndRejectsTampering() {
        String key = "callback-key-123";
        String body = "{\"reference\":\"x\",\"status\":\"COMPLETED\"}";
        String hex = Hmac.sha256Hex(key, body);
        String b64 = Base64.getEncoder().encodeToString(Hmac.sha256(key.getBytes(StandardCharsets.UTF_8),
                body.getBytes(StandardCharsets.UTF_8)));
        assertThat(Hmac.verify(key, body, hex)).isTrue();
        assertThat(Hmac.verify(key, body, "sha256=" + hex)).isTrue();
        assertThat(Hmac.verify(key, body, b64)).isTrue();
        assertThat(Hmac.verify(key, body + " ", hex)).isFalse();
        assertThat(Hmac.verify(key, body, null)).isFalse();
        assertThat(Hmac.verify(null, body, hex)).isFalse();
        assertThat(Hmac.verify(key, body, "not-a-signature!")).isFalse();
    }
}
