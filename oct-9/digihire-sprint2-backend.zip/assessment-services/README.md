# assessment-services

Phase 5 Sprint 2 (P5-S2): assessment integration framework and candidate rules.

| Tracker | What is here |
|---|---|
| #10 Common assessment integration framework | `providers/AssessmentProvider` SPI, `ProviderRegistry`, attempts, grading, results, audit, events |
| #11 Versant invocation in workflow | `VersantProvider` (TIN assign, bulk status, GSE grading via the definition's bands) |
| #12 Typing & other assessments | `RestAssessmentProvider` (configuration only: SHL, TYPING, any REST vendor) and `ManualProvider` (offline tests, result entry) |
| #13 Auto-trigger links by LOB / role | `asm_assessment_mapping` + `POST /internal/events/application` |
| #14 Results, timestamps, score validity | `asm_assessment_attempt` (invited / started / completed / result received, score, grade, valid until) |
| #15 60-day score validity | `assessment.score-validity-days` (admin config), reuse check, daily `ASSESSMENT_SCORE_EXPIRED` event |
| #16 / #17 Technical reschedule + approver | `POST /assessments/{id}/reschedule-requests`, approval flow `ASSESSMENT_RESCHEDULE` from admin-services |
| #18 SHL cooling (7 / 30 / 180) | `CoolingPolicy`, config `assessment.cooling-days.shl` (Versant 15 / 45 / 180 the same way) |
| #19 Voice Fresher Chennai | `VoiceFresherService`, config `voice-fresher.*` |
| #20 Assessment audit logging | every step in `adm_audit_log` with `candidate_id` |
| #21-23 Blacklist | reason capture, hashed identifiers, eligibility gate, removal through the `BLACKLIST_REMOVAL` approval flow |

## Run

```bash
cd assessment-services
./mvnw -DskipCommonUtils test
java -jar target/assessment-services-1.0.0.jar
```

Port 8990, context path `/assessment-services`, Eureka id `assessment-services`. Swagger UI: `/assessment-services/swagger-ui.html`.

admin-services must run first: it holds the permissions, the enterprise rules, the secrets and the approver hierarchy.

## Environment

| Variable | Required | Notes |
|---|---|---|
| DB_URL / DB_DRIVER / DB_USERNAME / DB_PASSWORD / DB_DIALECT | yes | same smartiedb as the other services. Tables `asm_*`; audit goes to the shared `adm_audit_log` |
| JWT_SECRET | yes | same Base64 secret as auth-services and admin-services |
| INTERNAL_API_KEY | yes | key other services send on `/internal/**` |
| ADMIN_SERVICES_URL | yes | e.g. `http://localhost:8989/admin-services` (direct, not through the gateway) |
| ADMIN_INTERNAL_KEY | no | key for admin-services `/internal/**`. Defaults to `INTERNAL_API_KEY`. Use the `assessment-services` entry of admin `INTERNAL_SERVICE_KEYS` when `SECRETS_REQUIRE_SERVICE_KEY=true` |
| VERSANT_ENABLED / VERSANT_URL | for Versant | credentials come from admin secrets `versant.api.username` / `versant.api.password` (allowed service `assessment-services`) |
| SHL_ENABLED / SHL_INVITE_URL / SHL_RESULT_URL | for SHL | token from secret `shl.api.token`, callback signing key `shl.callback.signing-key` |
| TYPING_ENABLED / TYPING_INVITE_URL / TYPING_RESULT_URL | for an online typing vendor | API key from secret `typing.api.key`. Leave off to run typing tests as MANUAL |
| ASSESSMENT_CALLBACK_BASE_URL | no | public URL vendors call back, e.g. `https://jobs.agshealth.com/api/assessment-services` |
| BLACKLIST_PEPPER | no | fallback only. Store the 16+ character key as admin secret `assessment.blacklist.pepper`. Never change it once data exists |
| ASSESSMENT_JOBS_ENABLED | no | `true` on exactly one instance (polling, link expiry, score validity, event push) |
| ASSESSMENT_EVENTS_WEBHOOK_URL | no | if set, events are POSTed there in batches (with `X-Internal-Key`); otherwise consumers pull `/internal/events` |
| ASSESSMENT_REQUIRE_HTTPS | no | refuse plain HTTP, send HSTS |

Rules read from admin-services enterprise configuration (cached 5 minutes, `application.yml` values are only the fallback):
`assessment.score-validity-days`, `assessment.cooling-days.<cooling key>` (e.g. `shl`, `versant`, `typing`),
`assessment.invite.link-validity-days`, `assessment.reschedule.max-per-attempt`, `voice-fresher.chennai-reject-block-days`,
`voice-fresher.restricted-locations`, `voice-fresher.role-codes`, `blacklist.removal.requires-approval`.

## Gateway

```yaml
       - id: assessment-services
         uri: lb://assessment-services
         predicates:
           - Path=/assessment-services/**
         filters:
           - AuthFilter
```

Add `/assessment-services/callbacks/` to `RouteValidator.openApiEndpoints` (vendors have no JWT; the body is HMAC-signed and
verified here). Block `/assessment-services/internal/**` like the admin-services internal paths.

## Wiring candidate-services (and auth-services)

1. **Before mapping a candidate to a requisition / at registration** call `POST /internal/eligibility/check`
   `{candidateId, email, mobile, idProofNumber, roleCode, location, purpose: "APPLICATION"}`. `eligible=false` with
   `BLACKLISTED` or `VOICE_FRESHER_RESTRICTED` must stop the mapping. `COOLING_PERIOD` and `REAPPLY_AS_FRESHER` are information.
2. **On application events** call `POST /internal/events/application` with `eventType` `CREATED`, `WALKED_IN`, `STAGE_CHANGED`
   (with `stage`) or `REJECTED`. Mapped assessments are invited automatically; a `REJECTED` Voice Fresher candidate in a restricted
   location gets the 6-month block.
3. **Consume events** from `GET /internal/events?afterSeq=<last seq>` (or the webhook). Map them to the existing statuses:

| Event | candidate-services action |
|---|---|
| `ASSESSMENT_INVITED` | status `VERSANT_YET_TO_START` (or the assessment's own stage), send the link with the notification engine |
| `ASSESSMENT_STARTED` | `VERSANT_INPROGRESS` |
| `ASSESSMENT_COMPLETED` | `VERSANT_COMPLETED` and move on (`WAITING_FOR_HRROUND`) |
| `ASSESSMENT_FAILED` | `VERSANT_FAILED`, store `coolingUntil`; `reapplyAsFresher=true` sends the candidate to the fresher pipeline |
| `ASSESSMENT_NOT_TAKEN` / `ASSESSMENT_LINK_EXPIRED` | `VERSANT_NOT_TAKEN` |
| `ASSESSMENT_SCORE_EXPIRED` | move to the Fresher Pipeline (BRD 4.7) |
| `CANDIDATE_BLACKLISTED` / `CANDIDATE_UNBLACKLISTED` | flag on the candidate record |
| `APPROVAL_REQUESTED` / `APPROVAL_LEVEL_ADVANCED` | notify the approvers listed in the payload |

4. **Retire the old Versant cron** in candidate-services once `VERSANT_ENABLED=true` here, so a TIN is not graded twice.

## Adding a new assessment vendor

- REST vendor: add a block under `assessment.providers.rest.<CODE>` (invite URL and body template, JSON pointers for reference,
  link, status, score, completed-at, status values), store its credentials in admin secrets, create the definition with
  `providerCode=<CODE>`. No code change.
- Anything else: implement `AssessmentProvider` as a Spring bean. The registry picks it up.

## Endpoints

| Method | Path | Rule |
|---|---|---|
| GET | /config/assessments, /config/assessments/{code} | ASSESSMENT_CONFIG:VIEW or ASSESSMENT:VIEW |
| POST / PUT | /config/assessments, /config/assessments/{code} | ASSESSMENT_CONFIG:MANAGE |
| GET / POST / PUT | /config/mappings, /config/mappings/{id} | ASSESSMENT_CONFIG:VIEW / MANAGE |
| GET | /config/mappings/preview?event=&lob=&roleCode=&location=&stage= | ASSESSMENT_CONFIG:VIEW or ASSESSMENT:VIEW |
| GET | /config/providers | ASSESSMENT_CONFIG:VIEW |
| POST | /assessments/invite | ASSESSMENT:TRIGGER |
| GET | /assessments?candidateId=&applicationId=&assessmentCode=&status= , /assessments/{id} | ASSESSMENT:VIEW |
| POST | /assessments/{id}/results | ASSESSMENT:RESULT_ENTRY (MANUAL provider only) |
| POST | /assessments/{id}/refresh, /retry, /cancel | ASSESSMENT:TRIGGER |
| POST | /assessments/{id}/reschedule-requests | ASSESSMENT:RESCHEDULE_REQUEST |
| GET | /candidates/{candidateId}/assessment-summary | ASSESSMENT:VIEW |
| POST | /eligibility/check | ASSESSMENT:VIEW or BLACKLIST:VIEW |
| GET | /approvals?subjectType=&status=&candidateId=&mine=true , /approvals/{id} | any reschedule / blacklist-removal permission |
| POST | /approvals/{id}/approve, /approvals/{id}/reject | ASSESSMENT:RESCHEDULE_APPROVE or BLACKLIST:REMOVE_APPROVE, plus approver of the current level in admin-services |
| POST | /approvals/{id}/cancel | requester |
| GET | /blacklist?status=&reasonCode=&candidateId= , /blacklist/{id} | BLACKLIST:VIEW |
| POST | /blacklist | BLACKLIST:CREATE |
| POST | /blacklist/check | BLACKLIST:VIEW |
| POST | /blacklist/{id}/removal-requests | BLACKLIST:REMOVE_REQUEST |
| GET / POST / PUT | /blacklist-reasons | logged in / BLACKLIST_REASON:MANAGE |
| POST | /internal/events/application, /internal/eligibility/check, /internal/blacklist/check | X-Internal-Key |
| GET | /internal/candidates/{id}/valid-scores, /internal/candidates/{id}/assessment-summary, /internal/events | X-Internal-Key |
| POST | /callbacks/{providerCode} | vendor HMAC signature |

Errors are RFC 7807 with `code`. `NOT_ELIGIBLE` also carries `reasons[]` (`BLACKLISTED`, `VOICE_FRESHER_RESTRICTED`,
`COOLING_PERIOD`, `VALID_SCORE_EXISTS`, `ATTEMPT_IN_PROGRESS`, `REAPPLY_AS_FRESHER`) each with `until` and `blocking`.
