# DigiHire Phase 5 - Sprint 2 (P5-S2) backend

Two deployables:

- `admin-services/` - the fixed Sprint 1 service plus the Sprint 2 admin items (secrets, approval hierarchy, config history,
  role copy, role-based test matrix). `sprint2-admin-services.diff` shows only the Sprint 2 changes.
- `assessment-services/` - new service for the assessment and blacklist items. It takes permissions, rules, secrets and
  approvers from admin-services, so nothing is hardcoded twice.

## Tracker coverage

| # | Task | Where |
|---|---|---|
| 1 | Secure credential / secret store | admin `secrets/*`, `SecretService`, `adm_secret` (AES-256-GCM envelope; AWS Secrets Manager backend switchable) |
| 2 | Secret access control & UI masking | `SECRET:VIEW` returns `valueHint` only; `SECRET:REVEAL` + reason; `/internal/secrets` only for listed services |
| 3 | Secret access logging | `adm_secret_access_log` (own transaction, so denials are kept) + `adm_audit_log` |
| 4 | Encryption at rest and in transit | envelope encryption, master-key rotation, `ADMIN_REQUIRE_HTTPS`, `ADMIN_REQUIRE_DB_TLS`, `SERVER_SSL_*`, hashed blacklist identifiers |
| 5 | Role creation & permission assignment | already in S1; adds `copyFrom` on role create |
| 6 | Organisational approval hierarchy | `adm_approver_assignment` (flow, level, LOB, location, delegate, validity) |
| 7 | Multi-level approver configuration | `adm_approval_flow` / `adm_approval_level` (ROLE, USER, REPORTING_MANAGER, HIERARCHY, fallback role, min approvals, SLA) |
| 8 | Enterprise-level configuration screen | S1 API + `GET /admin/config/{key}/history`; Sprint 2 rule keys seeded |
| 9 | Admin module role-based test matrix | `admin-role-matrix.csv` + `AdminRoleMatrixTest` |
| 10-20 | Assessment integration | `assessment-services` (see its README for the per-task table) |
| 21-23 | Blacklist | `assessment-services` blacklist, eligibility gate, `BLACKLIST_REMOVAL` approval |

Frontend was left out on request. Every screen has its API.

## New permissions (seed changeset rbac-seed-v3)

`SECRET:VIEW / MANAGE* / REVEAL*`, `APPROVAL_FLOW:VIEW / MANAGE`, `ASSESSMENT_CONFIG:VIEW / MANAGE`,
`ASSESSMENT:VIEW / TRIGGER / RESULT_ENTRY / RESCHEDULE_REQUEST / RESCHEDULE_APPROVE`,
`BLACKLIST:VIEW / CREATE / REMOVE_REQUEST / REMOVE_APPROVE`, `BLACKLIST_REASON:MANAGE` (* privileged, Super Admin only).

Defaults: Super Admin gets secrets, approval-flow and assessment configuration. Recruiter: assessments and blacklist view.
Recruitment Manager: plus reschedule approval, blacklisting and removal requests. TA Head: plus blacklist removal approval and
approval-flow view. Interviewer: `ASSESSMENT:VIEW` conditional. Change them on the matrix screen.

## Assumptions to confirm

- Cooling tiers: 1st fail -> tier 1, 2nd fail -> tier 2, 3rd fail -> 180 days and the candidate re-applies as a fresher; the
  count restarts after that. NOT_TAKEN, expired links and approved technical reschedules do not count.
- An approved technical reschedule clears the cooling period and any Voice Fresher block raised by that failed attempt.
- Reschedules allowed per attempt: 2 (`assessment.reschedule.max-per-attempt`).
- Voice Fresher block applies to the roles in `voice-fresher.role-codes` (empty until DEP-S2-11) after a rejection in a location of
  `voice-fresher.restricted-locations` (`CHENNAI`), for `voice-fresher.chennai-reject-block-days` (180).
- Blacklisting is Recruitment Manager / TA Head; removal needs reporting manager then TA Head. Reason list is a placeholder until DEP-S2-01.
- Versant payloads mirror the knowledge base (`/authentication/login`, `/tins/assign`, `/tins/assigned/status?scale=GSE`,
  "Overall GSE Score", pass 43, B1/B2/C1/C2). Compare with `VersantService` before switching it on. SHL and typing vendors are
  configuration-driven REST providers; fill the URLs and JSON pointers from DEP-S2-02 / DEP-S2-08.

## Open dependencies this code waits on

DEP-S2-01 reason list, DEP-S2-02 vendor credentials (store them with `POST /admin/secrets`), DEP-S2-03 vault decision
(`SECRETS_DEFAULT_BACKEND`), DEP-S2-04 KMS (`KeyEncryptionKeyProvider` bean), DEP-S2-05 approvers by LOB
(`POST /admin/approvals/approvers`), DEP-S2-09 LOB / role -> assessment mapping (`POST /assessment-services/config/mappings`),
DEP-S2-10 cooling sign-off (config values), DEP-S2-11 Voice Fresher role list (config value).

## Build status

Maven Central was not reachable from the build environment, so neither service was built or tested with Maven here. Both were
type-checked against API stubs (main and test sources), and the crypto, cooling, grading, HMAC and masking logic was executed with
the JDK. Run `./mvnw -DskipCommonUtils test` in each service before merging.
