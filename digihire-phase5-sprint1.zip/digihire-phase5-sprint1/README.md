# DigiHire Phase 5 – Sprint 1 (P5-S1) backend

Sprint 1 (21 Sep – 02 Oct 2026, Milestone 1) of the Phase 5 BRD, built as Spring Boot microservices that sit next to the existing `smartie-core` services. The 32 tracker items fall into four modules: **RBAC defaults and filters**, **Logging and timestamps**, **Email notifications** and the **Admin module**. They also include the **config-driven workflow engine** (replacing jBPM) with an **HR step builder**.

> **Status: code-complete, not yet compiled.** Maven Central was not reachable from the environment this was written in. Two checks were done instead:
> - All sources were parsed and cross-referenced with `javac` (no project-internal errors).
> - The workflow engine (step compiler, validator, engine) was compiled and run against the seed workflows and every step-library template, and all checks pass.
>
> **Run `mvn clean verify` first** (section 5) before deploying to STG.

---

## Contents
1. [What was built](#1-what-was-built)
2. [Architecture](#2-architecture)
3. [Technology choices and versions](#3-technology-choices-and-versions)
4. [Repository layout](#4-repository-layout)
5. [Build and run locally](#5-build-and-run-locally)
6. [Configuration reference](#6-configuration-reference)
7. [Plugging into the existing smartie-core](#7-plugging-into-the-existing-smartie-core)
8. [Workflow engine and HR step builder](#8-workflow-engine-and-hr-step-builder)
9. [RBAC framework](#9-rbac-framework)
10. [Central logging and audit](#10-central-logging-and-audit)
11. [Email notification engine](#11-email-notification-engine)
12. [API catalogue (mapped to the UX screens)](#12-api-catalogue-mapped-to-the-ux-screens)
13. [Sprint 1 traceability](#13-sprint-1-traceability)
14. [Testing](#14-testing)
15. [Open dependencies, limitations and next steps](#15-open-dependencies-limitations-and-next-steps)

---

## 1. What was built

| Deployable | Port | Context path | Responsibility |
|---|---|---|---|
| `digihire-platform-starter` | – | – | A shared Spring Boot auto-configuration jar. It provides JWT **signature verification**, RBAC authorities, `CurrentUser`, the `@Audited` annotation, the central audit writer, correlation IDs, request timing logs, RFC 7807 errors, `DataScopeSpecifications` and `AccessEvaluator`. It can be dropped into the **existing** services. |
| `admin-services` | 8989 | `/admin-services` | Admin users, roles, the permission matrix, default permission sets, user-level grants, LOB/location/team scope, override and shared access with approval, role-driven search filters, master data, admin-only enterprise config, and the **central log viewer**. |
| `workflow-services` | 8986 | `/workflow-services` | Revives the dormant skeleton as the **config-driven workflow engine**. It covers the step builder, the step library, states, transitions, rules, versioning, change log, validation, assignment to **job / role / LOB / location / hiring type**, runtime transitions, approvals and transition logs. |
| `notification-engine` | 8990 | `/notification-engine` | Versioned FreeMarker email templates (Walk-In, On Hold, Rejection, Interview), the **automated trigger engine**, the personalization token catalogue, SMTP delivery (works with AWS SES SMTP) with retry, and a per-candidate dispatch log. |

The existing `notification-services` (OTP, SES, SMS) is **unchanged**. `notification-engine` adds the Phase 5 template and trigger capability beside it.

### KISS decisions
* **No message broker.** Services talk over plain HTTP through Eureka, as they do today. The workflow engine hands events to the notification engine *after commit*. The notification engine is idempotent on `eventId` and retries failed sends itself (`FOR UPDATE SKIP LOCKED`, so it is safe with several instances).
* **One database, separate schemas.** `dh_admin`, `dh_workflow`, `dh_notify` and `dh_audit` live inside the existing `smartiedb`. Each service owns its schema through **Flyway**, with its own history table. `ddl-auto` is `none` for the Phase 5 schemas, which removes the drift risk noted in KB §28.4.
* **Audit is a direct async JDBC insert** into `dh_audit.audit_log` from every service. No extra log pipeline is needed. Technical logs are JSON (ECS) on stdout, ready for Filebeat → Elasticsearch.
* **Very little engine code.** The workflow "engine" is about 5 small pure-Java classes: model, step compiler, validator, rule evaluator and the decide/options engine. Everything else is JSON configuration edited through APIs: steps, states, transitions, rules, assignments, templates, triggers, roles, filters and thresholds.

---

## 2. Architecture

```mermaid
graph TD
    UI["Angular UI (HR / Admin / Employee / Candidate portals)"] -->|":8980"| GW["gateway-services (existing)<br/>AuthFilter, CSP, routing"]
    GW -->|"/admin-services/**"| ADM["admin-services :8989<br/>RBAC, admin users, config, log viewer"]
    GW -->|"/workflow-services/**"| WF["workflow-services :8986<br/>step builder + engine"]
    GW -->|"/notification-engine/**"| NE["notification-engine :8990<br/>templates, triggers, SMTP"]
    GW --> EX["existing: auth / candidate / job / vendor / notification services"]

    WF -- "GET /internal/rbac/effective (cached)" --> ADM
    NE -- "GET /internal/rbac/effective (cached)" --> ADM
    EX -. "optional: starter jar" .-> ADM
    WF -- "GET /internal/config (rules #config)" --> ADM
    WF -- "POST /internal/events (after commit)" --> NE
    EX -. "POST /internal/runtime/.../move" .-> WF
    NE -- "SMTP / SES SMTP" --> MAIL[("Mail relay")]

    subgraph "PostgreSQL smartiedb"
      S1[("dh_admin")]
      S2[("dh_workflow")]
      S3[("dh_notify")]
      S4[("dh_audit.audit_log")]
    end
    ADM --> S1
    WF --> S2
    NE --> S3
    ADM & WF & NE & EX -. "async audit insert" .-> S4
```

**Request security path:** the gateway validates the JWT as today. Each Phase 5 service then **verifies the HS256 signature again**, which fixes KB §25 item 2. It turns the claims (`userId`, `email`, `userType`, `userName`) into a `CurrentUser` and loads the user's effective access (roles, permissions, data scope) from admin-services. That access is cached for 2 minutes. Service-to-service calls use `/internal/**` with the `X-Internal-Key` header. The gateway must **not** route `/internal/**`.

---

## 3. Technology choices and versions

| Concern | Choice | Why |
|---|---|---|
| Runtime | **Java 21** (LTS). The starter targets release 17. | Chosen baseline. The starter stays loadable by the existing Java 17–20 services. |
| Framework | **Spring Boot 3.5.16**, **Spring Cloud 2025.0.3** (Northfields) | Latest 3.x line, and the same programming model as the existing 3.1 code. Upgrading the existing services is a minor-version bump. OSS support for 3.5 ended in June 2026; plan the 4.x move (section 15). |
| Workflow | **Config-driven engine** (JSON documents + sandboxed **SpEL**) | jBPM did not work out. This needs no BPMN tooling. HR edits steps through APIs, and versioning, validation and the audit trail are built in. |
| Rules | Spring Expression Language with `SimpleEvaluationContext` | Already on the classpath. It is sandboxed: no `T(...)`, constructors or bean references. |
| Persistence | Spring Data JPA (Hibernate 6.6) + **Flyway 11** (`flyway-database-postgresql`) | Versioned, repeatable schemas per service. |
| Security | Spring Security 6.5 **OAuth2 Resource Server** (Nimbus HS256) + method security | Standard, declarative `@PreAuthorize`, replacing the imperative `BearerTokenUtil` checks. |
| Templates | **FreeMarker** (the existing engine) in HTML auto-escape mode, `?new` disabled | Existing team knowledge. Safe against injected candidate data. |
| Mail | `spring-boot-starter-mail` over SMTP | Tracker #21 asks for SMTP. AWS SES is reached through its SMTP endpoint. |
| API docs | springdoc-openapi **2.8.17** | Swagger UI at `/<context>/swagger-ui.html`. |
| Cache | Caffeine | Per-instance access cache. No Redis needed. |
| Logs | Spring Boot structured logging (`logging.structured.format.console=ecs`) | JSON logs with no extra dependency. |

---

## 4. Repository layout

```text
digihire-phase5-sprint1/
├── pom.xml                         # parent/aggregator (Boot 3.5.16 parent, Cloud BOM, springdoc)
├── docker-compose.yml              # local Postgres + Mailpit (fake SMTP)
├── .env.example                    # every environment variable
├── digihire-platform-starter/      # shared auto-configuration (security, audit, errors, scope helpers)
│   └── src/main/java/com/ags/health/hr/platform/{config,security,audit,web,jpa}
├── admin-services/
│   ├── src/main/resources/db/migration/V1__admin_rbac_audit_schema.sql, V2__seed_rbac_defaults.sql
│   └── src/main/java/com/ags/health/hr/admin/{domain,repo,service,web}
├── workflow-services/
│   ├── src/main/resources/workflows/   # seed workflows (step-based) + default assignments
│   ├── src/main/resources/step-library/# 10 reusable hiring-step templates
│   ├── src/main/resources/db/migration/V1__workflow_schema.sql, V2__step_library.sql
│   └── src/main/java/com/ags/health/hr/workflow/{engine,domain,repo,service,web}
└── notification-engine/
    ├── src/main/resources/db/migration/V1__notification_schema.sql, V2__seed_standard_templates.sql
    └── src/main/java/com/ags/health/hr/notify/{domain,repo,service,web}
```

Package naming follows the existing convention: `com.ags.health.hr.<module>`.

---

## 5. Build and run locally

Prerequisites: JDK 21, Maven 3.9+, Docker (for Postgres and Mailpit), and the existing `discovery-services` (Eureka :8761) and `gateway-services` (:8980) from smartie-core.

```bash
# 1. infrastructure
docker compose up -d                       # postgres:5432, mailpit smtp:1025 / ui:8025

# 2. build everything (starter first - the reactor handles the order)
mvn clean verify                           # compiles + runs unit tests
mvn clean install -DskipTests              # installs the starter into ~/.m2 for the existing services

# 3. environment (see section 6); for a quick local run:
export DB_URL=jdbc:postgresql://localhost:5432/smartiedb DB_USERNAME=postgres DB_PASSWORD=postgres
export JWT_SECRET='<same value as gateway JwtUtil.SECRET>' INTERNAL_API_KEY=$(openssl rand -hex 32)
export BOOTSTRAP_ADMIN_EMAILS=you@agshealth.com LOG_FORMAT=
export NOTIFICATION_DELIVERY=SMTP SMTP_HOST=localhost SMTP_PORT=1025 SMTP_AUTH=false SMTP_STARTTLS=false

# 4. start in this order (admin first: it owns dh_audit and the RBAC data the others read)
java -jar admin-services/target/admin-services-5.1.0-SNAPSHOT.jar &
sleep 20
java -jar workflow-services/target/workflow-services-5.1.0-SNAPSHOT.jar &
java -jar notification-engine/target/notification-engine-5.1.0-SNAPSHOT.jar &
```

Swagger UI:
- http://localhost:8989/admin-services/swagger-ui.html
- http://localhost:8986/workflow-services/swagger-ui.html
- http://localhost:8990/notification-engine/swagger-ui.html

Use the **Authorize** button with a JWT issued by auth-services (log in through the UI and copy the `token` cookie).

To add the services to the existing scripts (`start_all.sh`, `build_dev_be.sh`, `prod_deploy.sh`), append the three module names after `auth-services`. `workflow-services` replaces the old skeleton on port 8986.

---

## 6. Configuration reference

Every value can be overridden by an environment variable (see `.env.example`). Secrets come only from the environment.

| Variable | Used by | Default | Notes |
|---|---|---|---|
| `DB_URL`, `DB_USERNAME`, `DB_PASSWORD` | all | local | Same `smartiedb`. Give **no query string** in `DB_URL`. |
| `EUREKA_URL`, `EUREKA_HOSTNAME` | all | localhost | As in the existing services. |
| `JWT_SECRET` | all | – (required) | **Same secret** as `gateway JwtUtil` / `auth JwtService`. |
| `JWT_SECRET_ENCODING` | all | `BASE64` | The existing code does `Decoders.BASE64.decode(SECRET)`. Use `HEX` or `RAW` if that changes. |
| `INTERNAL_API_KEY` | all | – (required) | Shared key for `/internal/**`. Rotate it like any secret. |
| `ADMIN_SERVICES_URL` | workflow, notification, starter users | `http://admin-services/admin-services` | Eureka service ID or host:port. |
| `LOG_FORMAT` | all | `ecs` | Empty gives plain text. `logstash` is also supported. |
| `BOOTSTRAP_ADMIN_EMAILS` | admin | – | Comma-separated list. These users always exist as ADMIN. |
| `AUDIT_RETENTION_DAYS` | admin | 730 | Nightly purge in batches (DEP-S1-05). |
| `NOTIFICATION_ENGINE_URL`, `WORKFLOW_NOTIFY_ENABLED` | workflow | Eureka / true | Automated email hand-off. |
| `NOTIFICATION_DELIVERY` | notification | `LOG` | `SMTP` sends for real. `LOG` renders and records only. |
| `SMTP_*`, `MAIL_FROM`, `MAIL_FROM_NAME` | notification | – | For AWS SES use `email-smtp.ap-south-1.amazonaws.com:587` with SES SMTP credentials. |
| `MAIL_OVERRIDE_RECIPIENT` | notification | empty | **UAT safety net**: every email goes to this inbox, with the original recipient in the subject. |

Business thresholds are **not** in YAML. They are enterprise config in admin-services (`/admin/config`), which admins edit at runtime: Versant pass score, score validity (60 days), SHL and Versant cooling periods, ORC re-apply block, Voice Fresher Chennai block, and vendor archive days. Workflow rules read them as `#config['key']`.

---

## 7. Plugging into the existing smartie-core

### 7.1 Place the modules
Copy the four module folders into the `smartie-core` root, next to `auth-services`. Either copy the parent `pom.xml` as `phase5-pom.xml` and build with `mvn -f phase5-pom.xml install`, or keep this folder as a sibling repository. **Replace** the dormant `workflow-services` skeleton with the new module (same name, same port 8986).

### 7.2 Gateway routes (`gateway-services/src/main/resources/application.yml`)
```yaml
spring:
  cloud:
    gateway:
      routes:
        - id: admin-services
          uri: lb://admin-services
          predicates: [ "Path=/admin-services/**" ]
        - id: workflow-services            # replaces the old skeleton route if present
          uri: lb://workflow-services
          predicates: [ "Path=/workflow-services/**" ]
        - id: notification-engine
          uri: lb://notification-engine
          predicates: [ "Path=/notification-engine/**" ]
        # IMPORTANT: never expose service-to-service endpoints
        - id: block-internal
          uri: no://op
          predicates: [ "Path=/*/internal/**" ]
          filters: [ "SetStatus=404" ]
          order: -1
```
`no://op` with `SetStatus` is the Spring Cloud Gateway idiom for a non-forwarding route. If your gateway version rejects it, reject `/*/internal/**` with 404 in the existing `PathTraversalValidationFilter` instead. Either way, `/internal/**` also requires `X-Internal-Key` inside each service.

Nothing needs to be added to `RouteValidator.openApiEndpoints`: every Phase 5 endpoint needs a JWT. In the CSP `connect-src`, the new paths are same-origin, so no change is needed.

### 7.3 JWT secret – do this first
`JwtUtil.SECRET` and `JwtService` hard-code the HS256 key (KB §25 item 1). Move it to the `JWT_SECRET` environment variable in gateway and auth-services, and give the **same value** to the Phase 5 services. They verify every token's signature and reject tokens without a valid one.

### 7.4 Use the starter in the existing services (optional, recommended)
The starter is compiled for Java 17 and uses only Spring 6.0 / Boot 3.1 APIs, so the current 3.1 services can use it as they are.

```xml
<dependency>
  <groupId>com.ags.health.hr</groupId>
  <artifactId>digihire-platform-starter</artifactId>
  <version>5.1.0-SNAPSHOT</version>
</dependency>
```

What turns on automatically, and how to control it:

| Feature | Active when | Property |
|---|---|---|
| Correlation ID (`X-Correlation-Id`) + one timed log line per request | always (servlet app) | `digihire.web.request-logging` |
| `AuditLogger` bean + `@Audited` | a `JdbcTemplate` bean exists | `digihire.audit.enabled`, `digihire.audit.table` |
| JPA timestamp columns (`AuditableEntity`, `SecurityAuditorAware`) | Spring Data JPA present and no `@EnableJpaAuditing` of your own | – |
| RFC 7807 fallback handler (lowest precedence, so your `@ControllerAdvice` still wins) | always | `digihire.web.problem-details-advice` |
| JWT signature verification + RBAC authorities + `@PreAuthorize` | **only** if you add `spring-boot-starter-oauth2-resource-server` | `digihire.security.enabled` |

For an existing service, start with **audit and correlation only**. Leave Spring Security off the classpath until each controller has `@PreAuthorize` annotations. Adding it secures every endpoint at once.

**Activity logs in 1 line** (tracker #13):
```java
@Audited(action = "CANDIDATE_MAPPED", entityType = "APPLICATION", entityId = "#result.id",
         candidateId = "#request.candidate")
public Application createApplication(Application request) { ... }
```
**Approval / custom logs:**
```java
auditLogger.log(AuditEvent.builder(AuditCategory.APPROVAL, "CTC_APPROVED")
        .entity("APPLICATION", app.getId()).candidate(app.getCandidate())
        .detail("ctc", ctc).detail("remarks", remarks).build());
```
**Recruiter / TL / LOB visibility** (tracker #5–#7) in `ApplicationsService` list and search queries:
```java
CurrentUser user = CurrentUserProvider.require();          // needs the security part, or build the scope via AccessClient
var mapping = new DataScopeSpecifications.Mapping("hr", "lob", "location", "id");
Page<Application> page = applicationRepository.findAll(
        DataScopeSpecifications.visibleTo(user.scope(), "APPLICATION", mapping).and(existingFilters), pageable);
```
Single record check (for example `GET /candidates/{id}`):
```java
var d = AccessEvaluator.check(user, "CANDIDATE:VIEW",
        new AccessEvaluator.Target("CANDIDATE", candidateId, application.getHr().toString(), job.getLob(), job.getLocation()));
if (!d.allowed()) throw new APIException("FORBIDDEN: " + d.reason(), 403);
```
For the Elasticsearch search path (`ESApplicationsService`), add the same scope as a `bool` filter:
- `terms hr ∈ {userId + teamUserIds}`
- OR `terms lob ∈ lobs`
- OR `terms location ∈ locations`
- OR `ids ∈ sharedIds("APPLICATION")`

When `scope.level() == ALL`, skip the filter.

Without Spring Security in a service, resolve the scope yourself:
```java
EffectiveAccess access = accessClient.resolve(token.getUserId(), token.getEmail(), token.getUserType()); // cached
```
(Declare an `HttpAccessClient` bean, or add the resource-server dependency to get it auto-configured.)

### 7.5 Put candidate-services on the workflow engine
The engine is **authoritative for transitions**. candidate-services keeps its `application.application_status` column as a read model.

1. **When an application is created or mapped**, start the workflow. The engine picks the workflow from the HR assignments:
```http
POST /workflow-services/internal/runtime/instances         (X-Internal-Key: …)
{ "entityType": "APPLICATION", "entityId": "<application.id>", "candidateId": "<candidate.id>",
  "criteria": { "jobId": "<jobposting.id>", "jobRole": "AR Caller", "lob": "AR_CALLING",
                "location": "CHENNAI", "hiringType": "FRESHER" },
  "context":  { "ownerId": "<application.hr>", "lob": "AR_CALLING", "location": "CHENNAI",
                "candidateName": "...", "candidateEmail": "...", "jobTitle": "...", "recruiterName": "..." } }
```
2. **Wherever `setApplicationStatus(X)` happens today** (ApplicationsService, InterviewService, VersantStatusUpdateCron, PanelEventService), ask the engine first:
```http
POST /workflow-services/internal/runtime/instances/APPLICATION/{applicationId}/move
{ "toState": "VERSANT_COMPLETED", "payload": { "score": 61 }, "remarks": "Versant cron",
  "context": { "coolingPeriodEndDate": null } }
```
   * `200 COMPLETED`: persist the new status as today.
   * `200 PENDING_APPROVAL`: keep the old status. The approver finishes it later.
   * `409 INVALID_TRANSITION` or `422 TRANSITION_NOT_ALLOWED`: reject the change. This is the invalid state validation.

   The seeded fresher workflow uses **exactly the 28 `ApplicationStatus` codes**, so no mapping table is needed.
3. **UI buttons** call the user-facing API directly with the user's JWT:
   * `GET /workflow-services/runtime/instances/APPLICATION/{id}` returns the current state, tab and allowed actions, with the reasons for any disabled ones.
   * `POST …/transitions/{code}` performs an action.

   Role, permission, record-scope, field and rule checks all happen in the engine.
4. Automated candidate emails (Walk-In, On Hold, Rejection, Interview) are sent by the trigger engine on the transition. **Remove the hard-coded `sendEmail` calls** for those events to avoid duplicates. Keep CREATED, SHORTLISTED and OFFERED until triggers exist for them.

Keys the engine and templates read from `context` / `payload`: `ownerId`, `lob`, `location` (scope), `coolingPeriodEndDate`, `lastAssessmentDate`, `salaryApproved`, `score`, `sameCandidate`, `reasonCode`, `feedback`, `remarks`, and the template tokens in §11.

### 7.6 Database
* Flyway creates the schemas `dh_admin`, `dh_workflow`, `dh_notify` and `dh_audit`. The DB user needs `CREATE` on the database the first time. After that, DML is enough.
* Existing services that use the starter's audit writer need `INSERT` on `dh_audit.audit_log`. They already share the same DB user.
* Migrations never touch existing tables. Seeds use `ON CONFLICT DO NOTHING`, so admin changes survive redeployments.

### 7.7 Startup order
Eureka → gateway → auth → **admin-services** → workflow-services and notification-engine (parallel) → the rest. Admin-services must migrate `dh_audit` before other services can write audit rows. Until then, a failed audit write goes to the application log as `AUDIT_WRITE_FAILED`.

---

## 8. Workflow engine and HR step builder

### 8.1 Concepts
| Concept | Meaning | Who edits |
|---|---|---|
| **Step library** | Reusable hiring-step templates: Walk-in, Interview round, Online assessment (SHL / Moodle / Typing), Versant, Approval, Document / Pre-BGV check, LOI, Offer, Joining, Single task. New kinds are JSON (`PUT /step-library/{code}`), not code. | Admin / TA Head |
| **Workflow** | Ordered **steps** + common states (Created, On Hold, Pipeline, Rejected …) + global actions (Hold, Reject, Pipeline) | HR (TL / Manager / TA Head) |
| **Step** | Label, tab, *optional* (skippable), **stages** (states inside the step; `exit=true` means the step is done), an **entry action** and **actions** (required fields, allowed roles, permissions, rules, guard, approval, system-only) and **parameters** (for example `passScore`) | HR |
| **Rule** | Named SpEL condition, e.g. cooling period over, score ≥ pass score, photo confirmed | HR / Admin |
| **Version** | Publishing freezes the draft into version N+1. New records use the active version; running records stay on the version they started with. Rollback activates an old version. | TA Head / Manager / Admin (`WORKFLOW:PUBLISH`) |
| **Assignment** | Which workflow applies to a **job, job role, LOB, location, hiring type or any combination**. The most specific match wins. | HR (`WORKFLOW:ASSIGN`, within own LOBs) |

The step list compiles into a plain state machine, and that state machine is what the engine executes:

```text
Blueprint (HR)                                     Compiled (engine)
CREATED ─► [WALK_IN] ─► [ASSESSMENT] ─► [VERSANT?] ─► [HR_ROUND] ─► [PANEL] ─► [FINAL_HR] ─► [OFFER] ─► [JOINING]
             stages       stages          optional      ...
Each step: entry action from previous step's exit stages (plus the step before it when a step is optional),
actions with tokens: NEXT | REJECT | STEP:<code> | <state>; from: * | STEP:<code> | EXITS:<code> | ALL_STEPS
```

### 8.2 Seeded workflows
| Code | Steps | Default assignment |
|---|---|---|
| `APPLICATION_HIRING` | Walk-in → In-facility assessment → Versant → HR round → Panel → Final HR → Offer → Joining. Uses the **28 existing status codes**. | Default for every application |
| `LATERAL_HIRING` | HR round → Panel → Final HR → Offer → Joining | `hiringType = LATERAL` |

### 8.3 HR walkthrough (API)
Examples go through the gateway: `https://<host>/workflow-services/...`

**1. Create a workflow for Voice hiring by copying the default one**
```http
POST /workflows
{ "code": "VOICE_FRESHER_CHENNAI", "name": "Voice fresher – Chennai", "entityType": "APPLICATION",
  "copyFrom": "APPLICATION_HIRING" }
```
**2. See the steps**
```http
GET /workflows/VOICE_FRESHER_CHENNAI/draft/steps
```
**3. Add an SHL test from the library after Versant, with its own pass score**
```http
POST /workflows/VOICE_FRESHER_CHENNAI/draft/steps
{ "templateCode": "ONLINE_ASSESSMENT", "stepCode": "SHL", "label": "SHL cognitive test",
  "position": 3, "parameters": { "provider": "SHL", "passScore": 70 } }
```
**4. Make Versant optional** (it becomes skippable, and SHL can be entered straight from the assessment step)
```http
PUT /workflows/VOICE_FRESHER_CHENNAI/draft/steps/VERSANT
{ ...step as returned by GET, "optional": true }
```
**5. Change an action.** For example, the HR round needs a 'communicationRating' field and only TL / Manager can select:
```http
PUT /workflows/VOICE_FRESHER_CHENNAI/draft/steps/HR_ROUND     (edit actions[].requiredFields / allowedRoles)
```
**6. Reorder or remove steps**
```http
PUT    /workflows/VOICE_FRESHER_CHENNAI/draft/steps-order   { "order": ["WALK_IN","ASSESSMENT","SHL","VERSANT","HR_ROUND","PANEL","FINAL_HR","OFFER","JOINING"] }
DELETE /workflows/VOICE_FRESHER_CHENNAI/draft/steps/FINAL_HR
```
Every call returns the **compiled draft plus issues**: unreachable states, dead ends, unknown steps or states, bad expressions and missing `{{params}}`. ERRORs block publishing; WARNINGs don't.

**7. Publish (versioned, logged)**
```http
POST /workflows/VOICE_FRESHER_CHENNAI/publish   { "changeSummary": "Added SHL, Versant optional" }
GET  /workflows/VOICE_FRESHER_CHENNAI/changes                         # change log with diffs
GET  /workflows/VOICE_FRESHER_CHENNAI/versions/1/compare/2
POST /workflows/VOICE_FRESHER_CHENNAI/versions/1/activate             # rollback
```
**8. Assign it to a combination**
```http
POST /workflow-assignments
{ "workflowCode": "VOICE_FRESHER_CHENNAI", "lob": "AR_CALLING", "location": "CHENNAI", "hiringType": "FRESHER" }
GET  /workflow-assignments/resolve?lob=AR_CALLING&location=CHENNAI&hiringType=FRESHER   # preview
```
Specificity weights: `jobId 16 > jobRole 8 > lob 4 > location 2 > hiringType 1`; ties go to the higher `priority`. The catch-all default is reserved to ALL-scope users (Admin / TA Head). TLs and Managers can only assign within their own LOBs.

### 8.4 Rules language
SpEL, sandboxed. Variables:
- `#entity`: the record context
- `#payload`: data sent with the action
- `#actor`: `id`, `roles`, `permissions`
- `#instance`: `state`, `workflowCode`
- `#config`: enterprise config

Functions: `#num(x)`, `#daysSince(date)`, `#isBlank(x)`, `#contains(list, x)`. Step guards can use `{{parameter}}` placeholders.
```text
#num(#payload['score']) >= #num(#config['assessment.versant.pass-score'] ?: 43)
#entity['coolingPeriodEndDate'] == null or #daysSince(#entity['coolingPeriodEndDate']) >= 0
#entity['lob'] != 'AR_CALLING' or #actor['roles'].contains('TL')
```
Try an expression with `POST /workflows/rules/test {expression, entity, payload, config}`.

### 8.5 Runtime
| Call | Purpose |
|---|---|
| `GET /runtime/instances/{type}/{id}` | State, stage label, **tab** (Applicant / HR Interview / Assessment / Panel / Final HR / Offer / Rejected), allowed actions with disabled reasons, pending approval |
| `POST /runtime/instances/{type}/{id}/transitions/{code}` | Do an action. Returns `COMPLETED` or `PENDING_APPROVAL`. |
| `POST /runtime/instances/{type}/{id}/move` | Target-state move for status-based callers |
| `POST /runtime/instances/{type}/{id}/validate` | Dry run |
| `GET /runtime/instances/{type}/{id}/history` | Workflow transition log (tracker #12) |
| `GET /workflow-approvals`, `POST /workflow-approvals/{id}/approve or reject` | Approver inbox, e.g. candidate re-initiation and technical reschedule (Figma §7) |

Status codes: `409` means the action isn't valid from the current state (invalid state validation), `403` means the role, permission or record scope doesn't allow it, and `422` means a required field or rule is missing.

---

## 9. RBAC framework

### 9.1 Model
* **Permissions**: 39 codes of the form `OBJECT:ACTION` (JOB, CANDIDATE, APPLICATION, WORKFLOW, USER, ROLE, CONFIG, MASTER_DATA, AUDIT_LOG, NOTIFICATION_TEMPLATE, ACCESS_OVERRIDE). They are catalogue data added by migration.
* **Roles** and their **scope level**:

  | Role | Scope level |
  |---|---|
  | ADMIN | ALL |
  | TA_HEAD | ALL |
  | MANAGER | LOB |
  | TL | LOB (team is always included) |
  | RECRUITER | OWN |
  | PANEL | OWN |
  | EMPLOYEE | OWN |
  | VENDOR | OWN |
  | CANDIDATE | OWN |

  The seeded **default permission sets** for Job, Candidate and Application (tracker #1–3) are kept separately, so `POST /admin/roles/{code}/reset-defaults` can restore them.
* **Effective access** = role permissions + user ALLOW − user DENY + approved temporary permissions (tracker #24). The scope is:
  - the widest level among the user's roles;
  - plus assigned LOBs and locations;
  - plus the reporting team (the `managerId` hierarchy, a recursive query);
  - plus records shared through approved access requests.
* **Users who were never configured** get the default roles of their legacy `userType`:

  | Legacy `userType` | Default role |
  |---|---|
  | EMPLOYEE_HR_ADMIN | ADMIN |
  | EMPLOYEE_HR | RECRUITER |
  | EMPLOYEE_NON_HR | EMPLOYEE |
  | VENDOR | VENDOR |
  | CANDIDATE | CANDIDATE |

  Nothing breaks on day 1.
* **Deactivated** users keep their login (auth-services) but lose every Phase 5 role and permission.
* **Guards**:
  - The last active ADMIN cannot be deactivated.
  - ADMIN keeps USER, ROLE and CONFIG management.
  - `INTERNAL` and `SYSTEM` are reserved role codes.
  - Enterprise config, roles and filters need **both** the ADMIN role and the permission (tracker #32).

### 9.2 Visibility rules (BRD 4.3)
| Level | Sees |
|---|---|
| OWN | Own records (`ownerId` = recruiter) + records shared by approval |
| TEAM / LOB / LOCATION | + records of all reports (TL / Manager) + all records in supervised LOBs or locations |
| ALL | Everything |

Override or shared access (tracker #6, #8):
- `POST /access-requests` with `objectId` (share one candidate) or `permissionCode` (temporary extra permission) for N days.
- The approver needs `ACCESS_OVERRIDE:APPROVE` and must be in the requester's reporting line, unless they have ALL scope.
- Every step is logged with category `APPROVAL`.

Grants reach the other services within the 2-minute cache TTL.

### 9.3 Role-driven dynamic filters (tracker #4)
`GET /admin-services/rbac/filters/{screen}` returns the filters a role may use, with their options already resolved. Screens covered: `CANDIDATE_LIST`, `APPLICANT_LIST`, `OPEN_POSITIONS`, `INTERVIEWS`, `MY_REFERRALS`, `AUDIT_LOG`, matching the left-hand filter panels in the screens.

For example, *Recruiter* filters appear only for TL and above, and LOB / location options are limited to the user's own scope. Filters are rows in `dh_admin.search_filter`, edited through `/admin/search-filters`. The list services keep computing the counts.

---

## 10. Central logging and audit

| Tracker item | How |
|---|---|
| #9 Central logging framework | `digihire-platform-starter`: `AuditLogger` (async JDBC, never blocks, drops with a WARN if the queue is full), `@Audited`, correlation IDs, JSON (ECS) stdout logs |
| #10 Timestamp logs | `created_at/by`, `updated_at/by` and `row_version` on every Phase 5 table (`AuditableEntity`), one `digihire.access` log line per request with `durationMs`, and `occurred_at` on every audit row |
| #11 Approval logs | category `APPROVAL`: access requests, workflow approvals |
| #12 Workflow transition logs | `dh_workflow.transition_log` (transactional) + category `WORKFLOW_TRANSITION` |
| #13 Activity logs | category `ACTIVITY` via `@Audited` or `AuditLogger`; `CONFIG_CHANGE`, `SECURITY` and `NOTIFICATION` are also produced |
| #14 Centralized log viewer | `GET /admin-services/admin/audit-logs` (filters: category, action, actor, entity, candidate, service, outcome, correlation ID, date range, free text), `GET /admin/audit-logs/candidates/{id}` (candidate timeline), `GET /admin/audit-logs/export` (CSV, injection-safe) |

Retention: `AUDIT_RETENTION_DAYS` (nightly batch purge at 02:30). If volume grows, convert `dh_audit.audit_log` to monthly partitions; the table is append-only and indexed on `occurred_at`.

---

## 11. Email notification engine

* **Standard templates** (tracker #15–18), seeded as version 1:

  | Template | Trigger | Recipient |
  |---|---|---|
  | `WALK_IN_INVITE` | transition `MARK_WALKIN` | candidate |
  | `ON_HOLD` | state `WITHHELD` or `PIPELINE` | candidate |
  | `REJECTION` | state `HR_REJECTED` or `PANEL_REJECTED` | candidate |
  | `INTERVIEW_SCHEDULED` | transition `SCHEDULE_HR_ROUND` or `SCHEDULE_PANEL`; online and in-office variants | candidate |

* **Trigger engine** (tracker #19): rows in `notification_trigger` of the form *event → template → recipients*. Match criteria are workflow, transition and/or target state, with `null` meaning any, plus an optional SpEL condition on `#data` / `#event`. Recipients: `CANDIDATE`, `RECRUITER`, `REFERRER`, `ACTOR`, `CUSTOM:x@agshealth.com`. **Adding a trigger for a new step or transition needs no code.**
* **Personalization and candidate audit mapping** (tracker #20):
  - `GET /templates/tokens` lists the tokens: `candidateName`, `jobTitle`, `interviewDate`, `interviewMode`, `interviewLink`, `venueAddress`, `recruiterName`, `reasonLabel`, `coolingPeriodEndDate`, `companyName` and more.
  - Every email is a `notification_dispatch` row, linked to the candidate, application and event, with the rendered HTML and the template version. It is also written to the audit log (category `NOTIFICATION`).
* **Template engine and SMTP** (tracker #21):
  - FreeMarker with HTML auto-escaping; `?new` and the API built-in are disabled.
  - Templates are validated by rendering them with sample tokens before they are saved.
  - Delivery is `SMTP` or `LOG`. Failures retry with backoff (2, 4, 8 … 60 min, 5 attempts). Manual retry: `POST /dispatches/{id}/retry`.
  - `MAIL_OVERRIDE_RECIPIENT` keeps UAT mail away from real candidates.
* **Ad-hoc send** (e.g. the Walk-In email button on Map Candidate): `POST /notification-engine/notifications/send`.

---

## 12. API catalogue (mapped to the UX screens)

All paths go through the gateway. Full request and response schemas are in each service's Swagger UI.

### 12.1 Screens → APIs
| Screen / Figma section | API |
|---|---|
| **Admin §8 "Customize Interview Flow"** | Step builder: `GET /workflow-services/step-library`, `GET/POST/PUT/DELETE /workflow-services/workflows/{code}/draft/steps[/{step}]`, `PUT …/draft/steps-order`, `POST …/publish`, `/workflow-assignments` |
| **Admin §8 "Change Pass Percentage"** | `PUT /admin-services/admin/config/assessment.versant.pass-score` (read by workflow rules as `#config`) |
| Admin: user list (search / deactivate / reactivate / create) | `/admin-services/admin/users` (+ `/roles`, `/permissions`) |
| Admin: role ↔ permission matrix | `GET/PUT /admin-services/admin/permission-matrix`, `/admin/permission-sets/defaults` |
| Admin: central log viewer | `/admin-services/admin/audit-logs` (+ `/export`, `/candidates/{id}`) |
| **Approval module §7** (candidate re-initiation, assessment reschedule) | `/workflow-services/workflow-approvals` |
| Approval: override or shared candidate access | `/admin-services/access-requests` |
| Left filter panels: Job location / Country / Timing / Type (Open Positions), Type / Status / Experience (Interviews), Status (My Referrals), Candidate list | `GET /admin-services/rbac/filters/{OPEN_POSITIONS \| INTERVIEWS \| MY_REFERRALS \| CANDIDATE_LIST \| APPLICANT_LIST}` + `GET /admin-services/master-data/{category}` |
| Application status cards ("Panel Scheduled", "LOI Issued" …), HR tabs | `GET /workflow-services/runtime/instances/APPLICATION/{id}` → `stateLabel`, `tab`, `availableTransitions` |
| Candidate interview summary: stage history | `GET /workflow-services/runtime/instances/APPLICATION/{id}/history` |
| Show / hide menus and buttons per role | `GET /admin-services/rbac/me`, `POST /admin-services/rbac/check` |
| Email templates admin | `/notification-engine/templates` (+ `/tokens`, `/preview`, `/versions`), `/notification-engine/triggers` |
| Candidate communication history | `GET /notification-engine/dispatches?candidateId=…`, `GET /dispatches/{id}` (rendered email) |

### 12.2 admin-services (`/admin-services`)
| Method | Path | Permission |
|---|---|---|
| GET | `/rbac/me` · POST `/rbac/check` · GET `/rbac/filters/{screen}` | authenticated |
| GET | `/rbac/effective?userId=&email=` | USER:VIEW |
| POST/GET | `/admin/users` (search: `search`, `status`, `role`, `page`, `size`) | USER:MANAGE / USER:VIEW |
| GET/PUT | `/admin/users/{id}` | USER:VIEW / USER:MANAGE |
| PATCH | `/admin/users/{id}/deactivate` · `/reactivate` | USER:MANAGE |
| PUT | `/admin/users/{id}/roles` · `/admin/users/{id}/permissions` | USER:MANAGE |
| GET/POST/PUT | `/admin/roles[/{code}]`, POST `/admin/roles/{code}/reset-defaults` | ROLE:VIEW / ADMIN + ROLE:MANAGE |
| GET | `/admin/permissions`, `/admin/permission-sets/defaults?objectType=JOB` | ROLE:VIEW |
| GET/PUT | `/admin/permission-matrix` | ROLE:VIEW / ADMIN + ROLE:MANAGE |
| POST | `/access-requests` · GET `/access-requests/mine` | ACCESS_OVERRIDE:REQUEST / authenticated |
| GET | `/access-requests?status=PENDING` · POST `/{id}/approve` · `/{id}/reject` | ACCESS_OVERRIDE:APPROVE |
| POST | `/access-requests/{id}/revoke` | requester or approver |
| GET/POST/PUT | `/admin/config[/{key}]` | CONFIG:VIEW / **ADMIN + CONFIG:MANAGE** |
| GET/POST/PUT | `/admin/search-filters[/{id}]` | CONFIG:VIEW / ADMIN + CONFIG:MANAGE |
| GET | `/master-data/{category}` · POST `/admin/master-data/{category}` | authenticated / MASTER_DATA:MANAGE |
| GET | `/admin/audit-logs`, `/admin/audit-logs/candidates/{id}`, `/admin/audit-logs/export` | AUDIT_LOG:VIEW / EXPORT |
| GET | `/internal/rbac/effective`, `/internal/config[/{key}]`, `/internal/users/by-role/{role}` | X-Internal-Key |

### 12.3 workflow-services (`/workflow-services`)
| Method | Path | Permission |
|---|---|---|
| GET | `/step-library[/{code}]` · PUT `/step-library/{code}` | WORKFLOW:VIEW / CONFIGURE |
| GET/POST | `/workflows` · GET `/workflows/{code}` · `/states` · `/active` · `/versions/{n}` · `/versions/{a}/compare/{b}` · `/changes` | WORKFLOW:VIEW / CONFIGURE |
| GET/PUT/DELETE | `/workflows/{code}/draft` · POST `/draft/validate` | VIEW / CONFIGURE |
| GET/POST | `/workflows/{code}/draft/steps` · PUT/DELETE `/draft/steps/{step}` · PUT `/draft/steps-order` · PUT `/draft/blueprint` | CONFIGURE |
| PUT/DELETE | `/workflows/{code}/draft/states/{s}` · `/draft/transitions/{t}` · `/draft/rules/{r}` · POST `/workflows/rules/test` | CONFIGURE |
| POST | `/workflows/{code}/publish` · `/versions/{n}/activate` | WORKFLOW:PUBLISH |
| GET/POST/PUT/PATCH | `/workflow-assignments[/{id}]`, `/{id}/deactivate`, GET `/resolve` | VIEW / ASSIGN |
| POST | `/runtime/instances` | APPLICATION:CREATE / MAP / WORKFLOW:ASSIGN |
| GET | `/runtime/instances/{type}/{id}` · `/history` · POST `/validate` | APPLICATION:VIEW / WORKFLOW:VIEW + record scope |
| POST | `/runtime/instances/{type}/{id}/transitions/{code}` · `/move` | per transition (roles, permissions, scope, fields, rules) |
| GET/POST | `/workflow-approvals` · `/{id}/approve` · `/{id}/reject` | approver permission + roles of the transition |
| * | `/internal/runtime/instances/**` | X-Internal-Key (system actor) |

### 12.4 notification-engine (`/notification-engine`)
| Method | Path | Permission |
|---|---|---|
| GET | `/templates` · `/templates/{code}` · `/versions` · `/versions/{n}` · `/tokens` | NOTIFICATION_TEMPLATE:VIEW |
| POST/PUT | `/templates` · `/templates/{code}` (new version) · POST `/{code}/versions/{n}/activate` | NOTIFICATION_TEMPLATE:MANAGE |
| POST | `/templates/preview` · `/templates/{code}/preview` | NOTIFICATION_TEMPLATE:VIEW |
| GET/POST/PUT/PATCH | `/triggers[/{code}]`, `/{code}/activate`, `/{code}/deactivate` | VIEW / MANAGE |
| POST | `/notifications/send` | NOTIFICATION_TEMPLATE:SEND |
| GET | `/dispatches` · `/dispatches/{id}` · POST `/dispatches/{id}/retry` | VIEW, CANDIDATE:VIEW or AUDIT_LOG:VIEW / MANAGE |
| POST | `/internal/events` | X-Internal-Key |

Errors are always RFC 7807, with `code`, `errors[]` and `correlationId`:
```json
{ "type":"about:blank", "title":"TRANSITION_NOT_ALLOWED", "status":422, "detail":"Field 'reasonCode' is required",
  "instance":"/workflow-services/runtime/instances/APPLICATION/…/transitions/HR_REJECT",
  "code":"TRANSITION_NOT_ALLOWED", "errors":[{"code":"MISSING_FIELD","message":"Field 'reasonCode' is required"}],
  "correlationId":"8c1f…" }
```

---

## 13. Sprint 1 traceability

| # | Tracker item | Where |
|---|---|---|
| 1–3 | Default permission set – Job / Candidate / Application | `V2__seed_rbac_defaults.sql` (`default_role_permission`), `/admin/permission-sets/defaults`, `/admin/roles/{code}/reset-defaults` |
| 4 | Role-driven dynamic search filters | `search_filter`, `/rbac/filters/{screen}` |
| 5 | Candidate visibility – recruiter / LOB / location | `DataScope`, `DataScopeSpecifications`, `AccessEvaluator`, runtime scope check |
| 6 | Recruiter ownership and shared-candidate access | OWN scope + `access-requests` with `objectId` |
| 7 | Elevated visibility for TL / Manager | LOB scope + reporting hierarchy (`managerId`, recursive team) |
| 8 | Override access with approver authorization | `access-requests` (approver chain check, validity window) |
| 9 | Central logging framework | starter `AuditLogger`, `@Audited`, ECS logs, correlation ID |
| 10 | Timestamp logs | `AuditableEntity`, request timing log, `occurred_at` |
| 11 | Approval logs | category APPROVAL (access requests + workflow approvals) |
| 12 | Workflow transition logs | `transition_log` + WORKFLOW_TRANSITION audit |
| 13 | Activity logs | `@Audited` / ACTIVITY |
| 14 | Centralized log viewer for Admin (FE) | backend API `/admin/audit-logs` (+ export, candidate timeline) |
| 15–18 | Standard templates Walk-In / On Hold / Rejection / Interview | `V2__seed_standard_templates.sql`, `/templates` |
| 19 | Automated trigger engine | `notification_trigger`, `/internal/events`, workflow after-commit hand-off |
| 20 | Personalization tokens and candidate audit mapping | `/templates/tokens`, `notification_dispatch`, NOTIFICATION audit |
| 21 | Template engine and SMTP configuration | FreeMarker renderer, `spring.mail.*`, retry worker |
| 22 | Admin user account creation | `POST /admin/users`, bootstrap admins |
| 23 | Admin user list – search, deactivate, reactivate | `/admin/users` |
| 24 | Granular user-based permission definition | `PUT /admin/users/{id}/permissions` (ALLOW/DENY) |
| 25 | Role-to-permission mapping matrix | `/admin/permission-matrix` |
| 26 | Workflow state configuration | step stages + common states (`/draft/steps`, `/draft/states`) |
| 27 | Workflow transition configuration | step entry actions and actions, global actions, extra transitions |
| 28 | Workflow rule configuration | named rules + guards + `{{params}}`, `/workflows/rules/test` |
| 29 | Workflow versioning | draft → publish (immutable versions), activate / rollback, instances pinned |
| 30 | Workflow change logging | `workflow_change_log` with diffs + CONFIG_CHANGE audit |
| 31 | Invalid workflow state validation | design time `WorkflowValidator` + compiler issues; runtime 409 `INVALID_STATE` / `INVALID_TRANSITION` |
| 32 | Restrict enterprise configuration to Admin | `hasRole('ADMIN') and hasAuthority('CONFIG:MANAGE')` on config, roles, matrix and filters |
| + | HR-defined workflow per job / role / LOB / combination | `/workflow-assignments` (specificity matching, LOB-scoped) |
| + | Every hiring step configurable by HR | step library + step builder + compiler |

---

## 14. Testing

Unit tests (plain JUnit 5 / AssertJ, no Spring context):

| Test | Covers |
|---|---|
| `workflow-services …/WorkflowEngineTest` | Seeded workflows valid; invalid state, permission, required field, system-only, config-driven rule, cooling period + approval, photo rule, options |
| `…/StepCompilerTest` | The 28 legacy codes are kept; HR makes Versant optional and inserts an SHL step with `passScore=70`; token errors |
| `…/WorkflowValidatorTest`, `…/RuleEvaluatorTest`, `…/AssignmentMatcherTest` | Graph checks, SpEL sandbox (`T(...)`, `new` blocked), job > role > LOB specificity |
| `notification-engine …/NotificationEngineTest` | Token defaults, HTML escaping, missing tokens, `?new` blocked, recipient resolution, sandboxed conditions |
| `digihire-platform-starter …/AccessEvaluatorTest` | OWN / shared / TEAM / LOB visibility |

```bash
mvn clean verify
```

Recommended next: add Testcontainers (`org.testcontainers:postgresql`) integration tests for the Flyway migrations and the three `/internal` hand-offs, plus a Boot 3.1 compatibility test profile for the starter.

**Verification done while writing this** (Maven Central unreachable from the authoring sandbox):
1. `javac` parse and cross-reference of all modules with library stubs: no project-internal errors.
2. The workflow engine classes were compiled and run for real against both seed workflows and all 10 step-library templates:
   - 28 legacy states;
   - main path CREATED → … → JOINED;
   - the optional-step skip;
   - `{{passScore}}` substitution;
   - every template compiles and validates.

   **All checks passed.**
3. An independent code review; its fixes are applied.

---

## 15. Open dependencies, limitations and next steps

| Item | Status / action |
|---|---|
| DEP-S1-04 signed RBAC matrix, DEP-S1-11 admin role hierarchy | Seeded defaults are a **proposal**. Adjust them through `/admin/permission-matrix` and `/admin/roles` after sign-off; no redeploy needed. |
| DEP-S1-03 role / LOB / location master data | Seeded examples in `master_data`. Load the real list through `/admin/master-data/{category}`. |
| DEP-S1-10 workflow state and transition catalogue per LOB / assessment | Configure it with the step builder and `/workflow-assignments`. |
| DEP-S1-05 log schema, sizing, retention | `dh_audit.audit_log` + `AUDIT_RETENTION_DAYS`; partition monthly if volume needs it. |
| DEP-S1-01 SMTP | Set `SMTP_*` (SES SMTP or AGS relay); `NOTIFICATION_DELIVERY=SMTP`. |
| Hard-coded JWT secret in gateway / auth (KB §25.1) | **Move to `JWT_SECRET` before go-live** (required by §7.3). |
| Front-end (tracker FE items, #14 log viewer UI) | APIs are ready; Angular screens are not part of this backend drop. |
| Sprint 2 items that fit this design | Secret store and credential masking (add a `sensitive` flag to `enterprise_config` + vault), multi-level approvers (chain several APPROVAL steps or extend `approverRoles` per level), assessment framework and 60-day validity (step library + `ASSESSMENT_SCORE_VALID` rule), blacklist (a rule over `#entity['blacklisted']`), unlock accounts (auth-services). |
| Access cache | Role / permission changes reach other services within 2 minutes (`digihire.access.cache-ttl`). |
| Spring Boot 3.5 OSS support ended June 2026 | Plan the move to Boot 4.1 / Spring Cloud 2025.1 together with the existing services. The main migration item is Jackson 2 → 3 (package `com.fasterxml` → `tools.jackson`, used in a handful of classes); `@MockBean` and other APIs removed in 4.x are not used. |
