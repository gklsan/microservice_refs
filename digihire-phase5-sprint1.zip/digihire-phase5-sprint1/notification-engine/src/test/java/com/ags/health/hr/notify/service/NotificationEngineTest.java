package com.ags.health.hr.notify.service;

import org.junit.jupiter.api.Test;

import java.util.Map;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

class NotificationEngineTest {

    private final TemplateRenderer renderer = new TemplateRenderer();

    @Test
    void rendersTokensWithDefaultsAndEscapesHtml() {
        TemplateRenderer.Rendered r = renderer.renderAdHoc(
                "Walk-in - ${jobTitle!\"Open position\"}",
                "<p>Dear ${candidateName!\"Candidate\"}</p><#if (interviewMode!\"\") == \"ONLINE\">online</#if>",
                Map.of("candidateName", "<script>x</script>", "interviewMode", "ONLINE"));
        assertThat(r.subject()).isEqualTo("Walk-in - Open position");
        assertThat(r.body()).contains("&lt;script&gt;").contains("online");
    }

    @Test
    void missingTokenWithoutDefaultFails() {
        assertThatThrownBy(() -> renderer.renderAdHoc("x", "${notProvided}", Map.of()))
                .isInstanceOf(TemplateRenderer.TemplateRenderException.class);
    }

    @Test
    void newBuiltinIsBlocked() {
        assertThatThrownBy(() -> renderer.renderAdHoc("x",
                "<#assign ex=\"freemarker.template.utility.Execute\"?new()>${ex(\"id\")}", Map.of()))
                .isInstanceOf(TemplateRenderer.TemplateRenderException.class);
    }

    @Test
    void resolvesRecipients() {
        Map<String, Object> data = Map.of("candidateEmail", "James@Example.com", "recruiterEmail", "not-an-email");
        assertThat(DispatchService.recipients("CANDIDATE, RECRUITER, CUSTOM:ta@agshealth.com", data,
                Map.of("email", "hr@agshealth.com")))
                .containsExactly("james@example.com", "ta@agshealth.com");
    }

    @Test
    void conditionsAreSandboxed() {
        ConditionEvaluator c = new ConditionEvaluator();
        assertThat(c.matches("#data['interviewMode'] == 'ONLINE'", Map.of("interviewMode", "ONLINE"), Map.of())).isTrue();
        assertThatThrownBy(() -> c.matches("T(java.lang.System).exit(0) == null", Map.of(), Map.of()))
                .isInstanceOf(RuntimeException.class);
    }
}
