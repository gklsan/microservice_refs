-- Standard candidate templates (tracker #15-18) and their automated triggers (tracker #19).
-- Seeded once; afterwards they are maintained through the /templates and /triggers APIs.

INSERT INTO dh_notify.notification_template (id, code, version_no, channel, name, category, subject, body, description, active, created_by)
VALUES (gen_random_uuid(), 'WALK_IN_INVITE', 1, 'EMAIL', 'Walk-in invitation', 'CANDIDATE', 'Walk-in interview at ${companyName} - ${jobTitle!"Open position"}', $tpl$<!DOCTYPE html>
<html><body style="margin:0;padding:0;background:#f5f6fa;font-family:Arial,Helvetica,sans-serif;color:#2a2d4a;">
<table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="background:#f5f6fa;padding:24px 0;">
<tr><td align="center">
<table role="presentation" width="600" cellpadding="0" cellspacing="0" style="background:#ffffff;border-radius:8px;overflow:hidden;">
<tr><td style="background:#262a3f;padding:20px 32px;color:#ffffff;font-size:22px;font-weight:bold;">${companyName}</td></tr>
<tr><td style="padding:32px;font-size:15px;line-height:1.6;">
<p>Dear ${candidateName!"Candidate"},</p>
<p>Thank you for your interest in the <b>${jobTitle!"open"}</b> role<#if location??> at our ${location} office</#if>. We are pleased to invite you for a <b>walk-in interview</b>.</p>
<table role="presentation" cellpadding="6" style="background:#eefaf3;border-radius:6px;margin:16px 0;">
<tr><td><b>Date</b></td><td>${interviewDate!"To be confirmed"}</td></tr>
<#if interviewTime??><tr><td><b>Time</b></td><td>${interviewTime}</td></tr></#if>
<#if venueAddress??><tr><td><b>Venue</b></td><td>${venueAddress}</td></tr></#if>
</table>
<p>Please carry the following:</p>
<ul><li>Original government photo ID (Aadhaar / PAN)</li><li>An updated copy of your resume</li><li>One passport-size photograph</li></ul>
<p>At the reception, share your registered mobile number or email ID to check in.</p>
<p>Regards,<br/>${recruiterName!"Talent Acquisition Team"}<br/>${companyName}<#if recruiterPhone??> &middot; ${recruiterPhone}</#if></p>
</td></tr>
<tr><td style="background:#f0f2f7;padding:16px 32px;font-size:12px;color:#6b6f85;">This is an automated message from DigiHire. Please do not reply to this email.</td></tr>
</table></td></tr></table></body></html>$tpl$, 'Sent when the recruiter schedules / marks a walk-in (BRD 4.5)', TRUE, 'flyway')
ON CONFLICT (code, version_no) DO NOTHING;

INSERT INTO dh_notify.notification_template (id, code, version_no, channel, name, category, subject, body, description, active, created_by)
VALUES (gen_random_uuid(), 'ON_HOLD', 1, 'EMAIL', 'Application on hold', 'CANDIDATE', 'Update on your application for ${jobTitle!"the position"}', $tpl$<!DOCTYPE html>
<html><body style="margin:0;padding:0;background:#f5f6fa;font-family:Arial,Helvetica,sans-serif;color:#2a2d4a;">
<table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="background:#f5f6fa;padding:24px 0;">
<tr><td align="center">
<table role="presentation" width="600" cellpadding="0" cellspacing="0" style="background:#ffffff;border-radius:8px;overflow:hidden;">
<tr><td style="background:#262a3f;padding:20px 32px;color:#ffffff;font-size:22px;font-weight:bold;">${companyName}</td></tr>
<tr><td style="padding:32px;font-size:15px;line-height:1.6;">
<p>Dear ${candidateName!"Candidate"},</p>
<p>Thank you for your time and interest in ${companyName}. Your application for <b>${jobTitle!"the position"}</b> is currently <b>on hold</b><#if reasonLabel??> (${reasonLabel})</#if>.</p>
<p>Your profile remains active in our talent pipeline and our recruitment team will contact you as soon as a suitable position opens up. You do not need to re-apply.</p>
<#if remarks??><p><i>${remarks}</i></p></#if>
<p>Regards,<br/>${recruiterName!"Talent Acquisition Team"}<br/>${companyName}<#if recruiterPhone??> &middot; ${recruiterPhone}</#if></p>
</td></tr>
<tr><td style="background:#f0f2f7;padding:16px 32px;font-size:12px;color:#6b6f85;">This is an automated message from DigiHire. Please do not reply to this email.</td></tr>
</table></td></tr></table></body></html>$tpl$, 'Sent when an application is put on hold or moved to the pipeline (BRD 4.5)', TRUE, 'flyway')
ON CONFLICT (code, version_no) DO NOTHING;

INSERT INTO dh_notify.notification_template (id, code, version_no, channel, name, category, subject, body, description, active, created_by)
VALUES (gen_random_uuid(), 'REJECTION', 1, 'EMAIL', 'Application outcome', 'CANDIDATE', 'Your application for ${jobTitle!"the position"} at ${companyName}', $tpl$<!DOCTYPE html>
<html><body style="margin:0;padding:0;background:#f5f6fa;font-family:Arial,Helvetica,sans-serif;color:#2a2d4a;">
<table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="background:#f5f6fa;padding:24px 0;">
<tr><td align="center">
<table role="presentation" width="600" cellpadding="0" cellspacing="0" style="background:#ffffff;border-radius:8px;overflow:hidden;">
<tr><td style="background:#262a3f;padding:20px 32px;color:#ffffff;font-size:22px;font-weight:bold;">${companyName}</td></tr>
<tr><td style="padding:32px;font-size:15px;line-height:1.6;">
<p>Dear ${candidateName!"Candidate"},</p>
<p>Thank you for the time and effort you invested in the selection process for <b>${jobTitle!"the position"}</b>.</p>
<p>After careful consideration, we regret to inform you that we will not be moving forward with your application at this time.</p>
<#if coolingPeriodEndDate??><p>You are welcome to apply again for suitable roles from <b>${coolingPeriodEndDate}</b>.</p></#if>
<p>We appreciate your interest in ${companyName} and wish you every success.</p>
<p>Regards,<br/>${recruiterName!"Talent Acquisition Team"}<br/>${companyName}<#if recruiterPhone??> &middot; ${recruiterPhone}</#if></p>
</td></tr>
<tr><td style="background:#f0f2f7;padding:16px 32px;font-size:12px;color:#6b6f85;">This is an automated message from DigiHire. Please do not reply to this email.</td></tr>
</table></td></tr></table></body></html>$tpl$, 'Sent when an application is rejected at any stage with a standard reason (BRD 4.5 / 4.6)', TRUE, 'flyway')
ON CONFLICT (code, version_no) DO NOTHING;

INSERT INTO dh_notify.notification_template (id, code, version_no, channel, name, category, subject, body, description, active, created_by)
VALUES (gen_random_uuid(), 'INTERVIEW_SCHEDULED', 1, 'EMAIL', 'Interview scheduled', 'CANDIDATE', '${interviewRound!"Interview"} scheduled - ${jobTitle!""} on ${interviewDate!""}', $tpl$<!DOCTYPE html>
<html><body style="margin:0;padding:0;background:#f5f6fa;font-family:Arial,Helvetica,sans-serif;color:#2a2d4a;">
<table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="background:#f5f6fa;padding:24px 0;">
<tr><td align="center">
<table role="presentation" width="600" cellpadding="0" cellspacing="0" style="background:#ffffff;border-radius:8px;overflow:hidden;">
<tr><td style="background:#262a3f;padding:20px 32px;color:#ffffff;font-size:22px;font-weight:bold;">${companyName}</td></tr>
<tr><td style="padding:32px;font-size:15px;line-height:1.6;">
<p>Dear ${candidateName!"Candidate"},</p>
<p>Your <b>${interviewRound!"interview"}</b> for the <b>${jobTitle!"open"}</b> role has been scheduled.</p>
<table role="presentation" cellpadding="6" style="background:#eefaf3;border-radius:6px;margin:16px 0;">
<tr><td><b>Date</b></td><td>${interviewDate!"To be confirmed"}</td></tr>
<#if interviewTime??><tr><td><b>Time</b></td><td>${interviewTime}</td></tr></#if>
<tr><td><b>Mode</b></td><td><#if (interviewMode!"") == "ONLINE">Online<#else>In-office</#if></td></tr>
<#if (interviewMode!"") == "ONLINE">
<tr><td><b>Join link</b></td><td><#if interviewLink??><a href="${interviewLink}">${interviewLink}</a><#else>will be shared shortly</#if></td></tr>
<#else>
<#if venueAddress??><tr><td><b>Venue</b></td><td>${venueAddress}</td></tr></#if>
</#if>
</table>
<#if (interviewMode!"") == "ONLINE"><p>Please join 5 minutes early from a quiet place with a working camera and microphone. Keep your photo ID ready for verification.</p>
<#else><p>Please carry an original government photo ID for verification at the reception.</p></#if>
<p>Regards,<br/>${recruiterName!"Talent Acquisition Team"}<br/>${companyName}<#if recruiterPhone??> &middot; ${recruiterPhone}</#if></p>
</td></tr>
<tr><td style="background:#f0f2f7;padding:16px 32px;font-size:12px;color:#6b6f85;">This is an automated message from DigiHire. Please do not reply to this email.</td></tr>
</table></td></tr></table></body></html>$tpl$, 'Sent when an HR round or panel interview is scheduled, online or in-office (BRD 4.5 / 4.10 / 4.12)', TRUE, 'flyway')
ON CONFLICT (code, version_no) DO NOTHING;

INSERT INTO dh_notify.notification_trigger (id, code, name, event_type, workflow_code, transition_code, to_state, template_code, recipients, active, created_by) VALUES (gen_random_uuid(), 'WALKIN_ON_MARK_WALKIN', 'Walk-in invite', 'WORKFLOW_TRANSITION', NULL, 'MARK_WALKIN', NULL, 'WALK_IN_INVITE', 'CANDIDATE', TRUE, 'flyway') ON CONFLICT (code) DO NOTHING;
INSERT INTO dh_notify.notification_trigger (id, code, name, event_type, workflow_code, transition_code, to_state, template_code, recipients, active, created_by) VALUES (gen_random_uuid(), 'HOLD_ON_WITHHELD', 'On hold notice', 'WORKFLOW_TRANSITION', NULL, 'PUT_ON_HOLD', NULL, 'ON_HOLD', 'CANDIDATE', TRUE, 'flyway') ON CONFLICT (code) DO NOTHING;
INSERT INTO dh_notify.notification_trigger (id, code, name, event_type, workflow_code, transition_code, to_state, template_code, recipients, active, created_by) VALUES (gen_random_uuid(), 'HOLD_ON_PIPELINE', 'Moved to pipeline notice', 'WORKFLOW_TRANSITION', NULL, NULL, 'PIPELINE', 'ON_HOLD', 'CANDIDATE', TRUE, 'flyway') ON CONFLICT (code) DO NOTHING;
INSERT INTO dh_notify.notification_trigger (id, code, name, event_type, workflow_code, transition_code, to_state, template_code, recipients, active, created_by) VALUES (gen_random_uuid(), 'REJECT_ON_HR_REJECTED', 'Rejection notice', 'WORKFLOW_TRANSITION', NULL, NULL, 'HR_REJECTED', 'REJECTION', 'CANDIDATE', TRUE, 'flyway') ON CONFLICT (code) DO NOTHING;
INSERT INTO dh_notify.notification_trigger (id, code, name, event_type, workflow_code, transition_code, to_state, template_code, recipients, active, created_by) VALUES (gen_random_uuid(), 'REJECT_ON_PANEL_REJECTED', 'Rejection notice (panel)', 'WORKFLOW_TRANSITION', NULL, NULL, 'PANEL_REJECTED', 'REJECTION', 'CANDIDATE', TRUE, 'flyway') ON CONFLICT (code) DO NOTHING;
INSERT INTO dh_notify.notification_trigger (id, code, name, event_type, workflow_code, transition_code, to_state, template_code, recipients, active, created_by) VALUES (gen_random_uuid(), 'INTERVIEW_ON_HR_ROUND', 'HR round scheduled', 'WORKFLOW_TRANSITION', NULL, 'SCHEDULE_HR_ROUND', NULL, 'INTERVIEW_SCHEDULED', 'CANDIDATE', TRUE, 'flyway') ON CONFLICT (code) DO NOTHING;
INSERT INTO dh_notify.notification_trigger (id, code, name, event_type, workflow_code, transition_code, to_state, template_code, recipients, active, created_by) VALUES (gen_random_uuid(), 'INTERVIEW_ON_PANEL', 'Panel interview scheduled', 'WORKFLOW_TRANSITION', NULL, 'SCHEDULE_PANEL', NULL, 'INTERVIEW_SCHEDULED', 'CANDIDATE', TRUE, 'flyway') ON CONFLICT (code) DO NOTHING;
