-- =====================================================================================================
-- notification-engine schema (Phase 5 / Sprint 1): templates, triggers, dispatch log
-- =====================================================================================================

-- Versioned FreeMarker templates; exactly one active version per code.
CREATE TABLE IF NOT EXISTS dh_notify.notification_template (
    id            UUID PRIMARY KEY,
    code          VARCHAR(60)   NOT NULL,
    version_no    INT           NOT NULL,
    channel       VARCHAR(10)   NOT NULL DEFAULT 'EMAIL',   -- EMAIL (SMS reserved)
    name          VARCHAR(150)  NOT NULL,
    category      VARCHAR(60)   NOT NULL DEFAULT 'CANDIDATE',
    subject       VARCHAR(500)  NOT NULL,                   -- FreeMarker, plain text
    body          TEXT          NOT NULL,                   -- FreeMarker, HTML (auto-escaped)
    description   VARCHAR(500),
    active        BOOLEAN       NOT NULL DEFAULT TRUE,
    created_at    TIMESTAMPTZ   NOT NULL DEFAULT now(),
    created_by    VARCHAR(100),
    updated_at    TIMESTAMPTZ,
    updated_by    VARCHAR(100),
    row_version   BIGINT        NOT NULL DEFAULT 0,
    UNIQUE (code, version_no)
);
CREATE UNIQUE INDEX IF NOT EXISTS ux_template_active ON dh_notify.notification_template (code) WHERE active;

-- Automated trigger engine configuration: which event sends which template to whom.
CREATE TABLE IF NOT EXISTS dh_notify.notification_trigger (
    id               UUID PRIMARY KEY,
    code             VARCHAR(60)   NOT NULL UNIQUE,
    name             VARCHAR(150)  NOT NULL,
    event_type       VARCHAR(40)   NOT NULL DEFAULT 'WORKFLOW_TRANSITION',
    workflow_code    VARCHAR(60),                          -- null = any workflow
    transition_code  VARCHAR(60),                          -- null = any transition
    to_state         VARCHAR(60),                          -- null = any target state
    template_code    VARCHAR(60)   NOT NULL,
    recipients       VARCHAR(500)  NOT NULL DEFAULT 'CANDIDATE', -- CANDIDATE, RECRUITER, REFERRER, ACTOR, CUSTOM:mail@x
    cc               VARCHAR(500),
    condition_expr   VARCHAR(1000),                        -- optional SpEL on #data / #event
    active           BOOLEAN       NOT NULL DEFAULT TRUE,
    created_at       TIMESTAMPTZ   NOT NULL DEFAULT now(),
    created_by       VARCHAR(100),
    updated_at       TIMESTAMPTZ,
    updated_by       VARCHAR(100),
    row_version      BIGINT        NOT NULL DEFAULT 0
);
CREATE INDEX IF NOT EXISTS ix_trigger_event ON dh_notify.notification_trigger (event_type, active);

-- One row per email per recipient = candidate communication audit.
CREATE TABLE IF NOT EXISTS dh_notify.notification_dispatch (
    id                UUID PRIMARY KEY,
    event_id          VARCHAR(100)  NOT NULL,              -- idempotency key from the producer
    trigger_code      VARCHAR(60),                         -- null for ad-hoc sends
    template_code     VARCHAR(60)   NOT NULL,
    template_version  INT           NOT NULL,
    channel           VARCHAR(10)   NOT NULL DEFAULT 'EMAIL',
    recipient         VARCHAR(254)  NOT NULL,
    cc                VARCHAR(1000),
    subject           VARCHAR(500),
    body              TEXT,
    status            VARCHAR(20)   NOT NULL,              -- PENDING | SENDING | SENT | FAILED | SKIPPED
    attempts          INT           NOT NULL DEFAULT 0,
    last_error        VARCHAR(2000),
    next_attempt_at   TIMESTAMPTZ,
    entity_type       VARCHAR(40),
    entity_id         VARCHAR(100),
    candidate_id      VARCHAR(100),
    correlation_id    VARCHAR(64),
    requested_by      VARCHAR(200),
    sent_at           TIMESTAMPTZ,
    created_at        TIMESTAMPTZ   NOT NULL DEFAULT now(),
    UNIQUE (event_id, template_code, recipient)
);
CREATE INDEX IF NOT EXISTS ix_dispatch_candidate ON dh_notify.notification_dispatch (candidate_id, created_at DESC);
CREATE INDEX IF NOT EXISTS ix_dispatch_entity ON dh_notify.notification_dispatch (entity_type, entity_id);
CREATE INDEX IF NOT EXISTS ix_dispatch_retry ON dh_notify.notification_dispatch (status, next_attempt_at);
