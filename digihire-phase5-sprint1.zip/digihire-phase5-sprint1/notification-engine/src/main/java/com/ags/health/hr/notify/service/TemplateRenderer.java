package com.ags.health.hr.notify.service;

import freemarker.core.HTMLOutputFormat;
import freemarker.core.PlainTextOutputFormat;
import freemarker.core.TemplateClassResolver;
import freemarker.template.Configuration;
import freemarker.template.Template;
import freemarker.template.TemplateExceptionHandler;
import org.springframework.stereotype.Component;

import java.io.StringReader;
import java.io.StringWriter;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * FreeMarker rendering (template engine, tracker #21). Body output is HTML auto-escaped, so candidate supplied
 * values can never inject markup; {@code ?new} / API built-ins are disabled.
 */
@Component
public class TemplateRenderer {

    private final Configuration html = config(true);
    private final Configuration text = config(false);
    private final Map<String, Template> cache = new ConcurrentHashMap<>();

    public record Rendered(String subject, String body) {
    }

    private static Configuration config(boolean isHtml) {
        Configuration cfg = new Configuration(Configuration.VERSION_2_3_32);
        cfg.setDefaultEncoding("UTF-8");
        cfg.setOutputFormat(isHtml ? HTMLOutputFormat.INSTANCE : PlainTextOutputFormat.INSTANCE);
        cfg.setTemplateExceptionHandler(TemplateExceptionHandler.RETHROW_HANDLER);
        cfg.setLogTemplateExceptions(false);
        cfg.setWrapUncheckedExceptions(true);
        cfg.setNewBuiltinClassResolver(TemplateClassResolver.ALLOWS_NOTHING_RESOLVER);
        cfg.setAPIBuiltinEnabled(false);
        cfg.setNumberFormat("computer");
        return cfg;
    }

    /** Renders cached compiled templates (key identifies an immutable template version). */
    public Rendered render(String cacheKey, String subjectSrc, String bodySrc, Map<String, Object> model) {
        return new Rendered(process(cacheKey + ":subject", subjectSrc, text, model),
                process(cacheKey + ":body", bodySrc, html, model));
    }

    /** Renders without caching (previews / validation of unsaved templates). */
    public Rendered renderAdHoc(String subjectSrc, String bodySrc, Map<String, Object> model) {
        return new Rendered(process(null, subjectSrc, text, model), process(null, bodySrc, html, model));
    }

    private String process(String key, String src, Configuration cfg, Map<String, Object> model) {
        try {
            Template t = key == null ? new Template("adhoc", new StringReader(src), cfg)
                    : cache.computeIfAbsent(key, k -> compile(k, src, cfg));
            StringWriter out = new StringWriter();
            t.process(model, out);
            return out.toString();
        } catch (TemplateRenderException e) {
            throw e;
        } catch (Exception e) {
            throw new TemplateRenderException(e.getMessage(), e);
        }
    }

    private static Template compile(String name, String src, Configuration cfg) {
        try {
            return new Template(name, new StringReader(src), cfg);
        } catch (Exception e) {
            throw new TemplateRenderException(e.getMessage(), e);
        }
    }

    public static class TemplateRenderException extends RuntimeException {
        public TemplateRenderException(String message, Throwable cause) {
            super(message, cause);
        }
    }
}
