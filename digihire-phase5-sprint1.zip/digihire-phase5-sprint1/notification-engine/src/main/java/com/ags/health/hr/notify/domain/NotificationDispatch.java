package com.ags.health.hr.notify.domain;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.Instant;
import java.util.UUID;

/** One email to one recipient - the candidate communication audit (tracker #20). */
@Entity
@Table(name = "notification_dispatch")
@Getter
@Setter
@NoArgsConstructor
public class NotificationDispatch {

    public enum Status { PENDING, SENDING, SENT, FAILED, SKIPPED }

    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    private UUID id;

    @Column(name = "event_id", nullable = false, updatable = false)
    private String eventId;

    @Column(name = "trigger_code", updatable = false)
    private String triggerCode;

    @Column(name = "template_code", nullable = false, updatable = false)
    private String templateCode;

    @Column(name = "template_version", nullable = false, updatable = false)
    private int templateVersion;

    @Column(nullable = false)
    private String channel = "EMAIL";

    @Column(nullable = false)
    private String recipient;

    private String cc;

    private String subject;

    private String body;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private Status status = Status.PENDING;

    @Column(nullable = false)
    private int attempts;

    @Column(name = "last_error")
    private String lastError;

    @Column(name = "next_attempt_at")
    private Instant nextAttemptAt;

    @Column(name = "entity_type")
    private String entityType;

    @Column(name = "entity_id")
    private String entityId;

    @Column(name = "candidate_id")
    private String candidateId;

    @Column(name = "correlation_id")
    private String correlationId;

    @Column(name = "requested_by")
    private String requestedBy;

    @Column(name = "sent_at")
    private Instant sentAt;

    @Column(name = "created_at", nullable = false, updatable = false)
    private Instant createdAt = Instant.now();
}
