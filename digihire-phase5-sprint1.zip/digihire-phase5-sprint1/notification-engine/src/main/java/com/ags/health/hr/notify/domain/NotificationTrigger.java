package com.ags.health.hr.notify.domain;

import com.ags.health.hr.platform.jpa.AuditableEntity;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.UUID;

/**
 * Automated trigger rule (tracker #19): when an event of {@code eventType} matches workflow / transition /
 * target state (null = any) and the optional condition, send {@code templateCode} to {@code recipients}.
 */
@Entity
@Table(name = "notification_trigger")
@Getter
@Setter
@NoArgsConstructor
public class NotificationTrigger extends AuditableEntity {

    @Id
    private UUID id;

    @Column(nullable = false, unique = true, updatable = false)
    private String code;

    @Column(nullable = false)
    private String name;

    @Column(name = "event_type", nullable = false)
    private String eventType = "WORKFLOW_TRANSITION";

    @Column(name = "workflow_code")
    private String workflowCode;

    @Column(name = "transition_code")
    private String transitionCode;

    @Column(name = "to_state")
    private String toState;

    @Column(name = "template_code", nullable = false)
    private String templateCode;

    @Column(nullable = false)
    private String recipients = "CANDIDATE";

    private String cc;

    @Column(name = "condition_expr")
    private String conditionExpr;

    @Column(nullable = false)
    private boolean active = true;
}
