package com.ags.health.hr.notify;

import org.springframework.boot.context.properties.ConfigurationProperties;

@ConfigurationProperties(prefix = "digihire.notification")
public record NotificationProperties(Delivery delivery,
                                     String fromAddress,
                                     String fromName,
                                     String companyName,
                                     boolean storeRenderedBody,
                                     int maxAttempts,
                                     String retryCron,
                                     String overrideRecipient) {

    public enum Delivery { SMTP, LOG }

    public NotificationProperties {
        delivery = delivery == null ? Delivery.LOG : delivery;
        companyName = companyName == null ? "AGS Health" : companyName;
        maxAttempts = maxAttempts <= 0 ? 5 : maxAttempts;
    }

    public boolean hasOverride() {
        return overrideRecipient != null && !overrideRecipient.isBlank();
    }
}
