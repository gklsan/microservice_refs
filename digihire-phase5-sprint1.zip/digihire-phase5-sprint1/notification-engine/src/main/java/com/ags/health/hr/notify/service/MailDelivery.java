package com.ags.health.hr.notify.service;

import com.ags.health.hr.notify.NotificationProperties;
import jakarta.mail.internet.MimeMessage;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;

import java.util.List;

/** Delivery channel (tracker #21 "SMTP configuration"): SMTP for real sends, LOG for dev / UAT dry-runs. */
public interface MailDelivery {

    void send(String to, List<String> cc, String subject, String html) throws Exception;

    @Configuration(proxyBeanMethods = false)
    class Config {

        private static final Logger log = LoggerFactory.getLogger(MailDelivery.class);

        @Bean
        @ConditionalOnProperty(prefix = "digihire.notification", name = "delivery", havingValue = "SMTP")
        MailDelivery smtpDelivery(JavaMailSender sender, NotificationProperties props) {
            return (to, cc, subject, html) -> {
                MimeMessage message = sender.createMimeMessage();
                MimeMessageHelper helper = new MimeMessageHelper(message, false, "UTF-8");
                helper.setFrom(props.fromAddress(), props.fromName());
                helper.setTo(to);
                if (cc != null && !cc.isEmpty()) {
                    helper.setCc(cc.toArray(String[]::new));
                }
                helper.setSubject(subject);
                helper.setText(html, true);
                sender.send(message);
            };
        }

        @Bean
        @ConditionalOnProperty(prefix = "digihire.notification", name = "delivery", havingValue = "LOG", matchIfMissing = true)
        MailDelivery logDelivery() {
            return (to, cc, subject, html) -> log.info("[LOG DELIVERY] to={} cc={} subject='{}' ({} chars)",
                    to, cc, subject, html == null ? 0 : html.length());
        }
    }
}
