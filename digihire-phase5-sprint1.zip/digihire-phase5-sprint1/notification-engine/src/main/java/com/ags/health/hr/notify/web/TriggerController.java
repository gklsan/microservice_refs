package com.ags.health.hr.notify.web;

import com.ags.health.hr.notify.service.TriggerService;
import com.ags.health.hr.notify.web.NotifyDtos.TriggerRequest;
import com.ags.health.hr.notify.web.NotifyDtos.TriggerResponse;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/** Automated trigger rules: event (workflow / transition / target state) -> template -> recipients. */
@RestController
@RequestMapping("/triggers")
@Tag(name = "Automated triggers")
public class TriggerController {

    private final TriggerService service;

    public TriggerController(TriggerService service) {
        this.service = service;
    }

    @GetMapping
    @PreAuthorize("hasAuthority('NOTIFICATION_TEMPLATE:VIEW')")
    public List<TriggerResponse> list() {
        return service.list();
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    @PreAuthorize("hasAuthority('NOTIFICATION_TEMPLATE:MANAGE')")
    @Operation(summary = "e.g. transitionCode=MARK_WALKIN -> WALK_IN_INVITE -> CANDIDATE (null criteria = any)")
    public TriggerResponse create(@Valid @RequestBody TriggerRequest req) {
        return service.create(req);
    }

    @PutMapping("/{code}")
    @PreAuthorize("hasAuthority('NOTIFICATION_TEMPLATE:MANAGE')")
    public TriggerResponse update(@PathVariable String code, @Valid @RequestBody TriggerRequest req) {
        return service.update(code, req);
    }

    @PatchMapping("/{code}/activate")
    @PreAuthorize("hasAuthority('NOTIFICATION_TEMPLATE:MANAGE')")
    public TriggerResponse activate(@PathVariable String code) {
        return service.setActive(code, true);
    }

    @PatchMapping("/{code}/deactivate")
    @PreAuthorize("hasAuthority('NOTIFICATION_TEMPLATE:MANAGE')")
    public TriggerResponse deactivate(@PathVariable String code) {
        return service.setActive(code, false);
    }
}
