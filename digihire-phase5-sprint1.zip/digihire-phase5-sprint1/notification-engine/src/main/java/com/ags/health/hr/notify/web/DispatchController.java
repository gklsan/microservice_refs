package com.ags.health.hr.notify.web;

import com.ags.health.hr.notify.domain.NotificationDispatch;
import com.ags.health.hr.notify.service.DispatchService;
import com.ags.health.hr.notify.web.NotifyDtos.DispatchResponse;
import com.ags.health.hr.notify.web.NotifyDtos.IntakeResult;
import com.ags.health.hr.notify.web.NotifyDtos.PageResponse;
import com.ags.health.hr.notify.web.NotifyDtos.SendRequest;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.time.Instant;
import java.util.UUID;

/** Ad-hoc sends and the dispatch log (which email went to which candidate, when, with which template version). */
@RestController
@Tag(name = "Dispatches")
public class DispatchController {

    private final DispatchService service;

    public DispatchController(DispatchService service) {
        this.service = service;
    }

    @PostMapping("/notifications/send")
    @PreAuthorize("hasAuthority('NOTIFICATION_TEMPLATE:SEND')")
    @Operation(summary = "Send a template to explicit recipients (e.g. Walk-In email from Map Candidate)")
    public IntakeResult send(@Valid @RequestBody SendRequest req) {
        return service.send(req);
    }

    @GetMapping("/dispatches")
    @PreAuthorize("hasAnyAuthority('NOTIFICATION_TEMPLATE:VIEW', 'CANDIDATE:VIEW', 'AUDIT_LOG:VIEW')")
    public PageResponse<DispatchResponse> search(@RequestParam(required = false) String candidateId,
                                                 @RequestParam(required = false) String entityType,
                                                 @RequestParam(required = false) String entityId,
                                                 @RequestParam(required = false) NotificationDispatch.Status status,
                                                 @RequestParam(required = false) String templateCode,
                                                 @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) Instant from,
                                                 @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) Instant to,
                                                 @RequestParam(defaultValue = "0") int page,
                                                 @RequestParam(defaultValue = "20") int size) {
        return service.search(candidateId, entityType, entityId, status, templateCode, from, to,
                PageRequest.of(Math.max(page, 0), Math.min(Math.max(size, 1), 100), Sort.by(Sort.Direction.DESC, "createdAt")));
    }

    @GetMapping("/dispatches/{id}")
    @PreAuthorize("hasAnyAuthority('NOTIFICATION_TEMPLATE:VIEW', 'CANDIDATE:VIEW', 'AUDIT_LOG:VIEW')")
    @Operation(summary = "Dispatch with the rendered email body")
    public DispatchResponse get(@PathVariable UUID id) {
        return service.get(id);
    }

    @PostMapping("/dispatches/{id}/retry")
    @PreAuthorize("hasAuthority('NOTIFICATION_TEMPLATE:MANAGE')")
    public DispatchResponse retry(@PathVariable UUID id) {
        return service.retry(id);
    }
}
