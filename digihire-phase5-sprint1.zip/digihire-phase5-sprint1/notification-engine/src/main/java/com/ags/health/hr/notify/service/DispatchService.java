package com.ags.health.hr.notify.service;

import com.ags.health.hr.notify.NotificationProperties;
import com.ags.health.hr.notify.domain.NotificationDispatch;
import com.ags.health.hr.notify.domain.NotificationTemplate;
import com.ags.health.hr.notify.domain.NotificationTrigger;
import com.ags.health.hr.notify.repo.NotificationDispatchRepository;
import com.ags.health.hr.notify.repo.NotificationTemplateRepository;
import com.ags.health.hr.notify.repo.NotificationTriggerRepository;
import com.ags.health.hr.notify.web.NotifyDtos.DispatchResponse;
import com.ags.health.hr.notify.web.NotifyDtos.IntakeResult;
import com.ags.health.hr.notify.web.NotifyDtos.NotificationEvent;
import com.ags.health.hr.notify.web.NotifyDtos.PageResponse;
import com.ags.health.hr.notify.web.NotifyDtos.SendRequest;
import com.ags.health.hr.platform.audit.AuditCategory;
import com.ags.health.hr.platform.audit.AuditEvent;
import com.ags.health.hr.platform.audit.AuditLogger;
import com.ags.health.hr.platform.security.CurrentUser;
import com.ags.health.hr.platform.security.CurrentUserProvider;
import com.ags.health.hr.platform.web.ApiException;
import com.ags.health.hr.platform.web.CorrelationIdFilter;
import jakarta.persistence.criteria.Predicate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.Duration;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;
import java.util.regex.Pattern;

/**
 * Automated trigger engine (tracker #19) + candidate communication audit (tracker #20).
 * Intake renders and records one dispatch row per recipient in the same transaction (idempotent on eventId),
 * then {@link DispatchWorker} sends after commit and retries failures.
 */
@Service
@Transactional
public class DispatchService {

    private static final Logger log = LoggerFactory.getLogger(DispatchService.class);
    private static final Pattern EMAIL = Pattern.compile("^[^\\s@]+@[^\\s@]+\\.[^\\s@]+$");
    static final Duration LEASE = Duration.ofMinutes(5);

    private final NotificationTriggerRepository triggers;
    private final NotificationTemplateRepository templates;
    private final NotificationDispatchRepository dispatches;
    private final TemplateRenderer renderer;
    private final ConditionEvaluator conditions;
    private final NotificationProperties props;
    private final ApplicationEventPublisher events;
    private final JdbcTemplate jdbc;
    private final AuditLogger audit;

    public DispatchService(NotificationTriggerRepository triggers, NotificationTemplateRepository templates,
                           NotificationDispatchRepository dispatches, TemplateRenderer renderer,
                           ConditionEvaluator conditions, NotificationProperties props,
                           ApplicationEventPublisher events, JdbcTemplate jdbc, AuditLogger audit) {
        this.triggers = triggers;
        this.templates = templates;
        this.dispatches = dispatches;
        this.renderer = renderer;
        this.conditions = conditions;
        this.props = props;
        this.events = events;
        this.jdbc = jdbc;
        this.audit = audit;
    }

    /** Published after the intake transaction commits; consumed by {@link DispatchWorker}. */
    public record DispatchesCreated(List<UUID> ids) {
    }

    // ------------------------------------------------------------------ intake
    public IntakeResult intake(NotificationEvent e) {
        Map<String, Object> data = e.data() == null ? new LinkedHashMap<>() : new LinkedHashMap<>(e.data());
        Map<String, Object> eventMap = eventMap(e);
        List<String> matched = new ArrayList<>();
        List<UUID> created = new ArrayList<>();
        for (NotificationTrigger t : triggers.findByEventTypeAndActiveTrue(e.eventType())) {
            if (!matches(t, e, data, eventMap)) {
                continue;
            }
            matched.add(t.getCode());
            Optional<NotificationTemplate> template = templates.findByCodeAndActiveTrue(t.getTemplateCode());
            if (template.isEmpty()) {
                log.warn("Trigger {} references missing/inactive template {}", t.getCode(), t.getTemplateCode());
                continue;
            }
            Set<String> to = recipients(t.getRecipients(), data, e.actor());
            List<String> cc = new ArrayList<>(recipients(t.getCc(), data, e.actor()));
            if (to.isEmpty()) {
                if (dispatches.existsByEventIdAndTemplateCodeAndRecipient(e.eventId(), template.get().getCode(), "-")) {
                    continue; // replayed event: the SKIPPED row already exists (unique event/template/recipient)
                }
                created.add(record(e.eventId(), t.getCode(), template.get(), "-", cc, null, e, data,
                        NotificationDispatch.Status.SKIPPED, "No recipient email found in event data for " + t.getRecipients()));
                continue;
            }
            for (String recipient : to) {
                if (dispatches.existsByEventIdAndTemplateCodeAndRecipient(e.eventId(), template.get().getCode(), recipient)) {
                    continue; // duplicate delivery of the same event
                }
                created.add(record(e.eventId(), t.getCode(), template.get(), recipient, cc, null, e, data, null, null));
            }
        }
        publish(created);
        return new IntakeResult(e.eventId(), matched, created);
    }

    /** Ad-hoc templated email from a screen (e.g. "Send walk-in email" on Map Candidate). */
    public IntakeResult send(SendRequest req) {
        NotificationTemplate template = templates.findByCodeAndActiveTrue(req.templateCode())
                .orElseThrow(() -> ApiException.notFound("Template", req.templateCode()));
        String eventId = "adhoc-" + UUID.randomUUID();
        NotificationEvent e = new NotificationEvent(eventId, "MANUAL", null, null, null, null, null, req.entityType(),
                req.entityId(), req.candidateId(), null, null, Instant.now().toString(), req.data());
        Map<String, Object> data = req.data() == null ? new LinkedHashMap<>() : new LinkedHashMap<>(req.data());
        List<UUID> created = new ArrayList<>();
        for (String to : new LinkedHashSet<>(req.to())) {
            created.add(record(eventId, null, template, to.trim().toLowerCase(), req.cc() == null ? List.of() : req.cc(),
                    requester(), e, data, null, null));
        }
        publish(created);
        return new IntakeResult(eventId, List.of(), created);
    }

    // ------------------------------------------------------------------ worker support
    @Transactional(readOnly = true)
    public Optional<NotificationDispatch> load(UUID id) {
        return dispatches.findById(id);
    }

    /** Multi-instance safe claim of due retries (FOR UPDATE SKIP LOCKED + lease). */
    public List<UUID> claimDue(int limit) {
        return jdbc.queryForList("""
                UPDATE dh_notify.notification_dispatch
                   SET status = 'SENDING', next_attempt_at = now() + interval '5 minutes'
                 WHERE id IN (SELECT id FROM dh_notify.notification_dispatch
                               WHERE status IN ('PENDING', 'FAILED', 'SENDING')
                                 AND attempts < ? AND next_attempt_at <= now()
                               ORDER BY next_attempt_at
                               LIMIT ? FOR UPDATE SKIP LOCKED)
                RETURNING id
                """, UUID.class, props.maxAttempts(), limit);
    }

    public void markResult(UUID id, boolean ok, String error) {
        NotificationDispatch d = dispatches.findById(id).orElse(null);
        if (d == null) {
            return;
        }
        d.setAttempts(d.getAttempts() + 1);
        if (ok) {
            d.setStatus(NotificationDispatch.Status.SENT);
            d.setSentAt(Instant.now());
            d.setLastError(null);
            d.setNextAttemptAt(null);
            if (!props.storeRenderedBody()) {
                d.setBody(null);
            }
        } else {
            d.setStatus(NotificationDispatch.Status.FAILED);
            d.setLastError(truncate(error, 2000));
            long backoffMinutes = Math.min(60, 1L << Math.min(d.getAttempts(), 6));
            d.setNextAttemptAt(Instant.now().plus(Duration.ofMinutes(backoffMinutes)));
        }
        audit.log(AuditEvent.builder(AuditCategory.NOTIFICATION, ok ? "EMAIL_SENT" : "EMAIL_FAILED")
                .entity(d.getEntityType(), d.getEntityId())
                .candidate(d.getCandidateId())
                .outcome(ok ? AuditEvent.Outcome.SUCCESS : AuditEvent.Outcome.FAILURE)
                .description(d.getSubject())
                .detail("dispatchId", d.getId().toString())
                .detail("template", d.getTemplateCode() + " v" + d.getTemplateVersion())
                .detail("trigger", d.getTriggerCode())
                .detail("recipient", d.getRecipient())
                .detail("attempt", d.getAttempts())
                .detail("error", ok ? null : truncate(error, 500))
                .build());
    }

    /** Manual retry from the dispatch log (e.g. after fixing a template or the SMTP relay). */
    public DispatchResponse retry(UUID id) {
        NotificationDispatch d = dispatches.findById(id).orElseThrow(() -> ApiException.notFound("Dispatch", id));
        if (d.getStatus() == NotificationDispatch.Status.SENT || d.getStatus() == NotificationDispatch.Status.SKIPPED) {
            throw ApiException.conflict("NOT_RETRYABLE", "Dispatch is " + d.getStatus());
        }
        if (d.getBody() == null) {
            throw ApiException.conflict("NOT_RETRYABLE", "Rendering failed - fix the template and send again");
        }
        d.setStatus(NotificationDispatch.Status.SENDING);
        d.setAttempts(0);
        d.setNextAttemptAt(Instant.now().plus(LEASE));
        publish(List.of(d.getId()));
        return DispatchResponse.of(d, false);
    }

    // ------------------------------------------------------------------ queries
    @Transactional(readOnly = true)
    public PageResponse<DispatchResponse> search(String candidateId, String entityType, String entityId,
                                                 NotificationDispatch.Status status, String templateCode,
                                                 Instant from, Instant to, Pageable pageable) {
        Specification<NotificationDispatch> spec = (root, q, cb) -> {
            List<Predicate> p = new ArrayList<>();
            if (candidateId != null) p.add(cb.equal(root.get("candidateId"), candidateId));
            if (entityType != null) p.add(cb.equal(root.get("entityType"), entityType));
            if (entityId != null) p.add(cb.equal(root.get("entityId"), entityId));
            if (status != null) p.add(cb.equal(root.get("status"), status));
            if (templateCode != null) p.add(cb.equal(root.get("templateCode"), templateCode));
            if (from != null) p.add(cb.greaterThanOrEqualTo(root.get("createdAt"), from));
            if (to != null) p.add(cb.lessThan(root.get("createdAt"), to));
            return cb.and(p.toArray(Predicate[]::new));
        };
        Page<NotificationDispatch> page = dispatches.findAll(spec, pageable);
        return new PageResponse<>(page.getContent().stream().map(d -> DispatchResponse.of(d, false)).toList(),
                page.getNumber(), page.getSize(), page.getTotalElements(), page.getTotalPages());
    }

    @Transactional(readOnly = true)
    public DispatchResponse get(UUID id) {
        return DispatchResponse.of(dispatches.findById(id).orElseThrow(() -> ApiException.notFound("Dispatch", id)), true);
    }

    // ------------------------------------------------------------------ internals
    private boolean matches(NotificationTrigger t, NotificationEvent e, Map<String, Object> data, Map<String, Object> eventMap) {
        if (t.getWorkflowCode() != null && !t.getWorkflowCode().equals(e.workflowCode())) return false;
        if (t.getTransitionCode() != null && !t.getTransitionCode().equals(e.transitionCode())) return false;
        if (t.getToState() != null && !t.getToState().equals(e.toState())) return false;
        try {
            return conditions.matches(t.getConditionExpr(), data, eventMap);
        } catch (RuntimeException ex) {
            log.warn("Condition of trigger {} failed: {}", t.getCode(), ex.getMessage());
            return false;
        }
    }

    private UUID record(String eventId, String triggerCode, NotificationTemplate template, String recipient,
                        List<String> cc, String requestedBy, NotificationEvent e, Map<String, Object> data,
                        NotificationDispatch.Status forcedStatus, String forcedError) {
        NotificationDispatch d = new NotificationDispatch();
        d.setEventId(eventId);
        d.setTriggerCode(triggerCode);
        d.setTemplateCode(template.getCode());
        d.setTemplateVersion(template.getVersionNo());
        d.setRecipient(recipient);
        d.setCc(cc == null || cc.isEmpty() ? null : String.join(",", cc));
        d.setEntityType(e.entityType());
        d.setEntityId(e.entityId());
        d.setCandidateId(e.candidateId() != null ? e.candidateId() : str(data.get("candidateId")));
        d.setCorrelationId(MDC.get(CorrelationIdFilter.MDC_KEY));
        d.setRequestedBy(requestedBy != null ? requestedBy : actorName(e.actor()));
        if (forcedStatus != null) {
            d.setStatus(forcedStatus);
            d.setLastError(forcedError);
            dispatches.save(d);
            return d.getId();
        }
        try {
            TemplateRenderer.Rendered r = renderer.render(template.getCode() + ":" + template.getVersionNo(),
                    template.getSubject(), template.getBody(), model(data, e));
            d.setSubject(truncate(r.subject(), 500));
            d.setBody(r.body());
            d.setStatus(NotificationDispatch.Status.SENDING);
            d.setNextAttemptAt(Instant.now().plus(LEASE));
        } catch (TemplateRenderer.TemplateRenderException ex) {
            d.setStatus(NotificationDispatch.Status.FAILED);
            d.setAttempts(props.maxAttempts()); // template errors are not retried automatically
            d.setLastError("Template error: " + truncate(ex.getMessage(), 1900));
        }
        dispatches.save(d);
        return d.getId();
    }

    private void publish(List<UUID> ids) {
        List<UUID> toSend = ids.stream()
                .filter(id -> dispatches.findById(id).map(d -> d.getStatus() == NotificationDispatch.Status.SENDING).orElse(false))
                .toList();
        if (!toSend.isEmpty()) {
            events.publishEvent(new DispatchesCreated(toSend));
        }
    }

    private Map<String, Object> model(Map<String, Object> data, NotificationEvent e) {
        Map<String, Object> m = new LinkedHashMap<>(data);
        m.putIfAbsent("companyName", props.companyName());
        if (e.remarks() != null) {
            m.putIfAbsent("remarks", e.remarks());
        }
        m.put("event", eventMap(e));
        return m;
    }

    private static Map<String, Object> eventMap(NotificationEvent e) {
        Map<String, Object> m = new LinkedHashMap<>();
        put(m, "eventType", e.eventType());
        put(m, "workflowCode", e.workflowCode());
        put(m, "transitionCode", e.transitionCode());
        put(m, "fromState", e.fromState());
        put(m, "toState", e.toState());
        put(m, "entityType", e.entityType());
        put(m, "entityId", e.entityId());
        put(m, "occurredAt", e.occurredAt());
        return m;
    }

    private static void put(Map<String, Object> m, String k, Object v) {
        if (v != null) {
            m.put(k, v);
        }
    }

    /** CANDIDATE, RECRUITER, REFERRER, ACTOR, CUSTOM:someone@agshealth.com (comma separated). */
    static Set<String> recipients(String spec, Map<String, Object> data, Map<String, Object> actor) {
        Set<String> result = new LinkedHashSet<>();
        if (spec == null || spec.isBlank()) {
            return result;
        }
        for (String raw : Arrays.stream(spec.split(",")).map(String::trim).filter(s -> !s.isEmpty()).toList()) {
            String email = switch (raw.toUpperCase()) {
                case "CANDIDATE" -> str(data.getOrDefault("candidateEmail", data.get("email")));
                case "RECRUITER" -> str(data.get("recruiterEmail"));
                case "REFERRER" -> str(data.get("referrerEmail"));
                case "ACTOR" -> actor == null ? null : str(actor.get("email"));
                default -> raw.toUpperCase().startsWith("CUSTOM:") ? raw.substring("CUSTOM:".length()).trim() : null;
            };
            if (email != null && EMAIL.matcher(email).matches()) {
                result.add(email.toLowerCase());
            }
        }
        return result;
    }

    private static String requester() {
        CurrentUser u = CurrentUserProvider.currentOrSystem();
        return u.email() != null ? u.email() : u.name();
    }

    private static String actorName(Map<String, Object> actor) {
        if (actor == null) {
            return "system";
        }
        Object name = actor.get("name");
        return name == null ? "system" : name.toString();
    }

    private static String str(Object o) {
        return o == null || o.toString().isBlank() ? null : o.toString().trim();
    }

    private static String truncate(String s, int max) {
        return s == null || s.length() <= max ? s : s.substring(0, max);
    }
}
