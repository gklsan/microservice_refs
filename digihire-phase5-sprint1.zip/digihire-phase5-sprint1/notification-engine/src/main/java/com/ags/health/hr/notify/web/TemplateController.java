package com.ags.health.hr.notify.web;

import com.ags.health.hr.notify.service.TemplateService;
import com.ags.health.hr.notify.service.TokenCatalogue;
import com.ags.health.hr.notify.web.NotifyDtos.PreviewRequest;
import com.ags.health.hr.notify.web.NotifyDtos.PreviewResponse;
import com.ags.health.hr.notify.web.NotifyDtos.TemplateRequest;
import com.ags.health.hr.notify.web.NotifyDtos.TemplateResponse;
import com.ags.health.hr.notify.web.NotifyDtos.TemplateVersionSummary;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.Map;

/** Standard email templates: Walk-In, On Hold, Rejection, Interview (+ any new one), versioned. */
@RestController
@RequestMapping("/templates")
@Tag(name = "Email templates")
public class TemplateController {

    private final TemplateService service;

    public TemplateController(TemplateService service) {
        this.service = service;
    }

    @GetMapping
    @PreAuthorize("hasAuthority('NOTIFICATION_TEMPLATE:VIEW')")
    public List<TemplateResponse> list() {
        return service.listActive();
    }

    @GetMapping("/tokens")
    @Operation(summary = "Personalization tokens available in templates, with examples")
    public List<TokenCatalogue.Token> tokens() {
        return TokenCatalogue.TOKENS;
    }

    @GetMapping("/{code}")
    @PreAuthorize("hasAuthority('NOTIFICATION_TEMPLATE:VIEW')")
    public TemplateResponse get(@PathVariable String code) {
        return service.active(code);
    }

    @GetMapping("/{code}/versions")
    @PreAuthorize("hasAuthority('NOTIFICATION_TEMPLATE:VIEW')")
    public List<TemplateVersionSummary> versions(@PathVariable String code) {
        return service.versions(code);
    }

    @GetMapping("/{code}/versions/{versionNo}")
    @PreAuthorize("hasAuthority('NOTIFICATION_TEMPLATE:VIEW')")
    public TemplateResponse version(@PathVariable String code, @PathVariable int versionNo) {
        return service.version(code, versionNo);
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    @PreAuthorize("hasAuthority('NOTIFICATION_TEMPLATE:MANAGE')")
    public TemplateResponse create(@Valid @RequestBody TemplateRequest req) {
        return service.create(req);
    }

    @PutMapping("/{code}")
    @PreAuthorize("hasAuthority('NOTIFICATION_TEMPLATE:MANAGE')")
    @Operation(summary = "Save as a new version and activate it (validated by rendering with sample tokens)")
    public TemplateResponse update(@PathVariable String code, @Valid @RequestBody TemplateRequest req) {
        return service.update(code, req);
    }

    @PostMapping("/{code}/versions/{versionNo}/activate")
    @PreAuthorize("hasAuthority('NOTIFICATION_TEMPLATE:MANAGE')")
    public TemplateResponse activate(@PathVariable String code, @PathVariable int versionNo) {
        return service.activate(code, versionNo);
    }

    @PostMapping("/preview")
    @PreAuthorize("hasAuthority('NOTIFICATION_TEMPLATE:VIEW')")
    @Operation(summary = "Render an unsaved subject/body with sample tokens (+ optional data overrides)")
    public PreviewResponse preview(@RequestBody PreviewRequest req) {
        return service.preview(req.subject(), req.body(), req.data());
    }

    @PostMapping("/{code}/preview")
    @PreAuthorize("hasAuthority('NOTIFICATION_TEMPLATE:VIEW')")
    public PreviewResponse previewStored(@PathVariable String code, @RequestBody(required = false) Map<String, Object> data) {
        return service.previewStored(code, data);
    }
}
