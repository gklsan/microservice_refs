package com.ags.health.hr.notify.repo;

import com.ags.health.hr.notify.domain.NotificationTemplate;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

public interface NotificationTemplateRepository extends JpaRepository<NotificationTemplate, UUID> {

    Optional<NotificationTemplate> findByCodeAndActiveTrue(String code);

    Optional<NotificationTemplate> findByCodeAndVersionNo(String code, int versionNo);

    List<NotificationTemplate> findByActiveTrueOrderByCodeAsc();

    List<NotificationTemplate> findByCodeOrderByVersionNoDesc(String code);

    boolean existsByCode(String code);

    @Query("select coalesce(max(t.versionNo), 0) from NotificationTemplate t where t.code = :code")
    int maxVersion(@Param("code") String code);
}
