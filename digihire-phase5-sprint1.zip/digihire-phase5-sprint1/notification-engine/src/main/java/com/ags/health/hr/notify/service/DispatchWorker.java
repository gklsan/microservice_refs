package com.ags.health.hr.notify.service;

import com.ags.health.hr.notify.NotificationProperties;
import com.ags.health.hr.notify.domain.NotificationDispatch;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import org.springframework.transaction.event.TransactionPhase;
import org.springframework.transaction.event.TransactionalEventListener;

import java.util.Arrays;
import java.util.List;
import java.util.UUID;

/** Sends dispatches outside any DB transaction (SMTP latency never holds locks) and retries failures. */
@Component
public class DispatchWorker {

    private static final Logger log = LoggerFactory.getLogger(DispatchWorker.class);

    private final DispatchService service;
    private final MailDelivery delivery;
    private final NotificationProperties props;

    public DispatchWorker(DispatchService service, MailDelivery delivery, NotificationProperties props) {
        this.service = service;
        this.delivery = delivery;
        this.props = props;
    }

    @Async
    @TransactionalEventListener(phase = TransactionPhase.AFTER_COMMIT)
    public void onCreated(DispatchService.DispatchesCreated event) {
        event.ids().forEach(this::deliver);
    }

    @Scheduled(cron = "${digihire.notification.retry-cron:0 */2 * * * *}")
    public void retryDue() {
        List<UUID> due = service.claimDue(50);
        if (!due.isEmpty()) {
            log.info("Retrying {} notification dispatches", due.size());
            due.forEach(this::deliver);
        }
    }

    void deliver(UUID id) {
        NotificationDispatch d = service.load(id).orElse(null);
        if (d == null || d.getStatus() != NotificationDispatch.Status.SENDING || d.getBody() == null) {
            return;
        }
        String to = d.getRecipient();
        String subject = d.getSubject();
        List<String> cc = d.getCc() == null ? List.of() : Arrays.asList(d.getCc().split(","));
        if (props.hasOverride()) { // UAT safety net: never mail real candidates
            subject = "[to: " + to + "] " + subject;
            to = props.overrideRecipient();
            cc = List.of();
        }
        try {
            delivery.send(to, cc, subject, d.getBody());
            service.markResult(id, true, null);
        } catch (Exception e) {
            log.warn("Dispatch {} failed: {}", id, e.getMessage());
            service.markResult(id, false, e.getClass().getSimpleName() + ": " + e.getMessage());
        }
    }
}
