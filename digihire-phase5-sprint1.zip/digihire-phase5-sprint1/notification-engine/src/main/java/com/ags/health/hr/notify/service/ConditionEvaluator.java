package com.ags.health.hr.notify.service;

import org.springframework.context.expression.MapAccessor;
import org.springframework.expression.ExpressionParser;
import org.springframework.expression.spel.standard.SpelExpressionParser;
import org.springframework.expression.spel.support.DataBindingPropertyAccessor;
import org.springframework.expression.spel.support.SimpleEvaluationContext;
import org.springframework.stereotype.Component;

import java.util.Map;

/**
 * Optional trigger condition, sandboxed SpEL over {@code #data} and {@code #event}, e.g.
 * {@code #data['interviewMode'] == 'ONLINE'} or {@code #event['workflowCode'] == 'LATERAL_HIRING'}.
 */
@Component
public class ConditionEvaluator {

    private final ExpressionParser parser = new SpelExpressionParser();

    public void validate(String expression) {
        parser.parseExpression(expression);
    }

    public boolean matches(String expression, Map<String, Object> data, Map<String, Object> event) {
        if (expression == null || expression.isBlank()) {
            return true;
        }
        SimpleEvaluationContext ctx = SimpleEvaluationContext
                .forPropertyAccessors(new MapAccessor(), DataBindingPropertyAccessor.forReadOnlyAccess())
                .withInstanceMethods().build();
        ctx.setVariable("data", data);
        ctx.setVariable("event", event);
        return Boolean.TRUE.equals(parser.parseExpression(expression).getValue(ctx, Boolean.class));
    }
}
