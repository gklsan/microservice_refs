package com.ags.health.hr.notify.domain;

import com.ags.health.hr.platform.jpa.AuditableEntity;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.UUID;

/** One version of an email template. Editing creates a new version; exactly one version is active. */
@Entity
@Table(name = "notification_template")
@Getter
@Setter
@NoArgsConstructor
public class NotificationTemplate extends AuditableEntity {

    @Id
    private UUID id;

    @Column(nullable = false, updatable = false)
    private String code;

    @Column(name = "version_no", nullable = false, updatable = false)
    private int versionNo;

    @Column(nullable = false)
    private String channel = "EMAIL";

    @Column(nullable = false)
    private String name;

    @Column(nullable = false)
    private String category = "CANDIDATE";

    @Column(nullable = false)
    private String subject;

    @Column(nullable = false)
    private String body;

    private String description;

    @Column(nullable = false)
    private boolean active;
}
