package com.ags.health.hr.notify.service;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Personalization tokens available to templates (tracker #20). Producers (workflow context / ad-hoc send)
 * supply these keys in {@code data}; templates use {@code ${candidateName!"Candidate"}} style defaults.
 * {@code companyName} is always injected. The examples are used for previews and template validation.
 */
public final class TokenCatalogue {

    private TokenCatalogue() {
    }

    public record Token(String key, String description, String example) {
    }

    public static final List<Token> TOKENS = List.of(
            new Token("candidateName", "Candidate full name (as per Aadhaar)", "James Wan"),
            new Token("candidateFirstName", "Candidate first name", "James"),
            new Token("candidateEmail", "Candidate email (recipient CANDIDATE)", "james.wan@example.com"),
            new Token("candidateMobile", "Candidate mobile", "9876543210"),
            new Token("jobTitle", "Job / requisition title", "Medical Coding - Fresher"),
            new Token("jobCode", "Oracle requisition number", "REQ-1082"),
            new Token("lob", "Line of business", "MEDICAL_CODING"),
            new Token("location", "Job location", "Chennai"),
            new Token("interviewRound", "Interview round name", "HR round"),
            new Token("interviewDate", "Interview / walk-in date", "20/10/2026"),
            new Token("interviewTime", "Interview time", "09:30 AM"),
            new Token("interviewMode", "ONLINE or WALK_IN", "ONLINE"),
            new Token("interviewLink", "Teams / online meeting link", "https://teams.microsoft.com/l/meetup-join/example"),
            new Token("venueAddress", "Walk-in / in-office venue", "AGS Health, Chennai One SEZ, Thoraipakkam, Chennai"),
            new Token("recruiterName", "Recruiter name (signature)", "Ajeeth Kumar"),
            new Token("recruiterEmail", "Recruiter email (recipient RECRUITER)", "ajeeth.kumar@agshealth.com"),
            new Token("recruiterPhone", "Recruiter phone", "044-40000000"),
            new Token("referrerEmail", "Referring employee email (recipient REFERRER)", "referrer@agshealth.com"),
            new Token("reasonCode", "Standard reason code (rejection / hold)", "NO_POSITIONS"),
            new Token("reasonLabel", "Standard reason text", "No positions available"),
            new Token("coolingPeriodEndDate", "Date the candidate may re-apply", "05/11/2026"),
            new Token("remarks", "Recruiter remarks", "We will reach out when a matching role opens."),
            new Token("companyName", "Company name (always present)", "AGS Health"));

    public static Map<String, Object> sampleData() {
        Map<String, Object> m = new LinkedHashMap<>();
        TOKENS.forEach(t -> m.put(t.key(), t.example()));
        return m;
    }
}
