package com.ags.health.hr.notify.service;

import com.ags.health.hr.notify.NotificationProperties;
import com.ags.health.hr.notify.domain.NotificationTemplate;
import com.ags.health.hr.notify.repo.NotificationTemplateRepository;
import com.ags.health.hr.notify.web.NotifyDtos.PreviewResponse;
import com.ags.health.hr.notify.web.NotifyDtos.TemplateRequest;
import com.ags.health.hr.notify.web.NotifyDtos.TemplateResponse;
import com.ags.health.hr.notify.web.NotifyDtos.TemplateVersionSummary;
import com.ags.health.hr.platform.audit.AuditCategory;
import com.ags.health.hr.platform.audit.AuditEvent;
import com.ags.health.hr.platform.audit.AuditLogger;
import com.ags.health.hr.platform.web.ApiException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * Standard template management (tracker #15-18, #21). Every save creates a new version (the previous one stays
 * for audit - dispatches record the exact version used). Templates are validated by rendering them with the
 * token catalogue sample data before they are saved.
 */
@Service
@Transactional
public class TemplateService {

    private final NotificationTemplateRepository repo;
    private final TemplateRenderer renderer;
    private final NotificationProperties props;
    private final AuditLogger audit;

    public TemplateService(NotificationTemplateRepository repo, TemplateRenderer renderer,
                           NotificationProperties props, AuditLogger audit) {
        this.repo = repo;
        this.renderer = renderer;
        this.props = props;
        this.audit = audit;
    }

    @Transactional(readOnly = true)
    public List<TemplateResponse> listActive() {
        return repo.findByActiveTrueOrderByCodeAsc().stream().map(TemplateResponse::of).toList();
    }

    @Transactional(readOnly = true)
    public TemplateResponse active(String code) {
        return TemplateResponse.of(repo.findByCodeAndActiveTrue(code).orElseThrow(() -> ApiException.notFound("Template", code)));
    }

    @Transactional(readOnly = true)
    public TemplateResponse version(String code, int versionNo) {
        return TemplateResponse.of(repo.findByCodeAndVersionNo(code, versionNo)
                .orElseThrow(() -> ApiException.notFound("Template version", code + " v" + versionNo)));
    }

    @Transactional(readOnly = true)
    public List<TemplateVersionSummary> versions(String code) {
        return repo.findByCodeOrderByVersionNoDesc(code).stream()
                .map(t -> new TemplateVersionSummary(t.getVersionNo(), t.isActive(), t.getName(), t.getCreatedAt(),
                        t.getCreatedBy()))
                .toList();
    }

    public TemplateResponse create(TemplateRequest req) {
        if (repo.existsByCode(req.code())) {
            throw ApiException.conflict("TEMPLATE_EXISTS", "Template already exists: " + req.code());
        }
        validate(req.subject(), req.body());
        NotificationTemplate t = newVersion(req, 1);
        repo.save(t);
        log("TEMPLATE_CREATED", t);
        return TemplateResponse.of(t);
    }

    /** Saves a new version and makes it active. */
    public TemplateResponse update(String code, TemplateRequest req) {
        if (!code.equals(req.code())) {
            throw ApiException.badRequest("CODE_MISMATCH", "Template code cannot be changed");
        }
        validate(req.subject(), req.body());
        repo.findByCodeAndActiveTrue(code).ifPresent(old -> {
            old.setActive(false);
            repo.saveAndFlush(old); // free the "one active per code" unique index first
        });
        NotificationTemplate t = newVersion(req, repo.maxVersion(code) + 1);
        repo.save(t);
        log("TEMPLATE_UPDATED", t);
        return TemplateResponse.of(t);
    }

    /** Roll back / forward to another version. */
    public TemplateResponse activate(String code, int versionNo) {
        NotificationTemplate target = repo.findByCodeAndVersionNo(code, versionNo)
                .orElseThrow(() -> ApiException.notFound("Template version", code + " v" + versionNo));
        repo.findByCodeAndActiveTrue(code).ifPresent(old -> {
            old.setActive(false);
            repo.saveAndFlush(old);
        });
        target.setActive(true);
        log("TEMPLATE_VERSION_ACTIVATED", target);
        return TemplateResponse.of(target);
    }

    @Transactional(readOnly = true)
    public PreviewResponse preview(String subject, String body, Map<String, Object> data) {
        Map<String, Object> model = new LinkedHashMap<>(TokenCatalogue.sampleData());
        if (data != null) {
            model.putAll(data);
        }
        model.putIfAbsent("companyName", props.companyName());
        try {
            TemplateRenderer.Rendered r = renderer.renderAdHoc(subject, body, model);
            return new PreviewResponse(true, r.subject(), r.body(), null);
        } catch (TemplateRenderer.TemplateRenderException e) {
            return new PreviewResponse(false, null, null, e.getMessage());
        }
    }

    @Transactional(readOnly = true)
    public PreviewResponse previewStored(String code, Map<String, Object> data) {
        NotificationTemplate t = repo.findByCodeAndActiveTrue(code).orElseThrow(() -> ApiException.notFound("Template", code));
        return preview(t.getSubject(), t.getBody(), data);
    }

    private void validate(String subject, String body) {
        PreviewResponse p = preview(subject, body, Map.of());
        if (!p.ok()) {
            throw ApiException.badRequest("TEMPLATE_INVALID", "Template does not render with the standard tokens: " + p.error());
        }
    }

    private static NotificationTemplate newVersion(TemplateRequest req, int versionNo) {
        NotificationTemplate t = new NotificationTemplate();
        t.setId(UUID.randomUUID());
        t.setCode(req.code());
        t.setVersionNo(versionNo);
        t.setName(req.name());
        t.setCategory(req.category() == null ? "CANDIDATE" : req.category());
        t.setSubject(req.subject());
        t.setBody(req.body());
        t.setDescription(req.description());
        t.setActive(true);
        return t;
    }

    private void log(String action, NotificationTemplate t) {
        audit.log(AuditEvent.builder(AuditCategory.CONFIG_CHANGE, action)
                .entity("NOTIFICATION_TEMPLATE", t.getCode()).detail("version", t.getVersionNo())
                .detail("subject", t.getSubject()).build());
    }
}
