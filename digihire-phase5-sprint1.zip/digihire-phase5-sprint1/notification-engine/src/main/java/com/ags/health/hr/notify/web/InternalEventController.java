package com.ags.health.hr.notify.web;

import com.ags.health.hr.notify.service.DispatchService;
import com.ags.health.hr.notify.web.NotifyDtos.IntakeResult;
import com.ags.health.hr.notify.web.NotifyDtos.NotificationEvent;
import io.swagger.v3.oas.annotations.Hidden;
import jakarta.validation.Valid;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

/** Event intake for producers (workflow-services, and later candidate/job services). X-Internal-Key protected. */
@Hidden
@RestController
public class InternalEventController {

    private final DispatchService service;

    public InternalEventController(DispatchService service) {
        this.service = service;
    }

    @PostMapping("/internal/events")
    public IntakeResult intake(@Valid @RequestBody NotificationEvent event) {
        return service.intake(event);
    }
}
