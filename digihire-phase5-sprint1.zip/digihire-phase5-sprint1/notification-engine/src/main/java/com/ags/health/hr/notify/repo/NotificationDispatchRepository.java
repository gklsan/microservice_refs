package com.ags.health.hr.notify.repo;

import com.ags.health.hr.notify.domain.NotificationDispatch;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

import java.util.UUID;

public interface NotificationDispatchRepository extends JpaRepository<NotificationDispatch, UUID>,
        JpaSpecificationExecutor<NotificationDispatch> {

    boolean existsByEventIdAndTemplateCodeAndRecipient(String eventId, String templateCode, String recipient);
}
