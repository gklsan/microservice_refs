package com.ags.health.hr.notify.repo;

import com.ags.health.hr.notify.domain.NotificationTrigger;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

public interface NotificationTriggerRepository extends JpaRepository<NotificationTrigger, UUID> {

    List<NotificationTrigger> findByEventTypeAndActiveTrue(String eventType);

    Optional<NotificationTrigger> findByCode(String code);

    List<NotificationTrigger> findAllByOrderByCodeAsc();
}
