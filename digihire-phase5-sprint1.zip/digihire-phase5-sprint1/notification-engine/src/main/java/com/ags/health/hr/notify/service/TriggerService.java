package com.ags.health.hr.notify.service;

import com.ags.health.hr.notify.domain.NotificationTrigger;
import com.ags.health.hr.notify.repo.NotificationTemplateRepository;
import com.ags.health.hr.notify.repo.NotificationTriggerRepository;
import com.ags.health.hr.notify.web.NotifyDtos.TriggerRequest;
import com.ags.health.hr.notify.web.NotifyDtos.TriggerResponse;
import com.ags.health.hr.platform.audit.AuditCategory;
import com.ags.health.hr.platform.audit.AuditEvent;
import com.ags.health.hr.platform.audit.AuditLogger;
import com.ags.health.hr.platform.web.ApiException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.UUID;

/** CRUD of automated trigger rules (tracker #19). */
@Service
@Transactional
public class TriggerService {

    private final NotificationTriggerRepository repo;
    private final NotificationTemplateRepository templates;
    private final ConditionEvaluator conditions;
    private final AuditLogger audit;

    public TriggerService(NotificationTriggerRepository repo, NotificationTemplateRepository templates,
                          ConditionEvaluator conditions, AuditLogger audit) {
        this.repo = repo;
        this.templates = templates;
        this.conditions = conditions;
        this.audit = audit;
    }

    @Transactional(readOnly = true)
    public List<TriggerResponse> list() {
        return repo.findAllByOrderByCodeAsc().stream().map(TriggerResponse::of).toList();
    }

    public TriggerResponse create(TriggerRequest req) {
        if (repo.findByCode(req.code()).isPresent()) {
            throw ApiException.conflict("TRIGGER_EXISTS", "Trigger already exists: " + req.code());
        }
        NotificationTrigger t = new NotificationTrigger();
        t.setId(UUID.randomUUID());
        t.setCode(req.code());
        apply(t, req);
        repo.save(t);
        log("TRIGGER_CREATED", t);
        return TriggerResponse.of(t);
    }

    public TriggerResponse update(String code, TriggerRequest req) {
        NotificationTrigger t = repo.findByCode(code).orElseThrow(() -> ApiException.notFound("Trigger", code));
        apply(t, req);
        log("TRIGGER_UPDATED", t);
        return TriggerResponse.of(t);
    }

    public TriggerResponse setActive(String code, boolean active) {
        NotificationTrigger t = repo.findByCode(code).orElseThrow(() -> ApiException.notFound("Trigger", code));
        t.setActive(active);
        log(active ? "TRIGGER_ACTIVATED" : "TRIGGER_DEACTIVATED", t);
        return TriggerResponse.of(t);
    }

    private void apply(NotificationTrigger t, TriggerRequest req) {
        if (!templates.existsByCode(req.templateCode())) {
            throw ApiException.badRequest("UNKNOWN_TEMPLATE", "Unknown template: " + req.templateCode());
        }
        for (String r : req.recipients().split(",")) {
            String v = r.trim().toUpperCase();
            if (!(v.equals("CANDIDATE") || v.equals("RECRUITER") || v.equals("REFERRER") || v.equals("ACTOR")
                    || v.startsWith("CUSTOM:"))) {
                throw ApiException.badRequest("INVALID_RECIPIENT",
                        "Recipient must be CANDIDATE, RECRUITER, REFERRER, ACTOR or CUSTOM:email - got " + r);
            }
        }
        if (req.conditionExpr() != null && !req.conditionExpr().isBlank()) {
            try {
                conditions.validate(req.conditionExpr());
            } catch (RuntimeException e) {
                throw ApiException.badRequest("INVALID_CONDITION", e.getMessage());
            }
        }
        t.setName(req.name());
        t.setEventType(req.eventType() == null ? "WORKFLOW_TRANSITION" : req.eventType());
        t.setWorkflowCode(blank(req.workflowCode()));
        t.setTransitionCode(blank(req.transitionCode()));
        t.setToState(blank(req.toState()));
        t.setTemplateCode(req.templateCode());
        t.setRecipients(req.recipients());
        t.setCc(blank(req.cc()));
        t.setConditionExpr(blank(req.conditionExpr()));
        t.setActive(req.active() == null || req.active());
    }

    private void log(String action, NotificationTrigger t) {
        audit.log(AuditEvent.builder(AuditCategory.CONFIG_CHANGE, action).entity("NOTIFICATION_TRIGGER", t.getCode())
                .detail("template", t.getTemplateCode()).detail("transition", t.getTransitionCode())
                .detail("toState", t.getToState()).detail("recipients", t.getRecipients()).build());
    }

    private static String blank(String s) {
        return s == null || s.isBlank() ? null : s.trim();
    }
}
