package com.ags.health.hr.notify.web;

import com.ags.health.hr.notify.domain.NotificationDispatch;
import com.ags.health.hr.notify.domain.NotificationTemplate;
import com.ags.health.hr.notify.domain.NotificationTrigger;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;

import java.time.Instant;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/** Contracts of notification-engine. */
public final class NotifyDtos {

    private NotifyDtos() {
    }

    /** Event posted by workflow-services (or any producer) to /internal/events. */
    public record NotificationEvent(@NotBlank String eventId,
                                    @NotBlank String eventType,
                                    String workflowCode,
                                    Integer versionNo,
                                    String transitionCode,
                                    String fromState,
                                    String toState,
                                    String entityType,
                                    String entityId,
                                    String candidateId,
                                    Map<String, Object> actor,
                                    String remarks,
                                    String occurredAt,
                                    Map<String, Object> data) {
    }

    public record IntakeResult(String eventId, List<String> matchedTriggers, List<UUID> dispatchIds) {
    }

    public record SendRequest(@NotBlank String templateCode,
                              @NotEmpty List<@Email String> to,
                              List<@Email String> cc,
                              Map<String, Object> data,
                              String candidateId,
                              String entityType,
                              String entityId) {
    }

    public record TemplateRequest(@NotBlank @Pattern(regexp = "[A-Z][A-Z0-9_]{1,59}") String code,
                                  @NotBlank @Size(max = 150) String name,
                                  @Size(max = 60) String category,
                                  @NotBlank @Size(max = 500) String subject,
                                  @NotBlank String body,
                                  @Size(max = 500) String description) {
    }

    public record TemplateResponse(UUID id, String code, int versionNo, String channel, String name, String category,
                                   String subject, String body, String description, boolean active,
                                   Instant createdAt, String createdBy) {
        public static TemplateResponse of(NotificationTemplate t) {
            return new TemplateResponse(t.getId(), t.getCode(), t.getVersionNo(), t.getChannel(), t.getName(),
                    t.getCategory(), t.getSubject(), t.getBody(), t.getDescription(), t.isActive(), t.getCreatedAt(),
                    t.getCreatedBy());
        }
    }

    public record TemplateVersionSummary(int versionNo, boolean active, String name, Instant createdAt, String createdBy) {
    }

    public record PreviewRequest(String subject, String body, Map<String, Object> data) {
    }

    public record PreviewResponse(boolean ok, String subject, String html, String error) {
    }

    public record TriggerRequest(@NotBlank @Pattern(regexp = "[A-Z][A-Z0-9_]{1,59}") String code,
                                 @NotBlank @Size(max = 150) String name,
                                 @Size(max = 40) String eventType,
                                 @Size(max = 60) String workflowCode,
                                 @Size(max = 60) String transitionCode,
                                 @Size(max = 60) String toState,
                                 @NotBlank String templateCode,
                                 @NotBlank @Size(max = 500) String recipients,
                                 @Size(max = 500) String cc,
                                 @Size(max = 1000) String conditionExpr,
                                 Boolean active) {
    }

    public record TriggerResponse(UUID id, String code, String name, String eventType, String workflowCode,
                                  String transitionCode, String toState, String templateCode, String recipients,
                                  String cc, String conditionExpr, boolean active, Instant updatedAt, String updatedBy) {
        public static TriggerResponse of(NotificationTrigger t) {
            return new TriggerResponse(t.getId(), t.getCode(), t.getName(), t.getEventType(), t.getWorkflowCode(),
                    t.getTransitionCode(), t.getToState(), t.getTemplateCode(), t.getRecipients(), t.getCc(),
                    t.getConditionExpr(), t.isActive(),
                    t.getUpdatedAt() != null ? t.getUpdatedAt() : t.getCreatedAt(),
                    t.getUpdatedBy() != null ? t.getUpdatedBy() : t.getCreatedBy());
        }
    }

    public record DispatchResponse(UUID id, String eventId, String triggerCode, String templateCode,
                                   int templateVersion, String channel, String recipient, String cc, String subject,
                                   String body, NotificationDispatch.Status status, int attempts, String lastError,
                                   String entityType, String entityId, String candidateId, String requestedBy,
                                   Instant createdAt, Instant sentAt) {
        public static DispatchResponse of(NotificationDispatch d, boolean withBody) {
            return new DispatchResponse(d.getId(), d.getEventId(), d.getTriggerCode(), d.getTemplateCode(),
                    d.getTemplateVersion(), d.getChannel(), d.getRecipient(), d.getCc(), d.getSubject(),
                    withBody ? d.getBody() : null, d.getStatus(), d.getAttempts(), d.getLastError(), d.getEntityType(),
                    d.getEntityId(), d.getCandidateId(), d.getRequestedBy(), d.getCreatedAt(), d.getSentAt());
        }
    }

    public record PageResponse<T>(List<T> content, int page, int size, long totalElements, int totalPages) {
    }
}
