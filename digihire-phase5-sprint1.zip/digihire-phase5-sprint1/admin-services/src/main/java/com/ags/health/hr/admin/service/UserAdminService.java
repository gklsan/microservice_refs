package com.ags.health.hr.admin.service;

import com.ags.health.hr.admin.domain.AppUser;
import com.ags.health.hr.admin.domain.Role;
import com.ags.health.hr.admin.repo.AppUserRepository;
import com.ags.health.hr.admin.repo.PermissionRepository;
import com.ags.health.hr.admin.repo.RoleRepository;
import com.ags.health.hr.admin.web.AdminDtos.AssignRolesRequest;
import com.ags.health.hr.admin.web.AdminDtos.CreateUserRequest;
import com.ags.health.hr.admin.web.AdminDtos.PageResponse;
import com.ags.health.hr.admin.web.AdminDtos.PermissionGrantDto;
import com.ags.health.hr.admin.web.AdminDtos.UpdateUserRequest;
import com.ags.health.hr.admin.web.AdminDtos.UserResponse;
import com.ags.health.hr.platform.audit.AuditCategory;
import com.ags.health.hr.platform.audit.AuditEvent;
import com.ags.health.hr.platform.audit.AuditLogger;
import com.ags.health.hr.platform.security.AccessClient;
import com.ags.health.hr.platform.web.ApiException;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import java.util.Collection;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.UUID;
import java.util.stream.Collectors;

/** Admin user account management (tracker #22, #23, #24). */
@Service
@Transactional
public class UserAdminService {

    private static final String ADMIN = "ADMIN";

    private final AppUserRepository users;
    private final RoleRepository roles;
    private final PermissionRepository permissions;
    private final AuditLogger audit;
    private final AccessClient accessClient;

    public UserAdminService(AppUserRepository users, RoleRepository roles, PermissionRepository permissions,
                            AuditLogger audit, AccessClient accessClient) {
        this.users = users;
        this.roles = roles;
        this.permissions = permissions;
        this.audit = audit;
        this.accessClient = accessClient;
    }

    public UserResponse create(CreateUserRequest req) {
        String email = req.email().trim().toLowerCase();
        if (users.findByEmailIgnoreCase(email).isPresent()) {
            throw ApiException.conflict("USER_EXISTS", "A user with email " + email + " already exists");
        }
        AppUser u = AppUser.create(email, req.fullName().trim());
        u.setEmployeeCode(req.employeeCode());
        if (StringUtils.hasText(req.userType())) {
            u.setUserType(req.userType());
        }
        u.setRoles(resolveRoles(req.roles()));
        u.setManagerId(validManager(req.managerId(), u.getId()));
        u.setScopes(scopes(req.lobs(), req.locations()));
        users.save(u);
        log("ADMIN_USER_CREATED", u, "roles", req.roles());
        return UserResponse.of(u);
    }

    public UserResponse update(UUID id, UpdateUserRequest req) {
        AppUser u = get(id);
        u.setFullName(req.fullName().trim());
        u.setEmployeeCode(req.employeeCode());
        u.setManagerId(validManager(req.managerId(), u.getId()));
        u.setScopes(scopes(req.lobs(), req.locations()));
        log("ADMIN_USER_UPDATED", u, "scopes", u.getScopes().size());
        return UserResponse.of(u);
    }

    @Transactional(readOnly = true)
    public PageResponse<UserResponse> search(String search, AppUser.Status status, String roleCode, Pageable pageable) {
        String q = StringUtils.hasText(search) ? search.trim() : null;
        String role = StringUtils.hasText(roleCode) ? roleCode.trim() : null;
        return PageResponse.of(users.search(q, status, role, pageable).map(UserResponse::of));
    }

    @Transactional(readOnly = true)
    public UserResponse find(UUID id) {
        return UserResponse.of(get(id));
    }

    public UserResponse deactivate(UUID id, String remarks) {
        AppUser u = get(id);
        if (u.isActive() && u.hasRole(ADMIN) && users.countByRoleAndStatus(ADMIN, AppUser.Status.ACTIVE) <= 1) {
            throw ApiException.conflict("LAST_ADMIN", "Cannot deactivate the last active administrator");
        }
        u.setStatus(AppUser.Status.INACTIVE);
        audit.log(AuditEvent.builder(AuditCategory.SECURITY, "ADMIN_USER_DEACTIVATED")
                .entity("USER", u.getId()).detail("email", u.getEmail()).detail("remarks", remarks).build());
        accessClient.evict(String.valueOf(u.getSmartieUserId()), u.getEmail());
        return UserResponse.of(u);
    }

    public UserResponse reactivate(UUID id, String remarks) {
        AppUser u = get(id);
        u.setStatus(AppUser.Status.ACTIVE);
        audit.log(AuditEvent.builder(AuditCategory.SECURITY, "ADMIN_USER_REACTIVATED")
                .entity("USER", u.getId()).detail("email", u.getEmail()).detail("remarks", remarks).build());
        return UserResponse.of(u);
    }

    public UserResponse assignRoles(UUID id, AssignRolesRequest req) {
        AppUser u = get(id);
        Set<String> before = u.getRoles().stream().map(Role::getCode).collect(Collectors.toSet());
        if (before.contains(ADMIN) && !req.roles().contains(ADMIN) && u.isActive()
                && users.countByRoleAndStatus(ADMIN, AppUser.Status.ACTIVE) <= 1) {
            throw ApiException.conflict("LAST_ADMIN", "Cannot remove ADMIN role from the last active administrator");
        }
        u.setRoles(resolveRoles(req.roles()));
        audit.log(AuditEvent.builder(AuditCategory.CONFIG_CHANGE, "USER_ROLES_CHANGED")
                .entity("USER", u.getId()).detail("before", before).detail("after", req.roles()).build());
        return UserResponse.of(u);
    }

    /** Granular user-level ALLOW / DENY on top of the role permissions (tracker #24). */
    public UserResponse setPermissions(UUID id, List<PermissionGrantDto> grants) {
        AppUser u = get(id);
        Set<String> codes = grants.stream().map(PermissionGrantDto::permission).collect(Collectors.toCollection(HashSet::new));
        Set<String> known = permissions.findByCodeIn(codes).stream().map(p -> p.getCode()).collect(Collectors.toSet());
        codes.removeAll(known);
        if (!codes.isEmpty()) {
            throw ApiException.badRequest("UNKNOWN_PERMISSION", "Unknown permission(s): " + codes);
        }
        u.setPermissionGrants(grants.stream()
                .map(g -> new AppUser.PermissionGrant(g.permission(), g.effect()))
                .collect(Collectors.toCollection(HashSet::new)));
        audit.log(AuditEvent.builder(AuditCategory.CONFIG_CHANGE, "USER_PERMISSIONS_CHANGED")
                .entity("USER", u.getId()).detail("grants", grants).build());
        return UserResponse.of(u);
    }

    @Transactional(readOnly = true)
    public List<UserResponse> byRole(String roleCode) {
        return users.findByRoleAndStatus(roleCode, AppUser.Status.ACTIVE).stream().map(UserResponse::of).toList();
    }

    /** Idempotent creation of bootstrap administrators (first deployment). */
    public void ensureAdmin(String email) {
        String normalized = email.trim().toLowerCase();
        AppUser u = users.findByEmailIgnoreCase(normalized).orElseGet(() -> {
            AppUser created = AppUser.create(normalized, normalized);
            created.setUserType("EMPLOYEE_HR_ADMIN");
            return created;
        });
        if (!u.hasRole(ADMIN)) {
            Set<Role> r = new HashSet<>(u.getRoles());
            r.addAll(resolveRoles(Set.of(ADMIN)));
            u.setRoles(r);
            u.setStatus(AppUser.Status.ACTIVE);
            users.save(u);
            log("BOOTSTRAP_ADMIN_ENSURED", u, "email", normalized);
        }
    }

    private AppUser get(UUID id) {
        return users.findById(id).orElseThrow(() -> ApiException.notFound("User", id));
    }

    private Set<Role> resolveRoles(Collection<String> codes) {
        List<Role> found = roles.findByCodeIn(codes);
        if (found.size() != new HashSet<>(codes).size()) {
            Set<String> foundCodes = found.stream().map(Role::getCode).collect(Collectors.toSet());
            throw ApiException.badRequest("UNKNOWN_ROLE", "Unknown role(s): "
                    + codes.stream().filter(c -> !foundCodes.contains(c)).toList());
        }
        return new HashSet<>(found);
    }

    private UUID validManager(UUID managerId, UUID self) {
        if (managerId == null) {
            return null;
        }
        if (managerId.equals(self)) {
            throw ApiException.badRequest("INVALID_MANAGER", "A user cannot report to himself");
        }
        if (!users.existsById(managerId)) {
            throw ApiException.badRequest("INVALID_MANAGER", "Manager not found: " + managerId);
        }
        if (users.findManagerChainIds(managerId).contains(self.toString())) {
            throw ApiException.badRequest("INVALID_MANAGER", "Reporting line would create a cycle");
        }
        return managerId;
    }

    private static Set<AppUser.ScopeValue> scopes(Set<String> lobs, Set<String> locations) {
        Set<AppUser.ScopeValue> result = new HashSet<>();
        if (lobs != null) {
            lobs.forEach(l -> result.add(new AppUser.ScopeValue(AppUser.Dimension.LOB, l)));
        }
        if (locations != null) {
            locations.forEach(l -> result.add(new AppUser.ScopeValue(AppUser.Dimension.LOCATION, l)));
        }
        return result;
    }

    private void log(String action, AppUser u, String key, Object value) {
        audit.log(AuditEvent.builder(AuditCategory.CONFIG_CHANGE, action)
                .entity("USER", u.getId()).detail("email", u.getEmail()).detail(key, value).build());
    }
}
