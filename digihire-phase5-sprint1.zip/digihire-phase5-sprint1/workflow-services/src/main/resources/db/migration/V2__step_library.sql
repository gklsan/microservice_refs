-- Step library: reusable hiring-step templates HR picks from when building a workflow
-- (Walk-in, Online assessment, Versant, Interview round, Approval, Document check, LOI, Offer, Joining ...).
-- New step kinds are added as data (API / JSON), never as code.
CREATE TABLE IF NOT EXISTS dh_workflow.step_template (
    code             VARCHAR(60)   PRIMARY KEY,
    name             VARCHAR(150)  NOT NULL,
    step_type        VARCHAR(40)   NOT NULL,          -- INTERVIEW | ASSESSMENT | APPROVAL | DOCUMENT | OFFER | TASK ...
    description      VARCHAR(1000),
    definition_json  TEXT          NOT NULL,          -- {"step": StepDef with {STEP} placeholders, "rules": [RuleDef]}
    active           BOOLEAN       NOT NULL DEFAULT TRUE,
    created_at       TIMESTAMPTZ   NOT NULL DEFAULT now(),
    created_by       VARCHAR(100),
    updated_at       TIMESTAMPTZ,
    updated_by       VARCHAR(100),
    row_version      BIGINT        NOT NULL DEFAULT 0
);
