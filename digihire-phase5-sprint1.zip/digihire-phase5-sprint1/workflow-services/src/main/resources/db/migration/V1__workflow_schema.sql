-- =====================================================================================================
-- workflow-services schema (Phase 5 / Sprint 1) - config-driven workflow engine
-- A workflow version is ONE immutable JSON document (states + transitions + rules). Only the draft is editable.
-- =====================================================================================================

CREATE TABLE IF NOT EXISTS dh_workflow.workflow_definition (
    id               UUID PRIMARY KEY,
    code             VARCHAR(60)  NOT NULL UNIQUE,
    name             VARCHAR(150) NOT NULL,
    entity_type      VARCHAR(40)  NOT NULL,          -- APPLICATION (vendor/job workflows later)
    description      VARCHAR(1000),
    active_version   INT,                            -- version used for NEW instances
    draft_json       TEXT,                           -- editable draft (null = no draft)
    active           BOOLEAN      NOT NULL DEFAULT TRUE,
    created_at       TIMESTAMPTZ  NOT NULL DEFAULT now(),
    created_by       VARCHAR(100),
    updated_at       TIMESTAMPTZ,
    updated_by       VARCHAR(100),
    row_version      BIGINT       NOT NULL DEFAULT 0
);

CREATE TABLE IF NOT EXISTS dh_workflow.workflow_version (
    id               UUID PRIMARY KEY,
    workflow_code    VARCHAR(60)  NOT NULL REFERENCES dh_workflow.workflow_definition (code),
    version_no       INT          NOT NULL,
    definition_json  TEXT         NOT NULL,          -- immutable once published
    change_summary   VARCHAR(1000),
    published_by     VARCHAR(100),
    published_at     TIMESTAMPTZ  NOT NULL,
    UNIQUE (workflow_code, version_no)
);

-- Which workflow applies to which job / job role / LOB / location / hiring type (or a combination).
CREATE TABLE IF NOT EXISTS dh_workflow.workflow_assignment (
    id              UUID PRIMARY KEY,
    workflow_code   VARCHAR(60)  NOT NULL REFERENCES dh_workflow.workflow_definition (code),
    entity_type     VARCHAR(40)  NOT NULL,
    job_id          VARCHAR(100),                    -- jobposting.id / Oracle requisition id
    job_role        VARCHAR(150),                    -- designation / role, e.g. "AR Caller", "Medical Coder"
    lob             VARCHAR(100),                    -- master data LOB code
    location        VARCHAR(100),                    -- master data LOCATION code
    hiring_type     VARCHAR(40),                     -- FRESHER | LATERAL | CAMPUS | VENDOR ...
    priority        INT          NOT NULL DEFAULT 0,
    description     VARCHAR(500),
    active          BOOLEAN      NOT NULL DEFAULT TRUE,
    created_at      TIMESTAMPTZ  NOT NULL DEFAULT now(),
    created_by      VARCHAR(100),
    updated_at      TIMESTAMPTZ,
    updated_by      VARCHAR(100),
    row_version     BIGINT       NOT NULL DEFAULT 0
);
CREATE INDEX IF NOT EXISTS ix_wf_assignment_entity ON dh_workflow.workflow_assignment (entity_type, active);

CREATE TABLE IF NOT EXISTS dh_workflow.workflow_instance (
    id               UUID PRIMARY KEY,
    workflow_code    VARCHAR(60)  NOT NULL,
    version_no       INT          NOT NULL,          -- pinned: in-flight records keep the version they started with
    entity_type      VARCHAR(40)  NOT NULL,
    entity_id        VARCHAR(100) NOT NULL,
    candidate_id     VARCHAR(100),
    current_state    VARCHAR(60)  NOT NULL,
    assignment_id    UUID,
    criteria_json    TEXT,                           -- job/role/lob/location/hiringType used for resolution
    context_json     TEXT,                           -- latest entity snapshot used by rules & notifications
    created_at       TIMESTAMPTZ  NOT NULL DEFAULT now(),
    created_by       VARCHAR(100),
    updated_at       TIMESTAMPTZ,
    updated_by       VARCHAR(100),
    row_version      BIGINT       NOT NULL DEFAULT 0,
    UNIQUE (entity_type, entity_id)
);
CREATE INDEX IF NOT EXISTS ix_wf_instance_state ON dh_workflow.workflow_instance (workflow_code, current_state);
CREATE INDEX IF NOT EXISTS ix_wf_instance_candidate ON dh_workflow.workflow_instance (candidate_id);

-- Workflow transition logs (tracker #12) - transactional source of truth, also mirrored to dh_audit.audit_log.
CREATE TABLE IF NOT EXISTS dh_workflow.transition_log (
    id               UUID PRIMARY KEY,
    instance_id      UUID         NOT NULL REFERENCES dh_workflow.workflow_instance (id) ON DELETE CASCADE,
    workflow_code    VARCHAR(60)  NOT NULL,
    version_no       INT          NOT NULL,
    transition_code  VARCHAR(60),                    -- null for START / RESTART
    from_state       VARCHAR(60),
    to_state         VARCHAR(60)  NOT NULL,
    actor_id         VARCHAR(100),
    actor_name       VARCHAR(200),
    actor_roles      VARCHAR(500),
    remarks          VARCHAR(2000),
    payload_json     TEXT,
    approval_id      UUID,
    occurred_at      TIMESTAMPTZ  NOT NULL
);
CREATE INDEX IF NOT EXISTS ix_wf_transition_instance ON dh_workflow.transition_log (instance_id, occurred_at);

-- Transitions configured with requiresApproval wait here (approval logs, tracker #11).
CREATE TABLE IF NOT EXISTS dh_workflow.approval_request (
    id                   UUID PRIMARY KEY,
    instance_id          UUID         NOT NULL REFERENCES dh_workflow.workflow_instance (id) ON DELETE CASCADE,
    entity_type          VARCHAR(40)  NOT NULL,
    entity_id            VARCHAR(100) NOT NULL,
    candidate_id         VARCHAR(100),
    transition_code      VARCHAR(60)  NOT NULL,
    from_state           VARCHAR(60)  NOT NULL,
    to_state             VARCHAR(60)  NOT NULL,
    approver_roles       VARCHAR(500),
    approver_permission  VARCHAR(80),
    requested_by         VARCHAR(100),
    requested_by_name    VARCHAR(200),
    remarks              VARCHAR(2000),
    payload_json         TEXT,
    status               VARCHAR(20)  NOT NULL,      -- PENDING | APPROVED | REJECTED | CANCELLED
    decided_by           VARCHAR(100),
    decided_by_name      VARCHAR(200),
    decided_at           TIMESTAMPTZ,
    decision_remarks     VARCHAR(2000),
    created_at           TIMESTAMPTZ  NOT NULL DEFAULT now(),
    created_by           VARCHAR(100),
    updated_at           TIMESTAMPTZ,
    updated_by           VARCHAR(100),
    row_version          BIGINT       NOT NULL DEFAULT 0
);
CREATE INDEX IF NOT EXISTS ix_wf_approval_status ON dh_workflow.approval_request (status, created_at DESC);
CREATE UNIQUE INDEX IF NOT EXISTS ux_wf_approval_pending ON dh_workflow.approval_request (instance_id) WHERE status = 'PENDING';

-- Workflow change logging (tracker #30).
CREATE TABLE IF NOT EXISTS dh_workflow.workflow_change_log (
    id             UUID PRIMARY KEY,
    workflow_code  VARCHAR(60)  NOT NULL,
    action         VARCHAR(40)  NOT NULL,            -- CREATED | DRAFT_UPDATED | PUBLISHED | ACTIVATED | DRAFT_DISCARDED | ASSIGNMENT_* | SEEDED
    version_no     INT,
    actor          VARCHAR(200),
    details_json   TEXT,
    occurred_at    TIMESTAMPTZ  NOT NULL
);
CREATE INDEX IF NOT EXISTS ix_wf_change_code ON dh_workflow.workflow_change_log (workflow_code, occurred_at DESC);
