package com.ags.health.hr.workflow.engine;

import org.springframework.context.expression.MapAccessor;
import org.springframework.expression.EvaluationContext;
import org.springframework.expression.Expression;
import org.springframework.expression.ExpressionParser;
import org.springframework.expression.spel.standard.SpelExpressionParser;
import org.springframework.expression.spel.support.DataBindingPropertyAccessor;
import org.springframework.expression.spel.support.SimpleEvaluationContext;

import java.lang.reflect.Method;
import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.OffsetDateTime;
import java.time.ZoneId;
import java.time.temporal.ChronoUnit;
import java.util.Collection;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Sandboxed SpEL evaluation for admin-authored rules. Uses {@link SimpleEvaluationContext}: no type references
 * ({@code T(java.lang.Runtime)}), no constructors, no bean references - rules can only read the data given to them.
 *
 * <h3>Variables available in a rule</h3>
 * <ul>
 *   <li>{@code #entity}   - attributes of the record (candidate / application snapshot sent by the caller)</li>
 *   <li>{@code #payload}  - data submitted with this transition (reasonCode, score, sameCandidate ...)</li>
 *   <li>{@code #actor}    - {id, roles, permissions, system}</li>
 *   <li>{@code #instance} - {state, workflowCode, versionNo}</li>
 *   <li>{@code #config}   - enterprise configuration from admin-services (key -> value)</li>
 * </ul>
 * <h3>Functions</h3>
 * {@code #num(x)} number conversion, {@code #daysSince(date)} whole days from date to today (negative if in the future),
 * {@code #isBlank(x)}, {@code #contains(collection, value)}.
 * <p>Examples:
 * {@code #num(#payload['score']) >= #num(#config['assessment.versant.pass-score'])},
 * {@code #entity['lob'] == 'AR_CALLING' and #actor['roles'].contains('TL')}.
 */
public class RuleEvaluator {

    private static final ZoneId ZONE = ZoneId.of("Asia/Kolkata");

    private final ExpressionParser parser = new SpelExpressionParser();
    private final Map<String, Expression> cache = new ConcurrentHashMap<>();

    public record RuleContext(Map<String, Object> entity, Map<String, Object> payload, Map<String, Object> actor,
                              Map<String, Object> instance, Map<String, String> config) {
    }

    /** Throws {@link IllegalArgumentException} with the parser message when the expression is invalid. */
    public void validateSyntax(String expression) {
        try {
            parser.parseExpression(expression);
        } catch (RuntimeException e) {
            throw new IllegalArgumentException(e.getMessage(), e);
        }
    }

    public boolean evaluate(String expression, RuleContext ctx) {
        Expression exp = cache.computeIfAbsent(expression, parser::parseExpression);
        Boolean result = exp.getValue(context(ctx), Boolean.class);
        return Boolean.TRUE.equals(result);
    }

    private EvaluationContext context(RuleContext ctx) {
        SimpleEvaluationContext ec = SimpleEvaluationContext
                .forPropertyAccessors(new MapAccessor(), DataBindingPropertyAccessor.forReadOnlyAccess())
                .withInstanceMethods()
                .build();
        ec.setVariable("entity", ctx.entity() == null ? Map.of() : ctx.entity());
        ec.setVariable("payload", ctx.payload() == null ? Map.of() : ctx.payload());
        ec.setVariable("actor", ctx.actor() == null ? Map.of() : ctx.actor());
        ec.setVariable("instance", ctx.instance() == null ? Map.of() : ctx.instance());
        ec.setVariable("config", ctx.config() == null ? Map.of() : ctx.config());
        ec.setVariable("num", FN_NUM);
        ec.setVariable("daysSince", FN_DAYS_SINCE);
        ec.setVariable("isBlank", FN_IS_BLANK);
        ec.setVariable("contains", FN_CONTAINS);
        return ec;
    }

    // ------------------------------------------------------------------ functions exposed to rules
    private static final Method FN_NUM = method("num", Object.class);
    private static final Method FN_DAYS_SINCE = method("daysSince", Object.class);
    private static final Method FN_IS_BLANK = method("isBlank", Object.class);
    private static final Method FN_CONTAINS = method("contains", Object.class, Object.class);

    private static Method method(String name, Class<?>... types) {
        try {
            return RuleEvaluator.class.getDeclaredMethod(name, types);
        } catch (NoSuchMethodException e) {
            throw new IllegalStateException(e);
        }
    }

    public static Double num(Object value) {
        if (value == null) {
            return null;
        }
        if (value instanceof Number n) {
            return n.doubleValue();
        }
        String s = value.toString().trim();
        return s.isEmpty() ? null : Double.valueOf(s);
    }

    public static Long daysSince(Object value) {
        LocalDate date = toDate(value);
        return date == null ? null : ChronoUnit.DAYS.between(date, LocalDate.now(ZONE));
    }

    public static boolean isBlank(Object value) {
        return value == null || value.toString().isBlank();
    }

    public static boolean contains(Object collection, Object value) {
        if (collection instanceof Collection<?> c) {
            return c.contains(value);
        }
        return collection != null && value != null && collection.toString().contains(value.toString());
    }

    static LocalDate toDate(Object value) {
        if (value == null) {
            return null;
        }
        if (value instanceof LocalDate d) {
            return d;
        }
        if (value instanceof Instant i) {
            return i.atZone(ZONE).toLocalDate();
        }
        if (value instanceof Number n) { // epoch millis
            return Instant.ofEpochMilli(n.longValue()).atZone(ZONE).toLocalDate();
        }
        String s = value.toString().trim();
        if (s.isEmpty()) {
            return null;
        }
        if (s.length() == 10) {
            return LocalDate.parse(s);
        }
        try {
            return OffsetDateTime.parse(s).atZoneSameInstant(ZONE).toLocalDate();
        } catch (RuntimeException e) {
            return LocalDateTime.parse(s).toLocalDate();
        }
    }
}
