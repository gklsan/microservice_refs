package com.ags.health.hr.workflow.domain;

import com.ags.health.hr.platform.jpa.AuditableEntity;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.UUID;

/** Runtime state of one record (e.g. one application). Pinned to the workflow version it started on. */
@Entity
@Table(name = "workflow_instance")
@Getter
@Setter
@NoArgsConstructor
public class WorkflowInstance extends AuditableEntity {

    @Id
    private UUID id;

    @Column(name = "workflow_code", nullable = false)
    private String workflowCode;

    @Column(name = "version_no", nullable = false)
    private int versionNo;

    @Column(name = "entity_type", nullable = false, updatable = false)
    private String entityType;

    @Column(name = "entity_id", nullable = false, updatable = false)
    private String entityId;

    @Column(name = "candidate_id")
    private String candidateId;

    @Column(name = "current_state", nullable = false)
    private String currentState;

    @Column(name = "assignment_id")
    private UUID assignmentId;

    @Column(name = "criteria_json")
    private String criteriaJson;

    @Column(name = "context_json")
    private String contextJson;
}
