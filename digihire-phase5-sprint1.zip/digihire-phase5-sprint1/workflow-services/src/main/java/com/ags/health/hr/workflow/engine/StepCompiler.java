package com.ags.health.hr.workflow.engine;

import com.ags.health.hr.workflow.engine.WorkflowModel.Blueprint;
import com.ags.health.hr.workflow.engine.WorkflowModel.StageDef;
import com.ags.health.hr.workflow.engine.WorkflowModel.StateCategory;
import com.ags.health.hr.workflow.engine.WorkflowModel.StateDef;
import com.ags.health.hr.workflow.engine.WorkflowModel.StepDef;
import com.ags.health.hr.workflow.engine.WorkflowModel.TransitionDef;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Turns the HR step list ({@link Blueprint}) into the executable state machine. This is the only "logic" behind the
 * step builder - everything else is data:
 * <ol>
 *   <li>common states + every stage of every step become states (tagged with their step)</li>
 *   <li>each step is entered from the previous step's exit stages (or {@code startFrom} for the first step) through
 *       its entry action; an optional step lets the next step be entered from the previous step too (skip)</li>
 *   <li>step actions, global actions and extra transitions are copied with their tokens resolved</li>
 * </ol>
 * Unresolvable tokens are reported as issues (and the validator reports anything else).
 */
public final class StepCompiler {

    private static final Pattern PARAM = Pattern.compile("\\{\\{\\s*([A-Za-z0-9_.-]+)\\s*}}");
    private static final Set<String> DEFAULT_ENTRY_PERMISSIONS = Set.of("APPLICATION:MOVE_STAGE");

    private StepCompiler() {
    }

    public record Result(WorkflowModel model, List<WorkflowValidator.Issue> issues) {
    }

    public static Result compile(WorkflowModel m) {
        Blueprint bp = m.blueprint();
        if (bp == null) {
            return new Result(m, List.of());
        }
        List<WorkflowValidator.Issue> issues = new ArrayList<>();
        List<StateDef> states = new ArrayList<>(bp.commonStates());
        List<TransitionDef> transitions = new ArrayList<>();

        // --- stages -> states, remember entry / all / exit stages per step
        Map<String, String> entry = new LinkedHashMap<>();
        Map<String, List<String>> live = new LinkedHashMap<>();   // non-terminal stages
        Map<String, List<String>> exits = new LinkedHashMap<>();
        for (StepDef step : bp.steps()) {
            if (step.code() == null || step.code().isBlank()) {
                issues.add(error("STEP_CODE_MISSING", "blueprint.steps", "Every step needs a code"));
                continue;
            }
            if (step.stages().isEmpty()) {
                issues.add(error("STEP_WITHOUT_STAGES", "steps." + step.code(), "Step '" + step.code() + "' has no stages"));
                continue;
            }
            List<String> liveStages = new ArrayList<>();
            List<String> exitStages = new ArrayList<>();
            for (StageDef stage : step.stages()) {
                String code = sub(stage.code(), step);
                StateCategory category = stage.category() == null ? StateCategory.INTERMEDIATE : stage.category();
                Map<String, Object> attrs = new LinkedHashMap<>();
                if (stage.attributes() != null) {
                    attrs.putAll(stage.attributes());
                }
                attrs.put("step", step.code());
                attrs.put("stepLabel", step.label());
                attrs.put("stepType", step.type());
                attrs.put("exit", stage.exit());
                states.add(new StateDef(code, stage.label(), category, stage.tab() != null ? stage.tab() : step.tab(),
                        null, attrs));
                if (category != StateCategory.TERMINAL) {
                    liveStages.add(code);
                }
                if (stage.exit()) {
                    exitStages.add(code);
                }
            }
            entry.put(step.code(), sub(step.stages().get(0).code(), step));
            live.put(step.code(), liveStages);
            exits.put(step.code(), exitStages);
        }

        // --- step entry + step actions
        List<StepDef> steps = bp.steps().stream().filter(s -> entry.containsKey(s.code())).toList();
        Set<String> enterFrom = new LinkedHashSet<>(bp.startFrom());
        for (int i = 0; i < steps.size(); i++) {
            StepDef step = steps.get(i);
            String next = i + 1 < steps.size() ? entry.get(steps.get(i + 1).code()) : null;
            if (!enterFrom.isEmpty()) {
                TransitionDef ea = step.entryAction();
                String code = ea != null && ea.code() != null ? sub(ea.code(), step) : "START_" + step.code();
                String label = ea != null && ea.label() != null ? ea.label() : "Start " + step.label();
                transitions.add(copy(ea, step, code, label, new ArrayList<>(enterFrom), entry.get(step.code()),
                        ea == null ? DEFAULT_ENTRY_PERMISSIONS : null));
            }
            for (TransitionDef a : step.actions()) {
                String code = sub(a.code(), step);
                List<String> from = resolveFrom(a.from(), step, live, exits, issues, "steps." + step.code() + "." + code);
                String to = resolveTo(a.to(), step, next, bp, entry, issues, "steps." + step.code() + "." + code);
                transitions.add(copy(a, step, code, a.label(), from, to, null));
            }
            Set<String> nextEnterFrom = new LinkedHashSet<>(exits.get(step.code()));
            if (step.optional()) {
                nextEnterFrom.addAll(enterFrom); // skip: the following step can also be entered from here
            }
            enterFrom = nextEnterFrom;
        }

        // --- global actions and extra transitions
        for (TransitionDef a : bp.globalActions()) {
            List<String> from = resolveFrom(a.from(), null, live, exits, issues, "globalActions." + a.code());
            String to = resolveTo(a.to(), null, null, bp, entry, issues, "globalActions." + a.code());
            transitions.add(copy(a, null, a.code(), a.label(), from, to, null));
        }
        for (TransitionDef t : bp.extraTransitions()) {
            List<String> from = resolveFrom(t.from(), null, live, exits, issues, "extraTransitions." + t.code());
            String to = resolveTo(t.to(), null, null, bp, entry, issues, "extraTransitions." + t.code());
            transitions.add(copy(t, null, t.code(), t.label(), from, to, null));
        }

        WorkflowModel compiled = new WorkflowModel(m.code(), m.name(), m.entityType(), m.description(), states,
                transitions, m.rules(), bp);
        return new Result(compiled, issues);
    }

    // ------------------------------------------------------------------ token resolution
    private static List<String> resolveFrom(List<String> tokens, StepDef step, Map<String, List<String>> live,
                                            Map<String, List<String>> exits, List<WorkflowValidator.Issue> issues,
                                            String path) {
        Set<String> result = new LinkedHashSet<>();
        for (String raw : tokens) {
            String t = sub(raw, step);
            if ("*".equals(t)) {
                if (step == null) {
                    issues.add(error("TOKEN_OUTSIDE_STEP", path, "'*' can only be used inside a step"));
                } else {
                    result.addAll(live.getOrDefault(step.code(), List.of()));
                }
            } else if ("ALL_STEPS".equals(t)) {
                live.values().forEach(result::addAll);
            } else if (t.startsWith("STEP:")) {
                String code = t.substring(5);
                if (!live.containsKey(code)) {
                    issues.add(error("UNKNOWN_STEP", path, "Unknown step '" + code + "'"));
                } else {
                    result.addAll(live.get(code));
                }
            } else if (t.startsWith("EXITS:")) {
                String code = t.substring(6);
                if (!exits.containsKey(code)) {
                    issues.add(error("UNKNOWN_STEP", path, "Unknown step '" + code + "'"));
                } else {
                    result.addAll(exits.get(code));
                }
            } else {
                result.add(t);
            }
        }
        return new ArrayList<>(result);
    }

    private static String resolveTo(String raw, StepDef step, String next, Blueprint bp, Map<String, String> entry,
                                    List<WorkflowValidator.Issue> issues, String path) {
        String t = sub(raw, step);
        if (t == null) {
            issues.add(error("MISSING_TARGET", path, "Action has no 'to'"));
            return null;
        }
        switch (t) {
            case "NEXT":
                if (next == null) {
                    issues.add(error("NO_NEXT_STEP", path, "'NEXT' used in the last step"));
                }
                return next;
            case "REJECT":
                if (bp.rejectionState() == null) {
                    issues.add(error("NO_REJECTION_STATE", path, "'REJECT' used but blueprint.rejectionState is not set"));
                }
                return bp.rejectionState();
            default:
                if (t.startsWith("STEP:")) {
                    String target = entry.get(t.substring(5));
                    if (target == null) {
                        issues.add(error("UNKNOWN_STEP", path, "Unknown step '" + t.substring(5) + "'"));
                    }
                    return target;
                }
                return t;
        }
    }

    private static TransitionDef copy(TransitionDef src, StepDef step, String code, String label, List<String> from,
                                      String to, Set<String> defaultPermissions) {
        Map<String, Object> attrs = new LinkedHashMap<>();
        if (src != null && src.attributes() != null) {
            attrs.putAll(src.attributes());
        }
        if (step != null) {
            attrs.put("step", step.code());
        }
        if (src == null) {
            return new TransitionDef(code, label, from, to, Set.of(), defaultPermissions, List.of(), List.of(), null,
                    false, Set.of(), null, false, attrs);
        }
        return new TransitionDef(code, label, from, to, src.allowedRoles(), src.requiredPermissions(),
                src.requiredFields(), src.rules(), params(src.guard(), step), src.requiresApproval(),
                src.approverRoles(), src.approverPermission(), src.systemOnly(), attrs);
    }

    /** {STEP} placeholder in codes. */
    static String sub(String value, StepDef step) {
        return value == null || step == null ? value : value.replace("{STEP}", step.code());
    }

    /** {{param}} placeholders in guards, filled from the step parameters. */
    static String params(String guard, StepDef step) {
        if (guard == null || step == null || step.parameters().isEmpty()) {
            return guard;
        }
        Matcher m = PARAM.matcher(guard);
        StringBuilder sb = new StringBuilder();
        while (m.find()) {
            Object v = step.parameters().get(m.group(1));
            String replacement = v == null ? m.group(0) : (v instanceof Number || v instanceof Boolean)
                    ? v.toString() : "'" + v.toString().replace("'", "''") + "'";
            m.appendReplacement(sb, Matcher.quoteReplacement(replacement));
        }
        m.appendTail(sb);
        return sb.toString();
    }

    private static WorkflowValidator.Issue error(String code, String path, String message) {
        return new WorkflowValidator.Issue(WorkflowValidator.Severity.ERROR, code, path, message);
    }
}
