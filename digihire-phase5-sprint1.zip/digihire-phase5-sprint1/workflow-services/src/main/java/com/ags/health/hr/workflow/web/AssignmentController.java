package com.ags.health.hr.workflow.web;

import com.ags.health.hr.platform.security.CurrentUser;
import com.ags.health.hr.workflow.service.AssignmentService;
import com.ags.health.hr.workflow.web.WorkflowDtos.AssignmentRequest;
import com.ags.health.hr.workflow.web.WorkflowDtos.AssignmentResponse;
import com.ags.health.hr.workflow.web.WorkflowDtos.Criteria;
import com.ags.health.hr.workflow.web.WorkflowDtos.ResolveResponse;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.UUID;

/**
 * HR defines which workflow applies to a job, job role, LOB, location, hiring type or any combination.
 * Resolution: most specific assignment wins (job 16 > role 8 > LOB 4 > location 2 > hiring type 1), then priority.
 */
@RestController
@RequestMapping("/workflow-assignments")
@Tag(name = "Workflow assignments (job / role / LOB)")
public class AssignmentController {

    private final AssignmentService service;

    public AssignmentController(AssignmentService service) {
        this.service = service;
    }

    @GetMapping
    @PreAuthorize("hasAuthority('WORKFLOW:VIEW')")
    public List<AssignmentResponse> list(@RequestParam(required = false) String workflowCode) {
        return service.list(workflowCode);
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    @PreAuthorize("hasAuthority('WORKFLOW:ASSIGN')")
    @Operation(summary = "Bind a workflow to jobId / jobRole / lob / location / hiringType (any combination)")
    public AssignmentResponse create(@AuthenticationPrincipal CurrentUser user, @Valid @RequestBody AssignmentRequest req) {
        return service.create(req, user);
    }

    @PutMapping("/{id}")
    @PreAuthorize("hasAuthority('WORKFLOW:ASSIGN')")
    public AssignmentResponse update(@AuthenticationPrincipal CurrentUser user, @PathVariable UUID id,
                                     @Valid @RequestBody AssignmentRequest req) {
        return service.update(id, req, user);
    }

    @PatchMapping("/{id}/deactivate")
    @PreAuthorize("hasAuthority('WORKFLOW:ASSIGN')")
    public AssignmentResponse deactivate(@AuthenticationPrincipal CurrentUser user, @PathVariable UUID id) {
        return service.deactivate(id, user);
    }

    @GetMapping("/resolve")
    @PreAuthorize("hasAuthority('WORKFLOW:VIEW')")
    @Operation(summary = "Preview: which workflow would a record with these attributes get?")
    public ResolveResponse resolve(@RequestParam(defaultValue = "APPLICATION") String entityType,
                                   @RequestParam(required = false) String jobId,
                                   @RequestParam(required = false) String jobRole,
                                   @RequestParam(required = false) String lob,
                                   @RequestParam(required = false) String location,
                                   @RequestParam(required = false) String hiringType) {
        return service.resolve(entityType, new Criteria(jobId, jobRole, lob, location, hiringType));
    }
}
