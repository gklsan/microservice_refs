package com.ags.health.hr.workflow.repo;

import com.ags.health.hr.workflow.domain.WorkflowVersion;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

public interface WorkflowVersionRepository extends JpaRepository<WorkflowVersion, UUID> {

    Optional<WorkflowVersion> findByWorkflowCodeAndVersionNo(String workflowCode, int versionNo);

    List<WorkflowVersion> findByWorkflowCodeOrderByVersionNoDesc(String workflowCode);

    @Query("select coalesce(max(v.versionNo), 0) from WorkflowVersion v where v.workflowCode = :code")
    int maxVersion(@Param("code") String code);
}
