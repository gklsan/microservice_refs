package com.ags.health.hr.workflow.repo;

import com.ags.health.hr.workflow.domain.WorkflowInstance;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;
import java.util.UUID;

public interface WorkflowInstanceRepository extends JpaRepository<WorkflowInstance, UUID> {

    Optional<WorkflowInstance> findByEntityTypeAndEntityId(String entityType, String entityId);

    long countByWorkflowCodeAndVersionNo(String workflowCode, int versionNo);
}
