package com.ags.health.hr.workflow.engine;

import com.ags.health.hr.workflow.engine.WorkflowModel.RuleDef;
import com.ags.health.hr.workflow.engine.WorkflowModel.TransitionDef;

import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;

/**
 * The whole engine: decides whether a transition may fire. Stateless and free of Spring/JPA so it is
 * trivially unit-testable; persistence and side effects live in {@code RuntimeService}.
 *
 * <p>Checks, in order: transition exists -> current state is a valid source (invalid state validation)
 * -> manual vs system -> role -> permissions -> required fields -> named rules -> inline guard -> approval.
 */
public class WorkflowEngine {

    private final RuleEvaluator rules;

    public WorkflowEngine(RuleEvaluator rules) {
        this.rules = rules;
    }

    /** Who is acting. {@code system=true} for integrations/schedulers (skips role & permission checks). */
    public record Actor(String id, String name, Set<String> roles, Set<String> permissions, boolean system) {
        public Map<String, Object> asMap() {
            Map<String, Object> m = new LinkedHashMap<>();
            m.put("id", id);
            m.put("name", name);
            m.put("roles", List.copyOf(roles));
            m.put("permissions", List.copyOf(permissions));
            m.put("system", system);
            return m;
        }
    }

    public record Violation(String code, String message) {
    }

    public record Decision(TransitionDef transition, boolean allowed, boolean requiresApproval,
                           List<Violation> violations) {
    }

    /** View of a transition the UI can offer as a button, with the reasons it is disabled. */
    public record Option(String code, String label, String to, boolean allowed, boolean requiresApproval,
                         List<String> requiredFields, List<Violation> reasons, Map<String, Object> attributes) {
    }

    public Decision decide(WorkflowModel model, String currentState, String transitionCode, Actor actor,
                           Map<String, Object> entity, Map<String, Object> payload, Map<String, String> config,
                           boolean checkFields) {
        Optional<TransitionDef> found = model.transition(transitionCode);
        if (found.isEmpty()) {
            return new Decision(null, false, false,
                    List.of(new Violation("UNKNOWN_TRANSITION", "Transition '" + transitionCode + "' does not exist in "
                            + model.code())));
        }
        TransitionDef t = found.get();
        List<Violation> v = new ArrayList<>();
        if (!t.from().contains(currentState)) {
            v.add(new Violation("INVALID_STATE", "'" + t.code() + "' is not allowed from state '" + currentState
                    + "' (allowed from " + t.from() + ")"));
            return new Decision(t, false, false, v); // nothing else matters
        }
        if (t.systemOnly() && !actor.system()) {
            v.add(new Violation("SYSTEM_ONLY", "'" + t.code() + "' can only be performed by the system"));
        }
        if (!actor.system()) {
            if (!t.allowedRoles().isEmpty() && Collections.disjoint(t.allowedRoles(), actor.roles())) {
                v.add(new Violation("ROLE_NOT_ALLOWED", "Requires one of roles " + t.allowedRoles()));
            }
            for (String p : t.requiredPermissions()) {
                if (!actor.permissions().contains(p)) {
                    v.add(new Violation("MISSING_PERMISSION", "Requires permission " + p));
                }
            }
        }
        Map<String, Object> safePayload = payload == null ? Map.of() : payload;
        if (checkFields) {
            for (String f : t.requiredFields()) {
                Object value = safePayload.containsKey(f) ? safePayload.get(f) : (entity == null ? null : entity.get(f));
                if (value == null || value.toString().isBlank()) {
                    v.add(new Violation("MISSING_FIELD", "Field '" + f + "' is required"));
                }
            }
        }
        RuleEvaluator.RuleContext ctx = new RuleEvaluator.RuleContext(entity, safePayload, actor.asMap(),
                Map.of("state", currentState, "workflowCode", model.code()), config);
        for (String ruleCode : t.rules()) {
            Optional<RuleDef> rule = model.rule(ruleCode);
            if (rule.isEmpty()) {
                v.add(new Violation("UNKNOWN_RULE", "Rule '" + ruleCode + "' is not defined"));
                continue;
            }
            evaluate(rule.get().expression(), ctx, "RULE_FAILED",
                    rule.get().errorMessage() != null ? rule.get().errorMessage() : "Rule " + ruleCode + " not satisfied", v);
        }
        if (t.guard() != null && !t.guard().isBlank()) {
            evaluate(t.guard(), ctx, "GUARD_FAILED", "Condition not satisfied: " + t.guard(), v);
        }
        return new Decision(t, v.isEmpty(), t.requiresApproval(), v);
    }

    /** Transitions leaving the current state, evaluated for this actor (field checks skipped - no payload yet). */
    public List<Option> options(WorkflowModel model, String currentState, Actor actor, Map<String, Object> entity,
                                Map<String, String> config) {
        List<Option> result = new ArrayList<>();
        for (TransitionDef t : model.transitionsFrom(currentState)) {
            if (t.systemOnly() && !actor.system()) {
                continue;
            }
            Decision d = decide(model, currentState, t.code(), actor, entity, Map.of(), config, false);
            result.add(new Option(t.code(), t.label(), t.to(), d.allowed(), t.requiresApproval(), t.requiredFields(),
                    d.violations(), t.attributes()));
        }
        return result;
    }

    /** Legacy integration: transitions that move current -> target (caller picks the first allowed one). */
    public List<TransitionDef> findByTarget(WorkflowModel model, String currentState, String targetState) {
        return model.transitionsFrom(currentState).stream().filter(t -> targetState.equals(t.to())).toList();
    }

    private void evaluate(String expression, RuleEvaluator.RuleContext ctx, String code, String message,
                          List<Violation> sink) {
        try {
            if (!rules.evaluate(expression, ctx)) {
                sink.add(new Violation(code, message));
            }
        } catch (RuntimeException e) {
            sink.add(new Violation("RULE_ERROR", message + " (evaluation error: " + e.getMessage() + ")"));
        }
    }
}
