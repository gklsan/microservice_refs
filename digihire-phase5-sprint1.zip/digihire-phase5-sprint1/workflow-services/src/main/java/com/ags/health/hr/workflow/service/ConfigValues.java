package com.ags.health.hr.workflow.service;

import com.ags.health.hr.platform.web.InternalServiceClient;
import com.ags.health.hr.workflow.WorkflowProperties;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import java.time.Instant;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Enterprise configuration from admin-services exposed to rules as {@code #config} (pass score, validity days ...),
 * so HR/Admin change thresholds without touching workflows. Cached; on failure the last known values are kept.
 */
@Component
public class ConfigValues {

    private static final Logger log = LoggerFactory.getLogger(ConfigValues.class);

    private final InternalServiceClient client;
    private final WorkflowProperties props;
    private volatile Map<String, String> values = Map.of();
    private volatile Instant expiresAt = Instant.EPOCH;

    public ConfigValues(InternalServiceClient client, WorkflowProperties props) {
        this.client = client;
        this.props = props;
    }

    @SuppressWarnings("unchecked")
    public Map<String, String> get() {
        if (Instant.now().isBefore(expiresAt) || props.configUrl() == null) {
            return values;
        }
        try {
            List<Map<String, Object>> rows = client.get(props.configUrl(), List.class);
            Map<String, String> fresh = new HashMap<>();
            if (rows != null) {
                for (Map<String, Object> r : rows) {
                    Object k = r.get("key");
                    Object v = r.get("value");
                    if (k != null && v != null) {
                        fresh.put(k.toString(), v.toString());
                    }
                }
            }
            values = Map.copyOf(fresh);
        } catch (RuntimeException e) {
            log.warn("Could not refresh enterprise config from admin-services: {}", e.getMessage());
        }
        expiresAt = Instant.now().plus(props.configCacheTtl());
        return values;
    }
}
