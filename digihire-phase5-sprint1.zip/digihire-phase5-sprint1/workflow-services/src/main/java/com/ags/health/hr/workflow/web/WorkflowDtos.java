package com.ags.health.hr.workflow.web;

import com.ags.health.hr.workflow.domain.ApprovalRequest;
import com.ags.health.hr.workflow.domain.WorkflowAssignment;
import com.ags.health.hr.workflow.engine.WorkflowEngine;
import com.ags.health.hr.workflow.engine.WorkflowModel;
import com.ags.health.hr.workflow.engine.WorkflowValidator;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;

import java.time.Instant;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/** Request / response contracts of workflow-services. */
public final class WorkflowDtos {

    private WorkflowDtos() {
    }

    // ------------------------------------------------------------------ definitions & versions
    public record CreateWorkflowRequest(@NotBlank @Pattern(regexp = "[A-Z][A-Z0-9_]{1,59}") String code,
                                        @NotBlank @Size(max = 150) String name,
                                        @NotBlank @Size(max = 40) String entityType,
                                        @Size(max = 1000) String description,
                                        /* optional: start the draft as a copy of this workflow's active version */
                                        String copyFrom) {
    }

    public record WorkflowSummary(String code, String name, String entityType, String description,
                                  Integer activeVersion, int latestVersion, boolean hasDraft, boolean active,
                                  Instant updatedAt, String updatedBy) {
    }

    public record VersionSummary(int versionNo, String changeSummary, String publishedBy, Instant publishedAt,
                                 boolean active, long runningInstances) {
    }

    public record WorkflowDetail(WorkflowSummary workflow, List<VersionSummary> versions,
                                 List<AssignmentResponse> assignments) {
    }

    public record DraftResponse(WorkflowModel model, boolean savedDraft, List<WorkflowValidator.Issue> issues) {
    }

    public record PublishRequest(@NotBlank @Size(max = 1000) String changeSummary, Boolean activate) {
    }

    public record ChangeLogEntry(String action, Integer versionNo, String actor, Map<String, Object> details,
                                 Instant occurredAt) {
    }

    public record StateView(String code, String label, WorkflowModel.StateCategory category, String tab) {
    }

    public record RuleTestRequest(@NotBlank String expression, Map<String, Object> entity, Map<String, Object> payload,
                                  Map<String, Object> actor, Map<String, String> config) {
    }

    public record RuleTestResponse(boolean valid, Boolean result, String error) {
    }

    // ------------------------------------------------------------------ assignments (job / role / LOB ...)
    public record AssignmentRequest(@NotBlank String workflowCode,
                                    @Size(max = 100) String jobId,
                                    @Size(max = 150) String jobRole,
                                    @Size(max = 100) String lob,
                                    @Size(max = 100) String location,
                                    @Size(max = 40) String hiringType,
                                    int priority,
                                    @Size(max = 500) String description,
                                    Boolean active) {
    }

    public record AssignmentResponse(UUID id, String workflowCode, String entityType, String jobId, String jobRole,
                                     String lob, String location, String hiringType, int priority, int specificity,
                                     String description, boolean active, Instant createdAt, String createdBy,
                                     Instant updatedAt, String updatedBy) {
        public static AssignmentResponse of(WorkflowAssignment a, int specificity) {
            return new AssignmentResponse(a.getId(), a.getWorkflowCode(), a.getEntityType(), a.getJobId(),
                    a.getJobRole(), a.getLob(), a.getLocation(), a.getHiringType(), a.getPriority(), specificity,
                    a.getDescription(), a.isActive(), a.getCreatedAt(), a.getCreatedBy(), a.getUpdatedAt(),
                    a.getUpdatedBy());
        }
    }

    /** Record attributes used to pick the workflow (all optional). */
    public record Criteria(String jobId, String jobRole, String lob, String location, String hiringType) {
    }

    public record ResolveResponse(String workflowCode, Integer versionNo, UUID assignmentId, String matchedBy) {
    }

    // ------------------------------------------------------------------ runtime
    public record StartRequest(@NotBlank @Size(max = 40) String entityType,
                               @NotBlank @Size(max = 100) String entityId,
                               @Size(max = 100) String candidateId,
                               /* optional explicit workflow (needs WORKFLOW:ASSIGN for users) */
                               String workflowCode,
                               @Valid Criteria criteria,
                               String initialState,
                               Map<String, Object> context,
                               /* true = discard the current instance and start again (re-mapping to another job) */
                               boolean restart,
                               @Size(max = 2000) String remarks) {
    }

    public record TransitionRequest(@Size(max = 2000) String remarks,
                                    Map<String, Object> payload,
                                    /* latest snapshot of the record (candidate name/email, job, lob, dates ...) */
                                    Map<String, Object> context) {
    }

    public record MoveRequest(@NotBlank String toState,
                              @Size(max = 2000) String remarks,
                              Map<String, Object> payload,
                              Map<String, Object> context) {
    }

    public record ValidateRequest(String transitionCode, String toState, Map<String, Object> payload,
                                  Map<String, Object> context) {
    }

    public record ValidateResponse(boolean allowed, boolean requiresApproval, String transitionCode,
                                   List<WorkflowEngine.Violation> violations) {
    }

    public record ApprovalView(UUID id, UUID instanceId, String entityType, String entityId, String candidateId,
                               String transitionCode, String fromState, String toState, String approverRoles,
                               String approverPermission, String requestedBy, String requestedByName, String remarks,
                               ApprovalRequest.Status status, String decidedBy, String decidedByName,
                               Instant decidedAt, String decisionRemarks, Instant createdAt) {
        public static ApprovalView of(ApprovalRequest a) {
            return new ApprovalView(a.getId(), a.getInstanceId(), a.getEntityType(), a.getEntityId(),
                    a.getCandidateId(), a.getTransitionCode(), a.getFromState(), a.getToState(), a.getApproverRoles(),
                    a.getApproverPermission(), a.getRequestedBy(), a.getRequestedByName(), a.getRemarks(),
                    a.getStatus(), a.getDecidedBy(), a.getDecidedByName(), a.getDecidedAt(), a.getDecisionRemarks(),
                    a.getCreatedAt());
        }
    }

    public record InstanceView(UUID id, String workflowCode, int versionNo, String entityType, String entityId,
                               String candidateId, String currentState, String stateLabel,
                               WorkflowModel.StateCategory stateCategory, String tab, UUID assignmentId,
                               Instant startedAt, Instant updatedAt, List<WorkflowEngine.Option> availableTransitions,
                               ApprovalView pendingApproval) {
    }

    public record TransitionResult(@NotNull String status, InstanceView instance, ApprovalView approval) {
        public static final String COMPLETED = "COMPLETED";
        public static final String PENDING_APPROVAL = "PENDING_APPROVAL";
        public static final String NO_CHANGE = "NO_CHANGE";
    }

    public record HistoryEntry(String transitionCode, String fromState, String toState, String actorId,
                               String actorName, String remarks, Map<String, Object> payload, UUID approvalId,
                               int versionNo, Instant occurredAt) {
    }

    public record DecisionRequest(@Size(max = 2000) String remarks) {
    }

    public record PageResponse<T>(List<T> content, int page, int size, long totalElements, int totalPages) {
    }

    // ------------------------------------------------------------------ step builder
    /** Library entry: the step (with {STEP} placeholders) and the rules it needs. */
    public record StepTemplateDoc(WorkflowModel.StepDef step, List<WorkflowModel.RuleDef> rules) {
    }

    public record StepTemplateRequest(@NotBlank @Size(max = 150) String name,
                                      @NotBlank @Size(max = 40) String stepType,
                                      @Size(max = 1000) String description,
                                      @NotNull WorkflowModel.StepDef step,
                                      List<WorkflowModel.RuleDef> rules,
                                      Boolean active) {
    }

    public record StepTemplateResponse(String code, String name, String stepType, String description,
                                       WorkflowModel.StepDef step, List<WorkflowModel.RuleDef> rules, boolean active,
                                       Instant updatedAt, String updatedBy) {
    }

    /**
     * Add a step to a workflow draft - either from the library ({@code templateCode}) or a fully specified
     * {@code step}. {@code position} is 0-based (null = append).
     */
    public record AddStepRequest(String templateCode,
                                 @NotBlank @Pattern(regexp = "[A-Z][A-Z0-9_]{1,39}") String stepCode,
                                 @Size(max = 150) String label,
                                 Integer position,
                                 Boolean optional,
                                 String tab,
                                 Map<String, Object> parameters,
                                 WorkflowModel.StepDef step) {
    }

    public record ReorderStepsRequest(@NotNull List<String> order) {
    }

    /** Step-level view for the step builder screen. */
    public record StepsResponse(WorkflowModel.Blueprint blueprint, List<WorkflowValidator.Issue> issues) {
    }
}

