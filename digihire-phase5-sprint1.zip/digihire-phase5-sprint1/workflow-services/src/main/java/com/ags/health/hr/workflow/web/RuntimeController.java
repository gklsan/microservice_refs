package com.ags.health.hr.workflow.web;

import com.ags.health.hr.platform.security.CurrentUser;
import com.ags.health.hr.workflow.service.RuntimeService;
import com.ags.health.hr.workflow.web.WorkflowDtos.HistoryEntry;
import com.ags.health.hr.workflow.web.WorkflowDtos.InstanceView;
import com.ags.health.hr.workflow.web.WorkflowDtos.MoveRequest;
import com.ags.health.hr.workflow.web.WorkflowDtos.StartRequest;
import com.ags.health.hr.workflow.web.WorkflowDtos.TransitionRequest;
import com.ags.health.hr.workflow.web.WorkflowDtos.TransitionResult;
import com.ags.health.hr.workflow.web.WorkflowDtos.ValidateRequest;
import com.ags.health.hr.workflow.web.WorkflowDtos.ValidateResponse;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/**
 * Runtime API used by the UI (buttons on Applicant / HR Interview / Panel tabs) and by existing services.
 * Every call is checked against the record's pinned workflow version, the caller's roles/permissions and the rules.
 */
@RestController
@RequestMapping("/runtime/instances")
@Tag(name = "Workflow runtime")
public class RuntimeController {

    private final RuntimeService service;

    public RuntimeController(RuntimeService service) {
        this.service = service;
    }

    @PostMapping
    @PreAuthorize("hasAnyAuthority('APPLICATION:CREATE', 'APPLICATION:MAP', 'WORKFLOW:ASSIGN')")
    @Operation(summary = "Start (or re-start after re-mapping) a record on the workflow resolved from job / role / LOB")
    public InstanceView start(@AuthenticationPrincipal CurrentUser user, @Valid @RequestBody StartRequest req) {
        return service.start(req, user);
    }

    @GetMapping("/{entityType}/{entityId}")
    @PreAuthorize("hasAnyAuthority('APPLICATION:VIEW', 'WORKFLOW:VIEW')")
    @Operation(summary = "Current state, tab and the transitions the caller may perform (with disabled reasons)")
    public InstanceView get(@AuthenticationPrincipal CurrentUser user, @PathVariable String entityType,
                            @PathVariable String entityId) {
        return service.get(entityType, entityId, user);
    }

    @GetMapping("/{entityType}/{entityId}/history")
    @PreAuthorize("hasAnyAuthority('APPLICATION:VIEW', 'WORKFLOW:VIEW')")
    @Operation(summary = "Workflow transition log of the record")
    public List<HistoryEntry> history(@AuthenticationPrincipal CurrentUser user, @PathVariable String entityType,
                                      @PathVariable String entityId) {
        return service.history(entityType, entityId, user);
    }

    @PostMapping("/{entityType}/{entityId}/transitions/{transitionCode}")
    @Operation(summary = "Perform a transition. Returns COMPLETED or PENDING_APPROVAL; 409 invalid state, 403 not permitted, 422 rule/field failure")
    public TransitionResult transition(@AuthenticationPrincipal CurrentUser user, @PathVariable String entityType,
                                       @PathVariable String entityId, @PathVariable String transitionCode,
                                       @Valid @RequestBody(required = false) TransitionRequest req) {
        TransitionRequest body = req == null ? new TransitionRequest(null, null, null) : req;
        return service.transition(entityType, entityId, transitionCode, body, user);
    }

    @PostMapping("/{entityType}/{entityId}/move")
    @Operation(summary = "Move to a target state (legacy status-based callers); rejected when the workflow has no such path")
    public TransitionResult move(@AuthenticationPrincipal CurrentUser user, @PathVariable String entityType,
                                 @PathVariable String entityId, @Valid @RequestBody MoveRequest req) {
        return service.move(entityType, entityId, req, user);
    }

    @PostMapping("/{entityType}/{entityId}/validate")
    @PreAuthorize("hasAnyAuthority('APPLICATION:VIEW', 'WORKFLOW:VIEW')")
    @Operation(summary = "Dry run: would this transition / target state be allowed right now?")
    public ValidateResponse validate(@AuthenticationPrincipal CurrentUser user, @PathVariable String entityType,
                                     @PathVariable String entityId, @RequestBody ValidateRequest req) {
        return service.validate(entityType, entityId, req, user);
    }
}
