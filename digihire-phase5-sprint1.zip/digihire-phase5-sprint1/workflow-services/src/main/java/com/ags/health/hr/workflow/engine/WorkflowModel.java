package com.ags.health.hr.workflow.engine;

import com.fasterxml.jackson.annotation.JsonIgnore;

import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;

/**
 * A complete workflow definition. Stored as one JSON document per version, so the whole workflow -
 * steps, states, transitions, rules - is configuration, not code.
 *
 * <p>Two authoring levels:
 * <ul>
 *   <li><b>Step builder</b> (what HR uses): {@link #blueprint()} holds an ordered list of hiring steps
 *       (Walk-in, Assessment, Versant, HR round, Panel, Final HR, Offer ...). {@link StepCompiler} turns it into
 *       the states and transitions below every time the draft is saved.</li>
 *   <li><b>State machine</b> (what the engine executes): states + transitions + rules. Workflows without a
 *       blueprint are edited at this level directly.</li>
 * </ul>
 * Example of the compiled level (abridged):
 * <pre>
 * {
 *   "code": "APPLICATION_HIRING", "name": "Fresher hiring", "entityType": "APPLICATION",
 *   "states": [ {"code":"CREATED","label":"Application created","category":"INITIAL","tab":"APPLICANT"} ... ],
 *   "transitions": [ {"code":"MARK_WALKIN","from":["CREATED"],"to":"WALKEDIN",
 *                     "requiredPermissions":["APPLICATION:SCHEDULE_INTERVIEW"],"requiredFields":["interviewDate"]} ... ],
 *   "rules": [ {"code":"COOLING_PERIOD_OVER","expression":"#entity['coolingPeriodEndDate'] == null or #daysSince(#entity['coolingPeriodEndDate']) >= 0",
 *               "errorMessage":"Candidate is still in cooling period"} ]
 * }
 * </pre>
 */
public record WorkflowModel(String code,
                            String name,
                            String entityType,
                            String description,
                            List<StateDef> states,
                            List<TransitionDef> transitions,
                            List<RuleDef> rules,
                            Blueprint blueprint) {

    public WorkflowModel {
        states = states == null ? new ArrayList<>() : new ArrayList<>(states);
        transitions = transitions == null ? new ArrayList<>() : new ArrayList<>(transitions);
        rules = rules == null ? new ArrayList<>() : new ArrayList<>(rules);
    }

    /** State-machine-only workflow (no step builder). */
    public WorkflowModel(String code, String name, String entityType, String description, List<StateDef> states,
                         List<TransitionDef> transitions, List<RuleDef> rules) {
        this(code, name, entityType, description, states, transitions, rules, null);
    }

    public WorkflowModel withBlueprint(Blueprint bp) {
        return new WorkflowModel(code, name, entityType, description, states, transitions, rules, bp);
    }

    public WorkflowModel withRules(List<RuleDef> newRules) {
        return new WorkflowModel(code, name, entityType, description, states, transitions, newRules, blueprint);
    }

    // ------------------------------------------------------------------ step builder
    /**
     * The HR-facing definition of a workflow: an ordered list of steps plus a few shared states.
     *
     * @param commonStates     states outside the steps: initial (CREATED), holding (ON HOLD, PIPELINE), rejection
     * @param startFrom        states from which the FIRST step is entered (e.g. CREATED)
     * @param rejectionState   state the token {@code REJECT} resolves to
     * @param steps            ordered hiring steps - add / remove / reorder freely
     * @param globalActions    actions available across steps (Put on hold, Reject, Move to pipeline ...)
     * @param extraTransitions any additional hand-made transitions (e.g. REGISTERED -> CREATED)
     */
    public record Blueprint(List<StateDef> commonStates, List<String> startFrom, String rejectionState,
                            List<StepDef> steps, List<TransitionDef> globalActions,
                            List<TransitionDef> extraTransitions) {
        public Blueprint {
            commonStates = commonStates == null ? new ArrayList<>() : new ArrayList<>(commonStates);
            startFrom = startFrom == null ? new ArrayList<>() : new ArrayList<>(startFrom);
            steps = steps == null ? new ArrayList<>() : new ArrayList<>(steps);
            globalActions = globalActions == null ? new ArrayList<>() : new ArrayList<>(globalActions);
            extraTransitions = extraTransitions == null ? new ArrayList<>() : new ArrayList<>(extraTransitions);
        }

        public Blueprint withSteps(List<StepDef> newSteps) {
            return new Blueprint(commonStates, startFrom, rejectionState, newSteps, globalActions, extraTransitions);
        }

        public Blueprint withCommonStates(List<StateDef> states) {
            return new Blueprint(states, startFrom, rejectionState, steps, globalActions, extraTransitions);
        }

        public Blueprint withExtraTransitions(List<TransitionDef> transitions) {
            return new Blueprint(commonStates, startFrom, rejectionState, steps, globalActions, transitions);
        }
    }

    /**
     * One hiring step. Codes may use the placeholder {@code {STEP}} (replaced by the step code) so library templates
     * can be reused; action guards may use {@code {{param}}} placeholders filled from {@code parameters}.
     *
     * @param type          informational type from the step library (INTERVIEW, ASSESSMENT, APPROVAL, DOCUMENT, OFFER ...)
     * @param optional      optional steps can be skipped: the next step is also enterable from the previous step
     * @param parameters    step settings (passScore, coolingDays, interviewMode ...) used as {@code {{name}}} placeholders
     * @param stages        states inside the step; the first one is the entry state; {@code exit=true} marks "step done"
     * @param entryAction   how a record enters the step from the previous step's exit stages (default: START_{STEP})
     * @param actions       moves inside / out of the step. {@code to} may be a stage, {@code NEXT} (next step),
     *                      {@code REJECT}, {@code STEP:<code>} or any state; {@code from} may be stages, {@code *} (all
     *                      stages of this step), {@code STEP:<code>}, {@code EXITS:<code>} or any state
     * @param templateCode  library template the step was created from (traceability only)
     */
    public record StepDef(String code, String label, String type, String tab, boolean optional, String description,
                          Map<String, Object> parameters, List<StageDef> stages, TransitionDef entryAction,
                          List<TransitionDef> actions, String templateCode) {
        public StepDef {
            parameters = parameters == null ? Map.of() : Collections.unmodifiableMap(new LinkedHashMap<>(parameters));
            stages = stages == null ? List.of() : List.copyOf(stages);
            actions = actions == null ? List.of() : List.copyOf(actions);
        }
    }

    /** A state inside a step. {@code exit=true}: the step is complete when the record is here. */
    public record StageDef(String code, String label, StateCategory category, boolean exit, String tab,
                           Map<String, Object> attributes) {
    }

    public enum StateCategory { INITIAL, INTERMEDIATE, TERMINAL }

    /**
     * @param tab        UI tab / bucket the candidate appears in (APPLICANT, HR_INTERVIEW, ASSESSMENT, PANEL, FINAL_HR, PIPELINE, REJECTED ...)
     * @param attributes free-form metadata (colour, SLA hours, legacy status ...)
     */
    public record StateDef(String code, String label, StateCategory category, String tab, String description,
                           Map<String, Object> attributes) {
    }

    /**
     * @param from                 states the transition can start from
     * @param to                   target state
     * @param allowedRoles         roles allowed to trigger it (empty = any role having the permissions)
     * @param requiredPermissions  permissions required (e.g. APPLICATION:REJECT)
     * @param requiredFields       payload fields that must be present (reasonCode, remarks, interviewDate ...)
     * @param rules                codes of reusable {@link RuleDef}s that must evaluate to true
     * @param guard                optional inline SpEL condition
     * @param requiresApproval     creates an approval request instead of moving immediately
     * @param approverRoles        roles that may approve (empty = anyone with approverPermission)
     * @param approverPermission   permission needed to approve (default WORKFLOW:APPROVE)
     * @param systemOnly           only integrations / schedulers may fire it (e.g. Versant score received)
     */
    public record TransitionDef(String code, String label, List<String> from, String to,
                                Set<String> allowedRoles, Set<String> requiredPermissions, List<String> requiredFields,
                                List<String> rules, String guard, boolean requiresApproval, Set<String> approverRoles,
                                String approverPermission, boolean systemOnly, Map<String, Object> attributes) {

        public TransitionDef {
            from = from == null ? List.of() : List.copyOf(from);
            allowedRoles = allowedRoles == null ? Set.of() : Set.copyOf(allowedRoles);
            requiredPermissions = requiredPermissions == null ? Set.of() : Set.copyOf(requiredPermissions);
            requiredFields = requiredFields == null ? List.of() : List.copyOf(requiredFields);
            rules = rules == null ? List.of() : List.copyOf(rules);
            approverRoles = approverRoles == null ? Set.of() : Set.copyOf(approverRoles);
            attributes = attributes == null ? Map.of() : Collections.unmodifiableMap(new LinkedHashMap<>(attributes));
        }
    }

    /** Reusable named condition (SpEL, evaluated in a sandbox - see {@link RuleEvaluator}). */
    public record RuleDef(String code, String description, String expression, String errorMessage) {
    }

    @JsonIgnore
    public Optional<StateDef> state(String stateCode) {
        return states.stream().filter(s -> s.code().equals(stateCode)).findFirst();
    }

    @JsonIgnore
    public Optional<TransitionDef> transition(String transitionCode) {
        return transitions.stream().filter(t -> t.code().equals(transitionCode)).findFirst();
    }

    @JsonIgnore
    public Optional<RuleDef> rule(String ruleCode) {
        return rules.stream().filter(r -> r.code().equals(ruleCode)).findFirst();
    }

    @JsonIgnore
    public List<TransitionDef> transitionsFrom(String stateCode) {
        return transitions.stream().filter(t -> t.from().contains(stateCode)).toList();
    }
}
