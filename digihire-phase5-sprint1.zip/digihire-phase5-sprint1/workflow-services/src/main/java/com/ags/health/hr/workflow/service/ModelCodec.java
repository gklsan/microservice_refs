package com.ags.health.hr.workflow.service;

import com.ags.health.hr.platform.web.ApiException;
import com.ags.health.hr.workflow.domain.WorkflowVersion;
import com.ags.health.hr.workflow.engine.WorkflowModel;
import com.ags.health.hr.workflow.repo.WorkflowVersionRepository;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.stereotype.Component;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/** JSON (de)serialisation of workflow documents + cache of immutable published versions. */
@Component
public class ModelCodec {

    private final ObjectMapper mapper;
    private final WorkflowVersionRepository versions;
    private final Map<String, WorkflowModel> published = new ConcurrentHashMap<>();

    public ModelCodec(ObjectMapper objectMapper, WorkflowVersionRepository versions) {
        this.mapper = objectMapper.copy().configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        this.versions = versions;
    }

    public WorkflowModel read(String json) {
        try {
            return mapper.readValue(json, WorkflowModel.class);
        } catch (Exception e) {
            throw ApiException.badRequest("INVALID_WORKFLOW_JSON", "Workflow document cannot be parsed: " + e.getMessage());
        }
    }

    public <T> T readValue(String json, Class<T> type) {
        try {
            return mapper.readValue(json, type);
        } catch (Exception e) {
            throw new IllegalArgumentException(e.getMessage(), e);
        }
    }

    public String write(Object value) {
        if (value == null) {
            return null;
        }
        try {
            return mapper.writeValueAsString(value);
        } catch (Exception e) {
            throw new IllegalStateException("Cannot serialise " + value.getClass().getSimpleName(), e);
        }
    }

    public Map<String, Object> readMap(String json) {
        if (json == null || json.isBlank()) {
            return new LinkedHashMap<>();
        }
        try {
            return mapper.readValue(json, new TypeReference<LinkedHashMap<String, Object>>() { });
        } catch (Exception e) {
            return new LinkedHashMap<>();
        }
    }

    /** Published versions never change, so they are cached forever. */
    public WorkflowModel version(String code, int versionNo) {
        return published.computeIfAbsent(code + ":" + versionNo, k -> {
            WorkflowVersion v = versions.findByWorkflowCodeAndVersionNo(code, versionNo)
                    .orElseThrow(() -> ApiException.notFound("Workflow version", code + " v" + versionNo));
            return read(v.getDefinitionJson());
        });
    }
}
