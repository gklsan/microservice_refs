package com.ags.health.hr.workflow.repo;

import com.ags.health.hr.workflow.domain.WorkflowAssignment;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.UUID;

public interface WorkflowAssignmentRepository extends JpaRepository<WorkflowAssignment, UUID> {

    List<WorkflowAssignment> findByEntityTypeAndActiveTrue(String entityType);

    List<WorkflowAssignment> findByWorkflowCodeOrderByCreatedAtDesc(String workflowCode);

    List<WorkflowAssignment> findAllByOrderByEntityTypeAscCreatedAtDesc();
}
