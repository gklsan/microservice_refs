package com.ags.health.hr.workflow.web;

import com.ags.health.hr.platform.security.CurrentUser;
import com.ags.health.hr.workflow.domain.ApprovalRequest;
import com.ags.health.hr.workflow.service.RuntimeService;
import com.ags.health.hr.workflow.web.WorkflowDtos.ApprovalView;
import com.ags.health.hr.workflow.web.WorkflowDtos.DecisionRequest;
import com.ags.health.hr.workflow.web.WorkflowDtos.PageResponse;
import com.ags.health.hr.workflow.web.WorkflowDtos.TransitionResult;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.data.domain.PageRequest;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.UUID;

/** Approval inbox for transitions configured with requiresApproval (e.g. candidate re-initiation). */
@RestController
@RequestMapping("/workflow-approvals")
@Tag(name = "Workflow approvals")
public class ApprovalController {

    private final RuntimeService service;

    public ApprovalController(RuntimeService service) {
        this.service = service;
    }

    @GetMapping
    @Operation(summary = "Approvals; PENDING list is filtered to what the caller may approve")
    public PageResponse<ApprovalView> list(@AuthenticationPrincipal CurrentUser user,
                                           @RequestParam(defaultValue = "PENDING") ApprovalRequest.Status status,
                                           @RequestParam(defaultValue = "0") int page,
                                           @RequestParam(defaultValue = "20") int size) {
        return service.approvals(status, user, PageRequest.of(Math.max(page, 0), Math.min(Math.max(size, 1), 100)));
    }

    @PostMapping("/{id}/approve")
    public TransitionResult approve(@AuthenticationPrincipal CurrentUser user, @PathVariable UUID id,
                                    @RequestBody(required = false) DecisionRequest req) {
        return service.approve(id, req == null ? null : req.remarks(), user);
    }

    @PostMapping("/{id}/reject")
    public ApprovalView reject(@AuthenticationPrincipal CurrentUser user, @PathVariable UUID id,
                               @RequestBody(required = false) DecisionRequest req) {
        return service.reject(id, req == null ? null : req.remarks(), user);
    }
}
