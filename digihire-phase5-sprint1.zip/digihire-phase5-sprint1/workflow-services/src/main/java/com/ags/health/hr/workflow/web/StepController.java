package com.ags.health.hr.workflow.web;

import com.ags.health.hr.workflow.engine.WorkflowModel;
import com.ags.health.hr.workflow.service.StepService;
import com.ags.health.hr.workflow.web.WorkflowDtos.AddStepRequest;
import com.ags.health.hr.workflow.web.WorkflowDtos.DraftResponse;
import com.ags.health.hr.workflow.web.WorkflowDtos.ReorderStepsRequest;
import com.ags.health.hr.workflow.web.WorkflowDtos.StepTemplateRequest;
import com.ags.health.hr.workflow.web.WorkflowDtos.StepTemplateResponse;
import com.ags.health.hr.workflow.web.WorkflowDtos.StepsResponse;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/**
 * Step builder for HR: configure every step of the hiring process (add from the library, edit, make optional,
 * reorder, remove). Changes land in the draft, are compiled into the state machine and validated immediately;
 * publish to make them live (versioned).
 */
@RestController
@Tag(name = "Workflow step builder")
public class StepController {

    private final StepService service;

    public StepController(StepService service) {
        this.service = service;
    }

    // ------------------------------------------------------------------ library
    @GetMapping("/step-library")
    @PreAuthorize("hasAuthority('WORKFLOW:VIEW')")
    @Operation(summary = "Reusable hiring steps: walk-in, assessments (SHL / Moodle / typing), Versant, interview rounds, approvals, document checks, LOI, offer, joining")
    public List<StepTemplateResponse> library() {
        return service.library();
    }

    @GetMapping("/step-library/{code}")
    @PreAuthorize("hasAuthority('WORKFLOW:VIEW')")
    public StepTemplateResponse template(@PathVariable String code) {
        return service.template(code);
    }

    @PutMapping("/step-library/{code}")
    @PreAuthorize("hasAuthority('WORKFLOW:CONFIGURE')")
    @Operation(summary = "Create / update a step template (new step kinds are data, not code)")
    public StepTemplateResponse saveTemplate(@PathVariable String code, @Valid @RequestBody StepTemplateRequest req) {
        return service.saveTemplate(code, req);
    }

    // ------------------------------------------------------------------ steps of a workflow draft
    @GetMapping("/workflows/{code}/draft/steps")
    @PreAuthorize("hasAuthority('WORKFLOW:VIEW')")
    @Operation(summary = "Ordered steps of the draft (+ compile / validation issues)")
    public StepsResponse steps(@PathVariable String code) {
        return service.steps(code);
    }

    @PostMapping("/workflows/{code}/draft/steps")
    @PreAuthorize("hasAuthority('WORKFLOW:CONFIGURE')")
    @Operation(summary = "Add a step from the library (templateCode) or a custom step, at a position")
    public DraftResponse add(@PathVariable String code, @Valid @RequestBody AddStepRequest req) {
        return service.addStep(code, req);
    }

    @PutMapping("/workflows/{code}/draft/steps/{stepCode}")
    @PreAuthorize("hasAuthority('WORKFLOW:CONFIGURE')")
    @Operation(summary = "Edit a step: label, optional, stages, entry action, actions (fields, roles, permissions, rules, approval), parameters")
    public DraftResponse update(@PathVariable String code, @PathVariable String stepCode,
                                @RequestBody WorkflowModel.StepDef step) {
        return service.updateStep(code, stepCode, step);
    }

    @DeleteMapping("/workflows/{code}/draft/steps/{stepCode}")
    @PreAuthorize("hasAuthority('WORKFLOW:CONFIGURE')")
    public DraftResponse remove(@PathVariable String code, @PathVariable String stepCode) {
        return service.removeStep(code, stepCode);
    }

    @PutMapping("/workflows/{code}/draft/steps-order")
    @PreAuthorize("hasAuthority('WORKFLOW:CONFIGURE')")
    @Operation(summary = "Reorder steps (drag & drop)")
    public DraftResponse reorder(@PathVariable String code, @Valid @RequestBody ReorderStepsRequest req) {
        return service.reorder(code, req.order());
    }

    @PutMapping("/workflows/{code}/draft/blueprint")
    @PreAuthorize("hasAuthority('WORKFLOW:CONFIGURE')")
    @Operation(summary = "Replace workflow-level settings: common states, startFrom, rejection state, global actions, extra transitions")
    public DraftResponse blueprint(@PathVariable String code, @RequestBody WorkflowModel.Blueprint blueprint) {
        return service.saveBlueprint(code, blueprint);
    }
}
