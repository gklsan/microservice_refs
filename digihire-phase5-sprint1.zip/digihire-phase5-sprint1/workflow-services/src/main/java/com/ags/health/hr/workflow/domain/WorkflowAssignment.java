package com.ags.health.hr.workflow.domain;

import com.ags.health.hr.platform.jpa.AuditableEntity;
import com.ags.health.hr.workflow.engine.AssignmentMatcher;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.UUID;

/**
 * HR-defined binding "this workflow applies to <job / job role / LOB / location / hiring type>".
 * Unset columns are wildcards; see {@link AssignmentMatcher} for the specificity rules.
 */
@Entity
@Table(name = "workflow_assignment")
@Getter
@Setter
@NoArgsConstructor
public class WorkflowAssignment extends AuditableEntity {

    @Id
    private UUID id;

    @Column(name = "workflow_code", nullable = false)
    private String workflowCode;

    @Column(name = "entity_type", nullable = false)
    private String entityType;

    @Column(name = "job_id")
    private String jobId;

    @Column(name = "job_role")
    private String jobRole;

    private String lob;

    private String location;

    @Column(name = "hiring_type")
    private String hiringType;

    @Column(nullable = false)
    private int priority;

    private String description;

    @Column(nullable = false)
    private boolean active = true;

    public AssignmentMatcher.Candidate asCandidate() {
        WorkflowAssignment self = this;
        return new AssignmentMatcher.Candidate() {
            public String jobId() { return self.jobId; }
            public String jobRole() { return self.jobRole; }
            public String lob() { return self.lob; }
            public String location() { return self.location; }
            public String hiringType() { return self.hiringType; }
            public int priority() { return self.priority; }
            public long createdAtEpochMillis() {
                return self.getCreatedAt() == null ? 0 : self.getCreatedAt().toEpochMilli();
            }
        };
    }
}
