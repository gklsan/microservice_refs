package com.ags.health.hr.workflow.repo;

import com.ags.health.hr.workflow.domain.WorkflowChangeLog;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.UUID;

public interface WorkflowChangeLogRepository extends JpaRepository<WorkflowChangeLog, UUID> {

    List<WorkflowChangeLog> findTop200ByWorkflowCodeOrderByOccurredAtDesc(String workflowCode);
}
