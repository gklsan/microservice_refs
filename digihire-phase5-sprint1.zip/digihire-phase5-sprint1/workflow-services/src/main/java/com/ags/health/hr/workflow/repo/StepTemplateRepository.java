package com.ags.health.hr.workflow.repo;

import com.ags.health.hr.workflow.domain.StepTemplate;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface StepTemplateRepository extends JpaRepository<StepTemplate, String> {

    List<StepTemplate> findByActiveTrueOrderByNameAsc();
}
