package com.ags.health.hr.workflow.domain;

import com.ags.health.hr.platform.jpa.AuditableEntity;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.UUID;

@Entity
@Table(name = "workflow_definition")
@Getter
@Setter
@NoArgsConstructor
public class WorkflowDefinition extends AuditableEntity {

    @Id
    private UUID id;

    @Column(nullable = false, unique = true, updatable = false)
    private String code;

    @Column(nullable = false)
    private String name;

    @Column(name = "entity_type", nullable = false)
    private String entityType;

    private String description;

    /** Version used for new instances. */
    @Column(name = "active_version")
    private Integer activeVersion;

    /** Editable draft JSON; null when there is no pending draft. */
    @Column(name = "draft_json")
    private String draftJson;

    @Column(nullable = false)
    private boolean active = true;
}
