package com.ags.health.hr.workflow.domain;

import com.ags.health.hr.platform.jpa.AuditableEntity;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.Instant;
import java.util.UUID;

/** A transition waiting for an approver (transitions configured with requiresApproval=true). */
@Entity
@Table(name = "approval_request")
@Getter
@Setter
@NoArgsConstructor
public class ApprovalRequest extends AuditableEntity {

    public enum Status { PENDING, APPROVED, REJECTED, CANCELLED }

    @Id
    private UUID id;

    @Column(name = "instance_id", nullable = false)
    private UUID instanceId;

    @Column(name = "entity_type", nullable = false)
    private String entityType;

    @Column(name = "entity_id", nullable = false)
    private String entityId;

    @Column(name = "candidate_id")
    private String candidateId;

    @Column(name = "transition_code", nullable = false)
    private String transitionCode;

    @Column(name = "from_state", nullable = false)
    private String fromState;

    @Column(name = "to_state", nullable = false)
    private String toState;

    @Column(name = "approver_roles")
    private String approverRoles;

    @Column(name = "approver_permission")
    private String approverPermission;

    @Column(name = "requested_by")
    private String requestedBy;

    @Column(name = "requested_by_name")
    private String requestedByName;

    private String remarks;

    @Column(name = "payload_json")
    private String payloadJson;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private Status status = Status.PENDING;

    @Column(name = "decided_by")
    private String decidedBy;

    @Column(name = "decided_by_name")
    private String decidedByName;

    @Column(name = "decided_at")
    private Instant decidedAt;

    @Column(name = "decision_remarks")
    private String decisionRemarks;
}
