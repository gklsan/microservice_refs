package com.ags.health.hr.workflow.domain;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.Instant;
import java.util.UUID;

/** Workflow transition log (tracker #12). Append-only. */
@Entity
@Table(name = "transition_log")
@Getter
@Setter
@NoArgsConstructor
public class TransitionLog {

    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    private UUID id;

    @Column(name = "instance_id", nullable = false, updatable = false)
    private UUID instanceId;

    @Column(name = "workflow_code", nullable = false, updatable = false)
    private String workflowCode;

    @Column(name = "version_no", nullable = false, updatable = false)
    private int versionNo;

    @Column(name = "transition_code", updatable = false)
    private String transitionCode;

    @Column(name = "from_state", updatable = false)
    private String fromState;

    @Column(name = "to_state", nullable = false, updatable = false)
    private String toState;

    @Column(name = "actor_id", updatable = false)
    private String actorId;

    @Column(name = "actor_name", updatable = false)
    private String actorName;

    @Column(name = "actor_roles", updatable = false)
    private String actorRoles;

    @Column(updatable = false)
    private String remarks;

    @Column(name = "payload_json", updatable = false)
    private String payloadJson;

    @Column(name = "approval_id", updatable = false)
    private UUID approvalId;

    @Column(name = "occurred_at", nullable = false, updatable = false)
    private Instant occurredAt;
}
