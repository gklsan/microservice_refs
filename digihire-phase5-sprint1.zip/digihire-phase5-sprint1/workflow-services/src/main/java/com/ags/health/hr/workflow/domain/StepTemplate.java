package com.ags.health.hr.workflow.domain;

import com.ags.health.hr.platform.jpa.AuditableEntity;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/** A reusable hiring step in the step library. */
@Entity
@Table(name = "step_template")
@Getter
@Setter
@NoArgsConstructor
public class StepTemplate extends AuditableEntity {

    @Id
    private String code;

    @Column(nullable = false)
    private String name;

    @Column(name = "step_type", nullable = false)
    private String stepType;

    private String description;

    /** {"step": StepDef, "rules": [RuleDef]} */
    @Column(name = "definition_json", nullable = false)
    private String definitionJson;

    @Column(nullable = false)
    private boolean active = true;
}
