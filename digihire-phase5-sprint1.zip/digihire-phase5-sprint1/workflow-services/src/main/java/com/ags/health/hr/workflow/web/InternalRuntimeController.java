package com.ags.health.hr.workflow.web;

import com.ags.health.hr.platform.security.CurrentUserProvider;
import com.ags.health.hr.workflow.service.RuntimeService;
import com.ags.health.hr.workflow.web.WorkflowDtos.InstanceView;
import com.ags.health.hr.workflow.web.WorkflowDtos.MoveRequest;
import com.ags.health.hr.workflow.web.WorkflowDtos.StartRequest;
import com.ags.health.hr.workflow.web.WorkflowDtos.TransitionRequest;
import com.ags.health.hr.workflow.web.WorkflowDtos.TransitionResult;
import io.swagger.v3.oas.annotations.Hidden;
import jakarta.validation.Valid;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * System calls (X-Internal-Key): candidate-services, Versant/Moodle crons, Oracle webhooks.
 * Acts as SYSTEM: may fire systemOnly transitions; state validity and rules are still enforced.
 */
@Hidden
@RestController
@RequestMapping("/internal/runtime/instances")
public class InternalRuntimeController {

    private final RuntimeService service;

    public InternalRuntimeController(RuntimeService service) {
        this.service = service;
    }

    @PostMapping
    public InstanceView start(@Valid @RequestBody StartRequest req) {
        return service.start(req, CurrentUserProvider.currentOrSystem());
    }

    @GetMapping("/{entityType}/{entityId}")
    public InstanceView get(@PathVariable String entityType, @PathVariable String entityId) {
        return service.get(entityType, entityId, CurrentUserProvider.currentOrSystem());
    }

    @PostMapping("/{entityType}/{entityId}/transitions/{transitionCode}")
    public TransitionResult transition(@PathVariable String entityType, @PathVariable String entityId,
                                       @PathVariable String transitionCode,
                                       @RequestBody(required = false) TransitionRequest req) {
        TransitionRequest body = req == null ? new TransitionRequest(null, null, null) : req;
        return service.transition(entityType, entityId, transitionCode, body, CurrentUserProvider.currentOrSystem());
    }

    @PostMapping("/{entityType}/{entityId}/move")
    public TransitionResult move(@PathVariable String entityType, @PathVariable String entityId,
                                 @Valid @RequestBody MoveRequest req) {
        return service.move(entityType, entityId, req, CurrentUserProvider.currentOrSystem());
    }
}
