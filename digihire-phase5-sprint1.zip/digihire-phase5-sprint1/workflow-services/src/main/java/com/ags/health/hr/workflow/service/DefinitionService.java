package com.ags.health.hr.workflow.service;

import com.ags.health.hr.platform.security.CurrentUserProvider;
import com.ags.health.hr.platform.web.ApiException;
import com.ags.health.hr.workflow.domain.WorkflowDefinition;
import com.ags.health.hr.workflow.domain.WorkflowVersion;
import com.ags.health.hr.workflow.engine.RuleEvaluator;
import com.ags.health.hr.workflow.engine.StepCompiler;
import com.ags.health.hr.workflow.engine.WorkflowDiff;
import com.ags.health.hr.workflow.engine.WorkflowModel;
import com.ags.health.hr.workflow.engine.WorkflowModel.RuleDef;
import com.ags.health.hr.workflow.engine.WorkflowModel.StateDef;
import com.ags.health.hr.workflow.engine.WorkflowModel.TransitionDef;
import com.ags.health.hr.workflow.engine.WorkflowValidator;
import com.ags.health.hr.workflow.repo.WorkflowChangeLogRepository;
import com.ags.health.hr.workflow.repo.WorkflowDefinitionRepository;
import com.ags.health.hr.workflow.repo.WorkflowInstanceRepository;
import com.ags.health.hr.workflow.repo.WorkflowVersionRepository;
import com.ags.health.hr.workflow.web.WorkflowDtos.ChangeLogEntry;
import com.ags.health.hr.workflow.web.WorkflowDtos.CreateWorkflowRequest;
import com.ags.health.hr.workflow.web.WorkflowDtos.DraftResponse;
import com.ags.health.hr.workflow.web.WorkflowDtos.RuleTestRequest;
import com.ags.health.hr.workflow.web.WorkflowDtos.RuleTestResponse;
import com.ags.health.hr.workflow.web.WorkflowDtos.StateView;
import com.ags.health.hr.workflow.web.WorkflowDtos.VersionSummary;
import com.ags.health.hr.workflow.web.WorkflowDtos.WorkflowSummary;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.function.Function;
import java.util.function.UnaryOperator;

/**
 * Admin / HR configuration of workflows: states (#26), transitions (#27), rules (#28), versioning (#29),
 * change logging (#30) and invalid-state validation (#31).
 *
 * <p>Life-cycle: every workflow has at most one editable DRAFT; publishing freezes it into version N+1
 * (immutable) and - by default - makes it the active version for NEW records. Records already running keep
 * the version they started with. Older versions can be re-activated (rollback).
 */
@Service
@Transactional
public class DefinitionService {

    private final WorkflowDefinitionRepository definitions;
    private final WorkflowVersionRepository versions;
    private final WorkflowInstanceRepository instances;
    private final WorkflowChangeLogRepository changeLogs;
    private final ModelCodec codec;
    private final WorkflowValidator validator;
    private final RuleEvaluator ruleEvaluator;
    private final ChangeLogger changeLogger;

    public DefinitionService(WorkflowDefinitionRepository definitions, WorkflowVersionRepository versions,
                             WorkflowInstanceRepository instances, WorkflowChangeLogRepository changeLogs,
                             ModelCodec codec, WorkflowValidator validator, RuleEvaluator ruleEvaluator,
                             ChangeLogger changeLogger) {
        this.definitions = definitions;
        this.versions = versions;
        this.instances = instances;
        this.changeLogs = changeLogs;
        this.codec = codec;
        this.validator = validator;
        this.ruleEvaluator = ruleEvaluator;
        this.changeLogger = changeLogger;
    }

    // ------------------------------------------------------------------ definitions
    public WorkflowSummary create(CreateWorkflowRequest req) {
        if (definitions.existsByCode(req.code())) {
            throw ApiException.conflict("WORKFLOW_EXISTS", "Workflow already exists: " + req.code());
        }
        WorkflowModel draft;
        if (req.copyFrom() != null && !req.copyFrom().isBlank()) {
            WorkflowModel source = activeModel(req.copyFrom());
            draft = new WorkflowModel(req.code(), req.name(), req.entityType(), req.description(),
                    source.states(), source.transitions(), source.rules(), source.blueprint());
        } else {
            // start as an empty step-based workflow so HR can add steps from the library straight away
            draft = new WorkflowModel(req.code(), req.name(), req.entityType(), req.description(),
                    List.of(), List.of(), List.of(), new WorkflowModel.Blueprint(null, null, null, null, null, null));
        }
        WorkflowDefinition d = new WorkflowDefinition();
        d.setId(UUID.randomUUID());
        d.setCode(req.code());
        d.setName(req.name());
        d.setEntityType(req.entityType());
        d.setDescription(req.description());
        d.setDraftJson(codec.write(draft));
        definitions.save(d);
        changeLogger.log(d.getCode(), "CREATED", null, Map.of("copyFrom", String.valueOf(req.copyFrom())));
        return toSummary(d);
    }

    @Transactional(readOnly = true)
    public List<WorkflowSummary> list() {
        return definitions.findAllByOrderByCodeAsc().stream().map(this::toSummary).toList();
    }

    @Transactional(readOnly = true)
    public WorkflowSummary summary(String code) {
        return toSummary(definition(code));
    }

    @Transactional(readOnly = true)
    public List<VersionSummary> versions(String code) {
        WorkflowDefinition d = definition(code);
        return versions.findByWorkflowCodeOrderByVersionNoDesc(code).stream()
                .map(v -> new VersionSummary(v.getVersionNo(), v.getChangeSummary(), v.getPublishedBy(),
                        v.getPublishedAt(), Integer.valueOf(v.getVersionNo()).equals(d.getActiveVersion()),
                        instances.countByWorkflowCodeAndVersionNo(code, v.getVersionNo())))
                .toList();
    }

    @Transactional(readOnly = true)
    public WorkflowModel versionModel(String code, int versionNo) {
        return codec.version(code, versionNo);
    }

    @Transactional(readOnly = true)
    public WorkflowModel activeModel(String code) {
        WorkflowDefinition d = definition(code);
        if (d.getActiveVersion() == null) {
            throw ApiException.conflict("NOT_PUBLISHED", "Workflow " + code + " has no published version yet");
        }
        return codec.version(code, d.getActiveVersion());
    }

    /** States of the active version - used by list screens (status filter options). */
    @Transactional(readOnly = true)
    public List<StateView> activeStates(String code) {
        return activeModel(code).states().stream()
                .map(s -> new StateView(s.code(), s.label(), s.category(), s.tab())).toList();
    }

    // ------------------------------------------------------------------ draft editing
    @Transactional(readOnly = true)
    public DraftResponse draft(String code) {
        WorkflowDefinition d = definition(code);
        WorkflowModel model = currentDraft(d);
        return new DraftResponse(model, d.getDraftJson() != null, check(model));
    }

    public DraftResponse saveDraft(String code, WorkflowModel model) {
        WorkflowDefinition d = definition(code);
        WorkflowModel normalised = new WorkflowModel(d.getCode(), model.name() != null ? model.name() : d.getName(),
                d.getEntityType(), model.description(), model.states(), model.transitions(), model.rules(),
                model.blueprint());
        return storeDraft(d, normalised, "DRAFT_UPDATED");
    }

    public DraftResponse upsertState(String code, StateDef state) {
        return editDraft(code, m -> m.blueprint() != null
                ? m.withBlueprint(m.blueprint().withCommonStates(replaceIn(m.blueprint().commonStates(), state, StateDef::code)))
                : replace(m, m.states(), state, StateDef::code, "states"));
    }

    public DraftResponse deleteState(String code, String stateCode) {
        return editDraft(code, m -> {
            List<String> usedBy = m.transitions().stream()
                    .filter(t -> stateCode.equals(t.to()) || t.from().contains(stateCode))
                    .map(TransitionDef::code).toList();
            if (!usedBy.isEmpty()) {
                throw ApiException.conflict("STATE_IN_USE", "State " + stateCode + " is used by transitions " + usedBy);
            }
            if (m.blueprint() != null) {
                return m.withBlueprint(m.blueprint().withCommonStates(
                        removeFrom(m.blueprint().commonStates(), stateCode, StateDef::code, "common state")));
            }
            return remove(m, m.states(), stateCode, StateDef::code, "states");
        });
    }

    public DraftResponse upsertTransition(String code, TransitionDef transition) {
        return editDraft(code, m -> m.blueprint() != null
                ? m.withBlueprint(m.blueprint().withExtraTransitions(
                        replaceIn(m.blueprint().extraTransitions(), transition, TransitionDef::code)))
                : replace(m, m.transitions(), transition, TransitionDef::code, "transitions"));
    }

    public DraftResponse deleteTransition(String code, String transitionCode) {
        return editDraft(code, m -> m.blueprint() != null
                ? m.withBlueprint(m.blueprint().withExtraTransitions(removeFrom(m.blueprint().extraTransitions(),
                        transitionCode, TransitionDef::code, "extra transition (step actions are edited on the step)")))
                : remove(m, m.transitions(), transitionCode, TransitionDef::code, "transitions"));
    }

    public DraftResponse upsertRule(String code, RuleDef rule) {
        return editDraft(code, m -> replace(m, m.rules(), rule, RuleDef::code, "rules"));
    }

    public DraftResponse deleteRule(String code, String ruleCode) {
        return editDraft(code, m -> {
            List<String> usedBy = m.transitions().stream().filter(t -> t.rules().contains(ruleCode))
                    .map(TransitionDef::code).toList();
            if (!usedBy.isEmpty()) {
                throw ApiException.conflict("RULE_IN_USE", "Rule " + ruleCode + " is used by transitions " + usedBy);
            }
            return remove(m, m.rules(), ruleCode, RuleDef::code, "rules");
        });
    }

    public void discardDraft(String code) {
        WorkflowDefinition d = definition(code);
        if (d.getActiveVersion() == null) {
            throw ApiException.conflict("NOT_PUBLISHED", "Cannot discard the only definition of an unpublished workflow");
        }
        d.setDraftJson(null);
        changeLogger.log(code, "DRAFT_DISCARDED", null, Map.of());
    }

    @Transactional(readOnly = true)
    public List<WorkflowValidator.Issue> validateDraft(String code) {
        return check(currentDraft(definition(code)));
    }

    // ------------------------------------------------------------------ versioning
    public VersionSummary publish(String code, String changeSummary, boolean activate) {
        WorkflowDefinition d = definition(code);
        if (d.getDraftJson() == null) {
            throw ApiException.conflict("NO_DRAFT", "There is no draft to publish for " + code);
        }
        WorkflowModel draft = codec.read(d.getDraftJson());
        List<WorkflowValidator.Issue> issues = check(draft);
        if (WorkflowValidator.hasErrors(issues)) {
            throw new ApiException(HttpStatus.UNPROCESSABLE_ENTITY, "WORKFLOW_INVALID",
                    "Draft has validation errors and cannot be published", issues);
        }
        int next = versions.maxVersion(code) + 1;
        WorkflowVersion v = new WorkflowVersion();
        v.setWorkflowCode(code);
        v.setVersionNo(next);
        v.setDefinitionJson(d.getDraftJson());
        v.setChangeSummary(changeSummary);
        v.setPublishedBy(CurrentUserProvider.currentOrSystem().email());
        v.setPublishedAt(Instant.now());
        versions.save(v);

        WorkflowModel previous = d.getActiveVersion() == null ? null : codec.version(code, d.getActiveVersion());
        d.setDraftJson(null);
        if (activate) {
            d.setActiveVersion(next);
        }
        changeLogger.log(code, "PUBLISHED", next, Map.of("changeSummary", changeSummary, "activated", activate,
                "diffAgainstActive", WorkflowDiff.between(previous, draft)));
        return new VersionSummary(next, changeSummary, v.getPublishedBy(), v.getPublishedAt(), activate, 0);
    }

    /** Make an existing version the active one for new records (rollback / roll-forward). */
    public WorkflowSummary activate(String code, int versionNo) {
        WorkflowDefinition d = definition(code);
        versions.findByWorkflowCodeAndVersionNo(code, versionNo)
                .orElseThrow(() -> ApiException.notFound("Workflow version", code + " v" + versionNo));
        Integer before = d.getActiveVersion();
        d.setActiveVersion(versionNo);
        changeLogger.log(code, "ACTIVATED", versionNo, Map.of("previousActive", String.valueOf(before)));
        return toSummary(d);
    }

    @Transactional(readOnly = true)
    public Map<String, Object> compare(String code, int from, int to) {
        return WorkflowDiff.between(codec.version(code, from), codec.version(code, to));
    }

    @Transactional(readOnly = true)
    public List<ChangeLogEntry> changes(String code) {
        definition(code);
        return changeLogs.findTop200ByWorkflowCodeOrderByOccurredAtDesc(code).stream()
                .map(c -> new ChangeLogEntry(c.getAction(), c.getVersionNo(), c.getActor(),
                        codec.readMap(c.getDetailsJson()), c.getOccurredAt()))
                .toList();
    }

    /** Rule builder "test" button: evaluates an expression against sample data. */
    public RuleTestResponse testRule(RuleTestRequest req) {
        try {
            ruleEvaluator.validateSyntax(req.expression());
            boolean result = ruleEvaluator.evaluate(req.expression(), new RuleEvaluator.RuleContext(
                    req.entity(), req.payload(), req.actor(), Map.of(), req.config()));
            return new RuleTestResponse(true, result, null);
        } catch (RuntimeException e) {
            return new RuleTestResponse(false, null, e.getMessage());
        }
    }

    // ------------------------------------------------------------------ helpers
    public WorkflowDefinition definition(String code) {
        return definitions.findByCode(code).orElseThrow(() -> ApiException.notFound("Workflow", code));
    }

    private WorkflowModel currentDraft(WorkflowDefinition d) {
        if (d.getDraftJson() != null) {
            return codec.read(d.getDraftJson());
        }
        if (d.getActiveVersion() != null) {
            return codec.version(d.getCode(), d.getActiveVersion());
        }
        return new WorkflowModel(d.getCode(), d.getName(), d.getEntityType(), d.getDescription(),
                List.of(), List.of(), List.of());
    }

    /** Draft edited through the step builder (used by StepService). */
    public DraftResponse editDraftModel(String code, UnaryOperator<WorkflowModel> edit) {
        return editDraft(code, edit);
    }

    /** Compile issues (step builder) + validation issues of the compiled state machine. */
    private List<WorkflowValidator.Issue> check(WorkflowModel model) {
        StepCompiler.Result compiled = StepCompiler.compile(model);
        List<WorkflowValidator.Issue> issues = new ArrayList<>(compiled.issues());
        issues.addAll(validator.validate(compiled.model()));
        return issues;
    }

    private DraftResponse editDraft(String code, UnaryOperator<WorkflowModel> edit) {
        WorkflowDefinition d = definition(code);
        return storeDraft(d, edit.apply(currentDraft(d)), "DRAFT_UPDATED");
    }

    private DraftResponse storeDraft(WorkflowDefinition d, WorkflowModel input, String action) {
        // step-based drafts are re-compiled on every save, so states/transitions always mirror the steps
        StepCompiler.Result compiled = StepCompiler.compile(input);
        WorkflowModel model = compiled.model();
        d.setDraftJson(codec.write(model));
        WorkflowModel active = d.getActiveVersion() == null ? null : codec.version(d.getCode(), d.getActiveVersion());
        changeLogger.log(d.getCode(), action, null, Map.of("diffAgainstActive", WorkflowDiff.between(active, model)));
        List<WorkflowValidator.Issue> issues = new ArrayList<>(compiled.issues());
        issues.addAll(validator.validate(model));
        return new DraftResponse(model, true, issues);
    }

    private static <T> WorkflowModel replace(WorkflowModel m, List<T> list, T item, Function<T, String> key, String part) {
        List<T> copy = new ArrayList<>(list);
        String k = key.apply(item);
        if (k == null || k.isBlank()) {
            throw ApiException.badRequest("CODE_REQUIRED", "code is required");
        }
        boolean replaced = false;
        for (int i = 0; i < copy.size(); i++) {
            if (k.equals(key.apply(copy.get(i)))) {
                copy.set(i, item);
                replaced = true;
            }
        }
        if (!replaced) {
            copy.add(item);
        }
        return with(m, part, copy);
    }

    static <T> List<T> replaceIn(List<T> list, T item, Function<T, String> key) {
        String k = key.apply(item);
        if (k == null || k.isBlank()) {
            throw ApiException.badRequest("CODE_REQUIRED", "code is required");
        }
        List<T> copy = new ArrayList<>(list);
        boolean replaced = false;
        for (int i = 0; i < copy.size(); i++) {
            if (k.equals(key.apply(copy.get(i)))) {
                copy.set(i, item);
                replaced = true;
            }
        }
        if (!replaced) {
            copy.add(item);
        }
        return copy;
    }

    static <T> List<T> removeFrom(List<T> list, String code, Function<T, String> key, String what) {
        List<T> copy = new ArrayList<>(list);
        if (!copy.removeIf(x -> code.equals(key.apply(x)))) {
            throw ApiException.notFound(what, code);
        }
        return copy;
    }

    private static <T> WorkflowModel remove(WorkflowModel m, List<T> list, String code, Function<T, String> key, String part) {
        List<T> copy = new ArrayList<>(list);
        if (!copy.removeIf(x -> code.equals(key.apply(x)))) {
            throw ApiException.notFound(part, code);
        }
        return with(m, part, copy);
    }

    @SuppressWarnings("unchecked")
    private static WorkflowModel with(WorkflowModel m, String part, List<?> items) {
        return switch (part) {
            case "states" -> new WorkflowModel(m.code(), m.name(), m.entityType(), m.description(),
                    (List<StateDef>) items, m.transitions(), m.rules(), m.blueprint());
            case "transitions" -> new WorkflowModel(m.code(), m.name(), m.entityType(), m.description(),
                    m.states(), (List<TransitionDef>) items, m.rules(), m.blueprint());
            default -> new WorkflowModel(m.code(), m.name(), m.entityType(), m.description(),
                    m.states(), m.transitions(), (List<RuleDef>) items, m.blueprint());
        };
    }

    private WorkflowSummary toSummary(WorkflowDefinition d) {
        return new WorkflowSummary(d.getCode(), d.getName(), d.getEntityType(), d.getDescription(),
                d.getActiveVersion(), versions.maxVersion(d.getCode()), d.getDraftJson() != null, d.isActive(),
                d.getUpdatedAt() != null ? d.getUpdatedAt() : d.getCreatedAt(),
                d.getUpdatedBy() != null ? d.getUpdatedBy() : d.getCreatedBy());
    }
}
