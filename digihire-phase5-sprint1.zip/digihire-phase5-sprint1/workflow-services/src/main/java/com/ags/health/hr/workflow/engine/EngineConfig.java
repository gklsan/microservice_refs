package com.ags.health.hr.workflow.engine;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration(proxyBeanMethods = false)
public class EngineConfig {

    @Bean
    RuleEvaluator ruleEvaluator() {
        return new RuleEvaluator();
    }

    @Bean
    WorkflowEngine workflowEngine(RuleEvaluator ruleEvaluator) {
        return new WorkflowEngine(ruleEvaluator);
    }

    @Bean
    WorkflowValidator workflowValidator(RuleEvaluator ruleEvaluator) {
        return new WorkflowValidator(ruleEvaluator);
    }
}
