package com.ags.health.hr.workflow.service;

import com.ags.health.hr.platform.audit.AuditCategory;
import com.ags.health.hr.platform.audit.AuditEvent;
import com.ags.health.hr.platform.audit.AuditLogger;
import com.ags.health.hr.platform.security.CurrentUser;
import com.ags.health.hr.platform.security.CurrentUserProvider;
import com.ags.health.hr.workflow.domain.WorkflowChangeLog;
import com.ags.health.hr.workflow.repo.WorkflowChangeLogRepository;
import org.springframework.stereotype.Component;

import java.time.Instant;
import java.util.Map;

/** Workflow change logging (tracker #30): local table + central audit log (CONFIG_CHANGE). */
@Component
public class ChangeLogger {

    private final WorkflowChangeLogRepository repo;
    private final ModelCodec codec;
    private final AuditLogger audit;

    public ChangeLogger(WorkflowChangeLogRepository repo, ModelCodec codec, AuditLogger audit) {
        this.repo = repo;
        this.codec = codec;
        this.audit = audit;
    }

    public void log(String workflowCode, String action, Integer versionNo, Map<String, ?> details) {
        CurrentUser user = CurrentUserProvider.currentOrSystem();
        WorkflowChangeLog entry = new WorkflowChangeLog();
        entry.setWorkflowCode(workflowCode);
        entry.setAction(action);
        entry.setVersionNo(versionNo);
        entry.setActor(user.email() != null ? user.email() : user.name());
        entry.setDetailsJson(codec.write(details));
        entry.setOccurredAt(Instant.now());
        repo.save(entry);
        audit.log(AuditEvent.builder(AuditCategory.CONFIG_CHANGE, "WORKFLOW_" + action)
                .entity("WORKFLOW", workflowCode)
                .detail("versionNo", versionNo)
                .details(details)
                .build());
    }
}
