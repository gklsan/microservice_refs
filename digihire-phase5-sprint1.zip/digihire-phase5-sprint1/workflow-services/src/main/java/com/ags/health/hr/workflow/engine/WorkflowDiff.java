package com.ags.health.hr.workflow.engine;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.TreeSet;
import java.util.function.Function;
import java.util.stream.Collectors;

/** Human-readable change summary between two versions - stored in the workflow change log (tracker #30). */
public final class WorkflowDiff {

    private WorkflowDiff() {
    }

    public static Map<String, Object> between(WorkflowModel before, WorkflowModel after) {
        Map<String, Object> diff = new LinkedHashMap<>();
        diff.put("states", section(before == null ? List.of() : before.states(), after.states(), WorkflowModel.StateDef::code));
        diff.put("transitions", section(before == null ? List.of() : before.transitions(), after.transitions(),
                WorkflowModel.TransitionDef::code));
        diff.put("rules", section(before == null ? List.of() : before.rules(), after.rules(), WorkflowModel.RuleDef::code));
        return diff;
    }

    private static <T> Map<String, Set<String>> section(List<T> before, List<T> after, Function<T, String> key) {
        Map<String, T> b = before.stream().collect(Collectors.toMap(key, x -> x, (x, y) -> y));
        Map<String, T> a = after.stream().collect(Collectors.toMap(key, x -> x, (x, y) -> y));
        Set<String> added = new TreeSet<>(a.keySet());
        added.removeAll(b.keySet());
        Set<String> removed = new TreeSet<>(b.keySet());
        removed.removeAll(a.keySet());
        Set<String> modified = a.keySet().stream()
                .filter(b::containsKey)
                .filter(k -> !Objects.equals(a.get(k), b.get(k)))
                .collect(Collectors.toCollection(TreeSet::new));
        Map<String, Set<String>> result = new LinkedHashMap<>();
        result.put("added", added);
        result.put("removed", removed);
        result.put("modified", modified);
        return result;
    }
}
