package com.ags.health.hr.workflow.service;

import com.ags.health.hr.platform.audit.AuditCategory;
import com.ags.health.hr.platform.audit.AuditEvent;
import com.ags.health.hr.platform.audit.AuditLogger;
import com.ags.health.hr.platform.security.AccessEvaluator;
import com.ags.health.hr.platform.security.CurrentUser;
import com.ags.health.hr.platform.web.ApiException;
import com.ags.health.hr.workflow.domain.ApprovalRequest;
import com.ags.health.hr.workflow.domain.TransitionLog;
import com.ags.health.hr.workflow.domain.WorkflowInstance;
import com.ags.health.hr.workflow.engine.WorkflowEngine;
import com.ags.health.hr.workflow.engine.WorkflowEngine.Actor;
import com.ags.health.hr.workflow.engine.WorkflowEngine.Decision;
import com.ags.health.hr.workflow.engine.WorkflowEngine.Violation;
import com.ags.health.hr.workflow.engine.WorkflowModel;
import com.ags.health.hr.workflow.engine.WorkflowModel.StateDef;
import com.ags.health.hr.workflow.engine.WorkflowModel.TransitionDef;
import com.ags.health.hr.workflow.repo.ApprovalRequestRepository;
import com.ags.health.hr.workflow.repo.TransitionLogRepository;
import com.ags.health.hr.workflow.repo.WorkflowInstanceRepository;
import com.ags.health.hr.workflow.web.WorkflowDtos.ApprovalView;
import com.ags.health.hr.workflow.web.WorkflowDtos.HistoryEntry;
import com.ags.health.hr.workflow.web.WorkflowDtos.InstanceView;
import com.ags.health.hr.workflow.web.WorkflowDtos.MoveRequest;
import com.ags.health.hr.workflow.web.WorkflowDtos.PageResponse;
import com.ags.health.hr.workflow.web.WorkflowDtos.ResolveResponse;
import com.ags.health.hr.workflow.web.WorkflowDtos.StartRequest;
import com.ags.health.hr.workflow.web.WorkflowDtos.TransitionRequest;
import com.ags.health.hr.workflow.web.WorkflowDtos.TransitionResult;
import com.ags.health.hr.workflow.web.WorkflowDtos.ValidateRequest;
import com.ags.health.hr.workflow.web.WorkflowDtos.ValidateResponse;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.Instant;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;

/**
 * Runtime side of the engine: starts records on the right workflow, moves them through transitions, parks
 * transitions that need approval, and records everything (transition log + central audit + notification event).
 */
@Service
@Transactional
public class RuntimeService {

    private final WorkflowInstanceRepository instances;
    private final TransitionLogRepository logs;
    private final ApprovalRequestRepository approvals;
    private final AssignmentService assignments;
    private final ModelCodec codec;
    private final WorkflowEngine engine;
    private final ConfigValues config;
    private final AuditLogger audit;
    private final ApplicationEventPublisher events;

    public RuntimeService(WorkflowInstanceRepository instances, TransitionLogRepository logs,
                          ApprovalRequestRepository approvals, AssignmentService assignments, ModelCodec codec,
                          WorkflowEngine engine, ConfigValues config, AuditLogger audit,
                          ApplicationEventPublisher events) {
        this.instances = instances;
        this.logs = logs;
        this.approvals = approvals;
        this.assignments = assignments;
        this.codec = codec;
        this.engine = engine;
        this.config = config;
        this.audit = audit;
        this.events = events;
    }

    /** Published after commit to notification-engine (see {@link TransitionNotifier}). */
    public record TransitionCompleted(UUID eventId, String workflowCode, int versionNo, String transitionCode,
                                      String fromState, String toState, String entityType, String entityId,
                                      String candidateId, String actorId, String actorName, String actorEmail,
                                      String remarks, Map<String, Object> context, Map<String, Object> payload,
                                      Instant occurredAt) {
    }

    // ------------------------------------------------------------------ start
    public InstanceView start(StartRequest req, CurrentUser user) {
        Optional<WorkflowInstance> existing = instances.findByEntityTypeAndEntityId(req.entityType(), req.entityId());
        if (existing.isPresent() && !req.restart()) {
            checkScope(existing.get(), codec.readMap(existing.get().getContextJson()), user, actor(user));
            return view(existing.get(), user); // idempotent
        }
        if (existing.isPresent() && !actor(user).system() && !user.hasPermission("WORKFLOW:ASSIGN")) {
            throw ApiException.forbidden("Restarting a record's workflow (re-mapping) requires WORKFLOW:ASSIGN");
        }
        String workflowCode;
        Integer versionNo;
        UUID assignmentId = null;
        if (req.workflowCode() != null && !req.workflowCode().isBlank()) {
            if (!actor(user).system() && !user.hasPermission("WORKFLOW:ASSIGN")) {
                throw ApiException.forbidden("Choosing a workflow explicitly requires WORKFLOW:ASSIGN");
            }
            workflowCode = req.workflowCode();
            versionNo = assignments.activeVersion(workflowCode);
        } else {
            ResolveResponse resolved = assignments.resolve(req.entityType(), req.criteria());
            workflowCode = resolved.workflowCode();
            versionNo = resolved.versionNo();
            assignmentId = resolved.assignmentId();
        }
        if (versionNo == null) {
            throw ApiException.conflict("NOT_PUBLISHED", "Workflow " + workflowCode + " has no active version");
        }
        WorkflowModel model = codec.version(workflowCode, versionNo);
        String initial = initialState(model, req.initialState());

        WorkflowInstance i = existing.orElseGet(WorkflowInstance::new);
        String previousState = existing.map(WorkflowInstance::getCurrentState).orElse(null);
        if (existing.isEmpty()) {
            i.setId(UUID.randomUUID());
            i.setEntityType(req.entityType());
            i.setEntityId(req.entityId());
        }
        i.setWorkflowCode(workflowCode);
        i.setVersionNo(versionNo);
        i.setCandidateId(req.candidateId() != null ? req.candidateId() : i.getCandidateId());
        i.setCurrentState(initial);
        i.setAssignmentId(assignmentId);
        i.setCriteriaJson(codec.write(req.criteria()));
        i.setContextJson(codec.write(merge(codec.readMap(i.getContextJson()), req.context())));
        instances.save(i);

        String code = existing.isPresent() ? "RESTART" : "START";
        record(i, model, code, previousState, initial, actor(user), user, req.remarks(), Map.of(), null);
        return view(i, user);
    }

    // ------------------------------------------------------------------ read
    @Transactional(readOnly = true)
    public InstanceView get(String entityType, String entityId, CurrentUser user) {
        WorkflowInstance i = instance(entityType, entityId);
        checkScope(i, codec.readMap(i.getContextJson()), user, actor(user));
        return view(i, user);
    }

    @Transactional(readOnly = true)
    public List<HistoryEntry> history(String entityType, String entityId, CurrentUser user) {
        WorkflowInstance i = instance(entityType, entityId);
        checkScope(i, codec.readMap(i.getContextJson()), user, actor(user));
        return logs.findByInstanceIdOrderByOccurredAtAsc(i.getId()).stream()
                .map(l -> new HistoryEntry(l.getTransitionCode(), l.getFromState(), l.getToState(), l.getActorId(),
                        l.getActorName(), l.getRemarks(), codec.readMap(l.getPayloadJson()), l.getApprovalId(),
                        l.getVersionNo(), l.getOccurredAt()))
                .toList();
    }

    /** Dry run - "invalid workflow state validation" at runtime (tracker #31). */
    @Transactional(readOnly = true)
    public ValidateResponse validate(String entityType, String entityId, ValidateRequest req, CurrentUser user) {
        WorkflowInstance i = instance(entityType, entityId);
        WorkflowModel model = codec.version(i.getWorkflowCode(), i.getVersionNo());
        checkScope(i, codec.readMap(i.getContextJson()), user, actor(user)); // stored context, not caller input
        Map<String, Object> entity = merge(codec.readMap(i.getContextJson()), req.context());
        String code = req.transitionCode();
        if (code == null && req.toState() != null) {
            List<TransitionDef> candidates = engine.findByTarget(model, i.getCurrentState(), req.toState());
            if (candidates.isEmpty()) {
                return new ValidateResponse(false, false, null, List.of(invalidTarget(model, i.getCurrentState(), req.toState())));
            }
            code = candidates.get(0).code();
        }
        if (code == null) {
            throw ApiException.badRequest("TARGET_REQUIRED", "transitionCode or toState is required");
        }
        Decision d = engine.decide(model, i.getCurrentState(), code, actor(user), entity, req.payload(), config.get(), true);
        return new ValidateResponse(d.allowed(), d.requiresApproval(), code, d.violations());
    }

    // ------------------------------------------------------------------ transitions
    public TransitionResult transition(String entityType, String entityId, String transitionCode,
                                       TransitionRequest req, CurrentUser user) {
        WorkflowInstance i = instance(entityType, entityId);
        return execute(i, transitionCode, req.remarks(), req.payload(), req.context(), user);
    }

    /**
     * Status-based integration for existing code (candidate-services sets an ApplicationStatus): finds the
     * configured transition current -> target and executes it; rejects moves the workflow does not allow.
     */
    public TransitionResult move(String entityType, String entityId, MoveRequest req, CurrentUser user) {
        WorkflowInstance i = instance(entityType, entityId);
        if (req.toState().equals(i.getCurrentState())) {
            return new TransitionResult(TransitionResult.NO_CHANGE, view(i, user), null);
        }
        WorkflowModel model = codec.version(i.getWorkflowCode(), i.getVersionNo());
        List<TransitionDef> candidates = engine.findByTarget(model, i.getCurrentState(), req.toState());
        if (candidates.isEmpty()) {
            Violation v = invalidTarget(model, i.getCurrentState(), req.toState());
            throw new ApiException(HttpStatus.CONFLICT, "INVALID_TRANSITION", v.message(), List.of(v));
        }
        Actor actor = actor(user);
        checkScope(i, codec.readMap(i.getContextJson()), user, actor);
        Map<String, Object> entity = merge(codec.readMap(i.getContextJson()), req.context());
        Decision first = null;
        for (TransitionDef t : candidates) {
            Decision d = engine.decide(model, i.getCurrentState(), t.code(), actor, entity, req.payload(), config.get(), true);
            if (d.allowed()) {
                return execute(i, t.code(), req.remarks(), req.payload(), req.context(), user);
            }
            first = first == null ? d : first;
        }
        throw rejected(first);
    }

    // ------------------------------------------------------------------ approvals
    @Transactional(readOnly = true)
    public PageResponse<ApprovalView> approvals(ApprovalRequest.Status status, CurrentUser user, Pageable pageable) {
        if (status != ApprovalRequest.Status.PENDING) {
            Page<ApprovalRequest> page = approvals.findByStatusOrderByCreatedAtDesc(status, pageable);
            return new PageResponse<>(page.getContent().stream().map(ApprovalView::of).toList(), page.getNumber(),
                    page.getSize(), page.getTotalElements(), page.getTotalPages());
        }
        // pending inbox: filter to what the caller may approve BEFORE paging (pending volume is small)
        List<ApprovalView> mine = approvals.findByStatusOrderByCreatedAtDesc(status, Pageable.ofSize(1000)).getContent()
                .stream().filter(a -> canApprove(a, user)).map(ApprovalView::of).toList();
        int size = pageable.getPageSize();
        int from = Math.min((int) pageable.getOffset(), mine.size());
        int to = Math.min(from + size, mine.size());
        return new PageResponse<>(mine.subList(from, to), pageable.getPageNumber(), size, mine.size(),
                (mine.size() + size - 1) / size);
    }

    public TransitionResult approve(UUID approvalId, String remarks, CurrentUser user) {
        ApprovalRequest a = pendingApproval(approvalId, user);
        WorkflowInstance i = instances.findById(a.getInstanceId())
                .orElseThrow(() -> ApiException.notFound("Workflow instance", a.getInstanceId()));
        if (!a.getFromState().equals(i.getCurrentState())) {
            throw ApiException.conflict("STALE_APPROVAL", "Record moved to " + i.getCurrentState()
                    + " - it is no longer in state " + a.getFromState() + "; reject this approval");
        }
        WorkflowModel model = codec.version(i.getWorkflowCode(), i.getVersionNo());
        Map<String, Object> payload = codec.readMap(a.getPayloadJson());
        // re-check state + rules at decision time (roles were checked when requested)
        Decision d = engine.decide(model, i.getCurrentState(), a.getTransitionCode(), systemActor(user),
                codec.readMap(i.getContextJson()), payload, config.get(), true);
        if (!d.allowed()) {
            throw rejected(d);
        }
        a.setStatus(ApprovalRequest.Status.APPROVED);
        decided(a, user, remarks);
        logApproval("WORKFLOW_APPROVAL_APPROVED", a);
        TransitionDef t = d.transition();
        applyTransition(i, model, t, actor(user), user, joinRemarks(a.getRemarks(), remarks), payload, a.getId());
        return new TransitionResult(TransitionResult.COMPLETED, view(i, user), ApprovalView.of(a));
    }

    public ApprovalView reject(UUID approvalId, String remarks, CurrentUser user) {
        ApprovalRequest a = pendingApproval(approvalId, user);
        a.setStatus(ApprovalRequest.Status.REJECTED);
        decided(a, user, remarks);
        logApproval("WORKFLOW_APPROVAL_REJECTED", a);
        return ApprovalView.of(a);
    }

    // ------------------------------------------------------------------ internals
    private TransitionResult execute(WorkflowInstance i, String transitionCode, String remarks,
                                     Map<String, Object> payload, Map<String, Object> context, CurrentUser user) {
        WorkflowModel model = codec.version(i.getWorkflowCode(), i.getVersionNo());
        Actor actor = actor(user);
        checkScope(i, codec.readMap(i.getContextJson()), user, actor); // stored context, not caller input
        Map<String, Object> entity = merge(codec.readMap(i.getContextJson()), context);
        Decision d = engine.decide(model, i.getCurrentState(), transitionCode, actor, entity, payload, config.get(), true);
        if (!d.allowed()) {
            throw rejected(d);
        }
        if (approvals.findFirstByInstanceIdAndStatus(i.getId(), ApprovalRequest.Status.PENDING).isPresent()) {
            throw ApiException.conflict("APPROVAL_PENDING", "Another transition is waiting for approval on this record");
        }
        i.setContextJson(codec.write(entity));
        TransitionDef t = d.transition();
        if (d.requiresApproval() && !actor.system()) {
            ApprovalRequest a = new ApprovalRequest();
            a.setId(UUID.randomUUID());
            a.setInstanceId(i.getId());
            a.setEntityType(i.getEntityType());
            a.setEntityId(i.getEntityId());
            a.setCandidateId(i.getCandidateId());
            a.setTransitionCode(t.code());
            a.setFromState(i.getCurrentState());
            a.setToState(t.to());
            a.setApproverRoles(String.join(",", t.approverRoles()));
            a.setApproverPermission(t.approverPermission() == null || t.approverPermission().isBlank()
                    ? "WORKFLOW:APPROVE" : t.approverPermission());
            a.setRequestedBy(user.userId());
            a.setRequestedByName(user.name() != null ? user.name() : user.email());
            a.setRemarks(remarks);
            a.setPayloadJson(codec.write(payload));
            approvals.save(a);
            logApproval("WORKFLOW_APPROVAL_REQUESTED", a);
            return new TransitionResult(TransitionResult.PENDING_APPROVAL, view(i, user), ApprovalView.of(a));
        }
        applyTransition(i, model, t, actor, user, remarks, payload, null);
        return new TransitionResult(TransitionResult.COMPLETED, view(i, user), null);
    }

    private void applyTransition(WorkflowInstance i, WorkflowModel model, TransitionDef t, Actor actor,
                                 CurrentUser user, String remarks, Map<String, Object> payload, UUID approvalId) {
        String from = i.getCurrentState();
        i.setCurrentState(t.to());
        instances.save(i);
        record(i, model, t.code(), from, t.to(), actor, user, remarks, payload, approvalId);
    }

    private void record(WorkflowInstance i, WorkflowModel model, String transitionCode, String from, String to,
                        Actor actor, CurrentUser user, String remarks, Map<String, Object> payload, UUID approvalId) {
        TransitionLog log = new TransitionLog();
        log.setInstanceId(i.getId());
        log.setWorkflowCode(i.getWorkflowCode());
        log.setVersionNo(i.getVersionNo());
        log.setTransitionCode(transitionCode);
        log.setFromState(from);
        log.setToState(to);
        log.setActorId(actor.id());
        log.setActorName(actor.name());
        log.setActorRoles(String.join(",", actor.roles()));
        log.setRemarks(remarks);
        log.setPayloadJson(payload == null || payload.isEmpty() ? null : codec.write(payload));
        log.setApprovalId(approvalId);
        log.setOccurredAt(Instant.now());
        logs.save(log);

        audit.log(AuditEvent.builder(AuditCategory.WORKFLOW_TRANSITION, transitionCode)
                .entity(i.getEntityType(), i.getEntityId())
                .candidate(i.getCandidateId())
                .description(label(model, from) + " -> " + label(model, to))
                .detail("workflow", i.getWorkflowCode())
                .detail("version", i.getVersionNo())
                .detail("fromState", from)
                .detail("toState", to)
                .detail("remarks", remarks)
                .detail("approvalId", approvalId == null ? null : approvalId.toString())
                .build());

        events.publishEvent(new TransitionCompleted(log.getId(), i.getWorkflowCode(), i.getVersionNo(), transitionCode,
                from, to, i.getEntityType(), i.getEntityId(), i.getCandidateId(), actor.id(), actor.name(),
                user == null ? null : user.email(), remarks, codec.readMap(i.getContextJson()),
                payload == null ? Map.of() : payload, log.getOccurredAt()));
    }

    /**
     * Record-level visibility (BRD 4.3): evaluated on the STORED context (ownerId / lob / location recorded when the
     * record was started or last moved) so callers cannot widen their own access; a recruiter can only move his own
     * (or shared) candidates, a TL/Manager those of his team / LOBs.
     */
    private static void checkScope(WorkflowInstance i, Map<String, Object> entity, CurrentUser user, Actor actor) {
        if (user == null || actor.system()) {
            return;
        }
        String owner = str(entity.get("ownerId"));
        String lob = str(entity.get("lob"));
        String location = str(entity.get("location"));
        if (owner == null && lob == null && location == null) {
            return;
        }
        AccessEvaluator.Decision d = AccessEvaluator.check(user, null,
                new AccessEvaluator.Target("CANDIDATE", i.getCandidateId(), owner, lob, location));
        if (!d.allowed()) {
            throw ApiException.forbidden("This record is outside your visibility (" + d.reason() + ")");
        }
    }

    private static String str(Object o) {
        return o == null || o.toString().isBlank() ? null : o.toString();
    }

    private ApprovalRequest pendingApproval(UUID id, CurrentUser user) {
        ApprovalRequest a = approvals.findById(id).orElseThrow(() -> ApiException.notFound("Approval", id));
        if (a.getStatus() != ApprovalRequest.Status.PENDING) {
            throw ApiException.conflict("ALREADY_DECIDED", "Approval is already " + a.getStatus());
        }
        if (user.userId() != null && user.userId().equals(a.getRequestedBy())) {
            throw ApiException.forbidden("You cannot approve your own request");
        }
        if (!canApprove(a, user)) {
            throw ApiException.forbidden("Requires " + a.getApproverPermission()
                    + (a.getApproverRoles() == null || a.getApproverRoles().isBlank() ? "" : " and one of roles " + a.getApproverRoles()));
        }
        return a;
    }

    private static boolean canApprove(ApprovalRequest a, CurrentUser user) {
        if (!user.hasPermission(a.getApproverPermission())) {
            return false;
        }
        if (a.getApproverRoles() == null || a.getApproverRoles().isBlank()) {
            return true;
        }
        for (String r : a.getApproverRoles().split(",")) {
            if (user.hasRole(r.trim())) {
                return true;
            }
        }
        return false;
    }

    private void decided(ApprovalRequest a, CurrentUser user, String remarks) {
        a.setDecidedBy(user.userId());
        a.setDecidedByName(user.name() != null ? user.name() : user.email());
        a.setDecidedAt(Instant.now());
        a.setDecisionRemarks(remarks);
    }

    private void logApproval(String action, ApprovalRequest a) {
        audit.log(AuditEvent.builder(AuditCategory.APPROVAL, action)
                .entity(a.getEntityType(), a.getEntityId())
                .candidate(a.getCandidateId())
                .detail("approvalId", a.getId().toString())
                .detail("transition", a.getTransitionCode())
                .detail("fromState", a.getFromState())
                .detail("toState", a.getToState())
                .detail("requestedBy", a.getRequestedByName())
                .detail("decidedBy", a.getDecidedByName())
                .detail("remarks", a.getRemarks())
                .detail("decisionRemarks", a.getDecisionRemarks())
                .build());
    }

    private InstanceView view(WorkflowInstance i, CurrentUser user) {
        WorkflowModel model = codec.version(i.getWorkflowCode(), i.getVersionNo());
        Optional<StateDef> state = model.state(i.getCurrentState());
        List<WorkflowEngine.Option> options = user == null ? List.of()
                : engine.options(model, i.getCurrentState(), actor(user), codec.readMap(i.getContextJson()), config.get());
        ApprovalView pending = approvals.findFirstByInstanceIdAndStatus(i.getId(), ApprovalRequest.Status.PENDING)
                .map(ApprovalView::of).orElse(null);
        return new InstanceView(i.getId(), i.getWorkflowCode(), i.getVersionNo(), i.getEntityType(), i.getEntityId(),
                i.getCandidateId(), i.getCurrentState(), state.map(StateDef::label).orElse(i.getCurrentState()),
                state.map(StateDef::category).orElse(null), state.map(StateDef::tab).orElse(null), i.getAssignmentId(),
                i.getCreatedAt(), i.getUpdatedAt(), options, pending);
    }

    private WorkflowInstance instance(String entityType, String entityId) {
        return instances.findByEntityTypeAndEntityId(entityType, entityId)
                .orElseThrow(() -> ApiException.notFound("Workflow instance", entityType + "/" + entityId));
    }

    private static String initialState(WorkflowModel model, String requested) {
        List<StateDef> initial = model.states().stream()
                .filter(s -> s.category() == WorkflowModel.StateCategory.INITIAL).toList();
        if (requested == null || requested.isBlank()) {
            if (initial.isEmpty()) {
                throw ApiException.conflict("NO_INITIAL_STATE", "Workflow " + model.code() + " has no INITIAL state");
            }
            return initial.get(0).code();
        }
        if (initial.stream().noneMatch(s -> s.code().equals(requested))) {
            throw ApiException.badRequest("INVALID_INITIAL_STATE", "'" + requested + "' is not an INITIAL state of "
                    + model.code() + " " + initial.stream().map(StateDef::code).toList());
        }
        return requested;
    }

    private static Violation invalidTarget(WorkflowModel model, String current, String target) {
        List<String> targets = model.transitionsFrom(current).stream().map(TransitionDef::to).distinct().toList();
        return new Violation("INVALID_TRANSITION", "Cannot move from '" + current + "' to '" + target
                + "'. Allowed next states: " + targets);
    }

    private static ApiException rejected(Decision d) {
        List<Violation> v = d == null ? List.of() : d.violations();
        boolean stateProblem = v.stream().anyMatch(x -> x.code().equals("INVALID_STATE") || x.code().equals("UNKNOWN_TRANSITION"));
        boolean accessProblem = v.stream().anyMatch(x -> x.code().equals("MISSING_PERMISSION")
                || x.code().equals("ROLE_NOT_ALLOWED") || x.code().equals("SYSTEM_ONLY"));
        HttpStatus status = stateProblem ? HttpStatus.CONFLICT : accessProblem ? HttpStatus.FORBIDDEN : HttpStatus.UNPROCESSABLE_ENTITY;
        String message = v.isEmpty() ? "Transition not allowed" : v.get(0).message();
        return new ApiException(status, "TRANSITION_NOT_ALLOWED", message, v);
    }

    static Actor actor(CurrentUser user) {
        if (user == null) {
            return new Actor(null, "system", Set.of(), Set.of(), true);
        }
        return new Actor(user.userId(), user.name() != null ? user.name() : user.email(), user.roles(),
                user.permissions(), user.hasRole("INTERNAL") || user.isSystem());
    }

    private static Actor systemActor(CurrentUser user) {
        return new Actor(user.userId(), user.name(), user.roles(), user.permissions(), true);
    }

    private static Map<String, Object> merge(Map<String, Object> base, Map<String, Object> update) {
        Map<String, Object> m = new LinkedHashMap<>(base == null ? Map.of() : base);
        if (update != null) {
            m.putAll(update);
        }
        return m;
    }

    private static String label(WorkflowModel model, String state) {
        return state == null ? "(start)" : model.state(state).map(StateDef::label).orElse(state);
    }

    private static String joinRemarks(String request, String decision) {
        if (decision == null || decision.isBlank()) {
            return request;
        }
        return (request == null ? "" : request + " | ") + "Approved: " + decision;
    }
}
