package com.ags.health.hr.workflow.service;

import com.ags.health.hr.platform.audit.AuditCategory;
import com.ags.health.hr.platform.audit.AuditEvent;
import com.ags.health.hr.platform.audit.AuditLogger;
import com.ags.health.hr.platform.web.ApiException;
import com.ags.health.hr.workflow.domain.StepTemplate;
import com.ags.health.hr.workflow.engine.WorkflowModel;
import com.ags.health.hr.workflow.engine.WorkflowModel.Blueprint;
import com.ags.health.hr.workflow.engine.WorkflowModel.RuleDef;
import com.ags.health.hr.workflow.engine.WorkflowModel.StepDef;
import com.ags.health.hr.workflow.repo.StepTemplateRepository;
import com.ags.health.hr.workflow.web.WorkflowDtos.AddStepRequest;
import com.ags.health.hr.workflow.web.WorkflowDtos.DraftResponse;
import com.ags.health.hr.workflow.web.WorkflowDtos.StepTemplateDoc;
import com.ags.health.hr.workflow.web.WorkflowDtos.StepTemplateRequest;
import com.ags.health.hr.workflow.web.WorkflowDtos.StepTemplateResponse;
import com.ags.health.hr.workflow.web.WorkflowDtos.StepsResponse;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

/**
 * Step builder: HR composes a workflow from hiring steps - add from the library, rename, change stages / actions /
 * fields / roles / approvals / parameters, mark optional, reorder, remove. Every change is stored in the draft and
 * compiled into the state machine; publishing versions it like any other workflow change.
 */
@Service
@Transactional
public class StepService {

    private final StepTemplateRepository library;
    private final DefinitionService definitions;
    private final ModelCodec codec;
    private final AuditLogger audit;

    public StepService(StepTemplateRepository library, DefinitionService definitions, ModelCodec codec, AuditLogger audit) {
        this.library = library;
        this.definitions = definitions;
        this.codec = codec;
        this.audit = audit;
    }

    // ------------------------------------------------------------------ step library
    @Transactional(readOnly = true)
    public List<StepTemplateResponse> library() {
        return library.findByActiveTrueOrderByNameAsc().stream().map(this::view).toList();
    }

    @Transactional(readOnly = true)
    public StepTemplateResponse template(String code) {
        return view(find(code));
    }

    public StepTemplateResponse saveTemplate(String code, StepTemplateRequest req) {
        StepTemplate t = library.findById(code).orElseGet(() -> {
            StepTemplate created = new StepTemplate();
            created.setCode(code);
            return created;
        });
        if (req.step().stages().isEmpty()) {
            throw ApiException.badRequest("STEP_WITHOUT_STAGES", "A step template needs at least one stage");
        }
        t.setName(req.name());
        t.setStepType(req.stepType());
        t.setDescription(req.description());
        t.setDefinitionJson(codec.write(new StepTemplateDoc(req.step(), req.rules() == null ? List.of() : req.rules())));
        t.setActive(req.active() == null || req.active());
        library.save(t);
        audit.log(AuditEvent.builder(AuditCategory.CONFIG_CHANGE, "STEP_TEMPLATE_SAVED").entity("STEP_TEMPLATE", code)
                .detail("name", req.name()).detail("stepType", req.stepType()).build());
        return view(t);
    }

    // ------------------------------------------------------------------ steps of a workflow draft
    @Transactional(readOnly = true)
    public StepsResponse steps(String workflowCode) {
        DraftResponse draft = definitions.draft(workflowCode);
        return new StepsResponse(draft.model().blueprint(), draft.issues());
    }

    public DraftResponse addStep(String workflowCode, AddStepRequest req) {
        StepDef base;
        List<RuleDef> neededRules = List.of();
        if (req.step() != null) {
            base = req.step();
        } else if (req.templateCode() != null) {
            StepTemplateDoc doc = doc(find(req.templateCode()));
            base = doc.step();
            neededRules = doc.rules() == null ? List.of() : doc.rules();
        } else {
            throw ApiException.badRequest("STEP_SOURCE_REQUIRED", "Provide templateCode (from the step library) or step");
        }
        Map<String, Object> params = new LinkedHashMap<>(base.parameters());
        if (req.parameters() != null) {
            params.putAll(req.parameters());
        }
        StepDef step = new StepDef(req.stepCode(), req.label() != null ? req.label() : base.label(), base.type(),
                req.tab() != null ? req.tab() : base.tab(), req.optional() != null ? req.optional() : base.optional(),
                base.description(), params, base.stages(), base.entryAction(), base.actions(),
                req.templateCode() != null ? req.templateCode() : base.templateCode());
        List<RuleDef> rulesToAdd = neededRules;
        return definitions.editDraftModel(workflowCode, m -> {
            Blueprint bp = blueprint(m);
            if (bp.steps().stream().anyMatch(s -> s.code().equals(step.code()))) {
                throw ApiException.conflict("STEP_EXISTS", "Step " + step.code() + " already exists in " + workflowCode);
            }
            List<StepDef> steps = new ArrayList<>(bp.steps());
            int pos = req.position() == null ? steps.size() : Math.max(0, Math.min(req.position(), steps.size()));
            steps.add(pos, step);
            return withRules(m.withBlueprint(bp.withSteps(steps)), rulesToAdd);
        });
    }

    public DraftResponse updateStep(String workflowCode, String stepCode, StepDef step) {
        if (step.code() != null && !step.code().equals(stepCode)) {
            throw ApiException.badRequest("CODE_MISMATCH", "Step code cannot be changed; remove and add instead");
        }
        StepDef fixed = new StepDef(stepCode, step.label(), step.type(), step.tab(), step.optional(), step.description(),
                step.parameters(), step.stages(), step.entryAction(), step.actions(), step.templateCode());
        return definitions.editDraftModel(workflowCode, m -> {
            Blueprint bp = blueprint(m);
            List<StepDef> steps = new ArrayList<>(bp.steps());
            int idx = indexOf(steps, stepCode);
            steps.set(idx, fixed);
            return m.withBlueprint(bp.withSteps(steps));
        });
    }

    public DraftResponse removeStep(String workflowCode, String stepCode) {
        return definitions.editDraftModel(workflowCode, m -> {
            Blueprint bp = blueprint(m);
            List<StepDef> steps = new ArrayList<>(bp.steps());
            steps.remove(indexOf(steps, stepCode));
            return m.withBlueprint(bp.withSteps(steps));
        });
    }

    public DraftResponse reorder(String workflowCode, List<String> order) {
        return definitions.editDraftModel(workflowCode, m -> {
            Blueprint bp = blueprint(m);
            Set<String> current = bp.steps().stream().map(StepDef::code).collect(Collectors.toSet());
            if (order.size() != current.size() || !new HashSet<>(order).equals(current)) {
                throw ApiException.badRequest("INVALID_ORDER", "order must list every step exactly once: " + current);
            }
            Map<String, StepDef> byCode = bp.steps().stream().collect(Collectors.toMap(StepDef::code, s -> s));
            return m.withBlueprint(bp.withSteps(order.stream().map(byCode::get).toList()));
        });
    }

    /** Replace blueprint-level settings (common states, startFrom, rejection state, global actions, extras). */
    public DraftResponse saveBlueprint(String workflowCode, Blueprint blueprint) {
        return definitions.editDraftModel(workflowCode, m -> m.withBlueprint(blueprint));
    }

    // ------------------------------------------------------------------ helpers
    private static Blueprint blueprint(WorkflowModel m) {
        if (m.blueprint() == null) {
            throw ApiException.conflict("NOT_STEP_BASED", "Workflow " + m.code()
                    + " is edited at state level. Create a new workflow copying a step-based one (copyFrom) to use the step builder.");
        }
        return m.blueprint();
    }

    private static WorkflowModel withRules(WorkflowModel m, List<RuleDef> needed) {
        if (needed.isEmpty()) {
            return m;
        }
        Set<String> have = m.rules().stream().map(RuleDef::code).collect(Collectors.toSet());
        List<RuleDef> rules = new ArrayList<>(m.rules());
        needed.stream().filter(r -> !have.contains(r.code())).forEach(rules::add);
        return m.withRules(rules);
    }

    private static int indexOf(List<StepDef> steps, String code) {
        for (int i = 0; i < steps.size(); i++) {
            if (steps.get(i).code().equals(code)) {
                return i;
            }
        }
        throw ApiException.notFound("Step", code);
    }

    private StepTemplate find(String code) {
        return library.findById(code).orElseThrow(() -> ApiException.notFound("Step template", code));
    }

    private StepTemplateDoc doc(StepTemplate t) {
        try {
            return codec.readValue(t.getDefinitionJson(), StepTemplateDoc.class);
        } catch (RuntimeException e) {
            throw ApiException.badRequest("INVALID_STEP_TEMPLATE", "Step template " + t.getCode() + " cannot be parsed");
        }
    }

    private StepTemplateResponse view(StepTemplate t) {
        StepTemplateDoc d = doc(t);
        return new StepTemplateResponse(t.getCode(), t.getName(), t.getStepType(), t.getDescription(), d.step(),
                d.rules(), t.isActive(), t.getUpdatedAt() != null ? t.getUpdatedAt() : t.getCreatedAt(),
                t.getUpdatedBy() != null ? t.getUpdatedBy() : t.getCreatedBy());
    }
}
