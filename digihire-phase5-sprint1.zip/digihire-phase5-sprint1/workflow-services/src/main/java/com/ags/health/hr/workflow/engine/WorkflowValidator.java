package com.ags.health.hr.workflow.engine;

import com.ags.health.hr.workflow.engine.WorkflowModel.RuleDef;
import com.ags.health.hr.workflow.engine.WorkflowModel.StateCategory;
import com.ags.health.hr.workflow.engine.WorkflowModel.StateDef;
import com.ags.health.hr.workflow.engine.WorkflowModel.TransitionDef;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.function.Function;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

/**
 * Design-time "invalid workflow state validation" (tracker #31). A draft with ERROR issues cannot be published;
 * WARNINGs are shown to the admin but do not block.
 */
public class WorkflowValidator {

    private static final Pattern CODE = Pattern.compile("[A-Z][A-Z0-9_]{0,59}");

    public enum Severity { ERROR, WARNING }

    public record Issue(Severity severity, String code, String path, String message) {
    }

    private final RuleEvaluator ruleEvaluator;

    public WorkflowValidator(RuleEvaluator ruleEvaluator) {
        this.ruleEvaluator = ruleEvaluator;
    }

    public static boolean hasErrors(List<Issue> issues) {
        return issues.stream().anyMatch(i -> i.severity() == Severity.ERROR);
    }

    public List<Issue> validate(WorkflowModel m) {
        List<Issue> issues = new ArrayList<>();
        if (m.code() == null || !CODE.matcher(m.code()).matches()) {
            error(issues, "INVALID_CODE", "code", "Workflow code must be UPPER_SNAKE_CASE");
        }
        if (m.entityType() == null || m.entityType().isBlank()) {
            error(issues, "MISSING_ENTITY_TYPE", "entityType", "entityType is required (e.g. APPLICATION)");
        }

        // ---- states
        Set<String> states = codes(m.states(), StateDef::code, "states", issues);
        for (StateDef s : m.states()) {
            if (s.category() == null) {
                error(issues, "MISSING_CATEGORY", "states." + s.code(), "State category is required (INITIAL / INTERMEDIATE / TERMINAL)");
            }
            if (s.label() == null || s.label().isBlank()) {
                warn(issues, "MISSING_LABEL", "states." + s.code(), "State has no label");
            }
        }
        List<String> initial = m.states().stream().filter(s -> s.category() == StateCategory.INITIAL).map(StateDef::code).toList();
        Set<String> terminal = m.states().stream().filter(s -> s.category() == StateCategory.TERMINAL).map(StateDef::code)
                .collect(Collectors.toSet());
        if (initial.isEmpty()) {
            error(issues, "NO_INITIAL_STATE", "states", "At least one INITIAL state is required");
        }
        if (terminal.isEmpty()) {
            error(issues, "NO_TERMINAL_STATE", "states", "At least one TERMINAL state is required");
        }

        // ---- rules
        Set<String> rules = codes(m.rules(), RuleDef::code, "rules", issues);
        for (RuleDef r : m.rules()) {
            checkExpression(issues, "rules." + r.code() + ".expression", r.expression(), true);
        }

        // ---- transitions
        codes(m.transitions(), TransitionDef::code, "transitions", issues);
        for (TransitionDef t : m.transitions()) {
            String p = "transitions." + t.code();
            if (t.from().isEmpty()) {
                error(issues, "NO_SOURCE_STATE", p + ".from", "Transition needs at least one 'from' state");
            }
            for (String f : t.from()) {
                if (!states.contains(f)) {
                    error(issues, "UNKNOWN_STATE", p + ".from", "Unknown state '" + f + "'");
                } else if (terminal.contains(f)) {
                    error(issues, "FROM_TERMINAL", p + ".from", "State '" + f + "' is TERMINAL and cannot have outgoing transitions");
                }
                if (f.equals(t.to())) {
                    warn(issues, "SELF_LOOP", p, "Transition loops on state '" + f + "'");
                }
            }
            if (t.to() == null || !states.contains(t.to())) {
                error(issues, "UNKNOWN_STATE", p + ".to", "Unknown target state '" + t.to() + "'");
            }
            for (String r : t.rules()) {
                if (!rules.contains(r)) {
                    error(issues, "UNKNOWN_RULE", p + ".rules", "Unknown rule '" + r + "'");
                }
            }
            checkExpression(issues, p + ".guard", t.guard(), false);
            if (t.requiresApproval() && t.approverRoles().isEmpty()
                    && (t.approverPermission() == null || t.approverPermission().isBlank())) {
                warn(issues, "APPROVER_DEFAULTED", p, "No approver roles/permission set - WORKFLOW:APPROVE will be required");
            }
            if (t.requiresApproval() && t.systemOnly()) {
                error(issues, "SYSTEM_APPROVAL", p, "A systemOnly transition cannot require approval");
            }
        }

        // ---- graph checks: reachability and dead ends
        Set<String> reachable = reachable(m, initial);
        for (StateDef s : m.states()) {
            if (s.category() != StateCategory.INITIAL && !reachable.contains(s.code())) {
                error(issues, "UNREACHABLE_STATE", "states." + s.code(), "State '" + s.code() + "' cannot be reached from any INITIAL state");
            }
            if (s.category() != StateCategory.TERMINAL && m.transitionsFrom(s.code()).isEmpty()) {
                warn(issues, "DEAD_END", "states." + s.code(), "Non-terminal state '" + s.code() + "' has no outgoing transition");
            }
        }
        return issues;
    }

    private void checkExpression(List<Issue> issues, String path, String expression, boolean required) {
        if (expression == null || expression.isBlank()) {
            if (required) {
                error(issues, "MISSING_EXPRESSION", path, "Expression is required");
            }
            return;
        }
        try {
            ruleEvaluator.validateSyntax(expression);
        } catch (IllegalArgumentException e) {
            error(issues, "INVALID_EXPRESSION", path, e.getMessage());
        }
    }

    private static Set<String> reachable(WorkflowModel m, List<String> initial) {
        Set<String> seen = new HashSet<>(initial);
        Deque<String> queue = new ArrayDeque<>(initial);
        while (!queue.isEmpty()) {
            String s = queue.poll();
            for (TransitionDef t : m.transitionsFrom(s)) {
                if (t.to() != null && seen.add(t.to())) {
                    queue.add(t.to());
                }
            }
        }
        return seen;
    }

    private static <T> Set<String> codes(List<T> items, Function<T, String> code, String path, List<Issue> issues) {
        Set<String> seen = new HashSet<>();
        for (T item : items) {
            String c = code.apply(item);
            if (c == null || !CODE.matcher(c).matches()) {
                error(issues, "INVALID_CODE", path, "Invalid code '" + c + "' (use UPPER_SNAKE_CASE)");
            } else if (!seen.add(c)) {
                error(issues, "DUPLICATE_CODE", path, "Duplicate code '" + c + "'");
            }
        }
        return seen;
    }

    private static void error(List<Issue> issues, String code, String path, String message) {
        issues.add(new Issue(Severity.ERROR, code, path, message));
    }

    private static void warn(List<Issue> issues, String code, String path, String message) {
        issues.add(new Issue(Severity.WARNING, code, path, message));
    }
}
