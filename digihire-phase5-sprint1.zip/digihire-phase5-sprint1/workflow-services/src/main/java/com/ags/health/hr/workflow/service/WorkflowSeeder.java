package com.ags.health.hr.workflow.service;

import com.ags.health.hr.workflow.WorkflowProperties;
import com.ags.health.hr.workflow.domain.StepTemplate;
import com.ags.health.hr.workflow.domain.WorkflowAssignment;
import com.ags.health.hr.workflow.domain.WorkflowDefinition;
import com.ags.health.hr.workflow.domain.WorkflowVersion;
import com.ags.health.hr.workflow.engine.StepCompiler;
import com.ags.health.hr.workflow.engine.WorkflowModel;
import com.ags.health.hr.workflow.engine.WorkflowValidator;
import com.ags.health.hr.workflow.repo.StepTemplateRepository;
import com.ags.health.hr.workflow.repo.WorkflowAssignmentRepository;
import com.ags.health.hr.workflow.repo.WorkflowDefinitionRepository;
import com.ags.health.hr.workflow.repo.WorkflowVersionRepository;
import com.ags.health.hr.workflow.web.WorkflowDtos.StepTemplateDoc;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.core.io.Resource;
import org.springframework.core.io.support.PathMatchingResourcePatternResolver;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * First-start seeding of the default workflows ({@code classpath:workflows/*.json}) and assignments
 * ({@code workflows/assignments.json}). Never overwrites anything that already exists, so admin changes survive
 * redeployments. Disable with {@code digihire.workflow.seed-enabled=false}.
 */
@Component
public class WorkflowSeeder implements ApplicationRunner {

    private static final Logger log = LoggerFactory.getLogger(WorkflowSeeder.class);

    private final WorkflowProperties props;
    private final WorkflowDefinitionRepository definitions;
    private final WorkflowVersionRepository versions;
    private final WorkflowAssignmentRepository assignments;
    private final ModelCodec codec;
    private final WorkflowValidator validator;
    private final ChangeLogger changeLogger;
    private final ObjectMapper objectMapper;
    private final StepTemplateRepository stepTemplates;

    public WorkflowSeeder(WorkflowProperties props, WorkflowDefinitionRepository definitions,
                          WorkflowVersionRepository versions, WorkflowAssignmentRepository assignments,
                          ModelCodec codec, WorkflowValidator validator, ChangeLogger changeLogger,
                          ObjectMapper objectMapper, StepTemplateRepository stepTemplates) {
        this.props = props;
        this.definitions = definitions;
        this.versions = versions;
        this.assignments = assignments;
        this.codec = codec;
        this.validator = validator;
        this.changeLogger = changeLogger;
        this.objectMapper = objectMapper;
        this.stepTemplates = stepTemplates;
    }

    /** Library seed files: {"code","name","stepType","description","step":{...},"rules":[...]} */
    public record SeedStepTemplate(String code, String name, String stepType, String description,
                                   WorkflowModel.StepDef step, List<WorkflowModel.RuleDef> rules) {
    }

    private void seedStepLibrary(PathMatchingResourcePatternResolver resolver) throws Exception {
        for (Resource r : resolver.getResources("classpath:step-library/*.json")) {
            SeedStepTemplate t;
            try (InputStream in = r.getInputStream()) {
                t = objectMapper.readValue(in, SeedStepTemplate.class);
            }
            if (stepTemplates.existsById(t.code())) {
                continue;
            }
            StepTemplate e = new StepTemplate();
            e.setCode(t.code());
            e.setName(t.name());
            e.setStepType(t.stepType());
            e.setDescription(t.description());
            e.setDefinitionJson(codec.write(new StepTemplateDoc(t.step(), t.rules() == null ? List.of() : t.rules())));
            stepTemplates.save(e);
            log.info("Seeded step template {}", t.code());
        }
    }

    public record SeedAssignment(String workflowCode, String entityType, String jobId, String jobRole, String lob,
                          String location, String hiringType, int priority, String description) {
    }

    @Override
    @Transactional
    public void run(ApplicationArguments args) throws Exception {
        if (!props.seedEnabled()) {
            return;
        }
        PathMatchingResourcePatternResolver resolver = new PathMatchingResourcePatternResolver();
        seedStepLibrary(resolver);
        for (Resource r : resolver.getResources("classpath:workflows/*.json")) {
            if ("assignments.json".equals(r.getFilename())) {
                continue;
            }
            String json;
            try (InputStream in = r.getInputStream()) {
                json = new String(in.readAllBytes(), StandardCharsets.UTF_8);
            }
            StepCompiler.Result compiled = StepCompiler.compile(codec.read(json)); // step-based seeds -> state machine
            WorkflowModel model = compiled.model();
            if (definitions.existsByCode(model.code())) {
                continue;
            }
            List<WorkflowValidator.Issue> issues = new ArrayList<>(compiled.issues());
            issues.addAll(validator.validate(model));
            if (WorkflowValidator.hasErrors(issues)) {
                log.error("Seed workflow {} is invalid, skipped: {}", model.code(), issues);
                continue;
            }
            WorkflowDefinition d = new WorkflowDefinition();
            d.setId(UUID.randomUUID());
            d.setCode(model.code());
            d.setName(model.name());
            d.setEntityType(model.entityType());
            d.setDescription(model.description());
            d.setActiveVersion(1);
            definitions.saveAndFlush(d);

            WorkflowVersion v = new WorkflowVersion();
            v.setWorkflowCode(model.code());
            v.setVersionNo(1);
            v.setDefinitionJson(codec.write(model));
            v.setChangeSummary("Seeded default workflow");
            v.setPublishedBy("system");
            v.setPublishedAt(Instant.now());
            versions.save(v);
            changeLogger.log(model.code(), "SEEDED", 1, Map.of("source", String.valueOf(r.getFilename())));
            log.info("Seeded workflow {} v1", model.code());
        }

        Resource seed = resolver.getResource("classpath:workflows/assignments.json");
        if (seed.exists() && assignments.count() == 0) {
            List<SeedAssignment> rows;
            try (InputStream in = seed.getInputStream()) {
                rows = objectMapper.readValue(in, new TypeReference<List<SeedAssignment>>() { });
            }
            for (SeedAssignment s : rows) {
                if (!definitions.existsByCode(s.workflowCode())) {
                    continue;
                }
                WorkflowAssignment a = new WorkflowAssignment();
                a.setId(UUID.randomUUID());
                a.setWorkflowCode(s.workflowCode());
                a.setEntityType(s.entityType());
                a.setJobId(s.jobId());
                a.setJobRole(s.jobRole());
                a.setLob(s.lob());
                a.setLocation(s.location());
                a.setHiringType(s.hiringType());
                a.setPriority(s.priority());
                a.setDescription(s.description());
                assignments.save(a);
            }
            log.info("Seeded {} workflow assignments", rows.size());
        }
    }
}
