package com.ags.health.hr.workflow.web;

import com.ags.health.hr.workflow.engine.WorkflowModel;
import com.ags.health.hr.workflow.engine.WorkflowModel.RuleDef;
import com.ags.health.hr.workflow.engine.WorkflowModel.StateDef;
import com.ags.health.hr.workflow.engine.WorkflowModel.TransitionDef;
import com.ags.health.hr.workflow.engine.WorkflowValidator;
import com.ags.health.hr.workflow.service.AssignmentService;
import com.ags.health.hr.workflow.service.DefinitionService;
import com.ags.health.hr.workflow.web.WorkflowDtos.ChangeLogEntry;
import com.ags.health.hr.workflow.web.WorkflowDtos.CreateWorkflowRequest;
import com.ags.health.hr.workflow.web.WorkflowDtos.DraftResponse;
import com.ags.health.hr.workflow.web.WorkflowDtos.PublishRequest;
import com.ags.health.hr.workflow.web.WorkflowDtos.RuleTestRequest;
import com.ags.health.hr.workflow.web.WorkflowDtos.RuleTestResponse;
import com.ags.health.hr.workflow.web.WorkflowDtos.StateView;
import com.ags.health.hr.workflow.web.WorkflowDtos.VersionSummary;
import com.ags.health.hr.workflow.web.WorkflowDtos.WorkflowDetail;
import com.ags.health.hr.workflow.web.WorkflowDtos.WorkflowSummary;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.Map;

/**
 * Workflow configuration (Admin / HR): states, transitions, rules, validation, versioning, change log.
 * Edits always go to the DRAFT; publish creates an immutable version.
 */
@RestController
@RequestMapping("/workflows")
@Tag(name = "Workflow configuration")
public class WorkflowAdminController {

    private final DefinitionService service;
    private final AssignmentService assignments;

    public WorkflowAdminController(DefinitionService service, AssignmentService assignments) {
        this.service = service;
        this.assignments = assignments;
    }

    @GetMapping
    @PreAuthorize("hasAuthority('WORKFLOW:VIEW')")
    public List<WorkflowSummary> list() {
        return service.list();
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    @PreAuthorize("hasAuthority('WORKFLOW:CONFIGURE')")
    @Operation(summary = "Create a workflow (empty draft, or copyFrom an existing workflow to tailor it for a job / role / LOB)")
    public WorkflowSummary create(@Valid @RequestBody CreateWorkflowRequest req) {
        return service.create(req);
    }

    @GetMapping("/{code}")
    @PreAuthorize("hasAuthority('WORKFLOW:VIEW')")
    public WorkflowDetail detail(@PathVariable String code) {
        return new WorkflowDetail(service.summary(code), service.versions(code), assignments.list(code));
    }

    @GetMapping("/{code}/states")
    @Operation(summary = "States of the active version (status filter options, tabs)")
    public List<StateView> states(@PathVariable String code) {
        return service.activeStates(code);
    }

    @GetMapping("/{code}/active")
    @PreAuthorize("hasAuthority('WORKFLOW:VIEW')")
    public WorkflowModel active(@PathVariable String code) {
        return service.activeModel(code);
    }

    @GetMapping("/{code}/versions/{versionNo}")
    @PreAuthorize("hasAuthority('WORKFLOW:VIEW')")
    public WorkflowModel version(@PathVariable String code, @PathVariable int versionNo) {
        return service.versionModel(code, versionNo);
    }

    @GetMapping("/{code}/versions/{from}/compare/{to}")
    @PreAuthorize("hasAuthority('WORKFLOW:VIEW')")
    public Map<String, Object> compare(@PathVariable String code, @PathVariable int from, @PathVariable int to) {
        return service.compare(code, from, to);
    }

    @GetMapping("/{code}/changes")
    @PreAuthorize("hasAuthority('WORKFLOW:VIEW')")
    @Operation(summary = "Workflow change log (who changed what, when)")
    public List<ChangeLogEntry> changes(@PathVariable String code) {
        return service.changes(code);
    }

    // ------------------------------------------------------------------ draft
    @GetMapping("/{code}/draft")
    @PreAuthorize("hasAuthority('WORKFLOW:VIEW')")
    @Operation(summary = "Current draft (or a copy of the active version when no draft exists) + validation issues")
    public DraftResponse draft(@PathVariable String code) {
        return service.draft(code);
    }

    @PutMapping("/{code}/draft")
    @PreAuthorize("hasAuthority('WORKFLOW:CONFIGURE')")
    @Operation(summary = "Replace the whole draft document (visual designer save)")
    public DraftResponse saveDraft(@PathVariable String code, @RequestBody WorkflowModel model) {
        return service.saveDraft(code, model);
    }

    @DeleteMapping("/{code}/draft")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    @PreAuthorize("hasAuthority('WORKFLOW:CONFIGURE')")
    public void discardDraft(@PathVariable String code) {
        service.discardDraft(code);
    }

    @PostMapping("/{code}/draft/validate")
    @PreAuthorize("hasAuthority('WORKFLOW:VIEW')")
    @Operation(summary = "Invalid workflow state validation (unreachable states, dead ends, unknown states/rules, bad expressions ...)")
    public List<WorkflowValidator.Issue> validate(@PathVariable String code) {
        return service.validateDraft(code);
    }

    @PutMapping("/{code}/draft/states/{stateCode}")
    @PreAuthorize("hasAuthority('WORKFLOW:CONFIGURE')")
    @Operation(summary = "Add or update a state")
    public DraftResponse upsertState(@PathVariable String code, @PathVariable String stateCode, @RequestBody StateDef state) {
        return service.upsertState(code, new StateDef(stateCode, state.label(), state.category(), state.tab(),
                state.description(), state.attributes()));
    }

    @DeleteMapping("/{code}/draft/states/{stateCode}")
    @PreAuthorize("hasAuthority('WORKFLOW:CONFIGURE')")
    public DraftResponse deleteState(@PathVariable String code, @PathVariable String stateCode) {
        return service.deleteState(code, stateCode);
    }

    @PutMapping("/{code}/draft/transitions/{transitionCode}")
    @PreAuthorize("hasAuthority('WORKFLOW:CONFIGURE')")
    @Operation(summary = "Add or update a transition (from/to, roles, permissions, required fields, rules, approval)")
    public DraftResponse upsertTransition(@PathVariable String code, @PathVariable String transitionCode,
                                          @RequestBody TransitionDef t) {
        return service.upsertTransition(code, new TransitionDef(transitionCode, t.label(), t.from(), t.to(),
                t.allowedRoles(), t.requiredPermissions(), t.requiredFields(), t.rules(), t.guard(),
                t.requiresApproval(), t.approverRoles(), t.approverPermission(), t.systemOnly(), t.attributes()));
    }

    @DeleteMapping("/{code}/draft/transitions/{transitionCode}")
    @PreAuthorize("hasAuthority('WORKFLOW:CONFIGURE')")
    public DraftResponse deleteTransition(@PathVariable String code, @PathVariable String transitionCode) {
        return service.deleteTransition(code, transitionCode);
    }

    @PutMapping("/{code}/draft/rules/{ruleCode}")
    @PreAuthorize("hasAuthority('WORKFLOW:CONFIGURE')")
    @Operation(summary = "Add or update a reusable rule (SpEL over #entity, #payload, #actor, #config)")
    public DraftResponse upsertRule(@PathVariable String code, @PathVariable String ruleCode, @RequestBody RuleDef r) {
        return service.upsertRule(code, new RuleDef(ruleCode, r.description(), r.expression(), r.errorMessage()));
    }

    @DeleteMapping("/{code}/draft/rules/{ruleCode}")
    @PreAuthorize("hasAuthority('WORKFLOW:CONFIGURE')")
    public DraftResponse deleteRule(@PathVariable String code, @PathVariable String ruleCode) {
        return service.deleteRule(code, ruleCode);
    }

    @PostMapping("/rules/test")
    @PreAuthorize("hasAuthority('WORKFLOW:CONFIGURE')")
    @Operation(summary = "Evaluate a rule expression against sample data (rule builder 'Test' button)")
    public RuleTestResponse testRule(@Valid @RequestBody RuleTestRequest req) {
        return service.testRule(req);
    }

    // ------------------------------------------------------------------ versions
    @PostMapping("/{code}/publish")
    @PreAuthorize("hasAuthority('WORKFLOW:PUBLISH')")
    @Operation(summary = "Validate and freeze the draft as version N+1 (activate=true by default). 422 with issues when invalid")
    public VersionSummary publish(@PathVariable String code, @Valid @RequestBody PublishRequest req) {
        return service.publish(code, req.changeSummary(), req.activate() == null || req.activate());
    }

    @PostMapping("/{code}/versions/{versionNo}/activate")
    @PreAuthorize("hasAuthority('WORKFLOW:PUBLISH')")
    @Operation(summary = "Make a published version active for new records (rollback)")
    public WorkflowSummary activate(@PathVariable String code, @PathVariable int versionNo) {
        return service.activate(code, versionNo);
    }
}
