package com.ags.health.hr.workflow.service;

import com.ags.health.hr.platform.security.CurrentUser;
import com.ags.health.hr.platform.security.DataScope;
import com.ags.health.hr.platform.web.ApiException;
import com.ags.health.hr.workflow.WorkflowProperties;
import com.ags.health.hr.workflow.domain.WorkflowAssignment;
import com.ags.health.hr.workflow.domain.WorkflowDefinition;
import com.ags.health.hr.workflow.engine.AssignmentMatcher;
import com.ags.health.hr.workflow.repo.WorkflowAssignmentRepository;
import com.ags.health.hr.workflow.web.WorkflowDtos.AssignmentRequest;
import com.ags.health.hr.workflow.web.WorkflowDtos.AssignmentResponse;
import com.ags.health.hr.workflow.web.WorkflowDtos.Criteria;
import com.ags.health.hr.workflow.web.WorkflowDtos.ResolveResponse;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;

/**
 * HR decides which workflow applies to a job, a job role, an LOB, a location, a hiring type - or any
 * combination (e.g. "AR Caller" + "AR_CALLING" + "CHENNAI"). Most specific match wins at runtime.
 *
 * <p>Guard rails: users below ALL-level scope may only create assignments for LOBs they supervise, and the
 * catch-all default (no criteria) is reserved to ALL-level users (Admin / TA Head).
 */
@Service
@Transactional
public class AssignmentService {

    private final WorkflowAssignmentRepository repo;
    private final DefinitionService definitions;
    private final WorkflowProperties props;
    private final ChangeLogger changeLogger;

    public AssignmentService(WorkflowAssignmentRepository repo, DefinitionService definitions,
                             WorkflowProperties props, ChangeLogger changeLogger) {
        this.repo = repo;
        this.definitions = definitions;
        this.props = props;
        this.changeLogger = changeLogger;
    }

    @Transactional(readOnly = true)
    public List<AssignmentResponse> list(String workflowCode) {
        List<WorkflowAssignment> rows = workflowCode == null ? repo.findAllByOrderByEntityTypeAscCreatedAtDesc()
                : repo.findByWorkflowCodeOrderByCreatedAtDesc(workflowCode);
        return rows.stream().map(AssignmentService::view).toList();
    }

    public AssignmentResponse create(AssignmentRequest req, CurrentUser user) {
        WorkflowAssignment a = new WorkflowAssignment();
        a.setId(UUID.randomUUID());
        apply(a, req, user);
        repo.save(a);
        changeLogger.log(a.getWorkflowCode(), "ASSIGNMENT_CREATED", null, describe(a));
        return view(a);
    }

    public AssignmentResponse update(UUID id, AssignmentRequest req, CurrentUser user) {
        WorkflowAssignment a = repo.findById(id).orElseThrow(() -> ApiException.notFound("Workflow assignment", id));
        checkLobScope(a.getLob(), a, user); // may the user touch the existing row at all?
        Map<String, Object> before = describe(a);
        apply(a, req, user);
        Map<String, Object> details = new LinkedHashMap<>();
        details.put("before", before);
        details.put("after", describe(a));
        changeLogger.log(a.getWorkflowCode(), "ASSIGNMENT_UPDATED", null, details);
        return view(a);
    }

    public AssignmentResponse deactivate(UUID id, CurrentUser user) {
        WorkflowAssignment a = repo.findById(id).orElseThrow(() -> ApiException.notFound("Workflow assignment", id));
        checkLobScope(a.getLob(), a, user);
        a.setActive(false);
        changeLogger.log(a.getWorkflowCode(), "ASSIGNMENT_DEACTIVATED", null, describe(a));
        return view(a);
    }

    /** Which workflow would a record with these attributes get? (also used by RuntimeService.start) */
    @Transactional(readOnly = true)
    public ResolveResponse resolve(String entityType, Criteria c) {
        Criteria criteria = c == null ? new Criteria(null, null, null, null, null) : c;
        AssignmentMatcher.Criteria mc = new AssignmentMatcher.Criteria(criteria.jobId(), criteria.jobRole(),
                criteria.lob(), criteria.location(), criteria.hiringType());
        List<WorkflowAssignment> active = repo.findByEntityTypeAndActiveTrue(entityType);
        Optional<WorkflowAssignment> best = active.stream()
                .map(a -> Map.entry(a, a.asCandidate()))
                .filter(e -> AssignmentMatcher.matches(e.getValue(), mc))
                .max((x, y) -> {
                    int s = Integer.compare(AssignmentMatcher.specificity(x.getValue()), AssignmentMatcher.specificity(y.getValue()));
                    if (s != 0) {
                        return s;
                    }
                    int p = Integer.compare(x.getValue().priority(), y.getValue().priority());
                    return p != 0 ? p : Long.compare(x.getValue().createdAtEpochMillis(), y.getValue().createdAtEpochMillis());
                })
                .map(Map.Entry::getKey);
        if (best.isPresent()) {
            WorkflowAssignment a = best.get();
            return new ResolveResponse(a.getWorkflowCode(), activeVersion(a.getWorkflowCode()), a.getId(), matchedBy(a));
        }
        String fallback = props.defaultWorkflows().get(entityType);
        if (fallback == null) {
            throw ApiException.conflict("NO_WORKFLOW", "No workflow assignment matches and no default is configured for "
                    + entityType);
        }
        return new ResolveResponse(fallback, activeVersion(fallback), null, "DEFAULT_CONFIGURATION");
    }

    @Transactional(readOnly = true)
    public Integer activeVersion(String code) {
        return definitions.summary(code).activeVersion();
    }

    private void apply(WorkflowAssignment a, AssignmentRequest req, CurrentUser user) {
        WorkflowDefinition wf = definitions.definition(req.workflowCode());
        if (wf.getActiveVersion() == null) {
            throw ApiException.conflict("NOT_PUBLISHED", "Publish workflow " + req.workflowCode() + " before assigning it");
        }
        a.setWorkflowCode(wf.getCode());
        a.setEntityType(wf.getEntityType());
        a.setJobId(blankToNull(req.jobId()));
        a.setJobRole(blankToNull(req.jobRole()));
        a.setLob(blankToNull(req.lob()));
        a.setLocation(blankToNull(req.location()));
        a.setHiringType(blankToNull(req.hiringType()));
        a.setPriority(req.priority());
        a.setDescription(req.description());
        a.setActive(req.active() == null || req.active());
        checkLobScope(a.getLob(), a, user);
        if (a.isActive()) {
            AssignmentMatcher.Candidate mine = a.asCandidate();
            boolean duplicate = repo.findByEntityTypeAndActiveTrue(a.getEntityType()).stream()
                    .filter(o -> !o.getId().equals(a.getId()))
                    .anyMatch(o -> AssignmentMatcher.sameCriteria(o.asCandidate(), mine) && o.getPriority() == a.getPriority());
            if (duplicate) {
                throw ApiException.conflict("DUPLICATE_ASSIGNMENT",
                        "An active assignment with the same criteria and priority already exists");
            }
        }
    }

    private static void checkLobScope(String lob, WorkflowAssignment a, CurrentUser user) {
        if (user == null || user.isSystem() || user.scope().level() == DataScope.Level.ALL) {
            return;
        }
        boolean noCriteria = a.getJobId() == null && a.getJobRole() == null && a.getLob() == null
                && a.getLocation() == null && a.getHiringType() == null;
        if (noCriteria) {
            throw ApiException.forbidden("Only Admin / TA Head can change the default (catch-all) assignment");
        }
        if (lob == null) {
            throw ApiException.forbidden("Specify the LOB - you can only assign workflows within your LOBs "
                    + user.scope().lobs());
        }
        if (!user.scope().lobs().contains(lob)) {
            throw ApiException.forbidden("LOB " + lob + " is outside your scope " + user.scope().lobs());
        }
    }

    private static String matchedBy(WorkflowAssignment a) {
        StringBuilder sb = new StringBuilder();
        append(sb, "jobId", a.getJobId());
        append(sb, "jobRole", a.getJobRole());
        append(sb, "lob", a.getLob());
        append(sb, "location", a.getLocation());
        append(sb, "hiringType", a.getHiringType());
        return sb.isEmpty() ? "DEFAULT_ASSIGNMENT" : sb.toString();
    }

    private static void append(StringBuilder sb, String key, String value) {
        if (value != null) {
            if (!sb.isEmpty()) {
                sb.append(" + ");
            }
            sb.append(key).append('=').append(value);
        }
    }

    private static Map<String, Object> describe(WorkflowAssignment a) {
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("assignmentId", a.getId().toString());
        m.put("criteria", matchedBy(a));
        m.put("priority", a.getPriority());
        m.put("active", a.isActive());
        return m;
    }

    private static AssignmentResponse view(WorkflowAssignment a) {
        return AssignmentResponse.of(a, AssignmentMatcher.specificity(a.asCandidate()));
    }

    private static String blankToNull(String s) {
        return s == null || s.isBlank() ? null : s.trim();
    }
}
