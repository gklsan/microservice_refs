package com.ags.health.hr.workflow.domain;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.Instant;
import java.util.UUID;

/** Workflow change logging (tracker #30). Append-only. */
@Entity
@Table(name = "workflow_change_log")
@Getter
@Setter
@NoArgsConstructor
public class WorkflowChangeLog {

    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    private UUID id;

    @Column(name = "workflow_code", nullable = false)
    private String workflowCode;

    @Column(nullable = false)
    private String action;

    @Column(name = "version_no")
    private Integer versionNo;

    private String actor;

    @Column(name = "details_json")
    private String detailsJson;

    @Column(name = "occurred_at", nullable = false)
    private Instant occurredAt;
}
