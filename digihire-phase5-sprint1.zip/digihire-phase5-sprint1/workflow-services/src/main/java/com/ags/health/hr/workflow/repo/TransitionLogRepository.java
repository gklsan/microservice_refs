package com.ags.health.hr.workflow.repo;

import com.ags.health.hr.workflow.domain.TransitionLog;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.UUID;

public interface TransitionLogRepository extends JpaRepository<TransitionLog, UUID> {

    List<TransitionLog> findByInstanceIdOrderByOccurredAtAsc(UUID instanceId);
}
