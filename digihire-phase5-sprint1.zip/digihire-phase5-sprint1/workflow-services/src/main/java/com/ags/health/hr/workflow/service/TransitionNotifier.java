package com.ags.health.hr.workflow.service;

import com.ags.health.hr.platform.audit.AuditCategory;
import com.ags.health.hr.platform.audit.AuditEvent;
import com.ags.health.hr.platform.audit.AuditLogger;
import com.ags.health.hr.platform.web.InternalServiceClient;
import com.ags.health.hr.workflow.WorkflowProperties;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;
import org.springframework.transaction.event.TransactionPhase;
import org.springframework.transaction.event.TransactionalEventListener;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * KISS event hand-off: after the transition COMMITS, POST it to notification-engine, which matches its
 * configured triggers (Walk-In, On Hold, Rejection, Interview ...) and sends the emails.
 * The call is async so the user never waits for SMTP; failures are logged to the central audit log.
 * notification-engine de-duplicates on eventId, so a manual replay is safe.
 */
@Component
public class TransitionNotifier {

    private static final Logger log = LoggerFactory.getLogger(TransitionNotifier.class);

    private final InternalServiceClient client;
    private final WorkflowProperties props;
    private final AuditLogger audit;

    public TransitionNotifier(InternalServiceClient client, WorkflowProperties props, AuditLogger audit) {
        this.client = client;
        this.props = props;
        this.audit = audit;
    }

    @Async
    @TransactionalEventListener(phase = TransactionPhase.AFTER_COMMIT)
    public void onTransition(RuntimeService.TransitionCompleted e) {
        if (!props.notification().enabled() || props.notification().url() == null) {
            return;
        }
        Map<String, Object> data = new LinkedHashMap<>(e.context());
        data.putAll(e.payload());
        Map<String, Object> actor = new LinkedHashMap<>();
        actor.put("id", e.actorId());
        actor.put("name", e.actorName());
        actor.put("email", e.actorEmail());

        Map<String, Object> event = new LinkedHashMap<>();
        event.put("eventId", e.eventId().toString());
        event.put("eventType", "WORKFLOW_TRANSITION");
        event.put("workflowCode", e.workflowCode());
        event.put("versionNo", e.versionNo());
        event.put("transitionCode", e.transitionCode());
        event.put("fromState", e.fromState());
        event.put("toState", e.toState());
        event.put("entityType", e.entityType());
        event.put("entityId", e.entityId());
        event.put("candidateId", e.candidateId());
        event.put("actor", actor);
        event.put("remarks", e.remarks());
        event.put("occurredAt", e.occurredAt().toString());
        event.put("data", data);
        try {
            client.post(props.notification().url(), event, Void.class);
        } catch (RuntimeException ex) {
            log.warn("Notification hand-off failed for event {} ({}): {}", e.eventId(), e.transitionCode(), ex.getMessage());
            audit.log(AuditEvent.builder(AuditCategory.NOTIFICATION, "NOTIFICATION_HANDOFF_FAILED")
                    .entity(e.entityType(), e.entityId()).candidate(e.candidateId())
                    .outcome(AuditEvent.Outcome.FAILURE)
                    .detail("eventId", e.eventId().toString()).detail("transition", e.transitionCode())
                    .detail("error", ex.getMessage()).build());
        }
    }
}
