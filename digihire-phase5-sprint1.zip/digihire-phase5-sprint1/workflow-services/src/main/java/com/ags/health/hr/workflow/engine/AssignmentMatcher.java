package com.ags.health.hr.workflow.engine;

import java.util.Comparator;
import java.util.List;
import java.util.Optional;

/**
 * Picks the workflow for a record from HR-defined assignments (job / job role / LOB / location / hiring type or any
 * combination). An assignment matches when every criterion it sets equals the record's value; unset criteria are
 * wildcards. The most specific match wins; weights make a job-level rule beat a role-level rule beat an LOB rule:
 * <pre>
 *   jobId 16 | jobRole 8 | lob 4 | location 2 | hiringType 1      (ties: higher priority, then newest)
 * </pre>
 * An assignment with no criteria at all is the default for the entity type.
 */
public final class AssignmentMatcher {

    private AssignmentMatcher() {
    }

    /** Values of the record being started (any may be null). */
    public record Criteria(String jobId, String jobRole, String lob, String location, String hiringType) {
    }

    /** Minimal view of an assignment row. */
    public interface Candidate {
        String jobId();
        String jobRole();
        String lob();
        String location();
        String hiringType();
        int priority();
        long createdAtEpochMillis();
    }

    public static <T extends Candidate> Optional<T> bestMatch(List<T> assignments, Criteria c) {
        return assignments.stream()
                .filter(a -> matches(a, c))
                .max(Comparator.<T>comparingInt(AssignmentMatcher::specificity)
                        .thenComparingInt(Candidate::priority)
                        .thenComparingLong(Candidate::createdAtEpochMillis));
    }

    public static boolean matches(Candidate a, Criteria c) {
        return eq(a.jobId(), c.jobId()) && eq(a.jobRole(), c.jobRole()) && eq(a.lob(), c.lob())
                && eq(a.location(), c.location()) && eq(a.hiringType(), c.hiringType());
    }

    public static int specificity(Candidate a) {
        return (set(a.jobId()) ? 16 : 0) + (set(a.jobRole()) ? 8 : 0) + (set(a.lob()) ? 4 : 0)
                + (set(a.location()) ? 2 : 0) + (set(a.hiringType()) ? 1 : 0);
    }

    /** Same criteria combination (used to reject duplicates). */
    public static boolean sameCriteria(Candidate a, Candidate b) {
        return same(a.jobId(), b.jobId()) && same(a.jobRole(), b.jobRole()) && same(a.lob(), b.lob())
                && same(a.location(), b.location()) && same(a.hiringType(), b.hiringType());
    }

    private static boolean eq(String rule, String value) {
        return !set(rule) || (value != null && rule.equalsIgnoreCase(value.trim()));
    }

    private static boolean same(String a, String b) {
        return set(a) ? set(b) && a.equalsIgnoreCase(b) : !set(b);
    }

    private static boolean set(String s) {
        return s != null && !s.isBlank();
    }
}
