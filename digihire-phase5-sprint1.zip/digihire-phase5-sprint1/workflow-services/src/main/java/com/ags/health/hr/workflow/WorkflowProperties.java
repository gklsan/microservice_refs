package com.ags.health.hr.workflow;

import org.springframework.boot.context.properties.ConfigurationProperties;

import java.time.Duration;
import java.util.Map;

@ConfigurationProperties(prefix = "digihire.workflow")
public record WorkflowProperties(boolean seedEnabled,
                                 Map<String, String> defaultWorkflows,
                                 Notification notification,
                                 String configUrl,
                                 Duration configCacheTtl) {

    public WorkflowProperties {
        defaultWorkflows = defaultWorkflows == null ? Map.of("APPLICATION", "APPLICATION_HIRING") : defaultWorkflows;
        notification = notification == null ? new Notification(false, null) : notification;
        configCacheTtl = configCacheTtl == null ? Duration.ofMinutes(5) : configCacheTtl;
    }

    public record Notification(boolean enabled, String url) {
    }
}
