package com.ags.health.hr.workflow.repo;

import com.ags.health.hr.workflow.domain.ApprovalRequest;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;
import java.util.UUID;

public interface ApprovalRequestRepository extends JpaRepository<ApprovalRequest, UUID> {

    Page<ApprovalRequest> findByStatusOrderByCreatedAtDesc(ApprovalRequest.Status status, Pageable pageable);

    Optional<ApprovalRequest> findFirstByInstanceIdAndStatus(UUID instanceId, ApprovalRequest.Status status);
}
