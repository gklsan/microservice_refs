package com.ags.health.hr.workflow.repo;

import com.ags.health.hr.workflow.domain.WorkflowDefinition;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

public interface WorkflowDefinitionRepository extends JpaRepository<WorkflowDefinition, UUID> {

    Optional<WorkflowDefinition> findByCode(String code);

    boolean existsByCode(String code);

    List<WorkflowDefinition> findAllByOrderByCodeAsc();
}
