package com.ags.health.hr.workflow.domain;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.Instant;
import java.util.UUID;

/** Immutable published version (tracker #29 workflow versioning). */
@Entity
@Table(name = "workflow_version")
@Getter
@Setter
@NoArgsConstructor
public class WorkflowVersion {

    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    private UUID id;

    @Column(name = "workflow_code", nullable = false, updatable = false)
    private String workflowCode;

    @Column(name = "version_no", nullable = false, updatable = false)
    private int versionNo;

    @Column(name = "definition_json", nullable = false, updatable = false)
    private String definitionJson;

    @Column(name = "change_summary")
    private String changeSummary;

    @Column(name = "published_by")
    private String publishedBy;

    @Column(name = "published_at", nullable = false)
    private Instant publishedAt;
}
