package com.ags.health.hr.workflow.engine;

import com.ags.health.hr.workflow.engine.WorkflowModel.StateCategory;
import com.ags.health.hr.workflow.engine.WorkflowModel.StateDef;
import com.ags.health.hr.workflow.engine.WorkflowModel.TransitionDef;
import org.junit.jupiter.api.Test;

import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;

class WorkflowValidatorTest {

    private final WorkflowValidator validator = new WorkflowValidator(new RuleEvaluator());

    private static StateDef s(String code, StateCategory c) {
        return new StateDef(code, code, c, null, null, null);
    }

    private static TransitionDef t(String code, List<String> from, String to, String guard) {
        return new TransitionDef(code, code, from, to, null, null, null, null, guard, false, null, null, false, null);
    }

    @Test
    void detectsStructuralProblems() {
        WorkflowModel m = new WorkflowModel("TEST", "t", "APPLICATION", null,
                List.of(s("A", StateCategory.INITIAL), s("B", StateCategory.INTERMEDIATE),
                        s("ORPHAN", StateCategory.INTERMEDIATE), s("END", StateCategory.TERMINAL)),
                List.of(t("A_B", List.of("A"), "B", null),
                        t("B_END", List.of("B"), "END", "#payload[ 'x' ] >"),       // bad expression
                        t("END_A", List.of("END"), "A", null),                      // out of terminal
                        t("B_GHOST", List.of("B"), "GHOST", null)),                  // unknown target
                List.of());
        List<String> codes = validator.validate(m).stream()
                .filter(i -> i.severity() == WorkflowValidator.Severity.ERROR)
                .map(WorkflowValidator.Issue::code).toList();
        assertThat(codes).contains("UNREACHABLE_STATE", "INVALID_EXPRESSION", "FROM_TERMINAL", "UNKNOWN_STATE");
    }
}
