package com.ags.health.hr.workflow.engine;

import org.junit.jupiter.api.Test;

import java.util.List;
import java.util.Map;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

class RuleEvaluatorTest {

    private final RuleEvaluator evaluator = new RuleEvaluator();

    private RuleEvaluator.RuleContext ctx(Map<String, Object> entity) {
        return new RuleEvaluator.RuleContext(entity, Map.of("score", "61"),
                Map.of("roles", List.of("TL")), Map.of(), Map.of("pass", "43"));
    }

    @Test
    void evaluatesDataFunctionsAndConfig() {
        assertThat(evaluator.evaluate("#num(#payload['score']) >= #num(#config['pass'])", ctx(Map.of()))).isTrue();
        assertThat(evaluator.evaluate("#actor['roles'].contains('TL')", ctx(Map.of()))).isTrue();
        assertThat(evaluator.evaluate("#entity['lob'] == 'AR_CALLING'", ctx(Map.of("lob", "AR_CALLING")))).isTrue();
        assertThat(evaluator.evaluate("#daysSince('2020-01-01') > 30", ctx(Map.of()))).isTrue();
    }

    @Test
    void sandboxBlocksTypeReferences() {
        assertThatThrownBy(() -> evaluator.evaluate("T(java.lang.Runtime).getRuntime() != null", ctx(Map.of())))
                .isInstanceOf(RuntimeException.class);
        assertThatThrownBy(() -> evaluator.evaluate("new java.io.File('/tmp').exists()", ctx(Map.of())))
                .isInstanceOf(RuntimeException.class);
    }
}
