package com.ags.health.hr.workflow.engine;

import com.ags.health.hr.workflow.engine.WorkflowModel.Blueprint;
import com.ags.health.hr.workflow.engine.WorkflowModel.StateCategory;
import com.ags.health.hr.workflow.engine.WorkflowModel.StateDef;
import com.ags.health.hr.workflow.engine.WorkflowModel.StepDef;
import com.ags.health.hr.workflow.engine.WorkflowModel.TransitionDef;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.Test;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import static org.assertj.core.api.Assertions.assertThat;

/** HR reconfigures steps: make a step optional, insert a library step with a parameter, and the engine follows. */
class StepCompilerTest {

    private final ObjectMapper om = new ObjectMapper().configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
    private final WorkflowValidator validator = new WorkflowValidator(new RuleEvaluator());

    private <T> T read(String path, Class<T> type) throws Exception {
        try (InputStream in = getClass().getResourceAsStream(path)) {
            return om.readValue(in, type);
        }
    }

    @Test
    void seededFresherWorkflowKeepsLegacyStatusCodes() throws Exception {
        WorkflowModel m = StepCompiler.compile(read("/workflows/application-hiring.json", WorkflowModel.class)).model();
        assertThat(m.states()).hasSize(28);
        assertThat(m.transition("SCHEDULE_HR_ROUND").orElseThrow().from()).containsExactly("VERSANT_COMPLETED");
        assertThat(m.transition("HR_SELECT").orElseThrow().to()).isEqualTo("PANEL_YET_TO_SCHEDULE");
    }

    @Test
    void hrCanMakeStepsOptionalAndInsertLibrarySteps() throws Exception {
        WorkflowModel draft = read("/workflows/application-hiring.json", WorkflowModel.class);
        Blueprint bp = draft.blueprint();
        List<StepDef> steps = new ArrayList<>(bp.steps());
        int versant = steps.stream().map(StepDef::code).toList().indexOf("VERSANT");
        StepDef v = steps.get(versant);
        steps.set(versant, new StepDef(v.code(), v.label(), v.type(), v.tab(), true, v.description(), v.parameters(),
                v.stages(), v.entryAction(), v.actions(), v.templateCode()));

        JsonNode doc = read("/step-library/online-assessment.json", JsonNode.class);
        StepDef tpl = om.treeToValue(doc.get("step"), StepDef.class);
        Map<String, Object> params = new LinkedHashMap<>(tpl.parameters());
        params.put("passScore", 70);
        steps.add(versant + 1, new StepDef("SHL", "SHL cognitive test", tpl.type(), tpl.tab(), false, null, params,
                tpl.stages(), tpl.entryAction(), tpl.actions(), "ONLINE_ASSESSMENT"));

        StepCompiler.Result r = StepCompiler.compile(draft.withBlueprint(bp.withSteps(steps)));
        List<WorkflowValidator.Issue> issues = new ArrayList<>(r.issues());
        issues.addAll(validator.validate(r.model()));
        assertThat(WorkflowValidator.hasErrors(issues)).isFalse();

        WorkflowModel m = r.model();
        assertThat(m.transition("SHL_ASSIGN").orElseThrow().from())
                .containsExactlyInAnyOrder("VERSANT_COMPLETED", "ASSESEMENT_COMPLETED"); // Versant can be skipped
        assertThat(m.transition("SHL_PASS").orElseThrow().guard()).isEqualTo("#num(#payload['score']) >= 70");
        assertThat(m.transition("SCHEDULE_HR_ROUND").orElseThrow().from()).containsExactly("SHL_PASSED");
    }

    @Test
    void reportsUnknownStepTokens() {
        StepDef s = new StepDef("ONE", "One", "TASK", null, false, null, null,
                List.of(new WorkflowModel.StageDef("ONE_DONE", "Done", StateCategory.TERMINAL, false, null, null)), null,
                List.of(), null);
        Blueprint bp = new Blueprint(List.of(new StateDef("CREATED", "Created", StateCategory.INITIAL, null, null, null)),
                List.of("CREATED"), null, List.of(s),
                List.of(new TransitionDef("GO", "Go", List.of("STEP:MISSING"), "REJECT", null, null, null, null, null,
                        false, null, null, false, null)), List.of());
        StepCompiler.Result r = StepCompiler.compile(new WorkflowModel("T", "t", "APPLICATION", null, null, null, null, bp));
        assertThat(r.issues().stream().map(WorkflowValidator.Issue::code).collect(Collectors.toSet()))
                .contains("UNKNOWN_STEP", "NO_REJECTION_STATE");
    }
}
