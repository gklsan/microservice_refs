package com.ags.health.hr.workflow.engine;

import org.junit.jupiter.api.Test;

import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;

class AssignmentMatcherTest {

    record A(String name, String jobId, String jobRole, String lob, String location, String hiringType, int priority,
             long createdAtEpochMillis) implements AssignmentMatcher.Candidate {
    }

    private final List<A> rules = List.of(
            new A("default", null, null, null, null, null, 0, 1),
            new A("lob", null, null, "AR_CALLING", null, null, 0, 2),
            new A("lob+location", null, null, "AR_CALLING", "CHENNAI", null, 0, 3),
            new A("role", null, "AR Caller", null, null, null, 0, 4),
            new A("job", "JOB-1", null, null, null, null, 0, 5),
            new A("lateral", null, null, null, null, "LATERAL", 0, 6));

    private String pick(String jobId, String role, String lob, String location, String type) {
        return AssignmentMatcher.bestMatch(rules, new AssignmentMatcher.Criteria(jobId, role, lob, location, type))
                .map(A::name).orElse("none");
    }

    @Test
    void mostSpecificWins() {
        assertThat(pick(null, null, "MEDICAL_CODING", "CHENNAI", "FRESHER")).isEqualTo("default");
        assertThat(pick(null, null, "AR_CALLING", "COIMBATORE", null)).isEqualTo("lob");
        assertThat(pick(null, null, "AR_CALLING", "CHENNAI", null)).isEqualTo("lob+location");
        assertThat(pick(null, "AR Caller", "AR_CALLING", "CHENNAI", null)).isEqualTo("role");
        assertThat(pick("JOB-1", "AR Caller", "AR_CALLING", "CHENNAI", "LATERAL")).isEqualTo("job");
        assertThat(pick(null, null, null, null, "lateral")).isEqualTo("lateral");
    }
}
