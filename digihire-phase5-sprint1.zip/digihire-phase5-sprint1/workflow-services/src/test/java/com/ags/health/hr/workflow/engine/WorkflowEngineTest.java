package com.ags.health.hr.workflow.engine;

import com.ags.health.hr.workflow.engine.WorkflowEngine.Actor;
import com.ags.health.hr.workflow.engine.WorkflowEngine.Decision;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import java.io.InputStream;
import java.time.LocalDate;
import java.util.List;
import java.util.Map;
import java.util.Set;

import static org.assertj.core.api.Assertions.assertThat;

/** Pure unit tests of the engine against the seeded APPLICATION_HIRING workflow. */
class WorkflowEngineTest {

    static WorkflowModel hiring;
    static WorkflowModel lateral;
    static final RuleEvaluator rules = new RuleEvaluator();
    static final WorkflowEngine engine = new WorkflowEngine(rules);
    static final WorkflowValidator validator = new WorkflowValidator(rules);

    static final Actor RECRUITER = new Actor("u1", "Recruiter", Set.of("RECRUITER"),
            Set.of("APPLICATION:MOVE_STAGE", "APPLICATION:SCHEDULE_INTERVIEW", "APPLICATION:REJECT", "APPLICATION:HOLD",
                    "APPLICATION:MAP"), false);
    static final Actor EMPLOYEE = new Actor("u2", "Employee", Set.of("EMPLOYEE"), Set.of("JOB:VIEW"), false);
    static final Actor SYSTEM = new Actor(null, "system", Set.of("INTERNAL"), Set.of(), true);

    @BeforeAll
    static void load() throws Exception {
        ObjectMapper om = new ObjectMapper().configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        try (InputStream in = WorkflowEngineTest.class.getResourceAsStream("/workflows/application-hiring.json")) {
            hiring = StepCompiler.compile(om.readValue(in, WorkflowModel.class)).model(); // step-based seed
        }
        try (InputStream in = WorkflowEngineTest.class.getResourceAsStream("/workflows/lateral-hiring.json")) {
            lateral = StepCompiler.compile(om.readValue(in, WorkflowModel.class)).model();
        }
    }

    @Test
    void seededWorkflowsAreValid() {
        assertThat(WorkflowValidator.hasErrors(validator.validate(hiring))).isFalse();
        assertThat(WorkflowValidator.hasErrors(validator.validate(lateral))).isFalse();
        assertThat(hiring.states()).hasSize(28);
    }

    @Test
    void rejectsTransitionFromWrongState() {
        Decision d = engine.decide(hiring, "CREATED", "PANEL_SELECT", RECRUITER, Map.of(), Map.of(), Map.of(), true);
        assertThat(d.allowed()).isFalse();
        assertThat(d.violations()).extracting(WorkflowEngine.Violation::code).containsExactly("INVALID_STATE");
    }

    @Test
    void checksPermissionsAndRequiredFields() {
        Decision noPerm = engine.decide(hiring, "CREATED", "MARK_WALKIN", EMPLOYEE, Map.of(),
                Map.of("interviewDate", "2026-10-01"), Map.of(), true);
        assertThat(noPerm.violations()).extracting(WorkflowEngine.Violation::code).contains("MISSING_PERMISSION");

        Decision noField = engine.decide(hiring, "CREATED", "MARK_WALKIN", RECRUITER, Map.of(), Map.of(), Map.of(), true);
        assertThat(noField.violations()).extracting(WorkflowEngine.Violation::code).containsExactly("MISSING_FIELD");

        Decision ok = engine.decide(hiring, "CREATED", "MARK_WALKIN", RECRUITER, Map.of(),
                Map.of("interviewDate", "2026-10-01"), Map.of(), true);
        assertThat(ok.allowed()).isTrue();
    }

    @Test
    void systemOnlyTransitionsAreBlockedForUsers() {
        Decision user = engine.decide(hiring, "VERSANT_INPROGRESS", "VERSANT_PASSED", RECRUITER, Map.of(),
                Map.of("score", 60), Map.of(), true);
        assertThat(user.violations()).extracting(WorkflowEngine.Violation::code).contains("SYSTEM_ONLY");
    }

    @Test
    void rulesReadEnterpriseConfig() {
        Map<String, String> config = Map.of("assessment.versant.pass-score", "50");
        Decision below = engine.decide(hiring, "VERSANT_INPROGRESS", "VERSANT_PASSED", SYSTEM, Map.of(),
                Map.of("score", 45), config, true);
        assertThat(below.allowed()).isFalse();
        Decision above = engine.decide(hiring, "VERSANT_INPROGRESS", "VERSANT_PASSED", SYSTEM, Map.of(),
                Map.of("score", 55), config, true);
        assertThat(above.allowed()).isTrue();
    }

    @Test
    void coolingPeriodAndApproval() {
        Map<String, Object> cooling = Map.of("coolingPeriodEndDate", LocalDate.now().plusDays(3).toString());
        Decision blocked = engine.decide(hiring, "VERSANT_FAILED", "REINITIATE_VERSANT", RECRUITER, cooling,
                Map.of("remarks", "retry"), Map.of(), true);
        assertThat(blocked.allowed()).isFalse();

        Map<String, Object> over = Map.of("coolingPeriodEndDate", LocalDate.now().minusDays(1).toString());
        Decision allowed = engine.decide(hiring, "VERSANT_FAILED", "REINITIATE_VERSANT", RECRUITER, over,
                Map.of("remarks", "retry"), Map.of(), true);
        assertThat(allowed.allowed()).isTrue();
        assertThat(allowed.requiresApproval()).isTrue();
    }

    @Test
    void panelSelectNeedsPhotoConfirmation() {
        Decision d = engine.decide(hiring, "PANEL_INPROGRESS", "PANEL_SELECT", RECRUITER, Map.of(),
                Map.of("feedback", "good", "sameCandidate", false), Map.of(), true);
        assertThat(d.allowed()).isFalse();
    }

    @Test
    void optionsListOnlyManualTransitions() {
        List<WorkflowEngine.Option> options = engine.options(hiring, "VERSANT_INPROGRESS", RECRUITER, Map.of(), Map.of());
        // pass / fail are systemOnly (Versant integration); only the global reject is offered to users
        assertThat(options).extracting(WorkflowEngine.Option::code).containsExactly("REJECT_APPLICATION");
        assertThat(engine.options(hiring, "CREATED", RECRUITER, Map.of(), Map.of()))
                .extracting(WorkflowEngine.Option::code).contains("MARK_WALKIN", "PUT_ON_HOLD", "REJECT_APPLICATION");
    }
}
