package com.ags.health.hr.platform;

import com.ags.health.hr.platform.security.AccessEvaluator;
import com.ags.health.hr.platform.security.AccessEvaluator.Target;
import com.ags.health.hr.platform.security.CurrentUser;
import com.ags.health.hr.platform.security.DataScope;
import org.junit.jupiter.api.Test;

import java.util.Map;
import java.util.Set;

import static org.assertj.core.api.Assertions.assertThat;

/** BRD 4.3 visibility rules. */
class AccessEvaluatorTest {

    private static CurrentUser user(DataScope.Level level, Set<String> team, Set<String> lobs, Map<String, Set<String>> shared) {
        return new CurrentUser("me", "me@agshealth.com", "Me", "EMPLOYEE_HR", Set.of("RECRUITER"),
                Set.of("CANDIDATE:VIEW"), new DataScope(level, "me", team, lobs, Set.of(), shared), null);
    }

    @Test
    void recruiterSeesOwnAndSharedOnly() {
        CurrentUser r = user(DataScope.Level.OWN, Set.of(), Set.of(), Map.of("CANDIDATE", Set.of("c-shared")));
        assertThat(AccessEvaluator.check(r, "CANDIDATE:VIEW", new Target("CANDIDATE", "c1", "me", "AR", null)).allowed()).isTrue();
        assertThat(AccessEvaluator.check(r, "CANDIDATE:VIEW", new Target("CANDIDATE", "c2", "other", "AR", null)).allowed()).isFalse();
        assertThat(AccessEvaluator.check(r, "CANDIDATE:VIEW", new Target("CANDIDATE", "c-shared", "other", "AR", null)).allowed()).isTrue();
        assertThat(AccessEvaluator.check(r, "CANDIDATE:EXPORT", new Target("CANDIDATE", "c1", "me", null, null)).reason())
                .isEqualTo("MISSING_PERMISSION");
    }

    @Test
    void tlSeesTeamAndSupervisedLob() {
        CurrentUser tl = user(DataScope.Level.LOB, Set.of("rec-1"), Set.of("AR_CALLING"), Map.of());
        assertThat(AccessEvaluator.check(tl, null, new Target("CANDIDATE", "c1", "rec-1", "MEDICAL_CODING", null)).reason()).isEqualTo("TEAM");
        assertThat(AccessEvaluator.check(tl, null, new Target("CANDIDATE", "c2", "x", "AR_CALLING", null)).reason()).isEqualTo("LOB");
        assertThat(AccessEvaluator.check(tl, null, new Target("CANDIDATE", "c3", "x", "MEDICAL_CODING", null)).allowed()).isFalse();
    }
}
