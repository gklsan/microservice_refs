import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { MatSnackBar } from '@angular/material/snack-bar';
import { ConfigView, PERMISSIONS } from '../../models/admin.models';
import { AdminApiService } from '../../services/admin-api.service';
import { RbacService } from '../../services/rbac.service';
import { errorMessage } from '../../utils/api-error.util';
import { ConfigFormDialogComponent, ConfigFormDialogData } from '../config-form-dialog/config-form-dialog.component';

interface CategoryGroup {
  category: string;
  items: ConfigView[];
}

/**
 * Tracker #32 "Restrict enterprise configuration to Admin". CONFIG:VIEW reads, only an active Super Admin
 * with CONFIG:MANAGE changes. Credentials are refused by the server (USE_SECRET_STORE).
 */
@Component({
  selector: 'app-admin-config-list',
  templateUrl: './config-list.component.html',
  styleUrls: ['./config-list.component.scss'],
})
export class ConfigListComponent implements OnInit {
  all: ConfigView[] = [];
  groups: CategoryGroup[] = [];
  categories: string[] = [];
  category = '';
  filter = '';
  loading = true;
  error = '';

  constructor(
    private api: AdminApiService,
    public rbac: RbacService,
    private dialog: MatDialog,
    private snack: MatSnackBar
  ) {}

  get canEdit(): boolean {
    return this.rbac.canManage(PERMISSIONS.CONFIG_MANAGE);
  }

  async ngOnInit(): Promise<void> {
    await this.rbac.ensureLoaded();
    await this.load();
  }

  async load(): Promise<void> {
    this.loading = true;
    this.error = '';
    try {
      this.all = await this.api.configs();
      this.categories = [...new Set(this.all.map((c) => c.category))].sort();
      this.regroup();
    } catch (e) {
      this.error = errorMessage(e);
    } finally {
      this.loading = false;
    }
  }

  regroup(): void {
    const q = this.filter.trim().toLowerCase();
    const rows = this.all.filter(
      (c) =>
        (!this.category || c.category === this.category) &&
        (!q || c.key.includes(q) || (c.description ?? '').toLowerCase().includes(q))
    );
    const map = new Map<string, ConfigView[]>();
    rows.forEach((c) => map.set(c.category, [...(map.get(c.category) ?? []), c]));
    this.groups = [...map.entries()].map(([category, items]) => ({ category, items }));
  }

  listValues(c: ConfigView): string[] {
    try {
      const v = JSON.parse(c.value);
      return Array.isArray(v) ? v.map((x) => String(x)) : [c.value];
    } catch {
      return [c.value];
    }
  }

  open(config?: ConfigView): void {
    const data: ConfigFormDialogData = { config, categories: this.categories };
    this.dialog
      .open(ConfigFormDialogComponent, { width: '560px', maxWidth: '95vw', data, disableClose: true })
      .afterClosed()
      .subscribe((saved?: ConfigView) => {
        if (!saved) return;
        this.snack.open(`${saved.key} saved. Other modules read it within 2 minutes.`, 'Close', { duration: 4000 });
        this.load();
      });
  }
}
