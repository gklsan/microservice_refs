import { Component, Inject } from '@angular/core';
import { AbstractControl, FormBuilder, ValidationErrors, ValidatorFn, Validators } from '@angular/forms';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import {
  CONFIG_CATEGORY_PATTERN,
  CONFIG_KEY_PATTERN,
  ConfigValueType,
  ConfigView,
  SECRET_LIKE_KEY,
} from '../../models/admin.models';
import { AdminApiService } from '../../services/admin-api.service';
import { errorMessage } from '../../utils/api-error.util';

export interface ConfigFormDialogData {
  /** undefined = create a new setting */
  config?: ConfigView;
  categories: string[];
}

/** Same checks as admin-services ConfigService.validate, so most mistakes never reach the server. */
export function configValueError(type: ConfigValueType, raw: string): string | null {
  const value = (raw ?? '').trim();
  switch (type) {
    case 'NUMBER':
      return value !== '' && !isNaN(Number(value)) ? null : 'Enter a number';
    case 'BOOLEAN':
      return /^(true|false)$/i.test(value) ? null : 'Pick true or false';
    case 'JSON':
      try {
        JSON.parse(value);
        return null;
      } catch {
        return 'Not valid JSON';
      }
    case 'LIST':
      try {
        return Array.isArray(JSON.parse(value)) ? null : 'Use a JSON array, e.g. [7,30,180]';
      } catch {
        return 'Use a JSON array, e.g. [7,30,180]';
      }
    default:
      return null;
  }
}

/** Create or edit one enterprise setting (tracker #32). Key, type and category are fixed after creation. */
@Component({
  selector: 'app-admin-config-form-dialog',
  templateUrl: './config-form-dialog.component.html',
  styles: [
    `
      .config-form { display: flex; flex-direction: column; gap: 4px; padding-top: 8px; }
      .config-form mat-form-field { width: 100%; }
      .two-col { display: flex; gap: 12px; }
      .two-col mat-form-field { flex: 1; }
      .bool-row { margin: 4px 0 16px; }
      .mono { font-family: monospace; }
      .error { color: #b00020; margin: 0 0 12px; }
      .muted { color: rgba(0, 0, 0, 0.6); }
      .small { font-size: 12px; }
    `,
  ],
})
export class ConfigFormDialogComponent {
  readonly types: ConfigValueType[] = ['STRING', 'NUMBER', 'BOOLEAN', 'LIST', 'JSON'];
  readonly isEdit: boolean;
  saving = false;
  error = '';

  readonly form = this.fb.nonNullable.group(
    {
      key: ['', [Validators.required, Validators.pattern(CONFIG_KEY_PATTERN), secretKeyValidator]],
      valueType: ['STRING' as ConfigValueType, Validators.required],
      category: ['', [Validators.required, Validators.pattern(CONFIG_CATEGORY_PATTERN)]],
      value: ['', [Validators.required, Validators.maxLength(10000)]],
      description: ['', Validators.maxLength(500)],
    },
    { validators: valueMatchesType }
  );

  constructor(
    @Inject(MAT_DIALOG_DATA) public data: ConfigFormDialogData,
    private ref: MatDialogRef<ConfigFormDialogComponent, ConfigView | undefined>,
    private fb: FormBuilder,
    private api: AdminApiService
  ) {
    this.isEdit = !!data.config;
    if (data.config) {
      const c = data.config;
      this.form.patchValue({
        key: c.key,
        valueType: c.valueType,
        category: c.category,
        value: c.value ?? '',
        description: c.description ?? '',
      });
      this.form.controls.key.disable();
      this.form.controls.valueType.disable();
      this.form.controls.category.disable();
    }
  }

  get type(): ConfigValueType {
    return this.form.controls.valueType.value;
  }

  get valueError(): string | null {
    return this.form.errors?.['value'] ?? null;
  }

  /** Category is stored upper case (ASSESSMENT, INTERVIEW ...). */
  upperCategory(): void {
    const c = this.form.controls.category;
    c.setValue(c.value.toUpperCase().replace(/[^A-Z0-9_]/g, '_'));
  }

  async save(): Promise<void> {
    if (this.form.invalid) {
      this.form.markAllAsTouched();
      return;
    }
    const v = this.form.getRawValue();
    this.saving = true;
    this.error = '';
    try {
      const saved = this.isEdit
        ? await this.api.updateConfig(v.key, {
            value: v.value.trim(),
            description: v.description.trim() || undefined,
            version: this.data.config?.version,
          })
        : await this.api.createConfig({
            key: v.key.trim(),
            value: v.value.trim(),
            valueType: v.valueType,
            category: v.category.trim(),
            description: v.description.trim() || undefined,
          });
      this.ref.close(saved);
    } catch (e) {
      this.error = errorMessage(e);
    } finally {
      this.saving = false;
    }
  }

  cancel(): void {
    this.ref.close(undefined);
  }
}

const secretKeyValidator: ValidatorFn = (c: AbstractControl): ValidationErrors | null =>
  SECRET_LIKE_KEY.test(c.value ?? '') ? { secret: true } : null;

const valueMatchesType: ValidatorFn = (g: AbstractControl): ValidationErrors | null => {
  const type = g.get('valueType')?.value as ConfigValueType;
  const msg = configValueError(type, g.get('value')?.value);
  return msg ? { value: msg } : null;
};
