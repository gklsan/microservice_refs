import { Component, OnInit } from '@angular/core';
import { PERMISSIONS } from '../../models/admin.models';
import { RbacService } from '../../services/rbac.service';

/** Tab bar for the admin area. Tabs follow the logged-in user's permissions from /rbac/me. */
@Component({
  selector: 'app-admin-shell',
  template: `
    <nav mat-tab-nav-bar [tabPanel]="panel" class="admin-tabs">
      <ng-container *ngFor="let t of tabs">
        <a mat-tab-link *appHasPermission="t.permission" [routerLink]="t.path" routerLinkActive #rla="routerLinkActive" [active]="rla.isActive">
          {{ t.label }}
        </a>
      </ng-container>
    </nav>
    <mat-tab-nav-panel #panel><router-outlet></router-outlet></mat-tab-nav-panel>
  `,
  styles: ['.admin-tabs { padding: 0 24px; background: #fff; }'],
})
export class AdminShellComponent implements OnInit {
  readonly tabs = [
    { path: 'users', label: 'Users', permission: PERMISSIONS.USER_VIEW },
    { path: 'roles', label: 'Roles and permissions', permission: PERMISSIONS.ROLE_VIEW },
    { path: 'config', label: 'Configuration', permission: PERMISSIONS.CONFIG_VIEW },
  ];

  constructor(private rbac: RbacService) {}

  ngOnInit(): void {
    this.rbac.ensureLoaded();
  }
}
