import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { BehaviorSubject, firstValueFrom } from 'rxjs';
import { environment } from '../../../environments/environment';
import { CheckRequest, CheckResponse, Me, PERMISSIONS, SUPER_ADMIN } from '../models/admin.models';

/**
 * The logged-in user's roles, permissions and scope from admin-services GET /rbac/me.
 * Loaded once after login and cached. Call refresh() after the user's own access may have changed,
 * clear() on logout.
 */
@Injectable({ providedIn: 'root' })
export class RbacService {
  private readonly meSubject = new BehaviorSubject<Me | null>(null);
  readonly me$ = this.meSubject.asObservable();
  private loading?: Promise<Me | null>;

  constructor(private http: HttpClient) {}

  get me(): Me | null {
    return this.meSubject.value;
  }

  ensureLoaded(): Promise<Me | null> {
    if (this.meSubject.value) {
      return Promise.resolve(this.meSubject.value);
    }
    return this.refresh();
  }

  refresh(): Promise<Me | null> {
    if (!this.loading) {
      this.loading = firstValueFrom(this.http.get<Me>(`${environment.API_URL}admin-services/rbac/me`))
        .then((me) => {
          this.meSubject.next(me);
          return me;
        })
        .catch(() => {
          this.meSubject.next(null);
          return null;
        })
        .finally(() => (this.loading = undefined));
    }
    return this.loading;
  }

  clear(): void {
    this.meSubject.next(null);
  }

  has(permission: string): boolean {
    const me = this.meSubject.value;
    return !!me && me.active && me.permissions.includes(permission);
  }

  hasRole(role: string): boolean {
    const me = this.meSubject.value;
    return !!me && me.active && me.roles.includes(role);
  }

  /** Same rule the API enforces for every change in the admin module. */
  canManage(permission: string = PERMISSIONS.USER_MANAGE): boolean {
    return this.hasRole(SUPER_ADMIN) && this.has(permission);
  }

  /** "C" permission: only valid on records the user owns or is assigned to. */
  isConditional(permission: string): boolean {
    return !!this.meSubject.value?.conditionalPermissions.includes(permission);
  }

  /**
   * Record-level decision from the server (ownership, assignment, team, LOB / location, shared records).
   * Use it before showing an action on one record when the permission is conditional or scoped.
   */
  check(req: CheckRequest): Promise<CheckResponse> {
    return firstValueFrom(this.http.post<CheckResponse>(`${environment.API_URL}admin-services/rbac/check`, req)).catch(
      () => ({ allowed: false, reason: 'Access check failed' })
    );
  }

  isSelf(email?: string | null): boolean {
    const me = this.meSubject.value;
    return !!me?.email && !!email && me.email.toLowerCase() === email.toLowerCase();
  }
}
