# smartie-happy - admin module (Phase 5 S1: tracker #22-25, #32)

Angular 16 + Angular Material, NgModule style like the rest of smartie-happy. Copy `src/app/admin/` into the app.
Compiled with `strict` and `strictTemplates` on Angular 16.1 / Material 16.1 and smoke-tested against a mock
admin-services (no console errors).

## Screens

| Route | Guard | Tracker |
|---|---|---|
| `/h/admin/users` | `USER:VIEW` | #23 list, search, status / role filter, deactivate, reactivate; #22 "Add user" |
| `/h/admin/users/:id` | `USER:VIEW` | details, roles, #24 granular permissions (ALLOW / DENY, own-records-only, expiry), effective access with sources |
| `/h/admin/roles` | `ROLE:VIEW` | #25 role x permission matrix, #1-3 reset to default sets, "Highlight changes from defaults" (DEP-S1-04 sign-off check), new / edit / retire role |
| `/h/admin/config` | `CONFIG:VIEW` | #32 enterprise configuration: list by category, add / edit with type checks (NUMBER, BOOLEAN, LIST, JSON), credentials refused |

All three screens sit under one tab bar (`AdminShellComponent`). A tab shows only when `/rbac/me` has its permission.

Write buttons show only for an active Super Admin (`SUPER_ADMIN` + `USER:MANAGE` / `ROLE:MANAGE`), never on the
logged-in admin's own row. The API enforces the same rules; the UI just avoids dead clicks.

## Wire it in (4 small edits)

1. Lazy route in `hr/hr-routing.module.ts` (children of the `/h/` layout):

```ts
{ path: 'admin', loadChildren: () => import('../admin/admin.module').then((m) => m.AdminModule) },
```

2. Side nav (`common-modules/navigation`, the SideNavComponent's module): import `SharedAdminModule`, then add below Archive:

```html
<a routerLink="/h/admin" routerLinkActive="active" *appHasPermission="['USER:VIEW', 'ROLE:VIEW', 'CONFIG:VIEW']">Admin</a>
```

3. Load / clear access with the session in `shared/services/auth.service.ts`:

```ts
// after a successful login / verify
this.rbacService.refresh();
// in logout()
this.rbacService.clear();
```

4. Nothing else: services call `${environment.API_URL}admin-services/...`, and the existing `HeaderInterceptor`
   already sends `withCredentials: true`, so the gateway turns the `token` cookie into the Bearer header.
   The gateway needs the `admin-services` route (see admin-services `docs/SETUP.md`).

## Notes

- `permissionGuard` and `*appHasPermission` read `GET /rbac/me`, not `localStorage.role`. Use them for any
  other screen that must follow the admin matrix.
- Errors: admin-services returns RFC 7807 with a `code`; `utils/api-error.util.ts` maps codes to messages.
  4xx are shown inside the dialog / page. Your `HeaderInterceptor` still handles 401 (logout) and 500.
- `ResponseInterceptor` adds `responseStatus` to response bodies. The admin code ignores it.
- Record-level checks: `RbacService.check({ permission, objectType, objectId, ownerId, assigneeIds, lob, location })`
  calls `POST /rbac/check`. Use it for "C" permissions (`rbac.isConditional(code)`) before showing an action on one record.
  It fails closed (`allowed: false`) when the call fails.
- Config versioning: the edit dialog sends the loaded `version`, so two admins editing the same key get `CONCURRENT_MODIFICATION`
  instead of a silent overwrite.
- Material icons are not used, so no icon font / registry changes are needed.
