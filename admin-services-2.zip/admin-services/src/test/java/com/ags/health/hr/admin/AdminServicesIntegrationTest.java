package com.ags.health.hr.admin;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import io.jsonwebtoken.io.Decoders;
import io.jsonwebtoken.security.Keys;
import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.ResultActions;

import java.util.Date;
import java.util.Map;

import static org.assertj.core.api.Assertions.assertThat;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.patch;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

/**
 * End-to-end scenarios, written once and run against each database:
 * <ul>
 *   <li>{@link H2AuthdbSmokeTest} - H2 authdb in PostgreSQL mode (local set-up). Always runs.</li>
 *   <li>{@link PostgresIntegrationTest} - embedded PostgreSQL (UAT / prod engine). Runs with -Dit.postgres=true.</li>
 * </ul>
 * Boot runs the SQL scripts, Hibernate validates them, and every rule is exercised through HTTP with real signed
 * JWTs (same Base64 secret handling as auth-services).
 */
@SpringBootTest(properties = {
        "eureka.client.enabled=false",
        "admin.security.jwt-secret=" + AdminServicesIntegrationTest.SECRET,
        "admin.security.internal-api-key=test-internal-key",
        "admin.bootstrap.super-admin-emails=" + AdminServicesIntegrationTest.ADMIN
})
@AutoConfigureMockMvc
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
abstract class AdminServicesIntegrationTest {

    static final String SECRET = "c2VjcmV0LWtleS1mb3ItdGVzdHMtb25seS0zMi1ieXRlcy1sb25nISE="; // 40 bytes, base64
    static final String ADMIN = "first.admin@agshealth.com";

    @Autowired
    MockMvc mvc;
    @Autowired
    ObjectMapper mapper;
    @Autowired
    JdbcTemplate jdbc;

    static String token(String userId, String email, String userType) {
        return "Bearer " + Jwts.builder()
                .setSubject(email)
                .addClaims(Map.of("userId", userId, "email", email, "userType", userType, "userName", email))
                .setIssuedAt(new Date())
                .setExpiration(new Date(System.currentTimeMillis() + 3_600_000))
                .signWith(Keys.hmacShaKeyFor(Decoders.BASE64.decode(SECRET)), SignatureAlgorithm.HS256)
                .compact();
    }

    static final String ADMIN_TOKEN = token("sa-1", ADMIN, "EMPLOYEE_HR_ADMIN");

    private ResultActions call(org.springframework.test.web.servlet.request.MockHttpServletRequestBuilder req,
                               String token, Object body) throws Exception {
        req.header("Authorization", token);
        if (body != null) {
            req.contentType(MediaType.APPLICATION_JSON).content(mapper.writeValueAsString(body));
        }
        return mvc.perform(req);
    }

    private JsonNode json(ResultActions r) throws Exception {
        return mapper.readTree(r.andReturn().getResponse().getContentAsString());
    }

    private String createUser(String email, String... roles) throws Exception {
        JsonNode n = json(call(post("/admin/users"), ADMIN_TOKEN, Map.of(
                "email", email, "fullName", email.substring(0, email.indexOf('@')), "userType", "EMPLOYEE_HR",
                "roles", roles)).andExpect(status().isCreated()));
        return n.get("id").asText();
    }

    @Test
    @Order(1)
    void seedMatchesTheAccessMatrix() {
        Integer roles = jdbc.queryForObject("SELECT count(*) FROM adm_role", Integer.class);
        Integer grants = jdbc.queryForObject("SELECT count(*) FROM adm_role_permission", Integer.class);
        Integer defaults = jdbc.queryForObject("SELECT count(*) FROM adm_default_role_permission", Integer.class);
        assertThat(roles).isEqualTo(8);
        assertThat(grants).isEqualTo(defaults).isEqualTo(162);
        // every code the reference workflow-services / notification-engine check must exist
        Integer known = jdbc.queryForObject("""
                SELECT count(*) FROM adm_permission WHERE code IN ('WORKFLOW:CONFIGURE','WORKFLOW:VIEW','WORKFLOW:ASSIGN',
                'WORKFLOW:PUBLISH','NOTIFICATION_TEMPLATE:MANAGE','NOTIFICATION_TEMPLATE:VIEW','NOTIFICATION_TEMPLATE:SEND',
                'APPLICATION:VIEW','APPLICATION:CREATE','APPLICATION:MAP','CANDIDATE:VIEW','AUDIT_LOG:VIEW')""", Integer.class);
        assertThat(known).isEqualTo(12);
    }

    @Test
    @Order(2)
    void noTokenIs401WithProblemBody() throws Exception {
        mvc.perform(get("/admin/users")).andExpect(status().isUnauthorized())
                .andExpect(jsonPath("$.code").value("UNAUTHORIZED"));
        call(get("/admin/users"), "Bearer not-a-jwt", null).andExpect(status().isUnauthorized())
                .andExpect(jsonPath("$.code").value("INVALID_TOKEN"));
    }

    @Test
    @Order(3)
    void bootstrapAdminCanManageAndIsLinkedOnFirstCall() throws Exception {
        call(get("/rbac/me"), ADMIN_TOKEN, null).andExpect(status().isOk())
                .andExpect(jsonPath("$.roles[0]").value("SUPER_ADMIN"))
                .andExpect(jsonPath("$.configured").value(true));
        assertThat(jdbc.queryForObject("SELECT smartie_user_id FROM adm_app_user WHERE email = ?", String.class, ADMIN))
                .isEqualTo("sa-1");
    }

    @Test
    @Order(4)
    void createSearchAndDuplicate() throws Exception {
        String id = createUser("Priya.R@agshealth.com", "RECRUITER");
        call(get("/admin/users/" + id), ADMIN_TOKEN, null).andExpect(status().isOk())
                .andExpect(jsonPath("$.email").value("priya.r@agshealth.com"))
                .andExpect(jsonPath("$.effectiveScopeLevel").value("OWN"))
                .andExpect(jsonPath("$.loginLinked").value(false));
        call(get("/admin/users?search=PRIYA&status=ACTIVE&role=recruiter"), ADMIN_TOKEN, null).andExpect(status().isOk())
                .andExpect(jsonPath("$.totalElements").value(1));
        call(post("/admin/users"), ADMIN_TOKEN, Map.of("email", "priya.r@agshealth.com", "fullName", "x",
                "userType", "EMPLOYEE_HR", "roles", new String[]{"RECRUITER"}))
                .andExpect(status().isConflict()).andExpect(jsonPath("$.code").value("USER_EXISTS"));
        call(post("/admin/users"), ADMIN_TOKEN, Map.of("email", "c@agshealth.com", "fullName", "x",
                "userType", "EMPLOYEE_HR", "roles", new String[]{"CANDIDATE"}))
                .andExpect(status().isBadRequest()).andExpect(jsonPath("$.code").value("ROLE_NOT_ASSIGNABLE"));
    }

    @Test
    @Order(5)
    void nonAdminIsForbiddenWithSameBodyShape() throws Exception {
        String rec = token("rec-1", "priya.r@agshealth.com", "EMPLOYEE_HR");
        call(get("/admin/users"), rec, null).andExpect(status().isForbidden())
                .andExpect(jsonPath("$.code").value("ACCESS_DENIED"));
    }

    @Test
    @Order(6)
    void selfModificationAndLastSuperAdminAreBlocked() throws Exception {
        String selfId = jdbc.queryForObject("SELECT CAST(id AS VARCHAR) FROM adm_app_user WHERE email = ?", String.class, ADMIN);
        call(put("/admin/users/" + selfId + "/roles"), ADMIN_TOKEN, Map.of("roles", new String[]{"RECRUITER"}))
                .andExpect(status().isForbidden()).andExpect(jsonPath("$.code").value("SELF_MODIFICATION_NOT_ALLOWED"));

        // a second super admin tries to remove the first one while the first is the only active one left
        String second = createUser("second.admin@agshealth.com", "SUPER_ADMIN");
        String secondToken = token("sa-2", "second.admin@agshealth.com", "EMPLOYEE_HR");
        call(patch("/admin/users/" + selfId + "/deactivate"), secondToken, Map.of("reason", "left"))
                .andExpect(status().isOk()).andExpect(jsonPath("$.status").value("INACTIVE"));
        // now "second" is the last one: first admin is inactive and has no rights at all
        call(get("/admin/users"), ADMIN_TOKEN, null).andExpect(status().isForbidden());
        call(patch("/admin/users/" + selfId + "/reactivate"), secondToken, Map.of("reason", "back"))
                .andExpect(status().isOk());
        call(patch("/admin/users/" + second + "/deactivate"), ADMIN_TOKEN, Map.of())
                .andExpect(status().isBadRequest()).andExpect(jsonPath("$.code").value("REASON_REQUIRED"));
    }

    @Test
    @Order(7)
    void inactiveSuperAdminHasNoPowerAndOneAdminAlwaysRemains() throws Exception {
        String second = jdbc.queryForObject("SELECT CAST(id AS VARCHAR) FROM adm_app_user WHERE email = 'second.admin@agshealth.com'", String.class);
        call(patch("/admin/users/" + second + "/deactivate"), ADMIN_TOKEN, Map.of("reason", "test"))
                .andExpect(status().isOk());
        String first = jdbc.queryForObject("SELECT CAST(id AS VARCHAR) FROM adm_app_user WHERE email = ?", String.class, ADMIN);
        // only the first admin is active now; the (inactive) second can do nothing, and nobody can strip the first
        String secondToken = token("sa-2", "second.admin@agshealth.com", "EMPLOYEE_HR");
        call(put("/admin/users/" + first + "/roles"), secondToken, Map.of("roles", new String[]{"RECRUITER"}))
                .andExpect(status().isForbidden());
        Integer active = jdbc.queryForObject("""
                SELECT count(*) FROM adm_app_user u JOIN adm_user_role ur ON ur.user_id = u.id
                JOIN adm_role r ON r.id = ur.role_id WHERE r.code = 'SUPER_ADMIN' AND u.status = 'ACTIVE'""", Integer.class);
        assertThat(active).isEqualTo(1);
    }

    @Test
    @Order(8)
    void granularPermissionsReplaceWithoutPrimaryKeyClash() throws Exception {
        String id = jdbc.queryForObject("SELECT CAST(id AS VARCHAR) FROM adm_app_user WHERE email = 'priya.r@agshealth.com'", String.class);
        call(put("/admin/users/" + id + "/permissions"), ADMIN_TOKEN, Map.of("grants", new Object[]{
                Map.of("permission", "OFFER:VIEW", "effect", "ALLOW", "conditional", false),
                Map.of("permission", "REPORT:VIEW", "effect", "DENY")})).andExpect(status().isOk());
        // same permission kept, flag flipped: delete-then-insert must not hit the PK
        call(put("/admin/users/" + id + "/permissions"), ADMIN_TOKEN, Map.of("grants", new Object[]{
                Map.of("permission", "OFFER:VIEW", "effect", "ALLOW", "conditional", true),
                Map.of("permission", "REPORT:VIEW", "effect", "DENY")})).andExpect(status().isOk());

        JsonNode detail = json(call(get("/admin/users/" + id + "/effective-access"), ADMIN_TOKEN, null)
                .andExpect(status().isOk()));
        assertThat(detail.at("/access/permissions").toString()).contains("OFFER:VIEW").doesNotContain("REPORT:VIEW");
        assertThat(detail.at("/access/conditionalPermissions").toString()).contains("OFFER:VIEW");

        call(put("/admin/users/" + id + "/permissions"), ADMIN_TOKEN, Map.of("grants", new Object[]{
                Map.of("permission", "USER:MANAGE", "effect", "ALLOW")}))
                .andExpect(status().isBadRequest()).andExpect(jsonPath("$.code").value("PRIVILEGED_PERMISSION"));
        call(put("/admin/users/" + id + "/permissions"), ADMIN_TOKEN, Map.of("grants", new Object[]{
                Map.of("permission", "REPORTS:VIEW", "effect", "ALLOW")}))
                .andExpect(status().isBadRequest()).andExpect(jsonPath("$.code").value("UNKNOWN_PERMISSION"));
    }

    @Test
    @Order(9)
    void superAdminRoleIsLocked() throws Exception {
        call(put("/admin/roles/SUPER_ADMIN"), ADMIN_TOKEN, Map.of("name", "Super Admin", "defaultScope", "ALL",
                "active", false)).andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.code").value("SUPER_ADMIN_ROLE_LOCKED"));
        call(put("/admin/permission-matrix"), ADMIN_TOKEN, Map.of("grants", Map.of("SUPER_ADMIN",
                new Object[]{Map.of("code", "AUDIT_LOG:VIEW", "conditional", false)})))
                .andExpect(status().isBadRequest()).andExpect(jsonPath("$.code").value("SUPER_ADMIN_ROLE_LOCKED"));
        call(put("/admin/permission-matrix"), ADMIN_TOKEN, Map.of("grants", Map.of("RECRUITER",
                new Object[]{Map.of("code", "ROLE:MANAGE", "conditional", false)})))
                .andExpect(status().isBadRequest()).andExpect(jsonPath("$.code").value("PRIVILEGED_PERMISSION"));
    }

    @Test
    @Order(10)
    void retiringARoleRemovesItsPermissionsOnTheNextRequest() throws Exception {
        String rec = token("rec-1", "priya.r@agshealth.com", "EMPLOYEE_HR");
        call(get("/rbac/me"), rec, null).andExpect(jsonPath("$.roles[0]").value("RECRUITER"));
        call(put("/admin/roles/RECRUITER"), ADMIN_TOKEN, Map.of("name", "Recruiter", "defaultScope", "OWN",
                "active", false)).andExpect(status().isOk()).andExpect(jsonPath("$.active").value(false));
        call(get("/rbac/me"), rec, null).andExpect(jsonPath("$.roles").isEmpty())
                .andExpect(jsonPath("$.permissions").value(org.hamcrest.Matchers.hasItem("OFFER:VIEW")));
        call(put("/admin/roles/RECRUITER"), ADMIN_TOKEN, Map.of("name", "Recruiter", "defaultScope", "OWN",
                "active", true)).andExpect(status().isOk());
    }

    @Test
    @Order(11)
    void newRegistrationGetsFallbackRoleOnly() throws Exception {
        call(get("/rbac/me"), token("cand-1", "someone@gmail.com", "CANDIDATE"), null).andExpect(status().isOk())
                .andExpect(jsonPath("$.configured").value(false))
                .andExpect(jsonPath("$.roles[0]").value("CANDIDATE"));
    }

    @Test
    @Order(11)
    void internalEndpointNeedsServiceKey() throws Exception {
        mvc.perform(get("/internal/rbac/effective").param("email", ADMIN)).andExpect(status().isUnauthorized());
        mvc.perform(get("/internal/rbac/effective").param("email", ADMIN).header("X-Internal-Key", "test-internal-key"))
                .andExpect(status().isOk()).andExpect(jsonPath("$.roles[0]").value("SUPER_ADMIN"));
    }

    @Test
    @Order(12)
    void enterpriseConfigIsSuperAdminOnlyAndTypeChecked() throws Exception {
        String rec = token("rec-1", "priya.r@agshealth.com", "EMPLOYEE_HR");
        call(get("/admin/config"), rec, null).andExpect(status().isForbidden());
        call(get("/admin/config?category=assessment"), ADMIN_TOKEN, null).andExpect(status().isOk())
                .andExpect(jsonPath("$[0].category").value("ASSESSMENT"));
        call(put("/admin/config/assessment.cooling-days.shl"), ADMIN_TOKEN, Map.of("value", "7,30"))
                .andExpect(status().isBadRequest()).andExpect(jsonPath("$.code").value("INVALID_CONFIG_VALUE"));
        call(put("/admin/config/assessment.cooling-days.shl"), ADMIN_TOKEN, Map.of("value", "[7,30,180]"))
                .andExpect(status().isOk());
        call(post("/admin/config"), ADMIN_TOKEN, Map.of("key", "versant.api-key", "value", "x", "valueType", "STRING",
                "category", "ASSESSMENT")).andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.code").value("USE_SECRET_STORE"));
        mvc.perform(get("/internal/config/panel.orc-reapply-block-days").header("X-Internal-Key", "test-internal-key"))
                .andExpect(status().isOk()).andExpect(jsonPath("$.value").value("60"));
    }

    @Test
    @Order(13)
    void everyChangeIsAudited() {
        Integer rows = jdbc.queryForObject("""
                SELECT count(*) FROM adm_audit_log WHERE action IN ('ADMIN_USER_CREATED', 'ADMIN_USER_DEACTIVATED',
                'ADMIN_USER_REACTIVATED', 'ADMIN_USER_PERMISSIONS_CHANGED', 'ROLE_RETIRED', 'SUPER_ADMIN_BOOTSTRAPPED')""",
                Integer.class);
        assertThat(rows).isGreaterThanOrEqualTo(6);
        // actor name / roles are filled for the central log viewer
        Integer withRoles = jdbc.queryForObject(
                "SELECT count(*) FROM adm_audit_log WHERE action = 'ADMIN_USER_CREATED' AND actor_roles = 'SUPER_ADMIN'", Integer.class);
        assertThat(withRoles).isGreaterThan(0);
    }

    @Test
    @Order(14)
    void teamVisibilityFollowsTheReportingLine() throws Exception {
        String tlId = createUser("tl.lead@agshealth.com", "RECRUITMENT_MANAGER");
        call(put("/admin/users/" + tlId), ADMIN_TOKEN, Map.of("fullName", "TL Lead", "scopeLevel", "TEAM"))
                .andExpect(status().isOk());
        JsonNode rec = json(call(post("/admin/users"), ADMIN_TOKEN, Map.of("email", "team.rec@agshealth.com",
                "fullName", "Team Rec", "userType", "EMPLOYEE_HR", "roles", new String[]{"RECRUITER"},
                "managerId", tlId)).andExpect(status().isCreated()));
        assertThat(rec.get("managerName").asText()).isEqualTo("TL Lead");
        // the recruiter signs in once (links the login), then shows up in the TL's team
        call(get("/rbac/me"), token("team-rec-1", "team.rec@agshealth.com", "EMPLOYEE_HR"), null).andExpect(status().isOk());
        call(get("/rbac/me"), token("tl-1", "tl.lead@agshealth.com", "EMPLOYEE_HR"), null)
                .andExpect(jsonPath("$.scope.level").value("TEAM"))
                .andExpect(jsonPath("$.scope.teamUserIds[0]").value("team-rec-1"));
        // audit details are stored as a JSON object on every database, not as a quoted string
        String details = jdbc.queryForObject("SELECT CAST(details AS VARCHAR(4000)) FROM adm_audit_log "
                + "WHERE action = 'ADMIN_USER_CREATED' AND entity_id = ?", String.class, tlId);
        assertThat(details).startsWith("{");
    }
}
