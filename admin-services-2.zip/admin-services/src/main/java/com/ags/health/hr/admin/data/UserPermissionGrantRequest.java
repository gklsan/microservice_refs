package com.ags.health.hr.admin.data;

import com.ags.health.hr.admin.enums.PermissionEffect;
import jakarta.validation.Valid;
import jakarta.validation.constraints.Future;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

import java.time.Instant;
import java.util.List;

/**
 * Full replace of a user's granular permissions. An empty list removes every override.
 * DENY always wins over role permissions and ALLOW grants.
 */
public record UserPermissionGrantRequest(@NotNull @Size(max = 200) List<@Valid @NotNull Item> grants) {

    /**
     * @param conditional only for ALLOW: true = valid only on records the user owns / is assigned to
     * @param expiresAt   optional end date for temporary access (e.g. covering a colleague for two weeks)
     */
    public record Item(@NotBlank @Size(max = 80) String permission,
                       @NotNull PermissionEffect effect,
                       boolean conditional,
                       @Future Instant expiresAt,
                       @Size(max = 500) String reason) {
    }
}
