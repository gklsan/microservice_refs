package com.ags.health.hr.admin;

import com.ags.health.hr.admin.config.DatabaseUrlGuard;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.properties.ConfigurationPropertiesScan;

@SpringBootApplication
@ConfigurationPropertiesScan
public class AdminServicesApplication {

    public static void main(String[] args) {
        SpringApplication app = new SpringApplication(AdminServicesApplication.class);
        app.addListeners(new DatabaseUrlGuard());
        app.run(args);
    }
}
