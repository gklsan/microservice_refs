package com.ags.health.hr.admin.services;

import com.ags.health.hr.admin.enums.AuditCategory;
import com.ags.health.hr.admin.security.CorrelationIdFilter;
import com.ags.health.hr.admin.security.CurrentUser;
import com.ags.health.hr.admin.security.SecurityUtils;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.RequiredArgsConstructor;
import org.slf4j.MDC;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import java.util.Map;
import java.util.TreeSet;

/**
 * Writes to the central audit table adm_audit_log (same columns as the reference starter's JdbcAuditLogger,
 * so tracker #9-14 can reuse the table). Runs inside the caller's transaction: an audit row exists if and
 * only if the change was committed.
 */
@Service
@RequiredArgsConstructor
public class AuditService {

    private static final String SERVICE = "admin-services";

    private final JdbcTemplate jdbc;
    private final ObjectMapper mapper;

    /** PostgreSQL needs CAST(? AS JSON); H2 (local authdb) would store that as a quoted string, so it uses FORMAT JSON. */
    private volatile String jsonParam;

    public void log(AuditCategory category, String action, String entityType, Object entityId, Map<String, ?> details) {
        log(category, action, entityType, entityId, null, null, details);
    }

    public void log(AuditCategory category, String action, String entityType, Object entityId,
                    String candidateId, String description, Map<String, ?> details) {
        CurrentUser actor = SecurityUtils.currentUser().orElse(null);
        String roles = actor == null || actor.access() == null ? null : String.join(",", new TreeSet<>(actor.access().roles()));
        jdbc.update("INSERT INTO adm_audit_log (id, category, action, entity_type, entity_id, candidate_id, actor_id, actor_name, "
                        + "actor_email, actor_roles, outcome, description, details, correlation_id, service_name, client_ip) "
                        + "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'SUCCESS', ?, " + jsonParam() + ", ?, ?, ?)",
                java.util.UUID.randomUUID(), category.name(), action, entityType, entityId == null ? null : String.valueOf(entityId), candidateId,
                actor == null ? "system" : actor.userId(), actor == null ? null : actor.name(),
                actor == null ? null : actor.email(), roles, description,
                toJson(details), MDC.get(CorrelationIdFilter.MDC_KEY), SERVICE, clientIp());
    }

    private String jsonParam() {
        if (jsonParam == null) {
            String product = jdbc.execute((java.sql.Connection c) -> c.getMetaData().getDatabaseProductName());
            jsonParam = product != null && product.toLowerCase().contains("h2") ? "? FORMAT JSON" : "CAST(? AS JSON)";
        }
        return jsonParam;
    }

    private String toJson(Map<String, ?> details) {
        if (details == null || details.isEmpty()) {
            return null;
        }
        try {
            return mapper.writeValueAsString(details);
        } catch (JsonProcessingException e) {
            return "{\"serialisationError\":true}";
        }
    }

    private static String clientIp() {
        if (RequestContextHolder.getRequestAttributes() instanceof ServletRequestAttributes attrs) {
            String forwarded = attrs.getRequest().getHeader("X-Forwarded-For");
            return forwarded != null ? forwarded.split(",")[0].trim() : attrs.getRequest().getRemoteAddr();
        }
        return null;
    }
}
