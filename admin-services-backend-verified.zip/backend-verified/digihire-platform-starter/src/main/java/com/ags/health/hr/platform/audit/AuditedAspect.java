package com.ags.health.hr.platform.audit;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.reflect.MethodSignature;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.expression.MethodBasedEvaluationContext;
import org.springframework.core.DefaultParameterNameDiscoverer;
import org.springframework.core.ParameterNameDiscoverer;
import org.springframework.expression.Expression;
import org.springframework.expression.spel.standard.SpelExpressionParser;
import org.springframework.util.StringUtils;

import java.lang.reflect.Method;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/** Implements {@link Audited}. */
@Aspect
public class AuditedAspect {

    private static final Logger log = LoggerFactory.getLogger(AuditedAspect.class);

    private final AuditLogger auditLogger;
    private final SpelExpressionParser parser = new SpelExpressionParser();
    private final ParameterNameDiscoverer names = new DefaultParameterNameDiscoverer();
    private final Map<String, Expression> cache = new ConcurrentHashMap<>();

    public AuditedAspect(AuditLogger auditLogger) {
        this.auditLogger = auditLogger;
    }

    @Around("@annotation(audited)")
    public Object around(ProceedingJoinPoint pjp, Audited audited) throws Throwable {
        Method method = ((MethodSignature) pjp.getSignature()).getMethod();
        String action = StringUtils.hasText(audited.action()) ? audited.action()
                : method.getDeclaringClass().getSimpleName() + "." + method.getName();
        try {
            Object result = pjp.proceed();
            record(pjp, method, audited, action, result, null);
            return result;
        } catch (Throwable ex) {
            record(pjp, method, audited, action, null, ex);
            throw ex;
        }
    }

    private void record(ProceedingJoinPoint pjp, Method method, Audited a, String action, Object result, Throwable ex) {
        try {
            MethodBasedEvaluationContext ctx = new MethodBasedEvaluationContext(pjp.getTarget(), method, pjp.getArgs(), names);
            ctx.setVariable("result", result);
            AuditEvent.Builder b = AuditEvent.builder(a.category(), action)
                    .entity(StringUtils.hasText(a.entityType()) ? a.entityType() : null, eval(a.entityId(), ctx))
                    .candidate(eval(a.candidateId(), ctx))
                    .description(StringUtils.hasText(a.description()) ? a.description() : null)
                    .outcome(ex == null ? AuditEvent.Outcome.SUCCESS : AuditEvent.Outcome.FAILURE);
            if (ex != null) {
                b.detail("error", ex.getClass().getSimpleName() + ": " + ex.getMessage());
            }
            auditLogger.log(b.build());
        } catch (RuntimeException e) {
            log.warn("@Audited evaluation failed for {}: {}", action, e.getMessage());
        }
    }

    private Object eval(String expression, MethodBasedEvaluationContext ctx) {
        if (!StringUtils.hasText(expression)) {
            return null;
        }
        try {
            return cache.computeIfAbsent(expression, parser::parseExpression).getValue(ctx);
        } catch (RuntimeException e) {
            return null; // e.g. #result.id when result is null on failure
        }
    }
}
