package com.ags.health.hr.platform.security;

import org.springframework.security.authentication.AbstractAuthenticationToken;
import org.springframework.security.core.GrantedAuthority;

import java.util.Collection;

/** Authentication whose principal is the {@link CurrentUser}. */
public class DigiHireAuthentication extends AbstractAuthenticationToken {

    private final CurrentUser user;

    public DigiHireAuthentication(CurrentUser user, Collection<? extends GrantedAuthority> authorities) {
        super(authorities);
        this.user = user;
        setAuthenticated(true);
    }

    @Override
    public Object getCredentials() {
        return user.token();
    }

    @Override
    public CurrentUser getPrincipal() {
        return user;
    }

    @Override
    public String getName() {
        return user.email() != null ? user.email() : user.userId();
    }
}
