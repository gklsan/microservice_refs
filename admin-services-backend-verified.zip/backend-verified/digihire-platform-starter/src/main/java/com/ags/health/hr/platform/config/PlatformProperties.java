package com.ags.health.hr.platform.config;

import org.springframework.boot.context.properties.ConfigurationProperties;

import java.time.Duration;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * All platform behaviour is driven from configuration under the {@code digihire.*} prefix.
 * Every value has a safe default; secrets must come from environment variables.
 */
@ConfigurationProperties(prefix = "digihire")
public class PlatformProperties {

    /** Logical service name written into audit rows (defaults to spring.application.name). */
    private String serviceName;

    private final Security security = new Security();
    private final Audit audit = new Audit();
    private final Access access = new Access();
    private final Web web = new Web();

    public String getServiceName() { return serviceName; }
    public void setServiceName(String serviceName) { this.serviceName = serviceName; }
    public Security getSecurity() { return security; }
    public Audit getAudit() { return audit; }
    public Access getAccess() { return access; }
    public Web getWeb() { return web; }

    public static class Security {
        /** Turn the platform security filter chain on/off (existing services may keep their own). */
        private boolean enabled = true;
        /** Same HS256 secret the gateway (JwtUtil) and auth-services (JwtService) use. Inject via env JWT_SECRET. */
        private String jwtSecret;
        /** How jwtSecret is encoded. Existing code uses jjwt Decoders.BASE64 -> BASE64. */
        private SecretEncoding jwtSecretEncoding = SecretEncoding.BASE64;
        /** Shared key for service-to-service calls on /internal/** (header X-Internal-Key). */
        private String internalApiKey;
        /** Extra ant-style paths that need no authentication. */
        private List<String> publicPaths = new ArrayList<>();

        public boolean isEnabled() { return enabled; }
        public void setEnabled(boolean enabled) { this.enabled = enabled; }
        public String getJwtSecret() { return jwtSecret; }
        public void setJwtSecret(String jwtSecret) { this.jwtSecret = jwtSecret; }
        public SecretEncoding getJwtSecretEncoding() { return jwtSecretEncoding; }
        public void setJwtSecretEncoding(SecretEncoding e) { this.jwtSecretEncoding = e; }
        public String getInternalApiKey() { return internalApiKey; }
        public void setInternalApiKey(String internalApiKey) { this.internalApiKey = internalApiKey; }
        public List<String> getPublicPaths() { return publicPaths; }
        public void setPublicPaths(List<String> publicPaths) { this.publicPaths = publicPaths; }
    }

    public enum SecretEncoding { BASE64, HEX, RAW }

    public static class Audit {
        private boolean enabled = true;
        /** Fully qualified table the audit rows are written to (DDL owned by admin-services). */
        private String table = "dh_audit.audit_log";
        /** Async writer queue size; when full, rows are dropped with a WARN log (never blocks business calls). */
        private int queueCapacity = 10_000;
        private int writerThreads = 2;

        public boolean isEnabled() { return enabled; }
        public void setEnabled(boolean enabled) { this.enabled = enabled; }
        public String getTable() { return table; }
        public void setTable(String table) { this.table = table; }
        public int getQueueCapacity() { return queueCapacity; }
        public void setQueueCapacity(int queueCapacity) { this.queueCapacity = queueCapacity; }
        public int getWriterThreads() { return writerThreads; }
        public void setWriterThreads(int writerThreads) { this.writerThreads = writerThreads; }
    }

    public static class Access {
        /** Base URL of admin-services (Eureka id works when spring-cloud-loadbalancer is present). */
        private String adminServiceUrl = "http://admin-services/admin-services";
        /** Cache effective access per user to avoid a call per request. */
        private Duration cacheTtl = Duration.ofMinutes(2);
        private long cacheMaxSize = 20_000;
        /**
         * Roles used when admin-services has no record for the user or is unreachable.
         * Keeps today's behaviour for users who were never configured in the admin module.
         */
        private Map<String, List<String>> fallbackRolesByUserType = new LinkedHashMap<>(Map.of(
                "EMPLOYEE_HR_ADMIN", List.of("ADMIN"),
                "EMPLOYEE_HR", List.of("RECRUITER"),
                "EMPLOYEE_NON_HR", List.of("EMPLOYEE"),
                "VENDOR", List.of("VENDOR"),
                "CANDIDATE", List.of("CANDIDATE")));

        public String getAdminServiceUrl() { return adminServiceUrl; }
        public void setAdminServiceUrl(String adminServiceUrl) { this.adminServiceUrl = adminServiceUrl; }
        public Duration getCacheTtl() { return cacheTtl; }
        public void setCacheTtl(Duration cacheTtl) { this.cacheTtl = cacheTtl; }
        public long getCacheMaxSize() { return cacheMaxSize; }
        public void setCacheMaxSize(long cacheMaxSize) { this.cacheMaxSize = cacheMaxSize; }
        public Map<String, List<String>> getFallbackRolesByUserType() { return fallbackRolesByUserType; }
        public void setFallbackRolesByUserType(Map<String, List<String>> m) { this.fallbackRolesByUserType = m; }
    }

    public static class Web {
        /** Register the RFC 7807 fallback exception handler. */
        private boolean problemDetailsAdvice = true;
        /** Log one structured line per HTTP request with duration (timestamp logs). */
        private boolean requestLogging = true;

        public boolean isProblemDetailsAdvice() { return problemDetailsAdvice; }
        public void setProblemDetailsAdvice(boolean v) { this.problemDetailsAdvice = v; }
        public boolean isRequestLogging() { return requestLogging; }
        public void setRequestLogging(boolean requestLogging) { this.requestLogging = requestLogging; }
    }
}
