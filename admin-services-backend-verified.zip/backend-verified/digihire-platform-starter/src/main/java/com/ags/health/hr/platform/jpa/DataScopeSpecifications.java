package com.ags.health.hr.platform.jpa;

import com.ags.health.hr.platform.security.DataScope;
import jakarta.persistence.criteria.CriteriaBuilder;
import jakarta.persistence.criteria.Path;
import jakarta.persistence.criteria.Predicate;
import jakarta.persistence.criteria.Root;
import org.springframework.data.jpa.domain.Specification;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.UUID;

/**
 * Converts a {@link DataScope} into a JPA {@link Specification} - the single place that implements the BRD 4.3
 * visibility rules for any list/search query (candidates, applications, jobs):
 * <ul>
 *   <li>OWN      - rows owned by the user (recruiter ownership) + rows shared with him via approved request</li>
 *   <li>TEAM     - OWN + rows owned by anyone reporting to him (TL / Manager elevated visibility)</li>
 *   <li>LOB      - rows in his supervised LOBs (optionally restricted to his locations) + TEAM + shared</li>
 *   <li>LOCATION - rows in his locations + TEAM + shared</li>
 *   <li>ALL      - no restriction (Admin / TA Head)</li>
 * </ul>
 * Usage in existing candidate-services (ApplicationRepository extends JpaSpecificationExecutor):
 * <pre>
 * var mapping = new DataScopeSpecifications.Mapping("hr", "lob", "location", "id");
 * repo.findAll(DataScopeSpecifications.visibleTo(user.scope(), "APPLICATION", mapping).and(otherFilters), page);
 * </pre>
 */
public final class DataScopeSpecifications {

    private DataScopeSpecifications() {
    }

    /**
     * Entity attribute names used for scoping. Any of them may be null when the entity has no such column.
     */
    public record Mapping(String ownerField, String lobField, String locationField, String idField) {
    }

    public static <T> Specification<T> visibleTo(DataScope scope, String objectType, Mapping m) {
        return (root, query, cb) -> {
            if (scope == null || scope.level() == DataScope.Level.NONE) {
                return cb.disjunction(); // nothing visible
            }
            if (scope.level() == DataScope.Level.ALL) {
                return cb.conjunction();
            }
            List<Predicate> anyOf = new ArrayList<>();

            // own rows (+ team rows)
            Set<String> owners = new HashSet<>();
            if (scope.userId() != null) {
                owners.add(scope.userId());
            }
            if (scope.level() != DataScope.Level.OWN) {
                owners.addAll(scope.teamUserIds()); // TEAM, LOB and LOCATION all include the user's team
            }
            in(root, cb, m.ownerField(), owners, anyOf);

            // shared via approved access request
            in(root, cb, m.idField(), scope.sharedIds(objectType), anyOf);

            if (scope.level() == DataScope.Level.LOB && m.lobField() != null && !scope.lobs().isEmpty()) {
                Predicate lob = root.get(m.lobField()).in(scope.lobs());
                if (m.locationField() != null && !scope.locations().isEmpty()) {
                    lob = cb.and(lob, root.get(m.locationField()).in(scope.locations()));
                }
                anyOf.add(lob);
            }
            if (scope.level() == DataScope.Level.LOCATION && m.locationField() != null && !scope.locations().isEmpty()) {
                anyOf.add(root.get(m.locationField()).in(scope.locations()));
            }
            return anyOf.isEmpty() ? cb.disjunction() : cb.or(anyOf.toArray(Predicate[]::new));
        };
    }

    private static <T> void in(Root<T> root, CriteriaBuilder cb, String field, Collection<String> values,
                               List<Predicate> sink) {
        if (field == null || values == null || values.isEmpty()) {
            return;
        }
        Path<Object> path = root.get(field);
        if (UUID.class.equals(path.getJavaType())) {
            List<UUID> uuids = new ArrayList<>();
            for (String v : values) {
                try {
                    uuids.add(UUID.fromString(v));
                } catch (IllegalArgumentException ignored) {
                    // skip non-uuid ids
                }
            }
            if (!uuids.isEmpty()) {
                sink.add(path.in(uuids));
            }
        } else {
            sink.add(path.in(values));
        }
    }
}
