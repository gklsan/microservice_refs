package com.ags.health.hr.platform.config;

import com.ags.health.hr.platform.audit.AuditLogger;
import com.ags.health.hr.platform.audit.AuditedAspect;
import com.ags.health.hr.platform.audit.JdbcAuditLogger;
import com.ags.health.hr.platform.jpa.SecurityAuditorAware;
import com.ags.health.hr.platform.security.ServiceUrlResolver;
import com.ags.health.hr.platform.web.InternalServiceClient;
import com.ags.health.hr.platform.web.CorrelationIdFilter;
import com.ags.health.hr.platform.web.GlobalExceptionHandler;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.ObjectProvider;
import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
import org.springframework.boot.autoconfigure.AutoConfiguration;
import org.springframework.boot.autoconfigure.condition.ConditionalOnBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.autoconfigure.condition.ConditionalOnWebApplication;
import org.springframework.boot.autoconfigure.jdbc.JdbcTemplateAutoConfiguration;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.Ordered;
import org.springframework.core.env.Environment;
import org.springframework.data.jpa.repository.config.EnableJpaAuditing;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.util.ClassUtils;
import org.springframework.util.StringUtils;

/**
 * Core platform wiring: correlation id + request timing log, audit logger, {@code @Audited} aspect,
 * JPA auditing (timestamp columns) and the ProblemDetail fallback handler.
 * Every piece can be switched off by property, and none of them replaces a bean the service already defines.
 */
@AutoConfiguration(after = JdbcTemplateAutoConfiguration.class,
        afterName = "org.springframework.boot.autoconfigure.orm.jpa.HibernateJpaAutoConfiguration")
@EnableConfigurationProperties(PlatformProperties.class)
public class PlatformAutoConfiguration {

    @Configuration(proxyBeanMethods = false)
    @ConditionalOnWebApplication(type = ConditionalOnWebApplication.Type.SERVLET)
    static class WebConfig {

        @Bean
        @ConditionalOnMissingBean(name = "digiHireCorrelationIdFilter")
        FilterRegistrationBean<CorrelationIdFilter> digiHireCorrelationIdFilter(PlatformProperties props) {
            FilterRegistrationBean<CorrelationIdFilter> reg =
                    new FilterRegistrationBean<>(new CorrelationIdFilter(props.getWeb().isRequestLogging()));
            reg.setOrder(Ordered.HIGHEST_PRECEDENCE);
            reg.addUrlPatterns("/*");
            return reg;
        }

        @Bean
        @ConditionalOnMissingBean
        @ConditionalOnClass(name = "org.springframework.dao.DataAccessException")
        @ConditionalOnProperty(prefix = "digihire.web", name = "problem-details-advice", havingValue = "true", matchIfMissing = true)
        GlobalExceptionHandler digiHireGlobalExceptionHandler() {
            return new GlobalExceptionHandler();
        }
    }

    @Configuration(proxyBeanMethods = false)
    @ConditionalOnClass(JdbcTemplate.class)
    @ConditionalOnProperty(prefix = "digihire.audit", name = "enabled", havingValue = "true", matchIfMissing = true)
    static class AuditConfig {

        @Bean
        @ConditionalOnMissingBean
        @ConditionalOnBean(JdbcTemplate.class)
        AuditLogger auditLogger(JdbcTemplate jdbcTemplate, ObjectMapper objectMapper, PlatformProperties props,
                                Environment env) {
            String service = StringUtils.hasText(props.getServiceName()) ? props.getServiceName()
                    : env.getProperty("spring.application.name", "unknown");
            return new JdbcAuditLogger(jdbcTemplate, objectMapper, props.getAudit().getTable(), service,
                    props.getAudit().getWriterThreads(), props.getAudit().getQueueCapacity());
        }
    }

    @Bean
    @ConditionalOnMissingBean
    ServiceUrlResolver serviceUrlResolver(ConfigurableListableBeanFactory beanFactory) {
        String lbClass = "org.springframework.cloud.client.loadbalancer.LoadBalancerClient";
        if (!ClassUtils.isPresent(lbClass, getClass().getClassLoader())) {
            return new ServiceUrlResolver(null);
        }
        @SuppressWarnings("unchecked")
        ObjectProvider<Object> provider = (ObjectProvider<Object>) beanFactory
                .getBeanProvider(ClassUtils.resolveClassName(lbClass, getClass().getClassLoader()));
        return new ServiceUrlResolver(provider);
    }

    @Bean
    @ConditionalOnMissingBean
    @ConditionalOnClass(name = "org.springframework.web.client.RestTemplate")
    InternalServiceClient internalServiceClient(ServiceUrlResolver resolver, PlatformProperties props, Environment env) {
        return new InternalServiceClient(resolver, props.getSecurity().getInternalApiKey(),
                env.getProperty("spring.application.name", "unknown"));
    }

    /** Guarantees an AuditLogger bean exists (no-op) so services can always inject it. */
    @Bean
    @ConditionalOnMissingBean
    AuditLogger noOpAuditLogger() {
        return AuditLogger.NO_OP;
    }

    @Bean
    @ConditionalOnMissingBean
    AuditedAspect auditedAspect(AuditLogger auditLogger) {
        return new AuditedAspect(auditLogger);
    }

    @Configuration(proxyBeanMethods = false)
    @ConditionalOnClass(EnableJpaAuditing.class)
    @ConditionalOnBean(name = "entityManagerFactory")
    @ConditionalOnMissingBean(name = "jpaAuditingHandler")
    @EnableJpaAuditing(auditorAwareRef = "securityAuditorAware")
    static class JpaAuditingConfig {

        @Bean
        SecurityAuditorAware securityAuditorAware() {
            return new SecurityAuditorAware();
        }
    }
}
