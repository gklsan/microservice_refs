package com.ags.health.hr.platform.audit;

import com.ags.health.hr.platform.security.CurrentUser;
import com.ags.health.hr.platform.security.CurrentUserProvider;
import com.ags.health.hr.platform.web.CorrelationIdFilter;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.beans.factory.DisposableBean;
import org.springframework.jdbc.core.JdbcTemplate;

import java.sql.Timestamp;
import java.util.Optional;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.regex.Pattern;

/**
 * Writes audit rows asynchronously into the shared audit table with plain JDBC (no JPA entity needed in the
 * consuming service). Caller context (actor, correlation id, client ip) is captured on the calling thread.
 */
public class JdbcAuditLogger implements AuditLogger, DisposableBean {

    private static final Logger log = LoggerFactory.getLogger(JdbcAuditLogger.class);
    private static final Pattern SAFE_TABLE = Pattern.compile("[A-Za-z0-9_.]+");

    private final JdbcTemplate jdbcTemplate;
    private final ObjectMapper objectMapper;
    private final String serviceName;
    private final String insertSql;
    private final ThreadPoolExecutor executor;

    public JdbcAuditLogger(JdbcTemplate jdbcTemplate, ObjectMapper objectMapper, String table,
                           String serviceName, int threads, int queueCapacity) {
        if (!SAFE_TABLE.matcher(table).matches()) {
            throw new IllegalArgumentException("Invalid audit table name: " + table);
        }
        this.jdbcTemplate = jdbcTemplate;
        this.objectMapper = objectMapper;
        this.serviceName = serviceName;
        this.insertSql = "INSERT INTO " + table + " (id, category, action, entity_type, entity_id, candidate_id, "
                + "actor_id, actor_name, actor_email, actor_roles, outcome, description, details, correlation_id, "
                + "service_name, client_ip, occurred_at) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,CAST(? AS jsonb),?,?,?,?)";
        AtomicInteger counter = new AtomicInteger();
        this.executor = new ThreadPoolExecutor(threads, threads, 60, TimeUnit.SECONDS,
                new ArrayBlockingQueue<>(queueCapacity),
                r -> {
                    Thread t = new Thread(r, "audit-writer-" + counter.incrementAndGet());
                    t.setDaemon(true);
                    return t;
                },
                (r, ex) -> log.warn("Audit queue full - audit row dropped"));
    }

    @Override
    public void log(AuditEvent event) {
        try {
            AuditEvent enriched = enrich(event);
            executor.execute(() -> write(enriched));
        } catch (RuntimeException ex) {
            log.warn("Could not queue audit event {}: {}", event.action(), ex.getMessage());
        }
    }

    private AuditEvent enrich(AuditEvent e) {
        String actorId = e.actorId();
        String actorName = e.actorName();
        String actorEmail = e.actorEmail();
        String actorRoles = e.actorRoles();
        if (actorId == null) {
            Optional<CurrentUser> user = CurrentUserProvider.current();
            if (user.isPresent()) {
                CurrentUser u = user.get();
                actorId = u.userId();
                actorName = u.name();
                actorEmail = u.email();
                actorRoles = String.join(",", u.roles());
            } else {
                actorId = CurrentUser.SYSTEM_ID;
                actorName = "system";
            }
        }
        return new AuditEvent(e.id(), e.category(), e.action(), e.entityType(), e.entityId(), e.candidateId(),
                actorId, actorName, actorEmail, actorRoles, e.outcome(), e.description(), e.details(),
                MDC.get(CorrelationIdFilter.MDC_KEY), serviceName, MDC.get(CorrelationIdFilter.MDC_CLIENT_IP),
                e.occurredAt());
    }

    private void write(AuditEvent e) {
        try {
            String details = e.details() == null || e.details().isEmpty() ? null : objectMapper.writeValueAsString(e.details());
            jdbcTemplate.update(insertSql, e.id(), e.category().name(), e.action(), e.entityType(), e.entityId(),
                    e.candidateId(), e.actorId(), e.actorName(), e.actorEmail(), e.actorRoles(),
                    e.outcome().name(), truncate(e.description(), 2000), details, e.correlationId(), e.serviceName(),
                    e.clientIp(), Timestamp.from(e.occurredAt()));
        } catch (Exception ex) {
            // last resort: keep it in the application log so nothing is silently lost
            log.error("AUDIT_WRITE_FAILED category={} action={} entity={}:{} actor={} error={}",
                    e.category(), e.action(), e.entityType(), e.entityId(), e.actorId(), ex.getMessage());
        }
    }

    private static String truncate(String s, int max) {
        return s == null || s.length() <= max ? s : s.substring(0, max);
    }

    @Override
    public void destroy() throws InterruptedException {
        executor.shutdown();
        executor.awaitTermination(10, TimeUnit.SECONDS);
    }
}
