package com.ags.health.hr.platform.security;

import com.ags.health.hr.platform.config.PlatformProperties;
import com.github.benmanes.caffeine.cache.Cache;
import com.github.benmanes.caffeine.cache.Caffeine;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import java.util.List;
import java.util.Objects;
import java.util.Set;

/**
 * Calls admin-services {@code GET /internal/rbac/effective} and caches the answer.
 * Fail-closed: when admin-services is unreachable the user keeps only the fallback roles for his
 * userType and NO permissions, so permission-protected endpoints answer 403.
 */
public class HttpAccessClient implements AccessClient {

    private static final Logger log = LoggerFactory.getLogger(HttpAccessClient.class);

    private final PlatformProperties properties;
    private final ServiceUrlResolver urlResolver;
    private final RestTemplate restTemplate = new RestTemplate();
    private final Cache<String, EffectiveAccess> cache;
    private final Cache<String, EffectiveAccess> failures = Caffeine.newBuilder()
            .expireAfterWrite(java.time.Duration.ofSeconds(30)).maximumSize(10_000).build();

    public HttpAccessClient(PlatformProperties properties, ServiceUrlResolver urlResolver) {
        this.properties = properties;
        this.urlResolver = urlResolver;
        this.cache = Caffeine.newBuilder()
                .expireAfterWrite(properties.getAccess().getCacheTtl())
                .maximumSize(properties.getAccess().getCacheMaxSize())
                .build();
    }

    @Override
    public EffectiveAccess resolve(String userId, String email, String userType) {
        String key = Objects.toString(userId, "") + "|" + Objects.toString(email, "");
        EffectiveAccess cached = cache.getIfPresent(key);
        if (cached == null) {
            cached = failures.getIfPresent(key);
        }
        if (cached != null) {
            return cached;
        }
        try {
            // URI variables are strictly encoded, so e-mails containing '+' survive the round trip
            java.net.URI url = UriComponentsBuilder
                    .fromUriString(urlResolver.resolve(properties.getAccess().getAdminServiceUrl()))
                    .path("/internal/rbac/effective")
                    .queryParam("userId", "{userId}")
                    .queryParam("email", "{email}")
                    .queryParam("userType", "{userType}")
                    .encode()
                    .buildAndExpand(Objects.toString(userId, ""), Objects.toString(email, ""), Objects.toString(userType, ""))
                    .toUri();
            HttpHeaders headers = new HttpHeaders();
            headers.set(InternalApiKeyFilter.HEADER, properties.getSecurity().getInternalApiKey());
            EffectiveAccess access = restTemplate.exchange(url, HttpMethod.GET, new HttpEntity<>(headers),
                    EffectiveAccess.class).getBody();
            if (access != null) {
                cache.put(key, access);
                return access;
            }
        } catch (RuntimeException ex) {
            log.warn("admin-services unreachable, using fallback roles for userType={} : {}", userType, ex.getMessage());
            EffectiveAccess fallback = fallback(userId, email, userType);
            failures.put(key, fallback); // short negative cache: one call per user per 30s while admin-services is down
            return fallback;
        }
        return fallback(userId, email, userType);
    }

    @Override
    public void evict(String userId, String email) {
        cache.invalidateAll();
        failures.invalidateAll();
    }

    private EffectiveAccess fallback(String userId, String email, String userType) {
        List<String> roles = properties.getAccess().getFallbackRolesByUserType().getOrDefault(userType, List.of());
        return new EffectiveAccess(userId, email, true, Set.copyOf(roles), Set.of(), DataScope.none(userId));
    }
}
