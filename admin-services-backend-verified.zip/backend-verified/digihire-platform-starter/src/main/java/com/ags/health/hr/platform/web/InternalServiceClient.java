package com.ags.health.hr.platform.web;

import com.ags.health.hr.platform.security.CurrentUser;
import com.ags.health.hr.platform.security.CurrentUserProvider;
import com.ags.health.hr.platform.security.InternalApiKeyFilter;
import com.ags.health.hr.platform.security.ServiceUrlResolver;
import org.slf4j.MDC;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.client.SimpleClientHttpRequestFactory;
import org.springframework.web.client.RestTemplate;

/**
 * Minimal service-to-service HTTP helper for {@code /internal/**} endpoints (KISS - no broker).
 * Resolves Eureka service ids, adds the internal key, the correlation id and the acting user.
 * <pre>
 * internalClient.post("http://notification-engine/notification-engine/internal/events", event, Void.class);
 * </pre>
 */
public class InternalServiceClient {

    private final ServiceUrlResolver resolver;
    private final String internalKey;
    private final String callerService;
    private final RestTemplate restTemplate;

    public InternalServiceClient(ServiceUrlResolver resolver, String internalKey, String callerService) {
        this.resolver = resolver;
        this.internalKey = internalKey;
        this.callerService = callerService;
        SimpleClientHttpRequestFactory factory = new SimpleClientHttpRequestFactory();
        factory.setConnectTimeout(3_000);
        factory.setReadTimeout(10_000);
        this.restTemplate = new RestTemplate(factory);
    }

    public <T> T post(String url, Object body, Class<T> responseType) {
        return restTemplate.exchange(resolver.resolve(url), HttpMethod.POST, new HttpEntity<>(body, headers()),
                responseType).getBody();
    }

    public <T> T get(String url, Class<T> responseType) {
        return restTemplate.exchange(resolver.resolve(url), HttpMethod.GET, new HttpEntity<>(headers()),
                responseType).getBody();
    }

    private HttpHeaders headers() {
        HttpHeaders h = new HttpHeaders();
        h.setContentType(MediaType.APPLICATION_JSON);
        if (internalKey != null) {
            h.set(InternalApiKeyFilter.HEADER, internalKey);
        }
        h.set("X-Caller-Service", callerService);
        String correlationId = MDC.get(CorrelationIdFilter.MDC_KEY);
        if (correlationId != null) {
            h.set(CorrelationIdFilter.HEADER, correlationId);
        }
        CurrentUserProvider.current().filter(u -> !u.isSystem()).ifPresent((CurrentUser u) -> {
            h.set("X-Actor-Id", u.userId());
            if (u.email() != null) {
                h.set("X-Actor-Email", u.email());
            }
        });
        return h;
    }
}
