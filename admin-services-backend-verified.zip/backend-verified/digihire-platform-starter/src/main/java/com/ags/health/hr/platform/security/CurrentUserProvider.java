package com.ags.health.hr.platform.security;

import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.util.ClassUtils;

import java.util.Optional;

/**
 * Static access to the caller. Safe to use from services that do not have Spring Security on the
 * classpath (returns empty).
 */
public final class CurrentUserProvider {

    private static final boolean SECURITY_PRESENT = ClassUtils.isPresent(
            "org.springframework.security.core.context.SecurityContextHolder", CurrentUserProvider.class.getClassLoader());

    private CurrentUserProvider() {
    }

    public static Optional<CurrentUser> current() {
        if (!SECURITY_PRESENT) {
            return Optional.empty();
        }
        return Holder.current();
    }

    /** Current user or a SYSTEM user (schedulers, startup seeders). */
    public static CurrentUser currentOrSystem() {
        return current().orElseGet(() -> CurrentUser.system("system"));
    }

    public static CurrentUser require() {
        return current().orElseThrow(() -> new IllegalStateException("No authenticated user"));
    }

    private static final class Holder {
        static Optional<CurrentUser> current() {
            Authentication auth = SecurityContextHolder.getContext().getAuthentication();
            if (auth != null && auth.getPrincipal() instanceof CurrentUser user) {
                return Optional.of(user);
            }
            return Optional.empty();
        }
    }
}
