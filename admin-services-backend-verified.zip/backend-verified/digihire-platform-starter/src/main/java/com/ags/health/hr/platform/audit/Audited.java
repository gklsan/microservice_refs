package com.ags.health.hr.platform.audit;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * Declarative activity logging - put it on any Spring bean method (controller or service):
 * <pre>
 * &#64;Audited(action = "CANDIDATE_MAPPED", entityType = "APPLICATION", entityId = "#result.id",
 *          candidateId = "#request.candidateId")
 * public Application map(MapRequest request) { ... }
 * </pre>
 * SpEL expressions can reference method arguments by name ({@code #request}), by index ({@code #p0})
 * and the return value ({@code #result}). Failures are logged with outcome FAILURE and re-thrown.
 */
@Target(ElementType.METHOD)
@Retention(RetentionPolicy.RUNTIME)
@Documented
public @interface Audited {

    AuditCategory category() default AuditCategory.ACTIVITY;

    /** Business action code, e.g. CANDIDATE_REJECTED. Defaults to ClassName.methodName. */
    String action() default "";

    String entityType() default "";

    /** SpEL for the entity id. */
    String entityId() default "";

    /** SpEL for the candidate id, so the row shows up in the candidate audit timeline. */
    String candidateId() default "";

    String description() default "";
}
