package com.ags.health.hr.platform.audit;

/** BRD 4.21 log families. All land in one table and are filtered by category in the Admin log viewer. */
public enum AuditCategory {
    /** Business activity by a user (create candidate, map job, export report ...). */
    ACTIVITY,
    /** Approval requested / approved / rejected (override access, workflow approvals ...). */
    APPROVAL,
    /** Candidate / application moved from one workflow state to another. */
    WORKFLOW_TRANSITION,
    /** Admin changed configuration (roles, permissions, workflow definitions, templates, enterprise config). */
    CONFIG_CHANGE,
    /** Security relevant events (access denied, user deactivated, override granted). */
    SECURITY,
    /** Email / SMS dispatched to a candidate. */
    NOTIFICATION
}
