package com.ags.health.hr.platform.jpa;

import com.ags.health.hr.platform.security.CurrentUser;
import com.ags.health.hr.platform.security.CurrentUserProvider;
import org.springframework.data.domain.AuditorAware;

import java.util.Optional;

/** Supplies created_by / updated_by from the authenticated user (email), or "system". */
public class SecurityAuditorAware implements AuditorAware<String> {

    @Override
    public Optional<String> getCurrentAuditor() {
        CurrentUser user = CurrentUserProvider.currentOrSystem();
        return Optional.ofNullable(user.email() != null ? user.email() : user.userId());
    }
}
