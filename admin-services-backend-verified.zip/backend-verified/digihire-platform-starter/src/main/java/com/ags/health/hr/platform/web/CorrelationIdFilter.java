package com.ags.health.hr.platform.web;

import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.web.filter.OncePerRequestFilter;

import java.io.IOException;
import java.util.UUID;
import java.util.regex.Pattern;

/**
 * Propagates {@code X-Correlation-Id} (creates one when missing) into the MDC, the response and the audit rows,
 * and - when enabled - writes one timestamped log line per request with its duration.
 */
public class CorrelationIdFilter extends OncePerRequestFilter {

    public static final String HEADER = "X-Correlation-Id";
    public static final String MDC_KEY = "correlationId";
    public static final String MDC_CLIENT_IP = "clientIp";
    private static final Pattern SAFE = Pattern.compile("[A-Za-z0-9\\-_.]{1,64}");
    private static final Logger accessLog = LoggerFactory.getLogger("digihire.access");

    private final boolean requestLogging;

    public CorrelationIdFilter(boolean requestLogging) {
        this.requestLogging = requestLogging;
    }

    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain chain)
            throws ServletException, IOException {
        String incoming = request.getHeader(HEADER);
        String correlationId = incoming != null && SAFE.matcher(incoming).matches() ? incoming : UUID.randomUUID().toString();
        String forwarded = request.getHeader("X-Forwarded-For");
        String clientIp = forwarded != null ? forwarded.split(",")[0].trim() : request.getRemoteAddr();
        long start = System.nanoTime();
        MDC.put(MDC_KEY, correlationId);
        MDC.put(MDC_CLIENT_IP, clientIp);
        response.setHeader(HEADER, correlationId);
        try {
            chain.doFilter(request, response);
        } finally {
            if (requestLogging && !request.getRequestURI().contains("/actuator")) {
                accessLog.info("method={} path={} status={} durationMs={}", request.getMethod(),
                        request.getRequestURI(), response.getStatus(), (System.nanoTime() - start) / 1_000_000);
            }
            MDC.remove(MDC_KEY);
            MDC.remove(MDC_CLIENT_IP);
        }
    }
}
