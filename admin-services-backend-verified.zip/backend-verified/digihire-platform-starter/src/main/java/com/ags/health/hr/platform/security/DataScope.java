package com.ags.health.hr.platform.security;

import java.util.Collections;
import java.util.Map;
import java.util.Set;

/**
 * Row-level visibility for a user (BRD 4.3). Produced by admin-services, consumed by any service that lists
 * candidates / applications / jobs (see {@link com.ags.health.hr.platform.jpa.DataScopeSpecifications}).
 *
 * @param level          widest visibility granted by the user's roles
 * @param userId         the user himself (owner match)
 * @param teamUserIds    users reporting (directly or indirectly) to this user - used for TEAM level (TL / Manager)
 * @param lobs           supervised / assigned lines of business
 * @param locations      assigned locations
 * @param sharedObjects  objects shared through an approved access request, keyed by object type (e.g. CANDIDATE -> ids)
 */
public record DataScope(Level level,
                        String userId,
                        Set<String> teamUserIds,
                        Set<String> lobs,
                        Set<String> locations,
                        Map<String, Set<String>> sharedObjects) {

    public enum Level { NONE, OWN, TEAM, LOB, LOCATION, ALL }

    public DataScope {
        level = level == null ? Level.NONE : level;
        teamUserIds = teamUserIds == null ? Set.of() : Set.copyOf(teamUserIds);
        lobs = lobs == null ? Set.of() : Set.copyOf(lobs);
        locations = locations == null ? Set.of() : Set.copyOf(locations);
        sharedObjects = sharedObjects == null ? Map.of() : Map.copyOf(sharedObjects);
    }

    public static DataScope none(String userId) {
        return new DataScope(Level.NONE, userId, Set.of(), Set.of(), Set.of(), Map.of());
    }

    public Set<String> sharedIds(String objectType) {
        // Map.copyOf(...) rejects null keys even on lookup (NPE), and callers may pass a null object type
        return objectType == null ? Collections.emptySet() : sharedObjects.getOrDefault(objectType, Collections.emptySet());
    }
}
