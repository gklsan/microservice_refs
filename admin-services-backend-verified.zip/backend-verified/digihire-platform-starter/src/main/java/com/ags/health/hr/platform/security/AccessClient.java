package com.ags.health.hr.platform.security;

/**
 * Resolves roles, permissions and data scope for a user.
 * Default implementation calls admin-services; admin-services itself provides a local implementation.
 */
public interface AccessClient {

    EffectiveAccess resolve(String userId, String email, String userType);

    /** Drop any cached entry (called after admin changes). */
    default void evict(String userId, String email) {
    }
}
