package com.ags.health.hr.platform.security;

import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.filter.OncePerRequestFilter;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.List;

/**
 * Authenticates service-to-service calls carrying {@code X-Internal-Key}. Grants ROLE_INTERNAL only,
 * which is what the {@code /internal/**} endpoints require. Optional headers X-Actor-Id / X-Actor-Name
 * let the caller pass the end user for audit purposes.
 */
public class InternalApiKeyFilter extends OncePerRequestFilter {

    public static final String HEADER = "X-Internal-Key";

    private final byte[] expectedKey;

    public InternalApiKeyFilter(String internalApiKey) {
        this.expectedKey = internalApiKey == null ? null : internalApiKey.getBytes(StandardCharsets.UTF_8);
    }

    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain chain)
            throws ServletException, IOException {
        String provided = request.getHeader(HEADER);
        if (provided != null && expectedKey != null && expectedKey.length > 0
                && MessageDigest.isEqual(expectedKey, provided.getBytes(StandardCharsets.UTF_8))) {
            String actorId = request.getHeader("X-Actor-Id");
            String actorName = request.getHeader("X-Actor-Name");
            CurrentUser system = CurrentUser.system(request.getHeader("X-Caller-Service") != null
                    ? request.getHeader("X-Caller-Service") : "internal");
            CurrentUser user = actorId == null ? system
                    : new CurrentUser(actorId, request.getHeader("X-Actor-Email"), actorName, "SYSTEM",
                    system.roles(), system.permissions(), system.scope(), null);
            SecurityContextHolder.getContext().setAuthentication(
                    new DigiHireAuthentication(user, List.of(new SimpleGrantedAuthority("ROLE_INTERNAL"))));
        }
        chain.doFilter(request, response);
    }
}
