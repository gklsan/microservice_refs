package com.ags.health.hr.platform.config;

import com.ags.health.hr.platform.security.AccessClient;
import com.ags.health.hr.platform.security.DigiHireJwtAuthenticationConverter;
import com.ags.health.hr.platform.security.HttpAccessClient;
import com.ags.health.hr.platform.security.InternalApiKeyFilter;
import com.ags.health.hr.platform.security.ServiceUrlResolver;
import org.springframework.boot.autoconfigure.AutoConfiguration;
import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.autoconfigure.condition.ConditionalOnWebApplication;
import org.springframework.boot.autoconfigure.security.oauth2.resource.servlet.OAuth2ResourceServerAutoConfiguration;
import org.springframework.boot.autoconfigure.security.servlet.SecurityAutoConfiguration;
import org.springframework.boot.autoconfigure.security.servlet.UserDetailsServiceAutoConfiguration;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.http.HttpMethod;
import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.oauth2.jose.jws.MacAlgorithm;
import org.springframework.security.oauth2.jwt.JwtDecoder;
import org.springframework.security.oauth2.jwt.NimbusJwtDecoder;
import org.springframework.security.oauth2.server.resource.web.authentication.BearerTokenAuthenticationFilter;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.util.StringUtils;

import javax.crypto.spec.SecretKeySpec;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Base64;
import java.util.HexFormat;
import java.util.List;

/**
 * Stateless JWT resource-server security that VERIFIES the HS256 signature (today downstream services only
 * Base64-decode the payload - see knowledge base §25 item 2). Only active when Spring Security +
 * oauth2-resource-server are on the classpath and {@code digihire.security.enabled=true}.
 */
@AutoConfiguration(after = PlatformAutoConfiguration.class, before = {SecurityAutoConfiguration.class, UserDetailsServiceAutoConfiguration.class,
        OAuth2ResourceServerAutoConfiguration.class})
@ConditionalOnWebApplication(type = ConditionalOnWebApplication.Type.SERVLET)
@ConditionalOnClass({SecurityFilterChain.class, JwtDecoder.class})
@ConditionalOnProperty(prefix = "digihire.security", name = "enabled", havingValue = "true", matchIfMissing = true)
@EnableConfigurationProperties(PlatformProperties.class)
@EnableMethodSecurity
public class PlatformSecurityAutoConfiguration {

    private static final String[] ALWAYS_PUBLIC = {
            "/actuator/health/**", "/actuator/info", "/v3/api-docs/**", "/swagger-ui/**", "/swagger-ui.html", "/error"
    };

    @Bean
    @ConditionalOnMissingBean
    public AccessClient accessClient(PlatformProperties properties, ServiceUrlResolver resolver) {
        return new HttpAccessClient(properties, resolver);
    }

    @Bean
    @ConditionalOnMissingBean
    public JwtDecoder digiHireJwtDecoder(PlatformProperties properties) {
        String secret = properties.getSecurity().getJwtSecret();
        if (!StringUtils.hasText(secret)) {
            throw new IllegalStateException("digihire.security.jwt-secret (env JWT_SECRET) must be set");
        }
        byte[] key = switch (properties.getSecurity().getJwtSecretEncoding()) {
            case BASE64 -> Base64.getDecoder().decode(secret);
            case HEX -> HexFormat.of().parseHex(secret);
            case RAW -> secret.getBytes(StandardCharsets.UTF_8);
        };
        return NimbusJwtDecoder.withSecretKey(new SecretKeySpec(key, "HmacSHA256"))
                .macAlgorithm(MacAlgorithm.HS256)
                .build();
    }

    @Bean
    @ConditionalOnMissingBean
    public DigiHireJwtAuthenticationConverter digiHireJwtAuthenticationConverter(AccessClient accessClient) {
        return new DigiHireJwtAuthenticationConverter(accessClient);
    }

    @Bean
    @ConditionalOnMissingBean(SecurityFilterChain.class)
    public SecurityFilterChain digiHireSecurityFilterChain(HttpSecurity http,
                                                           PlatformProperties properties,
                                                           JwtDecoder jwtDecoder,
                                                           DigiHireJwtAuthenticationConverter converter) throws Exception {
        List<String> publicPaths = new ArrayList<>(List.of(ALWAYS_PUBLIC));
        publicPaths.addAll(properties.getSecurity().getPublicPaths());

        http.csrf(csrf -> csrf.disable())
            .sessionManagement(s -> s.sessionCreationPolicy(SessionCreationPolicy.STATELESS))
            .authorizeHttpRequests(auth -> auth
                    .requestMatchers(HttpMethod.OPTIONS, "/**").permitAll()
                    .requestMatchers(publicPaths.toArray(String[]::new)).permitAll()
                    .requestMatchers("/internal/**").hasRole("INTERNAL")
                    .anyRequest().authenticated())
            .addFilterBefore(new InternalApiKeyFilter(properties.getSecurity().getInternalApiKey()),
                    BearerTokenAuthenticationFilter.class)
            .oauth2ResourceServer(oauth -> oauth.jwt(jwt -> jwt
                    .decoder(jwtDecoder)
                    .jwtAuthenticationConverter(converter)));
        return http.build();
    }
}
