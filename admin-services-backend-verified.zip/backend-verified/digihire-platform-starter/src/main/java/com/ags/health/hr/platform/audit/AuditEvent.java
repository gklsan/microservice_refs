package com.ags.health.hr.platform.audit;

import java.time.Instant;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.UUID;

/**
 * One immutable audit row. Use {@link #builder(AuditCategory, String)}:
 * <pre>
 * auditLogger.log(AuditEvent.builder(AuditCategory.APPROVAL, "ACCESS_REQUEST_APPROVED")
 *         .entity("ACCESS_REQUEST", id).detail("remarks", remarks).build());
 * </pre>
 * Actor, correlation id, service name and timestamp are filled in automatically when omitted.
 */
public record AuditEvent(UUID id,
                         AuditCategory category,
                         String action,
                         String entityType,
                         String entityId,
                         String candidateId,
                         String actorId,
                         String actorName,
                         String actorEmail,
                         String actorRoles,
                         Outcome outcome,
                         String description,
                         Map<String, Object> details,
                         String correlationId,
                         String serviceName,
                         String clientIp,
                         Instant occurredAt) {

    public enum Outcome { SUCCESS, FAILURE }

    public static Builder builder(AuditCategory category, String action) {
        return new Builder(category, action);
    }

    public static final class Builder {
        private final AuditCategory category;
        private final String action;
        private String entityType;
        private String entityId;
        private String candidateId;
        private String actorId;
        private String actorName;
        private String actorEmail;
        private String actorRoles;
        private Outcome outcome = Outcome.SUCCESS;
        private String description;
        private final Map<String, Object> details = new LinkedHashMap<>();
        private Instant occurredAt;

        private Builder(AuditCategory category, String action) {
            this.category = category;
            this.action = action;
        }

        public Builder entity(String type, Object id) {
            this.entityType = type;
            this.entityId = id == null ? null : id.toString();
            return this;
        }

        public Builder candidate(Object candidateId) {
            this.candidateId = candidateId == null ? null : candidateId.toString();
            return this;
        }

        public Builder actor(String id, String name, String email, String roles) {
            this.actorId = id;
            this.actorName = name;
            this.actorEmail = email;
            this.actorRoles = roles;
            return this;
        }

        public Builder outcome(Outcome outcome) {
            this.outcome = outcome;
            return this;
        }

        public Builder description(String description) {
            this.description = description;
            return this;
        }

        public Builder detail(String key, Object value) {
            if (value != null) {
                this.details.put(key, value);
            }
            return this;
        }

        public Builder details(Map<String, ?> values) {
            if (values != null) {
                values.forEach(this::detail);
            }
            return this;
        }

        public Builder occurredAt(Instant occurredAt) {
            this.occurredAt = occurredAt;
            return this;
        }

        public AuditEvent build() {
            return new AuditEvent(UUID.randomUUID(), category, action, entityType, entityId, candidateId,
                    actorId, actorName, actorEmail, actorRoles, outcome, description, Map.copyOf(details),
                    null, null, null, occurredAt == null ? Instant.now() : occurredAt);
        }
    }
}
