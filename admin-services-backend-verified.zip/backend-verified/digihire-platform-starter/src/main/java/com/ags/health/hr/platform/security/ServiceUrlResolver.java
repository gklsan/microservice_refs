package com.ags.health.hr.platform.security;

import org.springframework.beans.factory.ObjectProvider;
import org.springframework.util.ClassUtils;

import java.net.URI;

/**
 * Turns {@code http://admin-services/...} into a concrete instance URL through Eureka when
 * spring-cloud-loadbalancer is on the classpath; otherwise returns the URL unchanged
 * (so plain host names / k8s service names also work).
 * Deliberately does NOT register a RestTemplate bean, to avoid clashing with RestTemplate beans
 * that the existing services autowire by type.
 */
public class ServiceUrlResolver {

    private static final boolean LB_PRESENT = ClassUtils.isPresent(
            "org.springframework.cloud.client.loadbalancer.LoadBalancerClient", ServiceUrlResolver.class.getClassLoader());

    private final ObjectProvider<Object> loadBalancerClient;

    public ServiceUrlResolver(ObjectProvider<Object> loadBalancerClient) {
        this.loadBalancerClient = loadBalancerClient;
    }

    public String resolve(String url) {
        if (!LB_PRESENT || loadBalancerClient == null) {
            return url;
        }
        Object candidate = loadBalancerClient.getIfAvailable();
        if (candidate == null) {
            return url;
        }
        URI uri = URI.create(url);
        String host = uri.getHost();
        if (host == null || host.contains(".") || "localhost".equalsIgnoreCase(host) || uri.getPort() > 0) {
            return url; // already a concrete address
        }
        return LbSupport.choose(candidate, host, uri);
    }

    /** Isolated so the class is only loaded when spring-cloud-commons is present. */
    static final class LbSupport {
        static String choose(Object client, String serviceId, URI uri) {
            var lb = (org.springframework.cloud.client.loadbalancer.LoadBalancerClient) client;
            var instance = lb.choose(serviceId);
            if (instance == null) {
                throw new IllegalStateException("No available instance for service '" + serviceId + "'");
            }
            return lb.reconstructURI(instance, uri).toString();
        }
    }
}
