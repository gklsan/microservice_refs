package com.ags.health.hr.platform.audit;

/** Central logging API (BRD 4.21). Never throws; never blocks the business transaction. */
public interface AuditLogger {

    void log(AuditEvent event);

    AuditLogger NO_OP = event -> { };
}
