package com.ags.health.hr.platform.security;

import java.util.Set;

/**
 * Authenticated caller. Built from the (signature-verified) JWT issued by auth-services
 * plus the effective access resolved from admin-services.
 */
public record CurrentUser(String userId,
                          String email,
                          String name,
                          String userType,
                          Set<String> roles,
                          Set<String> permissions,
                          DataScope scope,
                          String token) {

    public static final String SYSTEM_ID = "00000000-0000-0000-0000-000000000000";

    public CurrentUser {
        roles = roles == null ? Set.of() : Set.copyOf(roles);
        permissions = permissions == null ? Set.of() : Set.copyOf(permissions);
        scope = scope == null ? DataScope.none(userId) : scope;
    }

    public static CurrentUser system(String name) {
        return new CurrentUser(SYSTEM_ID, "system@digihire", name, "SYSTEM",
                Set.of("INTERNAL"), Set.of(), DataScope.none(SYSTEM_ID), null);
    }

    public boolean hasRole(String role) {
        return roles.contains(role);
    }

    public boolean hasPermission(String permission) {
        return permissions.contains(permission);
    }

    public boolean isSystem() {
        return SYSTEM_ID.equals(userId);
    }
}
