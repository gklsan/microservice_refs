package com.ags.health.hr.platform.security;

import org.springframework.core.convert.converter.Converter;
import org.springframework.security.authentication.AbstractAuthenticationToken;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.oauth2.jwt.Jwt;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

/**
 * Maps the auth-services JWT (claims: sub, email, userId, userType, userName) to a {@link DigiHireAuthentication}.
 * Authorities produced:
 * <ul>
 *   <li>{@code USERTYPE_<userType>} - legacy user type (EMPLOYEE_HR, CANDIDATE, ...)</li>
 *   <li>{@code ROLE_<role>}        - Phase 5 roles from admin-services (ADMIN, TA_HEAD, TL, RECRUITER, ...)</li>
 *   <li>{@code <OBJECT>:<ACTION>}  - flattened permissions, e.g. {@code CANDIDATE:VIEW}</li>
 * </ul>
 * Use them with {@code @PreAuthorize("hasAuthority('WORKFLOW:CONFIGURE')")} or {@code hasRole('ADMIN')}.
 */
public class DigiHireJwtAuthenticationConverter implements Converter<Jwt, AbstractAuthenticationToken> {

    private final AccessClient accessClient;

    public DigiHireJwtAuthenticationConverter(AccessClient accessClient) {
        this.accessClient = accessClient;
    }

    @Override
    public AbstractAuthenticationToken convert(Jwt jwt) {
        String userId = jwt.getClaimAsString("userId");
        String email = jwt.hasClaim("email") ? jwt.getClaimAsString("email") : jwt.getSubject();
        String name = jwt.getClaimAsString("userName");
        String userType = jwt.getClaimAsString("userType");

        EffectiveAccess access = accessClient.resolve(userId, email, userType);
        boolean active = access.active();
        Set<String> roles = active ? access.roles() : Set.of();
        Set<String> permissions = active ? access.permissions() : Set.of();

        List<GrantedAuthority> authorities = new ArrayList<>();
        if (userType != null) {
            authorities.add(new SimpleGrantedAuthority("USERTYPE_" + userType));
        }
        roles.forEach(r -> authorities.add(new SimpleGrantedAuthority("ROLE_" + r)));
        permissions.forEach(p -> authorities.add(new SimpleGrantedAuthority(p)));

        String resolvedId = userId != null ? userId : access.userId();
        CurrentUser user = new CurrentUser(resolvedId, email, name, userType, roles, permissions,
                active ? access.scope() : DataScope.none(resolvedId), jwt.getTokenValue());
        return new DigiHireAuthentication(user, authorities);
    }
}
