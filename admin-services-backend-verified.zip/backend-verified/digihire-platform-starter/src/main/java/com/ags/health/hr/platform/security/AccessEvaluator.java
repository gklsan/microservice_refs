package com.ags.health.hr.platform.security;

/**
 * In-process record-level check, mirroring {@link com.ags.health.hr.platform.jpa.DataScopeSpecifications}
 * for single records (e.g. "can this recruiter open candidate X?").
 * <pre>
 * AccessEvaluator.Decision d = AccessEvaluator.check(user, "CANDIDATE:VIEW",
 *         new AccessEvaluator.Target("CANDIDATE", candidateId, application.getHr(), job.getLob(), job.getLocation()));
 * if (!d.allowed()) throw ApiException.forbidden(d.reason());
 * </pre>
 */
public final class AccessEvaluator {

    private AccessEvaluator() {
    }

    /** Record being accessed. Any field may be null (e.g. on create there is no owner yet). */
    public record Target(String objectType, String objectId, String ownerId, String lob, String location) {
    }

    public record Decision(boolean allowed, String reason) {
        static Decision allow(String reason) { return new Decision(true, reason); }
        static Decision deny(String reason) { return new Decision(false, reason); }
    }

    public static Decision check(CurrentUser user, String permission, Target target) {
        if (user == null) {
            return Decision.deny("NOT_AUTHENTICATED");
        }
        if (permission != null && !user.hasPermission(permission)) {
            return Decision.deny("MISSING_PERMISSION");
        }
        if (target == null || (target.objectId() == null && target.ownerId() == null
                && target.lob() == null && target.location() == null)) {
            return Decision.allow("PERMISSION");
        }
        DataScope scope = user.scope();
        switch (scope.level()) {
            case ALL:
                return Decision.allow("SCOPE_ALL");
            case NONE:
                return Decision.deny("NO_SCOPE");
            default:
                break;
        }
        String owner = target.ownerId();
        if (owner != null && owner.equals(user.userId())) {
            return Decision.allow("OWNER");
        }
        if (owner != null && scope.level() != DataScope.Level.OWN && scope.teamUserIds().contains(owner)) {
            return Decision.allow("TEAM");
        }
        if (target.objectId() != null && scope.sharedIds(target.objectType()).contains(target.objectId())) {
            return Decision.allow("SHARED_BY_APPROVAL");
        }
        if (scope.level() == DataScope.Level.LOB && target.lob() != null && scope.lobs().contains(target.lob())
                && (scope.locations().isEmpty() || target.location() == null || scope.locations().contains(target.location()))) {
            return Decision.allow("LOB");
        }
        if (scope.level() == DataScope.Level.LOCATION && target.location() != null
                && scope.locations().contains(target.location())) {
            return Decision.allow("LOCATION");
        }
        return Decision.deny("OUT_OF_SCOPE");
    }
}
