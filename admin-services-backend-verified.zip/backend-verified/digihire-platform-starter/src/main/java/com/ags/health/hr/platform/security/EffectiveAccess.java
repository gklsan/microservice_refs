package com.ags.health.hr.platform.security;

import java.util.Set;

/**
 * Everything a service needs to authorise a request: roles, flattened permission codes
 * (OBJECT:ACTION, e.g. CANDIDATE:VIEW) and the row-level {@link DataScope}.
 */
public record EffectiveAccess(String userId,
                              String email,
                              boolean active,
                              Set<String> roles,
                              Set<String> permissions,
                              DataScope scope) {

    public EffectiveAccess {
        roles = roles == null ? Set.of() : Set.copyOf(roles);
        permissions = permissions == null ? Set.of() : Set.copyOf(permissions);
        scope = scope == null ? DataScope.none(userId) : scope;
    }

    public boolean has(String permission) {
        return active && permissions.contains(permission);
    }
}
