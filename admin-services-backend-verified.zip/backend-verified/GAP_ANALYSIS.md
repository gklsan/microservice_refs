# Backend gap analysis — cross-verification against the real admin-services + digihire-platform-starter

Full request: regenerate complete backend (Java + SQL) and cross-verify the architect's real code
for correctness, resolving genuine gaps — not a rewrite.

This zip is the **real, verified backend source**, patched in two narrowly-scoped places. It is
not a regeneration from scratch: a from-scratch rewrite would have thrown away a well-designed,
internally consistent module to re-solve problems that don't exist, and would have risked
introducing new bugs in place of the two real ones found below. The two patches are additive
(no existing behavior removed) and each carries an inline comment explaining what it fixes and
why, plus what it deliberately does not fix.

Every `.java` file in both modules (61 total), both Flyway migrations, `application.yml`, and both
`pom.xml` files were read in full before drawing any conclusion below.

---

## Patched

### 1. `admin-services/.../repo/AppUserRepository.java` — N+1 query fix

`AccessService.resolve()` runs on every authenticated request into admin-services, and by every
other service's `HttpAccessClient` on a cache miss. It walks each of the user's active roles and
their permissions. `AppUser.roles` is `@ManyToMany(EAGER)`, but `Role.permissions` is plain `LAZY`
with no fetch hint on `findBySmartieUserId`/`findByEmailIgnoreCase` — one extra query per role the
user holds, on the hottest path in the module.

Fix: `@EntityGraph(attributePaths = {"roles", "roles.permissions", "permissionGrants", "scopes"})`
on both finders — one round trip instead of N+1. Matches the pattern `RoleRepository` already uses
for its own `permissions` fetch.

### 2. `admin-services/.../service/UserAdminService.java` — inconsistent cache eviction

`deactivate()` called `accessClient.evict(...)`; `reactivate()`, `assignRoles()` and
`setPermissions()` did not, despite changing the exact same "who can do what" data. No defensible
reason deactivation alone should get a stronger consistency guarantee. Fixed by calling `evict()`
from all four mutation paths.

**Real limitation this does not fix** (see class Javadoc added on `UserAdminService` and design
doc §6.3 for the full writeup): `AccessClient.evict()` is a no-op inside admin-services itself (no
local cache there); it does not reach the `HttpAccessClient` Caffeine cache every *other* service
holds (2-min TTL). A role/permission/activation change can still take up to 2 minutes to propagate
cross-service. Fixing that for real needs a design decision (pub/sub bust event, shorter TTL, or
synchronous per-service evict calls) — flagged, not invented here, since it's a bigger change than
what was asked.

`RoleService` was deliberately left unpatched — no `AccessClient` dependency today, and adding one
just to call a currently-no-op method isn't worth the coupling. Same underlying limitation, noted
rather than forced.

---

## Also fixed (frontend, delivered separately)

`api-error.util.ts` and `rbac.models.ts` in the Angular zip assumed `{"message": "..."}` error
bodies — wrong. Verified real shape by reading `GlobalExceptionHandler.java`: RFC 7807
`ProblemDetail` with `detail` (message) and a top-level `code` (not nested under "properties" —
Spring flattens `setProperty(...)` calls to the JSON root). Also distinguishes the one real 403
split: `ApiException.forbidden(...)` (business rules — still a normal ProblemDetail, `code:
"FORBIDDEN"`) vs. Spring Security's own `AccessDeniedException` on a `@PreAuthorize` failure
(bypasses `GlobalExceptionHandler` entirely, no `detail`/`code` at all). Full writeup in the design
doc's §6.1, in the `claude/rbac-admin-ui-integration.md` project doc.

---

## Investigated, ruled out (not bugs)

- `default_role_permission` unpopulated → `resetToDefaults()` a no-op: **disproven**, all 9 roles
  seeded in `V2__seed_rbac_defaults.sql`.
- `ACCESS_OVERRIDE:APPROVE` granted to no role → approval workflow unusable out of the box:
  **disproven**, granted by default to `ADMIN`, `TA_HEAD`, `MANAGER`, `TL`.

## Everything else

Audit logging, correlation-ID propagation, internal service-to-service auth
(`InternalApiKeyFilter`), JWT conversion (`DigiHireJwtAuthenticationConverter`), the
approver-reporting-chain check, the ADMIN-role lock rules, and both Flyway migrations were read in
full and are internally consistent with what the controllers/services expect from them. No other
issues found.

## Not included

`admin-services/src/test/java` was empty scaffolding in the original — no tests existed to verify
against, and none were fabricated to fill the gap. Worth doing for real, separately.
