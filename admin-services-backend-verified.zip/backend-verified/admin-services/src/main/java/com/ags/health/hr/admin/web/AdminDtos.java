package com.ags.health.hr.admin.web;

import com.ags.health.hr.admin.domain.AccessRequest;
import com.ags.health.hr.admin.domain.AppUser;
import com.ags.health.hr.admin.domain.EnterpriseConfig;
import com.ags.health.hr.admin.domain.MasterData;
import com.ags.health.hr.admin.domain.Permission;
import com.ags.health.hr.admin.domain.Role;
import com.ags.health.hr.admin.domain.SearchFilter;
import com.ags.health.hr.platform.security.DataScope;
import jakarta.validation.Valid;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import org.springframework.data.domain.Page;

import java.time.Instant;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;
import java.util.UUID;
import java.util.stream.Collectors;

/** Request / response contracts of admin-services (grouped to keep the module small). */
public final class AdminDtos {

    private AdminDtos() {
    }

    // ------------------------------------------------------------------ common
    public record PageResponse<T>(List<T> content, int page, int size, long totalElements, int totalPages) {
        public static <T> PageResponse<T> of(Page<T> p) {
            return new PageResponse<>(p.getContent(), p.getNumber(), p.getSize(), p.getTotalElements(), p.getTotalPages());
        }
    }

    public record RemarksRequest(@Size(max = 1000) String remarks) {
    }

    // ------------------------------------------------------------------ users (tracker #22, #23, #24)
    public record CreateUserRequest(@NotBlank @Email @Size(max = 254) String email,
                                    @NotBlank @Size(max = 200) String fullName,
                                    @Size(max = 50) String employeeCode,
                                    @Pattern(regexp = "EMPLOYEE_HR|EMPLOYEE_HR_ADMIN|EMPLOYEE_NON_HR") String userType,
                                    @NotEmpty Set<String> roles,
                                    Set<String> lobs,
                                    Set<String> locations,
                                    UUID managerId) {
    }

    public record UpdateUserRequest(@NotBlank @Size(max = 200) String fullName,
                                    @Size(max = 50) String employeeCode,
                                    UUID managerId,
                                    Set<String> lobs,
                                    Set<String> locations) {
    }

    public record AssignRolesRequest(@NotEmpty Set<String> roles) {
    }

    public record PermissionGrantDto(@NotBlank String permission, @NotNull AppUser.Effect effect) {
    }

    public record UserPermissionsRequest(@NotNull List<@Valid PermissionGrantDto> grants) {
    }

    public record UserResponse(UUID id, UUID smartieUserId, String email, String fullName, String employeeCode,
                               String userType, AppUser.Status status, UUID managerId, Set<String> roles,
                               Set<String> lobs, Set<String> locations, List<PermissionGrantDto> permissionGrants,
                               Instant createdAt, String createdBy, Instant updatedAt, String updatedBy) {
        public static UserResponse of(AppUser u) {
            return new UserResponse(u.getId(), u.getSmartieUserId(), u.getEmail(), u.getFullName(), u.getEmployeeCode(),
                    u.getUserType(), u.getStatus(), u.getManagerId(),
                    u.getRoles().stream().map(Role::getCode).collect(Collectors.toCollection(TreeSet::new)),
                    u.getScopes().stream().filter(s -> s.dimension() == AppUser.Dimension.LOB)
                            .map(AppUser.ScopeValue::value).collect(Collectors.toCollection(TreeSet::new)),
                    u.getScopes().stream().filter(s -> s.dimension() == AppUser.Dimension.LOCATION)
                            .map(AppUser.ScopeValue::value).collect(Collectors.toCollection(TreeSet::new)),
                    u.getPermissionGrants().stream().map(g -> new PermissionGrantDto(g.permissionCode(), g.effect())).toList(),
                    u.getCreatedAt(), u.getCreatedBy(), u.getUpdatedAt(), u.getUpdatedBy());
        }
    }

    // ------------------------------------------------------------------ roles & matrix (tracker #1-3, #25)
    public record RoleRequest(@NotBlank @Pattern(regexp = "[A-Z][A-Z0-9_]{1,49}") String code,
                              @NotBlank @Size(max = 100) String name,
                              @Size(max = 500) String description,
                              @NotNull DataScope.Level scopeLevel,
                              Boolean active,
                              Set<String> permissions) {
    }

    public record RoleResponse(UUID id, String code, String name, String description, DataScope.Level scopeLevel,
                               boolean systemRole, boolean active, Set<String> permissions) {
        public static RoleResponse of(Role r) {
            return new RoleResponse(r.getId(), r.getCode(), r.getName(), r.getDescription(), r.getScopeLevel(),
                    r.isSystemRole(), r.isActive(),
                    r.getPermissions().stream().map(Permission::getCode).collect(Collectors.toCollection(TreeSet::new)));
        }
    }

    public record PermissionResponse(String code, String objectType, String action, String description) {
        public static PermissionResponse of(Permission p) {
            return new PermissionResponse(p.getCode(), p.getObjectType(), p.getAction(), p.getDescription());
        }
    }

    /** Role x permission grid for the matrix screen. grants: roleCode -> permission codes. */
    public record MatrixResponse(List<RoleResponse> roles, List<PermissionResponse> permissions,
                                 Map<String, Set<String>> grants) {
    }

    public record MatrixUpdateRequest(@NotNull Map<String, Set<String>> grants) {
    }

    // ------------------------------------------------------------------ access requests (tracker #6, #8)
    public record AccessRequestCreate(@NotBlank @Pattern(regexp = "CANDIDATE|APPLICATION|JOB") String objectType,
                                      @Size(max = 100) String objectId,
                                      @Size(max = 80) String permissionCode,
                                      @NotBlank @Size(max = 1000) String reason,
                                      @Min(1) @Max(365) Integer validDays) {
    }

    public record AccessRequestResponse(UUID id, String requesterId, String requesterEmail, String requesterName,
                                        String objectType, String objectId, String permissionCode, String reason,
                                        AccessRequest.Status status, int validDays, Instant validUntil,
                                        String approverId, String approverEmail, Instant decidedAt,
                                        String decisionRemarks, Instant createdAt) {
        public static AccessRequestResponse of(AccessRequest a) {
            return new AccessRequestResponse(a.getId(), a.getRequesterId(), a.getRequesterEmail(), a.getRequesterName(),
                    a.getObjectType(), a.getObjectId(), a.getPermissionCode(), a.getReason(), a.getStatus(),
                    a.getValidDays(), a.getValidUntil(), a.getApproverId(), a.getApproverEmail(), a.getDecidedAt(),
                    a.getDecisionRemarks(), a.getCreatedAt());
        }
    }

    // ------------------------------------------------------------------ enterprise config (tracker #32)
    public record ConfigUpdateRequest(@NotNull String value, @Size(max = 500) String description) {
    }

    public record ConfigCreateRequest(@NotBlank @Pattern(regexp = "[a-z0-9][a-z0-9.\\-]{2,149}") String key,
                                      @NotNull String value,
                                      @NotNull EnterpriseConfig.ValueType valueType,
                                      @NotBlank @Size(max = 60) String category,
                                      @Size(max = 500) String description) {
    }

    public record ConfigResponse(String key, String value, EnterpriseConfig.ValueType valueType, String category,
                                 String description, Instant updatedAt, String updatedBy, Long version) {
        public static ConfigResponse of(EnterpriseConfig c) {
            return new ConfigResponse(c.getKey(), c.getValue(), c.getValueType(), c.getCategory(), c.getDescription(),
                    c.getUpdatedAt() != null ? c.getUpdatedAt() : c.getCreatedAt(),
                    c.getUpdatedBy() != null ? c.getUpdatedBy() : c.getCreatedBy(), c.getRowVersion());
        }
    }

    // ------------------------------------------------------------------ filters & master data (tracker #4)
    public record FilterOption(String value, String label) {
    }

    /** One filter as the UI renders it. optionsEndpoint is set when options come from another service. */
    public record FilterDefinition(String key, String label, String type, List<FilterOption> options,
                                   String optionsEndpoint, int order) {
    }

    public record SearchFilterRequest(@NotBlank @Size(max = 60) String screen,
                                      @NotBlank @Size(max = 60) String filterKey,
                                      @NotBlank @Size(max = 100) String label,
                                      @NotBlank @Pattern(regexp = "MULTI_SELECT|SELECT|DATE_RANGE|RANGE|TEXT|BOOLEAN") String filterType,
                                      @Size(max = 100) String optionsSource,
                                      String staticOptions,
                                      @Size(max = 500) String allowedRoles,
                                      boolean restrictToScope,
                                      int sortOrder,
                                      Boolean active) {
    }

    public record SearchFilterResponse(UUID id, String screen, String filterKey, String label, String filterType,
                                       String optionsSource, String staticOptions, String allowedRoles,
                                       boolean restrictToScope, int sortOrder, boolean active) {
        public static SearchFilterResponse of(SearchFilter f) {
            return new SearchFilterResponse(f.getId(), f.getScreen(), f.getFilterKey(), f.getLabel(), f.getFilterType(),
                    f.getOptionsSource(), f.getStaticOptions(), f.getAllowedRoles(), f.isRestrictToScope(),
                    f.getSortOrder(), f.isActive());
        }
    }

    public record MasterDataRequest(@NotBlank @Size(max = 100) String code,
                                    @NotBlank @Size(max = 200) String label,
                                    @Size(max = 100) String parentCode,
                                    int sortOrder,
                                    Boolean active) {
    }

    public record MasterDataResponse(UUID id, String category, String code, String label, String parentCode,
                                     int sortOrder, boolean active) {
        public static MasterDataResponse of(MasterData m) {
            return new MasterDataResponse(m.getId(), m.getCategory(), m.getCode(), m.getLabel(), m.getParentCode(),
                    m.getSortOrder(), m.isActive());
        }
    }

    // ------------------------------------------------------------------ rbac for UI
    public record MeResponse(String userId, String email, String name, String userType, Set<String> roles,
                             Set<String> permissions, DataScope scope) {
    }

    public record CheckRequest(String permission, String objectType, String objectId, String ownerId, String lob,
                               String location) {
    }

    public record CheckResponse(boolean allowed, String reason) {
    }
}
