package com.ags.health.hr.admin.domain;

import com.ags.health.hr.platform.jpa.AuditableEntity;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/** Enterprise-level key/value settings. Only ADMIN may change them (tracker #32). */
@Entity
@Table(name = "enterprise_config")
@Getter
@Setter
@NoArgsConstructor
public class EnterpriseConfig extends AuditableEntity {

    public enum ValueType { STRING, NUMBER, BOOLEAN, JSON, LIST }

    @Id
    @Column(name = "config_key")
    private String key;

    @Column(name = "config_value")
    private String value;

    @Enumerated(EnumType.STRING)
    @Column(name = "value_type", nullable = false)
    private ValueType valueType = ValueType.STRING;

    @Column(nullable = false)
    private String category = "GENERAL";

    private String description;
}
