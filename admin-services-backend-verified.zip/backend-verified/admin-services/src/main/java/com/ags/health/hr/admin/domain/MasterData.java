package com.ags.health.hr.admin.domain;

import com.ags.health.hr.platform.jpa.AuditableEntity;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.UUID;

/** Generic lookup values (LOB, LOCATION, COUNTRY, SHIFT, REJECTION_REASON, HOLD_REASON ...). */
@Entity
@Table(name = "master_data")
@Getter
@Setter
@NoArgsConstructor
public class MasterData extends AuditableEntity {

    @Id
    private UUID id;

    @Column(nullable = false)
    private String category;

    @Column(nullable = false)
    private String code;

    @Column(nullable = false)
    private String label;

    @Column(name = "parent_code")
    private String parentCode;

    @Column(name = "sort_order", nullable = false)
    private int sortOrder;

    @Column(nullable = false)
    private boolean active = true;
}
