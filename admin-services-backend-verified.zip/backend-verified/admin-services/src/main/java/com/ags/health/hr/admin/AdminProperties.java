package com.ags.health.hr.admin;

import org.springframework.boot.context.properties.ConfigurationProperties;

import java.util.List;

@ConfigurationProperties(prefix = "digihire.admin")
public record AdminProperties(List<String> bootstrapAdminEmails,
                              AccessRequests accessRequests,
                              Audit audit) {

    public AdminProperties {
        bootstrapAdminEmails = bootstrapAdminEmails == null ? List.of() : bootstrapAdminEmails;
        accessRequests = accessRequests == null ? new AccessRequests(7, 90, true) : accessRequests;
        audit = audit == null ? new Audit(730, "0 30 2 * * *", 50_000) : audit;
    }

    public record AccessRequests(int defaultValidityDays, int maxValidityDays, boolean approverMustBeInChain) {
    }

    public record Audit(int retentionDays, String purgeCron, int maxExportRows) {
    }
}
