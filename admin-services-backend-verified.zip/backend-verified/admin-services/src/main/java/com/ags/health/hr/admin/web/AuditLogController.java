package com.ags.health.hr.admin.web;

import com.ags.health.hr.admin.service.AuditQueryService;
import com.ags.health.hr.admin.service.AuditQueryService.AuditQuery;
import com.ags.health.hr.admin.service.AuditQueryService.AuditRow;
import com.ags.health.hr.admin.web.AdminDtos.PageResponse;
import com.ags.health.hr.platform.audit.AuditCategory;
import com.ags.health.hr.platform.audit.AuditEvent;
import com.ags.health.hr.platform.audit.AuditLogger;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.io.IOException;
import java.time.Instant;
import java.util.List;

/**
 * Centralized log viewer for Admin (tracker #14): timestamp, approval, workflow transition and activity logs
 * from all services in one searchable place.
 */
@RestController
@RequestMapping("/admin/audit-logs")
@Tag(name = "Central log viewer")
public class AuditLogController {

    private final AuditQueryService service;
    private final AuditLogger audit;

    public AuditLogController(AuditQueryService service, AuditLogger audit) {
        this.service = service;
        this.audit = audit;
    }

    @GetMapping
    @PreAuthorize("hasAuthority('AUDIT_LOG:VIEW')")
    @Operation(summary = "Search logs. category may repeat: ACTIVITY, APPROVAL, WORKFLOW_TRANSITION, CONFIG_CHANGE, SECURITY, NOTIFICATION")
    public PageResponse<AuditRow> search(@RequestParam(required = false) List<String> category,
                                         @RequestParam(required = false) String action,
                                         @RequestParam(required = false) String actor,
                                         @RequestParam(required = false) String entityType,
                                         @RequestParam(required = false) String entityId,
                                         @RequestParam(required = false) String candidateId,
                                         @RequestParam(required = false) String service,
                                         @RequestParam(required = false) String outcome,
                                         @RequestParam(required = false) String correlationId,
                                         @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) Instant from,
                                         @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) Instant to,
                                         @RequestParam(required = false) String q,
                                         @RequestParam(defaultValue = "0") int page,
                                         @RequestParam(defaultValue = "50") int size) {
        return this.service.search(new AuditQuery(category, action, actor, entityType, entityId, candidateId, service,
                outcome, correlationId, from, to, q), page, size);
    }

    @GetMapping("/candidates/{candidateId}")
    @PreAuthorize("hasAuthority('AUDIT_LOG:VIEW')")
    @Operation(summary = "Candidate audit timeline (workflow moves, emails sent, approvals)")
    public List<AuditRow> candidate(@PathVariable String candidateId) {
        return service.candidateTimeline(candidateId);
    }

    @GetMapping(value = "/export", produces = "text/csv")
    @PreAuthorize("hasAuthority('AUDIT_LOG:EXPORT')")
    public void export(@RequestParam(required = false) List<String> category,
                       @RequestParam(required = false) String actor,
                       @RequestParam(required = false) String entityType,
                       @RequestParam(required = false) String entityId,
                       @RequestParam(required = false) String candidateId,
                       @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) Instant from,
                       @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) Instant to,
                       HttpServletResponse response) throws IOException {
        response.setContentType("text/csv");
        response.setCharacterEncoding("UTF-8");
        response.setHeader("Content-Disposition", "attachment; filename=\"digihire-audit-log.csv\"");
        AuditQuery query = new AuditQuery(category, null, actor, entityType, entityId, candidateId, null, null, null,
                from, to, null);
        audit.log(AuditEvent.builder(AuditCategory.SECURITY, "AUDIT_LOG_EXPORTED").detail("filter", query.toString()).build());
        service.exportCsv(query, response.getWriter());
    }
}
