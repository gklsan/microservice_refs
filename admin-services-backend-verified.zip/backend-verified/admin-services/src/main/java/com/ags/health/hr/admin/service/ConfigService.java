package com.ags.health.hr.admin.service;

import com.ags.health.hr.admin.domain.EnterpriseConfig;
import com.ags.health.hr.admin.repo.EnterpriseConfigRepository;
import com.ags.health.hr.admin.web.AdminDtos.ConfigCreateRequest;
import com.ags.health.hr.admin.web.AdminDtos.ConfigResponse;
import com.ags.health.hr.admin.web.AdminDtos.ConfigUpdateRequest;
import com.ags.health.hr.platform.audit.AuditCategory;
import com.ags.health.hr.platform.audit.AuditEvent;
import com.ags.health.hr.platform.audit.AuditLogger;
import com.ags.health.hr.platform.web.ApiException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.List;

/** Enterprise-level configuration; writes are restricted to ADMIN at the controller (tracker #32). */
@Service
@Transactional
public class ConfigService {

    private final EnterpriseConfigRepository repo;
    private final ObjectMapper objectMapper;
    private final AuditLogger audit;

    public ConfigService(EnterpriseConfigRepository repo, ObjectMapper objectMapper, AuditLogger audit) {
        this.repo = repo;
        this.objectMapper = objectMapper;
        this.audit = audit;
    }

    @Transactional(readOnly = true)
    public List<ConfigResponse> list(String category) {
        List<EnterpriseConfig> rows = category == null ? repo.findAllByOrderByCategoryAscKeyAsc()
                : repo.findByCategoryOrderByKeyAsc(category);
        return rows.stream().map(ConfigResponse::of).toList();
    }

    @Transactional(readOnly = true)
    public ConfigResponse get(String key) {
        return ConfigResponse.of(find(key));
    }

    public ConfigResponse create(ConfigCreateRequest req) {
        if (repo.existsById(req.key())) {
            throw ApiException.conflict("CONFIG_EXISTS", "Configuration already exists: " + req.key());
        }
        validate(req.valueType(), req.value());
        EnterpriseConfig c = new EnterpriseConfig();
        c.setKey(req.key());
        c.setValue(req.value());
        c.setValueType(req.valueType());
        c.setCategory(req.category());
        c.setDescription(req.description());
        repo.save(c);
        audit.log(AuditEvent.builder(AuditCategory.CONFIG_CHANGE, "ENTERPRISE_CONFIG_CREATED")
                .entity("CONFIG", c.getKey()).detail("value", c.getValue()).build());
        return ConfigResponse.of(c);
    }

    public ConfigResponse update(String key, ConfigUpdateRequest req) {
        EnterpriseConfig c = find(key);
        validate(c.getValueType(), req.value());
        String before = c.getValue();
        c.setValue(req.value());
        if (req.description() != null) {
            c.setDescription(req.description());
        }
        audit.log(AuditEvent.builder(AuditCategory.CONFIG_CHANGE, "ENTERPRISE_CONFIG_UPDATED")
                .entity("CONFIG", key).detail("before", before).detail("after", req.value()).build());
        return ConfigResponse.of(c);
    }

    private EnterpriseConfig find(String key) {
        return repo.findById(key).orElseThrow(() -> ApiException.notFound("Configuration", key));
    }

    /** Type check so services reading the value never break at runtime. */
    void validate(EnterpriseConfig.ValueType type, String value) {
        try {
            switch (type) {
                case NUMBER -> new BigDecimal(value.trim());
                case BOOLEAN -> {
                    if (!"true".equalsIgnoreCase(value) && !"false".equalsIgnoreCase(value)) {
                        throw new IllegalArgumentException("expected true/false");
                    }
                }
                case JSON -> objectMapper.readTree(value);
                case LIST -> {
                    JsonNode node = objectMapper.readTree(value);
                    if (!node.isArray()) {
                        throw new IllegalArgumentException("expected a JSON array, e.g. [7,30,180]");
                    }
                }
                case STRING -> { }
            }
        } catch (Exception e) {
            throw ApiException.badRequest("INVALID_CONFIG_VALUE", "Value is not a valid " + type + ": " + e.getMessage());
        }
    }
}
