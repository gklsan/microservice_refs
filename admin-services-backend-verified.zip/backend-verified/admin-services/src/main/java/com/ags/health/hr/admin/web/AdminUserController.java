package com.ags.health.hr.admin.web;

import com.ags.health.hr.admin.domain.AppUser;
import com.ags.health.hr.admin.service.UserAdminService;
import com.ags.health.hr.admin.web.AdminDtos.AssignRolesRequest;
import com.ags.health.hr.admin.web.AdminDtos.CreateUserRequest;
import com.ags.health.hr.admin.web.AdminDtos.PageResponse;
import com.ags.health.hr.admin.web.AdminDtos.RemarksRequest;
import com.ags.health.hr.admin.web.AdminDtos.UpdateUserRequest;
import com.ags.health.hr.admin.web.AdminDtos.UserPermissionsRequest;
import com.ags.health.hr.admin.web.AdminDtos.UserResponse;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import java.util.UUID;

/** Admin user accounts (tracker #22 create, #23 list/search/deactivate/reactivate, #24 granular permissions). */
@RestController
@RequestMapping("/admin/users")
@Tag(name = "Admin users")
public class AdminUserController {

    private final UserAdminService service;

    public AdminUserController(UserAdminService service) {
        this.service = service;
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    @PreAuthorize("hasAuthority('USER:MANAGE')")
    @Operation(summary = "Create an admin-module user with roles, LOB/location scope and reporting manager")
    public UserResponse create(@Valid @RequestBody CreateUserRequest req) {
        return service.create(req);
    }

    @GetMapping
    @PreAuthorize("hasAuthority('USER:VIEW')")
    @Operation(summary = "Search users by name / email / employee code, status and role")
    public PageResponse<UserResponse> search(@RequestParam(required = false) String search,
                                             @RequestParam(required = false) AppUser.Status status,
                                             @RequestParam(required = false) String role,
                                             @RequestParam(defaultValue = "0") int page,
                                             @RequestParam(defaultValue = "20") int size) {
        return service.search(search, status, role,
                PageRequest.of(Math.max(page, 0), Math.min(Math.max(size, 1), 100), Sort.by("fullName")));
    }

    @GetMapping("/{id}")
    @PreAuthorize("hasAuthority('USER:VIEW')")
    public UserResponse get(@PathVariable UUID id) {
        return service.find(id);
    }

    @PutMapping("/{id}")
    @PreAuthorize("hasAuthority('USER:MANAGE')")
    public UserResponse update(@PathVariable UUID id, @Valid @RequestBody UpdateUserRequest req) {
        return service.update(id, req);
    }

    @PatchMapping("/{id}/deactivate")
    @PreAuthorize("hasAuthority('USER:MANAGE')")
    @Operation(summary = "Deactivate - user keeps logging in but loses every Phase 5 role/permission")
    public UserResponse deactivate(@PathVariable UUID id, @RequestBody(required = false) RemarksRequest req) {
        return service.deactivate(id, req == null ? null : req.remarks());
    }

    @PatchMapping("/{id}/reactivate")
    @PreAuthorize("hasAuthority('USER:MANAGE')")
    public UserResponse reactivate(@PathVariable UUID id, @RequestBody(required = false) RemarksRequest req) {
        return service.reactivate(id, req == null ? null : req.remarks());
    }

    @PutMapping("/{id}/roles")
    @PreAuthorize("hasAuthority('USER:MANAGE')")
    public UserResponse roles(@PathVariable UUID id, @Valid @RequestBody AssignRolesRequest req) {
        return service.assignRoles(id, req);
    }

    @PutMapping("/{id}/permissions")
    @PreAuthorize("hasAuthority('USER:MANAGE')")
    @Operation(summary = "Granular user-level ALLOW / DENY on top of role permissions")
    public UserResponse permissions(@PathVariable UUID id, @Valid @RequestBody UserPermissionsRequest req) {
        return service.setPermissions(id, req.grants());
    }
}
