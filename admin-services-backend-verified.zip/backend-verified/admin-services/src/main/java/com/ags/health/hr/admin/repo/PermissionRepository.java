package com.ags.health.hr.admin.repo;

import com.ags.health.hr.admin.domain.Permission;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Collection;
import java.util.List;
import java.util.UUID;

public interface PermissionRepository extends JpaRepository<Permission, UUID> {

    List<Permission> findByCodeIn(Collection<String> codes);

    List<Permission> findAllByOrderByObjectTypeAscActionAsc();
}
