package com.ags.health.hr.admin.repo;

import com.ags.health.hr.admin.domain.EnterpriseConfig;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface EnterpriseConfigRepository extends JpaRepository<EnterpriseConfig, String> {

    List<EnterpriseConfig> findByCategoryOrderByKeyAsc(String category);

    List<EnterpriseConfig> findAllByOrderByCategoryAscKeyAsc();
}
