package com.ags.health.hr.admin.service;

import com.ags.health.hr.admin.AdminProperties;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.stereotype.Component;

/** Guarantees the configured bootstrap administrators exist (BOOTSTRAP_ADMIN_EMAILS). */
@Component
public class BootstrapAdminRunner implements ApplicationRunner {

    private static final Logger log = LoggerFactory.getLogger(BootstrapAdminRunner.class);

    private final AdminProperties props;
    private final UserAdminService userAdminService;

    public BootstrapAdminRunner(AdminProperties props, UserAdminService userAdminService) {
        this.props = props;
        this.userAdminService = userAdminService;
    }

    @Override
    public void run(ApplicationArguments args) {
        props.bootstrapAdminEmails().stream()
                .filter(e -> e != null && !e.isBlank())
                .forEach(email -> {
                    try {
                        userAdminService.ensureAdmin(email);
                    } catch (RuntimeException ex) {
                        log.error("Could not bootstrap admin {}: {}", email, ex.getMessage());
                    }
                });
    }
}
