package com.ags.health.hr.admin.web;

import com.ags.health.hr.admin.domain.AccessRequest;
import com.ags.health.hr.admin.service.AccessRequestService;
import com.ags.health.hr.admin.web.AdminDtos.AccessRequestCreate;
import com.ags.health.hr.admin.web.AdminDtos.AccessRequestResponse;
import com.ags.health.hr.admin.web.AdminDtos.PageResponse;
import com.ags.health.hr.admin.web.AdminDtos.RemarksRequest;
import com.ags.health.hr.platform.security.CurrentUser;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import org.springframework.data.domain.PageRequest;
import org.springframework.http.HttpStatus;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import java.util.UUID;

/** Override / shared-candidate access requests and their approval (tracker #6, #8, #11). */
@RestController
@RequestMapping("/access-requests")
@Tag(name = "Access override requests")
public class AccessRequestController {

    private final AccessRequestService service;

    public AccessRequestController(AccessRequestService service) {
        this.service = service;
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    @PreAuthorize("hasAuthority('ACCESS_OVERRIDE:REQUEST')")
    @Operation(summary = "Request access to one record (objectId) or a temporary permission (permissionCode)")
    public AccessRequestResponse create(@AuthenticationPrincipal CurrentUser user,
                                        @Valid @RequestBody AccessRequestCreate req) {
        return service.create(user, req);
    }

    @GetMapping("/mine")
    public PageResponse<AccessRequestResponse> mine(@AuthenticationPrincipal CurrentUser user,
                                                    @RequestParam(defaultValue = "0") int page,
                                                    @RequestParam(defaultValue = "20") int size) {
        return service.mine(user, PageRequest.of(Math.max(page, 0), Math.min(Math.max(size, 1), 100)));
    }

    @GetMapping
    @PreAuthorize("hasAuthority('ACCESS_OVERRIDE:APPROVE')")
    @Operation(summary = "Approver inbox (default PENDING)")
    public PageResponse<AccessRequestResponse> byStatus(@RequestParam(defaultValue = "PENDING") AccessRequest.Status status,
                                                        @RequestParam(defaultValue = "0") int page,
                                                        @RequestParam(defaultValue = "20") int size) {
        return service.byStatus(status, PageRequest.of(Math.max(page, 0), Math.min(Math.max(size, 1), 100)));
    }

    @PostMapping("/{id}/approve")
    @PreAuthorize("hasAuthority('ACCESS_OVERRIDE:APPROVE')")
    public AccessRequestResponse approve(@AuthenticationPrincipal CurrentUser user, @PathVariable UUID id,
                                         @RequestBody(required = false) RemarksRequest req) {
        return service.approve(id, user, req == null ? null : req.remarks());
    }

    @PostMapping("/{id}/reject")
    @PreAuthorize("hasAuthority('ACCESS_OVERRIDE:APPROVE')")
    public AccessRequestResponse reject(@AuthenticationPrincipal CurrentUser user, @PathVariable UUID id,
                                        @RequestBody(required = false) RemarksRequest req) {
        return service.reject(id, user, req == null ? null : req.remarks());
    }

    @PostMapping("/{id}/revoke")
    public AccessRequestResponse revoke(@AuthenticationPrincipal CurrentUser user, @PathVariable UUID id,
                                        @RequestBody(required = false) RemarksRequest req) {
        return service.revoke(id, user, req == null ? null : req.remarks());
    }
}
