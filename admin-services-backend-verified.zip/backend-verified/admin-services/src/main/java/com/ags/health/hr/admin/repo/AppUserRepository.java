package com.ags.health.hr.admin.repo;

import com.ags.health.hr.admin.domain.AppUser;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.EntityGraph;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

public interface AppUserRepository extends JpaRepository<AppUser, UUID> {

    /*
     * PATCHED (gap analysis, see design doc): AppUser.roles is @ManyToMany(EAGER) but carries no fetch
     * hint for the nested Role.permissions collection, which is plain LAZY. AccessService.resolve() —
     * called on every authenticated request into admin-services, and by every other service's
     * HttpAccessClient on a cache miss — iterates every active role's permissions, so without this
     * entity graph each call to these two finders costs one extra query per role the user holds
     * (classic N+1). The nested "roles.permissions" path fetches both collections in one round trip;
     * permissionGrants/scopes are pulled in too since AccessService reads them unconditionally.
     */
    @EntityGraph(attributePaths = {"roles", "roles.permissions", "permissionGrants", "scopes"})
    Optional<AppUser> findBySmartieUserId(UUID smartieUserId);

    @EntityGraph(attributePaths = {"roles", "roles.permissions", "permissionGrants", "scopes"})
    Optional<AppUser> findByEmailIgnoreCase(String email);

    @Query("""
            select distinct u from AppUser u left join u.roles r
            where (:search is null
                   or lower(u.fullName) like lower(concat('%', cast(:search as string), '%'))
                   or lower(u.email) like lower(concat('%', cast(:search as string), '%'))
                   or lower(u.employeeCode) like lower(concat('%', cast(:search as string), '%')))
              and (:status is null or u.status = :status)
              and (:roleCode is null or r.code = :roleCode)
            """)
    Page<AppUser> search(@Param("search") String search,
                         @Param("status") AppUser.Status status,
                         @Param("roleCode") String roleCode,
                         Pageable pageable);

    @Query("select count(distinct u) from AppUser u join u.roles r where r.code = :roleCode and u.status = :status")
    long countByRoleAndStatus(@Param("roleCode") String roleCode, @Param("status") AppUser.Status status);

    @Query("select distinct u from AppUser u join u.roles r where r.code = :roleCode and u.status = :status order by u.fullName")
    List<AppUser> findByRoleAndStatus(@Param("roleCode") String roleCode, @Param("status") AppUser.Status status);

    /** All direct and indirect reports (smartie user ids) of a manager - TL / Manager team visibility. */
    @Query(value = """
            WITH RECURSIVE team AS (
                SELECT id, smartie_user_id FROM dh_admin.app_user WHERE manager_id = :managerId
                UNION
                SELECT u.id, u.smartie_user_id FROM dh_admin.app_user u JOIN team t ON u.manager_id = t.id
            )
            SELECT CAST(smartie_user_id AS VARCHAR) FROM team WHERE smartie_user_id IS NOT NULL
            """, nativeQuery = true)
    List<String> findTeamSmartieUserIds(@Param("managerId") UUID managerId);

    /** Manager chain (upwards) of a user - used to check the approver of an access request. */
    @Query(value = """
            WITH RECURSIVE chain AS (
                SELECT id, manager_id FROM dh_admin.app_user WHERE id = :userId
                UNION
                SELECT u.id, u.manager_id FROM dh_admin.app_user u JOIN chain c ON u.id = c.manager_id
            )
            SELECT CAST(id AS VARCHAR) FROM chain WHERE id <> :userId
            """, nativeQuery = true)
    List<String> findManagerChainIds(@Param("userId") UUID userId);
}
