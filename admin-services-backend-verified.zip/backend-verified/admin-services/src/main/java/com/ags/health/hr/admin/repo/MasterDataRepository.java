package com.ags.health.hr.admin.repo;

import com.ags.health.hr.admin.domain.MasterData;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

public interface MasterDataRepository extends JpaRepository<MasterData, UUID> {

    List<MasterData> findByCategoryAndActiveTrueOrderBySortOrderAscLabelAsc(String category);

    List<MasterData> findByCategoryOrderBySortOrderAscLabelAsc(String category);

    Optional<MasterData> findByCategoryAndCode(String category, String code);
}
