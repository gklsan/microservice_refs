package com.ags.health.hr.admin.service;

import com.ags.health.hr.admin.domain.Permission;
import com.ags.health.hr.admin.domain.Role;
import com.ags.health.hr.admin.repo.PermissionRepository;
import com.ags.health.hr.admin.repo.RoleRepository;
import com.ags.health.hr.admin.web.AdminDtos.MatrixResponse;
import com.ags.health.hr.admin.web.AdminDtos.PermissionResponse;
import com.ags.health.hr.admin.web.AdminDtos.RoleRequest;
import com.ags.health.hr.admin.web.AdminDtos.RoleResponse;
import com.ags.health.hr.platform.audit.AuditCategory;
import com.ags.health.hr.platform.audit.AuditEvent;
import com.ags.health.hr.platform.audit.AuditLogger;
import com.ags.health.hr.platform.web.ApiException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Collection;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import java.util.TreeSet;
import java.util.stream.Collectors;

/** Roles, default permission sets and the role-to-permission matrix (tracker #1-3, #25). */
@Service
@Transactional
public class RoleService {

    /** Permissions the ADMIN role can never lose - prevents locking everyone out of the Admin module. */
    static final Set<String> ADMIN_LOCKED = Set.of("ROLE:MANAGE", "USER:MANAGE", "CONFIG:MANAGE", "ROLE:VIEW", "USER:VIEW");

    private final RoleRepository roles;
    private final PermissionRepository permissions;
    private final JdbcTemplate jdbc;
    private final AuditLogger audit;

    public RoleService(RoleRepository roles, PermissionRepository permissions, JdbcTemplate jdbc, AuditLogger audit) {
        this.roles = roles;
        this.permissions = permissions;
        this.jdbc = jdbc;
        this.audit = audit;
    }

    @Transactional(readOnly = true)
    public List<RoleResponse> list() {
        return roles.findAllByOrderByCodeAsc().stream().map(RoleResponse::of).toList();
    }

    @Transactional(readOnly = true)
    public RoleResponse get(String code) {
        return RoleResponse.of(role(code));
    }

    @Transactional(readOnly = true)
    public List<PermissionResponse> permissionCatalogue() {
        return permissions.findAllByOrderByObjectTypeAscActionAsc().stream().map(PermissionResponse::of).toList();
    }

    public RoleResponse create(RoleRequest req) {
        if (Set.of("INTERNAL", "SYSTEM").contains(req.code())) {
            throw ApiException.badRequest("RESERVED_ROLE", "Role code " + req.code() + " is reserved for service-to-service calls");
        }
        if (roles.findByCode(req.code()).isPresent()) {
            throw ApiException.conflict("ROLE_EXISTS", "Role already exists: " + req.code());
        }
        Role r = Role.create(req.code(), req.name());
        apply(r, req);
        roles.save(r);
        audit.log(AuditEvent.builder(AuditCategory.CONFIG_CHANGE, "ROLE_CREATED").entity("ROLE", r.getCode())
                .detail("permissions", codes(r)).build());
        return RoleResponse.of(r);
    }

    public RoleResponse update(String code, RoleRequest req) {
        Role r = role(code);
        Set<String> before = codes(r);
        apply(r, req);
        if ("ADMIN".equals(code) && !r.isActive()) {
            throw ApiException.badRequest("ADMIN_ROLE_LOCKED", "The ADMIN role cannot be deactivated");
        }
        audit.log(AuditEvent.builder(AuditCategory.CONFIG_CHANGE, "ROLE_UPDATED").entity("ROLE", code)
                .detail("before", before).detail("after", codes(r)).detail("scopeLevel", r.getScopeLevel()).build());
        return RoleResponse.of(r);
    }

    @Transactional(readOnly = true)
    public MatrixResponse matrix() {
        List<Role> all = roles.findAllByOrderByCodeAsc();
        Map<String, Set<String>> grants = new LinkedHashMap<>();
        all.forEach(r -> grants.put(r.getCode(), codes(r)));
        return new MatrixResponse(all.stream().map(RoleResponse::of).toList(), permissionCatalogue(), grants);
    }

    /** Bulk save of the matrix screen: only roles present in the request are changed. */
    public MatrixResponse updateMatrix(Map<String, Set<String>> grants) {
        Map<String, Permission> catalogue = permissions.findAll().stream()
                .collect(Collectors.toMap(Permission::getCode, p -> p));
        Map<String, Object> diff = new TreeMap<>();
        grants.forEach((roleCode, codes) -> {
            Role r = role(roleCode);
            Set<String> before = codes(r);
            r.setPermissions(toPermissions(codes, catalogue));
            enforceAdminLock(r);
            Set<String> after = codes(r);
            if (!before.equals(after)) {
                Set<String> added = new TreeSet<>(after);
                added.removeAll(before);
                Set<String> removed = new TreeSet<>(before);
                removed.removeAll(after);
                diff.put(roleCode, Map.of("added", added, "removed", removed));
            }
        });
        if (!diff.isEmpty()) {
            audit.log(AuditEvent.builder(AuditCategory.CONFIG_CHANGE, "PERMISSION_MATRIX_UPDATED")
                    .entity("ROLE_MATRIX", "GLOBAL").details(diff).build());
        }
        return matrix();
    }

    /** Factory default permission set, optionally filtered by object (JOB / CANDIDATE / APPLICATION ...). */
    @Transactional(readOnly = true)
    public Map<String, Set<String>> defaultPermissionSets(String objectType) {
        String sql = "SELECT role_code, permission_code FROM dh_admin.default_role_permission"
                + (objectType == null ? "" : " WHERE permission_code LIKE ?") + " ORDER BY role_code, permission_code";
        Map<String, Set<String>> result = new TreeMap<>();
        Object[] args = objectType == null ? new Object[0] : new Object[]{objectType.toUpperCase() + ":%"};
        jdbc.query(sql, rs -> {
            result.computeIfAbsent(rs.getString(1), k -> new TreeSet<>()).add(rs.getString(2));
        }, args);
        return result;
    }

    /** Restore a role's permissions to the factory defaults. */
    public RoleResponse resetToDefaults(String code) {
        Role r = role(code);
        Set<String> defaults = defaultPermissionSets(null).getOrDefault(code, Set.of());
        if (defaults.isEmpty()) {
            throw ApiException.badRequest("NO_DEFAULTS", "Role " + code + " has no factory default permission set");
        }
        Set<String> before = codes(r);
        r.setPermissions(new HashSet<>(permissions.findByCodeIn(defaults)));
        audit.log(AuditEvent.builder(AuditCategory.CONFIG_CHANGE, "ROLE_RESET_TO_DEFAULTS").entity("ROLE", code)
                .detail("before", before).detail("after", codes(r)).build());
        return RoleResponse.of(r);
    }

    private void apply(Role r, RoleRequest req) {
        r.setName(req.name());
        r.setDescription(req.description());
        r.setScopeLevel(req.scopeLevel());
        if (req.active() != null) {
            r.setActive(req.active());
        }
        if (req.permissions() != null) {
            Map<String, Permission> catalogue = permissions.findAll().stream()
                    .collect(Collectors.toMap(Permission::getCode, p -> p));
            r.setPermissions(toPermissions(req.permissions(), catalogue));
        }
        enforceAdminLock(r);
    }

    private void enforceAdminLock(Role r) {
        if ("ADMIN".equals(r.getCode())) {
            Set<String> have = codes(r);
            if (!have.containsAll(ADMIN_LOCKED)) {
                throw ApiException.badRequest("ADMIN_ROLE_LOCKED", "ADMIN must keep " + ADMIN_LOCKED);
            }
        }
    }

    private static Set<Permission> toPermissions(Collection<String> codes, Map<String, Permission> catalogue) {
        Set<Permission> result = new HashSet<>();
        for (String c : codes) {
            Permission p = catalogue.get(c);
            if (p == null) {
                throw ApiException.badRequest("UNKNOWN_PERMISSION", "Unknown permission: " + c);
            }
            result.add(p);
        }
        return result;
    }

    private Role role(String code) {
        return roles.findByCode(code).orElseThrow(() -> ApiException.notFound("Role", code));
    }

    private static Set<String> codes(Role r) {
        return r.getPermissions().stream().map(Permission::getCode).collect(Collectors.toCollection(TreeSet::new));
    }
}
