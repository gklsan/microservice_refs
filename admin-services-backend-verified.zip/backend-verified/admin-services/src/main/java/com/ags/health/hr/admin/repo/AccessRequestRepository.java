package com.ags.health.hr.admin.repo;

import com.ags.health.hr.admin.domain.AccessRequest;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.time.Instant;
import java.util.Collection;
import java.util.List;
import java.util.UUID;

public interface AccessRequestRepository extends JpaRepository<AccessRequest, UUID> {

    @Query("select a from AccessRequest a where a.requesterId in :requesterIds and a.status = :status and a.validUntil > :now")
    List<AccessRequest> findEffective(@Param("requesterIds") Collection<String> requesterIds,
                                      @Param("status") AccessRequest.Status status,
                                      @Param("now") Instant now);

    Page<AccessRequest> findByRequesterIdOrderByCreatedAtDesc(String requesterId, Pageable pageable);

    Page<AccessRequest> findByStatusOrderByCreatedAtDesc(AccessRequest.Status status, Pageable pageable);
}
