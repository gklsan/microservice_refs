package com.ags.health.hr.admin.service;

import com.ags.health.hr.admin.domain.AppUser;
import com.ags.health.hr.admin.domain.MasterData;
import com.ags.health.hr.admin.domain.SearchFilter;
import com.ags.health.hr.admin.repo.AppUserRepository;
import com.ags.health.hr.admin.repo.MasterDataRepository;
import com.ags.health.hr.admin.repo.SearchFilterRepository;
import com.ags.health.hr.admin.web.AdminDtos.FilterDefinition;
import com.ags.health.hr.admin.web.AdminDtos.FilterOption;
import com.ags.health.hr.admin.web.AdminDtos.MasterDataRequest;
import com.ags.health.hr.admin.web.AdminDtos.MasterDataResponse;
import com.ags.health.hr.admin.web.AdminDtos.SearchFilterRequest;
import com.ags.health.hr.admin.web.AdminDtos.SearchFilterResponse;
import com.ags.health.hr.platform.audit.AuditCategory;
import com.ags.health.hr.platform.audit.AuditEvent;
import com.ags.health.hr.platform.audit.AuditLogger;
import com.ags.health.hr.platform.security.CurrentUser;
import com.ags.health.hr.platform.security.DataScope;
import com.ags.health.hr.platform.web.ApiException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Set;
import java.util.UUID;

/**
 * Role-driven dynamic search filters (tracker #4) and master data (LOB / location / reasons).
 * Filter rows are pure configuration: which filters a screen shows, to which roles, and where options come from.
 */
@Service
@Transactional
public class LookupService {

    private final SearchFilterRepository filters;
    private final MasterDataRepository masterData;
    private final AppUserRepository users;
    private final ObjectMapper objectMapper;
    private final AuditLogger audit;

    public LookupService(SearchFilterRepository filters, MasterDataRepository masterData, AppUserRepository users,
                         ObjectMapper objectMapper, AuditLogger audit) {
        this.filters = filters;
        this.masterData = masterData;
        this.users = users;
        this.objectMapper = objectMapper;
        this.audit = audit;
    }

    /** Filters of a screen for the current user, with options resolved and restricted to his scope. */
    @Transactional(readOnly = true)
    public List<FilterDefinition> filtersFor(String screen, CurrentUser user) {
        return filters.findByScreenAndActiveTrueOrderBySortOrderAsc(screen).stream()
                .filter(f -> f.visibleFor(user.roles()))
                .map(f -> toDefinition(f, user))
                .toList();
    }

    private FilterDefinition toDefinition(SearchFilter f, CurrentUser user) {
        String source = f.getOptionsSource();
        List<FilterOption> options = List.of();
        String endpoint = null;
        if (source != null) {
            if (source.equals("STATIC")) {
                options = parseStatic(f.getStaticOptions());
            } else if (source.startsWith("MASTER_DATA:")) {
                String category = source.substring("MASTER_DATA:".length());
                options = masterData.findByCategoryAndActiveTrueOrderBySortOrderAscLabelAsc(category).stream()
                        .map(m -> new FilterOption(m.getCode(), m.getLabel())).toList();
                if (f.isRestrictToScope()) {
                    options = restrict(options, category, user.scope());
                }
            } else if (source.startsWith("USERS:")) {
                options = users.findByRoleAndStatus(source.substring("USERS:".length()), AppUser.Status.ACTIVE).stream()
                        .filter(u -> u.getSmartieUserId() != null)
                        .map(u -> new FilterOption(u.getSmartieUserId().toString(), u.getFullName())).toList();
            } else if (source.startsWith("WORKFLOW_STATES:")) {
                endpoint = "/workflow-services/workflows/" + source.substring("WORKFLOW_STATES:".length()) + "/states";
            }
        }
        return new FilterDefinition(f.getFilterKey(), f.getLabel(), f.getFilterType(), options, endpoint, f.getSortOrder());
    }

    private List<FilterOption> restrict(List<FilterOption> options, String category, DataScope scope) {
        if (scope.level() == DataScope.Level.ALL) {
            return options;
        }
        Set<String> allowed = switch (category) {
            case "LOB" -> scope.lobs();
            case "LOCATION" -> scope.locations();
            default -> Set.of();
        };
        return allowed.isEmpty() ? options : options.stream().filter(o -> allowed.contains(o.value())).toList();
    }

    private List<FilterOption> parseStatic(String json) {
        if (json == null || json.isBlank()) {
            return List.of();
        }
        try {
            return objectMapper.readValue(json, new TypeReference<List<FilterOption>>() { });
        } catch (Exception e) {
            return List.of();
        }
    }

    // ------------------------------------------------------------------ admin CRUD of filters
    @Transactional(readOnly = true)
    public List<SearchFilterResponse> listFilters(String screen) {
        List<SearchFilter> rows = screen == null ? filters.findAll() : filters.findByScreenOrderBySortOrderAsc(screen);
        return rows.stream().map(SearchFilterResponse::of).toList();
    }

    public SearchFilterResponse saveFilter(UUID id, SearchFilterRequest req) {
        if (req.staticOptions() != null && !req.staticOptions().isBlank()) {
            try {
                objectMapper.readValue(req.staticOptions(), new TypeReference<List<FilterOption>>() { });
            } catch (Exception e) {
                throw ApiException.badRequest("INVALID_OPTIONS", "staticOptions must be [{\"value\":..,\"label\":..}]");
            }
        }
        SearchFilter f = id == null ? new SearchFilter() : filters.findById(id)
                .orElseThrow(() -> ApiException.notFound("Search filter", id));
        if (id == null) {
            f.setId(UUID.randomUUID());
        }
        f.setScreen(req.screen());
        f.setFilterKey(req.filterKey());
        f.setLabel(req.label());
        f.setFilterType(req.filterType());
        f.setOptionsSource(req.optionsSource());
        f.setStaticOptions(req.staticOptions());
        f.setAllowedRoles(req.allowedRoles());
        f.setRestrictToScope(req.restrictToScope());
        f.setSortOrder(req.sortOrder());
        f.setActive(req.active() == null || req.active());
        filters.save(f);
        audit.log(AuditEvent.builder(AuditCategory.CONFIG_CHANGE, id == null ? "SEARCH_FILTER_CREATED" : "SEARCH_FILTER_UPDATED")
                .entity("SEARCH_FILTER", f.getId()).detail("screen", f.getScreen()).detail("key", f.getFilterKey())
                .detail("allowedRoles", f.getAllowedRoles()).build());
        return SearchFilterResponse.of(f);
    }

    // ------------------------------------------------------------------ master data
    @Transactional(readOnly = true)
    public List<MasterDataResponse> masterData(String category, boolean includeInactive) {
        List<MasterData> rows = includeInactive ? masterData.findByCategoryOrderBySortOrderAscLabelAsc(category)
                : masterData.findByCategoryAndActiveTrueOrderBySortOrderAscLabelAsc(category);
        return rows.stream().map(MasterDataResponse::of).toList();
    }

    public MasterDataResponse saveMasterData(String category, MasterDataRequest req) {
        String cat = category.toUpperCase();
        MasterData m = masterData.findByCategoryAndCode(cat, req.code()).orElseGet(() -> {
            MasterData created = new MasterData();
            created.setId(UUID.randomUUID());
            created.setCategory(cat);
            created.setCode(req.code());
            return created;
        });
        m.setLabel(req.label());
        m.setParentCode(req.parentCode());
        m.setSortOrder(req.sortOrder());
        m.setActive(req.active() == null || req.active());
        masterData.save(m);
        audit.log(AuditEvent.builder(AuditCategory.CONFIG_CHANGE, "MASTER_DATA_SAVED")
                .entity("MASTER_DATA", cat + ":" + m.getCode()).detail("label", m.getLabel())
                .detail("active", m.isActive()).build());
        return MasterDataResponse.of(m);
    }
}
