package com.ags.health.hr.admin.domain;

import com.ags.health.hr.platform.jpa.AuditableEntity;
import jakarta.persistence.CollectionTable;
import jakarta.persistence.Column;
import jakarta.persistence.ElementCollection;
import jakarta.persistence.Embeddable;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.FetchType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.JoinTable;
import jakarta.persistence.ManyToMany;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

/**
 * Internal user known to the Admin module (recruiters, TLs, managers, TA head, admins, panel).
 * Identity/login stays in auth-services (smartieuser); this row holds authorisation data only
 * and is linked by {@code smartieUserId} (back-filled on first request) or by email.
 */
@Entity
@Table(name = "app_user")
@Getter
@Setter
@NoArgsConstructor
public class AppUser extends AuditableEntity {

    public enum Status { ACTIVE, INACTIVE }

    public enum Effect { ALLOW, DENY }

    public enum Dimension { LOB, LOCATION }

    @Embeddable
    public record PermissionGrant(@Column(name = "permission_code", nullable = false) String permissionCode,
                                  @Enumerated(EnumType.STRING) @Column(name = "effect", nullable = false) Effect effect) {
    }

    @Embeddable
    public record ScopeValue(@Enumerated(EnumType.STRING) @Column(name = "dimension", nullable = false) Dimension dimension,
                             @Column(name = "value", nullable = false) String value) {
    }

    @Id
    private UUID id;

    @Column(name = "smartie_user_id", unique = true)
    private UUID smartieUserId;

    @Column(nullable = false, unique = true)
    private String email;

    @Column(name = "full_name", nullable = false)
    private String fullName;

    @Column(name = "employee_code")
    private String employeeCode;

    @Column(name = "user_type", nullable = false)
    private String userType = "EMPLOYEE_HR";

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private Status status = Status.ACTIVE;

    @Column(name = "manager_id")
    private UUID managerId;

    @ManyToMany(fetch = FetchType.EAGER)
    @JoinTable(name = "user_role",
            joinColumns = @JoinColumn(name = "user_id"),
            inverseJoinColumns = @JoinColumn(name = "role_id"))
    private Set<Role> roles = new HashSet<>();

    @ElementCollection(fetch = FetchType.EAGER)
    @CollectionTable(name = "user_permission", joinColumns = @JoinColumn(name = "user_id"))
    private Set<PermissionGrant> permissionGrants = new HashSet<>();

    @ElementCollection(fetch = FetchType.EAGER)
    @CollectionTable(name = "user_scope", joinColumns = @JoinColumn(name = "user_id"))
    private Set<ScopeValue> scopes = new HashSet<>();

    public static AppUser create(String email, String fullName) {
        AppUser u = new AppUser();
        u.id = UUID.randomUUID();
        u.email = email.trim().toLowerCase();
        u.fullName = fullName;
        return u;
    }

    public boolean isActive() {
        return status == Status.ACTIVE;
    }

    public boolean hasRole(String roleCode) {
        return roles.stream().anyMatch(r -> r.getCode().equals(roleCode));
    }
}
