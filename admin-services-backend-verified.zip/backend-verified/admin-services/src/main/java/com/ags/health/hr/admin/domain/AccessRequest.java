package com.ags.health.hr.admin.domain;

import com.ags.health.hr.platform.jpa.AuditableEntity;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.Instant;
import java.util.UUID;

/**
 * Request for access beyond the default permission set (BRD 4.3: "any override access should require
 * approver authorization"). Two flavours:
 * <ul>
 *   <li>objectId set    -> share ONE record (e.g. a candidate owned by another recruiter)</li>
 *   <li>permissionCode  -> temporary extra permission (e.g. APPLICATION:BULK_UPDATE for 3 days)</li>
 * </ul>
 */
@Entity
@Table(name = "access_request")
@Getter
@Setter
@NoArgsConstructor
public class AccessRequest extends AuditableEntity {

    public enum Status { PENDING, APPROVED, REJECTED, REVOKED }

    @Id
    private UUID id;

    @Column(name = "requester_id", nullable = false)
    private String requesterId;

    @Column(name = "requester_email")
    private String requesterEmail;

    @Column(name = "requester_name")
    private String requesterName;

    @Column(name = "object_type", nullable = false)
    private String objectType;

    @Column(name = "object_id")
    private String objectId;

    @Column(name = "permission_code")
    private String permissionCode;

    @Column(nullable = false)
    private String reason;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private Status status = Status.PENDING;

    @Column(name = "valid_days", nullable = false)
    private int validDays;

    @Column(name = "valid_until")
    private Instant validUntil;

    @Column(name = "approver_id")
    private String approverId;

    @Column(name = "approver_email")
    private String approverEmail;

    @Column(name = "decided_at")
    private Instant decidedAt;

    @Column(name = "decision_remarks")
    private String decisionRemarks;

    public boolean isEffective(Instant now) {
        return status == Status.APPROVED && validUntil != null && validUntil.isAfter(now);
    }
}
