package com.ags.health.hr.admin.service;

import com.ags.health.hr.admin.AdminProperties;
import com.ags.health.hr.admin.domain.AccessRequest;
import com.ags.health.hr.admin.domain.AppUser;
import com.ags.health.hr.admin.repo.AccessRequestRepository;
import com.ags.health.hr.admin.repo.AppUserRepository;
import com.ags.health.hr.admin.repo.PermissionRepository;
import com.ags.health.hr.admin.web.AdminDtos.AccessRequestCreate;
import com.ags.health.hr.admin.web.AdminDtos.AccessRequestResponse;
import com.ags.health.hr.admin.web.AdminDtos.PageResponse;
import com.ags.health.hr.platform.audit.AuditCategory;
import com.ags.health.hr.platform.audit.AuditEvent;
import com.ags.health.hr.platform.audit.AuditLogger;
import com.ags.health.hr.platform.security.CurrentUser;
import com.ags.health.hr.platform.security.DataScope;
import com.ags.health.hr.platform.web.ApiException;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import java.time.Duration;
import java.time.Instant;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

/**
 * Override / shared-record access with approver authorization (tracker #6 and #8, BRD 4.3).
 * Every step is written to the central log with category APPROVAL (tracker #11).
 */
@Service
@Transactional
public class AccessRequestService {

    private final AccessRequestRepository requests;
    private final AppUserRepository users;
    private final PermissionRepository permissions;
    private final AccessService accessService;
    private final AdminProperties props;
    private final AuditLogger audit;

    public AccessRequestService(AccessRequestRepository requests, AppUserRepository users,
                                PermissionRepository permissions, AccessService accessService,
                                AdminProperties props, AuditLogger audit) {
        this.requests = requests;
        this.users = users;
        this.permissions = permissions;
        this.accessService = accessService;
        this.props = props;
        this.audit = audit;
    }

    public AccessRequestResponse create(CurrentUser requester, AccessRequestCreate req) {
        if (!StringUtils.hasText(req.objectId()) && !StringUtils.hasText(req.permissionCode())) {
            throw ApiException.badRequest("TARGET_REQUIRED", "Either objectId or permissionCode is required");
        }
        if (StringUtils.hasText(req.permissionCode()) && permissions.findByCodeIn(List.of(req.permissionCode())).isEmpty()) {
            throw ApiException.badRequest("UNKNOWN_PERMISSION", "Unknown permission: " + req.permissionCode());
        }
        int days = req.validDays() == null ? props.accessRequests().defaultValidityDays() : req.validDays();
        if (days > props.accessRequests().maxValidityDays()) {
            throw ApiException.badRequest("VALIDITY_TOO_LONG",
                    "Maximum validity is " + props.accessRequests().maxValidityDays() + " days");
        }
        AccessRequest a = new AccessRequest();
        a.setId(UUID.randomUUID());
        a.setRequesterId(requester.userId());
        a.setRequesterEmail(requester.email());
        a.setRequesterName(requester.name());
        a.setObjectType(req.objectType());
        a.setObjectId(StringUtils.hasText(req.objectId()) ? req.objectId() : null);
        a.setPermissionCode(StringUtils.hasText(req.permissionCode()) ? req.permissionCode() : null);
        a.setReason(req.reason());
        a.setValidDays(days);
        requests.save(a);
        log("ACCESS_REQUESTED", a, null);
        return AccessRequestResponse.of(a);
    }

    public AccessRequestResponse approve(UUID id, CurrentUser approver, String remarks) {
        AccessRequest a = pending(id);
        checkApprover(a, approver);
        Instant now = Instant.now();
        a.setStatus(AccessRequest.Status.APPROVED);
        a.setApproverId(approver.userId());
        a.setApproverEmail(approver.email());
        a.setDecidedAt(now);
        a.setValidUntil(now.plus(Duration.ofDays(a.getValidDays())));
        a.setDecisionRemarks(remarks);
        log("ACCESS_APPROVED", a, remarks);
        return AccessRequestResponse.of(a);
    }

    public AccessRequestResponse reject(UUID id, CurrentUser approver, String remarks) {
        AccessRequest a = pending(id);
        checkApprover(a, approver);
        a.setStatus(AccessRequest.Status.REJECTED);
        a.setApproverId(approver.userId());
        a.setApproverEmail(approver.email());
        a.setDecidedAt(Instant.now());
        a.setDecisionRemarks(remarks);
        log("ACCESS_REJECTED", a, remarks);
        return AccessRequestResponse.of(a);
    }

    public AccessRequestResponse revoke(UUID id, CurrentUser actor, String remarks) {
        AccessRequest a = requests.findById(id).orElseThrow(() -> ApiException.notFound("Access request", id));
        boolean own = a.getRequesterId().equals(actor.userId());
        if (!own && !actor.hasPermission("ACCESS_OVERRIDE:APPROVE")) {
            throw ApiException.forbidden("Only the requester or an approver can revoke");
        }
        if (a.getStatus() != AccessRequest.Status.APPROVED && a.getStatus() != AccessRequest.Status.PENDING) {
            throw ApiException.conflict("NOT_REVOCABLE", "Request is " + a.getStatus());
        }
        a.setStatus(AccessRequest.Status.REVOKED);
        a.setDecisionRemarks(remarks);
        a.setDecidedAt(Instant.now());
        log("ACCESS_REVOKED", a, remarks);
        return AccessRequestResponse.of(a);
    }

    @Transactional(readOnly = true)
    public PageResponse<AccessRequestResponse> mine(CurrentUser user, Pageable pageable) {
        return PageResponse.of(requests.findByRequesterIdOrderByCreatedAtDesc(user.userId(), pageable)
                .map(AccessRequestResponse::of));
    }

    @Transactional(readOnly = true)
    public PageResponse<AccessRequestResponse> byStatus(AccessRequest.Status status, Pageable pageable) {
        return PageResponse.of(requests.findByStatusOrderByCreatedAtDesc(status, pageable).map(AccessRequestResponse::of));
    }

    /**
     * Approver must hold ACCESS_OVERRIDE:APPROVE, cannot approve his own request and - when configured -
     * must be in the requester's reporting chain unless he has ALL-level scope (TA Head / Admin).
     */
    private void checkApprover(AccessRequest a, CurrentUser approver) {
        if (!approver.hasPermission("ACCESS_OVERRIDE:APPROVE")) {
            throw ApiException.forbidden("Missing permission ACCESS_OVERRIDE:APPROVE");
        }
        if (a.getRequesterId().equals(approver.userId())) {
            throw ApiException.forbidden("You cannot approve your own request");
        }
        if (!props.accessRequests().approverMustBeInChain() || approver.scope().level() == DataScope.Level.ALL) {
            return;
        }
        Optional<AppUser> requester = accessService.findUser(a.getRequesterId(), a.getRequesterEmail());
        Optional<AppUser> approverUser = accessService.findUser(approver.userId(), approver.email());
        if (requester.isEmpty() || approverUser.isEmpty()
                || !users.findManagerChainIds(requester.get().getId()).contains(approverUser.get().getId().toString())) {
            throw ApiException.forbidden("Approver must be in the requester's reporting line");
        }
    }

    private AccessRequest pending(UUID id) {
        AccessRequest a = requests.findById(id).orElseThrow(() -> ApiException.notFound("Access request", id));
        if (a.getStatus() != AccessRequest.Status.PENDING) {
            throw ApiException.conflict("ALREADY_DECIDED", "Request is already " + a.getStatus());
        }
        return a;
    }

    private void log(String action, AccessRequest a, String remarks) {
        audit.log(AuditEvent.builder(AuditCategory.APPROVAL, action)
                .entity("ACCESS_REQUEST", a.getId())
                .candidate("CANDIDATE".equals(a.getObjectType()) ? a.getObjectId() : null)
                .detail("requester", a.getRequesterEmail())
                .detail("objectType", a.getObjectType())
                .detail("objectId", a.getObjectId())
                .detail("permission", a.getPermissionCode())
                .detail("reason", a.getReason())
                .detail("validUntil", a.getValidUntil() == null ? null : a.getValidUntil().toString())
                .detail("remarks", remarks)
                .build());
    }
}
