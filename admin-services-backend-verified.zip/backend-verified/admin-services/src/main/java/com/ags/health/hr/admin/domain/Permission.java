package com.ags.health.hr.admin.domain;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.NoArgsConstructor;

import java.util.UUID;

/** Catalogue entry OBJECT:ACTION (seeded by Flyway; new objects are added by migration, not by UI). */
@Entity
@Table(name = "permission")
@Getter
@NoArgsConstructor
public class Permission {

    @Id
    private UUID id;

    @Column(nullable = false, unique = true)
    private String code;

    @Column(name = "object_type", nullable = false)
    private String objectType;

    @Column(nullable = false)
    private String action;

    private String description;
}
