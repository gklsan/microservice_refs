package com.ags.health.hr.admin.web;

import com.ags.health.hr.admin.service.LookupService;
import com.ags.health.hr.admin.web.AdminDtos.MasterDataRequest;
import com.ags.health.hr.admin.web.AdminDtos.MasterDataResponse;
import com.ags.health.hr.admin.web.AdminDtos.SearchFilterRequest;
import com.ags.health.hr.admin.web.AdminDtos.SearchFilterResponse;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.UUID;

/** Master data (LOB, location, reasons ...) and search-filter configuration. */
@RestController
@Tag(name = "Master data & search filters")
public class LookupController {

    private final LookupService service;

    public LookupController(LookupService service) {
        this.service = service;
    }

    @GetMapping("/master-data/{category}")
    @Operation(summary = "Active values of a category: LOB, LOCATION, COUNTRY, SHIFT, JOB_TYPE, EXPERIENCE_BAND, SOURCE, REJECTION_REASON, HOLD_REASON, INTERVIEW_MODE")
    public List<MasterDataResponse> masterData(@PathVariable String category,
                                               @RequestParam(defaultValue = "false") boolean includeInactive) {
        return service.masterData(category.toUpperCase(), includeInactive);
    }

    @PostMapping("/admin/master-data/{category}")
    @PreAuthorize("hasAuthority('MASTER_DATA:MANAGE')")
    @Operation(summary = "Create or update (by code) a master data value")
    public MasterDataResponse saveMasterData(@PathVariable String category, @Valid @RequestBody MasterDataRequest req) {
        return service.saveMasterData(category, req);
    }

    @GetMapping("/admin/search-filters")
    @PreAuthorize("hasAuthority('CONFIG:VIEW')")
    public List<SearchFilterResponse> filters(@RequestParam(required = false) String screen) {
        return service.listFilters(screen == null ? null : screen.toUpperCase());
    }

    @PostMapping("/admin/search-filters")
    @PreAuthorize("hasRole('ADMIN') and hasAuthority('CONFIG:MANAGE')")
    public SearchFilterResponse createFilter(@Valid @RequestBody SearchFilterRequest req) {
        return service.saveFilter(null, req);
    }

    @PutMapping("/admin/search-filters/{id}")
    @PreAuthorize("hasRole('ADMIN') and hasAuthority('CONFIG:MANAGE')")
    public SearchFilterResponse updateFilter(@PathVariable UUID id, @Valid @RequestBody SearchFilterRequest req) {
        return service.saveFilter(id, req);
    }
}
