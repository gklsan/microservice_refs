package com.ags.health.hr.admin.web;

import com.ags.health.hr.admin.service.RoleService;
import com.ags.health.hr.admin.web.AdminDtos.MatrixResponse;
import com.ags.health.hr.admin.web.AdminDtos.MatrixUpdateRequest;
import com.ags.health.hr.admin.web.AdminDtos.PermissionResponse;
import com.ags.health.hr.admin.web.AdminDtos.RoleRequest;
import com.ags.health.hr.admin.web.AdminDtos.RoleResponse;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Roles, permission catalogue, default permission sets and the role-to-permission matrix.
 * Changing roles/matrix is restricted to the ADMIN role (BRD 4.1 "Admin should fully control role creation and
 * permission mapping").
 */
@RestController
@RequestMapping("/admin")
@Tag(name = "Roles & permission matrix")
public class RoleController {

    private final RoleService service;

    public RoleController(RoleService service) {
        this.service = service;
    }

    @GetMapping("/roles")
    @PreAuthorize("hasAuthority('ROLE:VIEW')")
    public List<RoleResponse> roles() {
        return service.list();
    }

    @GetMapping("/roles/{code}")
    @PreAuthorize("hasAuthority('ROLE:VIEW')")
    public RoleResponse role(@PathVariable String code) {
        return service.get(code);
    }

    @PostMapping("/roles")
    @ResponseStatus(HttpStatus.CREATED)
    @PreAuthorize("hasRole('ADMIN') and hasAuthority('ROLE:MANAGE')")
    public RoleResponse create(@Valid @RequestBody RoleRequest req) {
        return service.create(req);
    }

    @PutMapping("/roles/{code}")
    @PreAuthorize("hasRole('ADMIN') and hasAuthority('ROLE:MANAGE')")
    public RoleResponse update(@PathVariable String code, @Valid @RequestBody RoleRequest req) {
        return service.update(code, req);
    }

    @PostMapping("/roles/{code}/reset-defaults")
    @PreAuthorize("hasRole('ADMIN') and hasAuthority('ROLE:MANAGE')")
    @Operation(summary = "Restore a role to its factory default permission set")
    public RoleResponse reset(@PathVariable String code) {
        return service.resetToDefaults(code);
    }

    @GetMapping("/permissions")
    @PreAuthorize("hasAuthority('ROLE:VIEW')")
    @Operation(summary = "Permission catalogue (OBJECT:ACTION)")
    public List<PermissionResponse> permissions() {
        return service.permissionCatalogue();
    }

    @GetMapping("/permission-matrix")
    @PreAuthorize("hasAuthority('ROLE:VIEW')")
    @Operation(summary = "Role x permission grid for the matrix screen")
    public MatrixResponse matrix() {
        return service.matrix();
    }

    @PutMapping("/permission-matrix")
    @PreAuthorize("hasRole('ADMIN') and hasAuthority('ROLE:MANAGE')")
    @Operation(summary = "Save the matrix (only roles present in the body are changed)")
    public MatrixResponse saveMatrix(@Valid @RequestBody MatrixUpdateRequest req) {
        return service.updateMatrix(req.grants());
    }

    @GetMapping("/permission-sets/defaults")
    @PreAuthorize("hasAuthority('ROLE:VIEW')")
    @Operation(summary = "Factory default permission sets per role; objectType = JOB | CANDIDATE | APPLICATION ...")
    public Map<String, Set<String>> defaults(@RequestParam(required = false) String objectType) {
        return service.defaultPermissionSets(objectType);
    }
}
