package com.ags.health.hr.admin.web;

import com.ags.health.hr.admin.service.AccessService;
import com.ags.health.hr.admin.service.ConfigService;
import com.ags.health.hr.admin.service.UserAdminService;
import com.ags.health.hr.admin.web.AdminDtos.ConfigResponse;
import com.ags.health.hr.admin.web.AdminDtos.UserResponse;
import com.ags.health.hr.platform.security.EffectiveAccess;
import io.swagger.v3.oas.annotations.Hidden;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/** Service-to-service API (X-Internal-Key). Not routed by the gateway. */
@Hidden
@RestController
@RequestMapping("/internal")
public class InternalController {

    private final AccessService accessService;
    private final ConfigService configService;
    private final UserAdminService userAdminService;

    public InternalController(AccessService accessService, ConfigService configService, UserAdminService userAdminService) {
        this.accessService = accessService;
        this.configService = configService;
        this.userAdminService = userAdminService;
    }

    /** Used by digihire-platform-starter (HttpAccessClient) in every other service. */
    @GetMapping("/rbac/effective")
    public EffectiveAccess effective(@RequestParam(required = false) String userId,
                                     @RequestParam(required = false) String email,
                                     @RequestParam(required = false) String userType) {
        return accessService.resolve(userId, email, userType);
    }

    @GetMapping("/config")
    public List<ConfigResponse> config(@RequestParam(required = false) String category) {
        return configService.list(category);
    }

    @GetMapping("/config/{key}")
    public ConfigResponse configValue(@PathVariable String key) {
        return configService.get(key);
    }

    /** e.g. notification-engine resolving recipients by role. */
    @GetMapping("/users/by-role/{roleCode}")
    public List<UserResponse> usersByRole(@PathVariable String roleCode) {
        return userAdminService.byRole(roleCode);
    }
}
