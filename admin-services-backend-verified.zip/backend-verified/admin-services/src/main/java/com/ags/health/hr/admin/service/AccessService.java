package com.ags.health.hr.admin.service;

import com.ags.health.hr.admin.domain.AccessRequest;
import com.ags.health.hr.admin.domain.AppUser;
import com.ags.health.hr.admin.domain.Permission;
import com.ags.health.hr.admin.domain.Role;
import com.ags.health.hr.admin.repo.AccessRequestRepository;
import com.ags.health.hr.admin.repo.AppUserRepository;
import com.ags.health.hr.admin.repo.RoleRepository;
import com.ags.health.hr.platform.config.PlatformProperties;
import com.ags.health.hr.platform.security.AccessClient;
import com.ags.health.hr.platform.security.DataScope;
import com.ags.health.hr.platform.security.EffectiveAccess;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import java.time.Instant;
import java.util.Collection;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;
import java.util.stream.Collectors;

/**
 * The RBAC permission framework (tracker #1-8, #24, #25): computes roles, permissions and data scope.
 * <pre>
 * permissions = U(role permissions) + user ALLOW - user DENY + approved temporary permission overrides
 * scope level = widest scope of the user's active roles
 * team        = all direct/indirect reports (manager hierarchy)
 * shared      = records granted through approved access requests
 * </pre>
 * Users not configured in the Admin module get the default roles of their legacy userType.
 * This is the local {@link AccessClient} of admin-services; every other service calls it over HTTP.
 */
@Service
public class AccessService implements AccessClient {

    private final AppUserRepository users;
    private final RoleRepository roles;
    private final AccessRequestRepository accessRequests;
    private final PlatformProperties platformProperties;

    public AccessService(AppUserRepository users, RoleRepository roles, AccessRequestRepository accessRequests,
                         PlatformProperties platformProperties) {
        this.users = users;
        this.roles = roles;
        this.accessRequests = accessRequests;
        this.platformProperties = platformProperties;
    }

    @Override
    @Transactional
    public EffectiveAccess resolve(String rawUserId, String rawEmail, String rawUserType) {
        String userId = StringUtils.hasText(rawUserId) ? rawUserId : null;
        String email = StringUtils.hasText(rawEmail) ? rawEmail : null;
        String userType = StringUtils.hasText(rawUserType) ? rawUserType : null;
        Optional<AppUser> found = findUser(userId, email);
        if (found.isEmpty()) {
            List<String> fallback = platformProperties.getAccess().getFallbackRolesByUserType()
                    .getOrDefault(userType, List.of());
            List<Role> fallbackRoles = roles.findByCodeIn(fallback);
            return build(userId, email, true, fallbackRoles, Set.of(), Set.of(), Set.of(), Set.of(), null);
        }
        AppUser user = found.get();
        if (user.getSmartieUserId() == null && isUuid(userId)) {
            user.setSmartieUserId(UUID.fromString(userId)); // back-fill link on first login
        }
        String effectiveId = user.getSmartieUserId() != null ? user.getSmartieUserId().toString() : userId;
        Set<String> allow = grants(user, AppUser.Effect.ALLOW);
        Set<String> deny = grants(user, AppUser.Effect.DENY);
        Set<String> lobs = scopes(user, AppUser.Dimension.LOB);
        Set<String> locations = scopes(user, AppUser.Dimension.LOCATION);
        return build(effectiveId, user.getEmail(), user.isActive(), user.getRoles(), allow, deny, lobs, locations,
                user.getId());
    }

    @Transactional(readOnly = true)
    public Optional<AppUser> findUser(String userId, String email) {
        Optional<AppUser> user = Optional.empty();
        if (isUuid(userId)) {
            user = users.findBySmartieUserId(UUID.fromString(userId));
        }
        if (user.isEmpty() && StringUtils.hasText(email)) {
            user = users.findByEmailIgnoreCase(email.trim());
        }
        return user;
    }

    private EffectiveAccess build(String userId, String email, boolean active, Collection<Role> userRoles,
                                  Set<String> allow, Set<String> deny, Set<String> lobs, Set<String> locations,
                                  UUID appUserId) {
        List<Role> activeRoles = userRoles.stream().filter(Role::isActive).toList();
        Set<String> roleCodes = activeRoles.stream().map(Role::getCode).collect(Collectors.toSet());

        Set<String> permissions = activeRoles.stream()
                .flatMap(r -> r.getPermissions().stream())
                .map(Permission::getCode)
                .collect(Collectors.toCollection(HashSet::new));
        permissions.addAll(allow);

        Map<String, Set<String>> shared = new HashMap<>();
        if (userId != null) {
            for (AccessRequest ar : accessRequests.findEffective(List.of(userId), AccessRequest.Status.APPROVED, Instant.now())) {
                if (ar.getObjectId() != null) {
                    shared.computeIfAbsent(ar.getObjectType(), k -> new HashSet<>()).add(ar.getObjectId());
                } else if (ar.getPermissionCode() != null) {
                    permissions.add(ar.getPermissionCode());
                }
            }
        }
        permissions.removeAll(deny);

        DataScope.Level level = activeRoles.stream()
                .map(Role::getScopeLevel)
                .max(Comparator.naturalOrder())
                .orElse(DataScope.Level.NONE);
        Set<String> team = appUserId == null ? Set.of() : new HashSet<>(users.findTeamSmartieUserIds(appUserId));

        DataScope scope = new DataScope(level, userId, team, lobs, locations, shared);
        return new EffectiveAccess(userId, email, active, roleCodes, permissions, scope);
    }

    private static Set<String> grants(AppUser u, AppUser.Effect effect) {
        return u.getPermissionGrants().stream().filter(g -> g.effect() == effect)
                .map(AppUser.PermissionGrant::permissionCode).collect(Collectors.toSet());
    }

    private static Set<String> scopes(AppUser u, AppUser.Dimension d) {
        return u.getScopes().stream().filter(s -> s.dimension() == d)
                .map(AppUser.ScopeValue::value).collect(Collectors.toSet());
    }

    static boolean isUuid(String value) {
        if (value == null) {
            return false;
        }
        try {
            UUID.fromString(value);
            return true;
        } catch (IllegalArgumentException e) {
            return false;
        }
    }
}
