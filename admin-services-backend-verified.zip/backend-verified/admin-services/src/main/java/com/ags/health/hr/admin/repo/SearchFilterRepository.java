package com.ags.health.hr.admin.repo;

import com.ags.health.hr.admin.domain.SearchFilter;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.UUID;

public interface SearchFilterRepository extends JpaRepository<SearchFilter, UUID> {

    List<SearchFilter> findByScreenAndActiveTrueOrderBySortOrderAsc(String screen);

    List<SearchFilter> findByScreenOrderBySortOrderAsc(String screen);
}
