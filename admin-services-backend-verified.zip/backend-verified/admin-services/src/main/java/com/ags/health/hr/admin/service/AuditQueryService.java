package com.ags.health.hr.admin.service;

import com.ags.health.hr.admin.AdminProperties;
import com.ags.health.hr.admin.web.AdminDtos.PageResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import java.io.IOException;
import java.io.Writer;
import java.sql.Timestamp;
import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.List;

/**
 * Centralized log viewer for Admin (tracker #14) over the shared audit table, plus the retention purge
 * (retention policy DEP-S1-05 -> AUDIT_RETENTION_DAYS).
 */
@Service
public class AuditQueryService {

    private static final Logger log = LoggerFactory.getLogger(AuditQueryService.class);
    private static final String TABLE = "dh_audit.audit_log";

    private final NamedParameterJdbcTemplate jdbc;
    private final AdminProperties props;

    public AuditQueryService(NamedParameterJdbcTemplate jdbc, AdminProperties props) {
        this.jdbc = jdbc;
        this.props = props;
    }

    public record AuditRow(String id, String category, String action, String entityType, String entityId,
                           String candidateId, String actorId, String actorName, String actorEmail, String actorRoles,
                           String outcome, String description, String details, String correlationId,
                           String serviceName, String clientIp, Instant occurredAt) {
    }

    /** Every filter is optional. */
    public record AuditQuery(List<String> categories, String action, String actor, String entityType, String entityId,
                             String candidateId, String serviceName, String outcome, String correlationId,
                             Instant from, Instant to, String text) {
    }

    private static final RowMapper<AuditRow> MAPPER = (rs, i) -> new AuditRow(
            rs.getString("id"), rs.getString("category"), rs.getString("action"), rs.getString("entity_type"),
            rs.getString("entity_id"), rs.getString("candidate_id"), rs.getString("actor_id"),
            rs.getString("actor_name"), rs.getString("actor_email"), rs.getString("actor_roles"),
            rs.getString("outcome"), rs.getString("description"), rs.getString("details"),
            rs.getString("correlation_id"), rs.getString("service_name"), rs.getString("client_ip"),
            rs.getTimestamp("occurred_at").toInstant());

    public PageResponse<AuditRow> search(AuditQuery q, int page, int size) {
        int safeSize = Math.min(Math.max(size, 1), 200);
        int safePage = Math.max(page, 0);
        MapSqlParameterSource params = new MapSqlParameterSource();
        String where = where(q, params);
        Long total = jdbc.queryForObject("SELECT count(*) FROM " + TABLE + where, params, Long.class);
        params.addValue("limit", safeSize).addValue("offset", (long) safePage * safeSize);
        List<AuditRow> rows = jdbc.query("SELECT * FROM " + TABLE + where
                + " ORDER BY occurred_at DESC LIMIT :limit OFFSET :offset", params, MAPPER);
        long t = total == null ? 0 : total;
        return new PageResponse<>(rows, safePage, safeSize, t, (int) ((t + safeSize - 1) / safeSize));
    }

    /** Candidate audit timeline: every row mapped to the candidate (transitions, emails, approvals ...). */
    public List<AuditRow> candidateTimeline(String candidateId) {
        return jdbc.query("SELECT * FROM " + TABLE + " WHERE candidate_id = :cid ORDER BY occurred_at DESC LIMIT 1000",
                new MapSqlParameterSource("cid", candidateId), MAPPER);
    }

    public void exportCsv(AuditQuery q, Writer out) throws IOException {
        MapSqlParameterSource params = new MapSqlParameterSource();
        String where = where(q, params);
        params.addValue("limit", props.audit().maxExportRows());
        out.write("occurred_at,category,action,outcome,entity_type,entity_id,candidate_id,actor_name,actor_email,service,correlation_id,description\n");
        List<AuditRow> rows = jdbc.query("SELECT * FROM " + TABLE + where + " ORDER BY occurred_at DESC LIMIT :limit",
                params, MAPPER);
        for (AuditRow r : rows) {
            out.write(String.join(",", csv(r.occurredAt().toString()), csv(r.category()), csv(r.action()),
                    csv(r.outcome()), csv(r.entityType()), csv(r.entityId()), csv(r.candidateId()), csv(r.actorName()),
                    csv(r.actorEmail()), csv(r.serviceName()), csv(r.correlationId()), csv(r.description())));
            out.write("\n");
        }
        out.flush();
    }

    @Scheduled(cron = "${digihire.admin.audit.purge-cron:0 30 2 * * *}")
    public void purge() {
        Instant cutoff = Instant.now().minus(props.audit().retentionDays(), ChronoUnit.DAYS);
        int deleted;
        int total = 0;
        do { // small batches keep locks short
            deleted = jdbc.update("DELETE FROM " + TABLE + " WHERE id IN (SELECT id FROM " + TABLE
                    + " WHERE occurred_at < :cutoff LIMIT 5000)", new MapSqlParameterSource("cutoff", Timestamp.from(cutoff)));
            total += deleted;
        } while (deleted > 0);
        if (total > 0) {
            log.info("Audit retention purge removed {} rows older than {}", total, cutoff);
        }
    }

    private String where(AuditQuery q, MapSqlParameterSource p) {
        List<String> c = new ArrayList<>();
        if (q.categories() != null && !q.categories().isEmpty()) {
            c.add("category IN (:categories)");
            p.addValue("categories", q.categories());
        }
        eq(c, p, "action", q.action());
        eq(c, p, "entity_type", q.entityType());
        eq(c, p, "entity_id", q.entityId());
        eq(c, p, "candidate_id", q.candidateId());
        eq(c, p, "service_name", q.serviceName());
        eq(c, p, "outcome", q.outcome());
        eq(c, p, "correlation_id", q.correlationId());
        if (StringUtils.hasText(q.actor())) {
            c.add("(actor_id = :actor OR lower(actor_email) = lower(:actor) OR lower(actor_name) LIKE lower(:actorLike))");
            p.addValue("actor", q.actor()).addValue("actorLike", "%" + q.actor() + "%");
        }
        if (q.from() != null) {
            c.add("occurred_at >= :from");
            p.addValue("from", Timestamp.from(q.from()));
        }
        if (q.to() != null) {
            c.add("occurred_at < :to");
            p.addValue("to", Timestamp.from(q.to()));
        }
        if (StringUtils.hasText(q.text())) {
            c.add("(description ILIKE :text OR action ILIKE :text OR CAST(details AS TEXT) ILIKE :text)");
            p.addValue("text", "%" + q.text() + "%");
        }
        return c.isEmpty() ? "" : " WHERE " + String.join(" AND ", c);
    }

    private static void eq(List<String> c, MapSqlParameterSource p, String column, String value) {
        if (StringUtils.hasText(value)) {
            c.add(column + " = :" + column);
            p.addValue(column, value);
        }
    }

    private static String csv(String v) {
        if (v == null) {
            return "";
        }
        String s = v;
        if (!s.isEmpty() && "=+-@".indexOf(s.charAt(0)) >= 0) {
            s = "'" + s; // CSV injection guard for Excel
        }
        return "\"" + s.replace("\"", "\"\"") + "\"";
    }
}
