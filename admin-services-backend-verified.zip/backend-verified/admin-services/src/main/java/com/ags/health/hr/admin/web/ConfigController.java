package com.ags.health.hr.admin.web;

import com.ags.health.hr.admin.service.ConfigService;
import com.ags.health.hr.admin.web.AdminDtos.ConfigCreateRequest;
import com.ags.health.hr.admin.web.AdminDtos.ConfigResponse;
import com.ags.health.hr.admin.web.AdminDtos.ConfigUpdateRequest;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/**
 * Enterprise configuration (pass percentage, cooling periods, validity windows ...).
 * Tracker #32: reads need CONFIG:VIEW, writes need the ADMIN role AND CONFIG:MANAGE - so a mis-configured
 * matrix can never hand enterprise settings to a non-admin.
 */
@RestController
@RequestMapping("/admin/config")
@Tag(name = "Enterprise configuration")
public class ConfigController {

    private final ConfigService service;

    public ConfigController(ConfigService service) {
        this.service = service;
    }

    @GetMapping
    @PreAuthorize("hasAuthority('CONFIG:VIEW')")
    public List<ConfigResponse> list(@RequestParam(required = false) String category) {
        return service.list(category);
    }

    @GetMapping("/{key}")
    @PreAuthorize("hasAuthority('CONFIG:VIEW')")
    public ConfigResponse get(@PathVariable String key) {
        return service.get(key);
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    @PreAuthorize("hasRole('ADMIN') and hasAuthority('CONFIG:MANAGE')")
    public ConfigResponse create(@Valid @RequestBody ConfigCreateRequest req) {
        return service.create(req);
    }

    @PutMapping("/{key}")
    @PreAuthorize("hasRole('ADMIN') and hasAuthority('CONFIG:MANAGE')")
    @Operation(summary = "Change a value (type-checked, logged with before/after)")
    public ConfigResponse update(@PathVariable String key, @Valid @RequestBody ConfigUpdateRequest req) {
        return service.update(key, req);
    }
}
