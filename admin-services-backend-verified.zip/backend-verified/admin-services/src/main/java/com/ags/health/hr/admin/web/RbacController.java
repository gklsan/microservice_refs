package com.ags.health.hr.admin.web;

import com.ags.health.hr.admin.service.AccessService;
import com.ags.health.hr.admin.service.LookupService;
import com.ags.health.hr.admin.web.AdminDtos.CheckRequest;
import com.ags.health.hr.admin.web.AdminDtos.CheckResponse;
import com.ags.health.hr.admin.web.AdminDtos.FilterDefinition;
import com.ags.health.hr.admin.web.AdminDtos.MeResponse;
import com.ags.health.hr.platform.security.AccessEvaluator;
import com.ags.health.hr.platform.security.CurrentUser;
import com.ags.health.hr.platform.security.EffectiveAccess;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/** Endpoints any logged-in user (UI) calls to adapt screens to his role. */
@RestController
@RequestMapping("/rbac")
@Tag(name = "RBAC", description = "Effective permissions, record checks and role-driven filters")
public class RbacController {

    private final LookupService lookupService;
    private final AccessService accessService;

    public RbacController(LookupService lookupService, AccessService accessService) {
        this.lookupService = lookupService;
        this.accessService = accessService;
    }

    @GetMapping("/me")
    @Operation(summary = "Roles, permissions and data scope of the caller - drives menu/button visibility")
    public MeResponse me(@AuthenticationPrincipal CurrentUser user) {
        return new MeResponse(user.userId(), user.email(), user.name(), user.userType(), user.roles(),
                user.permissions(), user.scope());
    }

    @PostMapping("/check")
    @Operation(summary = "Can the caller perform <permission> on this record? (owner / team / LOB / location / shared)")
    public CheckResponse check(@AuthenticationPrincipal CurrentUser user, @RequestBody CheckRequest req) {
        AccessEvaluator.Decision d = AccessEvaluator.check(user, req.permission(),
                new AccessEvaluator.Target(req.objectType(), req.objectId(), req.ownerId(), req.lob(), req.location()));
        return new CheckResponse(d.allowed(), d.reason());
    }

    @GetMapping("/filters/{screen}")
    @Operation(summary = "Filters the caller may use on a list screen (CANDIDATE_LIST, APPLICANT_LIST, OPEN_POSITIONS, INTERVIEWS, MY_REFERRALS, AUDIT_LOG)")
    public List<FilterDefinition> filters(@AuthenticationPrincipal CurrentUser user, @PathVariable String screen) {
        return lookupService.filtersFor(screen.toUpperCase(), user);
    }

    @GetMapping("/effective")
    @Operation(summary = "Effective access of another user (admin troubleshooting)")
    @org.springframework.security.access.prepost.PreAuthorize("hasAuthority('USER:VIEW')")
    public EffectiveAccess effectiveOf(@RequestParam(required = false) String userId,
                                       @RequestParam(required = false) String email,
                                       @RequestParam(required = false) String userType) {
        return accessService.resolve(userId, email, userType);
    }
}
