package com.ags.health.hr.admin.domain;

import com.ags.health.hr.platform.jpa.AuditableEntity;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.Arrays;
import java.util.Set;
import java.util.UUID;
import java.util.stream.Collectors;

/**
 * Filter definition for a list screen (left-hand filter panels in the Figma screens).
 * Visibility is role-driven through {@code allowedRoles}; options can be restricted to the user's scope.
 */
@Entity
@Table(name = "search_filter")
@Getter
@Setter
@NoArgsConstructor
public class SearchFilter extends AuditableEntity {

    @Id
    private UUID id;

    @Column(nullable = false)
    private String screen;

    @Column(name = "filter_key", nullable = false)
    private String filterKey;

    @Column(nullable = false)
    private String label;

    @Column(name = "filter_type", nullable = false)
    private String filterType;

    @Column(name = "options_source")
    private String optionsSource;

    @Column(name = "static_options")
    private String staticOptions;

    @Column(name = "allowed_roles")
    private String allowedRoles;

    @Column(name = "restrict_to_scope", nullable = false)
    private boolean restrictToScope;

    @Column(name = "sort_order", nullable = false)
    private int sortOrder;

    @Column(nullable = false)
    private boolean active = true;

    public Set<String> allowedRoleSet() {
        if (allowedRoles == null || allowedRoles.isBlank()) {
            return Set.of();
        }
        return Arrays.stream(allowedRoles.split(",")).map(String::trim).filter(s -> !s.isEmpty())
                .collect(Collectors.toSet());
    }

    public boolean visibleFor(Set<String> roles) {
        Set<String> allowed = allowedRoleSet();
        return allowed.isEmpty() || roles.stream().anyMatch(allowed::contains);
    }
}
