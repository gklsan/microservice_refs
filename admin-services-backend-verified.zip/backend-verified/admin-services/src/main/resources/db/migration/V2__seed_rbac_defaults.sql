-- Seed data: default roles, permission sets, role-driven filters, master data, enterprise config.
-- Idempotent (ON CONFLICT DO NOTHING) so re-running never overwrites admin changes.

-- permissions
INSERT INTO dh_admin.permission (id, code, object_type, action, description) VALUES (gen_random_uuid(), 'JOB:VIEW', 'JOB', 'VIEW', 'View job requisitions / postings') ON CONFLICT (code) DO NOTHING;
INSERT INTO dh_admin.permission (id, code, object_type, action, description) VALUES (gen_random_uuid(), 'JOB:CREATE', 'JOB', 'CREATE', 'Create job requisitions') ON CONFLICT (code) DO NOTHING;
INSERT INTO dh_admin.permission (id, code, object_type, action, description) VALUES (gen_random_uuid(), 'JOB:UPDATE', 'JOB', 'UPDATE', 'Update job requisitions') ON CONFLICT (code) DO NOTHING;
INSERT INTO dh_admin.permission (id, code, object_type, action, description) VALUES (gen_random_uuid(), 'JOB:PUBLISH', 'JOB', 'PUBLISH', 'Publish jobs to Career Page / Buddy Finder') ON CONFLICT (code) DO NOTHING;
INSERT INTO dh_admin.permission (id, code, object_type, action, description) VALUES (gen_random_uuid(), 'JOB:EDIT_JD', 'JOB', 'EDIT_JD', 'Edit job description (needs TA Head approval)') ON CONFLICT (code) DO NOTHING;
INSERT INTO dh_admin.permission (id, code, object_type, action, description) VALUES (gen_random_uuid(), 'JOB:MAP', 'JOB', 'MAP', 'Map candidates to a job') ON CONFLICT (code) DO NOTHING;
INSERT INTO dh_admin.permission (id, code, object_type, action, description) VALUES (gen_random_uuid(), 'CANDIDATE:VIEW', 'CANDIDATE', 'VIEW', 'View candidate profiles') ON CONFLICT (code) DO NOTHING;
INSERT INTO dh_admin.permission (id, code, object_type, action, description) VALUES (gen_random_uuid(), 'CANDIDATE:CREATE', 'CANDIDATE', 'CREATE', 'Create / upload candidates') ON CONFLICT (code) DO NOTHING;
INSERT INTO dh_admin.permission (id, code, object_type, action, description) VALUES (gen_random_uuid(), 'CANDIDATE:UPDATE', 'CANDIDATE', 'UPDATE', 'Update candidate profiles') ON CONFLICT (code) DO NOTHING;
INSERT INTO dh_admin.permission (id, code, object_type, action, description) VALUES (gen_random_uuid(), 'CANDIDATE:EXPORT', 'CANDIDATE', 'EXPORT', 'Export candidate data / PDF') ON CONFLICT (code) DO NOTHING;
INSERT INTO dh_admin.permission (id, code, object_type, action, description) VALUES (gen_random_uuid(), 'CANDIDATE:VIEW_SENSITIVE', 'CANDIDATE', 'VIEW_SENSITIVE', 'View ID proofs and sensitive documents') ON CONFLICT (code) DO NOTHING;
INSERT INTO dh_admin.permission (id, code, object_type, action, description) VALUES (gen_random_uuid(), 'APPLICATION:VIEW', 'APPLICATION', 'VIEW', 'View applications') ON CONFLICT (code) DO NOTHING;
INSERT INTO dh_admin.permission (id, code, object_type, action, description) VALUES (gen_random_uuid(), 'APPLICATION:CREATE', 'APPLICATION', 'CREATE', 'Create applications') ON CONFLICT (code) DO NOTHING;
INSERT INTO dh_admin.permission (id, code, object_type, action, description) VALUES (gen_random_uuid(), 'APPLICATION:UPDATE', 'APPLICATION', 'UPDATE', 'Update applications') ON CONFLICT (code) DO NOTHING;
INSERT INTO dh_admin.permission (id, code, object_type, action, description) VALUES (gen_random_uuid(), 'APPLICATION:MAP', 'APPLICATION', 'MAP', 'Map / re-map application to requisition') ON CONFLICT (code) DO NOTHING;
INSERT INTO dh_admin.permission (id, code, object_type, action, description) VALUES (gen_random_uuid(), 'APPLICATION:REJECT', 'APPLICATION', 'REJECT', 'Reject application') ON CONFLICT (code) DO NOTHING;
INSERT INTO dh_admin.permission (id, code, object_type, action, description) VALUES (gen_random_uuid(), 'APPLICATION:HOLD', 'APPLICATION', 'HOLD', 'Move application to On Hold / Pipeline') ON CONFLICT (code) DO NOTHING;
INSERT INTO dh_admin.permission (id, code, object_type, action, description) VALUES (gen_random_uuid(), 'APPLICATION:SCHEDULE_INTERVIEW', 'APPLICATION', 'SCHEDULE_INTERVIEW', 'Schedule walk-in / online interviews') ON CONFLICT (code) DO NOTHING;
INSERT INTO dh_admin.permission (id, code, object_type, action, description) VALUES (gen_random_uuid(), 'APPLICATION:MOVE_STAGE', 'APPLICATION', 'MOVE_STAGE', 'Move application between workflow stages') ON CONFLICT (code) DO NOTHING;
INSERT INTO dh_admin.permission (id, code, object_type, action, description) VALUES (gen_random_uuid(), 'APPLICATION:BULK_UPDATE', 'APPLICATION', 'BULK_UPDATE', 'Bulk status updates') ON CONFLICT (code) DO NOTHING;
INSERT INTO dh_admin.permission (id, code, object_type, action, description) VALUES (gen_random_uuid(), 'WORKFLOW:VIEW', 'WORKFLOW', 'VIEW', 'View workflow definitions') ON CONFLICT (code) DO NOTHING;
INSERT INTO dh_admin.permission (id, code, object_type, action, description) VALUES (gen_random_uuid(), 'WORKFLOW:CONFIGURE', 'WORKFLOW', 'CONFIGURE', 'Configure hiring steps and workflow drafts (steps, states, transitions, rules)') ON CONFLICT (code) DO NOTHING;
INSERT INTO dh_admin.permission (id, code, object_type, action, description) VALUES (gen_random_uuid(), 'WORKFLOW:PUBLISH', 'WORKFLOW', 'PUBLISH', 'Publish / activate workflow versions') ON CONFLICT (code) DO NOTHING;
INSERT INTO dh_admin.permission (id, code, object_type, action, description) VALUES (gen_random_uuid(), 'WORKFLOW:APPROVE', 'WORKFLOW', 'APPROVE', 'Approve workflow transitions that need approval') ON CONFLICT (code) DO NOTHING;
INSERT INTO dh_admin.permission (id, code, object_type, action, description) VALUES (gen_random_uuid(), 'WORKFLOW:ASSIGN', 'WORKFLOW', 'ASSIGN', 'Assign workflows to a job / role / LOB / location') ON CONFLICT (code) DO NOTHING;
INSERT INTO dh_admin.permission (id, code, object_type, action, description) VALUES (gen_random_uuid(), 'USER:VIEW', 'USER', 'VIEW', 'View admin users') ON CONFLICT (code) DO NOTHING;
INSERT INTO dh_admin.permission (id, code, object_type, action, description) VALUES (gen_random_uuid(), 'USER:MANAGE', 'USER', 'MANAGE', 'Create, deactivate, reactivate users and assign roles') ON CONFLICT (code) DO NOTHING;
INSERT INTO dh_admin.permission (id, code, object_type, action, description) VALUES (gen_random_uuid(), 'ROLE:VIEW', 'ROLE', 'VIEW', 'View roles and permission matrix') ON CONFLICT (code) DO NOTHING;
INSERT INTO dh_admin.permission (id, code, object_type, action, description) VALUES (gen_random_uuid(), 'ROLE:MANAGE', 'ROLE', 'MANAGE', 'Create roles and change the permission matrix') ON CONFLICT (code) DO NOTHING;
INSERT INTO dh_admin.permission (id, code, object_type, action, description) VALUES (gen_random_uuid(), 'CONFIG:VIEW', 'CONFIG', 'VIEW', 'View enterprise configuration') ON CONFLICT (code) DO NOTHING;
INSERT INTO dh_admin.permission (id, code, object_type, action, description) VALUES (gen_random_uuid(), 'CONFIG:MANAGE', 'CONFIG', 'MANAGE', 'Change enterprise configuration') ON CONFLICT (code) DO NOTHING;
INSERT INTO dh_admin.permission (id, code, object_type, action, description) VALUES (gen_random_uuid(), 'MASTER_DATA:MANAGE', 'MASTER_DATA', 'MANAGE', 'Maintain LOB / location / reason master data') ON CONFLICT (code) DO NOTHING;
INSERT INTO dh_admin.permission (id, code, object_type, action, description) VALUES (gen_random_uuid(), 'AUDIT_LOG:VIEW', 'AUDIT_LOG', 'VIEW', 'View central logs') ON CONFLICT (code) DO NOTHING;
INSERT INTO dh_admin.permission (id, code, object_type, action, description) VALUES (gen_random_uuid(), 'AUDIT_LOG:EXPORT', 'AUDIT_LOG', 'EXPORT', 'Export central logs') ON CONFLICT (code) DO NOTHING;
INSERT INTO dh_admin.permission (id, code, object_type, action, description) VALUES (gen_random_uuid(), 'NOTIFICATION_TEMPLATE:VIEW', 'NOTIFICATION_TEMPLATE', 'VIEW', 'View email templates and triggers') ON CONFLICT (code) DO NOTHING;
INSERT INTO dh_admin.permission (id, code, object_type, action, description) VALUES (gen_random_uuid(), 'NOTIFICATION_TEMPLATE:MANAGE', 'NOTIFICATION_TEMPLATE', 'MANAGE', 'Edit email templates and triggers') ON CONFLICT (code) DO NOTHING;
INSERT INTO dh_admin.permission (id, code, object_type, action, description) VALUES (gen_random_uuid(), 'NOTIFICATION_TEMPLATE:SEND', 'NOTIFICATION_TEMPLATE', 'SEND', 'Send ad-hoc templated emails') ON CONFLICT (code) DO NOTHING;
INSERT INTO dh_admin.permission (id, code, object_type, action, description) VALUES (gen_random_uuid(), 'ACCESS_OVERRIDE:REQUEST', 'ACCESS_OVERRIDE', 'REQUEST', 'Request override / shared access') ON CONFLICT (code) DO NOTHING;
INSERT INTO dh_admin.permission (id, code, object_type, action, description) VALUES (gen_random_uuid(), 'ACCESS_OVERRIDE:APPROVE', 'ACCESS_OVERRIDE', 'APPROVE', 'Approve override / shared access') ON CONFLICT (code) DO NOTHING;

-- roles
INSERT INTO dh_admin.role (id, code, name, description, scope_level, system_role, active, created_by) VALUES (gen_random_uuid(), 'ADMIN', 'Administrator', 'Full control of enterprise configuration, roles, workflows', 'ALL', TRUE, TRUE, 'flyway') ON CONFLICT (code) DO NOTHING;
INSERT INTO dh_admin.role (id, code, name, description, scope_level, system_role, active, created_by) VALUES (gen_random_uuid(), 'TA_HEAD', 'TA Head', 'Talent acquisition head - all candidates, approvals', 'ALL', TRUE, TRUE, 'flyway') ON CONFLICT (code) DO NOTHING;
INSERT INTO dh_admin.role (id, code, name, description, scope_level, system_role, active, created_by) VALUES (gen_random_uuid(), 'MANAGER', 'TA Manager', 'Elevated visibility across supervised LOBs', 'LOB', TRUE, TRUE, 'flyway') ON CONFLICT (code) DO NOTHING;
INSERT INTO dh_admin.role (id, code, name, description, scope_level, system_role, active, created_by) VALUES (gen_random_uuid(), 'TL', 'Team Lead', 'Elevated visibility across supervised LOBs and own team', 'LOB', TRUE, TRUE, 'flyway') ON CONFLICT (code) DO NOTHING;
INSERT INTO dh_admin.role (id, code, name, description, scope_level, system_role, active, created_by) VALUES (gen_random_uuid(), 'RECRUITER', 'Recruiter', 'Sees only owned or shared candidates', 'OWN', TRUE, TRUE, 'flyway') ON CONFLICT (code) DO NOTHING;
INSERT INTO dh_admin.role (id, code, name, description, scope_level, system_role, active, created_by) VALUES (gen_random_uuid(), 'PANEL', 'Panel Member', 'Interviewer - assigned candidates only', 'OWN', TRUE, TRUE, 'flyway') ON CONFLICT (code) DO NOTHING;
INSERT INTO dh_admin.role (id, code, name, description, scope_level, system_role, active, created_by) VALUES (gen_random_uuid(), 'EMPLOYEE', 'Employee', 'Buddy Finder referrals', 'OWN', TRUE, TRUE, 'flyway') ON CONFLICT (code) DO NOTHING;
INSERT INTO dh_admin.role (id, code, name, description, scope_level, system_role, active, created_by) VALUES (gen_random_uuid(), 'VENDOR', 'Vendor', 'Staffing agency portal', 'OWN', TRUE, TRUE, 'flyway') ON CONFLICT (code) DO NOTHING;
INSERT INTO dh_admin.role (id, code, name, description, scope_level, system_role, active, created_by) VALUES (gen_random_uuid(), 'CANDIDATE', 'Candidate', 'Self-service candidate', 'OWN', TRUE, TRUE, 'flyway') ON CONFLICT (code) DO NOTHING;

-- factory default permission sets (Job / Candidate / Application objects and admin objects)
INSERT INTO dh_admin.default_role_permission (role_code, permission_code) VALUES
  ('ADMIN','JOB:VIEW'),
  ('ADMIN','JOB:CREATE'),
  ('ADMIN','JOB:UPDATE'),
  ('ADMIN','JOB:PUBLISH'),
  ('ADMIN','JOB:EDIT_JD'),
  ('ADMIN','JOB:MAP'),
  ('ADMIN','CANDIDATE:VIEW'),
  ('ADMIN','CANDIDATE:CREATE'),
  ('ADMIN','CANDIDATE:UPDATE'),
  ('ADMIN','CANDIDATE:EXPORT'),
  ('ADMIN','CANDIDATE:VIEW_SENSITIVE'),
  ('ADMIN','APPLICATION:VIEW'),
  ('ADMIN','APPLICATION:CREATE'),
  ('ADMIN','APPLICATION:UPDATE'),
  ('ADMIN','APPLICATION:MAP'),
  ('ADMIN','APPLICATION:REJECT'),
  ('ADMIN','APPLICATION:HOLD'),
  ('ADMIN','APPLICATION:SCHEDULE_INTERVIEW'),
  ('ADMIN','APPLICATION:MOVE_STAGE'),
  ('ADMIN','APPLICATION:BULK_UPDATE'),
  ('ADMIN','WORKFLOW:VIEW'),
  ('ADMIN','WORKFLOW:CONFIGURE'),
  ('ADMIN','WORKFLOW:PUBLISH'),
  ('ADMIN','WORKFLOW:APPROVE'),
  ('ADMIN','WORKFLOW:ASSIGN'),
  ('ADMIN','USER:VIEW'),
  ('ADMIN','USER:MANAGE'),
  ('ADMIN','ROLE:VIEW'),
  ('ADMIN','ROLE:MANAGE'),
  ('ADMIN','CONFIG:VIEW'),
  ('ADMIN','CONFIG:MANAGE'),
  ('ADMIN','MASTER_DATA:MANAGE'),
  ('ADMIN','AUDIT_LOG:VIEW'),
  ('ADMIN','AUDIT_LOG:EXPORT'),
  ('ADMIN','NOTIFICATION_TEMPLATE:VIEW'),
  ('ADMIN','NOTIFICATION_TEMPLATE:MANAGE'),
  ('ADMIN','NOTIFICATION_TEMPLATE:SEND'),
  ('ADMIN','ACCESS_OVERRIDE:REQUEST'),
  ('ADMIN','ACCESS_OVERRIDE:APPROVE')
ON CONFLICT DO NOTHING;
INSERT INTO dh_admin.default_role_permission (role_code, permission_code) VALUES
  ('TA_HEAD','JOB:VIEW'),
  ('TA_HEAD','JOB:CREATE'),
  ('TA_HEAD','JOB:UPDATE'),
  ('TA_HEAD','JOB:PUBLISH'),
  ('TA_HEAD','JOB:EDIT_JD'),
  ('TA_HEAD','JOB:MAP'),
  ('TA_HEAD','CANDIDATE:VIEW'),
  ('TA_HEAD','CANDIDATE:CREATE'),
  ('TA_HEAD','CANDIDATE:UPDATE'),
  ('TA_HEAD','CANDIDATE:EXPORT'),
  ('TA_HEAD','CANDIDATE:VIEW_SENSITIVE'),
  ('TA_HEAD','APPLICATION:VIEW'),
  ('TA_HEAD','APPLICATION:CREATE'),
  ('TA_HEAD','APPLICATION:UPDATE'),
  ('TA_HEAD','APPLICATION:MAP'),
  ('TA_HEAD','APPLICATION:REJECT'),
  ('TA_HEAD','APPLICATION:HOLD'),
  ('TA_HEAD','APPLICATION:SCHEDULE_INTERVIEW'),
  ('TA_HEAD','APPLICATION:MOVE_STAGE'),
  ('TA_HEAD','APPLICATION:BULK_UPDATE'),
  ('TA_HEAD','WORKFLOW:VIEW'),
  ('TA_HEAD','WORKFLOW:CONFIGURE'),
  ('TA_HEAD','WORKFLOW:PUBLISH'),
  ('TA_HEAD','WORKFLOW:APPROVE'),
  ('TA_HEAD','WORKFLOW:ASSIGN'),
  ('TA_HEAD','USER:VIEW'),
  ('TA_HEAD','ROLE:VIEW'),
  ('TA_HEAD','CONFIG:VIEW'),
  ('TA_HEAD','AUDIT_LOG:VIEW'),
  ('TA_HEAD','AUDIT_LOG:EXPORT'),
  ('TA_HEAD','NOTIFICATION_TEMPLATE:VIEW'),
  ('TA_HEAD','NOTIFICATION_TEMPLATE:SEND'),
  ('TA_HEAD','ACCESS_OVERRIDE:REQUEST'),
  ('TA_HEAD','ACCESS_OVERRIDE:APPROVE')
ON CONFLICT DO NOTHING;
INSERT INTO dh_admin.default_role_permission (role_code, permission_code) VALUES
  ('MANAGER','JOB:VIEW'),
  ('MANAGER','JOB:CREATE'),
  ('MANAGER','JOB:UPDATE'),
  ('MANAGER','JOB:PUBLISH'),
  ('MANAGER','JOB:MAP'),
  ('MANAGER','CANDIDATE:VIEW'),
  ('MANAGER','CANDIDATE:CREATE'),
  ('MANAGER','CANDIDATE:UPDATE'),
  ('MANAGER','CANDIDATE:EXPORT'),
  ('MANAGER','APPLICATION:VIEW'),
  ('MANAGER','APPLICATION:CREATE'),
  ('MANAGER','APPLICATION:UPDATE'),
  ('MANAGER','APPLICATION:MAP'),
  ('MANAGER','APPLICATION:REJECT'),
  ('MANAGER','APPLICATION:HOLD'),
  ('MANAGER','APPLICATION:SCHEDULE_INTERVIEW'),
  ('MANAGER','APPLICATION:MOVE_STAGE'),
  ('MANAGER','APPLICATION:BULK_UPDATE'),
  ('MANAGER','WORKFLOW:VIEW'),
  ('MANAGER','WORKFLOW:CONFIGURE'),
  ('MANAGER','WORKFLOW:PUBLISH'),
  ('MANAGER','WORKFLOW:APPROVE'),
  ('MANAGER','WORKFLOW:ASSIGN'),
  ('MANAGER','AUDIT_LOG:VIEW'),
  ('MANAGER','NOTIFICATION_TEMPLATE:VIEW'),
  ('MANAGER','NOTIFICATION_TEMPLATE:SEND'),
  ('MANAGER','ACCESS_OVERRIDE:REQUEST'),
  ('MANAGER','ACCESS_OVERRIDE:APPROVE')
ON CONFLICT DO NOTHING;
INSERT INTO dh_admin.default_role_permission (role_code, permission_code) VALUES
  ('TL','JOB:VIEW'),
  ('TL','JOB:PUBLISH'),
  ('TL','JOB:MAP'),
  ('TL','CANDIDATE:VIEW'),
  ('TL','CANDIDATE:CREATE'),
  ('TL','CANDIDATE:UPDATE'),
  ('TL','CANDIDATE:EXPORT'),
  ('TL','APPLICATION:VIEW'),
  ('TL','APPLICATION:CREATE'),
  ('TL','APPLICATION:UPDATE'),
  ('TL','APPLICATION:MAP'),
  ('TL','APPLICATION:REJECT'),
  ('TL','APPLICATION:HOLD'),
  ('TL','APPLICATION:SCHEDULE_INTERVIEW'),
  ('TL','APPLICATION:MOVE_STAGE'),
  ('TL','APPLICATION:BULK_UPDATE'),
  ('TL','WORKFLOW:VIEW'),
  ('TL','WORKFLOW:CONFIGURE'),
  ('TL','WORKFLOW:APPROVE'),
  ('TL','WORKFLOW:ASSIGN'),
  ('TL','NOTIFICATION_TEMPLATE:VIEW'),
  ('TL','NOTIFICATION_TEMPLATE:SEND'),
  ('TL','ACCESS_OVERRIDE:REQUEST'),
  ('TL','ACCESS_OVERRIDE:APPROVE')
ON CONFLICT DO NOTHING;
INSERT INTO dh_admin.default_role_permission (role_code, permission_code) VALUES
  ('RECRUITER','JOB:VIEW'),
  ('RECRUITER','JOB:MAP'),
  ('RECRUITER','CANDIDATE:VIEW'),
  ('RECRUITER','CANDIDATE:CREATE'),
  ('RECRUITER','CANDIDATE:UPDATE'),
  ('RECRUITER','APPLICATION:VIEW'),
  ('RECRUITER','APPLICATION:CREATE'),
  ('RECRUITER','APPLICATION:UPDATE'),
  ('RECRUITER','APPLICATION:MAP'),
  ('RECRUITER','APPLICATION:REJECT'),
  ('RECRUITER','APPLICATION:HOLD'),
  ('RECRUITER','APPLICATION:SCHEDULE_INTERVIEW'),
  ('RECRUITER','APPLICATION:MOVE_STAGE'),
  ('RECRUITER','WORKFLOW:VIEW'),
  ('RECRUITER','NOTIFICATION_TEMPLATE:SEND'),
  ('RECRUITER','ACCESS_OVERRIDE:REQUEST')
ON CONFLICT DO NOTHING;
INSERT INTO dh_admin.default_role_permission (role_code, permission_code) VALUES
  ('PANEL','CANDIDATE:VIEW'),
  ('PANEL','APPLICATION:VIEW'),
  ('PANEL','APPLICATION:UPDATE'),
  ('PANEL','APPLICATION:MOVE_STAGE')
ON CONFLICT DO NOTHING;
INSERT INTO dh_admin.default_role_permission (role_code, permission_code) VALUES
  ('EMPLOYEE','JOB:VIEW')
ON CONFLICT DO NOTHING;
INSERT INTO dh_admin.default_role_permission (role_code, permission_code) VALUES
  ('VENDOR','JOB:VIEW'),
  ('VENDOR','CANDIDATE:VIEW'),
  ('VENDOR','CANDIDATE:CREATE'),
  ('VENDOR','APPLICATION:VIEW')
ON CONFLICT DO NOTHING;
INSERT INTO dh_admin.default_role_permission (role_code, permission_code) VALUES
  ('CANDIDATE','JOB:VIEW')
ON CONFLICT DO NOTHING;

-- apply defaults to the live matrix
INSERT INTO dh_admin.role_permission (role_id, permission_id)
SELECT r.id, p.id FROM dh_admin.default_role_permission d
JOIN dh_admin.role r ON r.code = d.role_code
JOIN dh_admin.permission p ON p.code = d.permission_code
ON CONFLICT DO NOTHING;

-- role-driven dynamic search filters
INSERT INTO dh_admin.search_filter (id, screen, filter_key, label, filter_type, options_source, static_options, allowed_roles, restrict_to_scope, sort_order, active, created_by) VALUES (gen_random_uuid(), 'CANDIDATE_LIST', 'location', 'Job location', 'MULTI_SELECT', 'MASTER_DATA:LOCATION', NULL, NULL, TRUE, 10, TRUE, 'flyway') ON CONFLICT (screen, filter_key) DO NOTHING;
INSERT INTO dh_admin.search_filter (id, screen, filter_key, label, filter_type, options_source, static_options, allowed_roles, restrict_to_scope, sort_order, active, created_by) VALUES (gen_random_uuid(), 'CANDIDATE_LIST', 'lob', 'Line of business', 'MULTI_SELECT', 'MASTER_DATA:LOB', NULL, NULL, TRUE, 20, TRUE, 'flyway') ON CONFLICT (screen, filter_key) DO NOTHING;
INSERT INTO dh_admin.search_filter (id, screen, filter_key, label, filter_type, options_source, static_options, allowed_roles, restrict_to_scope, sort_order, active, created_by) VALUES (gen_random_uuid(), 'CANDIDATE_LIST', 'status', 'Status', 'MULTI_SELECT', 'WORKFLOW_STATES:APPLICATION_HIRING', NULL, NULL, FALSE, 30, TRUE, 'flyway') ON CONFLICT (screen, filter_key) DO NOTHING;
INSERT INTO dh_admin.search_filter (id, screen, filter_key, label, filter_type, options_source, static_options, allowed_roles, restrict_to_scope, sort_order, active, created_by) VALUES (gen_random_uuid(), 'CANDIDATE_LIST', 'source', 'Source', 'MULTI_SELECT', 'MASTER_DATA:SOURCE', NULL, NULL, FALSE, 40, TRUE, 'flyway') ON CONFLICT (screen, filter_key) DO NOTHING;
INSERT INTO dh_admin.search_filter (id, screen, filter_key, label, filter_type, options_source, static_options, allowed_roles, restrict_to_scope, sort_order, active, created_by) VALUES (gen_random_uuid(), 'CANDIDATE_LIST', 'experience', 'Experience', 'MULTI_SELECT', 'MASTER_DATA:EXPERIENCE_BAND', NULL, NULL, FALSE, 50, TRUE, 'flyway') ON CONFLICT (screen, filter_key) DO NOTHING;
INSERT INTO dh_admin.search_filter (id, screen, filter_key, label, filter_type, options_source, static_options, allowed_roles, restrict_to_scope, sort_order, active, created_by) VALUES (gen_random_uuid(), 'CANDIDATE_LIST', 'recruiterIds', 'Recruiter', 'MULTI_SELECT', 'USERS:RECRUITER', NULL, 'TL,MANAGER,TA_HEAD,ADMIN', FALSE, 60, TRUE, 'flyway') ON CONFLICT (screen, filter_key) DO NOTHING;
INSERT INTO dh_admin.search_filter (id, screen, filter_key, label, filter_type, options_source, static_options, allowed_roles, restrict_to_scope, sort_order, active, created_by) VALUES (gen_random_uuid(), 'CANDIDATE_LIST', 'appliedOn', 'Received on', 'DATE_RANGE', NULL, NULL, NULL, FALSE, 70, TRUE, 'flyway') ON CONFLICT (screen, filter_key) DO NOTHING;
INSERT INTO dh_admin.search_filter (id, screen, filter_key, label, filter_type, options_source, static_options, allowed_roles, restrict_to_scope, sort_order, active, created_by) VALUES (gen_random_uuid(), 'APPLICANT_LIST', 'location', 'Job location', 'MULTI_SELECT', 'MASTER_DATA:LOCATION', NULL, NULL, TRUE, 10, TRUE, 'flyway') ON CONFLICT (screen, filter_key) DO NOTHING;
INSERT INTO dh_admin.search_filter (id, screen, filter_key, label, filter_type, options_source, static_options, allowed_roles, restrict_to_scope, sort_order, active, created_by) VALUES (gen_random_uuid(), 'APPLICANT_LIST', 'lob', 'Line of business', 'MULTI_SELECT', 'MASTER_DATA:LOB', NULL, NULL, TRUE, 20, TRUE, 'flyway') ON CONFLICT (screen, filter_key) DO NOTHING;
INSERT INTO dh_admin.search_filter (id, screen, filter_key, label, filter_type, options_source, static_options, allowed_roles, restrict_to_scope, sort_order, active, created_by) VALUES (gen_random_uuid(), 'APPLICANT_LIST', 'status', 'Status', 'MULTI_SELECT', 'WORKFLOW_STATES:APPLICATION_HIRING', NULL, NULL, FALSE, 30, TRUE, 'flyway') ON CONFLICT (screen, filter_key) DO NOTHING;
INSERT INTO dh_admin.search_filter (id, screen, filter_key, label, filter_type, options_source, static_options, allowed_roles, restrict_to_scope, sort_order, active, created_by) VALUES (gen_random_uuid(), 'APPLICANT_LIST', 'jobType', 'Type', 'MULTI_SELECT', 'MASTER_DATA:JOB_TYPE', NULL, NULL, FALSE, 40, TRUE, 'flyway') ON CONFLICT (screen, filter_key) DO NOTHING;
INSERT INTO dh_admin.search_filter (id, screen, filter_key, label, filter_type, options_source, static_options, allowed_roles, restrict_to_scope, sort_order, active, created_by) VALUES (gen_random_uuid(), 'APPLICANT_LIST', 'recruiterIds', 'Recruiter', 'MULTI_SELECT', 'USERS:RECRUITER', NULL, 'TL,MANAGER,TA_HEAD,ADMIN', FALSE, 50, TRUE, 'flyway') ON CONFLICT (screen, filter_key) DO NOTHING;
INSERT INTO dh_admin.search_filter (id, screen, filter_key, label, filter_type, options_source, static_options, allowed_roles, restrict_to_scope, sort_order, active, created_by) VALUES (gen_random_uuid(), 'APPLICANT_LIST', 'teamOnly', 'Only my team', 'BOOLEAN', NULL, NULL, 'TL,MANAGER', FALSE, 60, TRUE, 'flyway') ON CONFLICT (screen, filter_key) DO NOTHING;
INSERT INTO dh_admin.search_filter (id, screen, filter_key, label, filter_type, options_source, static_options, allowed_roles, restrict_to_scope, sort_order, active, created_by) VALUES (gen_random_uuid(), 'OPEN_POSITIONS', 'location', 'Job location', 'MULTI_SELECT', 'MASTER_DATA:LOCATION', NULL, NULL, FALSE, 10, TRUE, 'flyway') ON CONFLICT (screen, filter_key) DO NOTHING;
INSERT INTO dh_admin.search_filter (id, screen, filter_key, label, filter_type, options_source, static_options, allowed_roles, restrict_to_scope, sort_order, active, created_by) VALUES (gen_random_uuid(), 'OPEN_POSITIONS', 'country', 'Country', 'MULTI_SELECT', 'MASTER_DATA:COUNTRY', NULL, NULL, FALSE, 20, TRUE, 'flyway') ON CONFLICT (screen, filter_key) DO NOTHING;
INSERT INTO dh_admin.search_filter (id, screen, filter_key, label, filter_type, options_source, static_options, allowed_roles, restrict_to_scope, sort_order, active, created_by) VALUES (gen_random_uuid(), 'OPEN_POSITIONS', 'shift', 'Timing', 'MULTI_SELECT', 'MASTER_DATA:SHIFT', NULL, NULL, FALSE, 30, TRUE, 'flyway') ON CONFLICT (screen, filter_key) DO NOTHING;
INSERT INTO dh_admin.search_filter (id, screen, filter_key, label, filter_type, options_source, static_options, allowed_roles, restrict_to_scope, sort_order, active, created_by) VALUES (gen_random_uuid(), 'OPEN_POSITIONS', 'jobType', 'Type', 'MULTI_SELECT', 'MASTER_DATA:JOB_TYPE', NULL, NULL, FALSE, 40, TRUE, 'flyway') ON CONFLICT (screen, filter_key) DO NOTHING;
INSERT INTO dh_admin.search_filter (id, screen, filter_key, label, filter_type, options_source, static_options, allowed_roles, restrict_to_scope, sort_order, active, created_by) VALUES (gen_random_uuid(), 'INTERVIEWS', 'jobType', 'Type', 'MULTI_SELECT', 'MASTER_DATA:JOB_TYPE', NULL, NULL, FALSE, 10, TRUE, 'flyway') ON CONFLICT (screen, filter_key) DO NOTHING;
INSERT INTO dh_admin.search_filter (id, screen, filter_key, label, filter_type, options_source, static_options, allowed_roles, restrict_to_scope, sort_order, active, created_by) VALUES (gen_random_uuid(), 'INTERVIEWS', 'status', 'Status', 'MULTI_SELECT', 'STATIC', '[{"value": "SHORTLISTED", "label": "Shortlisted"}, {"value": "ON_HOLD", "label": "On hold"}, {"value": "OFFERED", "label": "Offered"}, {"value": "REJECTED", "label": "Rejected"}]', NULL, FALSE, 20, TRUE, 'flyway') ON CONFLICT (screen, filter_key) DO NOTHING;
INSERT INTO dh_admin.search_filter (id, screen, filter_key, label, filter_type, options_source, static_options, allowed_roles, restrict_to_scope, sort_order, active, created_by) VALUES (gen_random_uuid(), 'INTERVIEWS', 'experience', 'Experience', 'MULTI_SELECT', 'MASTER_DATA:EXPERIENCE_BAND', NULL, NULL, FALSE, 30, TRUE, 'flyway') ON CONFLICT (screen, filter_key) DO NOTHING;
INSERT INTO dh_admin.search_filter (id, screen, filter_key, label, filter_type, options_source, static_options, allowed_roles, restrict_to_scope, sort_order, active, created_by) VALUES (gen_random_uuid(), 'MY_REFERRALS', 'status', 'Status', 'MULTI_SELECT', 'STATIC', '[{"value": "OFFERED", "label": "Offered"}, {"value": "ON_HOLD", "label": "On-hold"}, {"value": "DECLINED", "label": "Declined"}]', NULL, FALSE, 10, TRUE, 'flyway') ON CONFLICT (screen, filter_key) DO NOTHING;
INSERT INTO dh_admin.search_filter (id, screen, filter_key, label, filter_type, options_source, static_options, allowed_roles, restrict_to_scope, sort_order, active, created_by) VALUES (gen_random_uuid(), 'AUDIT_LOG', 'category', 'Log type', 'MULTI_SELECT', 'STATIC', '[{"value": "ACTIVITY", "label": "Activity"}, {"value": "APPROVAL", "label": "Approval"}, {"value": "WORKFLOW_TRANSITION", "label": "Workflow transition"}, {"value": "CONFIG_CHANGE", "label": "Configuration change"}, {"value": "SECURITY", "label": "Security"}, {"value": "NOTIFICATION", "label": "Notification"}]', 'ADMIN,TA_HEAD,MANAGER', FALSE, 10, TRUE, 'flyway') ON CONFLICT (screen, filter_key) DO NOTHING;
INSERT INTO dh_admin.search_filter (id, screen, filter_key, label, filter_type, options_source, static_options, allowed_roles, restrict_to_scope, sort_order, active, created_by) VALUES (gen_random_uuid(), 'AUDIT_LOG', 'occurredAt', 'Date', 'DATE_RANGE', NULL, NULL, 'ADMIN,TA_HEAD,MANAGER', FALSE, 20, TRUE, 'flyway') ON CONFLICT (screen, filter_key) DO NOTHING;

-- master data
INSERT INTO dh_admin.master_data (id, category, code, label, parent_code, sort_order, active, created_by) VALUES (gen_random_uuid(), 'COUNTRY', 'IN', 'India', NULL, 10, TRUE, 'flyway') ON CONFLICT (category, code) DO NOTHING;
INSERT INTO dh_admin.master_data (id, category, code, label, parent_code, sort_order, active, created_by) VALUES (gen_random_uuid(), 'COUNTRY', 'US', 'USA', NULL, 20, TRUE, 'flyway') ON CONFLICT (category, code) DO NOTHING;
INSERT INTO dh_admin.master_data (id, category, code, label, parent_code, sort_order, active, created_by) VALUES (gen_random_uuid(), 'LOCATION', 'CHENNAI', 'Chennai', 'IN', 10, TRUE, 'flyway') ON CONFLICT (category, code) DO NOTHING;
INSERT INTO dh_admin.master_data (id, category, code, label, parent_code, sort_order, active, created_by) VALUES (gen_random_uuid(), 'LOCATION', 'COIMBATORE', 'Coimbatore', 'IN', 20, TRUE, 'flyway') ON CONFLICT (category, code) DO NOTHING;
INSERT INTO dh_admin.master_data (id, category, code, label, parent_code, sort_order, active, created_by) VALUES (gen_random_uuid(), 'LOCATION', 'BENGALURU', 'Bengaluru', 'IN', 30, TRUE, 'flyway') ON CONFLICT (category, code) DO NOTHING;
INSERT INTO dh_admin.master_data (id, category, code, label, parent_code, sort_order, active, created_by) VALUES (gen_random_uuid(), 'LOCATION', 'TRICHY', 'Trichy', 'IN', 40, TRUE, 'flyway') ON CONFLICT (category, code) DO NOTHING;
INSERT INTO dh_admin.master_data (id, category, code, label, parent_code, sort_order, active, created_by) VALUES (gen_random_uuid(), 'LOCATION', 'US_REMOTE', 'USA - Remote', 'US', 50, TRUE, 'flyway') ON CONFLICT (category, code) DO NOTHING;
INSERT INTO dh_admin.master_data (id, category, code, label, parent_code, sort_order, active, created_by) VALUES (gen_random_uuid(), 'LOB', 'MEDICAL_CODING', 'Medical Coding', NULL, 10, TRUE, 'flyway') ON CONFLICT (category, code) DO NOTHING;
INSERT INTO dh_admin.master_data (id, category, code, label, parent_code, sort_order, active, created_by) VALUES (gen_random_uuid(), 'LOB', 'AR_CALLING', 'AR Calling (Voice)', NULL, 20, TRUE, 'flyway') ON CONFLICT (category, code) DO NOTHING;
INSERT INTO dh_admin.master_data (id, category, code, label, parent_code, sort_order, active, created_by) VALUES (gen_random_uuid(), 'LOB', 'BILLING', 'Revenue Cycle / Billing', NULL, 30, TRUE, 'flyway') ON CONFLICT (category, code) DO NOTHING;
INSERT INTO dh_admin.master_data (id, category, code, label, parent_code, sort_order, active, created_by) VALUES (gen_random_uuid(), 'LOB', 'SUPPORT', 'Support', NULL, 40, TRUE, 'flyway') ON CONFLICT (category, code) DO NOTHING;
INSERT INTO dh_admin.master_data (id, category, code, label, parent_code, sort_order, active, created_by) VALUES (gen_random_uuid(), 'LOB', 'CORPORATE_IT', 'Corporate IT', NULL, 50, TRUE, 'flyway') ON CONFLICT (category, code) DO NOTHING;
INSERT INTO dh_admin.master_data (id, category, code, label, parent_code, sort_order, active, created_by) VALUES (gen_random_uuid(), 'JOB_TYPE', 'VOICE', 'Voice', NULL, 10, TRUE, 'flyway') ON CONFLICT (category, code) DO NOTHING;
INSERT INTO dh_admin.master_data (id, category, code, label, parent_code, sort_order, active, created_by) VALUES (gen_random_uuid(), 'JOB_TYPE', 'NON_VOICE', 'Non-voice', NULL, 20, TRUE, 'flyway') ON CONFLICT (category, code) DO NOTHING;
INSERT INTO dh_admin.master_data (id, category, code, label, parent_code, sort_order, active, created_by) VALUES (gen_random_uuid(), 'JOB_TYPE', 'MEDICAL_CODE', 'Medical code', NULL, 30, TRUE, 'flyway') ON CONFLICT (category, code) DO NOTHING;
INSERT INTO dh_admin.master_data (id, category, code, label, parent_code, sort_order, active, created_by) VALUES (gen_random_uuid(), 'JOB_TYPE', 'SUPPORT', 'Support', NULL, 40, TRUE, 'flyway') ON CONFLICT (category, code) DO NOTHING;
INSERT INTO dh_admin.master_data (id, category, code, label, parent_code, sort_order, active, created_by) VALUES (gen_random_uuid(), 'SHIFT', 'DAY_SHIFT', 'General shift', NULL, 10, TRUE, 'flyway') ON CONFLICT (category, code) DO NOTHING;
INSERT INTO dh_admin.master_data (id, category, code, label, parent_code, sort_order, active, created_by) VALUES (gen_random_uuid(), 'SHIFT', 'NIGHT_SHIFT', 'Night shift', NULL, 20, TRUE, 'flyway') ON CONFLICT (category, code) DO NOTHING;
INSERT INTO dh_admin.master_data (id, category, code, label, parent_code, sort_order, active, created_by) VALUES (gen_random_uuid(), 'EXPERIENCE_BAND', 'FRESHER', 'Fresher', NULL, 10, TRUE, 'flyway') ON CONFLICT (category, code) DO NOTHING;
INSERT INTO dh_admin.master_data (id, category, code, label, parent_code, sort_order, active, created_by) VALUES (gen_random_uuid(), 'EXPERIENCE_BAND', '0_1', '0 - 1 Years', NULL, 20, TRUE, 'flyway') ON CONFLICT (category, code) DO NOTHING;
INSERT INTO dh_admin.master_data (id, category, code, label, parent_code, sort_order, active, created_by) VALUES (gen_random_uuid(), 'EXPERIENCE_BAND', '1_3', '1 - 3 Years', NULL, 30, TRUE, 'flyway') ON CONFLICT (category, code) DO NOTHING;
INSERT INTO dh_admin.master_data (id, category, code, label, parent_code, sort_order, active, created_by) VALUES (gen_random_uuid(), 'EXPERIENCE_BAND', '4_5', '4 - 5 Years', NULL, 40, TRUE, 'flyway') ON CONFLICT (category, code) DO NOTHING;
INSERT INTO dh_admin.master_data (id, category, code, label, parent_code, sort_order, active, created_by) VALUES (gen_random_uuid(), 'EXPERIENCE_BAND', '6_7', '6 - 7 Years', NULL, 50, TRUE, 'flyway') ON CONFLICT (category, code) DO NOTHING;
INSERT INTO dh_admin.master_data (id, category, code, label, parent_code, sort_order, active, created_by) VALUES (gen_random_uuid(), 'EXPERIENCE_BAND', '8_PLUS', '8+ Years', NULL, 60, TRUE, 'flyway') ON CONFLICT (category, code) DO NOTHING;
INSERT INTO dh_admin.master_data (id, category, code, label, parent_code, sort_order, active, created_by) VALUES (gen_random_uuid(), 'SOURCE', 'AGS_HR', 'AGS HR', NULL, 10, TRUE, 'flyway') ON CONFLICT (category, code) DO NOTHING;
INSERT INTO dh_admin.master_data (id, category, code, label, parent_code, sort_order, active, created_by) VALUES (gen_random_uuid(), 'SOURCE', 'AGS_EMPLYOEE', 'Employee referral (ERS)', NULL, 20, TRUE, 'flyway') ON CONFLICT (category, code) DO NOTHING;
INSERT INTO dh_admin.master_data (id, category, code, label, parent_code, sort_order, active, created_by) VALUES (gen_random_uuid(), 'SOURCE', 'VENDOR', 'Vendor', NULL, 30, TRUE, 'flyway') ON CONFLICT (category, code) DO NOTHING;
INSERT INTO dh_admin.master_data (id, category, code, label, parent_code, sort_order, active, created_by) VALUES (gen_random_uuid(), 'SOURCE', 'FRIEND', 'Friend', NULL, 40, TRUE, 'flyway') ON CONFLICT (category, code) DO NOTHING;
INSERT INTO dh_admin.master_data (id, category, code, label, parent_code, sort_order, active, created_by) VALUES (gen_random_uuid(), 'SOURCE', 'CAREER_PORTAL', 'Career portal', NULL, 50, TRUE, 'flyway') ON CONFLICT (category, code) DO NOTHING;
INSERT INTO dh_admin.master_data (id, category, code, label, parent_code, sort_order, active, created_by) VALUES (gen_random_uuid(), 'SOURCE', 'WALK_IN', 'Walk-in', NULL, 60, TRUE, 'flyway') ON CONFLICT (category, code) DO NOTHING;
INSERT INTO dh_admin.master_data (id, category, code, label, parent_code, sort_order, active, created_by) VALUES (gen_random_uuid(), 'SOURCE', 'CAMPUS', 'Campus', NULL, 70, TRUE, 'flyway') ON CONFLICT (category, code) DO NOTHING;
INSERT INTO dh_admin.master_data (id, category, code, label, parent_code, sort_order, active, created_by) VALUES (gen_random_uuid(), 'SOURCE', 'SOCIAL', 'Social platforms', NULL, 80, TRUE, 'flyway') ON CONFLICT (category, code) DO NOTHING;
INSERT INTO dh_admin.master_data (id, category, code, label, parent_code, sort_order, active, created_by) VALUES (gen_random_uuid(), 'REJECTION_REASON', 'COMMUNICATION', 'Communication skills not meeting requirement', NULL, 10, TRUE, 'flyway') ON CONFLICT (category, code) DO NOTHING;
INSERT INTO dh_admin.master_data (id, category, code, label, parent_code, sort_order, active, created_by) VALUES (gen_random_uuid(), 'REJECTION_REASON', 'TECHNICAL', 'Technical / domain knowledge gap', NULL, 20, TRUE, 'flyway') ON CONFLICT (category, code) DO NOTHING;
INSERT INTO dh_admin.master_data (id, category, code, label, parent_code, sort_order, active, created_by) VALUES (gen_random_uuid(), 'REJECTION_REASON', 'ASSESSMENT_FAILED', 'Assessment not cleared', NULL, 30, TRUE, 'flyway') ON CONFLICT (category, code) DO NOTHING;
INSERT INTO dh_admin.master_data (id, category, code, label, parent_code, sort_order, active, created_by) VALUES (gen_random_uuid(), 'REJECTION_REASON', 'SALARY_MISMATCH', 'Salary expectation mismatch', NULL, 40, TRUE, 'flyway') ON CONFLICT (category, code) DO NOTHING;
INSERT INTO dh_admin.master_data (id, category, code, label, parent_code, sort_order, active, created_by) VALUES (gen_random_uuid(), 'REJECTION_REASON', 'SHIFT_NOT_OK', 'Not comfortable with shift / location', NULL, 50, TRUE, 'flyway') ON CONFLICT (category, code) DO NOTHING;
INSERT INTO dh_admin.master_data (id, category, code, label, parent_code, sort_order, active, created_by) VALUES (gen_random_uuid(), 'REJECTION_REASON', 'PHOTO_ID_MISMATCH', 'Photo / ID mismatch', NULL, 60, TRUE, 'flyway') ON CONFLICT (category, code) DO NOTHING;
INSERT INTO dh_admin.master_data (id, category, code, label, parent_code, sort_order, active, created_by) VALUES (gen_random_uuid(), 'REJECTION_REASON', 'NO_SHOW', 'Did not attend', NULL, 70, TRUE, 'flyway') ON CONFLICT (category, code) DO NOTHING;
INSERT INTO dh_admin.master_data (id, category, code, label, parent_code, sort_order, active, created_by) VALUES (gen_random_uuid(), 'REJECTION_REASON', 'OTHER', 'Other', NULL, 80, TRUE, 'flyway') ON CONFLICT (category, code) DO NOTHING;
INSERT INTO dh_admin.master_data (id, category, code, label, parent_code, sort_order, active, created_by) VALUES (gen_random_uuid(), 'HOLD_REASON', 'NO_POSITIONS', 'No positions available - moved to pipeline', NULL, 10, TRUE, 'flyway') ON CONFLICT (category, code) DO NOTHING;
INSERT INTO dh_admin.master_data (id, category, code, label, parent_code, sort_order, active, created_by) VALUES (gen_random_uuid(), 'HOLD_REASON', 'CANDIDATE_REQUEST', 'Candidate requested later date', NULL, 20, TRUE, 'flyway') ON CONFLICT (category, code) DO NOTHING;
INSERT INTO dh_admin.master_data (id, category, code, label, parent_code, sort_order, active, created_by) VALUES (gen_random_uuid(), 'HOLD_REASON', 'DOCUMENTS_PENDING', 'Documents pending', NULL, 30, TRUE, 'flyway') ON CONFLICT (category, code) DO NOTHING;
INSERT INTO dh_admin.master_data (id, category, code, label, parent_code, sort_order, active, created_by) VALUES (gen_random_uuid(), 'HOLD_REASON', 'OTHER', 'Other', NULL, 40, TRUE, 'flyway') ON CONFLICT (category, code) DO NOTHING;
INSERT INTO dh_admin.master_data (id, category, code, label, parent_code, sort_order, active, created_by) VALUES (gen_random_uuid(), 'INTERVIEW_MODE', 'WALK_IN', 'Walk-in (in-office)', NULL, 10, TRUE, 'flyway') ON CONFLICT (category, code) DO NOTHING;
INSERT INTO dh_admin.master_data (id, category, code, label, parent_code, sort_order, active, created_by) VALUES (gen_random_uuid(), 'INTERVIEW_MODE', 'ONLINE', 'Online', NULL, 20, TRUE, 'flyway') ON CONFLICT (category, code) DO NOTHING;

-- enterprise configuration (admin-only to change)
INSERT INTO dh_admin.enterprise_config (config_key, config_value, value_type, category, description, created_by) VALUES ('assessment.versant.pass-score', '43', 'NUMBER', 'ASSESSMENT', 'Versant GSE pass cut-off', 'flyway') ON CONFLICT (config_key) DO NOTHING;
INSERT INTO dh_admin.enterprise_config (config_key, config_value, value_type, category, description, created_by) VALUES ('assessment.score-validity-days', '60', 'NUMBER', 'ASSESSMENT', 'Assessment scores older than this push candidate to Fresher Pipeline (BRD 4.7)', 'flyway') ON CONFLICT (config_key) DO NOTHING;
INSERT INTO dh_admin.enterprise_config (config_key, config_value, value_type, category, description, created_by) VALUES ('assessment.cooling-days.shl', '[7,30,180]', 'LIST', 'ASSESSMENT', 'SHL cooling periods per attempt (BRD 4.8)', 'flyway') ON CONFLICT (config_key) DO NOTHING;
INSERT INTO dh_admin.enterprise_config (config_key, config_value, value_type, category, description, created_by) VALUES ('assessment.cooling-days.versant', '[15,45,180]', 'LIST', 'ASSESSMENT', 'Versant cooling periods per attempt (BRD 4.8)', 'flyway') ON CONFLICT (config_key) DO NOTHING;
INSERT INTO dh_admin.enterprise_config (config_key, config_value, value_type, category, description, created_by) VALUES ('panel.orc-reapply-block-days', '60', 'NUMBER', 'INTERVIEW', 'Rejected for an ORC cannot reapply to same ORC (BRD 4.12)', 'flyway') ON CONFLICT (config_key) DO NOTHING;
INSERT INTO dh_admin.enterprise_config (config_key, config_value, value_type, category, description, created_by) VALUES ('voice-fresher.chennai-reject-block-days', '180', 'NUMBER', 'INTERVIEW', 'Voice Fresher Chennai rejection block (BRD 4.8)', 'flyway') ON CONFLICT (config_key) DO NOTHING;
INSERT INTO dh_admin.enterprise_config (config_key, config_value, value_type, category, description, created_by) VALUES ('vendor.auto-archive-business-days', '7', 'NUMBER', 'VENDOR', 'Archive vendor profiles not registered within N business days (BRD 4.19)', 'flyway') ON CONFLICT (config_key) DO NOTHING;
INSERT INTO dh_admin.enterprise_config (config_key, config_value, value_type, category, description, created_by) VALUES ('notification.sender-name', 'AGS Health Talent Acquisition', 'STRING', 'NOTIFICATION', 'Display name for candidate emails', 'flyway') ON CONFLICT (config_key) DO NOTHING;
INSERT INTO dh_admin.enterprise_config (config_key, config_value, value_type, category, description, created_by) VALUES ('notification.company-name', 'AGS Health', 'STRING', 'NOTIFICATION', 'Company name token', 'flyway') ON CONFLICT (config_key) DO NOTHING;
INSERT INTO dh_admin.enterprise_config (config_key, config_value, value_type, category, description, created_by) VALUES ('audit.retention-days', '730', 'NUMBER', 'AUDIT', 'Informational - effective value comes from AUDIT_RETENTION_DAYS (DEP-S1-05)', 'flyway') ON CONFLICT (config_key) DO NOTHING;
