-- =====================================================================================================
-- admin-services schema (Phase 5 / Sprint 1)
-- Lives in the shared smartiedb, isolated in its own schemas so it never collides with the
-- Hibernate ddl-auto tables of the existing services.
-- =====================================================================================================

-- ---------- RBAC ----------
CREATE TABLE IF NOT EXISTS dh_admin.role (
    id            UUID PRIMARY KEY,
    code          VARCHAR(50)  NOT NULL UNIQUE,
    name          VARCHAR(100) NOT NULL,
    description   VARCHAR(500),
    scope_level   VARCHAR(20)  NOT NULL DEFAULT 'OWN',   -- NONE | OWN | TEAM | LOB | LOCATION | ALL
    system_role   BOOLEAN      NOT NULL DEFAULT FALSE,   -- seeded roles cannot be deleted
    active        BOOLEAN      NOT NULL DEFAULT TRUE,
    created_at    TIMESTAMPTZ  NOT NULL DEFAULT now(),
    created_by    VARCHAR(100),
    updated_at    TIMESTAMPTZ,
    updated_by    VARCHAR(100),
    row_version   BIGINT       NOT NULL DEFAULT 0
);

CREATE TABLE IF NOT EXISTS dh_admin.permission (
    id           UUID PRIMARY KEY,
    code         VARCHAR(80)  NOT NULL UNIQUE,            -- OBJECT:ACTION
    object_type  VARCHAR(40)  NOT NULL,
    action       VARCHAR(40)  NOT NULL,
    description  VARCHAR(300)
);

CREATE TABLE IF NOT EXISTS dh_admin.role_permission (
    role_id        UUID NOT NULL REFERENCES dh_admin.role (id) ON DELETE CASCADE,
    permission_id  UUID NOT NULL REFERENCES dh_admin.permission (id) ON DELETE CASCADE,
    PRIMARY KEY (role_id, permission_id)
);

-- Factory defaults (tracker #1-3 "default permission set"), used by "reset role to defaults".
CREATE TABLE IF NOT EXISTS dh_admin.default_role_permission (
    role_code        VARCHAR(50) NOT NULL,
    permission_code  VARCHAR(80) NOT NULL,
    PRIMARY KEY (role_code, permission_code)
);

CREATE TABLE IF NOT EXISTS dh_admin.app_user (
    id               UUID PRIMARY KEY,
    smartie_user_id  UUID UNIQUE,                        -- smartieuser.id; back-filled on first request
    email            VARCHAR(254) NOT NULL UNIQUE,       -- always lower case
    full_name        VARCHAR(200) NOT NULL,
    employee_code    VARCHAR(50),
    user_type        VARCHAR(40)  NOT NULL DEFAULT 'EMPLOYEE_HR',
    status           VARCHAR(20)  NOT NULL DEFAULT 'ACTIVE', -- ACTIVE | INACTIVE
    manager_id       UUID REFERENCES dh_admin.app_user (id),
    created_at       TIMESTAMPTZ  NOT NULL DEFAULT now(),
    created_by       VARCHAR(100),
    updated_at       TIMESTAMPTZ,
    updated_by       VARCHAR(100),
    row_version      BIGINT       NOT NULL DEFAULT 0
);
CREATE INDEX IF NOT EXISTS ix_app_user_manager ON dh_admin.app_user (manager_id);
CREATE INDEX IF NOT EXISTS ix_app_user_name ON dh_admin.app_user (lower(full_name));

CREATE TABLE IF NOT EXISTS dh_admin.user_role (
    user_id  UUID NOT NULL REFERENCES dh_admin.app_user (id) ON DELETE CASCADE,
    role_id  UUID NOT NULL REFERENCES dh_admin.role (id) ON DELETE CASCADE,
    PRIMARY KEY (user_id, role_id)
);

-- Granular user-based permission definition (tracker #24): ALLOW adds, DENY removes.
CREATE TABLE IF NOT EXISTS dh_admin.user_permission (
    user_id          UUID        NOT NULL REFERENCES dh_admin.app_user (id) ON DELETE CASCADE,
    permission_code  VARCHAR(80) NOT NULL,
    effect           VARCHAR(10) NOT NULL,               -- ALLOW | DENY
    PRIMARY KEY (user_id, permission_code)
);

-- Data scope assignments (tracker #5): LOB / LOCATION values.
CREATE TABLE IF NOT EXISTS dh_admin.user_scope (
    user_id    UUID         NOT NULL REFERENCES dh_admin.app_user (id) ON DELETE CASCADE,
    dimension  VARCHAR(20)  NOT NULL,                    -- LOB | LOCATION
    value      VARCHAR(100) NOT NULL,
    PRIMARY KEY (user_id, dimension, value)
);

-- Override / shared-candidate access with approver authorization (tracker #6, #8).
CREATE TABLE IF NOT EXISTS dh_admin.access_request (
    id                UUID PRIMARY KEY,
    requester_id      VARCHAR(100) NOT NULL,             -- smartieuser id from JWT
    requester_email   VARCHAR(254),
    requester_name    VARCHAR(200),
    object_type       VARCHAR(40)  NOT NULL,             -- CANDIDATE | APPLICATION | JOB
    object_id         VARCHAR(100),                      -- null = permission override not tied to one record
    permission_code   VARCHAR(80),
    reason            VARCHAR(1000) NOT NULL,
    status            VARCHAR(20)  NOT NULL,             -- PENDING | APPROVED | REJECTED | REVOKED
    valid_days        INT          NOT NULL,
    valid_until       TIMESTAMPTZ,
    approver_id       VARCHAR(100),
    approver_email    VARCHAR(254),
    decided_at        TIMESTAMPTZ,
    decision_remarks  VARCHAR(1000),
    created_at        TIMESTAMPTZ  NOT NULL DEFAULT now(),
    created_by        VARCHAR(100),
    updated_at        TIMESTAMPTZ,
    updated_by        VARCHAR(100),
    row_version       BIGINT       NOT NULL DEFAULT 0
);
CREATE INDEX IF NOT EXISTS ix_access_request_requester ON dh_admin.access_request (requester_id, status);
CREATE INDEX IF NOT EXISTS ix_access_request_status ON dh_admin.access_request (status, created_at DESC);

-- ---------- Enterprise configuration (tracker #32) ----------
CREATE TABLE IF NOT EXISTS dh_admin.enterprise_config (
    config_key    VARCHAR(150) PRIMARY KEY,
    config_value  TEXT,
    value_type    VARCHAR(20)  NOT NULL DEFAULT 'STRING', -- STRING | NUMBER | BOOLEAN | JSON | LIST
    category      VARCHAR(60)  NOT NULL DEFAULT 'GENERAL',
    description   VARCHAR(500),
    created_at    TIMESTAMPTZ  NOT NULL DEFAULT now(),
    created_by    VARCHAR(100),
    updated_at    TIMESTAMPTZ,
    updated_by    VARCHAR(100),
    row_version   BIGINT       NOT NULL DEFAULT 0
);

-- ---------- Role-driven dynamic search filters (tracker #4) ----------
CREATE TABLE IF NOT EXISTS dh_admin.search_filter (
    id                 UUID PRIMARY KEY,
    screen             VARCHAR(60)  NOT NULL,            -- CANDIDATE_LIST | APPLICANT_LIST | OPEN_POSITIONS | INTERVIEWS | MY_REFERRALS ...
    filter_key         VARCHAR(60)  NOT NULL,            -- request parameter name the list API understands
    label              VARCHAR(100) NOT NULL,
    filter_type        VARCHAR(20)  NOT NULL,            -- MULTI_SELECT | SELECT | DATE_RANGE | RANGE | TEXT | BOOLEAN
    options_source     VARCHAR(100),                     -- STATIC | MASTER_DATA:<category> | USERS:<role> | WORKFLOW_STATES:<code>
    static_options     TEXT,                             -- JSON array [{"value":"..","label":".."}] when STATIC
    allowed_roles      VARCHAR(500),                     -- CSV, null = everyone
    restrict_to_scope  BOOLEAN      NOT NULL DEFAULT FALSE, -- limit LOB/LOCATION options to the user's own scope
    sort_order         INT          NOT NULL DEFAULT 0,
    active             BOOLEAN      NOT NULL DEFAULT TRUE,
    created_at         TIMESTAMPTZ  NOT NULL DEFAULT now(),
    created_by         VARCHAR(100),
    updated_at         TIMESTAMPTZ,
    updated_by         VARCHAR(100),
    row_version        BIGINT       NOT NULL DEFAULT 0,
    UNIQUE (screen, filter_key)
);

-- ---------- Master data (DEP-S1-03: role, LOB, location master) ----------
CREATE TABLE IF NOT EXISTS dh_admin.master_data (
    id           UUID PRIMARY KEY,
    category     VARCHAR(60)  NOT NULL,                  -- LOB | LOCATION | COUNTRY | SHIFT | JOB_TYPE | REJECTION_REASON | HOLD_REASON ...
    code         VARCHAR(100) NOT NULL,
    label        VARCHAR(200) NOT NULL,
    parent_code  VARCHAR(100),                           -- e.g. LOCATION -> COUNTRY
    sort_order   INT          NOT NULL DEFAULT 0,
    active       BOOLEAN      NOT NULL DEFAULT TRUE,
    created_at   TIMESTAMPTZ  NOT NULL DEFAULT now(),
    created_by   VARCHAR(100),
    updated_at   TIMESTAMPTZ,
    updated_by   VARCHAR(100),
    row_version  BIGINT       NOT NULL DEFAULT 0,
    UNIQUE (category, code)
);

-- ---------- Central audit log (tracker #9-14) ----------
-- Written by every service through digihire-platform-starter (JdbcAuditLogger); read by the Admin log viewer.
CREATE TABLE IF NOT EXISTS dh_audit.audit_log (
    id              UUID PRIMARY KEY,
    category        VARCHAR(30)  NOT NULL,               -- ACTIVITY | APPROVAL | WORKFLOW_TRANSITION | CONFIG_CHANGE | SECURITY | NOTIFICATION
    action          VARCHAR(100) NOT NULL,
    entity_type     VARCHAR(60),
    entity_id       VARCHAR(100),
    candidate_id    VARCHAR(100),                        -- candidate audit mapping
    actor_id        VARCHAR(100),
    actor_name      VARCHAR(200),
    actor_email     VARCHAR(254),
    actor_roles     VARCHAR(500),
    outcome         VARCHAR(10)  NOT NULL DEFAULT 'SUCCESS',
    description     VARCHAR(2000),
    details         JSONB,
    correlation_id  VARCHAR(64),
    service_name    VARCHAR(60),
    client_ip       VARCHAR(64),
    occurred_at     TIMESTAMPTZ  NOT NULL
);
CREATE INDEX IF NOT EXISTS ix_audit_occurred     ON dh_audit.audit_log (occurred_at DESC);
CREATE INDEX IF NOT EXISTS ix_audit_category     ON dh_audit.audit_log (category, occurred_at DESC);
CREATE INDEX IF NOT EXISTS ix_audit_entity       ON dh_audit.audit_log (entity_type, entity_id);
CREATE INDEX IF NOT EXISTS ix_audit_candidate    ON dh_audit.audit_log (candidate_id, occurred_at DESC);
CREATE INDEX IF NOT EXISTS ix_audit_actor        ON dh_audit.audit_log (actor_id, occurred_at DESC);
CREATE INDEX IF NOT EXISTS ix_audit_correlation  ON dh_audit.audit_log (correlation_id);
