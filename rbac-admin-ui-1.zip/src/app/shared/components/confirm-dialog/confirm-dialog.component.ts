import { Component, Inject } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogModule, MatDialogRef } from '@angular/material/dialog';
import { MatButtonModule } from '@angular/material/button';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

export interface ConfirmDialogData {
  title: string;
  message: string;
  confirmLabel?: string;
  cancelLabel?: string;
  /** When true, renders the confirm button in warn color (destructive/irreversible actions). */
  destructive?: boolean;
  /** Optional free-text remarks field (used by deactivate/approve/reject/revoke flows that accept remarks). */
  requireRemarks?: boolean;
}

@Component({
  selector: 'app-confirm-dialog',
  standalone: true,
  imports: [CommonModule, FormsModule, MatDialogModule, MatButtonModule, MatFormFieldModule, MatInputModule],
  template: `
    <h2 mat-dialog-title>{{ data.title }}</h2>
    <div mat-dialog-content>
      <p>{{ data.message }}</p>
      @if (data.requireRemarks) {
        <mat-form-field appearance="outline" style="width: 100%">
          <mat-label>Remarks (optional)</mat-label>
          <textarea matInput [(ngModel)]="remarks" rows="2" maxlength="1000"></textarea>
        </mat-form-field>
      }
    </div>
    <div mat-dialog-actions align="end">
      <button mat-button (click)="dialogRef.close(null)">{{ data.cancelLabel ?? 'Cancel' }}</button>
      <button mat-raised-button [color]="data.destructive ? 'warn' : 'primary'"
              (click)="dialogRef.close(data.requireRemarks ? { remarks } : true)">
        {{ data.confirmLabel ?? 'Confirm' }}
      </button>
    </div>
  `,
})
export class ConfirmDialogComponent {
  remarks = '';

  constructor(
    public dialogRef: MatDialogRef<ConfirmDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: ConfirmDialogData,
  ) {}
}
