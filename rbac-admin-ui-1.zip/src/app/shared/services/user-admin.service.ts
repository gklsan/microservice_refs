import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../../environments/environment';
import {
  AdminUser, AssignRolesRequest, CreateUserRequest, PageResponse,
  RemarksRequest, UpdateUserRequest, UserPermissionsRequest, UserStatus,
} from '../../interfaces/rbac.models';

/** GET/POST/PUT/PATCH only — admin-services has no DELETE for users; deactivate/reactivate instead. */
@Injectable({ providedIn: 'root' })
export class UserAdminService {
  private readonly base = `${environment.apiUrl}/admin/users`;

  constructor(private http: HttpClient) {}

  search(opts: { search?: string; status?: UserStatus; role?: string; page?: number; size?: number }): Observable<PageResponse<AdminUser>> {
    let params = new HttpParams()
      .set('page', String(opts.page ?? 0))
      .set('size', String(opts.size ?? 20));
    if (opts.search) params = params.set('search', opts.search);
    if (opts.status) params = params.set('status', opts.status);
    if (opts.role) params = params.set('role', opts.role);
    return this.http.get<PageResponse<AdminUser>>(this.base, { params });
  }

  get(id: string): Observable<AdminUser> {
    return this.http.get<AdminUser>(`${this.base}/${id}`);
  }

  create(req: CreateUserRequest): Observable<AdminUser> {
    return this.http.post<AdminUser>(this.base, req);
  }

  update(id: string, req: UpdateUserRequest): Observable<AdminUser> {
    return this.http.put<AdminUser>(`${this.base}/${id}`, req);
  }

  /** 409 LAST_ADMIN if this is the last active administrator. */
  deactivate(id: string, remarks?: string): Observable<AdminUser> {
    const body: RemarksRequest = { remarks };
    return this.http.patch<AdminUser>(`${this.base}/${id}/deactivate`, body);
  }

  reactivate(id: string, remarks?: string): Observable<AdminUser> {
    const body: RemarksRequest = { remarks };
    return this.http.patch<AdminUser>(`${this.base}/${id}/reactivate`, body);
  }

  /** Full replace of the user's role set. 409 LAST_ADMIN if it would strip ADMIN from the last active admin. */
  assignRoles(id: string, req: AssignRolesRequest): Observable<AdminUser> {
    return this.http.put<AdminUser>(`${this.base}/${id}/roles`, req);
  }

  /** Full replace of the user's ALLOW/DENY permission grants (on top of role permissions). */
  setPermissions(id: string, req: UserPermissionsRequest): Observable<AdminUser> {
    return this.http.put<AdminUser>(`${this.base}/${id}/permissions`, req);
  }
}
