import { HttpErrorResponse } from '@angular/common/http';
import { ApiErrorBody, KnownErrorCode } from '../../interfaces/rbac.models';

/** Error bodies are always {"message": "..."} — RFC 7807 rendering is disabled in application.yml. */
export function apiErrorMessage(err: unknown, fallback = 'Something went wrong. Please try again.'): string {
  if (err instanceof HttpErrorResponse) {
    const body = err.error as ApiErrorBody | undefined;
    if (body?.message) return body.message;
  }
  return fallback;
}

/**
 * The server doesn't send a machine-readable `code` field today (message text only) — this matches
 * on the known message prefixes admin-services throws (see RoleService/UserAdminService/AccessRequestService).
 * Prefer branching UI behavior on these over string-matching the full message, which can change wording.
 */
export function apiErrorLooksLike(err: unknown, code: KnownErrorCode): boolean {
  const msg = apiErrorMessage(err, '');
  switch (code) {
    case 'LAST_ADMIN': return /last active administrator/i.test(msg);
    case 'ADMIN_ROLE_LOCKED': return /ADMIN (role )?(cannot be deactivated|must keep)/i.test(msg);
    case 'INVALID_MANAGER': return /(report to himself|Manager not found|Reporting line would create a cycle)/i.test(msg);
    case 'UNKNOWN_PERMISSION': return /Unknown permission/i.test(msg);
    case 'UNKNOWN_ROLE': return /Unknown role/i.test(msg);
    case 'VALIDITY_TOO_LONG': return /Maximum validity is/i.test(msg);
    case 'INVALID_CONFIG_VALUE': return /is not a valid/i.test(msg);
    case 'RESERVED_ROLE': return /reserved for service-to-service/i.test(msg);
    case 'ROLE_EXISTS': return /Role already exists/i.test(msg);
    case 'USER_EXISTS': return /user with email .* already exists/i.test(msg);
    case 'CONFIG_EXISTS': return /Configuration already exists/i.test(msg);
    case 'NO_DEFAULTS': return /no factory default permission set/i.test(msg);
    case 'TARGET_REQUIRED': return /Either objectId or permissionCode is required/i.test(msg);
    case 'ALREADY_DECIDED': return /already/i.test(msg) && /PENDING|APPROVED|REJECTED|REVOKED/.test(msg);
    case 'NOT_REVOCABLE': return /Request is/i.test(msg);
    default: return false;
  }
}
