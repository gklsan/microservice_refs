import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../../environments/environment';
import { MasterDataItem, MasterDataRequest, SearchFilterConfig, SearchFilterRequest } from '../../interfaces/rbac.models';

@Injectable({ providedIn: 'root' })
export class MasterDataService {
  private readonly base = environment.apiUrl;

  constructor(private http: HttpClient) {}

  list(category: string, includeInactive = false): Observable<MasterDataItem[]> {
    const params = new HttpParams().set('includeInactive', includeInactive);
    return this.http.get<MasterDataItem[]>(`${this.base}/master-data/${category.toUpperCase()}`, { params });
  }

  /** Upsert by code. Requires MASTER_DATA:MANAGE. */
  save(category: string, req: MasterDataRequest): Observable<MasterDataItem> {
    return this.http.post<MasterDataItem>(`${this.base}/admin/master-data/${category.toUpperCase()}`, req);
  }

  listFilters(screen?: string): Observable<SearchFilterConfig[]> {
    let params = new HttpParams();
    if (screen) params = params.set('screen', screen.toUpperCase());
    return this.http.get<SearchFilterConfig[]>(`${this.base}/admin/search-filters`, { params });
  }

  /** ADMIN role + CONFIG:MANAGE. */
  createFilter(req: SearchFilterRequest): Observable<SearchFilterConfig> {
    return this.http.post<SearchFilterConfig>(`${this.base}/admin/search-filters`, req);
  }

  updateFilter(id: string, req: SearchFilterRequest): Observable<SearchFilterConfig> {
    return this.http.put<SearchFilterConfig>(`${this.base}/admin/search-filters/${id}`, req);
  }
}
