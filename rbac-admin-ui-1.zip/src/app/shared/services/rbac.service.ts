import { Injectable, signal } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, tap } from 'rxjs';
import { environment } from '../../../environments/environment';
import { CheckRequest, CheckResponse, FilterDefinition, MeResponse } from '../../interfaces/rbac.models';

/**
 * Caller-facing RBAC endpoints (/rbac/**). Fetch `me()` once on login / app bootstrap and cache it —
 * there's no JWT-embedded permission claim here, every check is resolved live server-side.
 */
@Injectable({ providedIn: 'root' })
export class RbacService {
  private readonly base = `${environment.apiUrl}/rbac`;

  /** Cached effective access of the current user. Read via `me()` signal, refresh with `loadMe()`. */
  private readonly meSignal = signal<MeResponse | null>(null);
  readonly me = this.meSignal.asReadonly();

  constructor(private http: HttpClient) {}

  loadMe(): Observable<MeResponse> {
    return this.http.get<MeResponse>(`${this.base}/me`).pipe(tap((res) => this.meSignal.set(res)));
  }

  /** True once `loadMe()` has resolved and the permission is present. Returns false, not throws, before that. */
  hasPermission(permission: string): boolean {
    return this.meSignal()?.permissions.includes(permission) ?? false;
  }

  hasRole(roleCode: string): boolean {
    return this.meSignal()?.roles.includes(roleCode) ?? false;
  }

  /** Record-level check the frontend can't derive from `me()` alone (owner/team/LOB/location/shared logic). */
  check(req: CheckRequest): Observable<CheckResponse> {
    return this.http.post<CheckResponse>(`${this.base}/check`, req);
  }

  filtersFor(screen: string): Observable<FilterDefinition[]> {
    return this.http.get<FilterDefinition[]>(`${this.base}/filters/${screen.toUpperCase()}`);
  }

  /** Admin troubleshooting: view another user's effective access. Requires USER:VIEW. */
  effectiveOf(params: { userId?: string; email?: string; userType?: string }): Observable<MeResponse> {
    return this.http.get<MeResponse>(`${this.base}/effective`, { params: params as any });
  }
}
