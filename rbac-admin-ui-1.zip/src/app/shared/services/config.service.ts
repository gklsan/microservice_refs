import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../../environments/environment';
import { ConfigCreateRequest, ConfigUpdateRequest, EnterpriseConfig } from '../../interfaces/rbac.models';

@Injectable({ providedIn: 'root' })
export class ConfigService {
  private readonly base = `${environment.apiUrl}/admin/config`;

  constructor(private http: HttpClient) {}

  list(category?: string): Observable<EnterpriseConfig[]> {
    let params = new HttpParams();
    if (category) params = params.set('category', category);
    return this.http.get<EnterpriseConfig[]>(this.base, { params });
  }

  get(key: string): Observable<EnterpriseConfig> {
    return this.http.get<EnterpriseConfig>(`${this.base}/${key}`);
  }

  /** ADMIN role + CONFIG:MANAGE. 409 CONFIG_EXISTS if the key is taken. */
  create(req: ConfigCreateRequest): Observable<EnterpriseConfig> {
    return this.http.post<EnterpriseConfig>(this.base, req);
  }

  /** Value is type-checked server-side against the existing valueType — 400 INVALID_CONFIG_VALUE on mismatch. */
  update(key: string, req: ConfigUpdateRequest): Observable<EnterpriseConfig> {
    return this.http.put<EnterpriseConfig>(`${this.base}/${key}`, req);
  }
}
