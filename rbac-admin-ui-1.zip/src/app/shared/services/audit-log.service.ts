import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../../environments/environment';
import { AuditQuery, AuditRow, PageResponse } from '../../interfaces/rbac.models';

@Injectable({ providedIn: 'root' })
export class AuditLogService {
  private readonly base = `${environment.apiUrl}/admin/audit-logs`;

  constructor(private http: HttpClient) {}

  search(q: AuditQuery): Observable<PageResponse<AuditRow>> {
    let params = new HttpParams().set('page', q.page ?? 0).set('size', q.size ?? 50);
    if (q.category?.length) q.category.forEach((c) => (params = params.append('category', c)));
    if (q.action) params = params.set('action', q.action);
    if (q.actor) params = params.set('actor', q.actor);
    if (q.entityType) params = params.set('entityType', q.entityType);
    if (q.entityId) params = params.set('entityId', q.entityId);
    if (q.candidateId) params = params.set('candidateId', q.candidateId);
    if (q.service) params = params.set('service', q.service);
    if (q.outcome) params = params.set('outcome', q.outcome);
    if (q.correlationId) params = params.set('correlationId', q.correlationId);
    if (q.from) params = params.set('from', q.from);
    if (q.to) params = params.set('to', q.to);
    if (q.q) params = params.set('q', q.q);
    return this.http.get<PageResponse<AuditRow>>(this.base, { params });
  }

  /** Full candidate timeline (workflow moves, emails, approvals), capped at 1000 rows server-side. */
  candidateTimeline(candidateId: string): Observable<AuditRow[]> {
    return this.http.get<AuditRow[]>(`${this.base}/candidates/${candidateId}`);
  }

  /**
   * Triggers a CSV download via a plain navigation (not HttpClient) so the browser handles the
   * `Content-Disposition: attachment` response — an XHR blob round-trip isn't needed for this size.
   * Requires AUDIT_LOG:EXPORT. Capped server-side by digihire.admin.audit.max-export-rows (default 50,000).
   */
  exportCsvUrl(q: Omit<AuditQuery, 'page' | 'size' | 'q'>): string {
    let params = new HttpParams();
    if (q.category?.length) q.category.forEach((c) => (params = params.append('category', c)));
    if (q.actor) params = params.set('actor', q.actor);
    if (q.entityType) params = params.set('entityType', q.entityType);
    if (q.entityId) params = params.set('entityId', q.entityId);
    if (q.candidateId) params = params.set('candidateId', q.candidateId);
    if (q.from) params = params.set('from', q.from);
    if (q.to) params = params.set('to', q.to);
    return `${this.base}/export?${params.toString()}`;
  }
}
