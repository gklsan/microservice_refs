import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../../environments/environment';
import { Permission, PermissionMatrix, Role, RoleRequest } from '../../interfaces/rbac.models';

/** No DELETE — roles are retired by setting `active: false` via update(). ADMIN role can't be deactivated. */
@Injectable({ providedIn: 'root' })
export class RoleService {
  private readonly base = `${environment.apiUrl}/admin`;

  constructor(private http: HttpClient) {}

  list(): Observable<Role[]> {
    return this.http.get<Role[]>(`${this.base}/roles`);
  }

  get(code: string): Observable<Role> {
    return this.http.get<Role>(`${this.base}/roles/${code}`);
  }

  create(req: RoleRequest): Observable<Role> {
    return this.http.post<Role>(`${this.base}/roles`, req);
  }

  /** 400 ADMIN_ROLE_LOCKED if this would strip a locked permission from ADMIN or deactivate it. */
  update(code: string, req: RoleRequest): Observable<Role> {
    return this.http.put<Role>(`${this.base}/roles/${code}`, req);
  }

  resetToDefaults(code: string): Observable<Role> {
    return this.http.post<Role>(`${this.base}/roles/${code}/reset-defaults`, {});
  }

  permissionCatalogue(): Observable<Permission[]> {
    return this.http.get<Permission[]>(`${this.base}/permissions`);
  }

  matrix(): Observable<PermissionMatrix> {
    return this.http.get<PermissionMatrix>(`${this.base}/permission-matrix`);
  }

  /** Bulk save — only roles present in `grants` are changed server-side. */
  saveMatrix(grants: Record<string, string[]>): Observable<PermissionMatrix> {
    return this.http.put<PermissionMatrix>(`${this.base}/permission-matrix`, { grants });
  }

  defaultPermissionSets(objectType?: string): Observable<Record<string, string[]>> {
    let params = new HttpParams();
    if (objectType) params = params.set('objectType', objectType);
    return this.http.get<Record<string, string[]>>(`${this.base}/permission-sets/defaults`, { params });
  }
}
