import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../../environments/environment';
import { AccessRequest, AccessRequestCreate, AccessRequestStatus, PageResponse, RemarksRequest } from '../../interfaces/rbac.models';

@Injectable({ providedIn: 'root' })
export class AccessRequestService {
  private readonly base = `${environment.apiUrl}/access-requests`;

  constructor(private http: HttpClient) {}

  /** Requires ACCESS_OVERRIDE:REQUEST. Either objectId or permissionCode must be set. */
  create(req: AccessRequestCreate): Observable<AccessRequest> {
    return this.http.post<AccessRequest>(this.base, req);
  }

  mine(page = 0, size = 20): Observable<PageResponse<AccessRequest>> {
    const params = new HttpParams().set('page', page).set('size', size);
    return this.http.get<PageResponse<AccessRequest>>(`${this.base}/mine`, { params });
  }

  /** Approver inbox. Requires ACCESS_OVERRIDE:APPROVE. */
  byStatus(status: AccessRequestStatus = 'PENDING', page = 0, size = 20): Observable<PageResponse<AccessRequest>> {
    const params = new HttpParams().set('status', status).set('page', page).set('size', size);
    return this.http.get<PageResponse<AccessRequest>>(this.base, { params });
  }

  approve(id: string, remarks?: string): Observable<AccessRequest> {
    const body: RemarksRequest = { remarks };
    return this.http.post<AccessRequest>(`${this.base}/${id}/approve`, body);
  }

  reject(id: string, remarks?: string): Observable<AccessRequest> {
    const body: RemarksRequest = { remarks };
    return this.http.post<AccessRequest>(`${this.base}/${id}/reject`, body);
  }

  /** Available to the original requester even without ACCESS_OVERRIDE:APPROVE. */
  revoke(id: string, remarks?: string): Observable<AccessRequest> {
    const body: RemarksRequest = { remarks };
    return this.http.post<AccessRequest>(`${this.base}/${id}/revoke`, body);
  }
}
