import { inject } from '@angular/core';
import { ActivatedRouteSnapshot, CanActivateFn, Router } from '@angular/router';
import { catchError, map, of } from 'rxjs';
import { RbacService } from '../services/rbac.service';

/**
 * Route guard reading a required permission off route data:
 *   { path: 'users', component: UserListComponent, canActivate: [permissionGuard], data: { permission: 'USER:VIEW' } }
 *
 * Replaces any earlier `superAdminGuard` — this module has no SUPER_ADMIN role, only OBJECT:ACTION
 * permissions resolved from GET /rbac/me. Ensure `RbacService.loadMe()` has been called once after
 * login (e.g. in an app initializer or the auth success handler) before routes using this guard fire.
 */
export const permissionGuard: CanActivateFn = (route: ActivatedRouteSnapshot) => {
  const rbac = inject(RbacService);
  const router = inject(Router);
  const required = route.data['permission'] as string | undefined;

  if (!required) {
    return true; // route didn't declare a requirement — don't accidentally lock everyone out
  }

  if (rbac.me()) {
    return rbac.hasPermission(required) ? true : router.createUrlTree(['/forbidden']);
  }

  // me() not loaded yet (e.g. deep link / page refresh) — fetch once, then decide.
  return rbac.loadMe().pipe(
    map(() => (rbac.hasPermission(required) ? true : router.createUrlTree(['/forbidden']))),
    catchError(() => of(router.createUrlTree(['/login']))),
  );
};
