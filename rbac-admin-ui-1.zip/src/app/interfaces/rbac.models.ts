// Generated against admin-services (com.ags.health.hr.admin) — see AdminDtos.java for source of truth.

export type ScopeLevel = 'NONE' | 'OWN' | 'TEAM' | 'LOB' | 'LOCATION' | 'ALL';
export type UserStatus = 'ACTIVE' | 'INACTIVE';
export type UserType = 'EMPLOYEE_HR' | 'EMPLOYEE_HR_ADMIN' | 'EMPLOYEE_NON_HR';
export type GrantEffect = 'ALLOW' | 'DENY';
export type AccessRequestStatus = 'PENDING' | 'APPROVED' | 'REJECTED' | 'REVOKED';
export type ConfigValueType = 'STRING' | 'NUMBER' | 'BOOLEAN' | 'JSON' | 'LIST';
export type FilterType = 'MULTI_SELECT' | 'SELECT' | 'DATE_RANGE' | 'RANGE' | 'TEXT' | 'BOOLEAN';
export type AuditCategory = 'ACTIVITY' | 'APPROVAL' | 'WORKFLOW_TRANSITION' | 'CONFIG_CHANGE' | 'SECURITY' | 'NOTIFICATION';

export interface PageResponse<T> {
  content: T[];
  page: number;
  size: number;
  totalElements: number;
  totalPages: number;
}

export interface RemarksRequest {
  remarks?: string;
}

// ---------------------------------------------------------------- users

export interface PermissionGrant {
  permission: string;
  effect: GrantEffect;
}

export interface CreateUserRequest {
  email: string;
  fullName: string;
  employeeCode?: string;
  userType?: UserType;
  roles: string[];
  lobs?: string[];
  locations?: string[];
  managerId?: string;
}

export interface UpdateUserRequest {
  fullName: string;
  employeeCode?: string;
  managerId?: string;
  lobs?: string[];
  locations?: string[];
}

export interface AssignRolesRequest {
  roles: string[];
}

export interface UserPermissionsRequest {
  grants: PermissionGrant[];
}

export interface AdminUser {
  id: string;
  smartieUserId: string | null;
  email: string;
  fullName: string;
  employeeCode: string | null;
  userType: UserType;
  status: UserStatus;
  managerId: string | null;
  roles: string[];
  lobs: string[];
  locations: string[];
  permissionGrants: PermissionGrant[];
  createdAt: string;
  createdBy: string | null;
  updatedAt: string | null;
  updatedBy: string | null;
}

// ---------------------------------------------------------------- roles & matrix

export interface RoleRequest {
  code: string;
  name: string;
  description?: string;
  scopeLevel: ScopeLevel;
  active?: boolean;
  permissions?: string[];
}

export interface Role {
  id: string;
  code: string;
  name: string;
  description: string | null;
  scopeLevel: ScopeLevel;
  systemRole: boolean;
  active: boolean;
  permissions: string[];
}

export interface Permission {
  code: string;
  objectType: string;
  action: string;
  description: string | null;
}

export interface PermissionMatrix {
  roles: Role[];
  permissions: Permission[];
  grants: Record<string, string[]>; // roleCode -> permission codes
}

/** ADMIN role permissions the server refuses to let you remove (RoleService.ADMIN_LOCKED). Mirror only — server is authoritative. */
export const ADMIN_LOCKED_PERMISSIONS: readonly string[] = [
  'ROLE:MANAGE', 'USER:MANAGE', 'CONFIG:MANAGE', 'ROLE:VIEW', 'USER:VIEW',
];

// ---------------------------------------------------------------- access requests

export interface AccessRequestCreate {
  objectType: 'CANDIDATE' | 'APPLICATION' | 'JOB';
  objectId?: string;
  permissionCode?: string;
  reason: string;
  validDays?: number;
}

export interface AccessRequest {
  id: string;
  requesterId: string;
  requesterEmail: string | null;
  requesterName: string | null;
  objectType: string;
  objectId: string | null;
  permissionCode: string | null;
  reason: string;
  status: AccessRequestStatus;
  validDays: number;
  validUntil: string | null;
  approverId: string | null;
  approverEmail: string | null;
  decidedAt: string | null;
  decisionRemarks: string | null;
  createdAt: string;
}

// ---------------------------------------------------------------- enterprise config

export interface ConfigCreateRequest {
  key: string;
  value: string;
  valueType: ConfigValueType;
  category: string;
  description?: string;
}

export interface ConfigUpdateRequest {
  value: string;
  description?: string;
}

export interface EnterpriseConfig {
  key: string;
  value: string;
  valueType: ConfigValueType;
  category: string;
  description: string | null;
  updatedAt: string;
  updatedBy: string | null;
  version: number;
}

// ---------------------------------------------------------------- master data & filters

export interface MasterDataRequest {
  code: string;
  label: string;
  parentCode?: string;
  sortOrder: number;
  active?: boolean;
}

export interface MasterDataItem {
  id: string;
  category: string;
  code: string;
  label: string;
  parentCode: string | null;
  sortOrder: number;
  active: boolean;
}

export interface SearchFilterRequest {
  screen: string;
  filterKey: string;
  label: string;
  filterType: FilterType;
  optionsSource?: string;
  staticOptions?: string;
  allowedRoles?: string;
  restrictToScope: boolean;
  sortOrder: number;
  active?: boolean;
}

export interface SearchFilterConfig {
  id: string;
  screen: string;
  filterKey: string;
  label: string;
  filterType: FilterType;
  optionsSource: string | null;
  staticOptions: string | null;
  allowedRoles: string | null;
  restrictToScope: boolean;
  sortOrder: number;
  active: boolean;
}

export interface FilterOption {
  value: string;
  label: string;
}

export interface FilterDefinition {
  key: string;
  label: string;
  type: FilterType;
  options: FilterOption[];
  optionsEndpoint: string | null;
  order: number;
}

// ---------------------------------------------------------------- rbac for the caller

export interface DataScope {
  level: ScopeLevel;
  ownerId: string | null;
  team: string[];
  lobs: string[];
  locations: string[];
  shared: Record<string, string[]>;
}

export interface MeResponse {
  userId: string;
  email: string;
  name: string;
  userType: string;
  roles: string[];
  permissions: string[];
  scope: DataScope;
}

export interface CheckRequest {
  permission: string;
  objectType?: string;
  objectId?: string;
  ownerId?: string;
  lob?: string;
  location?: string;
}

export interface CheckResponse {
  allowed: boolean;
  reason: string | null;
}

// ---------------------------------------------------------------- audit log

export interface AuditQuery {
  category?: AuditCategory[];
  action?: string;
  actor?: string;
  entityType?: string;
  entityId?: string;
  candidateId?: string;
  service?: string;
  outcome?: string;
  correlationId?: string;
  from?: string;  // ISO instant
  to?: string;    // ISO instant
  q?: string;
  page?: number;
  size?: number;
}

export interface AuditRow {
  id: string;
  category: AuditCategory;
  action: string;
  entityType: string | null;
  entityId: string | null;
  candidateId: string | null;
  actorId: string | null;
  actorName: string | null;
  actorEmail: string | null;
  actorRoles: string | null;
  outcome: string | null;
  description: string | null;
  details: string | null;
  correlationId: string | null;
  serviceName: string | null;
  clientIp: string | null;
  occurredAt: string;
}

// ---------------------------------------------------------------- errors

/** Body shape returned by admin-services on every 4xx (platform GlobalExceptionHandler). */
export interface ApiErrorBody {
  message: string;
  code?: string;
}

/** Business-rule codes worth branching UI behavior on (see integration doc §4). */
export const KNOWN_ERROR_CODES = [
  'LAST_ADMIN', 'ADMIN_ROLE_LOCKED', 'INVALID_MANAGER', 'UNKNOWN_PERMISSION',
  'UNKNOWN_ROLE', 'VALIDITY_TOO_LONG', 'INVALID_CONFIG_VALUE', 'RESERVED_ROLE',
  'ROLE_EXISTS', 'USER_EXISTS', 'CONFIG_EXISTS', 'NO_DEFAULTS', 'TARGET_REQUIRED',
  'ALREADY_DECIDED', 'NOT_REVOCABLE',
] as const;
export type KnownErrorCode = typeof KNOWN_ERROR_CODES[number];
