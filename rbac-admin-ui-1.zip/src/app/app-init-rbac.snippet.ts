/**
 * Wire this into your app bootstrap (main.ts / app.config.ts) so RbacService.me() is populated
 * before any permissionGuard-protected route needs it. Adjust to whatever auth-success hook your
 * app already uses — this fires once after login, not on every navigation.
 */
import { APP_INITIALIZER } from '@angular/core';
import { RbacService } from './shared/services/rbac.service';
import { catchError, of } from 'rxjs';

export function rbacInitializerFactory(rbac: RbacService) {
  return () => rbac.loadMe().pipe(catchError(() => of(null))); // not logged in yet — guard falls back to /login
}

export const RBAC_APP_INITIALIZER_PROVIDER = {
  provide: APP_INITIALIZER,
  useFactory: rbacInitializerFactory,
  deps: [RbacService],
  multi: true,
};
