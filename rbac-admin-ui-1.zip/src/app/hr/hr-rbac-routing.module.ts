import { Routes } from '@angular/router';
import { permissionGuard } from '../shared/guards/permission.guard';
import { UserListComponent } from './components/user-list/user-list.component';
import { RoleListComponent } from './components/role-list/role-list.component';
import { PermissionMatrixComponent } from './components/permission-matrix/permission-matrix.component';
import { AccessRequestListComponent } from './components/access-request-list/access-request-list.component';
import { ConfigListComponent } from './components/config-list/config-list.component';
import { AuditLogComponent } from './components/audit-log/audit-log.component';

/**
 * Drop these into the children of your existing layout route (hr-routing.module.ts), replacing any
 * earlier `admins`/`roles` pair gated on a superAdminGuard — that guard and its concept don't map to
 * this backend. Each route is gated on the specific permission it needs, not one blanket admin flag.
 */
export const rbacAdminRoutes: Routes = [
  { path: 'users', component: UserListComponent, canActivate: [permissionGuard], data: { permission: 'USER:VIEW' } },
  { path: 'roles', component: RoleListComponent, canActivate: [permissionGuard], data: { permission: 'ROLE:VIEW' } },
  { path: 'permission-matrix', component: PermissionMatrixComponent, canActivate: [permissionGuard], data: { permission: 'ROLE:VIEW' } },
  { path: 'access-requests', component: AccessRequestListComponent, data: { mode: 'mine' } },
  { path: 'access-requests/inbox', component: AccessRequestListComponent, canActivate: [permissionGuard], data: { permission: 'ACCESS_OVERRIDE:APPROVE', mode: 'inbox' } },
  { path: 'config', component: ConfigListComponent, canActivate: [permissionGuard], data: { permission: 'CONFIG:VIEW' } },
  { path: 'audit-logs', component: AuditLogComponent, canActivate: [permissionGuard], data: { permission: 'AUDIT_LOG:VIEW' } },
];
