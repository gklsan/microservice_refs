import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';

import { MatTableModule } from '@angular/material/table';
import { MatPaginatorModule } from '@angular/material/paginator';
import { MatSortModule } from '@angular/material/sort';
import { MatDialogModule } from '@angular/material/dialog';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatTooltipModule } from '@angular/material/tooltip';
import { MatSnackBarModule } from '@angular/material/snack-bar';
import { MatSlideToggleModule } from '@angular/material/slide-toggle';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatProgressBarModule } from '@angular/material/progress-bar';
import { MatSelectModule } from '@angular/material/select';
import { MatChipsModule } from '@angular/material/chips';
import { MatTabsModule } from '@angular/material/tabs';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatNativeDateModule } from '@angular/material/core';

import { rbacAdminRoutes } from './hr-rbac-routing.module';

// Every component below is standalone — import the class directly rather than declaring it.
import { UserListComponent } from './components/user-list/user-list.component';
import { UserFormDialogComponent } from './components/user-form-dialog/user-form-dialog.component';
import { RoleListComponent } from './components/role-list/role-list.component';
import { RoleFormDialogComponent } from './components/role-form-dialog/role-form-dialog.component';
import { PermissionMatrixComponent } from './components/permission-matrix/permission-matrix.component';
import { AccessRequestListComponent } from './components/access-request-list/access-request-list.component';
import { ConfigListComponent } from './components/config-list/config-list.component';
import { AuditLogComponent } from './components/audit-log/audit-log.component';
import { ConfirmDialogComponent } from '../shared/components/confirm-dialog/confirm-dialog.component';

/**
 * If your app still uses NgModule-declared (non-standalone) components elsewhere, mount this
 * feature area either as its own lazy-loaded module (loadChildren pointing at rbacAdminRoutes)
 * or by importing these standalone components directly into your existing HrModule's `imports`
 * array (standalone components go in `imports`, not `declarations`).
 */
@NgModule({
  imports: [
    CommonModule, FormsModule, ReactiveFormsModule, RouterModule.forChild(rbacAdminRoutes),
    MatTableModule, MatPaginatorModule, MatSortModule, MatDialogModule, MatFormFieldModule,
    MatInputModule, MatButtonModule, MatIconModule, MatTooltipModule, MatSnackBarModule,
    MatSlideToggleModule, MatCheckboxModule, MatProgressBarModule, MatSelectModule, MatChipsModule,
    MatTabsModule, MatDatepickerModule, MatNativeDateModule,
    UserListComponent, UserFormDialogComponent, RoleListComponent, RoleFormDialogComponent,
    PermissionMatrixComponent, AccessRequestListComponent, ConfigListComponent, AuditLogComponent,
    ConfirmDialogComponent,
  ],
})
export class RbacAdminModule {}
