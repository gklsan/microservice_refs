import { Component, Inject, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, ReactiveFormsModule, Validators } from '@angular/forms';
import { MAT_DIALOG_DATA, MatDialogModule, MatDialogRef } from '@angular/material/dialog';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { MatButtonModule } from '@angular/material/button';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatSnackBar, MatSnackBarModule } from '@angular/material/snack-bar';

import { RoleService } from '../../../shared/services/role.service';
import { apiErrorLooksLike, apiErrorMessage } from '../../../shared/services/api-error.util';
import { ADMIN_LOCKED_PERMISSIONS, Permission, Role, ScopeLevel } from '../../../interfaces/rbac.models';

export interface RoleFormDialogData {
  mode: 'create' | 'edit';
  role?: Role;
}

const SCOPE_LEVELS: ScopeLevel[] = ['NONE', 'OWN', 'TEAM', 'LOB', 'LOCATION', 'ALL'];

@Component({
  selector: 'app-role-form-dialog',
  standalone: true,
  imports: [
    CommonModule, ReactiveFormsModule, MatDialogModule, MatFormFieldModule, MatInputModule,
    MatSelectModule, MatButtonModule, MatCheckboxModule, MatSnackBarModule,
  ],
  templateUrl: './role-form-dialog.component.html',
})
export class RoleFormDialogComponent implements OnInit {
  readonly scopeLevels = SCOPE_LEVELS;
  permissions: Permission[] = [];
  selected = new Set<string>();
  saving = false;

  form = this.fb.group({
    code: [{ value: '', disabled: this.data.mode === 'edit' }, [Validators.required, Validators.pattern(/^[A-Z][A-Z0-9_]{1,49}$/)]],
    name: ['', Validators.required],
    description: [''],
    scopeLevel: ['OWN' as ScopeLevel, Validators.required],
    active: [true],
  });

  constructor(
    private fb: FormBuilder,
    private roleService: RoleService,
    private snack: MatSnackBar,
    public dialogRef: MatDialogRef<RoleFormDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: RoleFormDialogData,
  ) {}

  get isAdminRole(): boolean {
    return this.data.mode === 'edit' && this.data.role?.code === 'ADMIN';
  }

  ngOnInit(): void {
    this.roleService.permissionCatalogue().subscribe((p) => (this.permissions = p));

    if (this.data.mode === 'edit' && this.data.role) {
      const r = this.data.role;
      this.form.patchValue({
        code: r.code,
        name: r.name,
        description: r.description ?? '',
        scopeLevel: r.scopeLevel,
        active: r.active,
      });
      this.selected = new Set(r.permissions);
    }
  }

  isLocked(code: string): boolean {
    return this.isAdminRole && ADMIN_LOCKED_PERMISSIONS.includes(code);
  }

  toggle(code: string, checked: boolean): void {
    if (this.isLocked(code) && !checked) return; // server would 400 anyway — block it in the UI
    if (checked) this.selected.add(code); else this.selected.delete(code);
  }

  save(): void {
    if (this.form.invalid) { this.form.markAllAsTouched(); return; }
    const v = this.form.getRawValue();
    this.saving = true;

    const req = {
      code: v.code!,
      name: v.name!,
      description: v.description || undefined,
      scopeLevel: v.scopeLevel!,
      active: this.isAdminRole ? true : v.active!,
      permissions: Array.from(this.selected),
    };

    const call = this.data.mode === 'create'
      ? this.roleService.create(req)
      : this.roleService.update(this.data.role!.code, req);

    call.subscribe({
      next: () => {
        this.saving = false;
        this.snack.open('Saved.', 'Dismiss', { duration: 3000 });
        this.dialogRef.close(true);
      },
      error: (err) => {
        this.saving = false;
        const msg = apiErrorLooksLike(err, 'ROLE_EXISTS') ? `Role code ${v.code} already exists.`
          : apiErrorLooksLike(err, 'RESERVED_ROLE') ? 'INTERNAL and SYSTEM are reserved role codes.'
          : apiErrorLooksLike(err, 'ADMIN_ROLE_LOCKED') ? 'ADMIN must keep its core management permissions.'
          : apiErrorMessage(err);
        this.snack.open(msg, 'Dismiss', { duration: 6000 });
      },
    });
  }
}
