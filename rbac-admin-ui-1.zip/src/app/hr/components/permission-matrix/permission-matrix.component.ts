import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatButtonModule } from '@angular/material/button';
import { MatSnackBar, MatSnackBarModule } from '@angular/material/snack-bar';
import { MatProgressBarModule } from '@angular/material/progress-bar';

import { RoleService } from '../../../shared/services/role.service';
import { RbacService } from '../../../shared/services/rbac.service';
import { apiErrorLooksLike, apiErrorMessage } from '../../../shared/services/api-error.util';
import { ADMIN_LOCKED_PERMISSIONS, PermissionMatrix } from '../../../interfaces/rbac.models';

/**
 * Grid screen (role x permission). Saves via PUT /admin/permission-matrix — only roles whose grants
 * changed are sent, since the server only touches roles present in the request body.
 */
@Component({
  selector: 'app-permission-matrix',
  standalone: true,
  imports: [CommonModule, MatCheckboxModule, MatButtonModule, MatSnackBarModule, MatProgressBarModule],
  templateUrl: './permission-matrix.component.html',
})
export class PermissionMatrixComponent implements OnInit {
  matrix: PermissionMatrix | null = null;
  /** working copy: roleCode -> Set of permission codes */
  working = new Map<string, Set<string>>();
  loading = false;
  saving = false;
  dirty = new Set<string>();

  constructor(
    private roleService: RoleService,
    public rbac: RbacService,
    private snack: MatSnackBar,
  ) {}

  ngOnInit(): void {
    this.load();
  }

  load(): void {
    this.loading = true;
    this.roleService.matrix().subscribe({
      next: (m) => {
        this.matrix = m;
        this.working = new Map(Object.entries(m.grants).map(([code, perms]) => [code, new Set(perms)]));
        this.dirty.clear();
        this.loading = false;
      },
      error: (err) => { this.loading = false; this.snack.open(apiErrorMessage(err), 'Dismiss', { duration: 5000 }); },
    });
  }

  isLocked(roleCode: string, permCode: string): boolean {
    return roleCode === 'ADMIN' && ADMIN_LOCKED_PERMISSIONS.includes(permCode);
  }

  checked(roleCode: string, permCode: string): boolean {
    return this.working.get(roleCode)?.has(permCode) ?? false;
  }

  toggle(roleCode: string, permCode: string, on: boolean): void {
    if (this.isLocked(roleCode, permCode) && !on) return;
    const set = this.working.get(roleCode) ?? new Set<string>();
    if (on) set.add(permCode); else set.delete(permCode);
    this.working.set(roleCode, set);
    this.dirty.add(roleCode);
  }

  save(): void {
    if (!this.dirty.size) return;
    this.saving = true;
    const grants: Record<string, string[]> = {};
    this.dirty.forEach((code) => { grants[code] = Array.from(this.working.get(code) ?? []); });

    this.roleService.saveMatrix(grants).subscribe({
      next: () => {
        this.saving = false;
        this.snack.open('Matrix saved.', 'Dismiss', { duration: 3000 });
        this.load();
      },
      error: (err) => {
        this.saving = false;
        const msg = apiErrorLooksLike(err, 'ADMIN_ROLE_LOCKED')
          ? 'ADMIN must keep its core management permissions.'
          : apiErrorMessage(err);
        this.snack.open(msg, 'Dismiss', { duration: 6000 });
      },
    });
  }

  discard(): void {
    this.load();
  }
}
