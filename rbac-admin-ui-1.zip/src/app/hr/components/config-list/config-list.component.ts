import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { MatTableModule } from '@angular/material/table';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { MatSnackBar, MatSnackBarModule } from '@angular/material/snack-bar';
import { MatDialogModule } from '@angular/material/dialog';

import { ConfigService } from '../../../shared/services/config.service';
import { RbacService } from '../../../shared/services/rbac.service';
import { apiErrorLooksLike, apiErrorMessage } from '../../../shared/services/api-error.util';
import { ConfigValueType, EnterpriseConfig } from '../../../interfaces/rbac.models';

/**
 * Reads need CONFIG:VIEW; writes need the ADMIN role AND CONFIG:MANAGE together, so a misconfigured
 * matrix alone can never hand enterprise settings to a non-admin (see RoleController API contract).
 * Value editor swaps control by valueType — server type-checks on save regardless.
 */
@Component({
  selector: 'app-config-list',
  standalone: true,
  imports: [
    CommonModule, FormsModule, MatTableModule, MatButtonModule, MatIconModule, MatFormFieldModule,
    MatInputModule, MatSelectModule, MatSnackBarModule, MatDialogModule,
  ],
  templateUrl: './config-list.component.html',
})
export class ConfigListComponent implements OnInit {
  readonly displayedColumns = ['key', 'category', 'value', 'updated', 'actions'];
  rows: EnterpriseConfig[] = [];
  editing: Record<string, string> = {};
  loading = false;

  newKey = { key: '', value: '', valueType: 'STRING' as ConfigValueType, category: 'GENERAL', description: '' };
  showNew = false;

  constructor(private configService: ConfigService, public rbac: RbacService, private snack: MatSnackBar) {}

  ngOnInit(): void {
    this.load();
  }

  load(): void {
    this.loading = true;
    this.configService.list().subscribe({
      next: (rows) => { this.rows = rows; this.loading = false; },
      error: (err) => { this.loading = false; this.snack.open(apiErrorMessage(err), 'Dismiss', { duration: 5000 }); },
    });
  }

  startEdit(row: EnterpriseConfig): void {
    this.editing[row.key] = row.value;
  }

  cancelEdit(key: string): void {
    delete this.editing[key];
  }

  saveEdit(row: EnterpriseConfig): void {
    const value = this.editing[row.key];
    this.configService.update(row.key, { value }).subscribe({
      next: () => { delete this.editing[row.key]; this.snack.open('Saved.', 'Dismiss', { duration: 3000 }); this.load(); },
      error: (err) => {
        const msg = apiErrorLooksLike(err, 'INVALID_CONFIG_VALUE')
          ? `Value doesn't match the expected type (${row.valueType}).`
          : apiErrorMessage(err);
        this.snack.open(msg, 'Dismiss', { duration: 6000 });
      },
    });
  }

  createConfig(): void {
    this.configService.create(this.newKey).subscribe({
      next: () => {
        this.showNew = false;
        this.newKey = { key: '', value: '', valueType: 'STRING', category: 'GENERAL', description: '' };
        this.snack.open('Created.', 'Dismiss', { duration: 3000 });
        this.load();
      },
      error: (err) => {
        const msg = apiErrorLooksLike(err, 'CONFIG_EXISTS')
          ? `Configuration key "${this.newKey.key}" already exists.`
          : apiErrorLooksLike(err, 'INVALID_CONFIG_VALUE')
            ? `Value doesn't match the selected type (${this.newKey.valueType}).`
            : apiErrorMessage(err);
        this.snack.open(msg, 'Dismiss', { duration: 6000 });
      },
    });
  }
}
