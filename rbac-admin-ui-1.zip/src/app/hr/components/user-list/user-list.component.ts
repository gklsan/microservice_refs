import { Component, OnInit, ViewChild } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { MatTableModule } from '@angular/material/table';
import { MatPaginator, MatPaginatorModule, PageEvent } from '@angular/material/paginator';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { MatChipsModule } from '@angular/material/chips';
import { MatTooltipModule } from '@angular/material/tooltip';
import { MatSnackBar, MatSnackBarModule } from '@angular/material/snack-bar';
import { MatDialog, MatDialogModule } from '@angular/material/dialog';
import { debounceTime, distinctUntilChanged, Subject } from 'rxjs';

import { UserAdminService } from '../../../shared/services/user-admin.service';
import { RbacService } from '../../../shared/services/rbac.service';
import { apiErrorMessage, apiErrorLooksLike } from '../../../shared/services/api-error.util';
import { AdminUser, UserStatus } from '../../../interfaces/rbac.models';
import { ConfirmDialogComponent } from '../../../shared/components/confirm-dialog/confirm-dialog.component';
import { UserFormDialogComponent } from '../user-form-dialog/user-form-dialog.component';

@Component({
  selector: 'app-user-list',
  standalone: true,
  imports: [
    CommonModule, FormsModule, MatTableModule, MatPaginatorModule, MatButtonModule, MatIconModule,
    MatFormFieldModule, MatInputModule, MatSelectModule, MatChipsModule, MatTooltipModule,
    MatSnackBarModule, MatDialogModule,
  ],
  templateUrl: './user-list.component.html',
})
export class UserListComponent implements OnInit {
  @ViewChild(MatPaginator) paginator!: MatPaginator;

  readonly displayedColumns = ['fullName', 'email', 'roles', 'status', 'scope', 'actions'];
  rows: AdminUser[] = [];
  totalElements = 0;
  pageSize = 20;
  pageIndex = 0;
  loading = false;

  search = '';
  status: UserStatus | '' = '';
  role = '';

  private searchChanged = new Subject<string>();

  constructor(
    private userAdmin: UserAdminService,
    public rbac: RbacService,
    private dialog: MatDialog,
    private snack: MatSnackBar,
  ) {
    this.searchChanged.pipe(debounceTime(300), distinctUntilChanged()).subscribe(() => {
      this.pageIndex = 0;
      this.load();
    });
  }

  ngOnInit(): void {
    this.load();
  }

  onSearchInput(value: string): void {
    this.search = value;
    this.searchChanged.next(value);
  }

  onFilterChange(): void {
    this.pageIndex = 0;
    this.load();
  }

  onPage(e: PageEvent): void {
    this.pageIndex = e.pageIndex;
    this.pageSize = e.pageSize;
    this.load();
  }

  load(): void {
    this.loading = true;
    this.userAdmin
      .search({
        search: this.search || undefined,
        status: this.status || undefined,
        role: this.role || undefined,
        page: this.pageIndex,
        size: this.pageSize,
      })
      .subscribe({
        next: (res) => {
          this.rows = res.content;
          this.totalElements = res.totalElements;
          this.loading = false;
        },
        error: (err) => {
          this.loading = false;
          this.snack.open(apiErrorMessage(err), 'Dismiss', { duration: 5000 });
        },
      });
  }

  openCreate(): void {
    const ref = this.dialog.open(UserFormDialogComponent, { width: '640px', data: { mode: 'create' } });
    ref.afterClosed().subscribe((saved) => { if (saved) this.load(); });
  }

  openEdit(user: AdminUser): void {
    const ref = this.dialog.open(UserFormDialogComponent, { width: '640px', data: { mode: 'edit', user } });
    ref.afterClosed().subscribe((saved) => { if (saved) this.load(); });
  }

  toggleStatus(user: AdminUser): void {
    const activating = user.status === 'INACTIVE';
    const ref = this.dialog.open(ConfirmDialogComponent, {
      width: '480px',
      data: {
        title: activating ? 'Reactivate user' : 'Deactivate user',
        message: activating
          ? `Reactivate ${user.fullName}? They'll regain their assigned roles and permissions.`
          : `Deactivate ${user.fullName}? They'll lose every role/permission until reactivated.`,
        confirmLabel: activating ? 'Reactivate' : 'Deactivate',
        destructive: !activating,
        requireRemarks: true,
      },
    });
    ref.afterClosed().subscribe((result) => {
      if (!result) return;
      const action = activating
        ? this.userAdmin.reactivate(user.id, result.remarks)
        : this.userAdmin.deactivate(user.id, result.remarks);
      action.subscribe({
        next: () => { this.snack.open('Saved.', 'Dismiss', { duration: 3000 }); this.load(); },
        error: (err) => {
          if (apiErrorLooksLike(err, 'LAST_ADMIN')) {
            this.snack.open("Can't deactivate the last active administrator.", 'Dismiss', { duration: 6000 });
          } else {
            this.snack.open(apiErrorMessage(err), 'Dismiss', { duration: 5000 });
          }
        },
      });
    });
  }
}
