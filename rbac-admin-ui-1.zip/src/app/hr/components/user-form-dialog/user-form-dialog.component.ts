import { Component, Inject, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, ReactiveFormsModule, Validators } from '@angular/forms';
import { MAT_DIALOG_DATA, MatDialogModule, MatDialogRef } from '@angular/material/dialog';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { MatButtonModule } from '@angular/material/button';
import { MatChipsModule } from '@angular/material/chips';
import { MatSnackBar, MatSnackBarModule } from '@angular/material/snack-bar';
import { MatTabsModule } from '@angular/material/tabs';
import { forkJoin } from 'rxjs';

import { UserAdminService } from '../../../shared/services/user-admin.service';
import { RoleService } from '../../../shared/services/role.service';
import { apiErrorMessage, apiErrorLooksLike } from '../../../shared/services/api-error.util';
import { AdminUser, GrantEffect, Permission, PermissionGrant, Role } from '../../../interfaces/rbac.models';

export interface UserFormDialogData {
  mode: 'create' | 'edit';
  user?: AdminUser;
}

/**
 * Roles, LOB/location scope, and permission grants (ALLOW/DENY) are three separate API calls —
 * PUT /admin/users/{id}/roles, PUT /admin/users/{id}, PUT /admin/users/{id}/permissions — not one form
 * submit. Create uses a single POST that accepts roles + scope together; edit fires up to three calls.
 */
@Component({
  selector: 'app-user-form-dialog',
  standalone: true,
  imports: [
    CommonModule, ReactiveFormsModule, MatDialogModule, MatFormFieldModule, MatInputModule,
    MatSelectModule, MatButtonModule, MatChipsModule, MatSnackBarModule, MatTabsModule,
  ],
  templateUrl: './user-form-dialog.component.html',
})
export class UserFormDialogComponent implements OnInit {
  roles: Role[] = [];
  permissions: Permission[] = [];
  saving = false;

  form = this.fb.group({
    email: [{ value: '', disabled: this.data.mode === 'edit' }, [Validators.required, Validators.email]],
    fullName: ['', Validators.required],
    employeeCode: [''],
    userType: ['EMPLOYEE_HR'],
    managerId: [''],
    roleCodes: [[] as string[], Validators.required],
    lobs: [[] as string[]],
    locations: [[] as string[]],
  });

  grants: PermissionGrant[] = [];

  constructor(
    private fb: FormBuilder,
    private userAdmin: UserAdminService,
    private roleService: RoleService,
    private snack: MatSnackBar,
    public dialogRef: MatDialogRef<UserFormDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: UserFormDialogData,
  ) {}

  ngOnInit(): void {
    forkJoin({ roles: this.roleService.list(), permissions: this.roleService.permissionCatalogue() }).subscribe(
      ({ roles, permissions }) => {
        this.roles = roles.filter((r) => r.active);
        this.permissions = permissions;
      },
    );

    if (this.data.mode === 'edit' && this.data.user) {
      const u = this.data.user;
      this.form.patchValue({
        email: u.email,
        fullName: u.fullName,
        employeeCode: u.employeeCode ?? '',
        userType: u.userType,
        managerId: u.managerId ?? '',
        roleCodes: u.roles,
        lobs: u.lobs,
        locations: u.locations,
      });
      this.grants = [...u.permissionGrants];
    }
  }

  effectFor(code: string): GrantEffect | null {
    return this.grants.find((g) => g.permission === code)?.effect ?? null;
  }

  setEffect(code: string, effect: GrantEffect | null): void {
    this.grants = this.grants.filter((g) => g.permission !== code);
    if (effect) this.grants.push({ permission: code, effect });
  }

  save(): void {
    if (this.form.invalid) { this.form.markAllAsTouched(); return; }
    const v = this.form.getRawValue();
    this.saving = true;

    if (this.data.mode === 'create') {
      this.userAdmin
        .create({
          email: v.email!,
          fullName: v.fullName!,
          employeeCode: v.employeeCode || undefined,
          userType: v.userType as any,
          roles: v.roleCodes!,
          lobs: v.lobs!,
          locations: v.locations!,
          managerId: v.managerId || undefined,
        })
        .subscribe({
          next: (created) => {
            if (this.grants.length) {
              this.userAdmin.setPermissions(created.id, { grants: this.grants }).subscribe({
                next: () => this.finish(),
                error: (err) => this.fail(err),
              });
            } else {
              this.finish();
            }
          },
          error: (err) => this.fail(err),
        });
      return;
    }

    // edit: update basic fields + scope, then roles, then permission grants
    const user = this.data.user!;
    this.userAdmin
      .update(user.id, {
        fullName: v.fullName!,
        employeeCode: v.employeeCode || undefined,
        managerId: v.managerId || undefined,
        lobs: v.lobs!,
        locations: v.locations!,
      })
      .subscribe({
        next: () => {
          this.userAdmin.assignRoles(user.id, { roles: v.roleCodes! }).subscribe({
            next: () => {
              this.userAdmin.setPermissions(user.id, { grants: this.grants }).subscribe({
                next: () => this.finish(),
                error: (err) => this.fail(err),
              });
            },
            error: (err) => this.fail(err),
          });
        },
        error: (err) => this.fail(err),
      });
  }

  private finish(): void {
    this.saving = false;
    this.snack.open('Saved.', 'Dismiss', { duration: 3000 });
    this.dialogRef.close(true);
  }

  private fail(err: unknown): void {
    this.saving = false;
    const msg = apiErrorLooksLike(err, 'LAST_ADMIN')
      ? "Can't remove the ADMIN role from the last active administrator."
      : apiErrorLooksLike(err, 'INVALID_MANAGER')
        ? 'Invalid manager: self-reference or reporting-line cycle.'
        : apiErrorMessage(err);
    this.snack.open(msg, 'Dismiss', { duration: 6000 });
  }
}
