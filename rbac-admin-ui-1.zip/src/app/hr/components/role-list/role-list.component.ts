import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatTableModule } from '@angular/material/table';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatChipsModule } from '@angular/material/chips';
import { MatTooltipModule } from '@angular/material/tooltip';
import { MatSnackBar, MatSnackBarModule } from '@angular/material/snack-bar';
import { MatDialog, MatDialogModule } from '@angular/material/dialog';
import { MatSlideToggleModule } from '@angular/material/slide-toggle';

import { RoleService } from '../../../shared/services/role.service';
import { RbacService } from '../../../shared/services/rbac.service';
import { apiErrorLooksLike, apiErrorMessage } from '../../../shared/services/api-error.util';
import { Role } from '../../../interfaces/rbac.models';
import { ConfirmDialogComponent } from '../../../shared/components/confirm-dialog/confirm-dialog.component';
import { RoleFormDialogComponent } from '../role-form-dialog/role-form-dialog.component';

/**
 * No delete endpoint exists for roles. "Removing" a role means setting active=false via
 * RoleService.update() — rows with active=false are shown greyed out, not hidden, since any user
 * still holding the role needs it to remain visible for troubleshooting.
 */
@Component({
  selector: 'app-role-list',
  standalone: true,
  imports: [
    CommonModule, MatTableModule, MatButtonModule, MatIconModule, MatChipsModule, MatTooltipModule,
    MatSnackBarModule, MatDialogModule, MatSlideToggleModule,
  ],
  templateUrl: './role-list.component.html',
})
export class RoleListComponent implements OnInit {
  readonly displayedColumns = ['name', 'code', 'scopeLevel', 'system', 'active', 'permissions', 'actions'];
  roles: Role[] = [];
  loading = false;

  constructor(
    private roleService: RoleService,
    public rbac: RbacService,
    private dialog: MatDialog,
    private snack: MatSnackBar,
  ) {}

  ngOnInit(): void {
    this.load();
  }

  load(): void {
    this.loading = true;
    this.roleService.list().subscribe({
      next: (roles) => { this.roles = roles; this.loading = false; },
      error: (err) => { this.loading = false; this.snack.open(apiErrorMessage(err), 'Dismiss', { duration: 5000 }); },
    });
  }

  openCreate(): void {
    const ref = this.dialog.open(RoleFormDialogComponent, { width: '720px', data: { mode: 'create' } });
    ref.afterClosed().subscribe((saved) => { if (saved) this.load(); });
  }

  openEdit(role: Role): void {
    const ref = this.dialog.open(RoleFormDialogComponent, { width: '720px', data: { mode: 'edit', role } });
    ref.afterClosed().subscribe((saved) => { if (saved) this.load(); });
  }

  toggleActive(role: Role): void {
    if (role.code === 'ADMIN' && role.active) {
      this.snack.open('The ADMIN role cannot be deactivated.', 'Dismiss', { duration: 5000 });
      return;
    }
    this.roleService
      .update(role.code, {
        code: role.code,
        name: role.name,
        description: role.description ?? undefined,
        scopeLevel: role.scopeLevel,
        active: !role.active,
        permissions: role.permissions,
      })
      .subscribe({
        next: () => { this.snack.open('Saved.', 'Dismiss', { duration: 3000 }); this.load(); },
        error: (err) => {
          const msg = apiErrorLooksLike(err, 'ADMIN_ROLE_LOCKED')
            ? 'The ADMIN role cannot be deactivated.'
            : apiErrorMessage(err);
          this.snack.open(msg, 'Dismiss', { duration: 5000 });
        },
      });
  }

  resetDefaults(role: Role): void {
    const ref = this.dialog.open(ConfirmDialogComponent, {
      width: '480px',
      data: {
        title: 'Reset to factory defaults',
        message: `Restore ${role.name} to its factory default permission set? Current custom grants will be lost.`,
        confirmLabel: 'Reset',
        destructive: true,
      },
    });
    ref.afterClosed().subscribe((confirmed) => {
      if (!confirmed) return;
      this.roleService.resetToDefaults(role.code).subscribe({
        next: () => { this.snack.open('Role reset to defaults.', 'Dismiss', { duration: 3000 }); this.load(); },
        error: (err) => {
          const msg = apiErrorLooksLike(err, 'NO_DEFAULTS')
            ? 'This role has no factory default permission set.'
            : apiErrorMessage(err);
          this.snack.open(msg, 'Dismiss', { duration: 5000 });
        },
      });
    });
  }
}
