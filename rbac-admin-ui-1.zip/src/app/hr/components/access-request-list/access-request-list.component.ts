import { Component, Input, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatTableModule } from '@angular/material/table';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatChipsModule } from '@angular/material/chips';
import { MatDialog, MatDialogModule } from '@angular/material/dialog';
import { MatSnackBar, MatSnackBarModule } from '@angular/material/snack-bar';
import { MatPaginatorModule, PageEvent } from '@angular/material/paginator';
import { MatTabsModule } from '@angular/material/tabs';

import { AccessRequestService } from '../../../shared/services/access-request.service';
import { RbacService } from '../../../shared/services/rbac.service';
import { apiErrorMessage } from '../../../shared/services/api-error.util';
import { AccessRequest, AccessRequestStatus } from '../../../interfaces/rbac.models';
import { ConfirmDialogComponent } from '../../../shared/components/confirm-dialog/confirm-dialog.component';

/**
 * Two modes on one component: 'mine' (any authenticated user, GET /access-requests/mine) and
 * 'inbox' (approvers, GET /access-requests?status=). Wire both into the routes — e.g.
 * /access-requests (mine) and /access-requests/inbox (gated on ACCESS_OVERRIDE:APPROVE).
 */
@Component({
  selector: 'app-access-request-list',
  standalone: true,
  imports: [
    CommonModule, MatTableModule, MatButtonModule, MatIconModule, MatChipsModule, MatDialogModule,
    MatSnackBarModule, MatPaginatorModule, MatTabsModule,
  ],
  templateUrl: './access-request-list.component.html',
})
export class AccessRequestListComponent implements OnInit {
  @Input() mode: 'mine' | 'inbox' = 'mine';

  readonly displayedColumns = ['requester', 'target', 'reason', 'status', 'validUntil', 'actions'];
  rows: AccessRequest[] = [];
  totalElements = 0;
  pageSize = 20;
  pageIndex = 0;
  statusFilter: AccessRequestStatus = 'PENDING';
  loading = false;

  constructor(
    private service: AccessRequestService,
    public rbac: RbacService,
    private dialog: MatDialog,
    private snack: MatSnackBar,
  ) {}

  ngOnInit(): void {
    this.load();
  }

  load(): void {
    this.loading = true;
    const call = this.mode === 'mine'
      ? this.service.mine(this.pageIndex, this.pageSize)
      : this.service.byStatus(this.statusFilter, this.pageIndex, this.pageSize);
    call.subscribe({
      next: (res) => { this.rows = res.content; this.totalElements = res.totalElements; this.loading = false; },
      error: (err) => { this.loading = false; this.snack.open(apiErrorMessage(err), 'Dismiss', { duration: 5000 }); },
    });
  }

  onPage(e: PageEvent): void {
    this.pageIndex = e.pageIndex;
    this.pageSize = e.pageSize;
    this.load();
  }

  onStatusFilterChange(status: AccessRequestStatus): void {
    this.statusFilter = status;
    this.pageIndex = 0;
    this.load();
  }

  approve(req: AccessRequest): void {
    this.withRemarks('Approve access request', `Approve access for ${req.requesterName ?? req.requesterEmail}?`, (remarks) =>
      this.service.approve(req.id, remarks));
  }

  reject(req: AccessRequest): void {
    this.withRemarks('Reject access request', `Reject access for ${req.requesterName ?? req.requesterEmail}?`, (remarks) =>
      this.service.reject(req.id, remarks), true);
  }

  revoke(req: AccessRequest): void {
    this.withRemarks('Revoke access', 'Revoke this access grant?', (remarks) =>
      this.service.revoke(req.id, remarks), true);
  }

  canRevoke(req: AccessRequest): boolean {
    const mine = req.requesterEmail === this.rbac.me()?.email;
    return (mine || this.rbac.hasPermission('ACCESS_OVERRIDE:APPROVE'))
      && (req.status === 'PENDING' || req.status === 'APPROVED');
  }

  private withRemarks(title: string, message: string, action: (remarks?: string) => ReturnType<AccessRequestService['approve']>, destructive = false): void {
    const ref = this.dialog.open(ConfirmDialogComponent, {
      width: '480px',
      data: { title, message, requireRemarks: true, destructive },
    });
    ref.afterClosed().subscribe((result) => {
      if (!result) return;
      action(result.remarks).subscribe({
        next: () => { this.snack.open('Saved.', 'Dismiss', { duration: 3000 }); this.load(); },
        error: (err) => this.snack.open(apiErrorMessage(err), 'Dismiss', { duration: 5000 }),
      });
    });
  }
}
