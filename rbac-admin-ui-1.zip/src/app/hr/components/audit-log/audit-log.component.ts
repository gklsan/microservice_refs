import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { MatTableModule } from '@angular/material/table';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatPaginatorModule, PageEvent } from '@angular/material/paginator';
import { MatSnackBar, MatSnackBarModule } from '@angular/material/snack-bar';
import { MatDatepickerModule } from '@angular/material/datepicker';

import { AuditLogService } from '../../../shared/services/audit-log.service';
import { RbacService } from '../../../shared/services/rbac.service';
import { apiErrorMessage } from '../../../shared/services/api-error.util';
import { AuditCategory, AuditRow } from '../../../interfaces/rbac.models';

const CATEGORIES: AuditCategory[] = ['ACTIVITY', 'APPROVAL', 'WORKFLOW_TRANSITION', 'CONFIG_CHANGE', 'SECURITY', 'NOTIFICATION'];

@Component({
  selector: 'app-audit-log',
  standalone: true,
  imports: [
    CommonModule, FormsModule, MatTableModule, MatFormFieldModule, MatInputModule, MatSelectModule,
    MatButtonModule, MatIconModule, MatPaginatorModule, MatSnackBarModule, MatDatepickerModule,
  ],
  templateUrl: './audit-log.component.html',
})
export class AuditLogComponent implements OnInit {
  readonly categories = CATEGORIES;
  readonly displayedColumns = ['occurredAt', 'category', 'action', 'actor', 'entity', 'outcome', 'description'];

  rows: AuditRow[] = [];
  totalElements = 0;
  pageSize = 50;
  pageIndex = 0;
  loading = false;

  selectedCategories: AuditCategory[] = [];
  actor = '';
  q = '';
  from: Date | null = null;
  to: Date | null = null;

  constructor(private auditLog: AuditLogService, public rbac: RbacService, private snack: MatSnackBar) {}

  ngOnInit(): void {
    this.search();
  }

  search(): void {
    this.pageIndex = 0;
    this.load();
  }

  onPage(e: PageEvent): void {
    this.pageIndex = e.pageIndex;
    this.pageSize = e.pageSize;
    this.load();
  }

  load(): void {
    this.loading = true;
    this.auditLog
      .search({
        category: this.selectedCategories.length ? this.selectedCategories : undefined,
        actor: this.actor || undefined,
        q: this.q || undefined,
        from: this.from ? this.from.toISOString() : undefined,
        to: this.to ? this.to.toISOString() : undefined,
        page: this.pageIndex,
        size: this.pageSize,
      })
      .subscribe({
        next: (res) => { this.rows = res.content; this.totalElements = res.totalElements; this.loading = false; },
        error: (err) => { this.loading = false; this.snack.open(apiErrorMessage(err), 'Dismiss', { duration: 5000 }); },
      });
  }

  exportCsv(): void {
    const url = this.auditLog.exportCsvUrl({
      category: this.selectedCategories.length ? this.selectedCategories : undefined,
      actor: this.actor || undefined,
      from: this.from ? this.from.toISOString() : undefined,
      to: this.to ? this.to.toISOString() : undefined,
    });
    window.open(url, '_blank');
  }
}
