/**
 * Suggested nav config array entries — matches the module list in the integration doc §4.
 * If your side nav renders from a static array (rather than hard-coded template markup), append these.
 * `permission` is checked against RbacService.hasPermission(); items the user lacks are simply filtered out.
 */
export interface NavItem {
  label: string;
  icon: string;
  route: string;
  permission?: string;
}

export const RBAC_ADMIN_NAV_ITEMS: NavItem[] = [
  { label: 'Users', icon: 'group', route: 'users', permission: 'USER:VIEW' },
  { label: 'Roles & Matrix', icon: 'security', route: 'roles', permission: 'ROLE:VIEW' },
  { label: 'Access Requests', icon: 'pending_actions', route: 'access-requests' }, // every user sees "My Requests"
  { label: 'Audit Log', icon: 'history', route: 'audit-logs', permission: 'AUDIT_LOG:VIEW' },
  { label: 'Enterprise Config', icon: 'tune', route: 'config', permission: 'CONFIG:VIEW' },
];
