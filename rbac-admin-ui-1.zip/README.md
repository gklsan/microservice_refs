# RBAC / Admin UI — generated against `admin-services`

Complete Angular integration code for the design doc at `claude/rbac-admin-ui-integration.md`
in the AGS project. Generated directly against the real backend at
`digihire-phase5-sprint1/admin-services`, not the old assumed API.

## Drop-in

Copy `src/app/interfaces`, `src/app/shared`, `src/app/hr` into your project at the same paths
(merge `shared` and `hr` if you already have folders there — nothing here assumes it owns the
whole tree).

## Wiring checklist

1. Set `environment.apiUrl` to include the `/admin-services` context path, or point it at
   whatever gateway route strips that prefix — confirm which with whoever owns the gateway config.
2. Add `RBAC_APP_INITIALIZER_PROVIDER` (see `app-init-rbac.snippet.ts`) to your app config so
   `RbacService.me()` is loaded after login.
3. Mount `RbacAdminModule` — either lazy-load it via `loadChildren` pointing at its routes, or
   import the standalone components directly into an existing module's `imports` array.
4. Add nav entries from `nav-item.model.ts` (or the routes in `hr-rbac-routing.module.ts`
   directly) under wherever your side nav renders.
5. Pull in `rbac-admin.styles.scss` — the templates reference `.toolbar`, `.muted`,
   `.inactive-row`, etc.
6. Wire `MasterDataService.list('LOB')` / `list('LOCATION')` into the two placeholder
   `mat-select` blocks in `user-form-dialog.component.html` — left unpopulated here since your
   actual LOB/location catalogue wasn't available to generate against.

## What's NOT included

- Angular Material theme / `provideAnimations()` setup — assumed already in your app.
- `environment.ts` itself — only `environment.apiUrl` is referenced.
- Unit tests — the backend itself ships none (`admin-services/src/test/java` is empty
  scaffolding); front-end tests weren't in scope here either. Worth doing properly, not
  generated to fill space.
- A dedicated `/forbidden` page component — `permissionGuard` redirects there; add a trivial one
  or point it at your existing error page.

## Files

```
interfaces/rbac.models.ts                          — every DTO, enum and error code from AdminDtos.java

shared/services/
  rbac.service.ts             — GET /rbac/me (cached), POST /rbac/check, GET /rbac/filters/{screen}
  user-admin.service.ts       — /admin/users/**
  role.service.ts             — /admin/roles/**, /admin/permission-matrix, /admin/permissions
  access-request.service.ts   — /access-requests/**
  config.service.ts           — /admin/config/**
  master-data.service.ts      — /master-data/**, /admin/search-filters/**
  audit-log.service.ts        — /admin/audit-logs/**
  api-error.util.ts           — {"message": "..."} unwrapping + known-error-code matching

shared/guards/permission.guard.ts                   — replaces any superAdminGuard concept entirely
shared/components/confirm-dialog/                   — reusable confirm/remarks dialog

hr/components/
  user-list/, user-form-dialog/                      — USER:VIEW / USER:MANAGE
  role-list/, role-form-dialog/                       — ROLE:VIEW / ROLE:MANAGE (+ ADMIN role)
  permission-matrix/                                  — bulk role x permission grid
  access-request-list/                                — dual-mode: 'mine' and 'inbox'
  config-list/                                         — CONFIG:VIEW / CONFIG:MANAGE (+ ADMIN role)
  audit-log/                                           — AUDIT_LOG:VIEW / AUDIT_LOG:EXPORT

hr/hr-rbac-routing.module.ts, nav-item.model.ts, rbac-admin.module.ts, rbac-admin.styles.scss
app-init-rbac.snippet.ts
```
