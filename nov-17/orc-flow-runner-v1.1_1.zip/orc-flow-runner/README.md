# DigiHire ↔ Oracle Recruiting Cloud – Flow Runner (v1.1)

A standalone, runnable jar that executes the Oracle flows from design v1.1. Use it to prove every step against the AGS Oracle test pod before the code moves into `smartie-core`.

| Flow | What it does | Oracle calls |
|---|---|---|
| auth | Checks the login (Basic, or exchanges username/password for a token) and makes one read | GET |
| flow0 | Reference data and ID check: requisition hiring team, workers, job, department, location, describe | GET |
| flow1 | Requisition sync: 15-min delta (keyset paging), optional full pass, live validity check at mapping | GET |
| flow2 | Candidate hand-over at selection: profile, work, education, certificates, skills, resume and interview summary PDF | GET, POST |
| flow3 | Offer stage tracking: finds the application the Oracle recruiter created and reads every offer/HR stage | GET only |
| flow4 | Requisition write-back: TL upload (create) and approved JD edit (update), custom fields (DFF), read-back | GET, POST, PATCH |

Nothing is hard-coded: endpoints, query parameters, payload field mappings, mandatory fields, value maps, stage names and rules all come from JSON config. Input comes from a JSON data file.

---

## 1. Requirements

- Java 17 or newer (`java -version`)
- To rebuild: Maven 3.9 (`mvn -q package`), or `./build.sh` with local Jackson jars

## 2. Quick start – no Oracle access needed

```bash
# 1. random test data (8 candidates covering every case + 3 requisition writes)
java -jar orc-flow-runner.jar generate-data --out data.json

# 2. run every flow against the embedded mock Oracle
java -jar orc-flow-runner.jar run --data data.json --mock --username test --password test --polls 9
```

Expected: all six flows run; the summary ends `RESULT: all steps completed`. The mock accepts any username; the password `wrong` is refused, to test the 401 path.

## 3. Live run against the AGS test pod

```bash
java -jar orc-flow-runner.jar export-samples --out ./orc-runner     # editable config + data templates
# edit orc-runner/config-live-template.json and orc-runner/data-live-template.json

# safest first step: login + reads only
java -jar orc-flow-runner.jar run --config orc-runner/config-live-template.json \
     --data orc-runner/data-live-template.json --flows auth,flow0,flow1 --username DIGIHIRE_INT

# see every write payload without sending it
java -jar orc-flow-runner.jar run ... --flows flow2,flow4 --dry-run

# then the real writes, one flow at a time
java -jar orc-flow-runner.jar run ... --flows flow2
java -jar orc-flow-runner.jar run ... --flows flow3 --polls 1
java -jar orc-flow-runner.jar run ... --flows flow4
```

### Username and password

| Option | How |
|---|---|
| Arguments | `--username U --password P` (the password then sits in shell history – avoid on shared machines) |
| Prompt | Leave out `--password`; the jar asks with hidden input |
| Environment | `ORACLE_USERNAME`, `ORACLE_PASSWORD` (and `ORACLE_CLIENT_ID`, `ORACLE_CLIENT_SECRET` for token mode) |
| File | `--password-file secret.txt` |

The password is held in memory only. It never goes to the call log, report, state or payload files.

### Auth modes

- **BASIC** (default): username and password on every call – what Fusion REST accepts out of the box.
- **TOKEN**: `--auth-mode token --token-url https://<idcs-host>/oauth2/v1/token` – the username and password are exchanged for an access token (password grant). The token is cached, refreshed before expiry, and fetched again once after a 401. Pass `--client-id` / `--client-secret` if the Oracle Identity app needs them (`oracle.auth.clientAuth` = `header` or `body`).

## 4. Output (folder `orc-run-output` or `--out`)

| File | Content |
|---|---|
| `report.json` | Every step with its status and message |
| `state.json` | Stands in for the DigiHire tables: candidate links, application links, Oracle stages, watermarks, reference cache, timeline, alerts. Reused by the next run (use `--reset-state` to start clean) |
| `calllog.jsonl` | Every Oracle call (method, URL, status, duration, masked request and response) – mirrors `integ_call_log` |
| `payloads/` | Masked copy of every request body (file contents replaced by their size) |
| `summaries/` | The interview summary PDFs sent to Oracle |
| `describe-*.json` | Oracle describe output – use it to confirm attribute, custom field and source code names |

Statuses: `PASS`, `INFO`, `WARN`, `SKIPPED`, `DRY_RUN`, `NEEDS_DATA`, `LINK_REQUIRED`, `HELD`, `WAITING`, `ALERT`, `BLOCKED`, `FAIL`, `AUTH_STOP`.
Exit codes: `0` ok · `1` bad arguments · `2` some steps failed · `3` login refused (all Oracle jobs stopped).

## 5. Input data file

```jsonc
{
  "configOverrides": { "flow4": { "draftPhaseId": "1" } },     // optional, merged over the config
  "requisitionSync":     { "initialWatermark": "2026-11-01T00:00:00Z" },
  "applicationTracking": { "initialWatermark": "2026-11-01T00:00:00Z" },
  "requisitionChecks": ["REQ-10452"],                           // flow0 + flow1 live check
  "workerEmails": ["recruiter@agshealth.com"],                  // flow0 person mapping
  "candidates": [ {                                             // flow2 + flow3
      "candidateId": "...", "firstName": "...", "lastName": "...", "email": "...", "countryCode": "+91", "mobile": "...",
      "address": {...}, "source": "JOB_PORTAL", "sourceDetail": "Naukri",
      "education": [...], "experience": [...], "certifications": [...], "skills": [...],
      "resume": { "fileName": "x.pdf", "path": "resumes/x.pdf" },          // path relative to the data file
      "interview": { "hrRound": {...}, "assessments": [...], "panel": {...}, "verification": {...} },
      "selection": { "applicationId": "...", "status": "PANEL_SELECTED", "requisitionNumber": "...", "recruiterEmail": "..." },
      "afterHandover": [ { "status": "PANEL_DECLINED", "at": "...", "remark": "..." } ],   // optional
      "mock": { "stagePath": "HIRED" }                                     // only used with --mock
  } ],
  "requisitionWrites": [                                        // flow4
    { "writeId": "...", "action": "CREATE", "title": "...", "recruiterEmail": "...", "hiringManagerEmail": "...",
      "primaryLocationId": "...", "unlimitedOpenings": "N", "numberOfOpenings": 10, "dff": { "lob": "AR Voice" } },
    { "writeId": "...", "action": "UPDATE", "requisitionNumber": "...", "title": "...", "externalDescription": "...", "dff": {...} }
  ]
}
```

A missing resume file is replaced by a generated test PDF (`flow2.attachments.generateResumeIfMissing`).

## 6. Making it dynamic – config

The built-in config (`export-samples` writes it as `orc-config.json`) is loaded first; `--config` is merged over it; `configOverrides` in the data file next; `--set key=value` last.

**Operations** – every Oracle call:

```json
"requisitionLiveCheck": {
  "method": "GET", "path": "/recruitingJobRequisitions",
  "query": { "finder": "findByRequisitionNumber;RequisitionNumber={requisitionNumber}", "onlyData": "true" },
  "timeoutSeconds": 3, "retry": false
}
```

`{name}` placeholders are filled by the flow. A query parameter whose placeholder has no value is left out.

**Mappings** – request bodies are JSON templates:

| Template value | Meaning |
|---|---|
| `"$.email\|lower\|required"` | Field from the current record, then pipes |
| `"$root.selection.status"` | Field from the top-level record |
| `"$ctx.recruiterId"` | Value worked out by the flow (resolved IDs, files) |
| `"$cfg.flow2.attachmentCategories.resume"` | Value from config |
| `{"$each": "$.education", "$map": {...}}` | One element per input element |
| `"Text {{$.field}}"` | Text with placeholders |

Pipes: `lower upper trim digits date int bool yn string first join:SEP default:V map:VALUEMAP maxlen:N required`. Empty values are left out. `required` marks the field as missing → `NEEDS_DATA`.

**Other sections:** `mandatory`, `valueMaps` (source medium, phone legislation), `dffSegments`, `flow1.openSet`, `flow3.stageMap` (Oracle phase/state → display text, DigiHire status, final), `flow4` draft IDs, `interviewSummary.sections`, `masking`, `http.retryDelaysSeconds`.

Changing an Oracle field or stage name is a config change, not a code change.

## 7. What each flow checks (design rules)

- **401** stops every Oracle job (exit 3). **403** fails that operation with "ask AGS to enable it". **429/5xx/timeout** retries with `http.retryDelaysSeconds`.
- **Look up first** before every create: stored CandidateNumber → else email look-up. A create interrupted after Oracle's 201 is found on the next run (`inFlight` marker) – no duplicate.
- **Flow 2:** never-selected candidates are skipped. A blank last name → `NEEDS_DATA`. A closed or full requisition → `HELD`. An email used by someone else → `LINK_REQUIRED`. Handed-over profile fields are listed as locked. The Oracle recruiter gets an alert to create the application.
- **Flow 3:** reads only. It links the Oracle application by person ID, flags a different requisition, records every stage with the stage map, and sets `OFFERED`/`JOINED` per the map. It stops at a final stage, reminds the recruiter when no application appears after `flow3.waitWorkingDays`, and alerts the recruiter when DigiHire rejects or declines after hand-over.
- **Flow 1:** the validity rule is open phase/state, openings left (minus handed-over candidates), and posting end date. The live check falls back to the synced row only if the last sync is under 15 minutes old.
- **Flow 4:** recruiter and hiring manager are resolved by work email, and the location is confirmed. The flow creates or patches the header, patches the DFF via its self link, then reads back. "Pending in Oracle" clears only when Oracle shows the new values.

## 8. Moving into smartie-core (after every step passes)

| Runner class | Goes to | Notes |
|---|---|---|
| `http.OracleClient`, `http.Auth` | integration-services `oracle/OracleRestClient` | Credentials from the Admin SecretStore, not args |
| `http.CallLog` | existing `integ_call_log` / `CallLog` | Use the common-utils masking list |
| `core.TemplateEngine`, `core.RunnerConfig` | integration-services `oracle/mapping` | Config moves to `application.yml` or an admin table |
| `flow.ReferenceFlow` | `OracleReferenceService` (Flow 0) | `refCache`/`personMap` → `oracle_ref`, `oracle_person_map` |
| `flow.RequisitionSyncFlow` | job-services `RequisitionSyncService` | Same query, keyset paging, validity rule |
| `flow.CandidateHandoverFlow` | `OracleSyncWorker` (outbox `CANDIDATE_CREATE`) | `inFlight` → outbox `IN_FLIGHT`; triggered by `StatusMover` |
| `flow.OfferTrackingFlow` | `ApplicationStatusPoller` + reconciliation job | timeline → `application_movement` |
| `flow.RequisitionWriteFlow` | integration-services requisition writer (Flow 4) | Called through `RequisitionPushPort` |
| `pdf.InterviewSummaryPdf` | candidate-services, using the existing PDFBox profile export | The runner uses a tiny built-in PDF writer to avoid dependencies |
| `state.StateStore` sections | DB tables | candidates/applications → link tables; watermarks → `oracle_watermark` |
| `mock.*`, `data.*` | test code only | Keep as an integration-test fixture |

## 9. Limits of the runner

- One process, one thread. Production uses the outbox, schedulers and locks.
- `state.json` is a stand-in for the database. Keep one output folder per environment.
- The mock behaves like Oracle for these calls but is not Oracle. Real names, IDs, error texts and permissions must be proved in the AGS test pod (Gates A–F).
