package com.ags.health.hr.integration.oracle.runner.flow;

import com.ags.health.hr.integration.oracle.runner.core.Json;
import com.ags.health.hr.integration.oracle.runner.core.TemplateEngine;
import com.ags.health.hr.integration.oracle.runner.http.OracleClient;
import com.ags.health.hr.integration.oracle.runner.http.OracleException;
import com.ags.health.hr.integration.oracle.runner.state.RunReport.Status;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.node.ObjectNode;

import java.time.OffsetDateTime;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

/**
 * Flow 4 – Requisition write-back. TL uploads (CREATE) and TA Head-approved JD edits (UPDATE) are written to
 * Oracle first; DigiHire shows "Pending in Oracle" until the read-back returns the new values.
 */
public final class RequisitionWriteFlow {

    private static final String F = "flow4";
    private final FlowContext c;
    private final ReferenceFlow ref;

    public RequisitionWriteFlow(FlowContext c, ReferenceFlow ref) { this.c = c; this.ref = ref; }

    public void run() {
        c.report.section("Flow 4 – Requisition write-back");
        if (c.data.path("requisitionWrites").isEmpty()) {
            c.report.add(F, "Requisition writes", "", Status.SKIPPED, "No requisitionWrites in the input file");
            return;
        }
        for (JsonNode w : c.data.path("requisitionWrites")) {
            String id = w.path("writeId").asText(w.path("requisitionNumber").asText("write"));
            try {
                if ("UPDATE".equalsIgnoreCase(w.path("action").asText())) update(w, id);
                else create(w, id);
            } catch (OracleException e) {
                c.state.entry("requisitionWrites", id).put("status", "FAILED").put("lastError", e.getMessage());
                c.fail(F, "Requisition write", id, e);
            } finally {
                c.state.save();
            }
        }
    }

    private void create(JsonNode w, String id) throws OracleException {
        ObjectNode st = c.state.entry("requisitionWrites", id);
        if ("DONE".equals(Json.text(st, "status")) || "PENDING_IN_ORACLE".equals(Json.text(st, "status"))) {
            c.report.add(F, "Create requisition", id, Status.INFO, "Already written as " + Json.text(st, "requisitionNumber") + " – not sent again");
            return;
        }
        ObjectNode ctx = Json.obj();
        List<String> missing = new ArrayList<>();
        resolvePerson(w, "recruiterEmail", "recruiterId", ctx, missing);
        resolvePerson(w, "hiringManagerEmail", "hiringManagerId", ctx, missing);
        String loc = Json.text(w, "primaryLocationId");
        if (loc != null && !ref.exists("locationById", "locationId", loc)) missing.add("primaryLocationId " + loc + " not found in Oracle");
        ctx.put("draftPhaseId", w.path("draftPhaseId").asText(c.cfg.str("flow4.draftPhaseId", "")));
        ctx.put("draftStateId", w.path("draftStateId").asText(c.cfg.str("flow4.draftStateId", "")));
        ctx.put("recruitingType", w.path("recruitingType").asText(c.cfg.str("flow4.recruitingType", "")));
        boolean supplyNumber = c.cfg.bool("flow4.supplyRequisitionNumber", false) && w.hasNonNull("requisitionNumber");
        if (supplyNumber) ctx.put("requisitionNumber", w.get("requisitionNumber").asText());

        TemplateEngine.Result body = c.templates.render(c.cfg.mapping("requisitionCreate"), w, ctx);
        missing.addAll(body.missing);
        missing.addAll(TemplateEngine.missingPaths(body.value, c.cfg.strings("mandatory.requisitionCreate")));
        if ("N".equals(Json.text(body.value, "UnlimitedOpenings")) && Json.isEmpty(body.value.path("NumberOfOpenings"))) {
            missing.add("NumberOfOpenings (required when UnlimitedOpenings = N)");
        }
        body.warnings.forEach(x -> c.report.add(F, "Mapping", id, Status.WARN, x));
        c.savePayload(id + "-requisition-create", body.value);
        if (!missing.isEmpty()) {
            st.put("status", "NEEDS_DATA");
            c.report.add(F, "Create requisition", id, Status.NEEDS_DATA, "Nothing sent. Missing: " + missing.stream().distinct().toList());
            return;
        }
        c.report.add(F, "Check before send", id, Status.PASS, "Recruiter, hiring manager and location confirmed");

        if (supplyNumber) {
            OracleClient.Response r = c.oracle.call("requisitionByNumber", FlowContext.p("requisitionNumber", w.get("requisitionNumber").asText()), null);
            if (!r.items().isEmpty()) {
                st.put("status", "PENDING_IN_ORACLE").put("requisitionNumber", w.get("requisitionNumber").asText());
                c.report.add(F, "Look up first", id, Status.PASS, "Requisition already exists in Oracle – earlier create had succeeded");
                return;
            }
        }
        if (c.options.dryRun()) {
            c.report.add(F, "Create requisition", id, Status.DRY_RUN, "Payload saved to payloads/" + id + "-requisition-create.json – not sent");
            return;
        }
        st.put("status", "IN_FLIGHT").put("at", OffsetDateTime.now().toString());
        c.state.save();
        OracleClient.Response r = c.oracle.call("requisitionCreate", FlowContext.p(), body.value);
        String number = Json.text(r.json(), "RequisitionNumber");
        st.put("requisitionNumber", number);
        st.put("requisitionId", Json.text(r.json(), "RequisitionId"));
        st.put("status", "PENDING_IN_ORACLE");
        c.state.entry("requisitions", number).put("pendingInOracle", true);
        c.report.add(F, "Create requisition", id, Status.PASS,
                number + " created (" + Json.text(r.json(), "PhaseName") + " › " + Json.text(r.json(), "StateName") + ") – Oracle approval applies");
        ObjectNode expected = (ObjectNode) body.value.deepCopy();
        patchDff(w, id, number, expected);
        readBack(id, number, expected, st);
    }

    private void update(JsonNode w, String id) throws OracleException {
        String number = Json.text(w, "requisitionNumber");
        if (number == null) {
            c.report.add(F, "Update requisition", id, Status.NEEDS_DATA, "requisitionNumber is required for UPDATE");
            return;
        }
        ObjectNode st = c.state.entry("requisitionWrites", id);
        TemplateEngine.Result body = c.templates.render(c.cfg.mapping("requisitionHeaderPatch"), w, Json.obj());
        body.warnings.forEach(x -> c.report.add(F, "Mapping", id, Status.WARN, x));
        ObjectNode expected = body.value.isObject() ? (ObjectNode) body.value.deepCopy() : Json.obj();
        if (!expected.isEmpty()) {
            c.savePayload(id + "-requisition-header-patch", body.value);
            if (c.options.dryRun()) {
                c.report.add(F, "Update header", id, Status.DRY_RUN, "Payload saved – not sent");
            } else {
                String uniq = requisitionUniqId(number);
                if (uniq == null) {
                    c.report.add(F, "Update header", id, Status.FAIL, "Requisition " + number + " not found or no self link");
                    return;
                }
                c.oracle.call("requisitionHeaderPatch", FlowContext.p("reqUniqId", uniq), body.value);
                st.put("status", "PENDING_IN_ORACLE").put("requisitionNumber", number);
                c.state.entry("requisitions", number).put("pendingInOracle", true);
                c.report.add(F, "Update header", id, Status.PASS, "PATCH accepted for " + expected.fieldNames().next() + (expected.size() > 1 ? " and " + (expected.size() - 1) + " more field(s)" : ""));
            }
        }
        patchDff(w, id, number, expected);
        if (!c.options.dryRun()) readBack(id, number, expected, st);
    }

    private void patchDff(JsonNode w, String id, String number, ObjectNode expected) throws OracleException {
        JsonNode dff = w.path("dff");
        if (!dff.isObject() || dff.isEmpty()) return;
        ObjectNode body = Json.obj();
        Iterator<Map.Entry<String, JsonNode>> it = dff.fields();
        while (it.hasNext()) {
            Map.Entry<String, JsonNode> e = it.next();
            String seg = Json.text(c.cfg.root(), "dffSegments." + e.getKey());
            if (seg == null) c.report.add(F, "Custom field (DFF)", id, Status.WARN, "No dffSegments entry for '" + e.getKey() + "' – not sent");
            else body.set(seg, e.getValue());
        }
        if (body.isEmpty()) return;
        c.savePayload(id + "-requisition-dff-patch", body);
        if (c.options.dryRun()) {
            c.report.add(F, "Update custom fields (DFF)", id, Status.DRY_RUN, "Payload saved – not sent");
            return;
        }
        String uniq = requisitionUniqId(number);
        OracleClient.Response g = c.oracle.call("requisitionDffGet", FlowContext.p("reqUniqId", uniq), null);
        String dffUniq = FlowContext.selfUniqId(g.first());
        if (dffUniq == null) {
            c.report.add(F, "Update custom fields (DFF)", id, Status.FAIL, "No DFF row / self link returned for " + number);
            return;
        }
        c.oracle.call("requisitionDffPatch", FlowContext.p("reqUniqId", uniq, "dffUniqId", dffUniq), body);
        ObjectNode dffExpected = expected.putObject("requisitionDFF");
        dffExpected.setAll(body);
        c.report.add(F, "Update custom fields (DFF)", id, Status.PASS, "PATCH accepted: " + body.size() + " segment(s)");
    }

    private void readBack(String id, String number, ObjectNode expected, ObjectNode st) throws OracleException {
        OracleClient.Response r = c.oracle.call("requisitionByNumber", FlowContext.p("requisitionNumber", number), null);
        JsonNode item = r.first();
        List<String> diffs = new ArrayList<>();
        Iterator<Map.Entry<String, JsonNode>> it = expected.fields();
        while (it.hasNext()) {
            Map.Entry<String, JsonNode> e = it.next();
            if (e.getKey().equals("requisitionDFF")) {
                JsonNode got = item.path("requisitionDFF").path(0);
                e.getValue().fields().forEachRemaining(d -> {
                    if (!d.getValue().asText().equals(got.path(d.getKey()).asText())) diffs.add("DFF " + d.getKey());
                });
            } else if (c.cfg.strings("flow4.readBackFields").contains(e.getKey())
                    && !e.getValue().asText().equals(item.path(e.getKey()).asText())) {
                diffs.add(e.getKey());
            }
        }
        ObjectNode row = c.state.entry("requisitions", number);
        if (diffs.isEmpty()) {
            row.put("pendingInOracle", false);
            st.put("status", "DONE");
            c.report.add(F, "Read back", id, Status.PASS, "Oracle shows the new values – \"Pending in Oracle\" cleared");
        } else {
            row.put("pendingInOracle", true);
            c.report.add(F, "Read back", id, Status.WARN, "Oracle does not show yet: " + diffs + " – stays \"Pending in Oracle\" (approval?)");
        }
    }

    private String requisitionUniqId(String number) throws OracleException {
        OracleClient.Response r = c.oracle.call("requisitionForUpdate", FlowContext.p("requisitionNumber", number), null);
        return r.items().isEmpty() ? null : FlowContext.selfUniqId(r.first());
    }

    private void resolvePerson(JsonNode w, String emailField, String ctxKey, ObjectNode ctx, List<String> missing) throws OracleException {
        String email = Json.text(w, emailField);
        if (email == null) { missing.add(emailField); return; }
        JsonNode p = ref.workerByEmail(email, false);
        if (p == null) missing.add(emailField + " (" + ReferenceFlow.mask(email) + ") not active in Oracle");
        else ctx.put(ctxKey, Long.parseLong(p.path("PersonId").asText()));
    }
}
