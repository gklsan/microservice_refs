package com.ags.health.hr.integration.oracle.runner.flow;

import com.ags.health.hr.integration.oracle.runner.core.Json;
import com.ags.health.hr.integration.oracle.runner.core.TemplateEngine;
import com.ags.health.hr.integration.oracle.runner.http.OracleClient;
import com.ags.health.hr.integration.oracle.runner.http.OracleException;
import com.ags.health.hr.integration.oracle.runner.state.RunReport.Status;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.node.ObjectNode;

import java.time.OffsetDateTime;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Flow 1 – Requisition sync: 15-minute delta (keyset paging on RequisitionLastModifiedDate),
 * optional nightly full pass, and the live validity check used at candidate mapping.
 */
public final class RequisitionSyncFlow {

    private static final String F = "flow1";
    private final FlowContext c;

    public RequisitionSyncFlow(FlowContext c) { this.c = c; }

    public record Validity(boolean mappable, List<String> reasons) {
        public String text() { return mappable ? "Mappable" : "Not mappable → Pipeline › On Hold: " + String.join("; ", reasons); }
    }

    public void run() {
        c.report.section("Flow 1 – Requisition sync");
        delta();
        if (c.options.fullPass()) fullPass();
        for (JsonNode n : c.data.path("requisitionChecks")) {
            liveCheck(n.isTextual() ? n.asText() : Json.text(n, "requisitionNumber"), true);
        }
        c.state.save();
    }

    private void delta() {
        String start = c.state.watermark("requisitions");
        if (start == null) start = Json.text(c.data, "requisitionSync.initialWatermark");
        if (start == null) start = c.cfg.str("flow1.initialWatermark", "2026-01-01T00:00:00Z");
        String since = minusOverlap(start);
        int limit = c.cfg.integer("paging.pageSize", 100);
        int maxPages = c.cfg.integer("paging.maxPages", 500);
        int offset = 0, pages = 0;
        Set<String> seen = new HashSet<>();
        String maxTs = start;
        try {
            while (pages++ < maxPages) {
                OracleClient.Response r = c.oracle.call("requisitionDelta",
                        FlowContext.p("since", since, "limit", String.valueOf(limit), "offset", offset == 0 ? null : String.valueOf(offset)), null);
                String lastTs = null;
                for (JsonNode item : r.items()) {
                    upsert(item);
                    seen.add(item.path("RequisitionId").asText());
                    lastTs = Json.text(item, "RequisitionLastModifiedDate");
                    if (lastTs != null && after(lastTs, maxTs)) maxTs = lastTs;
                }
                if (!r.hasMore() || r.items().isEmpty()) break;
                if (lastTs == null || !after(lastTs, since)) offset += r.items().size();
                else { since = lastTs; offset = 0; }
            }
            c.state.watermark("requisitions", maxTs);
            c.state.markRun("requisitions");
            c.report.add(F, "Delta sync (keyset paging)", "", Status.PASS,
                    seen.size() + " requisition(s) updated in " + (pages) + " page(s); saved time now " + maxTs);
        } catch (OracleException e) {
            c.fail(F, "Delta sync", "", e);
            c.report.add(F, "Delta sync", "", Status.INFO, "Saved time NOT moved; next run restarts from " + start);
        }
    }

    private void fullPass() {
        int limit = c.cfg.integer("paging.fullPassPageSize", 200);
        int offset = 0, count = 0, pages = 0;
        try {
            while (pages++ < c.cfg.integer("paging.maxPages", 500)) {
                OracleClient.Response r = c.oracle.call("requisitionFull",
                        FlowContext.p("limit", String.valueOf(limit), "offset", String.valueOf(offset)), null);
                for (JsonNode item : r.items()) { upsert(item); count++; }
                if (!r.hasMore() || r.items().isEmpty()) break;
                offset += r.items().size();
            }
            c.report.add(F, "Nightly full pass", "", Status.PASS, count + " requisition(s) read");
        } catch (OracleException e) {
            c.fail(F, "Nightly full pass", "", e);
        }
    }

    /** Maps one Oracle requisition into the DigiHire row (config.mappings.requisitionRow + dffSegments). */
    ObjectNode upsert(JsonNode item) {
        TemplateEngine.Result res = c.templates.render(c.cfg.mapping("requisitionRow"), item, Json.obj());
        ObjectNode row = res.value.isObject() ? (ObjectNode) res.value : Json.obj();
        ObjectNode dff = row.putObject("dff");
        JsonNode dffItem = item.path("requisitionDFF").path(0);
        Iterator<Map.Entry<String, JsonNode>> it = c.cfg.at("dffSegments").fields();
        while (it.hasNext()) {
            Map.Entry<String, JsonNode> e = it.next();
            if (e.getKey().startsWith("$")) continue;
            JsonNode v = dffItem.path(e.getValue().asText());
            if (!v.isMissingNode() && !v.isNull()) dff.set(e.getKey(), v);
        }
        row.put("syncedAt", OffsetDateTime.now().toString());
        String number = item.path("RequisitionNumber").asText();
        ObjectNode existing = c.state.entry("requisitions", number);
        boolean pending = existing.path("pendingInOracle").asBoolean(false);
        existing.removeAll();
        existing.setAll(row);
        if (pending) existing.put("pendingInOracle", true);
        Validity v = validity(existing);
        existing.put("mappable", v.mappable());
        existing.put("validityText", v.text());
        return existing;
    }

    /** Live check at mapping. Falls back to the synced row only when the last successful sync is recent. */
    public Validity liveCheck(String requisitionNumber, boolean report) {
        try {
            OracleClient.Response r = c.oracle.call("requisitionLiveCheck", FlowContext.p("requisitionNumber", requisitionNumber), null);
            JsonNode item = r.first();
            if (item.isMissingNode()) {
                Validity v = new Validity(false, List.of("requisition not found in Oracle"));
                if (report) c.report.add(F, "Live check at mapping", requisitionNumber, Status.HELD, v.text());
                return v;
            }
            ObjectNode row = c.state.entry("requisitions", requisitionNumber);
            for (String k : new String[]{"PhaseName:phase", "StateName:state", "NumberOfOpenings:numberOfOpenings",
                    "UnlimitedOpenings:unlimitedOpenings", "HiredCount:hiredCount", "ExternalPublishedJobEndDate:externalPostingEnd"}) {
                String[] kv = k.split(":");
                JsonNode val = item.path(kv[0]);
                if (!val.isMissingNode()) row.set(kv[1], val);
            }
            Validity v = validity(row);
            row.put("mappable", v.mappable());
            if (report) c.report.add(F, "Live check at mapping", requisitionNumber, v.mappable() ? Status.PASS : Status.HELD,
                    v.text() + " (" + r.ms() + " ms)");
            return v;
        } catch (OracleException e) {
            if (e.kind() == OracleException.Kind.TIMEOUT || e.kind() == OracleException.Kind.RETRYABLE) {
                String last = c.state.lastRun("requisitions");
                JsonNode row = c.state.get("requisitions", requisitionNumber);
                int minutes = c.cfg.integer("flow1.liveCheckFallbackMinutes", 15);
                boolean recent = last != null && OffsetDateTime.parse(last).isAfter(OffsetDateTime.now().minusMinutes(minutes));
                if (recent && row.isObject() && row.has("phase")) {
                    Validity v = validity(row);
                    if (report) c.report.add(F, "Live check at mapping", requisitionNumber, Status.WARN,
                            "Oracle did not answer in time – used synced row (last sync " + last + "): " + v.text());
                    return v;
                }
                Validity v = new Validity(false, List.of("Requisition status unavailable"));
                if (report) c.report.add(F, "Live check at mapping", requisitionNumber, Status.BLOCKED,
                        "Oracle did not answer in time and no sync in the last " + minutes + " min – mapping blocked");
                return v;
            }
            c.fail(F, "Live check at mapping", requisitionNumber, e);
            return new Validity(false, List.of(e.getMessage()));
        }
    }

    /** Validity rule: open phase/state, openings left, posting end date not passed. */
    public Validity validity(JsonNode row) {
        List<String> reasons = new ArrayList<>();
        String phase = Json.text(row, "phase"), state = Json.text(row, "state");
        boolean open = false;
        for (JsonNode o : c.cfg.at("flow1.openSet")) {
            if (matches(o.path("phase").asText(), phase) && matches(o.path("state").asText(), state)) { open = true; break; }
        }
        if (!open) reasons.add("phase/state " + phase + " › " + state + " is not in the open set");

        boolean unlimited = "Y".equalsIgnoreCase(Json.text(row, "unlimitedOpenings"));
        if (!unlimited) {
            int openings = row.path("numberOfOpenings").asInt(0);
            int hired = row.path("hiredCount").asInt(0);
            int handedOver = c.cfg.bool("flow1.countHandedOverAgainstOpenings", true) ? handedOverCount(Json.text(row, "requisitionNumber")) : 0;
            int left = openings - hired - handedOver;
            if (left <= 0) reasons.add("no openings left (openings " + openings + ", hired " + hired + ", handed over " + handedOver + ")");
        }
        String end = Json.text(row, "externalPostingEnd");
        if (end != null && !end.isBlank()) {
            try {
                if (OffsetDateTime.parse(end).isBefore(OffsetDateTime.now())) reasons.add("posting end date " + end.substring(0, 10) + " has passed");
            } catch (Exception ignored) {
                reasons.add("cannot read posting end date '" + end + "'");
            }
        }
        return new Validity(reasons.isEmpty(), reasons);
    }

    private int handedOverCount(String requisitionNumber) {
        if (requisitionNumber == null) return 0;
        int n = 0;
        Iterator<JsonNode> it = c.state.section("applications").elements();
        while (it.hasNext()) {
            JsonNode a = it.next();
            if (requisitionNumber.equals(Json.text(a, "requisitionNumber")) && a.path("handedOver").asBoolean(false)
                    && !a.path("final").asBoolean(false)) n++;
        }
        return n;
    }

    /** True when a is later than b (compares instants, so "Z" and "+00:00" agree). */
    static boolean after(String a, String b) {
        try {
            return OffsetDateTime.parse(a).isAfter(OffsetDateTime.parse(b));
        } catch (Exception e) {
            return a.compareTo(b) > 0;
        }
    }

    private static boolean matches(String pattern, String value) {
        return "*".equals(pattern) || (value != null && pattern.equalsIgnoreCase(value));
    }

    String minusOverlap(String ts) {
        try {
            OffsetDateTime t = OffsetDateTime.parse(ts).minusMinutes(c.cfg.integer("paging.overlapMinutes", 2));
            return t.withOffsetSameInstant(ZoneOffset.UTC).format(DateTimeFormatter.ofPattern(c.cfg.str("oracle.dateFormat", "yyyy-MM-dd'T'HH:mm:ssXXX")));
        } catch (Exception e) {
            return ts;
        }
    }
}
