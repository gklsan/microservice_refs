package com.ags.health.hr.integration.oracle.runner.core;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Turns a JSON template from config into a request body, so payloads are not hard-coded.
 *
 * <pre>
 * "$.firstName"                 value from the current item (the candidate, or the array element inside $each)
 * "$root.selection.status"      value from the top-level input record
 * "$ctx.resume.base64"          value computed by the flow (resolved Oracle IDs, files)
 * "$cfg.flow4.recruitingType"   value from config
 * "$.email|lower|required"      pipes: lower, upper, trim, digits, date, int, bool, yn, string, first,
 *                               join:SEP, default:VALUE, map:VALUE_MAP, maxlen:N, required
 * "Selected on {{$.date}}"      text with placeholders
 * {"$each": "$.education", "$map": {...}}   one output element per input element
 * </pre>
 * Empty values are left out of the output; "required" records the field as missing.
 */
public final class TemplateEngine {

    private static final Pattern EXPR = Pattern.compile("^\\$(root|ctx|cfg)?((?:\\.[^|]*)?)((?:\\|.*)?)$");
    private static final Pattern INTERP = Pattern.compile("\\{\\{(.+?)}}");

    private final RunnerConfig cfg;

    public TemplateEngine(RunnerConfig cfg) { this.cfg = cfg; }

    public static final class Result {
        public final JsonNode value;
        public final List<String> missing;
        public final List<String> warnings;
        Result(JsonNode value, List<String> missing, List<String> warnings) {
            this.value = value; this.missing = missing; this.warnings = warnings;
        }
        public boolean ok() { return missing.isEmpty(); }
    }

    private static final class Ctx {
        final JsonNode root; final JsonNode ctx;
        final List<String> missing = new ArrayList<>();
        final List<String> warnings = new ArrayList<>();
        Ctx(JsonNode root, JsonNode ctx) { this.root = root; this.ctx = ctx; }
    }

    public Result render(JsonNode template, JsonNode root, JsonNode ctx) {
        Ctx c = new Ctx(root, ctx == null ? Json.obj() : ctx);
        JsonNode out = node(template, root, c, "");
        return new Result(out == null ? Json.obj() : out, c.missing, c.warnings);
    }

    private JsonNode node(JsonNode t, JsonNode item, Ctx c, String field) {
        if (t == null || t.isNull()) return null;
        if (t.isTextual()) return text(t.asText(), item, c, field);
        if (t.isArray()) {
            ArrayNode out = Json.arr();
            int i = 0;
            for (JsonNode el : t) {
                JsonNode v = node(el, item, c, field + "[" + i++ + "]");
                if (v instanceof ArrayNode && el.has("$each")) {
                    v.forEach(out::add);
                } else if (!Json.isEmpty(v)) {
                    out.add(v);
                }
            }
            return out.isEmpty() ? null : out;
        }
        if (t.isObject()) {
            if (t.has("$each")) return each(t, item, c, field);
            ObjectNode out = Json.obj();
            Iterator<Map.Entry<String, JsonNode>> it = t.fields();
            while (it.hasNext()) {
                Map.Entry<String, JsonNode> e = it.next();
                if (e.getKey().startsWith("$comment")) continue;
                String f = field.isEmpty() ? e.getKey() : field + "." + e.getKey();
                JsonNode v = node(e.getValue(), item, c, f);
                if (!Json.isEmpty(v) || (v != null && v.isBoolean())) out.set(e.getKey(), v);
            }
            return out.isEmpty() ? null : out;
        }
        return t; // numbers and booleans pass through
    }

    private JsonNode each(JsonNode t, JsonNode item, Ctx c, String field) {
        JsonNode src = expr(t.get("$each").asText(), item, c, field);
        ArrayNode out = Json.arr();
        if (src != null && src.isArray()) {
            int i = 0;
            for (JsonNode el : src) {
                JsonNode v = node(t.get("$map"), el, c, field + "[" + i++ + "]");
                if (!Json.isEmpty(v)) out.add(v);
            }
        }
        return out.isEmpty() ? null : out;
    }

    private JsonNode text(String s, JsonNode item, Ctx c, String field) {
        if (s.startsWith("$") && EXPR.matcher(s).matches()) return expr(s, item, c, field);
        if (!s.contains("{{")) return Json.F.textNode(s);
        Matcher m = INTERP.matcher(s);
        StringBuilder sb = new StringBuilder();
        while (m.find()) {
            JsonNode v = expr(m.group(1).trim(), item, c, field);
            m.appendReplacement(sb, Matcher.quoteReplacement(Json.isEmpty(v) ? "" : v.asText()));
        }
        m.appendTail(sb);
        return Json.F.textNode(sb.toString());
    }

    /** Evaluates one "$..." expression including its pipes. */
    public JsonNode expr(String s, JsonNode item, JsonNode root, JsonNode ctx) {
        return expr(s, item, new Ctx(root, ctx), "");
    }

    private JsonNode expr(String s, JsonNode item, Ctx c, String field) {
        Matcher m = EXPR.matcher(s);
        if (!m.matches()) return Json.F.textNode(s);
        String scope = m.group(1);
        String path = m.group(2).startsWith(".") ? m.group(2).substring(1) : m.group(2);
        JsonNode base = scope == null ? item : switch (scope) {
            case "root" -> c.root;
            case "ctx" -> c.ctx;
            case "cfg" -> cfg.root();
            default -> item;
        };
        JsonNode v = Json.at(base, path);
        if (v.isMissingNode() || v.isNull()) v = null;
        String pipes = m.group(3);
        if (pipes != null && !pipes.isEmpty()) {
            for (String p : pipes.substring(1).split("\\|")) {
                v = pipe(p.stripLeading(), v, c, field.isEmpty() ? s : field);
            }
        }
        return v;
    }

    private JsonNode pipe(String p, JsonNode v, Ctx c, String field) {
        String name = (p.contains(":") ? p.substring(0, p.indexOf(':')) : p).strip();
        String arg = p.contains(":") ? p.substring(p.indexOf(':') + 1) : null;
        switch (name) {
            case "required":
                if (Json.isEmpty(v)) c.missing.add(field);
                return v;
            case "default":
                return Json.isEmpty(v) ? Json.F.textNode(arg) : v;
            case "defaultBool":
                return Json.isEmpty(v) ? Json.F.booleanNode(Boolean.parseBoolean(arg)) : v;
        }
        if (Json.isEmpty(v)) return null;
        String t = v.isValueNode() ? v.asText() : null;
        switch (name) {
            case "lower": return Json.F.textNode(t.toLowerCase(Locale.ROOT));
            case "upper": return Json.F.textNode(t.toUpperCase(Locale.ROOT));
            case "trim": return Json.F.textNode(t.trim());
            case "digits": return Json.F.textNode(t.replaceAll("\\D", ""));
            case "date": return Json.F.textNode(t.length() >= 10 ? t.substring(0, 10) : t);
            case "int": return Json.F.numberNode(Long.parseLong(t.trim()));
            case "bool": return Json.F.booleanNode(Boolean.parseBoolean(t) || "Y".equalsIgnoreCase(t));
            case "yn": return Json.F.textNode(Boolean.parseBoolean(t) || "Y".equalsIgnoreCase(t) ? "Y" : "N");
            case "string": return Json.F.textNode(v.isValueNode() ? t : Json.compact(v));
            case "maxlen": {
                int n = Integer.parseInt(arg);
                return Json.F.textNode(t.length() > n ? t.substring(0, n) : t);
            }
            case "first": return v.isArray() ? (v.isEmpty() ? null : v.get(0)) : v;
            case "join": {
                if (!v.isArray()) return v;
                List<String> parts = new ArrayList<>();
                v.forEach(x -> parts.add(x.asText()));
                return Json.F.textNode(String.join(arg == null ? ", " : arg, parts));
            }
            case "map": {
                JsonNode mapped = cfg.at("valueMaps." + arg + "." + t);
                if (mapped.isMissingNode() || mapped.isNull() || mapped.asText().isEmpty()) {
                    c.warnings.add("No value for '" + t + "' in valueMaps." + arg + " (field " + field + ")");
                    return null;
                }
                return mapped;
            }
            default:
                c.warnings.add("Unknown pipe '" + name + "' on field " + field);
                return v;
        }
    }

    /** Checks dotted paths (with [n]) are present and not blank in a rendered payload. */
    public static List<String> missingPaths(JsonNode payload, List<String> paths) {
        List<String> out = new ArrayList<>();
        for (String p : paths) if (Json.isEmpty(Json.at(payload, p))) out.add(p);
        return out;
    }
}
