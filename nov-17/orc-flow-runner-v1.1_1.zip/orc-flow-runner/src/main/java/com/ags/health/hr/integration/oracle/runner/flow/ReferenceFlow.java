package com.ags.health.hr.integration.oracle.runner.flow;

import com.ags.health.hr.integration.oracle.runner.core.Json;
import com.ags.health.hr.integration.oracle.runner.http.OracleClient;
import com.ags.health.hr.integration.oracle.runner.http.OracleException;
import com.ags.health.hr.integration.oracle.runner.state.RunReport.Status;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;

import java.time.Duration;
import java.time.OffsetDateTime;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.Set;
import java.util.TreeSet;

/**
 * Flow 0 – Reference data and ID check. Also used by Flows 2 and 4 to find and confirm IDs before a write.
 * Results are cached in state.refCache / state.personMap with the time they were checked.
 */
public final class ReferenceFlow {

    private static final String F = "flow0";
    private final FlowContext c;

    public ReferenceFlow(FlowContext c) { this.c = c; }

    public void run() {
        c.report.section("Flow 0 – Reference data and ID check");

        for (JsonNode n : c.data.path("requisitionChecks")) {
            String req = n.isTextual() ? n.asText() : Json.text(n, "requisitionNumber");
            try {
                hiringTeam(req, true);
            } catch (OracleException e) {
                c.fail(F, "Requisition hiring team", req, e);
            }
        }

        Set<String> emails = new LinkedHashSet<>();
        c.data.path("workerEmails").forEach(e -> emails.add(e.asText()));
        c.candidates().forEach(cd -> { String e = Json.text(cd, "selection.recruiterEmail"); if (e != null) emails.add(e); });
        c.data.path("requisitionWrites").forEach(w -> {
            String r = Json.text(w, "recruiterEmail"); if (r != null) emails.add(r);
            String h = Json.text(w, "hiringManagerEmail"); if (h != null) emails.add(h);
        });
        for (String email : emails) {
            try {
                JsonNode p = workerByEmail(email, true);
                if (p == null) c.report.add(F, "Worker by work email", mask(email), Status.WARN, "Not found / not active in Oracle");
                else c.report.add(F, "Worker by work email", mask(email), Status.PASS,
                        "PersonId " + p.path("PersonId").asText() + " (" + p.path("DisplayName").asText() + ")");
            } catch (OracleException e) {
                c.fail(F, "Worker by work email", mask(email), e);
            }
        }

        describe("candidateDescribe", "describe-candidate.json", "recruitingCandidates", "candidateCreate");
        describe("requisitionDescribe", "describe-requisition.json", "recruitingJobRequisitions", "requisitionCreate");
        c.state.markRun("reference");
        c.state.save();
    }

    /** Resolves the requisition's Oracle IDs and confirms each one (recruiter, hiring manager, job, department, location). */
    public JsonNode hiringTeam(String requisitionNumber, boolean report) throws OracleException {
        ObjectNode cache = c.state.entry("refCache", "REQ:" + requisitionNumber);
        if (!report && fresh(cache)) return cache;
        OracleClient.Response r = c.oracle.call("requisitionHiringTeam", FlowContext.p("requisitionNumber", requisitionNumber), null);
        JsonNode req = r.first();
        if (req.isMissingNode()) {
            if (report) c.report.add(F, "Requisition hiring team", requisitionNumber, Status.WARN, "Requisition not found in Oracle");
            return null;
        }
        cache.removeAll();
        cache.setAll((ObjectNode) req.deepCopy());
        cache.put("checkedAt", OffsetDateTime.now().toString());
        if (report) c.report.add(F, "Requisition hiring team", requisitionNumber, Status.PASS,
                "RequisitionId " + req.path("RequisitionId").asText());

        check(report, requisitionNumber, "Recruiter active", "workerByPersonId", "personId", Json.text(req, "RecruiterId"));
        check(report, requisitionNumber, "Hiring manager active", "workerByPersonId", "personId", Json.text(req, "HiringManagerId"));
        check(report, requisitionNumber, "Job valid", "jobById", "jobId", Json.text(req, "JobId"));
        check(report, requisitionNumber, "Department valid", "departmentById", "departmentId", Json.text(req, "DepartmentId"));
        String loc = Json.text(req, "PrimaryWorkLocationId") != null ? Json.text(req, "PrimaryWorkLocationId") : Json.text(req, "PrimaryLocationId");
        check(report, requisitionNumber, "Location valid", "locationById", "locationId", loc);
        return cache;
    }

    private void check(boolean report, String req, String label, String op, String param, String id) throws OracleException {
        if (id == null) {
            if (report) c.report.add(F, label, req, Status.WARN, "No ID on the requisition");
            return;
        }
        boolean ok = exists(op, param, id);
        if (report) c.report.add(F, label, req, ok ? Status.PASS : Status.WARN, (ok ? "Confirmed " : "NOT found / inactive: ") + param + "=" + id);
    }

    /** True when the GET returns at least one item. Cached for oracle cacheTtlHours. */
    public boolean exists(String op, String param, String id) throws OracleException {
        ObjectNode cache = c.state.entry("refCache", op + ":" + id);
        if (fresh(cache)) return cache.path("exists").asBoolean();
        OracleClient.Response r = c.oracle.call(op, FlowContext.p(param, id), null);
        boolean ok = r.items().size() > 0;
        cache.put("exists", ok);
        cache.put("checkedAt", OffsetDateTime.now().toString());
        if (ok) cache.set("item", r.first());
        return ok;
    }

    /** DigiHire user → Oracle person by work email (state.personMap). Null when not found. */
    public JsonNode workerByEmail(String email, boolean force) throws OracleException {
        String key = email.toLowerCase();
        JsonNode cached = c.state.get("personMap", key);
        if (!force && cached.isObject() && fresh(cached)) return cached.path("active").asBoolean() ? cached : null;
        OracleClient.Response r = c.oracle.call("workerByEmail", FlowContext.p("email", email), null);
        ObjectNode e = c.state.entry("personMap", key);
        e.removeAll();
        JsonNode item = r.first();
        e.put("active", !item.isMissingNode());
        e.put("checkedAt", OffsetDateTime.now().toString());
        if (!item.isMissingNode()) {
            e.put("PersonId", item.path("PersonId").asText());
            e.put("PersonNumber", item.path("PersonNumber").asText());
            e.put("DisplayName", item.path("DisplayName").asText());
        }
        return item.isMissingNode() ? null : e;
    }

    private boolean fresh(JsonNode cache) {
        String at = Json.text(cache, "checkedAt");
        if (at == null) return false;
        return OffsetDateTime.parse(at).isAfter(OffsetDateTime.now().minus(Duration.ofHours(c.cfg.integer("cacheTtlHours", 24))));
    }

    /** Saves the describe output and checks the field names our payload templates use actually exist. */
    private void describe(String op, String file, String resource, String mapping) {
        try {
            OracleClient.Response r = c.oracle.call(op, FlowContext.p(), null);
            Json.writeFile(c.outDir.resolve(file), r.json());
            Set<String> names = new TreeSet<>();
            collectNames(r.json(), names);
            c.report.add(F, "Describe " + resource, "", Status.PASS, names.size() + " attribute / child names saved to " + file);

            Set<String> unknown = new TreeSet<>();
            Iterator<String> it = c.cfg.mapping(mapping).fieldNames();
            while (it.hasNext()) {
                String k = it.next();
                if (!k.startsWith("$") && !names.contains(k)) unknown.add(k);
            }
            if (unknown.isEmpty()) c.report.add(F, "Template fields exist in Oracle", mapping, Status.PASS, "All top-level fields found in describe");
            else c.report.add(F, "Template fields exist in Oracle", mapping, Status.WARN, "Not in describe: " + unknown + " – check names in config.mappings." + mapping);
        } catch (OracleException e) {
            c.fail(F, "Describe " + resource, "", e);
        }
    }

    private static void collectNames(JsonNode n, Set<String> out) {
        if (n.isObject()) {
            JsonNode attrs = n.get("attributes");
            if (attrs instanceof ArrayNode) attrs.forEach(a -> { if (a.has("name")) out.add(a.get("name").asText()); });
            JsonNode children = n.get("children");
            if (children != null && children.isObject()) children.fieldNames().forEachRemaining(out::add);
            n.forEach(ch -> collectNames(ch, out));
        } else if (n.isArray()) {
            n.forEach(ch -> collectNames(ch, out));
        }
    }

    static String mask(String email) {
        int at = email.indexOf('@');
        return at <= 1 ? email : email.charAt(0) + "***" + email.substring(at);
    }
}
