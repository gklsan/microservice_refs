package com.ags.health.hr.integration.oracle.runner.data;

import com.ags.health.hr.integration.oracle.runner.core.Json;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;

import java.time.LocalDate;
import java.util.List;
import java.util.Locale;
import java.util.Random;

/**
 * Random but realistic test input. The first eight candidates cover each design case in a fixed order;
 * any extra candidates are random selections. Blocks named "mock" are read only by the embedded mock.
 */
public final class SampleDataGenerator {

    private static final String[] FIRST = {"Priya", "Arun", "Kavya", "Rahul", "Divya", "Karthik", "Sneha", "Vignesh", "Anitha", "Suresh",
            "Meena", "Ganesh", "Lakshmi", "Prakash", "Nithya", "Vijay", "Deepa", "Hari", "Revathi", "Manoj"};
    private static final String[] LAST = {"Raman", "Kumar", "Nair", "Iyer", "Subramanian", "Krishnan", "Reddy", "Menon", "Pillai", "Rao",
            "Natarajan", "Shankar", "Mohan", "Srinivasan", "Balaji"};
    private static final String[] CITY = {"Chennai", "Coimbatore", "Tiruchirappalli", "Madurai", "Hyderabad", "Bengaluru"};
    private static final String[] COLLEGE = {"Loyola College", "Madras University", "PSG College of Arts and Science", "Anna University",
            "Bharathiar University", "St. Joseph's College"};
    private static final String[] DEGREE = {"B.Com", "B.Sc Nursing", "BBA", "B.Sc Computer Science", "B.Pharm", "M.Com"};
    private static final String[] EMPLOYER = {"Acme RCM", "MedBill Services", "Omega Healthcare", "CareClaims Pvt Ltd", "HealthFirst BPO"};
    private static final String[] TITLE = {"AR Caller", "AR Analyst", "Medical Coder", "Payment Poster", "Customer Support Executive"};
    private static final String[] SKILLS = {"Medical billing", "AR calling", "Denial management", "CPT coding", "ICD-10", "Epic", "Excel",
            "Insurance verification", "Voice process"};
    private static final String[][] SOURCES = {{"JOB_PORTAL", "Naukri"}, {"SOCIAL_MEDIA", "LINKEDIN"}, {"AGS_EMPLYOEE", "EMP10423"},
            {"CAMPUS", "Loyola College"}, {"VENDOR", "TalentBridge Consultancy"}, {"AGS_HR", "Kavya Raman"}, {"JOB_FAIR", "Chennai Job Fair Nov 2026"}};

    private SampleDataGenerator() { }

    public static ObjectNode generate(int count, int seed) {
        Random r = new Random(seed);
        ObjectNode root = Json.obj();
        ObjectNode meta = root.putObject("meta");
        meta.put("description", "Random DigiHire test data for the ORC flow runner. Replace requisition numbers, worker emails and IDs with real test-pod values for a live run. 'mock' blocks are used only with --mock.");
        meta.put("generatedOn", LocalDate.now().toString());
        meta.put("seed", seed);

        ObjectNode overrides = root.putObject("configOverrides");
        overrides.put("$comment", "Merged over the config for this data file. Values below suit the embedded mock; set the AGS values for a live run.");
        overrides.putObject("flow4").put("draftPhaseId", "1").put("draftStateId", "1").put("recruitingType", "ORA_PROFESSIONAL");
        overrides.putObject("flow3").put("waitWorkingDays", 0);

        root.putObject("requisitionSync").put("initialWatermark", "2026-11-01T00:00:00Z");
        root.putObject("applicationTracking").put("initialWatermark", "2026-11-01T00:00:00Z");

        ArrayNode checks = root.putArray("requisitionChecks");
        for (String s : new String[]{"REQ-10452", "REQ-10453", "REQ-10454", "REQ-10455", "REQ-10456", "REQ-10499"}) checks.add(s);
        ArrayNode emails = root.putArray("workerEmails");
        for (String s : new String[]{"recruiter.kavya@agshealth.com", "hm.arun@agshealth.com", "tl.priya@agshealth.com", "former.user@agshealth.com"}) emails.add(s);

        ArrayNode cands = root.putArray("candidates");
        int n = Math.max(1, count);
        for (int i = 0; i < n; i++) cands.add(candidate(r, i, seed));

        ArrayNode writes = root.putArray("requisitionWrites");
        ObjectNode w1 = writes.addObject();
        w1.put("writeId", "TL-UPLOAD-" + seed + "-1");
        w1.put("action", "CREATE");
        w1.put("title", "AR Caller - Voice Fresher (Night) " + (100 + r.nextInt(900)));
        w1.put("recruiterEmail", "recruiter.kavya@agshealth.com");
        w1.put("hiringManagerEmail", "hm.arun@agshealth.com");
        w1.put("primaryLocationId", "300000000041001");
        w1.put("organizationId", "300000000063003");
        w1.put("unlimitedOpenings", "N");
        w1.put("numberOfOpenings", 10 + r.nextInt(20));
        w1.put("businessJustification", "TL upload - Q4 voice fresher hiring");
        w1.putObject("dff").put("lob", "AR Voice").put("clientCategory", "Hospital").put("requiredByDate", "2026-12-15");

        ObjectNode w2 = writes.addObject();
        w2.put("writeId", "JD-EDIT-" + seed + "-1");
        w2.put("action", "UPDATE");
        w2.put("requisitionNumber", "REQ-10452");
        w2.put("title", "AR Caller - Voice Fresher (Day shift)");
        w2.put("numberOfOpenings", 30);
        w2.put("externalDescription", "Join AGS Health as an AR Caller. Day shift, Chennai. Approved by TA Head.");
        w2.putObject("dff").put("specialtySoftware", "Epic");

        ObjectNode w3 = writes.addObject();
        w3.put("writeId", "TL-UPLOAD-" + seed + "-2");
        w3.put("action", "CREATE");
        w3.put("title", "Medical Coder - CPC");
        w3.put("recruiterEmail", "recruiter.kavya@agshealth.com");
        w3.put("hiringManagerEmail", "former.user@agshealth.com");
        w3.put("primaryLocationId", "300000000041001");
        w3.put("unlimitedOpenings", "N");
        w3.put("numberOfOpenings", 5);
        w3.put("$comment", "Hiring manager is not active in Oracle – expected result: NEEDS_DATA, nothing sent");
        return root;
    }

    private static ObjectNode candidate(Random r, int i, int seed) {
        String first = pick(r, FIRST), last = pick(r, LAST);
        ObjectNode c = Json.obj();
        String id = "C-" + (seed % 1000) + "-" + (1001 + i);
        c.put("candidateId", id);
        c.put("firstName", first);
        c.put("lastName", last);
        c.put("fullName", first + " " + last);
        c.put("email", (first + "." + last + (10 + r.nextInt(89))).toLowerCase(Locale.ROOT) + "@example.com");
        c.put("countryCode", "+91");
        c.put("mobile", "9" + (100000000 + r.nextInt(899999999)));
        String city = pick(r, CITY);
        c.putObject("address").put("line1", (1 + r.nextInt(120)) + " " + pick(r, new String[]{"Gandhi Street", "Anna Nagar 2nd Ave", "Lake View Road", "MG Road"}))
                .put("city", city).put("state", city.equals("Hyderabad") ? "Telangana" : city.equals("Bengaluru") ? "Karnataka" : "Tamil Nadu")
                .put("postalCode", String.valueOf(600001 + r.nextInt(40000))).put("country", "IN");
        String[] src = SOURCES[r.nextInt(SOURCES.length)];
        c.put("source", src[0]);
        c.put("sourceDetail", src[1]);
        c.put("experienceLevel", r.nextBoolean() ? "Fresher" : (1 + r.nextInt(6)) + " years");

        ArrayNode edu = c.putArray("education");
        int y = 2018 + r.nextInt(6);
        edu.addObject().put("degree", pick(r, DEGREE)).put("institution", pick(r, COLLEGE)).put("startDate", y + "-06-01").put("endDate", (y + 3) + "-05-31");
        ArrayNode exp = c.putArray("experience");
        if (r.nextInt(3) > 0) {
            exp.addObject().put("employer", pick(r, EMPLOYER)).put("jobTitle", pick(r, TITLE)).put("startDate", (y + 3) + "-07-01").put("current", true);
        }
        ArrayNode certs = c.putArray("certifications");
        if (r.nextBoolean()) certs.addObject().put("name", pick(r, new String[]{"CPC", "CCS", "CRCR"})).put("issuedBy", "AAPC");
        ArrayNode skills = c.putArray("skills");
        for (int k = 0; k < 2 + r.nextInt(3); k++) {
            String s = pick(r, SKILLS);
            boolean dup = false;
            for (var x : skills) if (x.asText().equals(s)) dup = true;
            if (!dup) skills.add(s);
        }
        c.putObject("resume").put("fileName", id + "_resume.pdf").put("path", "resumes/" + id + "_resume.pdf");

        ObjectNode iv = c.putObject("interview");
        ObjectNode hr = iv.putObject("hrRound");
        hr.put("date", "2026-11-0" + (2 + r.nextInt(7)) + "T10:30:00+05:30").put("mode", r.nextBoolean() ? "ONLINE" : "IN_OFFICE")
                .put("interviewer", "tl.priya@agshealth.com").put("result", "SELECT").put("remarks", "Good communication; flexible for night shift");
        ArrayNode comp = hr.putArray("competencies");
        for (String k : new String[]{"Communication", "Domain knowledge", "Attitude"}) comp.addObject().put("name", k).put("rating", 3 + r.nextInt(3));
        ArrayNode as = iv.putArray("assessments");
        as.addObject().put("name", "SHL Verify").put("date", "2026-11-04").put("result", "PASS").put("score", 60 + r.nextInt(35));
        as.addObject().put("name", "Versant English").put("date", "2026-11-05").put("result", "PASS").put("score", 50 + r.nextInt(30));
        ObjectNode panel = iv.putObject("panel");
        panel.put("date", "2026-11-09T15:00:00+05:30").put("panelName", "AR Voice Panel 2").put("orcId", "REQ-10452")
                .put("result", "SELECTED").put("remarks", "Strong AR basics");
        panel.putArray("panelists").add("hm.arun@agshealth.com").add("tl.priya@agshealth.com");
        iv.putObject("verification").put("idVerified", "Yes").put("photoMatch", "Yes");

        ObjectNode sel = c.putObject("selection");
        sel.put("applicationId", "A-" + (seed % 1000) + "-" + (5001 + i));
        sel.put("status", "PANEL_SELECTED");
        sel.put("requisitionNumber", "REQ-10452");
        sel.put("selectedAt", "2026-11-10T16:00:00+05:30");
        sel.put("selectedBy", "hm.arun@agshealth.com");
        sel.put("recruiterEmail", "recruiter.kavya@agshealth.com");
        ObjectNode mock = c.putObject("mock");
        mock.put("stagePath", "HIRED");

        switch (i) {
            case 0 -> c.put("$case", "Selected → created in Oracle → recruiter creates application → offer → hired (JOINED)");
            case 1 -> {
                c.put("$case", "Shortlisted → offer extended; later declined in DigiHire → Oracle recruiter alerted, nothing written to Oracle");
                sel.put("status", "SHORTLISTED");
                mock.put("stagePath", "STUCK_EXTENDED");
                c.putArray("afterHandover").addObject().put("status", "PANEL_DECLINED").put("at", "2026-11-12T11:00:00+05:30")
                        .put("remark", "Candidate declined - accepted another offer");
            }
            case 2 -> {
                c.put("$case", "Single name (no last name) → NEEDS_DATA, nothing sent");
                c.put("lastName", "");
                c.put("fullName", first);
            }
            case 3 -> {
                c.put("$case", "Selected for a filled requisition → HELD 'Requisition no longer open'");
                sel.put("requisitionNumber", "REQ-10453");
            }
            case 4 -> {
                c.put("$case", "Rejected at HR round (not selected) → stays in DigiHire only");
                sel.put("status", "HR_REJECTED");
            }
            case 5 -> {
                c.put("$case", "Email already used in Oracle by someone else → LINK_REQUIRED");
                mock.putObject("existingInOracle").put("firstName", "Someone").put("lastName", "Else");
            }
            case 6 -> {
                c.put("$case", "Oracle recruiter creates the application on a different requisition → linked and flagged; offer declined");
                mock.put("applicationRequisition", "REQ-10456");
                mock.put("stagePath", "DECLINED");
            }
            case 7 -> {
                c.put("$case", "Oracle recruiter never creates the application → waiting + reminder");
                mock.put("createApplication", false);
            }
            default -> {
                c.put("$case", "Random selection");
                sel.put("status", r.nextBoolean() ? "PANEL_SELECTED" : "SHORTLISTED");
                sel.put("requisitionNumber", r.nextBoolean() ? "REQ-10452" : "REQ-10456");
                mock.put("stagePath", List.of("HIRED", "DECLINED", "DISQUALIFIED", "STUCK_EXTENDED").get(r.nextInt(4)));
            }
        }
        return c;
    }

    private static String pick(Random r, String[] a) { return a[r.nextInt(a.length)]; }
}
