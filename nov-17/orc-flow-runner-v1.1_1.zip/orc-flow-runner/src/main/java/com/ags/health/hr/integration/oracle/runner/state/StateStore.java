package com.ags.health.hr.integration.oracle.runner.state;

import com.ags.health.hr.integration.oracle.runner.core.Json;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;

import java.nio.file.Files;
import java.nio.file.Path;
import java.time.OffsetDateTime;

/**
 * Stands in for the DigiHire tables between runs (state.json in the output folder):
 * candidate links, application links, Oracle stages, watermarks, reference cache, timeline, alerts.
 * When this moves into smartie-core each section maps to a table (see README).
 */
public final class StateStore {

    private final Path file;
    private final ObjectNode root;

    public StateStore(Path file, boolean reset) {
        this.file = file;
        if (!reset && Files.exists(file)) {
            JsonNode n = Json.read(file);
            this.root = n.isObject() ? (ObjectNode) n : Json.obj();
        } else {
            this.root = Json.obj();
        }
        for (String s : new String[]{"watermarks", "lastSuccessfulRun", "requisitions", "personMap", "refCache",
                "candidates", "applications", "requisitionWrites"}) {
            if (!root.has(s)) root.set(s, Json.obj());
        }
        for (String s : new String[]{"timeline", "alerts", "reconciliation"}) {
            if (!root.has(s)) root.set(s, Json.arr());
        }
    }

    public ObjectNode section(String name) { return (ObjectNode) root.get(name); }

    public ArrayNode list(String name) { return (ArrayNode) root.get(name); }

    public ObjectNode entry(String section, String key) {
        ObjectNode s = section(section);
        JsonNode e = s.get(key);
        if (!(e instanceof ObjectNode)) {
            e = Json.obj();
            s.set(key, e);
        }
        return (ObjectNode) e;
    }

    public JsonNode get(String section, String key) { return section(section).path(key); }

    public String watermark(String kind) { return Json.text(section("watermarks"), kind); }

    public void watermark(String kind, String value) { section("watermarks").put(kind, value); }

    public void markRun(String kind) { section("lastSuccessfulRun").put(kind, OffsetDateTime.now().toString()); }

    public String lastRun(String kind) { return Json.text(section("lastSuccessfulRun"), kind); }

    public ObjectNode timeline(String applicationId, String source, String syncState, String text,
                               String oraclePhase, String oracleState, String oracleChangedAt) {
        ObjectNode row = Json.obj();
        row.put("applicationId", applicationId);
        row.put("source", source);
        row.put("syncState", syncState);
        row.put("text", text);
        if (oraclePhase != null) row.put("oraclePhase", oraclePhase);
        if (oracleState != null) row.put("oracleState", oracleState);
        if (oracleChangedAt != null) row.put("oracleChangedAt", oracleChangedAt);
        row.put("at", OffsetDateTime.now().toString());
        list("timeline").add(row);
        return row;
    }

    public ObjectNode alert(String to, String subject, String text, String applicationId) {
        ObjectNode a = Json.obj();
        a.put("to", to == null ? "(recruiter not resolved)" : to);
        a.put("subject", subject);
        a.put("text", text);
        if (applicationId != null) a.put("applicationId", applicationId);
        a.put("at", OffsetDateTime.now().toString());
        list("alerts").add(a);
        return a;
    }

    public void save() { Json.writeFile(file, root); }

    public JsonNode root() { return root; }
}
