package com.ags.health.hr.integration.oracle.runner.flow;

import com.ags.health.hr.integration.oracle.runner.http.OracleClient;
import com.ags.health.hr.integration.oracle.runner.http.OracleException;
import com.ags.health.hr.integration.oracle.runner.state.RunReport.Status;

/** Step 0: get a token (TOKEN mode) or check Basic login, then make one cheap read. */
public final class AuthCheckFlow {

    private static final String F = "auth";
    private final FlowContext c;

    public AuthCheckFlow(FlowContext c) { this.c = c; }

    public void run() {
        c.report.section("Auth – login check (" + c.oracle.auth().mode() + ")");
        try {
            c.oracle.auth().header();
            c.report.add(F, "Credentials accepted locally", c.oracle.auth().mode(),
                    Status.PASS, "TOKEN".equals(c.oracle.auth().mode()) ? "Access token received" : "Basic header built");
            OracleClient.Response r = c.oracle.call("authCheck", FlowContext.p(), null);
            c.report.add(F, "First Oracle read", "", Status.PASS, "HTTP " + r.status() + " in " + r.ms() + " ms");
        } catch (OracleException e) {
            c.fail(F, "Login", "", e);
        }
    }
}
