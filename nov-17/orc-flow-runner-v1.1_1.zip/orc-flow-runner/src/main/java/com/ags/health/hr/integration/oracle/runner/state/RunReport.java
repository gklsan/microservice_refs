package com.ags.health.hr.integration.oracle.runner.state;

import com.ags.health.hr.integration.oracle.runner.core.Json;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;

import java.nio.file.Path;
import java.time.OffsetDateTime;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** Collects one line per step and prints a summary table; written to report.json. */
public final class RunReport {

    /** Outcomes. PASS/INFO/SKIPPED are fine; WARN needs a look; the rest are business states or failures. */
    public enum Status { PASS, INFO, WARN, SKIPPED, DRY_RUN, NEEDS_DATA, LINK_REQUIRED, HELD, WAITING, ALERT, BLOCKED, FAIL, AUTH_STOP }

    public record Step(String flow, String step, String item, Status status, String message) { }

    private final List<Step> steps = new ArrayList<>();
    private final String startedAt = OffsetDateTime.now().toString();

    public Step add(String flow, String step, String item, Status status, String message) {
        Step s = new Step(flow, step, item == null ? "" : item, status, message == null ? "" : message);
        steps.add(s);
        System.out.printf("  %-10s %-34s %-18s %s%n", "[" + status + "]", ascii(trunc(step, 34)), ascii(trunc(s.item(), 18)), ascii(s.message()));
        return s;
    }

    public void section(String title) {
        System.out.println();
        System.out.println("== " + ascii(title) + " ==");
    }

    public boolean hasFailures() {
        return steps.stream().anyMatch(s -> s.status() == Status.FAIL || s.status() == Status.AUTH_STOP);
    }

    public boolean authStopped() { return steps.stream().anyMatch(s -> s.status() == Status.AUTH_STOP); }

    public void printSummary() {
        Map<String, Map<Status, Integer>> byFlow = new LinkedHashMap<>();
        for (Step s : steps) byFlow.computeIfAbsent(s.flow(), k -> new LinkedHashMap<>()).merge(s.status(), 1, Integer::sum);
        System.out.println();
        System.out.println("== Summary ==");
        byFlow.forEach((flow, counts) -> System.out.printf("  %-8s %s%n", flow, counts));
        System.out.println(hasFailures() ? "  RESULT: some steps FAILED - see report.json and calllog.jsonl"
                : "  RESULT: all steps completed (check WARN / business states above)");
    }

    public void write(Path file) {
        ObjectNode root = Json.obj();
        root.put("startedAt", startedAt);
        root.put("finishedAt", OffsetDateTime.now().toString());
        root.put("result", hasFailures() ? "FAILED" : "COMPLETED");
        ArrayNode arr = root.putArray("steps");
        for (Step s : steps) {
            ObjectNode o = arr.addObject();
            o.put("flow", s.flow()); o.put("step", s.step()); o.put("item", s.item());
            o.put("status", s.status().name()); o.put("message", s.message());
        }
        Json.writeFile(file, root);
    }

    private static String trunc(String s, int n) { return s.length() > n ? s.substring(0, n - 2) + ".." : s; }

    /** Console output stays plain ASCII so every terminal (including Windows cmd) shows it correctly. */
    static String ascii(String s) {
        return s.replace("\u2013", "-").replace("\u2014", "-").replace("\u203a", ">").replace("\u2192", "->")
                .replace("\u2018", "'").replace("\u2019", "'").replace("\u201c", "\"").replace("\u201d", "\"").replace("\u2026", "...");
    }
}
