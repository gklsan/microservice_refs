package com.ags.health.hr.integration.oracle.runner.http;

import com.ags.health.hr.integration.oracle.runner.core.Json;
import com.fasterxml.jackson.databind.JsonNode;

/**
 * Error classes from the design:
 * AUTH (401) stops every Oracle job; FORBIDDEN (403) parks that operation; RETRYABLE (429, 5xx, timeout)
 * is retried then fails; CLIENT (other 4xx) fails with Oracle's message; CONFIG is a local setup problem.
 */
public class OracleException extends Exception {

    public enum Kind { AUTH, FORBIDDEN, RETRYABLE, TIMEOUT, CLIENT, CONFIG }

    private final Kind kind;
    private final int status;
    private final String operation;

    public OracleException(Kind kind, int status, String operation, String message) {
        super(message);
        this.kind = kind; this.status = status; this.operation = operation;
    }

    public Kind kind() { return kind; }
    public int status() { return status; }
    public String operation() { return operation; }

    public static Kind classify(int status) {
        if (status == 401) return Kind.AUTH;
        if (status == 403) return Kind.FORBIDDEN;
        if (status == 429 || status >= 500) return Kind.RETRYABLE;
        return Kind.CLIENT;
    }

    /** Pulls a readable message out of an Oracle error body (JSON or plain text). */
    public static String messageFrom(String body) {
        if (body == null || body.isBlank()) return "(no message)";
        JsonNode j = Json.parse(body);
        if (j.isObject()) {
            StringBuilder sb = new StringBuilder();
            for (String k : new String[]{"title", "detail", "error_description", "error", "message"}) {
                String v = Json.text(j, k);
                if (v != null && !v.isBlank()) sb.append(sb.length() > 0 ? " | " : "").append(v);
            }
            JsonNode details = j.path("o:errorDetails");
            if (details.isArray()) details.forEach(d -> {
                String v = Json.text(d, "detail");
                if (v != null) sb.append(" | ").append(v);
            });
            if (sb.length() > 0) return trim(sb.toString());
        }
        return trim(body.replaceAll("\\s+", " "));
    }

    private static String trim(String s) { return s.length() > 500 ? s.substring(0, 500) + "..." : s; }
}
