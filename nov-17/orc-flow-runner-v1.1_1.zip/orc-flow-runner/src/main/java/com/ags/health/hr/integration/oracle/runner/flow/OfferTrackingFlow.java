package com.ags.health.hr.integration.oracle.runner.flow;

import com.ags.health.hr.integration.oracle.runner.core.Json;
import com.ags.health.hr.integration.oracle.runner.http.OracleClient;
import com.ags.health.hr.integration.oracle.runner.http.OracleException;
import com.ags.health.hr.integration.oracle.runner.state.RunReport.Status;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;

import java.time.DayOfWeek;
import java.time.OffsetDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

/**
 * Flow 3 – Offer stage tracking (read only). Finds the job application the Oracle recruiter created for a
 * handed-over candidate and records every offer and HR stage until a final stage. Never writes to Oracle.
 */
public final class OfferTrackingFlow {

    private static final String F = "flow3";
    private final FlowContext c;
    private final RequisitionSyncFlow reqHelper;

    public OfferTrackingFlow(FlowContext c, RequisitionSyncFlow reqHelper) { this.c = c; this.reqHelper = reqHelper; }

    public void run() {
        c.report.section("Flow 3 – Offer stage tracking (read only)");
        if (tracked().isEmpty()) {
            c.report.add(F, "Tracked applications", "", Status.SKIPPED, "No handed-over candidate is being tracked yet (run flow2 first)");
            return;
        }
        int polls = Math.max(1, c.options.polls());
        for (int i = 1; i <= polls; i++) {
            poll(i, polls);
            if (i < polls) sleep(c.cfg.integer("flow3.pollIntervalSeconds", 0));
        }
        waitingCheck();
        afterHandoverEvents();
        if (c.options.reconcile()) reconcile();
        summary();
        c.state.save();
    }

    private List<ObjectNode> tracked() {
        List<ObjectNode> out = new ArrayList<>();
        Iterator<JsonNode> it = c.state.section("applications").elements();
        while (it.hasNext()) {
            JsonNode a = it.next();
            if (a.path("handedOver").asBoolean(false) && !a.path("final").asBoolean(false) && a.hasNonNull("personId")) out.add((ObjectNode) a);
        }
        return out;
    }

    private void poll(int n, int of) {
        String start = c.state.watermark("applications");
        if (start == null) start = Json.text(c.data, "applicationTracking.initialWatermark");
        if (start == null) start = c.cfg.str("flow3.initialWatermark", "2026-01-01T00:00:00Z");
        String since = reqHelper.minusOverlap(start);
        int limit = c.cfg.integer("paging.applicationPageSize", 200);
        int offset = 0, pages = 0, read = 0, ours = 0;
        String maxTs = start;
        try {
            while (pages++ < c.cfg.integer("paging.maxPages", 500)) {
                OracleClient.Response r = c.oracle.call("applicationDelta",
                        FlowContext.p("since", since, "limit", String.valueOf(limit), "offset", offset == 0 ? null : String.valueOf(offset)), null);
                String lastTs = null;
                for (JsonNode item : r.items()) {
                    read++;
                    if (handle(item)) ours++;
                    lastTs = Json.text(item, "LastModifiedDate");
                    if (lastTs != null && RequisitionSyncFlow.after(lastTs, maxTs)) maxTs = lastTs;
                }
                if (!r.hasMore() || r.items().isEmpty()) break;
                if (lastTs == null || !RequisitionSyncFlow.after(lastTs, since)) offset += r.items().size();
                else { since = lastTs; offset = 0; }
            }
            c.state.watermark("applications", maxTs);
            c.state.markRun("applications");
            c.report.add(F, "Poll " + n + "/" + of + " – changed applications", "", Status.PASS,
                    read + " read, " + ours + " belong to DigiHire candidates, " + (read - ours) + " ignored");
        } catch (OracleException e) {
            c.fail(F, "Poll " + n + "/" + of, "", e);
        }
    }

    /** Applies one Oracle application row. Returns true when it belongs to a DigiHire hand-over. */
    private boolean handle(JsonNode item) {
        String pid = item.path("CandidatePersonId").asText();
        String jobAppId = item.path("JobApplicationId").asText();
        String reqNum = Json.text(item, "RequisitionNumber");

        ObjectNode app = null;
        String appId = null;
        List<Map.Entry<String, ObjectNode>> unlinked = new ArrayList<>();
        Iterator<Map.Entry<String, JsonNode>> it = c.state.section("applications").fields();
        while (it.hasNext()) {
            Map.Entry<String, JsonNode> e = it.next();
            ObjectNode a = (ObjectNode) e.getValue();
            if (jobAppId.equals(Json.text(a, "oracleJobApplicationId"))) { app = a; appId = e.getKey(); break; }
            if (pid.equals(Json.text(a, "personId")) && !a.has("oracleJobApplicationId") && a.path("handedOver").asBoolean(false)) {
                unlinked.add(Map.entry(e.getKey(), a));
            }
        }
        if (app == null) {
            if (unlinked.isEmpty()) return false;
            Map.Entry<String, ObjectNode> pick = unlinked.stream()
                    .filter(e -> reqNum != null && reqNum.equals(Json.text(e.getValue(), "requisitionNumber")))
                    .findFirst().orElse(unlinked.get(0));
            appId = pick.getKey();
            app = pick.getValue();
            app.put("oracleJobApplicationId", jobAppId);
            app.put("oracleRequisitionNumber", reqNum);
            app.put("trackingState", "TRACKING");
            c.state.timeline(appId, "ORACLE", "FROM_ORACLE", "Oracle recruiter created job application " + jobAppId, null, null, Json.text(item, "LastModifiedDate"));
            boolean sameReq = reqNum != null && reqNum.equals(Json.text(app, "requisitionNumber"));
            if (sameReq) {
                c.report.add(F, "Link Oracle application", appId, Status.PASS, "JobApplicationId " + jobAppId + " on " + reqNum);
            } else {
                app.put("differentRequisition", true);
                c.state.alert(Json.text(app, "recruiterEmail"), "Oracle application on a different requisition",
                        "Candidate " + Json.text(app, "candidateNumber") + " was selected for " + Json.text(app, "requisitionNumber")
                                + " but the Oracle application is on " + reqNum + ". Please check.", appId);
                c.report.add(F, "Link Oracle application", appId, Status.WARN,
                        "Linked, but on a different requisition (" + reqNum + " vs " + Json.text(app, "requisitionNumber") + ") – recruiter alerted");
            }
        }
        applyStage(appId, app, item);
        return true;
    }

    private void applyStage(String appId, ObjectNode app, JsonNode item) {
        String phase = Json.text(item, "PhaseName");
        String state = Json.text(item, "StateName");
        boolean disq = item.path("DisqualifiedFlag").asBoolean(false);
        String changedAt = Json.text(item, "LastModifiedDate");
        if (phase == null && state == null) return;
        boolean same = phase != null && phase.equals(Json.text(app, "oraclePhase")) && state != null && state.equals(Json.text(app, "oracleState"))
                && disq == app.path("disqualified").asBoolean(false);
        if (same) return;

        JsonNode rule = stageRule(phase, state, disq);
        String display = rule == null ? "In Oracle – " + phase + " › " + state
                : rule.path("display").asText().replace("{phase}", phase == null ? "" : phase).replace("{state}", state == null ? "" : state);
        app.put("oraclePhase", phase);
        app.put("oracleState", state);
        app.put("disqualified", disq);
        app.put("oracleLastModified", changedAt);
        app.put("display", display);
        c.state.timeline(appId, "ORACLE", "FROM_ORACLE", display, phase, state, changedAt);
        String msg = phase + " › " + state + (disq ? " (disqualified)" : "") + " → \"" + display + "\"";
        String dh = rule == null ? null : Json.text(rule, "digihireStatus");
        if (dh != null && !dh.equals(Json.text(app, "digihireStatus"))) {
            app.put("digihireStatus", dh);
            msg += "; DigiHire status → " + dh;
        }
        boolean fin = rule != null && rule.path("final").asBoolean(false);
        if (fin) {
            app.put("final", true);
            app.put("trackingState", "FINAL");
            msg += "; final – tracking stopped";
        }
        c.report.add(F, "Stage change", appId, Status.PASS, msg);
    }

    /** First matching entry in config.flow3.stageMap ("*" matches anything; "disqualified": true matches DisqualifiedFlag). */
    private JsonNode stageRule(String phase, String state, boolean disq) {
        for (JsonNode r : c.cfg.at("flow3.stageMap")) {
            if (r.path("disqualified").asBoolean(false)) { if (disq) return r; else continue; }
            if (match(r.path("phase").asText("*"), phase) && match(r.path("state").asText("*"), state)) return r;
        }
        return null;
    }

    private static boolean match(String p, String v) { return "*".equals(p) || (v != null && p.equalsIgnoreCase(v)); }

    /** Hand-overs still without an Oracle application: ask Oracle directly once the wait time has passed, else remind. */
    private void waitingCheck() {
        int waitDays = c.cfg.integer("flow3.waitWorkingDays", 2);
        for (ObjectNode a : tracked()) {
            if (a.has("oracleJobApplicationId")) continue;
            String appId = keyOf(a);
            OffsetDateTime handed = OffsetDateTime.parse(a.path("handedOverAt").asText());
            int days = workingDaysBetween(handed, OffsetDateTime.now());
            if (days < waitDays) {
                c.report.add(F, "Waiting for Oracle application", appId, Status.WAITING,
                        "Handed over " + days + " working day(s) ago; reminder after " + waitDays);
                continue;
            }
            try {
                OracleClient.Response r = "requisitionAndEmail".equals(c.cfg.str("flow3.applicationLookup", "personId"))
                        ? c.oracle.call("applicationsByRequisitionAndEmail",
                            FlowContext.p("requisitionNumber", Json.text(a, "requisitionNumber"), "email", Json.text(a, "email")), null)
                        : c.oracle.call("applicationsByPerson", FlowContext.p("personId", Json.text(a, "personId")), null);
                boolean linked = false;
                for (JsonNode item : r.items()) linked |= handle(item);
                if (linked) continue;
                String last = Json.text(a, "lastReminderAt");
                if (last != null && OffsetDateTime.parse(last).isAfter(OffsetDateTime.now().minusHours(c.cfg.integer("flow3.reminderEveryHours", 24)))) {
                    c.report.add(F, "Waiting for Oracle application", appId, Status.WAITING, "Still no application; reminder already sent at " + last);
                    continue;
                }
                a.put("lastReminderAt", OffsetDateTime.now().toString());
                c.state.alert(Json.text(a, "recruiterEmail"), "Reminder: create Oracle job application",
                        "Candidate " + Json.text(a, "candidateNumber") + " was handed over " + days + " working day(s) ago for "
                                + Json.text(a, "requisitionNumber") + " and has no Oracle application yet.", appId);
                c.state.timeline(appId, "DIGIHIRE", "PENDING", "Waiting for Oracle application – reminder sent", null, null, null);
                c.report.add(F, "Waiting for Oracle application", appId, Status.WAITING, "No application after " + days + " working day(s) – reminder sent");
            } catch (OracleException e) {
                c.fail(F, "Look up application for candidate", appId, e);
            }
        }
    }

    /** DigiHire status changes after hand-over (e.g. HR_REJECTED, PANEL_DECLINED) only alert the Oracle recruiter. */
    private void afterHandoverEvents() {
        List<String> alertOn = c.cfg.strings("flow3.alertOnDigiHireStatuses");
        for (JsonNode cand : c.candidates()) {
            String appId = Json.text(cand, "selection.applicationId");
            JsonNode a0 = c.state.get("applications", appId);
            if (!(a0 instanceof ObjectNode a) || !a.path("handedOver").asBoolean(false)) continue;
            for (JsonNode ev : cand.path("afterHandover")) {
                String st = Json.text(ev, "status");
                String key = st + "@" + Json.text(ev, "at");
                ArrayNode done = a.has("alertedEvents") ? (ArrayNode) a.get("alertedEvents") : a.putArray("alertedEvents");
                boolean seen = false;
                for (JsonNode d : done) if (d.asText().equals(key)) seen = true;
                if (seen || !alertOn.contains(st)) continue;
                done.add(key);
                String where = a.has("oraclePhase") ? a.path("oraclePhase").asText() + " › " + a.path("oracleState").asText() : "no Oracle application yet";
                c.state.timeline(appId, "DIGIHIRE", "DIGIHIRE_ONLY", st + " in DigiHire (" + Json.text(ev, "remark") + ")", null, null, null);
                if (a.path("final").asBoolean(false)) {
                    c.report.add(F, "DigiHire change after hand-over", appId, Status.INFO, st + " – Oracle already final (" + where + "); no alert");
                    continue;
                }
                c.state.alert(Json.text(a, "recruiterEmail"), "Candidate " + st + " in DigiHire",
                        "Candidate " + Json.text(a, "candidateNumber") + " is " + st + " in DigiHire; Oracle shows " + where + ". Please act in Oracle.", appId);
                c.report.add(F, "DigiHire change after hand-over", appId, Status.ALERT,
                        st + " while Oracle is at " + where + " – Oracle recruiter alerted; nothing written to Oracle");
            }
        }
    }

    /** Nightly: re-read every linked, non-final application and correct DigiHire. */
    private void reconcile() {
        int checked = 0, fixed = 0;
        for (ObjectNode a : tracked()) {
            String jid = Json.text(a, "oracleJobApplicationId");
            if (jid == null) continue;
            String appId = keyOf(a);
            try {
                OracleClient.Response r = c.oracle.call("applicationById", FlowContext.p("jobApplicationId", jid), null);
                checked++;
                JsonNode item = r.first();
                if (item.isMissingNode()) {
                    c.report.add(F, "Reconcile", appId, Status.WARN, "Oracle application " + jid + " not found");
                    continue;
                }
                String before = Json.text(a, "oraclePhase") + " › " + Json.text(a, "oracleState");
                String after = Json.text(item, "PhaseName") + " › " + Json.text(item, "StateName");
                if (!before.equals(after)) {
                    fixed++;
                    ObjectNode row = c.state.list("reconciliation").addObject();
                    row.put("applicationId", appId); row.put("digihire", before); row.put("oracle", after);
                    row.put("at", OffsetDateTime.now().toString());
                    applyStage(appId, a, item);
                }
            } catch (OracleException e) {
                c.fail(F, "Reconcile", appId, e);
            }
        }
        c.report.add(F, "Nightly reconciliation", "", fixed == 0 ? Status.PASS : Status.WARN,
                checked + " checked, " + fixed + " mismatch(es) corrected and reported");
    }

    private void summary() {
        Map<String, Integer> byState = new HashMap<>();
        c.state.section("applications").elements().forEachRemaining(a -> byState.merge(a.path("trackingState").asText("?"), 1, Integer::sum));
        c.report.add(F, "Tracking summary", "", Status.INFO, byState.toString());
    }

    private String keyOf(ObjectNode a) {
        Iterator<Map.Entry<String, JsonNode>> it = c.state.section("applications").fields();
        while (it.hasNext()) { Map.Entry<String, JsonNode> e = it.next(); if (e.getValue() == a) return e.getKey(); }
        return "?";
    }

    static int workingDaysBetween(OffsetDateTime from, OffsetDateTime to) {
        int days = 0;
        OffsetDateTime d = from.plusDays(1);
        while (!d.isAfter(to)) {
            if (d.getDayOfWeek() != DayOfWeek.SATURDAY && d.getDayOfWeek() != DayOfWeek.SUNDAY) days++;
            d = d.plusDays(1);
        }
        return days;
    }

    private static void sleep(int s) {
        if (s <= 0) return;
        try { Thread.sleep(s * 1000L); } catch (InterruptedException e) { Thread.currentThread().interrupt(); }
    }
}
