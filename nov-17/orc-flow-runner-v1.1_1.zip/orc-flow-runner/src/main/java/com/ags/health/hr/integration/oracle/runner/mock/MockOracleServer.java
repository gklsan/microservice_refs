package com.ags.health.hr.integration.oracle.runner.mock;

import com.ags.health.hr.integration.oracle.runner.core.Json;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpServer;

import java.io.IOException;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.time.OffsetDateTime;
import java.time.ZoneOffset;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.Executors;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * TEST ONLY. In-memory stand-in for the Oracle REST resources the flows call, so every step can be run
 * before AGS gives access. Behaviour mirrors Oracle where it matters: collection envelope, finders, q filters,
 * orderBy/limit/offset/hasMore, onlyData/fields/expand, self links with UniqIDs, 201/400/401 responses.
 * It also plays the Oracle recruiter: after a candidate is created it creates the job application and moves it
 * one stage forward on every application poll, following the candidate's "mock.stagePath" in the input file.
 * Any username works; the password "wrong" is refused (to test 401).
 */
public final class MockOracleServer {

    private static final String REST = "/hcmRestApi/resources/11.13.18.05";
    private static final Pattern COND = Pattern.compile("^\\s*([A-Za-z0-9_]+)\\s*(>=|<=|>|<|=)\\s*(.*?)\\s*$");

    private static final Map<String, List<String[]>> PATHS = Map.of(
            "HIRED", List.of(st("New", "To be Reviewed"), st("Offer", "Draft"), st("Offer", "Pending Approval"), st("Offer", "Approved"),
                    st("Offer", "Extended"), st("Offer", "Accepted"), st("HR", "Ready for Hire"), st("HR", "Processed")),
            "DECLINED", List.of(st("New", "To be Reviewed"), st("Offer", "Draft"), st("Offer", "Approved"), st("Offer", "Extended"),
                    st("Offer", "Declined by Candidate")),
            "STUCK_EXTENDED", List.of(st("New", "To be Reviewed"), st("Offer", "Draft"), st("Offer", "Approved"), st("Offer", "Extended")),
            "DISQUALIFIED", List.of(st("New", "To be Reviewed"), st("Interview", "Scheduled"), st("Interview", "Rejected by Employer", "disq")));

    private final HttpServer server;
    private final JsonNode data;
    private final List<ObjectNode> requisitions = new ArrayList<>();
    private final List<ObjectNode> candidates = new ArrayList<>();
    private final List<ObjectNode> applications = new ArrayList<>();
    private final List<ObjectNode> workers = new ArrayList<>();
    private final List<ObjectNode> jobs = new ArrayList<>(), departments = new ArrayList<>(), locations = new ArrayList<>();
    private final Set<String> tokens = new HashSet<>();
    private final Map<String, Integer> stageIndex = new HashMap<>();
    private OffsetDateTime clock = OffsetDateTime.now(ZoneOffset.UTC).truncatedTo(ChronoUnit.SECONDS);
    private long nextCandidate = 187476, nextPerson = 300100176560465L, nextApp = 300000987654321L, nextReq = 10600, nextDoc = 300100176560500L;
    private String baseUrl;

    private static String[] st(String... s) { return s; }

    private MockOracleServer(int port, JsonNode data) throws IOException {
        this.data = data;
        this.server = HttpServer.create(new InetSocketAddress("127.0.0.1", port), 0);
        this.server.setExecutor(Executors.newFixedThreadPool(4));
        this.server.createContext("/", this::handle);
        seed();
    }

    public static MockOracleServer start(int port, JsonNode data) {
        try {
            MockOracleServer m = new MockOracleServer(port, data);
            m.server.start();
            m.baseUrl = "http://127.0.0.1:" + m.server.getAddress().getPort();
            return m;
        } catch (IOException e) {
            throw new IllegalStateException("Cannot start mock Oracle on port " + port + ": " + e.getMessage(), e);
        }
    }

    public String baseUrl() { return baseUrl; }
    public String tokenUrl() { return baseUrl + "/oauth2/v1/token"; }
    public void stop() { server.stop(0); ((java.util.concurrent.ExecutorService) server.getExecutor()).shutdownNow(); }

    // ------------------------------------------------------------------ seed data

    private void seed() {
        OffsetDateTime base = clock.minusDays(3);
        requisitions.add(req("REQ-10452", 300000123456789L, "AR Caller - Voice Fresher", "Open", "Open", 25, "N", 7, base, "2026-12-31", "AR Voice"));
        requisitions.add(req("REQ-10453", 300000123456790L, "AR Analyst - Non Voice", "Open", "Open", 5, "N", 5, base.plusMinutes(1), "2026-12-31", "AR Non Voice"));
        requisitions.add(req("REQ-10454", 300000123456791L, "Medical Coder - CPC", "Open", "Open", 10, "N", 2, base.plusMinutes(2), "2026-10-31", "Coding"));
        requisitions.add(req("REQ-10455", 300000123456792L, "Payment Poster", "Draft", "In Progress", 4, "N", 0, base.plusMinutes(3), null, "Payment Posting"));
        requisitions.add(req("REQ-10456", 300000123456793L, "Customer Support - Voice", "Open", "Open", 0, "Y", 12, base.plusMinutes(4), null, "AR Voice"));
        ObjectNode slow = req("REQ-10499", 300000123456799L, "Slow Requisition (mock timeout test)", "Open", "Open", 3, "N", 0, base.plusMinutes(5), null, "AR Voice");
        slow.put("__slow", true);
        requisitions.add(slow);
        // filler requisitions so the delta needs several pages; groups share a timestamp to exercise keyset paging
        for (int i = 0; i < 230; i++) {
            OffsetDateTime t = base.plusHours(1).plusMinutes(i / 7);
            requisitions.add(req("REQ-2" + String.format("%04d", i), 300000200000000L + i, "Filler requisition " + i,
                    i % 9 == 0 ? "Closed" : "Open", i % 9 == 0 ? "Filled" : "Open", 3, "N", i % 4, t, null, i % 2 == 0 ? "AR Voice" : "Coding"));
        }

        workers.add(worker(300000011112222L, "104882", "Kavya Raman", "recruiter.kavya@agshealth.com"));
        workers.add(worker(300000011113333L, "104990", "Arun Kumar", "hm.arun@agshealth.com"));
        workers.add(worker(300000022224444L, "105301", "Priya Nair", "tl.priya@agshealth.com"));
        jobs.add(Json.obj().put("JobId", 300000000074004L).put("JobCode", "ARC-VF").put("Name", "AR Caller").put("ActiveStatus", "A"));
        departments.add(Json.obj().put("OrganizationId", 300000000063003L).put("Name", "Revenue Cycle - AR").put("Status", "A"));
        locations.add(Json.obj().put("LocationId", 300000000052002L).put("LocationName", "Chennai - Ambattur").put("ActiveStatus", "A"));
        locations.add(Json.obj().put("LocationId", 300000000041001L).put("LocationName", "Chennai").put("ActiveStatus", "A"));

        // candidates that already exist in Oracle (from input "mock.existingInOracle")
        for (JsonNode c : data.path("candidates")) {
            JsonNode ex = c.path("mock").path("existingInOracle");
            if (ex.isObject()) {
                ObjectNode o = Json.obj();
                o.put("CandidateNumber", String.valueOf(nextCandidate++));
                o.put("PersonId", nextPerson++);
                o.put("FirstName", ex.path("firstName").asText());
                o.put("LastName", ex.path("lastName").asText());
                o.put("Email", c.path("email").asText().toLowerCase());
                o.put("CandidateType", "ORA_EXTERNAL_CANDIDATE");
                candidates.add(o);
            }
        }
        // applications of people DigiHire does not know (must be ignored by Flow 3)
        for (int i = 0; i < 3; i++) {
            ObjectNode a = Json.obj();
            a.put("JobApplicationId", nextApp++);
            a.put("CandidatePersonId", 300100999000000L + i);
            a.put("RequisitionId", 300000123456789L);
            a.put("RequisitionNumber", "REQ-10452");
            a.put("PhaseId", 1).put("PhaseName", "New").put("StateId", 1).put("StateName", "To be Reviewed");
            a.put("DisqualifiedFlag", false);
            a.put("LastModifiedDate", tick().toString());
            applications.add(a);
        }
    }

    private ObjectNode req(String number, long id, String title, String phase, String state, int openings, String unlimited,
                           int hired, OffsetDateTime modified, String endDate, String lob) {
        ObjectNode r = Json.obj();
        r.put("RequisitionId", id);
        r.put("RequisitionNumber", number);
        r.put("Title", title);
        r.put("RecruitingType", "ORA_PROFESSIONAL");
        r.put("PhaseId", phase.equals("Open") ? 2 : 1).put("PhaseName", phase);
        r.put("StateId", state.equals("Open") ? 2 : 1).put("StateName", state);
        r.put("NumberOfOpenings", openings);
        r.put("UnlimitedOpenings", unlimited);
        r.put("HiredCount", hired);
        r.put("RecruiterId", 300000011112222L);
        r.put("HiringManagerId", 300000011113333L);
        r.put("JobId", 300000000074004L);
        r.put("DepartmentId", 300000000063003L);
        r.put("PrimaryLocationId", 300000000041001L);
        r.put("PrimaryWorkLocationId", 300000000052002L);
        r.put("FullTimeOrPartTime", "FULL_TIME");
        r.put("RegularOrTemporary", "R");
        r.put("JobShift", "NIGHT");
        r.put("EducationLevel", "BACHELORS");
        r.put("EmployeeReferralBonus", 5000);
        r.put("ExternalPublishedJobStatus", "POSTED");
        r.put("ExternalPublishedJobStartDate", "2026-11-01T00:00:00+00:00");
        if (endDate != null) r.put("ExternalPublishedJobEndDate", endDate + "T00:00:00+00:00"); else r.putNull("ExternalPublishedJobEndDate");
        r.put("InternalDescription", "Internal posting for " + title);
        r.put("ExternalDescription", "Join AGS Health as " + title + ".");
        r.put("RequisitionLastModifiedDate", modified.toString());
        ArrayNode dff = r.putArray("requisitionDFF");
        ObjectNode d = dff.addObject();
        d.put("RequisitionId", id);
        d.put("lob", lob);
        d.put("clientCategory", "Hospital");
        d.put("requisitionType", "New Hire");
        d.put("departmentGroup", "Revenue Cycle");
        r.putArray("otherWorkLocations");
        r.put("__uniq", "00020000000EACED00057708000110D9" + Long.toHexString(id).toUpperCase());
        return r;
    }

    private ObjectNode worker(long personId, String number, String name, String email) {
        ObjectNode w = Json.obj();
        w.put("PersonId", personId).put("PersonNumber", number).put("DisplayName", name).put("WorkEmail", email);
        w.putArray("assignments").addObject().put("AssignmentNumber", "E" + number).put("PrimaryFlag", true)
                .put("LegalEmployerName", "AGS Health Pvt Ltd").put("BusinessUnitName", "AGS India BU");
        return w;
    }

    private synchronized OffsetDateTime tick() {
        OffsetDateTime now = OffsetDateTime.now(ZoneOffset.UTC).truncatedTo(ChronoUnit.SECONDS);
        clock = now.isAfter(clock) ? now : clock.plusSeconds(1);
        return clock;
    }

    // ------------------------------------------------------------------ HTTP

    private void handle(HttpExchange ex) throws IOException {
        try {
            String path = ex.getRequestURI().getPath();
            String method = ex.getRequestMethod();
            Map<String, String> q = query(ex.getRequestURI().getRawQuery());
            String body = new String(ex.getRequestBody().readAllBytes(), StandardCharsets.UTF_8);

            if (path.equals("/oauth2/v1/token") && method.equals("POST")) { token(ex, body); return; }
            if (!path.startsWith(REST)) { send(ex, 404, err("Not Found", "Unknown path " + path)); return; }
            if (!authorised(ex)) { send(ex, 401, err("Unauthorized", "Invalid credentials")); return; }
            String p = path.substring(REST.length());
            String[] seg = p.split("/");
            String res = seg.length > 1 ? seg[1] : "";

            if (res.equals("recruitingJobRequisitions") && q.getOrDefault("finder", "").contains("REQ-10499")
                    && q.getOrDefault("fields", "").contains("HiredCount")) {
                try { Thread.sleep(4500); } catch (InterruptedException ie) { Thread.currentThread().interrupt(); }
            }
            synchronized (this) {
                switch (res) {
                    case "recruitingJobRequisitions" -> requisitionsApi(ex, method, seg, q, body);
                    case "recruitingCandidates" -> candidatesApi(ex, method, seg, q, body);
                    case "recruitingJobApplications" -> {
                        if (!method.equals("GET")) { send(ex, 405, err("Method Not Allowed", "Mock: DigiHire must not write job applications")); return; }
                        if (q.containsKey("q") && q.get("q").startsWith("LastModifiedDate")) recruiterActs();
                        Map<String, String> alias = Map.of("EmailAddress", "__email");
                        send(ex, 200, collection(applications, q, alias, "recruitingJobApplications", "JobApplicationId"));
                    }
                    case "publicWorkers" -> send(ex, 200, collection(workers, q, Map.of(), "publicWorkers", "PersonId"));
                    case "jobsLov" -> send(ex, 200, collection(jobs, q, Map.of(), "jobsLov", "JobId"));
                    case "departmentsLov" -> send(ex, 200, collection(departments, q, Map.of(), "departmentsLov", "OrganizationId"));
                    case "locationsLov" -> send(ex, 200, collection(locations, q, Map.of(), "locationsLov", "LocationId"));
                    default -> send(ex, 404, err("Not Found", "Mock has no resource " + res));
                }
            }
        } catch (Exception e) {
            send(ex, 500, err("Internal Server Error", e.toString()));
        }
    }

    private void requisitionsApi(HttpExchange ex, String method, String[] seg, Map<String, String> q, String body) throws IOException {
        if (seg.length == 3 && seg[2].equals("describe")) { send(ex, 200, describeRequisition()); return; }
        if (seg.length == 2) {
            if (method.equals("GET")) {
                send(ex, 200, collection(requisitions, q, Map.of(), "recruitingJobRequisitions", "__uniq"));
                return;
            }
            if (method.equals("POST")) { createRequisition(ex, Json.parse(body)); return; }
        }
        ObjectNode r = requisitions.stream().filter(x -> seg.length > 2 && x.path("__uniq").asText().equals(seg[2])).findFirst().orElse(null);
        if (r == null) { send(ex, 404, err("Not Found", "No requisition with that UniqID")); return; }
        if (seg.length == 3 && method.equals("PATCH")) {
            JsonNode b = Json.parse(body);
            b.fields().forEachRemaining(e -> { if (!e.getKey().equals("requisitionDFF")) r.set(e.getKey(), e.getValue()); });
            r.put("RequisitionLastModifiedDate", tick().toString());
            send(ex, 200, clean(r, null, true, "recruitingJobRequisitions", "__uniq"));
            return;
        }
        if (seg.length >= 5 && seg[3].equals("child") && seg[4].equals("requisitionDFF")) {
            ObjectNode dff = (ObjectNode) r.path("requisitionDFF").path(0);
            String dffUniq = "DFF" + r.path("RequisitionId").asText();
            if (seg.length == 5 && method.equals("GET")) {
                ObjectNode item = dff.deepCopy();
                item.putArray("links").addObject().put("rel", "self").put("href",
                        baseUrl + REST + "/recruitingJobRequisitions/" + seg[2] + "/child/requisitionDFF/" + dffUniq);
                send(ex, 200, envelope(List.of(item), false, 25, 0));
                return;
            }
            if (seg.length == 6 && method.equals("PATCH") && seg[5].equals(dffUniq)) {
                Json.parse(body).fields().forEachRemaining(e -> dff.set(e.getKey(), e.getValue()));
                r.put("RequisitionLastModifiedDate", tick().toString());
                send(ex, 200, dff);
                return;
            }
        }
        send(ex, 404, err("Not Found", "Mock does not support " + method + " " + String.join("/", seg)));
    }

    private void createRequisition(HttpExchange ex, JsonNode b) throws IOException {
        List<String> missing = new ArrayList<>();
        for (String f : new String[]{"Title", "RecruitingType", "PhaseId", "StateId", "PrimaryLocationId", "RecruiterId", "HiringManagerId", "UnlimitedOpenings"}) {
            if (Json.isEmpty(b.path(f))) missing.add(f);
        }
        if (!missing.isEmpty()) { send(ex, 400, err("Bad Request", "Required attributes missing: " + missing)); return; }
        long id = 300000123400000L + nextReq;
        String number = b.hasNonNull("RequisitionNumber") ? b.get("RequisitionNumber").asText() : "REQ-" + (nextReq++);
        ObjectNode r = req(number, id, b.path("Title").asText(), "Draft", "In Progress", b.path("NumberOfOpenings").asInt(0),
                b.path("UnlimitedOpenings").asText(), 0, tick(), null, null);
        ((ObjectNode) r.path("requisitionDFF").path(0)).removeAll().put("RequisitionId", id);
        b.fields().forEachRemaining(e -> { if (!e.getKey().equals("PhaseId") && !e.getKey().equals("StateId")) r.set(e.getKey(), e.getValue()); });
        requisitions.add(r);
        send(ex, 201, clean(r, null, true, "recruitingJobRequisitions", "__uniq"));
    }

    private void candidatesApi(HttpExchange ex, String method, String[] seg, Map<String, String> q, String body) throws IOException {
        if (seg.length == 3 && seg[2].equals("describe")) { send(ex, 200, describeCandidate()); return; }
        if (seg.length == 2 && method.equals("GET")) { send(ex, 200, collection(candidates, q, Map.of(), "recruitingCandidates", "CandidateNumber")); return; }
        if (seg.length == 2 && method.equals("POST")) {
            JsonNode b = Json.parse(body);
            if (Json.isEmpty(b.path("LastName")) || Json.isEmpty(b.path("Email"))) { send(ex, 400, err("Bad Request", "LastName and Email are required")); return; }
            String email = b.path("Email").asText().toLowerCase();
            if (candidates.stream().anyMatch(c -> c.path("Email").asText().equalsIgnoreCase(email))) {
                send(ex, 400, err("Bad Request", "The email address " + email + " is already used by another candidate. (IRC-1052)"));
                return;
            }
            for (JsonNode a : b.path("attachments")) {
                try { Base64.getDecoder().decode(a.path("FileContents").asText()); }
                catch (IllegalArgumentException e) { send(ex, 400, err("Bad Request", "Attachment FileContents is not valid base64")); return; }
            }
            ObjectNode c = Json.obj();
            c.put("CandidateNumber", String.valueOf(nextCandidate++));
            c.put("PersonId", nextPerson++);
            c.put("CandidateType", "ORA_EXTERNAL_CANDIDATE");
            c.put("CreatedBy", "DIGIHIRE_INTEGRATION");
            c.put("CreationDate", tick().toString());
            b.fields().forEachRemaining(e -> { if (!e.getKey().equals("attachments")) c.set(e.getKey(), e.getValue()); });
            c.put("Email", email);
            ArrayNode atts = c.putArray("attachments");
            for (JsonNode a : b.path("attachments")) {
                atts.addObject().put("AttachedDocumentId", nextDoc++).put("UploadedFileName", a.path("UploadedFileName").asText())
                        .put("CategoryName", a.path("CategoryName").asText());
            }
            candidates.add(c);
            send(ex, 201, c);
            return;
        }
        if (seg.length == 5 && seg[3].equals("child") && seg[4].equals("attachments") && method.equals("POST")) {
            ObjectNode c = candidates.stream().filter(x -> x.path("CandidateNumber").asText().equals(seg[2])).findFirst().orElse(null);
            if (c == null) { send(ex, 404, err("Not Found", "No candidate " + seg[2])); return; }
            JsonNode a = Json.parse(body);
            ObjectNode att = ((ArrayNode) c.withArray("attachments")).addObject();
            att.put("AttachedDocumentId", nextDoc++).put("UploadedFileName", a.path("UploadedFileName").asText());
            send(ex, 201, att);
            return;
        }
        send(ex, 404, err("Not Found", "Mock does not support " + method + " " + String.join("/", seg)));
    }

    /** Plays the Oracle recruiter: creates the job application, then moves it one stage per poll. */
    private void recruiterActs() {
        for (JsonNode cand : data.path("candidates")) {
            JsonNode mock = cand.path("mock");
            if (!mock.path("createApplication").asBoolean(true)) continue;
            String email = cand.path("email").asText().toLowerCase();
            ObjectNode oc = candidates.stream().filter(c -> c.path("Email").asText().equalsIgnoreCase(email)
                    && c.has("CreatedBy")).findFirst().orElse(null);
            if (oc == null) continue;
            long pid = oc.path("PersonId").asLong();
            String reqNum = mock.path("applicationRequisition").asText(cand.path("selection").path("requisitionNumber").asText());
            ObjectNode app = applications.stream().filter(a -> a.path("CandidatePersonId").asLong() == pid).findFirst().orElse(null);
            List<String[]> path = PATHS.getOrDefault(mock.path("stagePath").asText("HIRED"), PATHS.get("HIRED"));
            String key = String.valueOf(pid);
            if (app == null) {
                app = Json.obj();
                app.put("JobApplicationId", nextApp++);
                app.put("CandidatePersonId", pid);
                ObjectNode r = requisitions.stream().filter(x -> x.path("RequisitionNumber").asText().equals(reqNum)).findFirst().orElse(null);
                app.put("RequisitionId", r == null ? 0 : r.path("RequisitionId").asLong());
                app.put("RequisitionNumber", reqNum);
                app.put("__email", email);
                stageIndex.put(key, 0);
                setStage(app, path.get(0));
                applications.add(app);
            } else {
                int i = stageIndex.getOrDefault(key, 0);
                if (i + 1 < path.size()) {
                    stageIndex.put(key, i + 1);
                    setStage(app, path.get(i + 1));
                }
            }
        }
    }

    private void setStage(ObjectNode app, String[] s) {
        app.put("PhaseId", Math.abs(s[0].hashCode() % 100)).put("PhaseName", s[0]);
        app.put("StateId", Math.abs(s[1].hashCode() % 1000)).put("StateName", s[1]);
        app.put("DisqualifiedFlag", s.length > 2);
        app.put("LastModifiedDate", tick().toString());
    }

    // ------------------------------------------------------------------ query engine

    private JsonNode collection(List<ObjectNode> all, Map<String, String> q, Map<String, String> alias, String resource, String uniqField) {
        List<ObjectNode> items = new ArrayList<>();
        Map<String, String> finder = finder(q.get("finder"));
        List<String[]> conds = new ArrayList<>();
        if (q.containsKey("q")) for (String part : q.get("q").split(";")) {
            Matcher m = COND.matcher(part);
            if (m.matches()) conds.add(new String[]{m.group(1), m.group(2), unquote(m.group(3))});
        }
        for (ObjectNode it : all) {
            boolean ok = true;
            for (Map.Entry<String, String> f : finder.entrySet()) {
                String field = alias.getOrDefault(f.getKey(), f.getKey());
                if (!it.path(field).asText().equalsIgnoreCase(f.getValue())) { ok = false; break; }
            }
            for (String[] c : conds) if (ok && !test(it.path(alias.getOrDefault(c[0], c[0])).asText(null), c[1], c[2])) ok = false;
            if (ok) items.add(it);
        }
        if (q.containsKey("orderBy")) {
            String[] ob = q.get("orderBy").split(":");
            Comparator<ObjectNode> cmp = Comparator.comparing(o -> sortKey(o.path(ob[0])));
            if (ob.length > 1 && ob[1].equalsIgnoreCase("desc")) cmp = cmp.reversed();
            items.sort(cmp);
        }
        int offset = Integer.parseInt(q.getOrDefault("offset", "0"));
        int limit = Integer.parseInt(q.getOrDefault("limit", "25"));
        List<ObjectNode> page = items.subList(Math.min(offset, items.size()), Math.min(offset + limit, items.size()));
        boolean onlyData = "true".equals(q.get("onlyData"));
        Set<String> expand = new HashSet<>(List.of(q.getOrDefault("expand", "").split(",")));
        Set<String> fields = q.containsKey("fields") ? new HashSet<>(List.of(q.get("fields").split(","))) : null;
        List<JsonNode> out = new ArrayList<>();
        for (ObjectNode it : page) {
            ObjectNode o = clean(it, fields, !onlyData, resource, uniqField);
            Iterator<Map.Entry<String, JsonNode>> f = o.fields();
            while (f.hasNext()) {
                Map.Entry<String, JsonNode> e = f.next();
                if (e.getValue().isArray() && !e.getKey().equals("links") && !expand.contains(e.getKey()) && !expand.contains("all")) f.remove();
            }
            out.add(o);
        }
        return envelope(out, offset + limit < items.size(), limit, offset);
    }

    private ObjectNode clean(ObjectNode it, Set<String> fields, boolean links, String resource, String uniqField) {
        ObjectNode o = Json.obj();
        it.fields().forEachRemaining(e -> {
            if (e.getKey().startsWith("__")) return;
            if (fields != null && !fields.contains(e.getKey()) && !e.getValue().isArray()) return;
            o.set(e.getKey(), e.getValue().deepCopy());
        });
        if (links) {
            String id = it.path(uniqField).asText();
            o.putArray("links").addObject().put("rel", "self").put("href", baseUrl + REST + "/" + resource + "/" + id);
        }
        return o;
    }

    private static ObjectNode envelope(List<JsonNode> items, boolean hasMore, int limit, int offset) {
        ObjectNode env = Json.obj();
        ArrayNode arr = env.putArray("items");
        items.forEach(arr::add);
        env.put("count", items.size()).put("hasMore", hasMore).put("limit", limit).put("offset", offset);
        return env;
    }

    private static String sortKey(JsonNode v) {
        if (v.isNumber()) return String.format("%020d", v.asLong());
        try { return OffsetDateTime.parse(v.asText()).withOffsetSameInstant(ZoneOffset.UTC).toString(); } catch (Exception e) { return v.asText(""); }
    }

    private static boolean test(String actual, String op, String expected) {
        if (actual == null) return false;
        int cmp;
        try {
            cmp = Long.signum(OffsetDateTime.parse(actual).toInstant().toEpochMilli() - OffsetDateTime.parse(expected).toInstant().toEpochMilli());
        } catch (Exception e) {
            try { cmp = Long.compare(Long.parseLong(actual), Long.parseLong(expected)); }
            catch (NumberFormatException n) { cmp = actual.compareToIgnoreCase(expected); }
        }
        return switch (op) {
            case "=" -> cmp == 0;
            case ">" -> cmp > 0;
            case ">=" -> cmp >= 0;
            case "<" -> cmp < 0;
            case "<=" -> cmp <= 0;
            default -> false;
        };
    }

    private static Map<String, String> finder(String f) {
        Map<String, String> out = new LinkedHashMap<>();
        if (f == null || !f.contains(";")) return out;
        for (String kv : f.substring(f.indexOf(';') + 1).split(",")) {
            int eq = kv.indexOf('=');
            if (eq > 0) out.put(kv.substring(0, eq).trim(), unquote(kv.substring(eq + 1).trim()));
        }
        return out;
    }

    private static String unquote(String s) {
        return s.length() >= 2 && s.startsWith("'") && s.endsWith("'") ? s.substring(1, s.length() - 1) : s;
    }

    private static Map<String, String> query(String raw) {
        Map<String, String> m = new LinkedHashMap<>();
        if (raw == null) return m;
        for (String kv : raw.split("&")) {
            int eq = kv.indexOf('=');
            String k = eq < 0 ? kv : kv.substring(0, eq);
            String v = eq < 0 ? "" : kv.substring(eq + 1);
            m.put(URLDecoder.decode(k, StandardCharsets.UTF_8), URLDecoder.decode(v.replace("+", "%2B"), StandardCharsets.UTF_8));
        }
        return m;
    }

    // ------------------------------------------------------------------ auth

    private boolean authorised(HttpExchange ex) {
        String h = ex.getRequestHeaders().getFirst("Authorization");
        if (h == null) return false;
        if (h.startsWith("Bearer ")) return tokens.contains(h.substring(7));
        if (h.startsWith("Basic ")) {
            String raw = new String(Base64.getDecoder().decode(h.substring(6)), StandardCharsets.UTF_8);
            int c = raw.indexOf(':');
            return c > 0 && !raw.substring(c + 1).equals("wrong") && !raw.substring(c + 1).isEmpty();
        }
        return false;
    }

    private void token(HttpExchange ex, String body) throws IOException {
        Map<String, String> f = query(body);
        if (!"password".equals(f.get("grant_type")) || f.get("username") == null || "wrong".equals(f.get("password"))) {
            send(ex, 401, Json.obj().put("error", "invalid_grant").put("error_description", "Invalid username or password"));
            return;
        }
        String t = UUID.randomUUID().toString();
        synchronized (this) { tokens.add(t); }
        send(ex, 200, Json.obj().put("access_token", t).put("token_type", "Bearer").put("expires_in", 3600));
    }

    // ------------------------------------------------------------------ describe

    private JsonNode describeCandidate() {
        ObjectNode root = Json.obj();
        ObjectNode r = root.putObject("Resources").putObject("recruitingCandidates");
        ArrayNode attrs = r.putArray("attributes");
        for (String a : new String[]{"CandidateNumber", "PersonId", "FirstName", "LastName", "MiddleNames", "Email", "SourceMedium",
                "SourceName", "CandidateType", "PreferredLanguage", "CreatedBy", "CreationDate"}) attrs.addObject().put("name", a);
        ObjectNode ch = r.putObject("children");
        for (String c : new String[]{"candidatePhones", "candidateAddress", "education", "experience", "licensesAndCertificates", "skills", "attachments"}) {
            ch.putObject(c).putArray("attributes");
        }
        ObjectNode lov = r.putObject("lov").putObject("SourceMedium");
        for (String s : new String[]{"RECRUITER_SOURCED", "EMPLOYEE_REFERRAL", "REFERRAL", "SOCIAL_MEDIA", "JOB_FAIR", "JOB_BOARD", "AGENCY", "CAMPUS"}) {
            lov.put(s, s.replace('_', ' '));
        }
        return root;
    }

    private JsonNode describeRequisition() {
        ObjectNode root = Json.obj();
        ObjectNode r = root.putObject("Resources").putObject("recruitingJobRequisitions");
        ArrayNode attrs = r.putArray("attributes");
        for (String a : new String[]{"RequisitionId", "RequisitionNumber", "Title", "RecruitingType", "PhaseId", "PhaseName", "StateId", "StateName",
                "NumberOfOpenings", "UnlimitedOpenings", "HiredCount", "RecruiterId", "HiringManagerId", "PrimaryLocationId", "PrimaryWorkLocationId",
                "OrganizationId", "BusinessJustification", "EmployeeReferralBonus", "InternalDescription", "ExternalDescription",
                "ExternalPublishedJobStatus", "ExternalPublishedJobEndDate", "RequisitionLastModifiedDate"}) attrs.addObject().put("name", a);
        ObjectNode ch = r.putObject("children");
        ArrayNode dff = ch.putObject("requisitionDFF").putArray("attributes");
        for (String s : new String[]{"lob", "clientCategory", "specialtySoftware", "requisitionType", "requiredByDate", "departmentGroup", "employeeReferral"}) {
            dff.addObject().put("name", s);
        }
        ch.putObject("otherWorkLocations").putArray("attributes");
        return root;
    }

    // ------------------------------------------------------------------ helpers

    private static ObjectNode err(String title, String detail) {
        return Json.obj().put("title", title).put("detail", detail);
    }

    private static void send(HttpExchange ex, int status, JsonNode body) throws IOException {
        byte[] b = Json.compact(body).getBytes(StandardCharsets.UTF_8);
        ex.getResponseHeaders().set("Content-Type", "application/json");
        ex.sendResponseHeaders(status, b.length);
        try (OutputStream os = ex.getResponseBody()) { os.write(b); }
    }
}
