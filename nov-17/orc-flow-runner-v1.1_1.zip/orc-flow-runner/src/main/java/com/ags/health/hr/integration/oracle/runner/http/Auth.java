package com.ags.health.hr.integration.oracle.runner.http;

import com.ags.health.hr.integration.oracle.runner.core.Json;
import com.ags.health.hr.integration.oracle.runner.core.RunnerConfig;
import com.fasterxml.jackson.databind.JsonNode;

import java.io.IOException;
import java.net.URI;
import java.net.URLEncoder;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.time.Instant;
import java.util.Base64;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * Builds the Authorization header. Two modes, chosen by config oracle.auth.mode or --auth-mode:
 * <ul>
 *   <li>BASIC – username and password on every call (what Fusion REST accepts by default).</li>
 *   <li>TOKEN – username and password are exchanged for an OAuth access token at oracle.auth.tokenUrl
 *       (password grant, client id/secret from config, args or env); the token is cached and refreshed.</li>
 * </ul>
 * Credentials are held in memory only and never logged.
 */
public abstract class Auth {

    public abstract String header() throws OracleException;

    public abstract String mode();

    /** Called after a 401 so a token can be fetched again once. */
    public void invalidate() { }

    public static Auth create(RunnerConfig cfg, Credentials creds, HttpClient http) {
        String mode = cfg.str("oracle.auth.mode", "BASIC").toUpperCase();
        if ("TOKEN".equals(mode)) return new TokenAuth(cfg, creds, http);
        return new BasicAuth(creds);
    }

    /** Username, password and optional OAuth client credentials. */
    public record Credentials(String username, char[] password, String clientId, char[] clientSecret) {
        @Override public String toString() { return "Credentials[username=" + username + ", password=****]"; }
    }

    static final class BasicAuth extends Auth {
        private final String value;
        BasicAuth(Credentials c) {
            String raw = c.username() + ":" + new String(c.password());
            this.value = "Basic " + Base64.getEncoder().encodeToString(raw.getBytes(StandardCharsets.UTF_8));
        }
        @Override public String header() { return value; }
        @Override public String mode() { return "BASIC"; }
    }

    static final class TokenAuth extends Auth {
        private final RunnerConfig cfg;
        private final Credentials creds;
        private final HttpClient http;
        private String token;
        private Instant expiresAt = Instant.EPOCH;

        TokenAuth(RunnerConfig cfg, Credentials creds, HttpClient http) {
            this.cfg = cfg; this.creds = creds; this.http = http;
        }

        @Override public String mode() { return "TOKEN"; }

        @Override public void invalidate() { token = null; expiresAt = Instant.EPOCH; }

        @Override
        public synchronized String header() throws OracleException {
            if (token != null && Instant.now().isBefore(expiresAt.minusSeconds(60))) return "Bearer " + token;
            String tokenUrl = cfg.str("oracle.auth.tokenUrl", "");
            if (tokenUrl.isEmpty()) throw new OracleException(OracleException.Kind.CONFIG, 0, "token", "oracle.auth.tokenUrl is not set (needed for TOKEN mode)");

            Map<String, String> form = new LinkedHashMap<>();
            form.put("grant_type", cfg.str("oracle.auth.grantType", "password"));
            form.put("username", creds.username());
            form.put("password", new String(creds.password()));
            String scope = cfg.str("oracle.auth.scope", "");
            if (!scope.isEmpty()) form.put("scope", scope);
            boolean clientInHeader = "header".equalsIgnoreCase(cfg.str("oracle.auth.clientAuth", "header"));
            if (!clientInHeader && creds.clientId() != null) {
                form.put("client_id", creds.clientId());
                if (creds.clientSecret() != null) form.put("client_secret", new String(creds.clientSecret()));
            }
            String body = form.entrySet().stream()
                    .map(e -> URLEncoder.encode(e.getKey(), StandardCharsets.UTF_8) + "=" + URLEncoder.encode(e.getValue(), StandardCharsets.UTF_8))
                    .collect(Collectors.joining("&"));

            HttpRequest.Builder rb = HttpRequest.newBuilder(URI.create(tokenUrl))
                    .timeout(Duration.ofSeconds(cfg.integer("http.readTimeoutSeconds", 30)))
                    .header("Content-Type", "application/x-www-form-urlencoded")
                    .header("Accept", "application/json")
                    .POST(HttpRequest.BodyPublishers.ofString(body));
            if (clientInHeader && creds.clientId() != null) {
                String cs = creds.clientId() + ":" + (creds.clientSecret() == null ? "" : new String(creds.clientSecret()));
                rb.header("Authorization", "Basic " + Base64.getEncoder().encodeToString(cs.getBytes(StandardCharsets.UTF_8)));
            }
            try {
                HttpResponse<String> r = http.send(rb.build(), HttpResponse.BodyHandlers.ofString());
                if (r.statusCode() == 401 || r.statusCode() == 400 || r.statusCode() == 403) {
                    throw new OracleException(OracleException.Kind.AUTH, r.statusCode(), "token",
                            "Token request refused (HTTP " + r.statusCode() + "): " + OracleException.messageFrom(r.body()));
                }
                if (r.statusCode() / 100 != 2) {
                    throw new OracleException(OracleException.Kind.RETRYABLE, r.statusCode(), "token", "Token endpoint returned HTTP " + r.statusCode());
                }
                JsonNode json = Json.parse(r.body());
                token = Json.text(json, "access_token");
                if (token == null) throw new OracleException(OracleException.Kind.AUTH, r.statusCode(), "token", "Token response has no access_token");
                long ttl = json.path("expires_in").asLong(3600);
                expiresAt = Instant.now().plusSeconds(ttl);
                return "Bearer " + token;
            } catch (IOException e) {
                throw new OracleException(OracleException.Kind.RETRYABLE, 0, "token", "Token endpoint not reachable: " + e.getMessage());
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                throw new OracleException(OracleException.Kind.RETRYABLE, 0, "token", "Interrupted");
            }
        }
    }
}
