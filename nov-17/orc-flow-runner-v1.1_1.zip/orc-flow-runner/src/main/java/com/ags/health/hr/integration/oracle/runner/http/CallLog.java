package com.ags.health.hr.integration.oracle.runner.http;

import com.ags.health.hr.integration.oracle.runner.core.Json;
import com.ags.health.hr.integration.oracle.runner.core.RunnerConfig;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;

import java.io.IOException;
import java.io.UncheckedIOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.time.OffsetDateTime;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.regex.Pattern;

/** Writes every Oracle call to calllog.jsonl (one JSON per line) with personal data masked. Mirrors integ_call_log. */
public final class CallLog {

    private static final Pattern EMAIL = Pattern.compile("([A-Za-z0-9._%+-])[A-Za-z0-9._%+-]*(@[A-Za-z0-9.-]+)");

    private final Path file;
    private final Set<String> maskKeys = new HashSet<>();
    private final Set<String> fileKeys = new HashSet<>();
    private final int maxBody;

    public CallLog(Path file, RunnerConfig cfg) {
        this.file = file;
        cfg.strings("masking.keys").forEach(k -> maskKeys.add(k.toLowerCase()));
        cfg.strings("masking.fileKeys").forEach(k -> fileKeys.add(k.toLowerCase()));
        this.maxBody = cfg.integer("masking.maxLoggedBodyChars", 4000);
        try {
            Files.createDirectories(file.toAbsolutePath().getParent());
        } catch (IOException e) {
            throw new UncheckedIOException(e);
        }
    }

    public synchronized void write(String op, String method, String url, int attempt, int status, long ms,
                                   JsonNode request, String responseBody, String error, JsonNode resolved) {
        ObjectNode line = Json.obj();
        line.put("calledAt", OffsetDateTime.now().toString());
        line.put("operation", op);
        line.put("method", method);
        line.put("url", maskUrl(url));
        line.put("attempt", attempt);
        line.put("httpStatus", status);
        line.put("durationMs", ms);
        if (resolved != null && !resolved.isEmpty()) line.set("resolved", resolved);
        if (request != null) line.set("request", mask(request));
        if (responseBody != null) {
            JsonNode r = Json.parse(responseBody);
            String text = Json.compact(r.isMissingNode() ? Json.F.textNode("") : mask(r));
            line.put("response", text.length() > maxBody ? text.substring(0, maxBody) + "...(truncated)" : text);
        }
        if (error != null) line.put("error", error);
        try {
            Files.writeString(file, Json.compact(line) + System.lineSeparator(), StandardCharsets.UTF_8,
                    StandardOpenOption.CREATE, StandardOpenOption.APPEND);
        } catch (IOException e) {
            System.err.println("WARN cannot write call log: " + e.getMessage());
        }
    }

    public String maskUrl(String url) {
        return url == null ? null : EMAIL.matcher(url).replaceAll("$1***$2").replace("%40", "@").replaceAll(EMAIL.pattern(), "$1***$2");
    }

    /** Returns a masked deep copy. */
    public JsonNode mask(JsonNode n) {
        if (n == null) return null;
        JsonNode copy = n.deepCopy();
        maskInPlace(copy);
        return copy;
    }

    private void maskInPlace(JsonNode n) {
        if (n instanceof ObjectNode o) {
            Iterator<Map.Entry<String, JsonNode>> it = o.fields();
            while (it.hasNext()) {
                Map.Entry<String, JsonNode> e = it.next();
                String k = e.getKey().toLowerCase();
                JsonNode v = e.getValue();
                if (fileKeys.contains(k) && v.isTextual()) {
                    e.setValue(Json.F.textNode("[file content, " + v.asText().length() + " base64 chars]"));
                } else if (maskKeys.contains(k) && v.isValueNode() && !v.isNull()) {
                    e.setValue(Json.F.textNode(maskValue(v.asText())));
                } else {
                    maskInPlace(v);
                }
            }
        } else if (n instanceof ArrayNode a) {
            a.forEach(this::maskInPlace);
        }
    }

    static String maskValue(String s) {
        if (s.contains("@")) return EMAIL.matcher(s).replaceAll("$1***$2");
        if (s.length() <= 2) return "**";
        return s.charAt(0) + "*".repeat(Math.min(6, s.length() - 2)) + s.charAt(s.length() - 1);
    }
}
