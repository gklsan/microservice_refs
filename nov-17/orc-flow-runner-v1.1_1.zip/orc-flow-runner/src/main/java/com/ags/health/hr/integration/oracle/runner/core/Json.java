package com.ags.health.hr.integration.oracle.runner.core;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.JsonNodeFactory;
import com.fasterxml.jackson.databind.node.MissingNode;
import com.fasterxml.jackson.databind.node.ObjectNode;

import java.io.IOException;
import java.io.InputStream;
import java.io.UncheckedIOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;

/** Small JSON helpers shared by every class. */
public final class Json {

    public static final ObjectMapper MAPPER = new ObjectMapper().enable(SerializationFeature.INDENT_OUTPUT);
    public static final JsonNodeFactory F = JsonNodeFactory.instance;

    private Json() { }

    public static ObjectNode obj() { return F.objectNode(); }

    public static ArrayNode arr() { return F.arrayNode(); }

    public static JsonNode read(Path file) {
        try {
            return MAPPER.readTree(file.toFile());
        } catch (IOException e) {
            throw new UncheckedIOException("Cannot read JSON file " + file + ": " + e.getMessage(), e);
        }
    }

    public static JsonNode read(InputStream in, String name) {
        try (in) {
            return MAPPER.readTree(in);
        } catch (IOException e) {
            throw new UncheckedIOException("Cannot read JSON " + name + ": " + e.getMessage(), e);
        }
    }

    public static JsonNode parse(String text) {
        if (text == null || text.isBlank()) return MissingNode.getInstance();
        try {
            return MAPPER.readTree(text);
        } catch (IOException e) {
            return F.textNode(text);
        }
    }

    public static String write(JsonNode node) {
        try {
            return MAPPER.writeValueAsString(node);
        } catch (IOException e) {
            throw new UncheckedIOException(e);
        }
    }

    public static String compact(JsonNode node) {
        try {
            return new ObjectMapper().writeValueAsString(node);
        } catch (IOException e) {
            throw new UncheckedIOException(e);
        }
    }

    /** Writes atomically (temp file + move) so a crash never leaves half a file. */
    public static void writeFile(Path file, JsonNode node) {
        try {
            Path parent = file.toAbsolutePath().getParent();
            if (parent != null) Files.createDirectories(parent);
            Path tmp = file.resolveSibling(file.getFileName() + ".tmp");
            Files.writeString(tmp, write(node), StandardCharsets.UTF_8);
            Files.move(tmp, file, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE);
        } catch (IOException e) {
            throw new UncheckedIOException("Cannot write " + file + ": " + e.getMessage(), e);
        }
    }

    /**
     * Reads a dotted path such as {@code a.b[0].c} or {@code items.0.Name}.
     * Returns MissingNode when any part is absent.
     */
    public static JsonNode at(JsonNode node, String path) {
        if (node == null) return MissingNode.getInstance();
        if (path == null || path.isEmpty()) return node;
        JsonNode cur = node;
        for (String raw : path.replace("[", ".").replace("]", "").split("\\.")) {
            if (raw.isEmpty()) continue;
            if (cur == null || cur.isMissingNode() || cur.isNull()) return MissingNode.getInstance();
            if (cur.isArray() && raw.chars().allMatch(Character::isDigit)) {
                cur = cur.path(Integer.parseInt(raw));
            } else {
                cur = cur.path(raw);
            }
        }
        return cur == null ? MissingNode.getInstance() : cur;
    }

    public static String text(JsonNode node, String path) {
        JsonNode v = at(node, path);
        return v.isMissingNode() || v.isNull() ? null : v.asText();
    }

    public static boolean isEmpty(JsonNode v) {
        return v == null || v.isMissingNode() || v.isNull()
                || (v.isTextual() && v.asText().isBlank())
                || (v.isContainerNode() && v.isEmpty());
    }
}
