package com.ags.health.hr.integration.oracle.runner.pdf;

import java.io.ByteArrayOutputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

/**
 * Tiny text-only PDF writer (A4, Helvetica) so the runner has no PDF library dependency.
 * In smartie-core the interview summary should use the existing PDFBox profile export instead.
 */
public final class SimplePdf {

    private static final float W = 595, H = 842, MARGIN = 50;

    private record Line(boolean bold, float size, String text, float gapBefore) { }

    private final List<Line> lines = new ArrayList<>();
    private final String title;

    public SimplePdf(String title) { this.title = title; }

    public SimplePdf heading(String text) { lines.add(new Line(true, 12, text, 10)); return this; }

    public SimplePdf title(String text) { lines.add(new Line(true, 16, text, 0)); return this; }

    public SimplePdf text(String text) {
        for (String w : wrap(text, 10)) lines.add(new Line(false, 10, w, 2));
        return this;
    }

    public SimplePdf small(String text) {
        for (String w : wrap(text, 8)) lines.add(new Line(false, 8, w, 2));
        return this;
    }

    public SimplePdf field(String label, String value) {
        return text(label + ": " + (value == null || value.isBlank() ? "-" : value));
    }

    public byte[] bytes() {
        List<StringBuilder> pages = new ArrayList<>();
        StringBuilder cur = null;
        float y = 0;
        for (Line l : lines) {
            float need = l.size() + 4 + l.gapBefore();
            if (cur == null || y - need < MARGIN) {
                cur = new StringBuilder();
                pages.add(cur);
                y = H - MARGIN;
            }
            y -= need;
            cur.append("BT /").append(l.bold() ? "F2" : "F1").append(' ').append(l.size()).append(" Tf ")
               .append(MARGIN).append(' ').append(y).append(" Td (").append(escape(l.text())).append(") Tj ET\n");
        }
        if (pages.isEmpty()) pages.add(new StringBuilder());

        ByteArrayOutputStream out = new ByteArrayOutputStream();
        List<Integer> offsets = new ArrayList<>();
        write(out, "%PDF-1.4\n%âãÏÓ\n");
        int pageCount = pages.size();
        int firstPageObj = 5;
        StringBuilder kids = new StringBuilder();
        for (int i = 0; i < pageCount; i++) kids.append(firstPageObj + i * 2).append(" 0 R ");

        obj(out, offsets, "<< /Type /Catalog /Pages 2 0 R >>");
        obj(out, offsets, "<< /Type /Pages /Kids [" + kids + "] /Count " + pageCount + " >>");
        obj(out, offsets, "<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica /Encoding /WinAnsiEncoding >>");
        obj(out, offsets, "<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold /Encoding /WinAnsiEncoding >>");
        for (int i = 0; i < pageCount; i++) {
            int contentObj = firstPageObj + i * 2 + 1;
            obj(out, offsets, "<< /Type /Page /Parent 2 0 R /MediaBox [0 0 " + (int) W + " " + (int) H + "] "
                    + "/Resources << /Font << /F1 3 0 R /F2 4 0 R >> >> /Contents " + contentObj + " 0 R >>");
            byte[] stream = pages.get(i).toString().getBytes(StandardCharsets.ISO_8859_1);
            offsets.add(out.size());
            write(out, contentObj + " 0 obj\n<< /Length " + stream.length + " >>\nstream\n");
            out.writeBytes(stream);
            write(out, "\nendstream\nendobj\n");
        }
        int infoObj = offsets.size() + 1;
        obj(out, offsets, "<< /Title (" + escape(title) + ") /Producer (DigiHire ORC Flow Runner) >>");
        int xref = out.size();
        StringBuilder x = new StringBuilder("xref\n0 " + (offsets.size() + 1) + "\n0000000000 65535 f \n");
        for (int off : offsets) x.append(String.format("%010d 00000 n \n", off));
        x.append("trailer\n<< /Size ").append(offsets.size() + 1).append(" /Root 1 0 R /Info ").append(infoObj)
         .append(" 0 R >>\nstartxref\n").append(xref).append("\n%%EOF\n");
        write(out, x.toString());
        return out.toByteArray();
    }

    private static void obj(ByteArrayOutputStream out, List<Integer> offsets, String body) {
        offsets.add(out.size());
        write(out, offsets.size() + " 0 obj\n" + body + "\nendobj\n");
    }

    private static void write(ByteArrayOutputStream out, String s) { out.writeBytes(s.getBytes(StandardCharsets.ISO_8859_1)); }

    private static List<String> wrap(String text, float size) {
        int max = (int) ((W - 2 * MARGIN) / (size * 0.5f));
        List<String> out = new ArrayList<>();
        for (String para : (text == null ? "" : text).split("\n")) {
            String rest = para;
            while (rest.length() > max) {
                int cut = rest.lastIndexOf(' ', max);
                if (cut <= 0) cut = max;
                out.add(rest.substring(0, cut));
                rest = rest.substring(cut).trim();
            }
            out.add(rest);
        }
        return out;
    }

    private static String escape(String s) {
        StringBuilder sb = new StringBuilder();
        for (char ch : s.toCharArray()) {
            switch (ch) {
                case '\\' -> sb.append("\\\\");
                case '(' -> sb.append("\\(");
                case ')' -> sb.append("\\)");
                case '–', '—' -> sb.append('-');
                case '›' -> sb.append('>');
                case '‘', '’' -> sb.append('\'');
                case '“', '”' -> sb.append('"');
                case '•' -> sb.append('-');
                default -> sb.append(ch < 256 ? ch : '?');
            }
        }
        return sb.toString();
    }
}
