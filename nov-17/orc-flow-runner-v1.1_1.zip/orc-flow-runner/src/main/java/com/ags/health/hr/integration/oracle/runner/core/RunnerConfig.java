package com.ags.health.hr.integration.oracle.runner.core;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.node.ObjectNode;

import java.io.InputStream;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

/**
 * All behaviour comes from configuration: base URL, operations (method, path, query), payload mappings,
 * mandatory fields, value maps, stage map, validity rules, retries, masking. The built-in default
 * (defaults/orc-config.json) is loaded first and a user file, if given, is deep-merged over it.
 */
public final class RunnerConfig {

    private final ObjectNode root;

    private RunnerConfig(ObjectNode root) { this.root = root; }

    public static RunnerConfig load(Path userFile) {
        ObjectNode base = (ObjectNode) defaults();
        if (userFile != null) {
            merge(base, Json.read(userFile));
        }
        return new RunnerConfig(base);
    }

    public static JsonNode defaults() {
        InputStream in = RunnerConfig.class.getResourceAsStream("/defaults/orc-config.json");
        if (in == null) throw new IllegalStateException("Built-in config defaults/orc-config.json missing from the jar");
        return Json.read(in, "defaults/orc-config.json");
    }

    /** Deep merge: objects merge key by key, everything else (arrays, values) replaces. */
    static void merge(ObjectNode target, JsonNode src) {
        Iterator<Map.Entry<String, JsonNode>> it = src.fields();
        while (it.hasNext()) {
            Map.Entry<String, JsonNode> e = it.next();
            JsonNode existing = target.get(e.getKey());
            if (existing instanceof ObjectNode && e.getValue().isObject()) {
                merge((ObjectNode) existing, e.getValue());
            } else {
                target.set(e.getKey(), e.getValue().deepCopy());
            }
        }
    }

    public JsonNode root() { return root; }

    /** Merges overrides (for example "configOverrides" from the data file) over the current values. */
    public void mergeOverrides(JsonNode overrides) {
        ObjectNode copy = overrides.deepCopy();
        copy.remove("$comment");
        merge(root, copy);
    }

    public JsonNode at(String path) { return Json.at(root, path); }

    public String str(String path, String def) {
        JsonNode v = at(path);
        return v.isMissingNode() || v.isNull() || v.asText().isEmpty() ? def : v.asText();
    }

    public int integer(String path, int def) {
        JsonNode v = at(path);
        return v.isMissingNode() || v.isNull() ? def : v.asInt(def);
    }

    public boolean bool(String path, boolean def) {
        JsonNode v = at(path);
        return v.isMissingNode() || v.isNull() ? def : v.asBoolean(def);
    }

    public List<String> strings(String path) {
        List<String> out = new ArrayList<>();
        at(path).forEach(n -> out.add(n.asText()));
        return out;
    }

    public List<Integer> ints(String path) {
        List<Integer> out = new ArrayList<>();
        at(path).forEach(n -> out.add(n.asInt()));
        return out;
    }

    public void set(String key, String value) {
        String[] parts = key.split("\\.");
        ObjectNode cur = root;
        for (int i = 0; i < parts.length - 1; i++) {
            JsonNode next = cur.get(parts[i]);
            if (!(next instanceof ObjectNode)) {
                next = Json.obj();
                cur.set(parts[i], next);
            }
            cur = (ObjectNode) next;
        }
        cur.put(parts[parts.length - 1], value);
    }

    public JsonNode operation(String name) {
        JsonNode op = at("operations." + name);
        if (op.isMissingNode()) throw new IllegalArgumentException("Operation '" + name + "' is not defined in config.operations");
        return op;
    }

    public JsonNode mapping(String name) {
        JsonNode m = at("mappings." + name);
        if (m.isMissingNode()) throw new IllegalArgumentException("Mapping '" + name + "' is not defined in config.mappings");
        return m;
    }

    public String baseUrl() { return str("oracle.baseUrl", ""); }

    public String restPath() { return str("oracle.restPath", "/hcmRestApi/resources/11.13.18.05"); }
}
