package com.ags.health.hr.integration.oracle.runner;

import com.ags.health.hr.integration.oracle.runner.core.Json;
import com.ags.health.hr.integration.oracle.runner.core.RunnerConfig;
import com.ags.health.hr.integration.oracle.runner.data.SampleDataGenerator;
import com.ags.health.hr.integration.oracle.runner.flow.AuthCheckFlow;
import com.ags.health.hr.integration.oracle.runner.flow.CandidateHandoverFlow;
import com.ags.health.hr.integration.oracle.runner.flow.FlowContext;
import com.ags.health.hr.integration.oracle.runner.flow.OfferTrackingFlow;
import com.ags.health.hr.integration.oracle.runner.flow.ReferenceFlow;
import com.ags.health.hr.integration.oracle.runner.flow.RequisitionSyncFlow;
import com.ags.health.hr.integration.oracle.runner.flow.RequisitionWriteFlow;
import com.ags.health.hr.integration.oracle.runner.http.Auth;
import com.ags.health.hr.integration.oracle.runner.http.CallLog;
import com.ags.health.hr.integration.oracle.runner.http.OracleClient;
import com.ags.health.hr.integration.oracle.runner.mock.MockOracleServer;
import com.ags.health.hr.integration.oracle.runner.state.RunReport;
import com.ags.health.hr.integration.oracle.runner.state.StateStore;
import com.fasterxml.jackson.databind.JsonNode;

import java.io.Console;
import java.io.IOException;
import java.io.InputStream;
import java.net.URI;
import java.net.http.HttpClient;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * DigiHire ↔ Oracle Recruiting Cloud flow runner (design v1.1).
 *
 * <pre>
 * java -jar orc-flow-runner.jar run --data data.json --username USER --password PASS
 * java -jar orc-flow-runner.jar run --data data.json --mock --username test --password test
 * java -jar orc-flow-runner.jar generate-data --candidates 6 --out data.json
 * java -jar orc-flow-runner.jar export-samples --out ./orc-runner
 * java -jar orc-flow-runner.jar help
 * </pre>
 */
public final class OrcFlowRunner {

    public static final String VERSION = "1.1.0";
    private static final List<String> ALL_FLOWS = List.of("auth", "flow0", "flow1", "flow2", "flow3", "flow4");

    public static void main(String[] argv) {
        int code;
        try {
            code = new OrcFlowRunner().dispatch(argv);
        } catch (IllegalArgumentException e) {
            System.err.println("ERROR: " + e.getMessage());
            System.err.println("Run 'java -jar orc-flow-runner.jar help' for usage.");
            code = 1;
        }
        System.exit(code);
    }

    int dispatch(String[] argv) {
        String cmd = argv.length == 0 || argv[0].startsWith("--") ? "run" : argv[0];
        String[] rest = argv.length > 0 && !argv[0].startsWith("--") ? Arrays.copyOfRange(argv, 1, argv.length) : argv;
        Args a = Args.parse(rest);
        return switch (cmd) {
            case "run" -> run(a);
            case "generate-data" -> generate(a);
            case "export-samples" -> exportSamples(a);
            case "mock-server" -> mockServer(a);
            case "help", "-h", "--help" -> { help(); yield 0; }
            default -> throw new IllegalArgumentException("Unknown command '" + cmd + "'");
        };
    }

    // ---------------------------------------------------------------- run

    int run(Args a) {
        RunnerConfig cfg = RunnerConfig.load(a.path("config"));
        Path dataFile = a.path("data");
        if (dataFile == null) throw new IllegalArgumentException("--data <file.json> is required (create one with: generate-data --out data.json)");
        if (!Files.exists(dataFile)) throw new IllegalArgumentException("Data file not found: " + dataFile);
        JsonNode data = Json.read(dataFile);
        if (data.path("configOverrides").isObject()) cfg.mergeOverrides(data.get("configOverrides"));
        if (a.has("base-url")) cfg.set("oracle.baseUrl", a.get("base-url"));
        if (a.has("auth-mode")) cfg.set("oracle.auth.mode", a.get("auth-mode").toUpperCase());
        if (a.has("token-url")) cfg.set("oracle.auth.tokenUrl", a.get("token-url"));
        for (String kv : a.all("set")) {
            int eq = kv.indexOf('=');
            if (eq < 1) throw new IllegalArgumentException("--set needs key=value, got " + kv);
            cfg.set(kv.substring(0, eq), kv.substring(eq + 1));
        }

        MockOracleServer mock = null;
        if (a.flag("mock")) {
            mock = MockOracleServer.start(a.integer("mock-port", 0), data);
            cfg.set("oracle.baseUrl", mock.baseUrl());
            cfg.set("oracle.auth.tokenUrl", mock.tokenUrl());
        }

        Auth.Credentials creds = credentials(a, cfg);
        Path out = a.path("out") == null ? Path.of("orc-run-output") : a.path("out");
        List<String> flows = a.has("flows") && !"all".equalsIgnoreCase(a.get("flows"))
                ? Arrays.stream(a.get("flows").split(",")).map(String::trim).toList() : ALL_FLOWS;
        for (String f : flows) if (!ALL_FLOWS.contains(f)) throw new IllegalArgumentException("Unknown flow '" + f + "'. Use " + ALL_FLOWS);

        banner(cfg, creds, dataFile, out, flows, a, mock != null);

        RunReport report = new RunReport();
        StateStore state = new StateStore(out.resolve("state.json"), a.flag("reset-state"));
        CallLog log = new CallLog(out.resolve("calllog.jsonl"), cfg);
        HttpClient http = OracleClient.httpClient(cfg);
        OracleClient oracle = new OracleClient(cfg, Auth.create(cfg, creds, http), log, http, a.flag("verbose"));
        FlowContext.Options opts = new FlowContext.Options(a.flag("dry-run"), a.flag("verbose"),
                a.integer("polls", 1), a.flag("full-pass"), a.flag("reconcile"));
        Path dataDir = dataFile.toAbsolutePath().getParent();
        FlowContext ctx = new FlowContext(cfg, oracle, state, report, log, data, dataDir, out, opts);

        ReferenceFlow ref = new ReferenceFlow(ctx);
        RequisitionSyncFlow reqs = new RequisitionSyncFlow(ctx);
        try {
            for (String f : flows) {
                try {
                    switch (f) {
                        case "auth" -> new AuthCheckFlow(ctx).run();
                        case "flow0" -> ref.run();
                        case "flow1" -> reqs.run();
                        case "flow2" -> new CandidateHandoverFlow(ctx, ref, reqs).run();
                        case "flow3" -> new OfferTrackingFlow(ctx, reqs).run();
                        case "flow4" -> new RequisitionWriteFlow(ctx, ref).run();
                        default -> { }
                    }
                } catch (FlowContext.AuthStop stop) {
                    report.add(f, "Run stopped", "", RunReport.Status.AUTH_STOP, "No further Oracle calls in this run");
                    break;
                } catch (RuntimeException e) {
                    report.add(f, "Unexpected error", "", RunReport.Status.FAIL, e.toString());
                    if (a.flag("verbose")) e.printStackTrace();
                }
            }
        } finally {
            state.save();
            report.write(out.resolve("report.json"));
            if (mock != null) mock.stop();
        }
        report.printSummary();
        System.out.println("  Output folder : " + out.toAbsolutePath());
        System.out.println("    report.json  - every step   | state.json - links, stages, timeline, alerts");
        System.out.println("    calllog.jsonl - every Oracle call (masked) | payloads/ - request bodies (masked) | summaries/ - interview PDFs");
        return report.authStopped() ? 3 : report.hasFailures() ? 2 : 0;
    }

    private Auth.Credentials credentials(Args a, RunnerConfig cfg) {
        String user = a.has("username") ? a.get("username") : System.getenv("ORACLE_USERNAME");
        char[] pass = null;
        if (a.has("password")) pass = a.get("password").toCharArray();
        else if (a.has("password-file")) {
            try {
                pass = Files.readString(a.path("password-file"), StandardCharsets.UTF_8).strip().toCharArray();
            } catch (IOException e) {
                throw new IllegalArgumentException("Cannot read --password-file: " + e.getMessage());
            }
        } else if (System.getenv("ORACLE_PASSWORD") != null) pass = System.getenv("ORACLE_PASSWORD").toCharArray();
        Console console = System.console();
        if (user == null && console != null) user = console.readLine("Oracle username: ");
        if (pass == null && console != null) pass = console.readPassword("Oracle password for %s: ", user);
        if (user == null || user.isBlank() || pass == null || pass.length == 0) {
            throw new IllegalArgumentException("Username and password are required: --username/--password, or env ORACLE_USERNAME/ORACLE_PASSWORD, or the prompt");
        }
        String clientId = a.has("client-id") ? a.get("client-id") : System.getenv("ORACLE_CLIENT_ID");
        String secret = a.has("client-secret") ? a.get("client-secret") : System.getenv("ORACLE_CLIENT_SECRET");
        if ("TOKEN".equals(cfg.str("oracle.auth.mode", "BASIC")) && clientId == null && !a.flag("mock")) {
            System.out.println("  NOTE: TOKEN mode without a client id - fine only if the token endpoint does not need one.");
        }
        return new Auth.Credentials(user, pass, clientId, secret == null ? null : secret.toCharArray());
    }

    private void banner(RunnerConfig cfg, Auth.Credentials c, Path data, Path out, List<String> flows, Args a, boolean mock) {
        System.out.println("DigiHire ORC Flow Runner " + VERSION + " (design v1.1)");
        System.out.println("  Oracle     : " + host(cfg.baseUrl()) + cfg.restPath() + (mock ? "  [EMBEDDED MOCK]" : ""));
        System.out.println("  Auth       : " + cfg.str("oracle.auth.mode", "BASIC") + " as " + c.username()
                + ("TOKEN".equals(cfg.str("oracle.auth.mode", "")) ? " (token from " + host(cfg.str("oracle.auth.tokenUrl", "?")) + ")" : ""));
        System.out.println("  Data       : " + data.toAbsolutePath());
        System.out.println("  Flows      : " + flows + (a.flag("dry-run") ? "  [DRY RUN - no writes]" : "")
                + (a.flag("full-pass") ? " +full-pass" : "") + (a.flag("reconcile") ? " +reconcile" : "")
                + (a.integer("polls", 1) > 1 ? " polls=" + a.integer("polls", 1) : ""));
        System.out.println("  Output     : " + out.toAbsolutePath());
    }

    private static String host(String url) {
        try { URI u = URI.create(url); return u.getScheme() + "://" + u.getAuthority(); } catch (Exception e) { return url; }
    }

    // ---------------------------------------------------------------- other commands

    int generate(Args a) {
        Path out = a.path("out") == null ? Path.of("data.json") : a.path("out");
        JsonNode data = SampleDataGenerator.generate(a.integer("candidates", 8), a.integer("seed", (int) (System.currentTimeMillis() % 100000)));
        Json.writeFile(out, data);
        System.out.println("Random test data written to " + out.toAbsolutePath());
        System.out.println("Try it:  java -jar orc-flow-runner.jar run --data " + out + " --mock --username test --password test --polls 8");
        return 0;
    }

    int exportSamples(Args a) {
        Path dir = a.path("out") == null ? Path.of("orc-runner") : a.path("out");
        try {
            Files.createDirectories(dir);
            copy("/defaults/orc-config.json", dir.resolve("orc-config.json"));
            copy("/defaults/config-live-template.json", dir.resolve("config-live-template.json"));
            copy("/defaults/data-live-template.json", dir.resolve("data-live-template.json"));
            Json.writeFile(dir.resolve("sample-data.json"), SampleDataGenerator.generate(8, 42));
        } catch (IOException e) {
            throw new IllegalArgumentException("Cannot write samples: " + e.getMessage());
        }
        System.out.println("Samples written to " + dir.toAbsolutePath() + ": orc-config.json, config-live-template.json, data-live-template.json, sample-data.json");
        return 0;
    }

    int mockServer(Args a) {
        JsonNode data = a.path("data") == null ? SampleDataGenerator.generate(8, 42) : Json.read(a.path("data"));
        MockOracleServer m = MockOracleServer.start(a.integer("port", 8099), data);
        System.out.println("Mock Oracle running at " + m.baseUrl() + RunnerConfig.load(null).restPath());
        System.out.println("Token endpoint: " + m.tokenUrl() + "   (any username; password 'wrong' is refused)");
        System.out.println("Press Ctrl+C to stop.");
        try { Thread.currentThread().join(); } catch (InterruptedException e) { Thread.currentThread().interrupt(); }
        return 0;
    }

    private static void copy(String resource, Path target) throws IOException {
        try (InputStream in = OrcFlowRunner.class.getResourceAsStream(resource)) {
            if (in == null) throw new IOException("missing resource " + resource);
            Files.write(target, in.readAllBytes());
        }
    }

    static void help() {
        System.out.println("""
            DigiHire ORC Flow Runner %s - runs the DigiHire <-> Oracle Recruiting Cloud flows (design v1.1)

            COMMANDS
              run              Run the flows (default command)
              generate-data    Write a random test data file          --candidates N  --out data.json  --seed N
              export-samples   Write editable config and data files   --out ./orc-runner
              mock-server      Start the mock Oracle only             --port 8099  --data data.json
              help             This text

            RUN OPTIONS
              --data FILE            Input JSON (candidates, requisition checks, requisition writes)   [required]
              --username U           Oracle user  (or env ORACLE_USERNAME, or prompt)
              --password P           Oracle password (or --password-file F, env ORACLE_PASSWORD, or hidden prompt)
              --auth-mode basic|token  BASIC = user/password on each call; TOKEN = exchange user/password for an access token
              --token-url URL        OAuth token endpoint for TOKEN mode
              --client-id ID         OAuth client id (or env ORACLE_CLIENT_ID)
              --client-secret S      OAuth client secret (or env ORACLE_CLIENT_SECRET)
              --config FILE          Config merged over the built-in defaults (operations, mappings, rules)
              --base-url URL         Oracle pod, e.g. https://fa-xxxx.fa.ocs.oraclecloud.com
              --set key=value        Override any config value, e.g. --set flow3.waitWorkingDays=0 (repeatable)
              --flows LIST           auth,flow0,flow1,flow2,flow3,flow4  (default: all)
              --out DIR              Output folder (default ./orc-run-output); state.json there is reused next run
              --reset-state          Start with an empty state.json
              --dry-run              Build and save every payload but send no POST/PATCH (reads still run)
              --polls N              Flow 3: poll N times in this run
              --full-pass            Flow 1: also run the nightly full requisition pass
              --reconcile            Flow 3: also run the nightly reconciliation
              --mock                 Start an embedded mock Oracle and run against it (no Oracle access needed)
              --verbose              Print every HTTP call

            EXIT CODES  0 ok | 1 bad arguments | 2 some steps failed | 3 login refused (all Oracle jobs stopped)
            """.formatted(VERSION));
    }

    // ---------------------------------------------------------------- args

    /** Minimal --key value / --flag parser. --set may repeat. */
    static final class Args {
        private final Map<String, List<String>> values = new HashMap<>();

        static Args parse(String[] argv) {
            Args a = new Args();
            for (int i = 0; i < argv.length; i++) {
                String k = argv[i];
                if (!k.startsWith("--")) throw new IllegalArgumentException("Unexpected argument '" + k + "'");
                k = k.substring(2);
                String v = "true";
                if (k.contains("=") && !k.startsWith("set")) {
                    v = k.substring(k.indexOf('=') + 1);
                    k = k.substring(0, k.indexOf('='));
                } else if (i + 1 < argv.length && !argv[i + 1].startsWith("--")) {
                    v = argv[++i];
                }
                a.values.computeIfAbsent(k, x -> new ArrayList<>()).add(v);
            }
            return a;
        }

        boolean has(String k) { return values.containsKey(k); }
        String get(String k) { List<String> v = values.get(k); return v == null ? null : v.get(v.size() - 1); }
        List<String> all(String k) { return values.getOrDefault(k, List.of()); }
        boolean flag(String k) { return has(k) && !"false".equalsIgnoreCase(get(k)); }
        Path path(String k) { return has(k) ? Path.of(get(k)) : null; }
        int integer(String k, int def) {
            try { return has(k) ? Integer.parseInt(get(k)) : def; }
            catch (NumberFormatException e) { throw new IllegalArgumentException("--" + k + " must be a number"); }
        }
    }
}
