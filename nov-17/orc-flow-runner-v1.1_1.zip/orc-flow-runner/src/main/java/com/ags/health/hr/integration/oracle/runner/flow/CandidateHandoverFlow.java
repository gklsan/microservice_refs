package com.ags.health.hr.integration.oracle.runner.flow;

import com.ags.health.hr.integration.oracle.runner.core.Json;
import com.ags.health.hr.integration.oracle.runner.core.TemplateEngine;
import com.ags.health.hr.integration.oracle.runner.http.OracleClient;
import com.ags.health.hr.integration.oracle.runner.http.OracleException;
import com.ags.health.hr.integration.oracle.runner.pdf.InterviewSummaryPdf;
import com.ags.health.hr.integration.oracle.runner.state.RunReport.Status;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.OffsetDateTime;
import java.util.ArrayList;
import java.util.Base64;
import java.util.List;
import java.util.Locale;

/**
 * Flow 2 – Candidate hand-over at selection. For each selected candidate:
 * checks → requisition still open → look up first → create candidate (profile, work, education,
 * certificates, skills, resume, interview summary PDF) or add a new summary to the existing candidate →
 * store IDs → alert the Oracle recruiter → lock the handed-over profile fields.
 * DigiHire never creates the Oracle job application.
 */
public final class CandidateHandoverFlow {

    private static final String F = "flow2";
    private final FlowContext c;
    private final ReferenceFlow ref;
    private final RequisitionSyncFlow reqs;

    public CandidateHandoverFlow(FlowContext c, ReferenceFlow ref, RequisitionSyncFlow reqs) {
        this.c = c; this.ref = ref; this.reqs = reqs;
    }

    public void run() {
        c.report.section("Flow 2 – Candidate hand-over at selection");
        List<String> triggers = c.cfg.strings("flow2.triggerStatuses");
        for (JsonNode cand : c.candidates()) {
            String candId = Json.text(cand, "candidateId");
            String status = Json.text(cand, "selection.status");
            String appId = Json.text(cand, "selection.applicationId");
            if (status == null || !triggers.contains(status)) {
                c.report.add(F, "Selection check", candId, Status.SKIPPED,
                        "Status " + status + " – not selected, stays in DigiHire only");
                continue;
            }
            JsonNode app = c.state.get("applications", appId);
            if (app.isObject() && app.path("handedOver").asBoolean(false)) {
                c.report.add(F, "Selection check", candId, Status.INFO, "Application " + appId + " already handed over – nothing to send");
                continue;
            }
            try {
                handOver(cand, candId, appId);
            } catch (OracleException e) {
                c.fail(F, "Hand-over", candId, e);
            } catch (IOException e) {
                c.report.add(F, "Read resume file", candId, Status.FAIL, e.getMessage());
            } finally {
                c.state.save();
            }
        }
    }

    private void handOver(JsonNode cand, String candId, String appId) throws OracleException, IOException {
        String req = Json.text(cand, "selection.requisitionNumber");

        // 1. Files
        ObjectNode ctx = Json.obj();
        ObjectNode resume = resume(cand, candId);
        if (resume == null) return;
        ctx.set("resume", resume);
        byte[] summary = InterviewSummaryPdf.build(cand, c.cfg, c.templates);
        String summaryName = c.templates.render(Json.F.textNode(c.cfg.str("flow2.summaryFileName", "DigiHire_Interview_Summary_{{$.selection.requisitionNumber}}.pdf")), cand, Json.obj()).value.asText();
        Path summaryFile = c.outDir.resolve("summaries").resolve(appId + "_" + summaryName);
        Files.createDirectories(summaryFile.getParent());
        Files.write(summaryFile, summary);
        ObjectNode sum = ctx.putObject("summary");
        sum.put("fileName", summaryName);
        sum.put("contentType", "application/pdf");
        sum.put("base64", Base64.getEncoder().encodeToString(summary));
        c.report.add(F, "Interview summary PDF", candId, Status.PASS, summary.length / 1024 + " KB – " + c.outDir.relativize(summaryFile));

        // 2. Payload and mandatory check (Flow 0 rules)
        TemplateEngine.Result body = c.templates.render(c.cfg.mapping("candidateCreate"), cand, ctx);
        List<String> missing = new ArrayList<>(body.missing);
        missing.addAll(TemplateEngine.missingPaths(body.value, c.cfg.strings("mandatory.candidateCreate")));
        body.warnings.forEach(w -> c.report.add(F, "Mapping", candId, Status.WARN, w));
        c.savePayload(candId + "-candidate-create", body.value);
        if (!missing.isEmpty()) {
            ObjectNode s = c.state.entry("candidates", candId);
            s.put("status", "NEEDS_DATA");
            s.set("missingFields", Json.MAPPER.valueToTree(missing.stream().distinct().toList()));
            c.state.timeline(appId, "DIGIHIRE", "PENDING", "Needs data before hand-over: " + missing, null, null, null);
            c.report.add(F, "Mandatory check", candId, Status.NEEDS_DATA, "Nothing sent. Missing: " + missing.stream().distinct().toList());
            return;
        }
        c.report.add(F, "Mandatory check", candId, Status.PASS, "All mandatory values present");

        // 3. Requisition still open?
        if (c.cfg.bool("flow2.recheckRequisition", true)) {
            RequisitionSyncFlow.Validity v = reqs.liveCheck(req, false);
            if (!v.mappable()) {
                ObjectNode a = c.state.entry("applications", appId);
                a.put("candidateId", candId);
                a.put("requisitionNumber", req);
                a.put("trackingState", "HELD");
                c.state.timeline(appId, "DIGIHIRE", "PENDING", "Held: Requisition no longer open – " + v.reasons(), null, null, null);
                c.report.add(F, "Requisition still open", req, Status.HELD, "Requisition no longer open – nothing created in Oracle: " + v.reasons());
                return;
            }
            c.report.add(F, "Requisition still open", req, Status.PASS, "Open with openings left");
        }

        // 4. Look up first
        ObjectNode link = c.state.entry("candidates", candId);
        String candidateNumber = Json.text(link, "candidateNumber");
        String personId = Json.text(link, "personId");
        boolean existing = false;
        boolean adoptedEarlierCreate = false;
        if (candidateNumber != null) {
            OracleClient.Response r = c.oracle.call("candidateByNumber", FlowContext.p("candidateNumber", candidateNumber), null);
            if (r.items().isEmpty()) {
                markLinkRequired(link, appId, candId, "Stored candidate " + candidateNumber + " not found in Oracle");
                return;
            }
            personId = r.first().path("PersonId").asText(personId);
            existing = true;
            c.report.add(F, "Look up first", candId, Status.PASS, "Already in Oracle as candidate " + candidateNumber + " – reuse");
        } else if (link.path("inFlight").asBoolean(false) || c.cfg.bool("flow2.lookupByEmail", true)) {
            JsonNode found = lookupByEmail(Json.text(body.value, "Email"), candId);
            if (found != null) {
                boolean ours = link.path("inFlight").asBoolean(false);
                boolean nameMatch = same(Json.text(found, "FirstName"), Json.text(body.value, "FirstName"))
                        && same(Json.text(found, "LastName"), Json.text(body.value, "LastName"));
                if (ours || nameMatch) {
                    candidateNumber = found.path("CandidateNumber").asText();
                    personId = found.path("PersonId").asText();
                    existing = true;
                    adoptedEarlierCreate = ours;
                    link.put("candidateNumber", candidateNumber);
                    link.put("personId", personId);
                    link.remove("inFlight");
                    c.report.add(F, "Look up first", candId, Status.PASS, (ours ? "Earlier create had succeeded" : "Same email and name already in Oracle")
                            + " – linked to candidate " + candidateNumber + " (no duplicate)");
                } else {
                    markLinkRequired(link, appId, candId, "Email already used by Oracle candidate " + found.path("CandidateNumber").asText() + " with a different name");
                    return;
                }
            } else {
                c.report.add(F, "Look up first", candId, Status.PASS, "Not in Oracle yet");
            }
        }

        // 5. Write
        if (existing && adoptedEarlierCreate) {
            c.state.entry("applications", appId).put("summaryAttachmentId", "included-in-create");
        } else if (existing) {
            addSummary(cand, candId, appId, candidateNumber, ctx);
            if (c.options.dryRun()) return;
        } else {
            if (c.options.dryRun()) {
                c.report.add(F, "Create candidate", candId, Status.DRY_RUN, "Payload saved to payloads/" + candId + "-candidate-create.json – not sent");
                return;
            }
            link.put("inFlight", true);
            link.put("inFlightAt", OffsetDateTime.now().toString());
            c.state.save();
            try {
                OracleClient.Response r = c.oracle.call("candidateCreate", FlowContext.p(), body.value);
                candidateNumber = Json.text(r.json(), "CandidateNumber");
                personId = Json.text(r.json(), "PersonId");
                link.remove("inFlight");
                link.remove("inFlightAt");
                if (candidateNumber == null) {
                    link.put("inFlight", true);
                    c.report.add(F, "Create candidate", candId, Status.FAIL, "Oracle answered " + r.status() + " but no CandidateNumber – next run will look up by email");
                    return;
                }
                link.put("candidateNumber", candidateNumber);
                link.put("personId", personId);
                ArrayNode att = link.putArray("attachments");
                r.json().path("attachments").forEach(a -> att.addObject()
                        .put("fileName", a.path("UploadedFileName").asText())
                        .put("attachedDocumentId", a.path("AttachedDocumentId").asText()));
                c.report.add(F, "Create candidate", candId, Status.PASS,
                        "CandidateNumber " + candidateNumber + ", PersonId " + personId + " (" + r.ms() + " ms)");
            } catch (OracleException e) {
                if (e.kind() == OracleException.Kind.CLIENT && duplicate(e.getMessage())) {
                    link.remove("inFlight");
                    markLinkRequired(link, appId, candId, "Oracle says the email is already used: " + e.getMessage());
                    return;
                }
                if (e.kind() == OracleException.Kind.CLIENT || e.kind() == OracleException.Kind.FORBIDDEN) link.remove("inFlight");
                throw e;
            }
        }

        // 6. Store links, timeline, alert, lock
        OffsetDateTime now = OffsetDateTime.now();
        link.put("status", "HANDED_OVER");
        link.put("handedOverAt", now.toString());
        link.remove("missingFields");
        link.set("lockedFields", c.cfg.at("flow2.lockFields").deepCopy());
        ObjectNode a = c.state.entry("applications", appId);
        a.put("candidateId", candId);
        a.put("requisitionNumber", Json.text(cand, "selection.requisitionNumber"));
        a.put("email", Json.text(body.value, "Email"));
        a.put("candidateNumber", candidateNumber);
        a.put("personId", personId);
        a.put("handedOver", true);
        a.put("handedOverAt", now.toString());
        a.put("trackingState", "WAITING_FOR_APPLICATION");
        a.put("final", false);
        c.state.timeline(appId, "DIGIHIRE", "SYNCED", "Handed over to Oracle – candidate " + candidateNumber, null, null, null);
        String to = recruiterEmail(cand);
        if (to != null) a.put("recruiterEmail", to);
        c.state.alert(to, "Create Oracle job application",
                "Candidate " + candidateNumber + " (" + Json.text(cand, "fullName") + ") was selected in DigiHire for "
                        + Json.text(cand, "selection.requisitionNumber") + ". Please create the job application in Oracle.", appId);
        c.report.add(F, "Alert Oracle recruiter", candId, Status.PASS, "Alert queued for " + ReferenceFlow.mask(to == null ? "-" : to));
        c.report.add(F, "Lock profile fields", candId, Status.INFO, "Locked in DigiHire: " + c.cfg.strings("flow2.lockFields"));
    }

    private void addSummary(JsonNode cand, String candId, String appId, String candidateNumber, ObjectNode ctx) throws OracleException {
        ObjectNode a = c.state.entry("applications", appId);
        if (a.has("summaryAttachmentId")) {
            c.report.add(F, "Add interview summary", candId, Status.INFO, "Already attached for " + appId);
            return;
        }
        TemplateEngine.Result body = c.templates.render(c.cfg.mapping("interviewSummaryAttachment"), cand, ctx);
        c.savePayload(candId + "-" + appId + "-summary-attachment", body.value);
        if (c.options.dryRun()) {
            c.report.add(F, "Add interview summary", candId, Status.DRY_RUN, "Payload saved – not sent");
            return;
        }
        OracleClient.Response r = c.oracle.call("candidateAttachmentAdd", FlowContext.p("candidateNumber", candidateNumber), body.value);
        a.put("summaryAttachmentId", r.json().path("AttachedDocumentId").asText("added"));
        c.report.add(F, "Add interview summary", candId, Status.PASS, "Attached to existing candidate " + candidateNumber);
    }

    private JsonNode lookupByEmail(String email, String candId) throws OracleException {
        if (email == null) return null;
        try {
            OracleClient.Response r = c.oracle.call("candidateByEmail", FlowContext.p("email", email), null);
            return r.items().isEmpty() ? null : r.first();
        } catch (OracleException e) {
            if (e.kind() == OracleException.Kind.CLIENT) {
                c.report.add(F, "Look up first", candId, Status.WARN,
                        "Email look-up not allowed by Oracle (" + e.getMessage() + ") – relying on stored IDs; set flow2.lookupByEmail=false");
                return null;
            }
            throw e;
        }
    }

    private void markLinkRequired(ObjectNode link, String appId, String candId, String why) {
        link.put("status", "LINK_REQUIRED");
        link.put("lastError", why);
        c.state.timeline(appId, "DIGIHIRE", "FAILED", "Link required: " + why, null, null, null);
        c.state.alert(c.cfg.str("flow2.linkRequiredOwner", "link-required-queue"), "Link required", why + " (DigiHire candidate " + candId + ")", appId);
        c.report.add(F, "Duplicate check", candId, Status.LINK_REQUIRED, why);
    }

    private boolean duplicate(String msg) {
        String m = msg.toLowerCase(Locale.ROOT);
        for (String p : c.cfg.strings("flow2.duplicateEmailPatterns")) if (m.contains(p.toLowerCase(Locale.ROOT))) return true;
        return false;
    }

    private ObjectNode resume(JsonNode cand, String candId) throws IOException {
        JsonNode r = cand.path("resume");
        String fileName = r.path("fileName").asText(candId + "_resume.pdf");
        String ext = fileName.contains(".") ? fileName.substring(fileName.lastIndexOf('.') + 1).toLowerCase(Locale.ROOT) : "";
        if (!c.cfg.strings("flow2.attachments.allowedExtensions").contains(ext)) {
            c.report.add(F, "Resume file", candId, Status.NEEDS_DATA, "File type ." + ext + " not allowed " + c.cfg.strings("flow2.attachments.allowedExtensions"));
            return null;
        }
        byte[] bytes = null;
        String path = Json.text(r, "path");
        if (path != null) {
            Path p = c.dataDir.resolve(path).normalize();
            if (Files.exists(p)) bytes = Files.readAllBytes(p);
        }
        if (bytes == null) {
            if (!c.cfg.bool("flow2.attachments.generateResumeIfMissing", true)) {
                c.report.add(F, "Resume file", candId, Status.NEEDS_DATA, "Resume file not found: " + path);
                return null;
            }
            bytes = InterviewSummaryPdf.placeholderResume(cand);
            fileName = fileName.endsWith(".pdf") ? fileName : candId + "_resume.pdf";
            c.report.add(F, "Resume file", candId, Status.INFO, "No file at '" + path + "' – generated a placeholder test resume");
        }
        long maxBytes = c.cfg.integer("flow2.attachments.maxMb", 5) * 1024L * 1024L;
        if (bytes.length > maxBytes) {
            c.report.add(F, "Resume file", candId, Status.NEEDS_DATA, "Resume is " + bytes.length / 1024 + " KB – over the " + maxBytes / 1024 / 1024 + " MB limit");
            return null;
        }
        ObjectNode o = Json.obj();
        o.put("fileName", fileName);
        o.put("contentType", r.path("contentType").asText(contentType(fileName)));
        o.put("base64", Base64.getEncoder().encodeToString(bytes));
        return o;
    }

    private static String contentType(String name) {
        String n = name.toLowerCase(Locale.ROOT);
        if (n.endsWith(".pdf")) return "application/pdf";
        if (n.endsWith(".docx")) return "application/vnd.openxmlformats-officedocument.wordprocessingml.document";
        if (n.endsWith(".doc")) return "application/msword";
        return "application/octet-stream";
    }

    /** Oracle recruiter on the requisition (Flow 0), else the DigiHire recruiter email from the input. */
    String recruiterEmail(JsonNode cand) {
        String req = Json.text(cand, "selection.requisitionNumber");
        try {
            JsonNode team = ref.hiringTeam(req, false);
            String rid = team == null ? null : Json.text(team, "RecruiterId");
            if (rid != null && ref.exists("workerByPersonId", "personId", rid)) {
                String email = Json.text(c.state.get("refCache", "workerByPersonId:" + rid), "item.WorkEmail");
                if (email != null) return email;
            }
        } catch (OracleException ignored) {
            // fall back to the DigiHire value below
        }
        return Json.text(cand, "selection.recruiterEmail");
    }

    private static boolean same(String a, String b) { return a != null && b != null && a.trim().equalsIgnoreCase(b.trim()); }
}
