package com.ags.health.hr.integration.oracle.runner.flow;

import com.ags.health.hr.integration.oracle.runner.core.Json;
import com.ags.health.hr.integration.oracle.runner.core.RunnerConfig;
import com.ags.health.hr.integration.oracle.runner.core.TemplateEngine;
import com.ags.health.hr.integration.oracle.runner.http.CallLog;
import com.ags.health.hr.integration.oracle.runner.http.OracleClient;
import com.ags.health.hr.integration.oracle.runner.http.OracleException;
import com.ags.health.hr.integration.oracle.runner.state.RunReport;
import com.ags.health.hr.integration.oracle.runner.state.StateStore;
import com.fasterxml.jackson.databind.JsonNode;

import java.nio.file.Path;
import java.util.LinkedHashMap;
import java.util.Map;

/** Everything a flow needs. One instance per run. */
public final class FlowContext {

    public final RunnerConfig cfg;
    public final OracleClient oracle;
    public final StateStore state;
    public final RunReport report;
    public final TemplateEngine templates;
    public final CallLog callLog;
    public final JsonNode data;
    public final Path dataDir;
    public final Path outDir;
    public final Options options;

    /** Run options from the command line. */
    public record Options(boolean dryRun, boolean verbose, int polls, boolean fullPass, boolean reconcile) { }

    public FlowContext(RunnerConfig cfg, OracleClient oracle, StateStore state, RunReport report, CallLog callLog,
                       JsonNode data, Path dataDir, Path outDir, Options options) {
        this.cfg = cfg; this.oracle = oracle; this.state = state; this.report = report; this.callLog = callLog;
        this.templates = new TemplateEngine(cfg);
        this.data = data; this.dataDir = dataDir; this.outDir = outDir; this.options = options;
    }

    public static Map<String, String> p(String... kv) {
        Map<String, String> m = new LinkedHashMap<>();
        for (int i = 0; i + 1 < kv.length; i += 2) if (kv[i + 1] != null) m.put(kv[i], kv[i + 1]);
        return m;
    }

    /** Saves a masked copy of a request body for review (payloads/NAME.json). */
    public void savePayload(String name, JsonNode body) {
        Json.writeFile(outDir.resolve("payloads").resolve(name.replaceAll("[^A-Za-z0-9._-]", "_") + ".json"), callLog.mask(body));
    }

    /** Thrown to stop the whole run after a 401. */
    public static final class AuthStop extends RuntimeException {
        public AuthStop(OracleException e) { super(e.getMessage(), e); }
    }

    /** Converts an Oracle failure into a report line; 401 stops the run. Returns the report status used. */
    public RunReport.Status fail(String flow, String step, String item, OracleException e) {
        switch (e.kind()) {
            case AUTH -> {
                report.add(flow, step, item, RunReport.Status.AUTH_STOP, "Login refused – all Oracle jobs stopped: " + e.getMessage());
                throw new AuthStop(e);
            }
            case FORBIDDEN -> {
                report.add(flow, step, item, RunReport.Status.FAIL,
                        "403 – operation '" + e.operation() + "' not allowed for this user (ask AGS to enable it): " + e.getMessage());
                return RunReport.Status.FAIL;
            }
            default -> {
                report.add(flow, step, item, RunReport.Status.FAIL, e.kind() + " – " + e.getMessage());
                return RunReport.Status.FAIL;
            }
        }
    }

    /** UniqID = last path segment of the "self" link. */
    public static String selfUniqId(JsonNode item) {
        for (JsonNode l : item.path("links")) {
            if ("self".equals(l.path("rel").asText())) {
                String href = l.path("href").asText();
                return href.substring(href.lastIndexOf('/') + 1);
            }
        }
        return null;
    }

    public JsonNode candidates() { return data.path("candidates"); }
}
