package com.ags.health.hr.integration.oracle.runner.http;

import com.ags.health.hr.integration.oracle.runner.core.Json;
import com.ags.health.hr.integration.oracle.runner.core.RunnerConfig;
import com.fasterxml.jackson.databind.JsonNode;

import java.io.IOException;
import java.net.ProxySelector;
import java.net.URI;
import java.net.URLEncoder;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.net.http.HttpTimeoutException;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * The one Oracle HTTP caller. Every request is described by an operation in config.operations:
 * <pre>
 * "getRequisitionByNumber": {
 *   "method": "GET", "path": "/recruitingJobRequisitions",
 *   "query": { "finder": "findByRequisitionNumber;RequisitionNumber={requisitionNumber}", "onlyData": "true" },
 *   "timeoutSeconds": 3, "retry": false
 * }
 * </pre>
 * {name} placeholders are filled from the params map. A query parameter whose placeholder has no value is left out.
 * Retries 429/5xx/timeouts with the configured delays; 401 stops; 403 parks the operation.
 */
public final class OracleClient {

    private static final Pattern PH = Pattern.compile("\\{([A-Za-z0-9_]+)}");

    private final RunnerConfig cfg;
    private final Auth auth;
    private final CallLog log;
    private final HttpClient http;
    private final boolean verbose;

    public record Response(int status, JsonNode json, String raw, long ms, String url) {
        public JsonNode items() { return json.path("items"); }
        public boolean hasMore() { return json.path("hasMore").asBoolean(false); }
        public JsonNode first() { return items().path(0); }
    }

    public OracleClient(RunnerConfig cfg, Auth auth, CallLog log, HttpClient http, boolean verbose) {
        this.cfg = cfg; this.auth = auth; this.log = log; this.http = http; this.verbose = verbose;
    }

    public static HttpClient httpClient(RunnerConfig cfg) {
        return HttpClient.newBuilder()
                .connectTimeout(Duration.ofSeconds(cfg.integer("http.connectTimeoutSeconds", 10)))
                .followRedirects(HttpClient.Redirect.NORMAL)
                .proxy(ProxySelector.getDefault())
                .build();
    }

    public Auth auth() { return auth; }

    public Response call(String op, Map<String, String> params, JsonNode body) throws OracleException {
        return call(op, params, body, null);
    }

    public Response call(String op, Map<String, String> params, JsonNode body, JsonNode resolved) throws OracleException {
        JsonNode def = cfg.operation(op);
        String method = def.path("method").asText("GET").toUpperCase();
        String url = buildUrl(def, params == null ? Map.of() : params);
        int timeout = def.path("timeoutSeconds").asInt(cfg.integer("http.readTimeoutSeconds", 30));
        boolean retry = def.path("retry").asBoolean(true);
        List<Integer> delays = cfg.ints("http.retryDelaysSeconds");
        int maxAttempts = retry ? delays.size() + 1 : 1;
        boolean reauthed = false;

        for (int attempt = 1; ; attempt++) {
            long start = System.nanoTime();
            String authHeader = auth.header();
            HttpRequest.Builder rb = HttpRequest.newBuilder(URI.create(url))
                    .timeout(Duration.ofSeconds(timeout))
                    .header("Authorization", authHeader)
                    .header("Accept", "application/json")
                    .header("REST-Framework-Version", cfg.str("oracle.restFrameworkVersion", "4"));
            String ct = def.path("contentType").asText(cfg.str("oracle.contentTypes." + method, "application/json"));
            HttpRequest.BodyPublisher pub = body == null ? HttpRequest.BodyPublishers.noBody()
                    : HttpRequest.BodyPublishers.ofString(Json.compact(body), StandardCharsets.UTF_8);
            if (body != null) rb.header("Content-Type", ct);
            rb.method(method, pub);

            int status = 0;
            String raw = null;
            OracleException failure;
            try {
                HttpResponse<String> r = http.send(rb.build(), HttpResponse.BodyHandlers.ofString(StandardCharsets.UTF_8));
                status = r.statusCode();
                raw = r.body();
                long ms = (System.nanoTime() - start) / 1_000_000;
                if (status / 100 == 2) {
                    log.write(op, method, url, attempt, status, ms, body, raw, null, resolved);
                    if (verbose) System.out.printf("    %s %s -> %d (%d ms)%n", method, log.maskUrl(url), status, ms);
                    return new Response(status, raw == null || raw.isBlank() ? Json.obj() : Json.parse(raw), raw, ms, url);
                }
                String msg = OracleException.messageFrom(raw);
                log.write(op, method, url, attempt, status, ms, body, raw, msg, resolved);
                if (verbose) System.out.printf("    %s %s -> %d %s%n", method, log.maskUrl(url), status, msg);
                OracleException.Kind kind = OracleException.classify(status);
                if (kind == OracleException.Kind.AUTH && "TOKEN".equals(auth.mode()) && !reauthed) {
                    auth.invalidate();
                    reauthed = true;
                    attempt--;
                    continue;
                }
                failure = new OracleException(kind, status, op, "HTTP " + status + ": " + msg);
            } catch (HttpTimeoutException e) {
                long ms = (System.nanoTime() - start) / 1_000_000;
                log.write(op, method, url, attempt, 0, ms, body, null, "timeout after " + timeout + " s", resolved);
                failure = new OracleException(OracleException.Kind.TIMEOUT, 0, op, "No answer within " + timeout + " s");
            } catch (IOException e) {
                long ms = (System.nanoTime() - start) / 1_000_000;
                log.write(op, method, url, attempt, 0, ms, body, null, "io: " + e.getMessage(), resolved);
                failure = new OracleException(OracleException.Kind.RETRYABLE, 0, op, "Connection problem: " + e);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                throw new OracleException(OracleException.Kind.RETRYABLE, 0, op, "Interrupted");
            }

            boolean retryable = failure.kind() == OracleException.Kind.RETRYABLE || failure.kind() == OracleException.Kind.TIMEOUT;
            if (!retryable || attempt >= maxAttempts) throw failure;
            int delay = delays.get(attempt - 1);
            if (verbose) System.out.printf("    retry %d/%d in %d s (%s)%n", attempt, maxAttempts - 1, delay, failure.getMessage());
            sleep(delay);
        }
    }

    String buildUrl(JsonNode def, Map<String, String> params) {
        String path = def.path("path").asText();
        String filled = fill(path, params, true);
        if (filled == null) throw new IllegalArgumentException("Missing path parameter for " + path + " params=" + params.keySet());
        String base = filled.startsWith("http") ? filled : trimSlash(cfg.baseUrl()) + cfg.restPath() + filled;

        StringBuilder q = new StringBuilder();
        Map<String, String> query = new LinkedHashMap<>();
        Iterator<Map.Entry<String, JsonNode>> it = def.path("query").fields();
        while (it.hasNext()) {
            Map.Entry<String, JsonNode> e = it.next();
            String v = fill(e.getValue().asText(), params, false);
            if (v != null && !v.isEmpty()) query.put(e.getKey(), v);
        }
        for (Map.Entry<String, String> e : query.entrySet()) {
            q.append(q.length() == 0 ? "?" : "&").append(e.getKey()).append('=').append(encodeQuery(e.getValue()));
        }
        return base + q;
    }

    /** Replaces {name}; returns null when a placeholder has no value. */
    private static String fill(String template, Map<String, String> params, boolean pathEncode) {
        Matcher m = PH.matcher(template);
        StringBuilder sb = new StringBuilder();
        while (m.find()) {
            String v = params.get(m.group(1));
            if (v == null) return null;
            String enc = pathEncode ? URLEncoder.encode(v, StandardCharsets.UTF_8).replace("+", "%20") : v;
            m.appendReplacement(sb, Matcher.quoteReplacement(enc));
        }
        m.appendTail(sb);
        return sb.toString();
    }

    private String encodeQuery(String v) {
        if ("full".equalsIgnoreCase(cfg.str("oracle.queryEncoding", "minimal"))) {
            return URLEncoder.encode(v, StandardCharsets.UTF_8).replace("+", "%20");
        }
        StringBuilder sb = new StringBuilder();
        for (char c : v.toCharArray()) {
            switch (c) {
                case ' ' -> sb.append("%20");
                case '\'' -> sb.append("%27");
                case '>' -> sb.append("%3E");
                case '<' -> sb.append("%3C");
                case '@' -> sb.append("%40");
                case '+' -> sb.append("%2B");
                case '#' -> sb.append("%23");
                case '&' -> sb.append("%26");
                case '"' -> sb.append("%22");
                case '%' -> sb.append("%25");
                default -> {
                    if (c > 127) sb.append(URLEncoder.encode(String.valueOf(c), StandardCharsets.UTF_8));
                    else sb.append(c);
                }
            }
        }
        return sb.toString();
    }

    private static String trimSlash(String s) { return s.endsWith("/") ? s.substring(0, s.length() - 1) : s; }

    private static void sleep(int seconds) {
        try {
            Thread.sleep(seconds * 1000L);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }
}
