#!/usr/bin/env bash
# Builds target/orc-flow-runner.jar without Maven, using local Jackson jars.
# Normal build:  mvn -q package   (needs Maven Central; produces the same shaded jar)
# This script:   JACKSON_DIR=/path/to/jackson/jars ./build.sh
set -euo pipefail
cd "$(dirname "$0")"
JACKSON_DIR="${JACKSON_DIR:-$HOME/.m2/repository/com/fasterxml/jackson/core}"
CP=$(find "$JACKSON_DIR" -name 'jackson-*2.1[0-9]*.jar' \( -name 'jackson-core-*' -o -name 'jackson-databind-*' -o -name 'jackson-annotations-*' \) | grep -v sources | tr '\n' ':')
[ -z "$CP" ] && { echo "Jackson jars not found under $JACKSON_DIR"; exit 1; }
rm -rf target/classes target/fat && mkdir -p target/classes target/fat
javac --release 17 -Xlint:deprecation -encoding UTF-8 -cp "$CP" -d target/classes $(find src/main/java -name '*.java')
cp -r src/main/resources/* target/classes/
for j in ${CP//:/ }; do (cd target/fat && unzip -qo "$j" -x 'META-INF/*.SF' 'META-INF/*.DSA' 'META-INF/*.RSA' 'module-info.class' 'META-INF/MANIFEST.MF'); done
cp -r target/classes/* target/fat/
printf 'Main-Class: com.ags.health.hr.integration.oracle.runner.OrcFlowRunner\nImplementation-Version: 1.1.0\n' > target/manifest.txt
jar cfm target/orc-flow-runner.jar target/manifest.txt -C target/fat .
echo "Built target/orc-flow-runner.jar"
