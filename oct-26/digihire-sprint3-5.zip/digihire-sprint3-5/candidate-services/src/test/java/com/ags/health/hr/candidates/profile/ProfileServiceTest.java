package com.ags.health.hr.candidates.profile;

import com.ags.health.hr.candidates.profile.domain.FieldCatalog;
import com.ags.health.hr.candidates.profile.domain.ProfileStage;
import com.ags.health.hr.candidates.profile.domain.ProfileValidator;
import com.ags.health.hr.candidates.profile.domain.RegistrationStatus;
import com.ags.health.hr.candidates.profile.domain.StageEditPolicy;
import com.ags.health.hr.candidates.profile.port.ProfilePort;
import com.ags.health.hr.candidates.profile.service.ProfileDocument;
import com.ags.health.hr.candidates.profile.service.ProfileDocumentBuilder;
import com.ags.health.hr.candidates.profile.service.ProfileService;
import com.ags.health.hr.candidates.profile.store.ProfileChangeStore;
import com.ags.health.hr.candidates.shared.domain.Statuses;
import com.ags.health.hr.candidates.shared.port.StatusChange;
import com.ags.health.hr.candidates.shared.service.CandidateGuard;
import com.ags.health.hr.candidates.support.Fakes;
import com.ags.health.hr.candidates.support.Sprint3Fixture;
import com.ags.health.hr.common.platform.caller.Caller;
import com.ags.health.hr.common.platform.error.PlatformException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.time.ZoneId;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

class ProfileServiceTest {

    private final Sprint3Fixture f = new Sprint3Fixture();
    private final FieldCatalog catalog = FieldCatalog.standard(2026);
    private final Map<String, Map<String, Object>> store = new HashMap<>();
    private final StringBuilder rendered = new StringBuilder();
    private ProfileService service;

    @BeforeEach
    void setUp() {
        ProfilePort port = new ProfilePort() {
            @Override
            public Optional<Map<String, Object>> load(String id) {
                return Optional.ofNullable(store.get(id));
            }

            @Override
            public void apply(String id, Map<String, Object> changes, StatusChange actor) {
                store.computeIfAbsent(id, k -> new LinkedHashMap<>()).putAll(changes);
            }

            @Override
            public Optional<String> candidateIdByEmailOrMobile(String email, String mobile) {
                return store.entrySet().stream().filter(e -> (email != null && email.equals(e.getValue().get("email")))
                        || (mobile != null && mobile.equals(e.getValue().get("mobile")))).map(Map.Entry::getKey).findFirst();
            }
        };
        service = new ProfileService(catalog, new ProfileValidator(catalog, 18, 60), new StageEditPolicy(f.catalog), port, f.apps,
                new CandidateGuard(f.candidates, f.candidates), new ProfileChangeStore(f.db.jdbc),
                new ProfileDocumentBuilder(catalog, ZoneId.of("Asia/Kolkata")), doc -> {
                    doc.sections().forEach(s -> s.lines().forEach(l -> rendered.append(l.label()).append('=').append(l.value()).append('\n')));
                    return new byte[]{1};
                }, f.audit, f.clock);
        f.candidates.add("C1", true, null);
        Map<String, Object> base = new LinkedHashMap<>();
        base.put("firstName", "Asha");
        base.put("lastName", "Kumar");
        base.put("dateOfBirth", "1998-02-01");
        base.put("gender", "FEMALE");
        base.put("email", "asha@mail.com");
        base.put("mobile", "9876543210");
        base.put("addressLine1", "12 Main Road");
        base.put("city", "Chennai");
        base.put("state", "Tamil Nadu");
        base.put("pincode", "600001");
        base.put("highestQualification", "UG");
        base.put("yearOfPassing", 2020L);
        base.put("experienceType", "FRESHER");
        base.put("panNumber", "ABCDE1234F");
        store.put("C1", base);
    }

    @Test
    void candidateUpdatesOwnProfileBeforeApplying() {
        Caller self = Fakes.candidate("U-C1");
        ProfileService.UpdateResult r = service.update(self, "C1", Map.of("lastName", "Kumari", "alternateMobile", "9123456780"), null);
        assertThat(r.changed()).containsExactlyInAnyOrder("lastName", "alternateMobile");
        assertThat(r.registration().complete()).isTrue();
        assertThat(service.history(Fakes.recruiter("r", "CANDIDATE:VIEW"), "C1", 10)).hasSize(2);
    }

    @Test
    void identityFieldsLockOnceAnApplicationExists() {
        f.apps.add("A1", "C1", "R1", Statuses.CREATED, "rec1", null, null, null);
        Caller self = Fakes.candidate("U-C1");
        assertThatThrownBy(() -> service.update(self, "C1", Map.of("lastName", "X"), null))
                .isInstanceOf(PlatformException.class)
                .satisfies(e -> assertThat(((PlatformException) e).getDetails().toString()).contains("FIELD_LOCKED"));
        assertThat(service.update(self, "C1", Map.of("city", "Madurai"), null).changed()).containsExactly("city");
        Caller admin = Fakes.recruiter("adm", "CANDIDATE:UPDATE", "CANDIDATE:UPDATE_LOCKED");
        assertThatThrownBy(() -> service.update(admin, "C1", Map.of("lastName", "X"), null)).isInstanceOf(PlatformException.class);
        assertThat(service.update(admin, "C1", Map.of("lastName", "Kumaran"), "Court order").overrideUsed()).isTrue();
        assertThat(f.db.auditRows("PROFILE_UPDATED_WITH_OVERRIDE")).hasSize(1);
        assertThat(service.fields(self, "C1").stage()).isEqualTo(ProfileStage.APPLICANT);
    }

    @Test
    void invalidIdentityAndContactDataIsRejected() {
        Caller self = Fakes.candidate("U-C1");
        store.put("C2", new LinkedHashMap<>(Map.of("email", "taken@mail.com")));
        assertThatThrownBy(() -> service.update(self, "C1", Map.of("panNumber", "ABC", "pincode", "12", "dateOfBirth", "2015-01-01",
                "email", "taken@mail.com", "unknown", "x"), null))
                .satisfies(e -> assertThat(((PlatformException) e).getDetails().toString())
                        .contains("INVALID_PAN", "INVALID_PINCODE", "UNKNOWN_FIELD", "DUPLICATE"));
    }

    @Test
    void completenessReportsMissingRegistrationFields() {
        store.get("C1").remove("pincode");
        RegistrationStatus s = service.completeness(Fakes.candidate("U-C1"), "C1");
        assertThat(s.complete()).isFalse();
        assertThat(s.missing()).extracting("field").containsExactly("pincode");
        assertThatThrownBy(() -> service.requireRegistered("C1")).hasMessageContaining("registration");
    }

    @Test
    void pdfExportMasksSensitiveValuesForStaff() {
        service.exportPdf(Fakes.recruiter("rec", "CANDIDATE:EXPORT"), "C1");
        assertThat(rendered.toString()).contains("PAN=******234F").doesNotContain("ABCDE1234F").contains("Email=as**@mail.com");
        assertThat(f.db.auditRows("PROFILE_EXPORTED")).hasSize(1);
        ProfileDocument d = new ProfileDocumentBuilder(catalog, ZoneId.of("Asia/Kolkata")).build("C1", store.get("C1"), "x", Fakes.NOW, true);
        assertThat(d.watermark()).startsWith("CONFIDENTIAL");
    }

    @Test
    void staffOutsideScopeCanNotRead() {
        f.candidates.inScope = false;
        assertThatThrownBy(() -> service.completeness(Fakes.recruiter("rec", "CANDIDATE:VIEW"), "C1"))
                .hasMessageContaining("scope");
    }
}
