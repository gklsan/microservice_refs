package com.ags.health.hr.candidates.assessmentbridge;

import com.ags.health.hr.candidates.shared.domain.Statuses;
import com.ags.health.hr.candidates.support.Fakes;
import com.ags.health.hr.candidates.support.Sprint3Fixture;
import com.ags.health.hr.common.platform.error.PlatformException;
import com.ags.health.hr.common.platform.notify.NotificationRequest;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

class AssessmentInboxTest {

    private final Sprint3Fixture f = new Sprint3Fixture();
    private final AssessmentExceptionStore exceptions = new AssessmentExceptionStore(f.db.jdbc);
    private final AssessmentOutcomeHandler handler = new AssessmentOutcomeHandler(f.apps, f.mover, f.policy, f.catalog,
            new NextStageRouting(List.of("VOICE_FRESHER"), List.of(), true), exceptions, f.clock);
    private final AssessmentEventInbox inbox = new AssessmentEventInbox(new InboxStore(f.db.jdbc), List.of(handler), f.db.tx,
            f.audit, Fakes.clock());
    private final ObjectMapper mapper = new ObjectMapper();

    private AssessmentEvent event(String type, String app, String provider) {
        ObjectNode p = mapper.createObjectNode().put("provider", provider).put("attemptId", "AT-" + app).put("assessmentCode", "X");
        return new AssessmentEvent(1, UUID.randomUUID(), type, "ASSESSMENT_ATTEMPT", "AT-" + app, "C1", app, p, Fakes.NOW, null, 0);
    }

    @Test
    void completedShlAdvancesToVersantForVoiceRolesAndDuplicatesAreIgnored() {
        f.apps.add("A1", "C1", "R1", Statuses.ASSESEMENT_INPROGRESS, "rec1", "LOB1", "CHENNAI", "VOICE_FRESHER");
        AssessmentEvent e = event("ASSESSMENT_COMPLETED", "A1", "SHL");
        AssessmentEventInbox.Summary s = inbox.accept(List.of(e, e));
        assertThat(s.processed()).isEqualTo(1);
        assertThat(s.duplicates()).isEqualTo(1);
        assertThat(f.apps.find("A1").orElseThrow().status()).isEqualTo(Statuses.VERSANT_YET_TO_START);
    }

    @Test
    void versantNotTakenOpensAnExceptionAndRescheduleResolvesIt() {
        f.apps.add("A1", "C1", "R1", Statuses.VERSANT_INPROGRESS, "rec1", "LOB1", "CHENNAI", "VOICE_FRESHER");
        inbox.accept(List.of(event("ASSESSMENT_NOT_TAKEN", "A1", "VERSANT")));
        assertThat(f.apps.find("A1").orElseThrow().status()).isEqualTo(Statuses.VERSANT_NOT_TAKEN);
        assertThat(exceptions.list("VERSANT", "OPEN", 10)).hasSize(1);
        inbox.accept(List.of(event("ASSESSMENT_RESCHEDULED", "A1", "VERSANT")));
        assertThat(f.apps.find("A1").orElseThrow().status()).isEqualTo(Statuses.VERSANT_YET_TO_START);
        assertThat(exceptions.list("VERSANT", "OPEN", 10)).isEmpty();
    }

    @Test
    void expiredScoreMovesInProcessCandidatesToFresherPipeline() {
        f.apps.add("A1", "C1", "R1", Statuses.PANEL_YET_TO_SCHEDULE, "rec1", "LOB1", "CHENNAI", "ROLE1");
        f.apps.add("A2", "C1", "R1", Statuses.OFFERED, "rec1", "LOB1", "CHENNAI", "ROLE1");
        inbox.accept(List.of(event("ASSESSMENT_SCORE_EXPIRED", "A1", "SHL"), event("ASSESSMENT_SCORE_EXPIRED", "A2", "SHL")));
        assertThat(f.apps.find("A1").orElseThrow().status()).isEqualTo(Statuses.PIPELINE);
        assertThat(f.apps.log).anyMatch(l -> l.contains("FRESHER_PIPELINE"));
        assertThat(f.apps.find("A2").orElseThrow().status()).isEqualTo(Statuses.OFFERED);
    }

    @Test
    void failuresAreNotRecordedSoTheBatchCanBeResent() {
        f.apps.add("A1", "C1", "R1", Statuses.ASSESEMENT_INPROGRESS, "rec1", "LOB1", "CHENNAI", "ROLE1");
        AssessmentEventInbox broken = new AssessmentEventInbox(new InboxStore(f.db.jdbc), List.of(new AssessmentEventHandler() {
            @Override
            public boolean supports(AssessmentEvent event) {
                return true;
            }

            @Override
            public String handle(AssessmentEvent event) {
                throw new IllegalStateException("db down");
            }
        }), f.db.tx, f.audit, Fakes.clock());
        AssessmentEvent e = event("ASSESSMENT_COMPLETED", "A1", "SHL");
        assertThatThrownBy(() -> broken.accept(List.of(e))).isInstanceOf(PlatformException.class);
        assertThat(inbox.accept(List.of(e)).processed()).isEqualTo(1);
    }

    @Test
    void outboxRelayDeliversApplicationEventsAndNotificationsOnlyWhenADeliveryExists() {
        f.candidates.add("C1", true, "rec1");
        f.apps.add("A1", "C1", "R1", Statuses.CREATED, "rec1", "LOB1", "CHENNAI", "ROLE1");
        f.mover.move(Fakes.recruiter("rec1", "APPLICATION:MOVE_STAGE"),
                com.ags.health.hr.candidates.shared.service.StatusMover.Move.to("A1", Statuses.WAITING_FOR_HRROUND, "APPLICATION:MOVE_STAGE"));
        new OutboxNotificationPort(f.outbox).trigger(new NotificationRequest("WALK_IN_INVITE", "A1", "C1", "k1", Map.of("venue", "HQ")));
        List<NotificationRequest> delivered = new ArrayList<>();
        OutboxRelay without = new OutboxRelay(f.outbox, List.of(new AssessmentEventDispatcher(f.assessments, mapper),
                new NotificationDispatcher(null, mapper)), 50);
        assertThat(without.relay().delivered()).isEqualTo(1);
        assertThat(f.assessments.events).hasSize(1);
        assertThat(f.assessments.events.get(0)).containsEntry("eventType", "STAGE_CHANGED").containsEntry("stage", "WAITING_FOR_HRROUND");
        OutboxRelay with = new OutboxRelay(f.outbox, List.of(new NotificationDispatcher(delivered::add, mapper)), 50);
        assertThat(with.relay().delivered()).isEqualTo(1);
        assertThat(delivered.get(0).context()).containsEntry("venue", "HQ");
    }
}
