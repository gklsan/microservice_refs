package com.ags.health.hr.candidates.support;

import com.ags.health.hr.candidates.assessmentbridge.ApplicationEventRelay;
import com.ags.health.hr.candidates.mapping.domain.MappingScenarioResolver;
import com.ags.health.hr.candidates.mapping.domain.RemapPlanner;
import com.ags.health.hr.candidates.mapping.port.LinkOnlyMeetingPort;
import com.ags.health.hr.candidates.mapping.service.ApplicantActionService;
import com.ags.health.hr.candidates.mapping.service.MappingService;
import com.ags.health.hr.candidates.mapping.service.RejectionReasonService;
import com.ags.health.hr.candidates.mapping.service.SchedulingService;
import com.ags.health.hr.candidates.mapping.store.InterviewSlotStore;
import com.ags.health.hr.candidates.mapping.store.MappingActionStore;
import com.ags.health.hr.candidates.mapping.store.RejectionReasonStore;
import com.ags.health.hr.candidates.shared.domain.StageCatalog;
import com.ags.health.hr.candidates.shared.domain.TabMovementPolicy;
import com.ags.health.hr.candidates.shared.service.ApplicantActionGuard;
import com.ags.health.hr.candidates.shared.service.StatusMover;
import com.ags.health.hr.common.platform.audit.AuditRecorder;
import com.ags.health.hr.common.platform.outbox.OutboxStore;
import com.ags.health.hr.common.platform.time.BusinessClock;

import java.time.ZoneId;
import java.util.List;
import java.util.Set;

public class Sprint3Fixture {

    public final P5TestDb db = P5TestDb.candidate();
    public final Fakes.Applications apps = new Fakes.Applications();
    public final Fakes.Candidates candidates = new Fakes.Candidates();
    public final Fakes.Requisitions reqs = new Fakes.Requisitions();
    public final Fakes.Assessments assessments = new Fakes.Assessments();
    public final Fakes.Notifications notifications = new Fakes.Notifications();
    public final Fakes.Callers callers = new Fakes.Callers(null);
    public final StageCatalog catalog = StageCatalog.standard();
    public final TabMovementPolicy policy = new TabMovementPolicy(catalog, null);
    public final AuditRecorder audit = db.audit(callers, Fakes.clock());
    public final BusinessClock clock = new BusinessClock(Fakes.clock(), ZoneId.of("Asia/Kolkata"));
    public final OutboxStore outbox = new OutboxStore(db.jdbc, db.mapper, Fakes.clock(), "cand_p5_outbox",
            new OutboxStore.Policy(5, 30, 600));
    public final ApplicantActionGuard guard = new ApplicantActionGuard(false);
    public final List<com.ags.health.hr.candidates.shared.service.MoveGuard> moveGuards = new java.util.ArrayList<>();
    public final StatusMover mover = new StatusMover(apps, guard, null, policy, catalog, audit, notifications,
            List.of(new ApplicationEventRelay(outbox, candidates, catalog)), Fakes.clock(),
            Set.of("REMAP", "REPROCESS", "RESCHEDULED", "FRESHER_PIPELINE", "OFFER_REJECTED", "ORC_CHANGE"), moveGuards);
    public final MappingActionStore actions = new MappingActionStore(db.jdbc, db.mapper);
    public final RejectionReasonService reasons = new RejectionReasonService(new RejectionReasonStore(db.jdbc), audit, Fakes.clock());
    public boolean registered = true;

    public MappingService mapping() {
        return new MappingService(candidates, apps, reqs, assessments, List.of(), id -> {
            if (!registered) {
                throw com.ags.health.hr.common.platform.error.PlatformException.unprocessable("REGISTRATION_INCOMPLETE", "x", List.of());
            }
        }, new MappingScenarioResolver(catalog), actions, mover, audit, notifications, clock,
                new MappingService.Settings(true, false, "APPLICATION_ON_HOLD", "REGISTRATION_INVITE"));
    }

    public ApplicantActionService applicant(ApplicantActionService.RemapMode mode) {
        return new ApplicantActionService(mover, guard, apps, reqs, assessments, new RemapPlanner(catalog), reasons, actions, catalog,
                audit, clock, new ApplicantActionService.Settings("HR_REJECTED", mode, "APPLICATION_REJECTED", "APPLICATION_ON_HOLD"));
    }

    public SchedulingService scheduling() {
        return new SchedulingService(new InterviewSlotStore(db.jdbc), mover, guard, candidates,
                new LinkOnlyMeetingPort("https://meet.example/x"), actions, catalog, audit, notifications, clock,
                new SchedulingService.Settings("WALK_IN_INVITE", "ONLINE_INTERVIEW_SCHEDULED", "INTERVIEW_CANCELLED", 60, true, 500));
    }
}
