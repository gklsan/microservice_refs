package com.ags.health.hr.candidates.idproof;

import com.ags.health.hr.candidates.idproof.domain.VerificationBadge;
import com.ags.health.hr.candidates.idproof.port.IdentityVerificationPort;
import com.ags.health.hr.candidates.idproof.service.IdProofService;
import com.ags.health.hr.candidates.idproof.service.IdVerificationDispatcher;
import com.ags.health.hr.candidates.idproof.store.IdDocumentStore;
import com.ags.health.hr.candidates.shared.service.CandidateGuard;
import com.ags.health.hr.candidates.support.Fakes;
import com.ags.health.hr.candidates.support.Sprint3Fixture;
import com.ags.health.hr.common.platform.caller.Caller;
import com.ags.health.hr.common.platform.crypto.IdentifierHasher;
import com.ags.health.hr.common.platform.error.PlatformException;
import com.ags.health.hr.common.platform.outbox.OutboxEvent;
import com.ags.health.hr.common.platform.storage.EnvelopeEncryptingDocumentStore;
import com.ags.health.hr.common.platform.storage.InMemoryDocumentStore;
import com.ags.health.hr.common.platform.storage.StaticKeyEncryptionKeyProvider;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.nio.charset.StandardCharsets;
import java.util.Base64;
import java.util.List;
import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

class IdProofServiceTest {

    private static final byte[] PDF = "%PDF-1.7\n1 0 obj << /Type /Catalog >> endobj\n%%EOF".getBytes(StandardCharsets.ISO_8859_1);

    private final Sprint3Fixture f = new Sprint3Fixture();
    private final InMemoryDocumentStore raw = new InMemoryDocumentStore();
    private String providerStatus = "VERIFIED";
    private boolean providerDown;
    private IdProofService service;

    @BeforeEach
    void setUp() {
        String key = Base64.getEncoder().encodeToString(new byte[32]);
        EnvelopeEncryptingDocumentStore secure = new EnvelopeEncryptingDocumentStore(raw, new StaticKeyEncryptionKeyProvider("k1:" + key, "k1"));
        IdentityVerificationPort verifier = r -> providerDown
                ? new IdentityVerificationPort.Result("ERROR", null, null, null, "down", true)
                : new IdentityVerificationPort.Result(providerStatus, "STUB", "REF-1", 0.97, "ok", false);
        service = new IdProofService(new IdDocumentStore(f.db.jdbc), secure, new IdentifierHasher("pepper-for-tests-123"), verifier,
                id -> Optional.empty(), new CandidateGuard(f.candidates, f.candidates), f.outbox, f.audit, Fakes.clock(),
                new IdProofService.Settings(1024 * 1024, true));
        f.candidates.add("C1", true, null);
        f.candidates.add("C2", true, null);
    }

    private void relay() {
        IdVerificationDispatcher d = new IdVerificationDispatcher(service);
        for (OutboxEvent e : f.outbox.due(50, List.of(IdProofService.VERIFY_EVENT))) {
            try {
                d.deliver(e);
                f.outbox.markPublished(List.of(e));
            } catch (RuntimeException ex) {
                f.outbox.markFailed(List.of(e), ex.getMessage());
            }
        }
    }

    @Test
    void uploadEncryptsMasksAndVerifiesThroughTheOutbox() {
        IdProofService.DocumentView v = service.upload(Fakes.candidate("U-C1"), "C1", "pan", "abcpe1234f", PDF, "pan.pdf");
        assertThat(v.numberMasked()).isEqualTo("******234F");
        assertThat(v.status()).isEqualTo("VERIFYING");
        assertThat(new String(raw.get("p5/id-docs/C1/" + v.id()).orElseThrow(), StandardCharsets.ISO_8859_1)).doesNotContain("%PDF");
        relay();
        assertThat(service.badge("C1")).isEqualTo(VerificationBadge.VERIFIED);
        assertThat(f.db.auditRows("ID_DOCUMENT_VERIFICATION_RESULT")).hasSize(1);
    }

    @Test
    void outageKeepsTheDocumentVerifyingForRetry() {
        providerDown = true;
        service.upload(Fakes.candidate("U-C1"), "C1", "AADHAAR", "234123412346", PDF, "a.pdf");
        relay();
        assertThat(service.badge("C1")).isEqualTo(VerificationBadge.PENDING);
        assertThat(f.outbox.stats().pending()).isEqualTo(1);
    }

    @Test
    void sameNumberOnAnotherCandidateGoesToManualReview() {
        service.upload(Fakes.candidate("U-C1"), "C1", "PAN", "ABCPE1234F", PDF, "p.pdf");
        IdProofService.DocumentView v = service.upload(Fakes.candidate("U-C2"), "C2", "PAN", "ABCPE1234F", PDF, "p.pdf");
        assertThat(v.status()).isEqualTo("MANUAL_REVIEW");
        assertThat(f.db.auditRows("ID_NUMBER_DUPLICATE")).hasSize(1);
    }

    @Test
    void invalidFilesAndNumbersAreRefused() {
        Caller self = Fakes.candidate("U-C1");
        assertThatThrownBy(() -> service.upload(self, "C1", "PAN", "BAD", PDF, "p.pdf")).hasMessageContaining("not valid");
        assertThatThrownBy(() -> service.upload(self, "C1", "PAN", "ABCPE1234F", "MZ executable......".getBytes(), "p.pdf"))
                .hasMessageContaining("Allowed file types");
        byte[] js = "%PDF-1.7 /JavaScript (app.alert(1))".getBytes(StandardCharsets.ISO_8859_1);
        assertThatThrownBy(() -> service.upload(self, "C1", "PAN", "ABCPE1234F", js, "p.pdf")).hasMessageContaining("scripts");
        assertThatThrownBy(() -> service.upload(self, "C1", "PAN", "ABCPE1234F", PDF, "p.pdf.exe")).isInstanceOf(PlatformException.class);
    }

    @Test
    void revealNeedsPermissionScopeAndReasonAndIsAudited() {
        IdProofService.DocumentView v = service.upload(Fakes.candidate("U-C1"), "C1", "PAN", "ABCPE1234F", PDF, "p.pdf");
        assertThatThrownBy(() -> service.download(Fakes.recruiter("rec", "CANDIDATE_ID_DOC:VIEW"), v.id(), "x"))
                .hasMessageContaining("CANDIDATE_ID_DOC:REVEAL");
        Caller officer = Fakes.recruiter("ver", "CANDIDATE_ID_DOC:REVEAL");
        assertThatThrownBy(() -> service.download(officer, v.id(), null)).hasMessageContaining("Remarks");
        assertThat(service.download(officer, v.id(), "BGV check").content()).isEqualTo(PDF);
        assertThat(service.download(Fakes.candidate("U-C1"), v.id(), null).content()).isEqualTo(PDF);
        assertThat(f.db.auditRows("ID_DOCUMENT_REVEALED")).hasSize(2);
        f.candidates.inScope = false;
        assertThatThrownBy(() -> service.download(officer, v.id(), "x")).hasMessageContaining("scope");
    }

    @Test
    void mismatchAndReuploadDriveTheBadge() {
        providerStatus = "MISMATCH";
        service.upload(Fakes.candidate("U-C1"), "C1", "PAN", "ABCPE1234F", PDF, "p.pdf");
        relay();
        assertThat(service.badge("C1")).isEqualTo(VerificationBadge.ATTENTION);
        providerStatus = "VERIFIED";
        service.upload(Fakes.candidate("U-C1"), "C1", "PAN", "ABCPE1234F", PDF, "p.pdf");
        relay();
        assertThat(service.badge("C1")).isEqualTo(VerificationBadge.VERIFIED);
        assertThat(service.summary(Fakes.candidate("U-C1"), "C1").documents()).extracting("status").contains("SUPERSEDED", "VERIFIED");
    }
}
