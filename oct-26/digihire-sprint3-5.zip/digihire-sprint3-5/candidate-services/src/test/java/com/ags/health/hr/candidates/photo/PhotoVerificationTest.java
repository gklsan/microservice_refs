package com.ags.health.hr.candidates.photo;

import com.ags.health.hr.candidates.photo.domain.PhotoCheck;
import com.ags.health.hr.candidates.photo.domain.PhotoDecision;
import com.ags.health.hr.candidates.photo.domain.PhotoRules;
import com.ags.health.hr.candidates.photo.service.PhotoVerificationService;
import com.ags.health.hr.candidates.photo.store.PhotoCheckStore;
import com.ags.health.hr.candidates.shared.domain.Statuses;
import com.ags.health.hr.candidates.support.Fakes;
import com.ags.health.hr.candidates.support.Sprint3Fixture;
import com.ags.health.hr.common.platform.caller.Caller;
import org.junit.jupiter.api.Test;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

class PhotoVerificationTest {

    private final Sprint3Fixture f = new Sprint3Fixture();
    private double score = 0.9;
    private final PhotoVerificationService service = new PhotoVerificationService(new PhotoCheckStore(f.db.jdbc),
            new PhotoRules(240, 240, 1024 * 1024, 0.8, 0.6), (probe, ref) -> new com.ags.health.hr.candidates.photo.port.FaceMatchPort.Result(score, "STUB", null),
            id -> Optional.of(new byte[]{1}), f.mover, f.catalog, f.audit, Fakes.clock());

    static byte[] png(int w, int h) throws IOException {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        ImageIO.write(new BufferedImage(w, h, BufferedImage.TYPE_INT_RGB), "png", out);
        return out.toByteArray();
    }

    @Test
    void photoRulesCheckFormatSizeAndShape() throws IOException {
        service.validatePhoto(png(300, 400), "me.png");
        assertThatThrownBy(() -> service.validatePhoto(png(100, 100), "me.png")).hasMessageContaining("at least");
        assertThatThrownBy(() -> service.validatePhoto(png(900, 300), "me.png")).hasMessageContaining("portrait");
        assertThatThrownBy(() -> service.validatePhoto(png(300, 400), "me.jpg")).hasMessageContaining("extension");
    }

    @Test
    void panelistMismatchIsFlaggedForAuditReview() {
        f.apps.add("A1", "C1", "R1", Statuses.PANEL_INPROGRESS, "rec1", null, null, null);
        Caller panelist = Fakes.recruiter("pan1", "CANDIDATE_PHOTO:VERIFY");
        assertThatThrownBy(() -> service.manual(panelist, "A1", "MISMATCH", null)).hasMessageContaining("Remarks");
        PhotoCheck c = service.manual(panelist, "A1", "MISMATCH", "Face differs from ID");
        assertThat(c.flagged()).isTrue();
        Caller auditor = Fakes.recruiter("aud", "AUDIT_LOG:VIEW");
        assertThat(service.reviewQueue(auditor, null, 10)).extracting(PhotoCheck::id).containsExactly(c.id());
        service.review(auditor, c.id(), "CONFIRMED_MISMATCH", "Confirmed with HR");
        assertThat(service.reviewQueue(auditor, null, 10)).isEmpty();
        assertThat(f.db.auditRows("PHOTO_MISMATCH_FLAGGED")).hasSize(1);
    }

    @Test
    void automaticMatchUsesThresholds() {
        f.apps.add("A1", "C1", "R1", Statuses.INTERVIEW_INPROGRESS, "rec1", null, null, null);
        Caller hr = Fakes.recruiter("hr", "CANDIDATE_PHOTO:VERIFY");
        assertThat(service.automatic(hr, f.apps.find("A1").orElseThrow(), "HR_ROUND", new byte[]{2}).decision()).isEqualTo(PhotoDecision.MATCH);
        score = 0.7;
        assertThat(service.automatic(hr, f.apps.find("A1").orElseThrow(), "HR_ROUND", new byte[]{2}).decision()).isEqualTo(PhotoDecision.UNSURE);
        score = 0.2;
        assertThat(service.automatic(hr, f.apps.find("A1").orElseThrow(), "HR_ROUND", new byte[]{2}).flagged()).isTrue();
    }
}
