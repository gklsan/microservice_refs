package com.ags.health.hr.candidates.offer;

import com.ags.health.hr.candidates.assessmentbridge.AssessmentEvent;
import com.ags.health.hr.candidates.assessmentbridge.AssessmentExceptionStore;
import com.ags.health.hr.candidates.shared.domain.Statuses;
import com.ags.health.hr.candidates.support.Fakes;
import com.ags.health.hr.candidates.support.Sprint3Fixture;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.Test;

import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

class OfferOutcomeHandlerTest {

    private final Sprint3Fixture f = new Sprint3Fixture();
    private final AssessmentExceptionStore exceptions = new AssessmentExceptionStore(f.db.jdbc);
    private final OfferOutcomeHandler handler = new OfferOutcomeHandler(f.apps, f.mover, f.policy, exceptions, f.audit, Fakes.clock(),
            Statuses.SHORTLISTED, "OFFER_REJECTED");

    private AssessmentEvent event(String type) {
        return new AssessmentEvent(1, UUID.randomUUID(), type, "OFFER", "S1", "C1", "A1",
                new ObjectMapper().createObjectNode().put("oracleStatus", "REJECTED").put("syncId", "S1"), Fakes.NOW, null, 0);
    }

    @Test
    void rejectedOfferRevertsImmediatelyAndNotifies() {
        f.apps.add("A1", "C1", "R1", Statuses.OFFERED, "rec1", null, null, null);
        assertThat(handler.handle(event("OFFER_REJECTED"))).isEqualTo("REVERTED_SHORTLISTED");
        assertThat(f.apps.find("A1").orElseThrow().status()).isEqualTo(Statuses.SHORTLISTED);
        assertThat(f.notifications.types()).containsExactly("OFFER_REJECTED");
    }

    @Test
    void pushFailureOpensAnExceptionAndHireMovesToJoined() {
        f.apps.add("A1", "C1", "R1", Statuses.OFFERED, "rec1", null, null, null);
        handler.handle(event("OFFER_PUSH_FAILED"));
        assertThat(exceptions.list("ORACLE_OFFER", "OPEN", 10)).hasSize(1);
        assertThat(handler.handle(event("CANDIDATE_HIRED"))).isEqualTo("MOVED_JOINED");
    }

    @Test
    void pushRequiresOfferedStatusAndSurfacesValidationErrors() {
        f.apps.add("A1", "C1", "R1", Statuses.SHORTLISTED, "rec1", null, null, null);
        OfferIntegrationPort port = new OfferIntegrationPort() {
            @Override
            public PushResult push(String a, String c, String by, Map<String, Object> d) {
                return new PushResult(null, "INVALID", null, List.of(Map.of("field", "panNumber", "code", "REQUIRED")));
            }

            @Override
            public Map<String, Object> status(String a) {
                return Map.of();
            }
        };
        OfferService s = new OfferService(f.mover, f.guard, id -> java.util.Optional.of(Map.of("x", 1)), port, f.audit, Set.of(Statuses.OFFERED));
        var rec = Fakes.recruiter("rec1", "OFFER:PUSH");
        assertThatThrownBy(() -> s.push(rec, "A1")).hasMessageContaining("Offer can be pushed only");
        f.apps.add("A2", "C1", "R1", Statuses.OFFERED, "rec1", null, null, null);
        assertThatThrownBy(() -> s.push(rec, "A2")).hasMessageContaining("pre-push validation");
    }
}
