package com.ags.health.hr.candidates.support;

import com.ags.health.hr.common.platform.audit.AuditRecorder;
import com.ags.health.hr.common.platform.audit.SharedAuditLogSink;
import com.ags.health.hr.common.platform.caller.CallerProvider;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.transaction.support.TransactionTemplate;

import javax.sql.DataSource;
import java.time.Clock;
import java.util.List;
import java.util.Map;

public final class P5TestDb {

    public final DataSource dataSource;
    public final JdbcTemplate jdbc;
    public final ObjectMapper mapper;
    public final TransactionTemplate tx;

    private P5TestDb(DataSource dataSource) {
        this.dataSource = dataSource;
        this.jdbc = new JdbcTemplate(dataSource);
        this.mapper = new ObjectMapper();
        this.tx = new TransactionTemplate(new DataSourceTransactionManager(dataSource));
    }

    public static P5TestDb h2(String... scripts) {
        DriverManagerDataSource ds = TestDatabase.create("p5", List.of(scripts));
        return new P5TestDb(ds);
    }

    public static P5TestDb candidate() {
        return h2("db/p5/candidate-p5-schema.sql", "db/p5/candidate-p5-data.sql");
    }

    public AuditRecorder audit(CallerProvider callers, Clock clock) {
        return new AuditRecorder(List.of(SharedAuditLogSink.create(jdbc, mapper, "audit_log", 4000)), callers, "test", clock);
    }

    public List<Map<String, Object>> auditRows(String action) {
        return jdbc.queryForList("SELECT * FROM audit_log WHERE action = ? ORDER BY event_time", action);
    }

    public int count(String table) {
        Integer n = jdbc.queryForObject("SELECT count(*) FROM " + table, Integer.class);
        return n == null ? 0 : n;
    }
}
