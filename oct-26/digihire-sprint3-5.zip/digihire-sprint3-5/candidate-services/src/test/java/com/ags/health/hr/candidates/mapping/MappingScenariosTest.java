package com.ags.health.hr.candidates.mapping;

import com.ags.health.hr.candidates.mapping.domain.MappingAction;
import com.ags.health.hr.candidates.mapping.domain.MappingAssessment;
import com.ags.health.hr.candidates.mapping.domain.MappingScenario;
import com.ags.health.hr.candidates.mapping.service.MappingService;
import com.ags.health.hr.candidates.shared.domain.Statuses;
import com.ags.health.hr.candidates.support.Fakes;
import com.ags.health.hr.candidates.support.Sprint3Fixture;
import com.ags.health.hr.common.platform.assessment.EligibilityResult;
import com.ags.health.hr.common.platform.caller.Caller;
import com.ags.health.hr.common.platform.error.PlatformException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.List;
import java.util.Set;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

class MappingScenariosTest {

    private final Sprint3Fixture f = new Sprint3Fixture();
    private final Caller rec = Fakes.recruiter("rec1", "APPLICATION:MAP");
    private MappingService mapping;

    @BeforeEach
    void setUp() {
        f.reqs.add("R1", "LOB1", "CHENNAI", "ROLE1", 5, 1, true);
        f.reqs.add("R2", "LOB1", "CHENNAI", "ROLE1", 2, 2, true);
        f.reqs.add("R3", "LOB1", "CHENNAI", "ROLE1", 2, 0, false);
        f.callers.current = rec;
        mapping = f.mapping();
    }

    private MappingAssessment assess(String candidate, String req) {
        return mapping.assess(rec, new MappingService.AssessRequest(candidate, null, null, req));
    }

    @Test
    void s1UntaggedCandidateIsTaggedAndMapped() {
        f.candidates.add("C1", true, null);
        assertThat(assess("C1", "R1").scenario()).isEqualTo(MappingScenario.S1_UNTAGGED_NO_APPLICATION);
        MappingService.MapOutcome o = mapping.map(rec, new MappingService.MapRequest("C1", "R1", "ERS", "EMP123", "ref drive"));
        assertThat(o.tagged()).isTrue();
        assertThat(o.status()).isEqualTo(Statuses.CREATED);
        assertThat(f.candidates.log).containsExactly("tag:C1:rec1");
        assertThat(f.actions.forCandidate("C1", 10)).hasSize(1);
        assertThat(f.db.auditRows("CANDIDATE_TAGGED_AND_MAPPED")).hasSize(1);
        assertThat(f.db.count("cand_p5_outbox")).isEqualTo(1);
    }

    @Test
    void s2TaggedToMeIsMappedWithoutRetagging() {
        f.candidates.add("C1", true, "rec1");
        assertThat(assess("C1", "R1").action()).isEqualTo(MappingAction.MAP);
        assertThat(mapping.map(rec, new MappingService.MapRequest("C1", "R1", "DIRECT", null, "ok")).tagged()).isFalse();
    }

    @Test
    void s3TaggedToOtherNeedsAccessUnlessCallerMayRetag() {
        f.candidates.add("C1", true, "rec9");
        MappingAssessment a = assess("C1", "R1");
        assertThat(a.scenario()).isEqualTo(MappingScenario.S3_TAGGED_TO_OTHER_NO_APPLICATION);
        assertThat(a.action()).isEqualTo(MappingAction.REQUEST_ACCESS);
        assertThatThrownBy(() -> mapping.map(rec, new MappingService.MapRequest("C1", "R1", "DIRECT", null, "x")))
                .isInstanceOf(PlatformException.class).hasMessageContaining("can not be mapped");
        Caller head = new Caller("head", "h@a.com", "Head", Set.of("TA_HEAD"), Set.of("APPLICATION:MAP", "CANDIDATE:RETAG"), Set.of(),
                "ALL", Set.of(), Set.of(), Set.of(), false);
        assertThat(mapping.assess(head, new MappingService.AssessRequest("C1", null, null, "R1")).action())
                .isEqualTo(MappingAction.TAG_AND_MAP);
    }

    @Test
    void s4AndS5OpenApplications() {
        f.candidates.add("C1", true, "rec1");
        f.apps.add("A1", "C1", "R9", Statuses.WAITING_FOR_HRROUND, "rec1", "LOB1", "CHENNAI", "ROLE1");
        assertThat(assess("C1", "R1").scenario()).isEqualTo(MappingScenario.S4_OPEN_APPLICATION_MINE);
        assertThatThrownBy(() -> mapping.map(rec, new MappingService.MapRequest("C1", "R1", "DIRECT", null, "x")))
                .satisfies(e -> assertThat(((PlatformException) e).getCode()).isEqualTo("USE_REMAP"));
        f.candidates.add("C2", true, "rec7");
        f.apps.add("A2", "C2", "R9", Statuses.CREATED, "rec7", null, null, null);
        MappingAssessment a = assess("C2", "R1");
        assertThat(a.scenario()).isEqualTo(MappingScenario.S5_OPEN_APPLICATION_OTHER);
        assertThat(a.has("NOT_OWNER")).isTrue();
    }

    @Test
    void s6NotRegisteredIsInvited() {
        f.candidates.add("C1", false, null);
        assertThat(assess("C1", "R1").action()).isEqualTo(MappingAction.INVITE_TO_REGISTER);
        assertThat(mapping.assess(rec, new MappingService.AssessRequest(null, "new@mail.com", null, "R1")).scenario())
                .isEqualTo(MappingScenario.S6_NOT_REGISTERED);
    }

    @Test
    void noOpeningsMapsIntoPipelineOnHoldAndNotifies() {
        f.candidates.add("C1", true, null);
        MappingService.MapOutcome o = mapping.map(rec, new MappingService.MapRequest("C1", "R2", "VENDOR", "V-77", "full"));
        assertThat(o.action()).isEqualTo(MappingAction.MAP_ON_HOLD);
        assertThat(o.status()).isEqualTo(Statuses.PIPELINE);
        assertThat(f.notifications.types()).containsExactly("APPLICATION_ON_HOLD");
    }

    @Test
    void inactiveRequisitionEligibilityAndDuplicatesBlock() {
        f.candidates.add("C1", true, null);
        assertThat(assess("C1", "R3").has("REQUISITION_INACTIVE")).isTrue();
        assertThat(assess("C1", "NOPE").has("REQUISITION_NOT_FOUND")).isTrue();
        f.assessments.next = new EligibilityResult(false, List.of(new EligibilityResult.Reason("BLACKLISTED", "bl", null, true)));
        assertThat(assess("C1", "R1").has("BLACKLISTED")).isTrue();
        f.assessments.next = EligibilityResult.ok();
        f.assessments.failure = new RuntimeException("down");
        assertThat(assess("C1", "R1").has("ELIGIBILITY_UNAVAILABLE")).isTrue();
        f.assessments.failure = null;
        f.candidates.add("C2", true, "rec1");
        f.apps.add("A2", "C2", "R1", Statuses.CREATED, "rec1", null, null, null);
        assertThat(assess("C2", "R1").has("ALREADY_MAPPED")).isTrue();
    }

    @Test
    void sourceAndRemarksAreRequired() {
        f.candidates.add("C1", true, null);
        assertThatThrownBy(() -> mapping.map(rec, new MappingService.MapRequest("C1", "R1", "ERS", null, "x")))
                .hasMessageContaining("Referrer");
        assertThatThrownBy(() -> mapping.map(rec, new MappingService.MapRequest("C1", "R1", "DIRECT", null, " ")))
                .hasMessageContaining("Remarks");
    }
}
