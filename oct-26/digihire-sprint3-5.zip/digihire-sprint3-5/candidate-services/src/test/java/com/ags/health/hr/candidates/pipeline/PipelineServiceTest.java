package com.ags.health.hr.candidates.pipeline;

import com.ags.health.hr.candidates.assessmentbridge.NextStageRouting;
import com.ags.health.hr.candidates.pipeline.domain.CsvBulkRowReader;
import com.ags.health.hr.candidates.pipeline.service.PipelineService;
import com.ags.health.hr.candidates.pipeline.store.BulkJobStore;
import com.ags.health.hr.candidates.shared.domain.Statuses;
import com.ags.health.hr.candidates.shared.port.StageEntry;
import com.ags.health.hr.candidates.support.Fakes;
import com.ags.health.hr.candidates.support.Sprint3Fixture;
import com.ags.health.hr.common.platform.assessment.AssessmentPort;
import com.ags.health.hr.common.platform.bulk.BulkSummary;
import com.ags.health.hr.common.platform.caller.Caller;
import org.junit.jupiter.api.Test;

import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

class PipelineServiceTest {

    private final Sprint3Fixture f = new Sprint3Fixture();
    private final PipelineService service = new PipelineService(f.mover, f.guard, f.apps, f.assessments,
            new NextStageRouting(List.of("VOICE"), List.of(), true), f.catalog, List.of(new CsvBulkRowReader()),
            new BulkJobStore(f.db.jdbc), f.db.tx, f.audit, Fakes.clock(), new PipelineService.Settings(100, 100_000));
    private final Caller rec = Fakes.recruiter("rec1", "APPLICATION:BULK_UPDATE", "APPLICATION:REPROCESS");

    private void passedAssessment(String app) {
        f.apps.history.get(app).add(new StageEntry(Statuses.ASSESEMENT_COMPLETED, Fakes.NOW.minus(Duration.ofDays(10)), "sys", true));
    }

    private void validScore() {
        f.assessments.scores = List.of(new AssessmentPort.ValidScore("AT", "SHL", "B", 70.0, Fakes.NOW.minus(Duration.ofDays(10)),
                Fakes.NOW.plus(Duration.ofDays(50))));
    }

    @Test
    void multiSelectMovesEachItemIndependentlyAndValidatesStageHistory() {
        f.apps.add("A1", "C1", "R1", Statuses.PIPELINE, "rec1", "L", "X", "ROLE");
        f.apps.add("A2", "C2", "R1", Statuses.PIPELINE, "rec1", "L", "X", "ROLE");
        f.apps.add("A3", "C3", "R1", Statuses.PIPELINE, "other", "L", "X", "ROLE");
        passedAssessment("A1");
        validScore();
        BulkSummary s = service.bulk(rec, new PipelineService.BulkRequest(List.of("A1", "A2", "A3", "A1"), "PANEL_YET_TO_SCHEDULE",
                null, "drive", false));
        assertThat(s.total()).isEqualTo(3);
        assertThat(s.succeeded()).isEqualTo(1);
        assertThat(s.items()).extracting("code").containsExactly("OK", "STAGE_HISTORY_INVALID", "NOT_TAGGED_RECRUITER");
        assertThat(f.apps.find("A1").orElseThrow().status()).isEqualTo(Statuses.PANEL_YET_TO_SCHEDULE);
        assertThat(service.job(rec, s.jobId())).containsKey("items");
    }

    @Test
    void dryRunChangesNothing() {
        f.apps.add("A1", "C1", "R1", Statuses.CREATED, "rec1", null, null, null);
        BulkSummary s = service.bulk(rec, new PipelineService.BulkRequest(List.of("A1"), "PIPELINE", null, null, true));
        assertThat(s.succeeded()).isEqualTo(1);
        assertThat(f.apps.find("A1").orElseThrow().status()).isEqualTo(Statuses.CREATED);
    }

    @Test
    void csvUploadReadsRowsAndNeutralisesFormulas() {
        f.apps.add("A1", "C1", "R1", Statuses.CREATED, "rec1", null, null, null);
        String csv = "applicationId,targetStatus,reasonCode,remarks\nA1,PIPELINE,ON_HOLD,\"=cmd, hold\"\nNOPE,PIPELINE,,\n";
        BulkSummary s = service.upload(rec, "moves.csv", csv.getBytes(StandardCharsets.UTF_8), false);
        assertThat(s.succeeded()).isEqualTo(1);
        assertThat(s.failed()).isEqualTo(1);
        assertThatThrownBy(() -> service.upload(rec, "moves.exe", csv.getBytes(StandardCharsets.UTF_8), false))
                .hasMessageContaining(".xlsx");
    }

    @Test
    void reprocessResumesFromThePriorStageOrReEvaluatesExpiredScores() {
        f.apps.add("A1", "C1", "R1", Statuses.PIPELINE, "rec1", "L", "X", "VOICE");
        passedAssessment("A1");
        validScore();
        assertThat(service.previewReprocess(rec, "A1").resumeAt()).isEqualTo(Statuses.VERSANT_YET_TO_START);
        f.assessments.scores = List.of();
        PipelineService.ReprocessPreview p = service.reprocess(rec, "A1", "re-evaluate");
        assertThat(p.resumeAt()).isEqualTo(Statuses.ASSESEMENT_YET_TO_START);
        assertThat(p.basis()).isEqualTo("SCORE_EXPIRED_REEVALUATION");
        assertThat(f.apps.find("A1").orElseThrow().status()).isEqualTo(Statuses.ASSESEMENT_YET_TO_START);
    }
}
