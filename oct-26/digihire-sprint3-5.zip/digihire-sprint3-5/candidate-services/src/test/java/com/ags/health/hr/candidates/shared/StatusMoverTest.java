package com.ags.health.hr.candidates.shared;

import com.ags.health.hr.candidates.shared.domain.Statuses;
import com.ags.health.hr.candidates.shared.domain.Tab;
import com.ags.health.hr.candidates.shared.service.StatusMover;
import com.ags.health.hr.candidates.support.Fakes;
import com.ags.health.hr.candidates.support.Sprint3Fixture;
import com.ags.health.hr.common.platform.caller.Caller;
import com.ags.health.hr.common.platform.error.PlatformException;
import org.junit.jupiter.api.Test;

import java.util.Set;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

class StatusMoverTest {

    private final Sprint3Fixture f = new Sprint3Fixture();

    @Test
    void taggedRecruiterMovesAlongTheConfiguredPathAndEverythingIsLogged() {
        f.apps.add("A1", "C1", "R1", Statuses.CREATED, "rec1", "LOB1", "CHENNAI", "ROLE1");
        Caller rec = Fakes.recruiter("rec1", "APPLICATION:MOVE_STAGE");
        f.callers.current = rec;
        StatusMover.Result r = f.mover.move(rec, StatusMover.Move.to("A1", Statuses.WAITING_FOR_HRROUND, "APPLICATION:MOVE_STAGE")
                .reason(null, "ready").notify("HR_READY"));
        assertThat(r.fromTab()).isEqualTo(Tab.APPLICANT);
        assertThat(r.toTab()).isEqualTo(Tab.HR_INTERVIEW);
        assertThat(f.apps.find("A1").orElseThrow().status()).isEqualTo(Statuses.WAITING_FOR_HRROUND);
        assertThat(f.db.auditRows("STATUS_CHANGED")).hasSize(1);
        assertThat(f.notifications.types()).containsExactly("HR_READY");
        assertThat(f.db.count("cand_p5_outbox")).isEqualTo(1);
    }

    @Test
    void otherRecruiterIsRefusedAndTheDenialIsAudited() {
        f.apps.add("A1", "C1", "R1", Statuses.CREATED, "rec1", null, null, null);
        Caller other = Fakes.recruiter("rec2", "APPLICATION:MOVE_STAGE");
        assertThatThrownBy(() -> f.mover.move(other, StatusMover.Move.to("A1", Statuses.WAITING_FOR_HRROUND, "APPLICATION:MOVE_STAGE")))
                .isInstanceOf(PlatformException.class).hasMessageContaining("tagged recruiter");
        assertThat(f.db.auditRows("STATUS_CHANGE_DENIED")).hasSize(1);
        assertThat(f.apps.find("A1").orElseThrow().status()).isEqualTo(Statuses.CREATED);
    }

    @Test
    void teamLeadOfTheTaggedRecruiterMayAct() {
        f.apps.add("A1", "C1", "R1", Statuses.CREATED, "rec1", null, null, null);
        Caller tl = Fakes.lead("tl1", Set.of("rec1"), "APPLICATION:MOVE_STAGE");
        f.mover.move(tl, StatusMover.Move.to("A1", Statuses.PIPELINE, "APPLICATION:MOVE_STAGE"));
        assertThat(f.apps.find("A1").orElseThrow().status()).isEqualTo(Statuses.PIPELINE);
    }

    @Test
    void transitionsOutsideThePolicyAreBlocked() {
        f.apps.add("A1", "C1", "R1", Statuses.CREATED, "rec1", null, null, null);
        Caller rec = Fakes.recruiter("rec1", "APPLICATION:MOVE_STAGE");
        assertThatThrownBy(() -> f.mover.move(rec, StatusMover.Move.to("A1", Statuses.OFFERED, "APPLICATION:MOVE_STAGE")))
                .isInstanceOf(PlatformException.class)
                .satisfies(e -> assertThat(((PlatformException) e).getCode()).isEqualTo("TRANSITION_NOT_ALLOWED"));
        assertThat(f.db.auditRows("STATUS_CHANGE_BLOCKED")).hasSize(1);
    }

    @Test
    void resetNeedsAnAllowedReason() {
        f.apps.add("A1", "C1", "R1", Statuses.PANEL_INPROGRESS, "rec1", null, null, null);
        Caller sys = Caller.system("test");
        assertThatThrownBy(() -> f.mover.move(sys, StatusMover.Move.to("A1", Statuses.CREATED, null).reason("WHATEVER", null).asReset()))
                .isInstanceOf(PlatformException.class);
        f.mover.move(sys, StatusMover.Move.to("A1", Statuses.PIPELINE, null).reason("FRESHER_PIPELINE", null).asReset());
        assertThat(f.db.auditRows("STATUS_RESET")).hasSize(1);
    }

    @Test
    void remarksAreValidated() {
        f.apps.add("A1", "C1", "R1", Statuses.CREATED, "rec1", null, null, null);
        Caller rec = Fakes.recruiter("rec1", "APPLICATION:HOLD");
        assertThatThrownBy(() -> f.mover.move(rec, StatusMover.Move.to("A1", Statuses.PIPELINE, "APPLICATION:HOLD").requireRemarks()))
                .hasMessageContaining("Remarks");
    }
}
