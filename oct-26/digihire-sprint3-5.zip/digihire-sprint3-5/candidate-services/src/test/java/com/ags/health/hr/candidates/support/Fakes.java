package com.ags.health.hr.candidates.support;

import com.ags.health.hr.candidates.shared.port.ApplicationPort;
import com.ags.health.hr.candidates.shared.port.ApplicationView;
import com.ags.health.hr.candidates.shared.port.CandidateAccessPort;
import com.ags.health.hr.candidates.shared.port.CandidatePort;
import com.ags.health.hr.candidates.shared.port.CandidateView;
import com.ags.health.hr.candidates.shared.port.NewApplication;
import com.ags.health.hr.candidates.shared.port.RequisitionPort;
import com.ags.health.hr.candidates.shared.port.RequisitionView;
import com.ags.health.hr.candidates.shared.port.StageEntry;
import com.ags.health.hr.candidates.shared.port.StageHistoryPort;
import com.ags.health.hr.candidates.shared.port.StatusChange;
import com.ags.health.hr.candidates.shared.domain.StageCatalog;
import com.ags.health.hr.common.platform.assessment.AssessmentPort;
import com.ags.health.hr.common.platform.assessment.EligibilityResult;
import com.ags.health.hr.common.platform.caller.Caller;
import com.ags.health.hr.common.platform.caller.CallerProvider;
import com.ags.health.hr.common.platform.notify.NotificationPort;
import com.ags.health.hr.common.platform.notify.NotificationRequest;

import java.time.Clock;
import java.time.Instant;
import java.time.LocalDate;
import java.time.ZoneOffset;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.concurrent.atomic.AtomicInteger;

public final class Fakes {

    public static final Instant NOW = Instant.parse("2026-10-20T05:30:00Z");

    private Fakes() {
    }

    public static Clock clock() {
        return Clock.fixed(NOW, ZoneOffset.UTC);
    }

    public static Caller recruiter(String id, String... permissions) {
        return new Caller(id, id + "@agshealth.com", "Recruiter " + id, Set.of("RECRUITER"), Set.of(permissions), Set.of(), "OWN",
                Set.of(), Set.of(), Set.of(), false);
    }

    public static Caller lead(String id, Set<String> team, String... permissions) {
        return new Caller(id, id + "@agshealth.com", "Lead " + id, Set.of("RECRUITMENT_MANAGER"), Set.of(permissions), Set.of(),
                "TEAM", team, Set.of(), Set.of(), false);
    }

    public static Caller candidate(String userId) {
        return new Caller(userId, userId + "@mail.com", "Candidate " + userId, Set.of("CANDIDATE"), Set.of("CANDIDATE_SELF:VIEW"),
                Set.of(), "OWN", Set.of(), Set.of(), Set.of(), false);
    }

    public static final class Callers implements CallerProvider {
        public Caller current;

        public Callers(Caller c) {
            this.current = c;
        }

        @Override
        public Optional<Caller> current() {
            return Optional.ofNullable(current);
        }
    }

    public static final class Applications implements ApplicationPort, StageHistoryPort {
        public final Map<String, ApplicationView> apps = new LinkedHashMap<>();
        public final Map<String, List<StageEntry>> history = new LinkedHashMap<>();
        public final List<String> log = new ArrayList<>();
        private final AtomicInteger seq = new AtomicInteger();
        private final StageCatalog catalog = StageCatalog.standard();

        public ApplicationView add(String id, String candidateId, String requisitionId, String status, String hr, String lob,
                                   String location, String role) {
            ApplicationView a = new ApplicationView(id, candidateId, "JOB-" + requisitionId, requisitionId, status, hr, lob, location,
                    "ORC-" + requisitionId, role, "DIRECT", NOW);
            apps.put(id, a);
            history.computeIfAbsent(id, k -> new ArrayList<>()).add(new StageEntry(status, NOW.minusSeconds(3600), hr, false));
            return a;
        }

        @Override
        public Optional<ApplicationView> find(String applicationId) {
            return Optional.ofNullable(apps.get(applicationId));
        }

        @Override
        public List<ApplicationView> findOpenByCandidate(String candidateId) {
            return apps.values().stream().filter(a -> a.candidateId().equals(candidateId) && catalog.isOpen(a.status())).toList();
        }

        @Override
        public List<ApplicationView> findByCandidate(String candidateId) {
            return apps.values().stream().filter(a -> a.candidateId().equals(candidateId)).toList();
        }

        @Override
        public ApplicationView create(NewApplication n) {
            String id = "APP-" + seq.incrementAndGet();
            ApplicationView a = new ApplicationView(id, n.candidateId(), n.jobId(), n.requisitionId(), n.status(), n.hrUserId(),
                    null, null, null, null, n.source(), NOW);
            apps.put(id, a);
            log.add("create:" + id + ":" + n.status());
            history.computeIfAbsent(id, k -> new ArrayList<>()).add(new StageEntry(n.status(), NOW, n.change().actorId(), false));
            return a;
        }

        @Override
        public void changeStatus(String id, String toStatus, StatusChange change) {
            ApplicationView a = apps.get(id);
            apps.put(id, new ApplicationView(a.id(), a.candidateId(), a.jobId(), a.requisitionId(), toStatus, a.hrUserId(), a.lob(),
                    a.location(), a.orcId(), a.roleCode(), a.source(), NOW));
            log.add("status:" + id + ":" + toStatus + ":" + change.reasonCode());
            history.computeIfAbsent(id, k -> new ArrayList<>()).add(new StageEntry(toStatus, NOW, change.actorId(), change.system()));
        }

        @Override
        public void retag(String id, String hrUserId, StatusChange change) {
            ApplicationView a = apps.get(id);
            apps.put(id, new ApplicationView(a.id(), a.candidateId(), a.jobId(), a.requisitionId(), a.status(), hrUserId, a.lob(),
                    a.location(), a.orcId(), a.roleCode(), a.source(), NOW));
            log.add("retag:" + id + ":" + hrUserId);
        }

        @Override
        public void changeRequisition(String id, String requisitionId, String jobId, StatusChange change) {
            ApplicationView a = apps.get(id);
            apps.put(id, new ApplicationView(a.id(), a.candidateId(), jobId, requisitionId, a.status(), a.hrUserId(), null, null,
                    null, null, a.source(), NOW));
            log.add("requisition:" + id + ":" + requisitionId);
        }

        @Override
        public List<StageEntry> history(String applicationId) {
            return history.getOrDefault(applicationId, List.of());
        }
    }

    public static final class Candidates implements CandidatePort, CandidateAccessPort {
        public final Map<String, CandidateView> candidates = new LinkedHashMap<>();
        public final List<String> log = new ArrayList<>();
        public boolean inScope = true;

        public CandidateView add(String id, boolean registered, String taggedRecruiter) {
            CandidateView c = new CandidateView(id, "U-" + id, id.toLowerCase() + "@mail.com", "98765" + String.format("%05d",
                    Math.abs(id.hashCode()) % 100000), "Name " + id, registered, taggedRecruiter, "DIRECT", null, null);
            candidates.put(id, c);
            return c;
        }

        @Override
        public Optional<CandidateView> find(String candidateId) {
            return Optional.ofNullable(candidates.get(candidateId));
        }

        @Override
        public Optional<CandidateView> findByEmailOrMobile(String email, String mobile) {
            return candidates.values().stream().filter(c -> (email != null && email.equalsIgnoreCase(c.email()))
                    || (mobile != null && mobile.equals(c.mobile()))).findFirst();
        }

        @Override
        public void tagRecruiter(String candidateId, String hrUserId, StatusChange change) {
            CandidateView c = candidates.get(candidateId);
            candidates.put(candidateId, new CandidateView(c.id(), c.smartieUserId(), c.email(), c.mobile(), c.fullName(),
                    c.registered(), hrUserId, c.source(), c.subSource(), c.coolingUntil()));
            log.add("tag:" + candidateId + ":" + hrUserId);
        }

        @Override
        public boolean canView(Caller caller, String candidateId) {
            return inScope;
        }
    }

    public static final class Requisitions implements RequisitionPort {
        public final Map<String, RequisitionView> reqs = new LinkedHashMap<>();

        public RequisitionView add(String id, String lob, String location, String role, int openings, int filled, boolean active) {
            RequisitionView r = new RequisitionView(id, "JOB-" + id, "Title " + id, lob, location, "ORC-" + id, role,
                    active ? "OPEN" : "CLOSED", active, openings, filled, LocalDate.of(2027, 3, 31));
            reqs.put(id, r);
            return r;
        }

        @Override
        public Optional<RequisitionView> find(String requisitionId) {
            return Optional.ofNullable(reqs.get(requisitionId));
        }
    }

    public static final class Assessments implements AssessmentPort {
        public EligibilityResult next = EligibilityResult.ok();
        public RuntimeException failure;
        public List<ValidScore> scores = new ArrayList<>();
        public final List<Map<String, Object>> events = new ArrayList<>();

        @Override
        public EligibilityResult check(String candidateId, String email, String mobile, String assessmentCode, String lob,
                                       String roleCode, String location, String purpose) {
            if (failure != null) {
                throw failure;
            }
            return next;
        }

        @Override
        public List<ValidScore> validScores(String candidateId) {
            return scores;
        }

        @Override
        public void applicationEvent(Map<String, Object> event) {
            if (failure != null) {
                throw failure;
            }
            events.add(event);
        }
    }

    public static final class Notifications implements NotificationPort {
        public final List<NotificationRequest> sent = new ArrayList<>();

        @Override
        public void trigger(NotificationRequest request) {
            sent.add(request);
        }

        public List<String> types() {
            return sent.stream().map(NotificationRequest::eventType).toList();
        }
    }
}
