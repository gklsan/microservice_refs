package com.ags.health.hr.candidates.hrround;

import com.ags.health.hr.candidates.hrround.service.HrRoundService;
import com.ags.health.hr.candidates.hrround.store.CompetencyStore;
import com.ags.health.hr.candidates.hrround.store.HrInterviewStore;
import com.ags.health.hr.candidates.photo.domain.PhotoRules;
import com.ags.health.hr.candidates.photo.port.FaceMatchPort;
import com.ags.health.hr.candidates.photo.service.PhotoVerificationService;
import com.ags.health.hr.candidates.photo.store.PhotoCheckStore;
import com.ags.health.hr.candidates.shared.domain.Statuses;
import com.ags.health.hr.candidates.support.Fakes;
import com.ags.health.hr.candidates.support.Sprint3Fixture;
import com.ags.health.hr.common.platform.caller.Caller;
import com.ags.health.hr.common.platform.error.PlatformException;
import com.ags.health.hr.common.platform.storage.InMemoryDocumentStore;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.Map;
import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

class HrRoundServiceTest {

    private final Sprint3Fixture f = new Sprint3Fixture();
    private double faceScore = 0.95;
    private HrRoundService hr;
    private final Caller rec = Fakes.recruiter("rec1", "INTERVIEW_FEEDBACK:CREATE");
    private static final Map<String, Integer> GOOD = Map.of("COMMUNICATION", 4, "DOMAIN_KNOWLEDGE", 4, "ATTITUDE", 5);

    @BeforeEach
    void setUp() {
        PhotoVerificationService photos = new PhotoVerificationService(new PhotoCheckStore(f.db.jdbc), new PhotoRules(100, 100, 1 << 20, 0.8, 0.6),
                (p, r) -> new FaceMatchPort.Result(faceScore, "STUB", null), id -> Optional.of(new byte[]{1}), f.mover, f.catalog, f.audit,
                Fakes.clock());
        hr = new HrRoundService(new HrInterviewStore(f.db.jdbc), new CompetencyStore(f.db.jdbc), f.mover, f.guard, f.policy, photos,
                f.reasons, new InMemoryDocumentStore(), f.audit, Fakes.clock(), new HrRoundService.Settings(1, true, 60, 1 << 20,
                "APPLICATION_REJECTED"));
        f.apps.add("A1", "C1", "R1", Statuses.WAITING_FOR_HRROUND, "rec1", "L", "X", "ROLE");
    }

    static byte[] png() throws IOException {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        ImageIO.write(new BufferedImage(200, 240, BufferedImage.TYPE_INT_RGB), "png", out);
        return out.toByteArray();
    }

    @Test
    void onlineInterviewNeedsScreenshotThenSelectsIntoAValidNextStage() throws IOException {
        HrInterviewStore.Interview i = hr.start(rec, "A1", "online");
        assertThat(f.apps.find("A1").orElseThrow().status()).isEqualTo(Statuses.INTERVIEW_INPROGRESS);
        HrRoundService.FeedbackRequest select = new HrRoundService.FeedbackRequest(GOOD, "good", "SELECT", "PANEL_YET_TO_SCHEDULE", null, null, null);
        assertThatThrownBy(() -> hr.feedback(rec, i.id(), select))
                .satisfies(e -> assertThat(((PlatformException) e).getDetails().toString()).contains("SCREENSHOT_REQUIRED"));
        hr.screenshot(rec, i.id(), png(), "shot.png");
        assertThatThrownBy(() -> hr.feedback(rec, i.id(), new HrRoundService.FeedbackRequest(GOOD, "x", "SELECT", "OFFERED", null, null, null)))
                .hasMessageContaining("Next stage");
        HrRoundService.FeedbackResult r = hr.feedback(rec, i.id(), select);
        assertThat(r.toStatus()).isEqualTo(Statuses.PANEL_YET_TO_SCHEDULE);
        assertThat(r.score()).isGreaterThan(60);
    }

    @Test
    void lowScoresCanNotSelectAndRejectionGoesStraightToRejectedTab() throws IOException {
        HrInterviewStore.Interview i = hr.start(rec, "A1", "ONLINE");
        hr.screenshot(rec, i.id(), png(), "shot.png");
        Map<String, Integer> weak = Map.of("COMMUNICATION", 1, "DOMAIN_KNOWLEDGE", 2, "ATTITUDE", 2);
        assertThatThrownBy(() -> hr.feedback(rec, i.id(), new HrRoundService.FeedbackRequest(weak, "x", "SELECT", "PANEL_YET_TO_SCHEDULE",
                null, null, null))).satisfies(e -> assertThat(((PlatformException) e).getDetails().toString())
                .contains("SCORE_BELOW_PASS", "MANDATORY_BELOW_MINIMUM"));
        HrRoundService.FeedbackResult r = hr.feedback(rec, i.id(), new HrRoundService.FeedbackRequest(weak, "Not a fit", "REJECT", null,
                "COMMUNICATION", null, null));
        assertThat(r.toTab()).isEqualTo("REJECTED");
        assertThat(f.notifications.types()).containsExactly("APPLICATION_REJECTED");
    }

    @Test
    void inOfficeKioskMismatchBlocksFeedbackUnlessOverridden() throws IOException {
        HrInterviewStore.Interview i = hr.start(rec, "A1", "IN_OFFICE");
        faceScore = 0.1;
        assertThat(hr.kioskPhoto(rec, i.id(), png(), "kiosk.png").flagged()).isTrue();
        HrRoundService.FeedbackRequest select = new HrRoundService.FeedbackRequest(GOOD, "ok", "SELECT", "WAITING_FOR_DEVICE", null, null, null);
        assertThatThrownBy(() -> hr.feedback(rec, i.id(), select))
                .satisfies(e -> assertThat(((PlatformException) e).getDetails().toString()).contains("KIOSK_PHOTO_MISMATCH"));
        HrRoundService.FeedbackResult r = hr.feedback(rec, i.id(), new HrRoundService.FeedbackRequest(GOOD, "ok", "SELECT",
                "WAITING_FOR_DEVICE", null, null, "ID checked manually by HR"));
        assertThat(r.toStatus()).isEqualTo(Statuses.WAITING_FOR_DEVICE);
    }
}
