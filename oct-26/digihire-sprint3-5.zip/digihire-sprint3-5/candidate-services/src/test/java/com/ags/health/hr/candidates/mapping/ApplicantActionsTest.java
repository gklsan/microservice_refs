package com.ags.health.hr.candidates.mapping;

import com.ags.health.hr.candidates.mapping.domain.RemapPlan;
import com.ags.health.hr.candidates.mapping.domain.RemapScenario;
import com.ags.health.hr.candidates.mapping.service.ApplicantActionService;
import com.ags.health.hr.candidates.mapping.service.SchedulingService;
import com.ags.health.hr.candidates.mapping.store.InterviewSlotStore;
import com.ags.health.hr.candidates.shared.domain.Statuses;
import com.ags.health.hr.candidates.support.Fakes;
import com.ags.health.hr.candidates.support.Sprint3Fixture;
import com.ags.health.hr.common.platform.caller.Caller;
import com.ags.health.hr.common.platform.error.PlatformException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.time.Duration;
import java.time.Instant;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

class ApplicantActionsTest {

    private final Sprint3Fixture f = new Sprint3Fixture();
    private final Caller rec = Fakes.recruiter("rec1", "APPLICATION:REJECT", "APPLICATION:REMAP", "APPLICATION:MOVE_STAGE",
            "APPLICATION:HOLD", "APPLICATION:SCHEDULE_INTERVIEW", "INTERVIEW_SLOT:MANAGE");

    @BeforeEach
    void setUp() {
        f.callers.current = rec;
        f.candidates.add("C1", true, "rec1");
        f.reqs.add("R1", "LOB1", "CHENNAI", "ROLE1", 5, 0, true);
        f.reqs.add("R2", "LOB1", "CHENNAI", "ROLE2", 5, 0, true);
        f.reqs.add("R3", "LOB2", "CHENNAI", "ROLE1", 5, 0, true);
        f.reqs.add("R4", "LOB1", "TRICHY", "ROLE1", 5, 0, true);
        f.reqs.add("R5", "LOB1", "CHENNAI", "ROLE1", 1, 1, true);
    }

    @Test
    void rejectionNeedsAStandardReasonAndSendsItsTemplate() {
        f.apps.add("A1", "C1", "R1", Statuses.CREATED, "rec1", "LOB1", "CHENNAI", "ROLE1");
        ApplicantActionService s = f.applicant(ApplicantActionService.RemapMode.IN_PLACE);
        assertThatThrownBy(() -> s.reject(rec, "A1", "MADE_UP", "x")).hasMessageContaining("rejection reason");
        assertThatThrownBy(() -> s.reject(rec, "A1", "SALARY_MISMATCH", null)).hasMessageContaining("Remarks");
        s.reject(rec, "A1", "NOT_QUALIFIED", null);
        assertThat(f.apps.find("A1").orElseThrow().status()).isEqualTo(Statuses.HR_REJECTED);
        assertThat(f.notifications.types()).containsExactly("APPLICATION_REJECTED");
    }

    @Test
    void remapScenariosArePlannedFromRequisitionDifferences() {
        f.apps.add("A1", "C1", "R1", Statuses.ASSESEMENT_COMPLETED, "rec1", "LOB1", "CHENNAI", "ROLE1");
        ApplicantActionService s = f.applicant(ApplicantActionService.RemapMode.IN_PLACE);
        RemapPlan newRole = s.previewRemap(rec, "A1", "R2");
        assertThat(newRole.scenario()).isEqualTo(RemapScenario.SAME_LOB_NEW_ROLE);
        assertThat(newRole.resultingStatus()).isEqualTo(Statuses.ASSESEMENT_YET_TO_START);
        assertThat(s.previewRemap(rec, "A1", "R3").scenario()).isEqualTo(RemapScenario.NEW_LOB);
        assertThat(s.previewRemap(rec, "A1", "R3").resultingStatus()).isEqualTo(Statuses.CREATED);
        assertThat(s.previewRemap(rec, "A1", "R4").scenario()).isEqualTo(RemapScenario.NEW_LOCATION);
        RemapPlan full = s.previewRemap(rec, "A1", "R5");
        assertThat(full.allowed()).isFalse();
        assertThat(full.suggestion()).isEqualTo("MOVE_TO_PIPELINE_ON_HOLD");
        f.apps.add("A2", "C1", "R1", Statuses.OFFERED, "rec1", "LOB1", "CHENNAI", "ROLE1");
        assertThat(s.previewRemap(rec, "A2", "R2").scenario()).isEqualTo(RemapScenario.STAGE_LOCKED);
    }

    @Test
    void remapInPlaceChangesRequisitionAndResetsStage() {
        f.apps.add("A1", "C1", "R1", Statuses.ASSESEMENT_COMPLETED, "rec1", "LOB1", "CHENNAI", "ROLE1");
        ApplicantActionService.RemapResult r = f.applicant(ApplicantActionService.RemapMode.IN_PLACE)
                .remap(rec, "A1", "R2", "role change");
        assertThat(r.status()).isEqualTo(Statuses.ASSESEMENT_YET_TO_START);
        assertThat(f.apps.find("A1").orElseThrow().requisitionId()).isEqualTo("R2");
        assertThat(f.db.auditRows("APPLICATION_REMAPPED")).hasSize(1);
        assertThat(f.db.auditRows("STATUS_RESET")).hasSize(1);
    }

    @Test
    void remapAsNewApplicationClosesTheOldOne() {
        f.apps.add("A1", "C1", "R1", Statuses.WAITING_FOR_HRROUND, "rec1", "LOB1", "CHENNAI", "ROLE1");
        ApplicantActionService.RemapResult r = f.applicant(ApplicantActionService.RemapMode.NEW_APPLICATION)
                .remap(rec, "A1", "R2", "role change");
        assertThat(f.apps.find("A1").orElseThrow().status()).isEqualTo(Statuses.REMAPPED);
        assertThat(f.apps.find(r.newApplicationId()).orElseThrow().requisitionId()).isEqualTo("R2");
    }

    @Test
    void walkInSlotsAreCappedAndReschedulingReleasesTheSeat() {
        f.apps.add("A1", "C1", "R1", Statuses.CREATED, "rec1", "LOB1", "CHENNAI", "ROLE1");
        f.apps.add("A2", "C1", "R1", Statuses.CREATED, "rec1", "LOB1", "CHENNAI", "ROLE1");
        SchedulingService s = f.scheduling();
        Instant start = Fakes.NOW.plus(Duration.ofDays(1));
        InterviewSlotStore.Slot slot = s.createSlot(rec, new SchedulingService.SlotRequest("WALK_IN", "LOB1", "CHENNAI", "Tower B",
                start, start.plus(Duration.ofHours(3)), 1));
        s.scheduleWalkIn(rec, "A1", new SchedulingService.ScheduleRequest(slot.id(), null, null, null, null, "first"));
        assertThatThrownBy(() -> s.scheduleWalkIn(rec, "A2", new SchedulingService.ScheduleRequest(slot.id(), null, null, null, null, null)))
                .satisfies(e -> assertThat(((PlatformException) e).getCode()).isEqualTo("SLOT_FULL"));
        s.scheduleWalkIn(rec, "A1", new SchedulingService.ScheduleRequest(null, start.plus(Duration.ofDays(1)), null, "HQ", null, "moved"));
        s.scheduleWalkIn(rec, "A2", new SchedulingService.ScheduleRequest(slot.id(), null, null, null, null, null));
        assertThat(f.notifications.types()).containsOnly("WALK_IN_INVITE").hasSize(3);
    }

    @Test
    void onlineInterviewCreatesMeetingAndMovesToHrRound() {
        f.apps.add("A1", "C1", "R1", Statuses.CREATED, "rec1", "LOB1", "CHENNAI", "ROLE1");
        Instant start = Fakes.NOW.plus(Duration.ofDays(2));
        InterviewSlotStore.Booking b = f.scheduling().scheduleOnline(rec, "A1",
                new SchedulingService.ScheduleRequest(null, start, start.plus(Duration.ofMinutes(45)), null, "hr@agshealth.com", null));
        assertThat(b.meetingUrl()).startsWith("https://meet.example/x/");
        assertThat(f.apps.find("A1").orElseThrow().status()).isEqualTo(Statuses.WAITING_FOR_HRROUND);
        assertThat(f.notifications.types()).containsExactly("ONLINE_INTERVIEW_SCHEDULED");
    }
}
