package com.ags.health.hr.candidates.panel;

import com.ags.health.hr.candidates.mapping.domain.MappingAssessment;
import com.ags.health.hr.candidates.mapping.domain.MappingScenarioResolver;
import com.ags.health.hr.candidates.mapping.port.LinkOnlyMeetingPort;
import com.ags.health.hr.candidates.mapping.service.MappingService;
import com.ags.health.hr.candidates.panel.port.PanelistDirectoryPort;
import com.ags.health.hr.candidates.panel.service.OrcRestrictionGuard;
import com.ags.health.hr.candidates.panel.service.PanelService;
import com.ags.health.hr.candidates.panel.store.OrcRestrictionStore;
import com.ags.health.hr.candidates.panel.store.PanelStore;
import com.ags.health.hr.candidates.photo.domain.PhotoRules;
import com.ags.health.hr.candidates.photo.service.PhotoVerificationService;
import com.ags.health.hr.candidates.photo.store.PhotoCheckStore;
import com.ags.health.hr.candidates.shared.domain.Statuses;
import com.ags.health.hr.candidates.support.Fakes;
import com.ags.health.hr.candidates.support.Sprint3Fixture;
import com.ags.health.hr.common.platform.caller.Caller;
import com.ags.health.hr.common.platform.storage.InMemoryDocumentStore;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.time.Duration;
import java.time.Instant;
import java.util.List;
import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

class PanelServiceTest {

    private final Sprint3Fixture f = new Sprint3Fixture();
    private final OrcRestrictionStore restrictions = new OrcRestrictionStore(f.db.jdbc);
    private final InMemoryDocumentStore files = new InMemoryDocumentStore();
    private PanelService panel;
    private final Caller rec = Fakes.recruiter("rec1", "INTERVIEW_SCHEDULE:UPDATE", "PANEL:CHANGE_ORC", "APPLICATION:MAP");
    private final Caller panelist = Fakes.recruiter("pan1");
    private final Instant start = Fakes.NOW.plus(Duration.ofDays(1));

    @BeforeEach
    void setUp() {
        PanelistDirectoryPort dir = id -> Optional.of(new PanelistDirectoryPort.Panelist(id, id + "@agshealth.com", id, !id.equals("gone")));
        PhotoVerificationService photos = new PhotoVerificationService(new PhotoCheckStore(f.db.jdbc), new PhotoRules(1, 1, 10, 0.8, 0.6),
                (a, b) -> null, id -> Optional.empty(), f.mover, f.catalog, f.audit, Fakes.clock());
        panel = new PanelService(new PanelStore(f.db.jdbc), restrictions, dir, new LinkOnlyMeetingPort("https://teams.example"), f.reqs,
                f.apps, f.mover, f.guard, f.reasons, photos, files, f.audit, Fakes.clock(), new PanelService.Settings(60, 1 << 20, 30,
                "APPLICATION_REJECTED"));
        f.apps.add("A1", "C1", "R1", Statuses.PANEL_YET_TO_SCHEDULE, "rec1", "LOB1", "CHENNAI", "ROLE1");
        f.reqs.add("R1", "LOB1", "CHENNAI", "ROLE1", 5, 0, true);
        f.reqs.add("R2", "LOB1", "CHENNAI", "ROLE1", 5, 0, true);
        f.reqs.add("R3", "LOB2", "CHENNAI", "ROLE1", 5, 0, true);
    }

    private PanelStore.Schedule schedule() {
        return panel.schedule(rec, "A1", new PanelService.ScheduleRequest("lob1", "chennai", "ORC-R1", List.of("pan1", "pan2"), "ONLINE",
                start, start.plus(Duration.ofHours(1)), "first round"));
    }

    @Test
    void scheduleRescheduleKeepsFullHistory() {
        assertThatThrownBy(() -> panel.schedule(rec, "A1", new PanelService.ScheduleRequest("L", "C", "O", List.of("gone"), "ONLINE",
                start, start.plusSeconds(3600), null))).hasMessageContaining("not an active panel member");
        PanelStore.Schedule s = schedule();
        assertThat(s.meetingUrl()).startsWith("https://teams.example/");
        assertThat(f.apps.find("A1").orElseThrow().status()).isEqualTo(Statuses.PANEL_INPROGRESS);
        assertThatThrownBy(() -> panel.reschedule(rec, s.id(), new PanelService.RescheduleRequest(start.plus(Duration.ofDays(1)),
                start.plus(Duration.ofDays(1)).plusSeconds(1800), null, "BUSINESS_NEED", null))).hasMessageContaining("Remarks");
        panel.reschedule(rec, s.id(), new PanelService.RescheduleRequest(start.plus(Duration.ofDays(1)),
                start.plus(Duration.ofDays(1)).plusSeconds(1800), List.of("pan3"), "BUSINESS_NEED", "Client visit"));
        assertThat(panel.overview(rec, "A1").get("history").toString()).contains("RESCHEDULED", "Client visit", "BUSINESS_NEED");
    }

    @Test
    void onlyPanelistsDecideAndRejectionBlocksTheSameOrcFor60Days() {
        PanelStore.Schedule s = schedule();
        assertThatThrownBy(() -> panel.decide(Fakes.recruiter("x"), s.id(), new PanelService.DecisionRequest("SELECT", null, "ok")))
                .hasMessageContaining("panelist");
        panel.decide(panelist, s.id(), new PanelService.DecisionRequest("REJECT", "NOT_QUALIFIED", "Weak domain"));
        assertThat(f.apps.find("A1").orElseThrow().status()).isEqualTo(Statuses.PANEL_REJECTED);
        f.candidates.add("C1", true, "rec1");
        f.reqs.add("R9", "LOB1", "CHENNAI", "ROLE1", 5, 0, true);
        f.reqs.reqs.put("R9", new com.ags.health.hr.candidates.shared.port.RequisitionView("R9", "J9", "T", "LOB1", "CHENNAI", "ORC-R1",
                "ROLE1", "OPEN", true, 5, 0, null));
        MappingService mapping = new MappingService(f.candidates, f.apps, f.reqs, f.assessments,
                List.of(new OrcRestrictionGuard(restrictions, Fakes.clock())), id -> { }, new MappingScenarioResolver(f.catalog), f.actions,
                f.mover, f.audit, f.notifications, f.clock, new MappingService.Settings(true, false, null, "INV"));
        MappingAssessment a = mapping.assess(rec, new MappingService.AssessRequest("C1", null, null, "R9"));
        assertThat(a.has("ORC_RESTRICTED")).isTrue();
        assertThat(a.blockers().get(0).until()).isEqualTo(Fakes.NOW.plus(Duration.ofDays(60)));
    }

    @Test
    void photoMismatchRejectionIsHighlighted() {
        PanelStore.Schedule s = schedule();
        panel.decide(panelist, s.id(), new PanelService.DecisionRequest("REJECT", "PHOTO_MISMATCH", "Different person"));
        assertThat(f.db.auditRows("PHOTO_MISMATCH_FLAGGED")).hasSize(1);
    }

    @Test
    void orcChangeFollowsSameOrDifferentPanelPath() {
        PanelStore.Schedule s = schedule();
        panel.decide(panelist, s.id(), new PanelService.DecisionRequest("SELECT", null, "Strong"));
        assertThatThrownBy(() -> panel.changeOrc(rec, "A1", new PanelService.OrcChangeRequest("R3", "SAME_PANEL", "move")))
                .hasMessageContaining("same LOB");
        panel.changeOrc(rec, "A1", new PanelService.OrcChangeRequest("R2", "SAME_PANEL", "Opening moved"));
        assertThat(f.apps.find("A1").orElseThrow().status()).isEqualTo(Statuses.PANEL_SELECTED);
        assertThat(f.apps.find("A1").orElseThrow().requisitionId()).isEqualTo("R2");
        f.apps.add("A2", "C2", "R1", Statuses.PANEL_ON_HOLD, "rec1", "LOB1", "CHENNAI", "ROLE1");
        f.db.jdbc.update("INSERT INTO cand_panel_schedule (id, application_id, candidate_id, round_no, lob, location, orc_id, panelist_ids, "
                + "mode, starts_at, ends_at, status, created_by, created_at) VALUES ('S2', 'A2', 'C2', 1, 'LOB1', 'CHENNAI', 'ORC-R1', 'pan1', "
                + "'ONLINE', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP, 'COMPLETED', 'rec1', CURRENT_TIMESTAMP)");
        panel.changeOrc(rec, "A2", new PanelService.OrcChangeRequest("R3", "DIFFERENT_PANEL", "New LOB"));
        assertThat(f.apps.find("A2").orElseThrow().status()).isEqualTo(Statuses.PANEL_YET_TO_SCHEDULE);
    }

    @Test
    void recordingsAreValidatedAndEveryViewIsAudited() {
        PanelStore.Schedule s = schedule();
        byte[] mp4 = new byte[]{0, 0, 0, 24, 'f', 't', 'y', 'p', 'i', 's', 'o', 'm', 0, 0};
        assertThatThrownBy(() -> panel.uploadRecording(panelist, s.id(), "not a video at all".getBytes(), "r.mp4"))
                .hasMessageContaining("Allowed");
        PanelStore.Recording r = panel.uploadRecording(panelist, s.id(), mp4, "round1.mp4");
        assertThatThrownBy(() -> panel.recordingUrl(rec, r.id())).hasMessageContaining("PANEL:RECORDING_VIEW");
        Caller reviewer = Fakes.recruiter("tl", "PANEL:RECORDING_VIEW");
        assertThat(panel.recordingUrl(reviewer, r.id()).toString()).contains("p5/panel/A1");
        panel.review(reviewer, r.id(), "Clear audio, decision supported");
        assertThat(f.db.auditRows("PANEL_RECORDING_VIEWED")).hasSize(1);
    }
}
