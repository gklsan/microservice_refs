package com.ags.health.hr.candidates.shared.config;

import com.ags.health.hr.candidates.shared.client.JobServicesRequisitionClient;
import com.ags.health.hr.candidates.shared.domain.StageCatalog;
import com.ags.health.hr.candidates.shared.domain.TabMovementPolicy;
import com.ags.health.hr.candidates.shared.port.ApplicationPort;
import com.ags.health.hr.candidates.shared.port.CandidateAccessPort;
import com.ags.health.hr.candidates.shared.port.CandidatePort;
import com.ags.health.hr.candidates.shared.port.RequisitionPort;
import com.ags.health.hr.candidates.shared.service.ApplicantActionGuard;
import com.ags.health.hr.candidates.shared.service.CandidateGuard;
import com.ags.health.hr.candidates.shared.service.MoveGuard;
import com.ags.health.hr.candidates.shared.service.StatusMoveListener;
import com.ags.health.hr.candidates.shared.service.StatusMover;
import com.ags.health.hr.common.platform.approval.AdminApprovalClient;
import com.ags.health.hr.common.platform.approval.ApprovalPort;
import com.ags.health.hr.common.platform.assessment.AssessmentHttpClient;
import com.ags.health.hr.common.platform.assessment.AssessmentPort;
import com.ags.health.hr.common.platform.audit.AuditRecorder;
import com.ags.health.hr.common.platform.audit.AuditTableInspector;
import com.ags.health.hr.common.platform.audit.LocalAuditLogTable;
import com.ags.health.hr.common.platform.audit.SharedAuditLogSink;
import com.ags.health.hr.common.platform.caller.CallerProvider;
import com.ags.health.hr.common.platform.caller.InternalKeyVerifier;
import com.ags.health.hr.common.platform.caller.JwtCallerProvider;
import com.ags.health.hr.common.platform.db.SchemaInitializer;
import com.ags.health.hr.common.platform.http.InternalHttp;
import com.ags.health.hr.common.platform.jobs.JobLock;
import com.ags.health.hr.common.platform.jobs.ScheduledJobRunner;
import com.ags.health.hr.common.platform.notify.NotificationPort;
import com.ags.health.hr.common.platform.outbox.OutboxStore;
import com.ags.health.hr.common.platform.storage.DocumentStore;
import com.ags.health.hr.common.platform.storage.EnvelopeEncryptingDocumentStore;
import com.ags.health.hr.common.platform.storage.InMemoryDocumentStore;
import com.ags.health.hr.common.platform.storage.S3DocumentStore;
import com.ags.health.hr.common.platform.storage.StaticKeyEncryptionKeyProvider;
import com.ags.health.hr.common.platform.time.BusinessClock;
import com.ags.health.hr.common.platform.workflow.WorkflowHttpClient;
import com.amazonaws.services.s3.AmazonS3;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.ObjectProvider;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.support.TransactionTemplate;

import javax.sql.DataSource;
import java.time.Clock;
import java.time.Duration;
import java.time.ZoneId;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;

@Configuration
@EnableScheduling
@EnableConfigurationProperties(CandidateP5Properties.class)
@ConditionalOnProperty(prefix = "digihire.candidate", name = "enabled", havingValue = "true", matchIfMissing = true)
public class CandidateP5Config {

    public static final String SCHEMA = "db/p5/candidate-p5-schema.sql";
    public static final String DATA = "db/p5/candidate-p5-data.sql";

    @Bean
    public Clock p5Clock() {
        return Clock.systemUTC();
    }

    @Bean
    public BusinessClock p5BusinessClock(Clock p5Clock, CandidateP5Properties props) {
        return new BusinessClock(p5Clock, ZoneId.of(props.getJobs().getZone()));
    }

    @Bean(initMethod = "run")
    @ConditionalOnProperty(prefix = "digihire.candidate", name = "schema-init", havingValue = "true", matchIfMissing = true)
    public SchemaInitializer p5SchemaInitializer(DataSource dataSource) {
        return new SchemaInitializer(dataSource, List.of(SCHEMA, DATA));
    }

    @Bean
    public InternalHttp p5InternalHttp(ObjectMapper mapper, CandidateP5Properties props) {
        String key = props.getSecurity().getOutboundKey() != null ? props.getSecurity().getOutboundKey()
                : props.getSecurity().getInternalKey();
        return new InternalHttp(mapper, Duration.ofSeconds(props.getClients().getTimeoutSeconds()),
                key == null ? Map.of(InternalKeyVerifier.CALLER_HEADER, props.getServiceName())
                        : Map.of(InternalKeyVerifier.HEADER, key, InternalKeyVerifier.CALLER_HEADER, props.getServiceName()));
    }

    @Bean
    @ConditionalOnMissingBean(CallerProvider.class)
    public CallerProvider p5CallerProvider(InternalHttp p5InternalHttp, CandidateP5Properties props, Clock p5Clock) {
        return new JwtCallerProvider(props.getSecurity().getJwtSecret(), p5InternalHttp, props.getClients().getAdminUrl(),
                Duration.ofSeconds(props.getSecurity().getRbacCacheSeconds()), p5Clock);
    }

    @Bean
    public InternalKeyVerifier p5InternalKeyVerifier(CandidateP5Properties props) {
        return new InternalKeyVerifier(props.getSecurity().getInternalKey(), props.getSecurity().getServiceKeys());
    }

    @Bean
    public AuditRecorder p5AuditRecorder(JdbcTemplate jdbc, ObjectMapper mapper, CallerProvider callers,
                                         CandidateP5Properties props, Clock p5Clock) {
        String table = props.getAudit().getTable();
        if (AuditTableInspector.isH2(jdbc)) {
            LocalAuditLogTable.createIfMissingOnH2(jdbc, table);
        }
        return new AuditRecorder(List.of(SharedAuditLogSink.create(jdbc, mapper, table, props.getAudit().getDetailsLength())),
                callers, props.getServiceName(), p5Clock);
    }

    @Bean
    public ApprovalPort p5ApprovalPort(InternalHttp p5InternalHttp, CandidateP5Properties props) {
        return new AdminApprovalClient(p5InternalHttp, props.getClients().getAdminUrl());
    }

    @Bean
    public AssessmentPort p5AssessmentPort(InternalHttp p5InternalHttp, CandidateP5Properties props) {
        return new AssessmentHttpClient(p5InternalHttp, props.getClients().getAssessmentUrl());
    }

    @Bean
    @ConditionalOnMissingBean(RequisitionPort.class)
    public RequisitionPort p5RequisitionPort(InternalHttp p5InternalHttp, CandidateP5Properties props) {
        return new JobServicesRequisitionClient(p5InternalHttp, props.getClients().getJobUrl());
    }

    @Bean
    public JobLock p5JobLock(JdbcTemplate jdbc, Clock p5Clock) {
        return new JobLock(jdbc, p5Clock, "cand_p5_job_lock");
    }

    @Bean
    public ScheduledJobRunner p5JobRunner(JobLock p5JobLock, CandidateP5Properties props) {
        return new ScheduledJobRunner(p5JobLock, () -> props.getJobs().isEnabled(), Duration.ofMinutes(10));
    }

    @Bean
    public OutboxStore p5OutboxStore(JdbcTemplate jdbc, ObjectMapper mapper, Clock p5Clock, CandidateP5Properties props) {
        CandidateP5Properties.Outbox o = props.getOutbox();
        return new OutboxStore(jdbc, mapper, p5Clock, "cand_p5_outbox",
                new OutboxStore.Policy(o.getMaxAttempts(), o.getBackoffBaseSeconds(), o.getBackoffMaxSeconds()));
    }

    @Bean
    public TransactionTemplate p5TransactionTemplate(PlatformTransactionManager tm) {
        return new TransactionTemplate(tm);
    }

    @Bean
    public DocumentStore p5DocumentStore(CandidateP5Properties props, ObjectProvider<AmazonS3> s3) {
        CandidateP5Properties.Storage s = props.getStorage();
        if ("S3".equals(s.getMode().toUpperCase(Locale.ROOT))) {
            AmazonS3 client = s3.getIfAvailable();
            if (client == null || s.getBucket() == null || s.getBucket().isBlank()) {
                throw new IllegalStateException("digihire.candidate.storage.mode=S3 needs an AmazonS3 bean and a bucket");
            }
            return new S3DocumentStore(client, s.getBucket(), s.getKmsKeyId());
        }
        return new InMemoryDocumentStore();
    }

    @Bean
    public EnvelopeEncryptingDocumentStore p5SecureDocumentStore(DocumentStore p5DocumentStore, CandidateP5Properties props) {
        CandidateP5Properties.Storage s = props.getStorage();
        if (s.getKekKeys() == null || s.getKekKeys().isBlank()) {
            throw new IllegalStateException("digihire.candidate.storage.kek-keys is required (keyId:base64-32-bytes)");
        }
        return new EnvelopeEncryptingDocumentStore(p5DocumentStore, new StaticKeyEncryptionKeyProvider(s.getKekKeys(), s.getKekActive()));
    }

    @Bean
    public StageCatalog p5StageCatalog(CandidateP5Properties props) {
        return new StageCatalog(props.getStages().getTabOverrides());
    }

    @Bean
    public TabMovementPolicy p5TabMovementPolicy(StageCatalog p5StageCatalog, CandidateP5Properties props) {
        return new TabMovementPolicy(p5StageCatalog, props.getStages().getTransitionOverrides());
    }

    @Bean
    public ApplicantActionGuard p5ApplicantActionGuard(CandidateP5Properties props) {
        return new ApplicantActionGuard(props.getApplicant().isAllowScopeAll());
    }

    @Bean
    public CandidateGuard p5CandidateGuard(CandidatePort candidates, CandidateAccessPort access) {
        return new CandidateGuard(candidates, access);
    }

    @Bean
    public StatusMover p5StatusMover(ApplicationPort applications, ApplicantActionGuard guard, InternalHttp p5InternalHttp,
                                     TabMovementPolicy policy, StageCatalog catalog, AuditRecorder audit,
                                     NotificationPort notifications, ObjectProvider<StatusMoveListener> listeners,
                                     ObjectProvider<MoveGuard> moveGuards,
                                     Clock p5Clock, CandidateP5Properties props) {
        return new StatusMover(applications, guard, props.isWorkflowEnabled()
                ? new WorkflowHttpClient(p5InternalHttp, props.getClients().getWorkflowUrl()) : null, policy, catalog, audit,
                notifications, listeners.orderedStream().toList(), p5Clock, new HashSet<>(props.getStages().getResetReasons()),
                moveGuards.orderedStream().toList());
    }
}
