package com.ags.health.hr.candidates.offer;

import com.ags.health.hr.candidates.shared.port.ApplicationView;
import com.ags.health.hr.candidates.shared.service.ApplicantActionGuard;
import com.ags.health.hr.candidates.shared.service.StatusMover;
import com.ags.health.hr.common.platform.audit.AuditRecorder;
import com.ags.health.hr.common.platform.caller.Caller;
import com.ags.health.hr.common.platform.error.PlatformException;

import java.util.Map;
import java.util.Set;

public class OfferService {

    public static final String PUSH = "OFFER:PUSH";
    public static final String VIEW = "OFFER:VIEW";

    private final StatusMover mover;
    private final ApplicantActionGuard guard;
    private final OfferDataPort data;
    private final OfferIntegrationPort integration;
    private final AuditRecorder audit;
    private final Set<String> pushableStatuses;

    public OfferService(StatusMover mover, ApplicantActionGuard guard, OfferDataPort data, OfferIntegrationPort integration,
                        AuditRecorder audit, Set<String> pushableStatuses) {
        this.mover = mover;
        this.guard = guard;
        this.data = data;
        this.integration = integration;
        this.audit = audit;
        this.pushableStatuses = Set.copyOf(pushableStatuses);
    }

    public OfferIntegrationPort.PushResult push(Caller caller, String applicationId) {
        ApplicationView app = mover.load(applicationId);
        guard.require(caller, app, PUSH);
        if (!pushableStatuses.contains(app.status())) {
            throw PlatformException.conflict("OFFER_NOT_READY", "Offer can be pushed only at " + pushableStatuses);
        }
        if (data == null) {
            throw new PlatformException(501, "OFFER_DATA_ADAPTER_MISSING", "No OfferDataPort adapter is configured", null);
        }
        Map<String, Object> payload = data.offerData(app.id())
                .orElseThrow(() -> PlatformException.notFound("Offer details", applicationId));
        OfferIntegrationPort.PushResult r = integration.push(app.id(), app.candidateId(), caller.userId(), payload);
        boolean invalid = "INVALID".equals(r.status());
        audit.record("INTEGRATION", invalid ? "OFFER_PUSH_REJECTED" : "OFFER_PUSH_REQUESTED", "APPLICATION", app.id(), app.candidateId(),
                invalid ? AuditRecorder.FAILURE : AuditRecorder.SUCCESS, null,
                AuditRecorder.details("syncId", r.syncId(), "status", r.status(), "errors", r.errors()));
        if (invalid) {
            throw PlatformException.unprocessable("OFFER_INVALID", "Offer failed pre-push validation", r.errors());
        }
        return r;
    }

    public Map<String, Object> status(Caller caller, String applicationId) {
        ApplicationView app = mover.load(applicationId);
        if (!caller.hasAny(VIEW, PUSH)) {
            throw PlatformException.forbidden("PERMISSION_DENIED", "Missing permission " + VIEW);
        }
        guard.require(caller, app, null);
        return integration.status(app.id());
    }
}
