package com.ags.health.hr.candidates.assessmentbridge;

public interface AssessmentEventHandler {

    boolean supports(AssessmentEvent event);

    String handle(AssessmentEvent event);
}
