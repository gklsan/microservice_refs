package com.ags.health.hr.candidates.offer;

import java.util.Map;
import java.util.Optional;

public interface OfferDataPort {

    Optional<Map<String, Object>> offerData(String applicationId);
}
