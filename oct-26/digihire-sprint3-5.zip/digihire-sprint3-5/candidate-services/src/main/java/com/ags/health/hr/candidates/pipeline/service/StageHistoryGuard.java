package com.ags.health.hr.candidates.pipeline.service;

import com.ags.health.hr.candidates.assessmentbridge.NextStageRouting;
import com.ags.health.hr.candidates.pipeline.domain.StageHistoryValidator;
import com.ags.health.hr.candidates.shared.domain.StageCatalog;
import com.ags.health.hr.candidates.shared.domain.Tab;
import com.ags.health.hr.candidates.shared.port.ApplicationView;
import com.ags.health.hr.candidates.shared.port.StageHistoryPort;
import com.ags.health.hr.candidates.shared.service.MoveGuard;
import com.ags.health.hr.candidates.shared.service.StatusMover;
import com.ags.health.hr.common.platform.assessment.AssessmentPort;
import com.ags.health.hr.common.platform.caller.Caller;
import com.ags.health.hr.common.platform.error.PlatformException;

import java.time.Clock;
import java.util.List;
import java.util.Map;

public class StageHistoryGuard implements MoveGuard {

    private final StageHistoryPort history;
    private final AssessmentPort assessments;
    private final NextStageRouting routing;
    private final StageCatalog catalog;
    private final StageHistoryValidator validator = new StageHistoryValidator();
    private final Clock clock;

    public StageHistoryGuard(StageHistoryPort history, AssessmentPort assessments, NextStageRouting routing, StageCatalog catalog,
                             Clock clock) {
        this.history = history;
        this.assessments = assessments;
        this.routing = routing;
        this.catalog = catalog;
        this.clock = clock;
    }

    @Override
    public void check(Caller caller, ApplicationView app, String to, StatusMover.Move move) {
        if (app.status() == null || catalog.tabOf(app.status()) != Tab.PIPELINE) {
            return;
        }
        Tab target = catalog.tabOf(to);
        if (target == Tab.PIPELINE || target == Tab.REJECTED || target == Tab.APPLICANT || target == Tab.HR_INTERVIEW) {
            return;
        }
        List<AssessmentPort.ValidScore> scores;
        try {
            scores = assessments.validScores(app.candidateId());
        } catch (RuntimeException e) {
            throw PlatformException.unavailable("ASSESSMENT_UNAVAILABLE", "Assessment scores could not be checked");
        }
        StageHistoryValidator.Check c = validator.check(to, history.history(app.id()), scores,
                routing.requiresVersant(app.lob(), app.roleCode()), clock.instant());
        if (!c.ok()) {
            throw new PlatformException(409, "STAGE_HISTORY_INVALID", "Prior stage history does not allow moving to " + to,
                    c.problems().stream().map(p -> Map.<String, Object>of("code", p)).toList());
        }
    }
}
