package com.ags.health.hr.candidates.offer;

import com.ags.health.hr.candidates.assessmentbridge.AssessmentEvent;
import com.ags.health.hr.candidates.assessmentbridge.AssessmentEventHandler;
import com.ags.health.hr.candidates.assessmentbridge.AssessmentExceptionStore;
import com.ags.health.hr.candidates.shared.domain.Reasons;
import com.ags.health.hr.candidates.shared.domain.Statuses;
import com.ags.health.hr.candidates.shared.domain.TabMovementPolicy;
import com.ags.health.hr.candidates.shared.port.ApplicationPort;
import com.ags.health.hr.candidates.shared.port.ApplicationView;
import com.ags.health.hr.candidates.shared.service.StatusMover;
import com.ags.health.hr.common.platform.audit.AuditRecorder;
import com.ags.health.hr.common.platform.caller.Caller;

import java.time.Clock;
import java.util.Optional;

public class OfferOutcomeHandler implements AssessmentEventHandler {

    public static final String SOURCE = "integration-services";
    public static final String PROVIDER = "ORACLE_OFFER";

    private final ApplicationPort applications;
    private final StatusMover mover;
    private final TabMovementPolicy policy;
    private final AssessmentExceptionStore exceptions;
    private final AuditRecorder audit;
    private final Clock clock;
    private final String revertStatus;
    private final String rejectedTemplate;
    private final Caller system = Caller.system(SOURCE);

    public OfferOutcomeHandler(ApplicationPort applications, StatusMover mover, TabMovementPolicy policy,
                               AssessmentExceptionStore exceptions, AuditRecorder audit, Clock clock, String revertStatus,
                               String rejectedTemplate) {
        this.applications = applications;
        this.mover = mover;
        this.policy = policy;
        this.exceptions = exceptions;
        this.audit = audit;
        this.clock = clock;
        this.revertStatus = revertStatus;
        this.rejectedTemplate = rejectedTemplate;
    }

    @Override
    public boolean supports(AssessmentEvent e) {
        return e.eventType() != null && (e.eventType().startsWith("OFFER_") || e.eventType().equals("CANDIDATE_HIRED"));
    }

    @Override
    public String handle(AssessmentEvent e) {
        Optional<ApplicationView> found = e.applicationId() == null ? Optional.empty() : applications.find(e.applicationId());
        if (found.isEmpty()) {
            return "APPLICATION_NOT_FOUND";
        }
        ApplicationView app = found.get();
        String oracleStatus = e.text("oracleStatus");
        switch (e.eventType()) {
            case "OFFER_REJECTED", "OFFER_WITHDRAWN", "OFFER_RESCINDED" -> {
                exceptions.resolveForApplication(app.id(), PROVIDER, "OFFER_CLOSED", SOURCE, clock.instant());
                if (!Statuses.OFFERED.equals(app.status())) {
                    return "IGNORED_" + app.status();
                }
                StatusMover.Move move = StatusMover.Move.to(app.id(), revertStatus, null).reason(Reasons.OFFER_REJECTED, oracleStatus)
                        .asReset().with("oracleStatus", oracleStatus).with("externalOfferId", e.text("externalOfferId"));
                if (rejectedTemplate != null) {
                    move = move.notify(rejectedTemplate);
                }
                mover.move(system, app, move);
                return "REVERTED_" + revertStatus;
            }
            case "CANDIDATE_HIRED" -> {
                if (!policy.allows(app.status(), Statuses.JOINED)) {
                    return "SKIPPED_" + app.status();
                }
                mover.move(system, app, StatusMover.Move.to(app.id(), Statuses.JOINED, null).reason("ORACLE_HIRED", null)
                        .with("oracleStatus", oracleStatus));
                return "MOVED_JOINED";
            }
            case "OFFER_PUSH_FAILED", "OFFER_PARKED" -> {
                exceptions.open(app.id(), app.candidateId(), PROVIDER, null, e.text("syncId"), e.eventType().substring(6),
                        e.text("error"), clock.instant());
                return "EXCEPTION_OPENED";
            }
            default -> {
                exceptions.resolveForApplication(app.id(), PROVIDER, e.eventType(), SOURCE, clock.instant());
                audit.recordQuietly("INTEGRATION", e.eventType(), "APPLICATION", app.id(), app.candidateId(), AuditRecorder.SUCCESS,
                        oracleStatus, AuditRecorder.details("externalOfferId", e.text("externalOfferId"), "syncId", e.text("syncId")));
                return "RECORDED";
            }
        }
    }
}
