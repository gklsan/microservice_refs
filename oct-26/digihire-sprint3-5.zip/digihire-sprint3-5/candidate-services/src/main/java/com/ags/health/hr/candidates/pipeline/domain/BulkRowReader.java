package com.ags.health.hr.candidates.pipeline.domain;

import java.util.List;

public interface BulkRowReader {

    String HEADER_APPLICATION = "applicationId";
    String HEADER_STATUS = "targetStatus";
    String HEADER_REASON = "reasonCode";
    String HEADER_REMARKS = "remarks";

    boolean supports(String fileName);

    List<BulkRow> read(byte[] content, int maxRows);
}
