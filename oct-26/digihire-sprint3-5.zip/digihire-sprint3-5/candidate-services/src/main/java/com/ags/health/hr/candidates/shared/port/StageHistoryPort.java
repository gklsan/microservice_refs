package com.ags.health.hr.candidates.shared.port;

import java.util.List;

public interface StageHistoryPort {

    List<StageEntry> history(String applicationId);
}
