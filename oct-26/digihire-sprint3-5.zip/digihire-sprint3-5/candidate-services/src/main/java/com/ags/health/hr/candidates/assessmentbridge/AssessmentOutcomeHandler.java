package com.ags.health.hr.candidates.assessmentbridge;

import com.ags.health.hr.candidates.shared.domain.Reasons;
import com.ags.health.hr.candidates.shared.domain.StageCatalog;
import com.ags.health.hr.candidates.shared.domain.Statuses;
import com.ags.health.hr.candidates.shared.domain.Tab;
import com.ags.health.hr.candidates.shared.domain.TabMovementPolicy;
import com.ags.health.hr.candidates.shared.port.ApplicationPort;
import com.ags.health.hr.candidates.shared.port.ApplicationView;
import com.ags.health.hr.candidates.shared.service.StatusMover;
import com.ags.health.hr.common.platform.caller.Caller;
import com.ags.health.hr.common.platform.time.BusinessClock;

import java.util.Optional;
import java.util.Set;

public class AssessmentOutcomeHandler implements AssessmentEventHandler {

    public static final String SOURCE = "assessment-services";

    private static final Set<String> TYPES = Set.of("ASSESSMENT_INVITED", "ASSESSMENT_COMPLETED", "ASSESSMENT_FAILED",
            "ASSESSMENT_NOT_TAKEN", "ASSESSMENT_LINK_EXPIRED", "ASSESSMENT_INVITE_FAILED", "ASSESSMENT_RESCHEDULED",
            "ASSESSMENT_CANCELLED", "ASSESSMENT_SCORE_EXPIRED");
    private static final Set<Tab> SCORE_DEPENDENT = Set.of(Tab.ASSESSMENT, Tab.VERSANT, Tab.PANEL);

    private final ApplicationPort applications;
    private final StatusMover mover;
    private final TabMovementPolicy policy;
    private final StageCatalog catalog;
    private final NextStageRouting routing;
    private final AssessmentExceptionStore exceptions;
    private final BusinessClock clock;
    private final Caller system = Caller.system(SOURCE);

    public AssessmentOutcomeHandler(ApplicationPort applications, StatusMover mover, TabMovementPolicy policy,
                                    StageCatalog catalog, NextStageRouting routing, AssessmentExceptionStore exceptions,
                                    BusinessClock clock) {
        this.applications = applications;
        this.mover = mover;
        this.policy = policy;
        this.catalog = catalog;
        this.routing = routing;
        this.exceptions = exceptions;
        this.clock = clock;
    }

    @Override
    public boolean supports(AssessmentEvent event) {
        return event.eventType() != null && TYPES.contains(event.eventType());
    }

    @Override
    public String handle(AssessmentEvent e) {
        if (e.applicationId() == null || e.applicationId().isBlank()) {
            return "NO_APPLICATION";
        }
        Optional<ApplicationView> found = applications.find(e.applicationId());
        if (found.isEmpty()) {
            return "APPLICATION_NOT_FOUND";
        }
        ApplicationView app = found.get();
        if (!catalog.isOpen(app.status())) {
            return "APPLICATION_CLOSED";
        }
        String provider = e.provider() == null ? "UNKNOWN" : e.provider();
        ProviderStatuses s = ProviderStatuses.of(provider);
        String attempt = e.text("attemptId") != null ? e.text("attemptId") : e.aggregateId();
        String code = e.text("assessmentCode");
        return switch (e.eventType()) {
            case "ASSESSMENT_INVITED" -> {
                exceptions.resolveForApplication(app.id(), provider, "REINVITED", SOURCE, clock.now());
                yield moveIfAllowed(app, s.yetToStart(), null, e);
            }
            case "ASSESSMENT_COMPLETED" -> {
                exceptions.resolveForApplication(app.id(), provider, "COMPLETED", SOURCE, clock.now());
                String r = moveIfAllowed(app, s.completed(), null, e);
                if (!r.startsWith("MOVED") || !routing.autoAdvance()) {
                    yield r;
                }
                ApplicationView after = applications.find(app.id()).orElse(app);
                String next = s == ProviderStatuses.VERSANT ? routing.afterVersant() : routing.afterAssessment(after);
                yield r + "," + moveIfAllowed(after, next, Reasons.WORKFLOW_AUTO, e);
            }
            case "ASSESSMENT_FAILED" -> {
                exceptions.resolveForApplication(app.id(), provider, "FAILED", SOURCE, clock.now());
                yield moveIfAllowed(app, s.failed(), e.text("coolingUntil") == null ? null : Reasons.COOLING_PERIOD, e);
            }
            case "ASSESSMENT_NOT_TAKEN", "ASSESSMENT_LINK_EXPIRED", "ASSESSMENT_INVITE_FAILED" -> {
                String kind = e.eventType().substring("ASSESSMENT_".length());
                exceptions.open(app.id(), app.candidateId(), provider, code, attempt, kind, e.text("status"), clock.now());
                if (s.notTaken() != null && !"INVITE_FAILED".equals(kind)) {
                    yield "EXCEPTION_OPENED," + moveIfAllowed(app, s.notTaken(), kind, e);
                }
                yield "EXCEPTION_OPENED";
            }
            case "ASSESSMENT_RESCHEDULED" -> {
                exceptions.resolveForApplication(app.id(), provider, "RESCHEDULED", SOURCE, clock.now());
                if (app.status().equals(s.yetToStart())) {
                    yield "UNCHANGED";
                }
                yield reset(app, s.yetToStart(), "RESCHEDULED", e);
            }
            case "ASSESSMENT_CANCELLED" -> "IGNORED";
            case "ASSESSMENT_SCORE_EXPIRED" -> {
                Tab tab = catalog.tabOf(app.status());
                if (!SCORE_DEPENDENT.contains(tab) || catalog.lockedForRemap(app.status())) {
                    yield "NOT_AFFECTED";
                }
                yield reset(app, Statuses.PIPELINE, Reasons.FRESHER_PIPELINE, e);
            }
            default -> "IGNORED";
        };
    }

    private String moveIfAllowed(ApplicationView app, String to, String reason, AssessmentEvent e) {
        if (to == null || to.equals(app.status())) {
            return "UNCHANGED";
        }
        if (!policy.allows(app.status(), to)) {
            return "SKIPPED_" + app.status() + "_TO_" + to;
        }
        mover.move(system, app, StatusMover.Move.to(app.id(), to, null).reason(reason, null)
                .with("assessmentEventId", String.valueOf(e.id())).with("attemptId", e.text("attemptId"))
                .with("provider", e.provider()).with("score", e.text("score")).with("coolingUntil", e.text("coolingUntil")));
        return "MOVED_" + to;
    }

    private String reset(ApplicationView app, String to, String reason, AssessmentEvent e) {
        mover.move(system, app, StatusMover.Move.to(app.id(), to, null).reason(reason, null).asReset()
                .with("assessmentEventId", String.valueOf(e.id())).with("attemptId", e.text("attemptId"))
                .with("provider", e.provider()));
        return "RESET_" + to;
    }
}
