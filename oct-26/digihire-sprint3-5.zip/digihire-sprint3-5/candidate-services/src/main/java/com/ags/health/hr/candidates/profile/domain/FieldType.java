package com.ags.health.hr.candidates.profile.domain;

public enum FieldType { TEXT, NAME, EMAIL, MOBILE, PAN, AADHAAR, PASSPORT, PINCODE, DATE, DOB, CHOICE, NUMBER, BOOLEAN }
