package com.ags.health.hr.candidates.panel.web;

import com.ags.health.hr.candidates.panel.service.PanelService;
import com.ags.health.hr.candidates.panel.store.PanelStore;
import com.ags.health.hr.common.platform.caller.CallerProvider;
import com.ags.health.hr.common.platform.error.PlatformException;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.Map;

@ConditionalOnProperty(prefix = "digihire.candidate.panel", name = "enabled", havingValue = "true", matchIfMissing = true)
@RestController
public class PanelController {

    public record NotesRequest(String notes) {
    }

    private final PanelService panel;
    private final CallerProvider callers;

    public PanelController(PanelService panel, CallerProvider callers) {
        this.panel = panel;
        this.callers = callers;
    }

    @PostMapping("/applicants/{applicationId}/panel")
    public PanelStore.Schedule schedule(@PathVariable String applicationId, @RequestBody PanelService.ScheduleRequest body) {
        return panel.schedule(callers.require(), applicationId, body);
    }

    @GetMapping("/applicants/{applicationId}/panel")
    public Map<String, Object> overview(@PathVariable String applicationId) {
        return panel.overview(callers.require(), applicationId);
    }

    @PostMapping("/applicants/{applicationId}/panel/orc-change")
    public PanelStore.Schedule changeOrc(@PathVariable String applicationId, @RequestBody PanelService.OrcChangeRequest body) {
        return panel.changeOrc(callers.require(), applicationId, body);
    }

    @PostMapping("/panel-schedules/{scheduleId}/reschedule")
    public PanelStore.Schedule reschedule(@PathVariable String scheduleId, @RequestBody PanelService.RescheduleRequest body) {
        return panel.reschedule(callers.require(), scheduleId, body);
    }

    @PostMapping("/panel-schedules/{scheduleId}/decision")
    public PanelStore.Schedule decide(@PathVariable String scheduleId, @RequestBody PanelService.DecisionRequest body) {
        return panel.decide(callers.require(), scheduleId, body);
    }

    @PostMapping("/panel-schedules/{scheduleId}/recordings/upload-url")
    public PanelService.UploadTicket uploadUrl(@PathVariable String scheduleId, @RequestParam(required = false) String contentType) {
        return panel.recordingUploadUrl(callers.require(), scheduleId, contentType);
    }

    @PostMapping(value = "/panel-schedules/{scheduleId}/recordings", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public PanelStore.Recording upload(@PathVariable String scheduleId, @RequestParam MultipartFile file) {
        try {
            return panel.uploadRecording(callers.require(), scheduleId, file.getBytes(), file.getOriginalFilename());
        } catch (IOException e) {
            throw PlatformException.badRequest("FILE_UNREADABLE", "Uploaded file could not be read");
        }
    }

    @PostMapping("/panel-recordings/{recordingId}/confirm")
    public PanelStore.Recording confirm(@PathVariable String recordingId) {
        return panel.confirmUpload(callers.require(), recordingId);
    }

    @GetMapping("/panel-recordings/{recordingId}/url")
    public Map<String, Object> url(@PathVariable String recordingId) {
        return Map.of("url", panel.recordingUrl(callers.require(), recordingId).toString());
    }

    @PostMapping("/panel-recordings/{recordingId}/review")
    public PanelStore.Recording review(@PathVariable String recordingId, @RequestBody NotesRequest body) {
        return panel.review(callers.require(), recordingId, body.notes());
    }
}
