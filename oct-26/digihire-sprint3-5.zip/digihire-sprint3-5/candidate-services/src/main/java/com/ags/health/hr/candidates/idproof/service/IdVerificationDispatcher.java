package com.ags.health.hr.candidates.idproof.service;

import com.ags.health.hr.candidates.assessmentbridge.OutboxDispatcher;
import com.ags.health.hr.common.platform.outbox.OutboxEvent;

public class IdVerificationDispatcher implements OutboxDispatcher {

    private final IdProofService service;

    public IdVerificationDispatcher(IdProofService service) {
        this.service = service;
    }

    @Override
    public String eventType() {
        return IdProofService.VERIFY_EVENT;
    }

    @Override
    public boolean ready() {
        return true;
    }

    @Override
    public void deliver(OutboxEvent event) {
        service.runVerification(event.payload().path("documentId").asText());
    }
}
