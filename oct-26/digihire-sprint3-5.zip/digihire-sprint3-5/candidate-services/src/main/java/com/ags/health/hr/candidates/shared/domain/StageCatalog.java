package com.ags.health.hr.candidates.shared.domain;

import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

public class StageCatalog {

    private static final Set<String> TERMINAL = Set.of(Statuses.JOINED, Statuses.REMAPPED);
    private static final Set<String> LOCKED_FOR_REMAP = Set.of(Statuses.PANEL_SELECTED, Statuses.SHORTLISTED,
            Statuses.OFFERED, Statuses.JOINED, Statuses.REMAPPED);

    private final Map<String, Tab> tabs;

    public StageCatalog(Map<String, String> overrides) {
        Map<String, Tab> m = new LinkedHashMap<>(defaults());
        if (overrides != null) {
            overrides.forEach((status, tab) -> m.put(norm(status), Tab.valueOf(norm(tab))));
        }
        this.tabs = Collections.unmodifiableMap(m);
    }

    public static StageCatalog standard() {
        return new StageCatalog(Map.of());
    }

    public static Map<String, Tab> defaults() {
        Map<String, Tab> m = new LinkedHashMap<>();
        m.put(Statuses.REGISTERED, Tab.MAP_CANDIDATE);
        m.put(Statuses.CREATED, Tab.APPLICANT);
        m.put(Statuses.WALKEDIN, Tab.APPLICANT);
        m.put(Statuses.WAITING_FOR_HRROUND, Tab.HR_INTERVIEW);
        m.put(Statuses.INTERVIEW_INPROGRESS, Tab.HR_INTERVIEW);
        m.put(Statuses.WAITING_FOR_DEVICE, Tab.ASSESSMENT);
        m.put(Statuses.DEVICE_ALLOCATION_FAILED, Tab.ASSESSMENT);
        m.put(Statuses.ASSESEMENT_YET_TO_START, Tab.ASSESSMENT);
        m.put(Statuses.ASSESEMENT_INPROGRESS, Tab.ASSESSMENT);
        m.put(Statuses.ASSESEMENT_COMPLETED, Tab.ASSESSMENT);
        m.put(Statuses.ASSESEMENT_FAILED, Tab.REJECTED);
        m.put(Statuses.VERSANT_YET_TO_START, Tab.VERSANT);
        m.put(Statuses.VERSANT_INPROGRESS, Tab.VERSANT);
        m.put(Statuses.VERSANT_COMPLETED, Tab.VERSANT);
        m.put(Statuses.VERSANT_NOT_TAKEN, Tab.VERSANT);
        m.put(Statuses.VERSANT_FAILED, Tab.REJECTED);
        m.put(Statuses.PANEL_YET_TO_SCHEDULE, Tab.PANEL);
        m.put(Statuses.PANEL_INPROGRESS, Tab.PANEL);
        m.put(Statuses.PANEL_ON_HOLD, Tab.PANEL);
        m.put(Statuses.PANEL_SELECTED, Tab.OFFER);
        m.put(Statuses.SHORTLISTED, Tab.OFFER);
        m.put(Statuses.OFFERED, Tab.OFFER);
        m.put(Statuses.DEFERRED, Tab.PIPELINE);
        m.put(Statuses.WITHHELD, Tab.PIPELINE);
        m.put(Statuses.PIPELINE, Tab.PIPELINE);
        m.put(Statuses.HR_REJECTED, Tab.REJECTED);
        m.put(Statuses.PANEL_REJECTED, Tab.REJECTED);
        m.put(Statuses.PANEL_DECLINED, Tab.REJECTED);
        m.put(Statuses.JOINED, Tab.JOINED);
        m.put(Statuses.REMAPPED, Tab.CLOSED);
        return m;
    }

    public Tab tabOf(String status) {
        if (status == null) {
            return Tab.MAP_CANDIDATE;
        }
        Tab t = tabs.get(norm(status));
        if (t == null) {
            throw new IllegalArgumentException("Unknown application status " + status);
        }
        return t;
    }

    public boolean known(String status) {
        return status != null && tabs.containsKey(norm(status));
    }

    public boolean isTerminal(String status) {
        return status != null && TERMINAL.contains(norm(status));
    }

    public boolean isOpen(String status) {
        if (status == null || isTerminal(status)) {
            return false;
        }
        Tab t = tabs.get(norm(status));
        return t != null && t != Tab.REJECTED && t != Tab.CLOSED && t != Tab.JOINED;
    }

    public boolean isRejected(String status) {
        return status != null && tabs.get(norm(status)) == Tab.REJECTED;
    }

    public boolean lockedForRemap(String status) {
        return status != null && LOCKED_FOR_REMAP.contains(norm(status));
    }

    public Map<String, Tab> all() {
        return tabs;
    }

    static String norm(String v) {
        return v.trim().toUpperCase(Locale.ROOT);
    }
}
