package com.ags.health.hr.candidates.shared.domain;

public enum Tab { MAP_CANDIDATE, APPLICANT, HR_INTERVIEW, ASSESSMENT, VERSANT, PANEL, PIPELINE, OFFER, JOINED, REJECTED, CLOSED }
