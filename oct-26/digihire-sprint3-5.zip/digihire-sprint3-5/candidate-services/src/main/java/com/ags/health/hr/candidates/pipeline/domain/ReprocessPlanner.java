package com.ags.health.hr.candidates.pipeline.domain;

import com.ags.health.hr.candidates.shared.port.StageEntry;

import java.time.Instant;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import static com.ags.health.hr.candidates.shared.domain.Statuses.*;

public class ReprocessPlanner {

    public record Plan(String resumeAt, String basis, boolean scoreReused) {
    }

    public Plan plan(List<StageEntry> history, boolean validScore, boolean versantRequired, Instant now) {
        Set<String> seen = history == null ? Set.of() : history.stream().map(StageEntry::status).collect(Collectors.toSet());
        if (seen.contains(PANEL_SELECTED) && validScore) {
            return new Plan(SHORTLISTED, "PANEL_SELECTED_EARLIER", true);
        }
        if (seen.contains(ASSESEMENT_COMPLETED)) {
            if (!validScore) {
                return new Plan(ASSESEMENT_YET_TO_START, "SCORE_EXPIRED_REEVALUATION", false);
            }
            if (versantRequired && !seen.contains(VERSANT_COMPLETED)) {
                return new Plan(VERSANT_YET_TO_START, "ASSESSMENT_CLEARED", true);
            }
            return new Plan(PANEL_YET_TO_SCHEDULE, versantRequired ? "VERSANT_CLEARED" : "ASSESSMENT_CLEARED", true);
        }
        if (seen.contains(INTERVIEW_INPROGRESS) || seen.contains(WAITING_FOR_DEVICE) || seen.contains(ASSESEMENT_YET_TO_START)) {
            return new Plan(ASSESEMENT_YET_TO_START, "HR_ROUND_CLEARED", false);
        }
        return new Plan(WAITING_FOR_HRROUND, "NO_PRIOR_ROUND", false);
    }
}
