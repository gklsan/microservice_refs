package com.ags.health.hr.candidates.hrround.store;

import com.ags.health.hr.candidates.hrround.domain.Competency;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

import java.sql.Timestamp;
import java.time.Instant;
import java.util.List;

public class CompetencyStore {

    private static final String COLUMNS = "code, name, lob, role_code, weight, max_rating, min_rating, mandatory, active, sort_order";
    private static final RowMapper<Competency> ROW = (rs, i) -> new Competency(rs.getString(1), rs.getString(2), rs.getString(3),
            rs.getString(4), rs.getInt(5), rs.getInt(6), rs.getInt(7), rs.getBoolean(8), rs.getBoolean(9), rs.getInt(10));

    private final JdbcTemplate jdbc;

    public CompetencyStore(JdbcTemplate jdbc) {
        this.jdbc = jdbc;
    }

    public List<Competency> all(boolean activeOnly) {
        return jdbc.query("SELECT " + COLUMNS + " FROM cand_competency" + (activeOnly ? " WHERE active = TRUE" : "")
                + " ORDER BY sort_order, code", ROW);
    }

    public void upsert(Competency c, String actor, Instant at) {
        int n = jdbc.update("UPDATE cand_competency SET name = ?, lob = ?, role_code = ?, weight = ?, max_rating = ?, min_rating = ?, "
                        + "mandatory = ?, active = ?, sort_order = ?, updated_by = ?, updated_at = ? WHERE code = ?",
                c.name(), c.lob(), c.roleCode(), c.weight(), c.maxRating(), c.minRating(), c.mandatory(), c.active(), c.sortOrder(),
                actor, Timestamp.from(at), c.code());
        if (n == 0) {
            jdbc.update("INSERT INTO cand_competency (" + COLUMNS + ", updated_by, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
                    c.code(), c.name(), c.lob(), c.roleCode(), c.weight(), c.maxRating(), c.minRating(), c.mandatory(), c.active(),
                    c.sortOrder(), actor, Timestamp.from(at));
        }
    }
}
