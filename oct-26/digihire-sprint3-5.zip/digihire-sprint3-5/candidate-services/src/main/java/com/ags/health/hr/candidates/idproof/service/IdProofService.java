package com.ags.health.hr.candidates.idproof.service;

import com.ags.health.hr.candidates.idproof.domain.IdDocument;
import com.ags.health.hr.candidates.idproof.domain.IdDocumentType;
import com.ags.health.hr.candidates.idproof.domain.VerificationBadge;
import com.ags.health.hr.candidates.idproof.domain.VerificationStatus;
import com.ags.health.hr.candidates.idproof.port.IdentityHintPort;
import com.ags.health.hr.candidates.idproof.port.IdentityVerificationPort;
import com.ags.health.hr.candidates.idproof.store.IdDocumentStore;
import com.ags.health.hr.candidates.shared.port.CandidateView;
import com.ags.health.hr.candidates.shared.service.CandidateGuard;
import com.ags.health.hr.candidates.shared.service.Remarks;
import com.ags.health.hr.common.platform.audit.AuditRecorder;
import com.ags.health.hr.common.platform.caller.Caller;
import com.ags.health.hr.common.platform.crypto.IdentifierHasher;
import com.ags.health.hr.common.platform.error.PlatformException;
import com.ags.health.hr.common.platform.outbox.OutboxStore;
import com.ags.health.hr.common.platform.storage.EnvelopeEncryptingDocumentStore;
import com.ags.health.hr.common.platform.storage.FileInspector;
import com.ags.health.hr.common.platform.storage.StoredDocument;
import com.ags.health.hr.common.platform.validation.IdentityValidators;
import com.ags.health.hr.common.platform.validation.Masking;
import org.springframework.transaction.annotation.Transactional;

import java.nio.charset.StandardCharsets;
import java.time.Clock;
import java.time.Instant;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;

public class IdProofService {

    public static final String UPLOAD = "CANDIDATE:UPDATE";
    public static final String VIEW = "CANDIDATE_ID_DOC:VIEW";
    public static final String REVEAL = "CANDIDATE_ID_DOC:REVEAL";
    public static final String VERIFY = "CANDIDATE_ID_DOC:VERIFY";
    public static final String VERIFY_EVENT = "ID_VERIFICATION_REQUESTED";

    private static final Set<FileInspector.Kind> ALLOWED = Set.of(FileInspector.Kind.PDF, FileInspector.Kind.JPEG, FileInspector.Kind.PNG);

    public record DocumentView(String id, String type, String numberMasked, String status, String contentType, long size,
                               Instant uploadedAt, Instant verifiedAt, String provider, String note) {

        static DocumentView of(IdDocument d) {
            return new DocumentView(d.id(), d.type().name(), d.numberMasked(), d.status().name(), d.contentType(), d.size(),
                    d.uploadedAt(), d.verifiedAt(), d.provider(), d.verificationNote());
        }
    }

    public record Summary(String candidateId, VerificationBadge badge, List<DocumentView> documents) {
    }

    public record Download(byte[] content, String contentType, String fileName) {
    }

    public record Settings(long maxBytes, boolean autoVerify) {
    }

    private final IdDocumentStore store;
    private final EnvelopeEncryptingDocumentStore files;
    private final IdentifierHasher hasher;
    private final IdentityVerificationPort verifier;
    private final IdentityHintPort hints;
    private final CandidateGuard guard;
    private final OutboxStore outbox;
    private final AuditRecorder audit;
    private final Clock clock;
    private final Settings settings;

    public IdProofService(IdDocumentStore store, EnvelopeEncryptingDocumentStore files, IdentifierHasher hasher,
                          IdentityVerificationPort verifier, IdentityHintPort hints, CandidateGuard guard, OutboxStore outbox,
                          AuditRecorder audit, Clock clock, Settings settings) {
        this.store = store;
        this.files = files;
        this.hasher = hasher;
        this.verifier = verifier;
        this.hints = hints;
        this.guard = guard;
        this.outbox = outbox;
        this.audit = audit;
        this.clock = clock;
        this.settings = settings;
    }

    @Transactional
    public DocumentView upload(Caller caller, String candidateId, String type, String number, byte[] content, String fileName) {
        CandidateView c = guard.load(candidateId);
        CandidateGuard.Basis basis = guard.require(caller, c, UPLOAD, true);
        IdDocumentType t = IdDocumentType.parse(type);
        IdentityValidators.check(t.kind(), number).ifPresent(code -> {
            throw PlatformException.badRequest(code, t + " number is not valid");
        });
        String normalised = IdentityValidators.normalise(t.kind(), number);
        FileInspector.Kind kind = FileInspector.require(content, fileName, settings.maxBytes(), ALLOWED);
        String hash = hasher.hash(t.kind(), normalised);
        List<String> others = store.otherCandidatesWithNumber(hash, c.id());
        Instant now = clock.instant();
        String id = UUID.randomUUID().toString();
        String key = "p5/id-docs/" + c.id() + "/" + id;
        StoredDocument stored = files.put(key, content, kind.contentType(), Map.of("candidate", c.id(), "type", t.name()));
        files.put(key + ".number", normalised.getBytes(StandardCharsets.UTF_8), "text/plain", Map.of());
        VerificationStatus status = others.isEmpty() ? VerificationStatus.UPLOADED : VerificationStatus.MANUAL_REVIEW;
        IdDocument doc = new IdDocument(id, c.id(), t, hash, Masking.lastFour(normalised), key, kind.contentType(), content.length,
                stored.sha256(), status, null, null, others.isEmpty() ? null : "Same number exists on another candidate", null,
                caller.userId(), now, now);
        store.insert(doc);
        store.supersede(c.id(), t, id, now);
        audit.record("SECURITY", "ID_DOCUMENT_UPLOADED", "CANDIDATE", c.id(), c.id(), AuditRecorder.SUCCESS, null,
                AuditRecorder.details("documentId", id, "type", t, "basis", basis, "size", content.length, "duplicateNumber", !others.isEmpty()));
        if (!others.isEmpty()) {
            audit.record("SECURITY", "ID_NUMBER_DUPLICATE", "CANDIDATE", c.id(), c.id(), AuditRecorder.FAILURE,
                    "ID number already used by another candidate", AuditRecorder.details("documentId", id, "type", t,
                            "otherCandidates", others.size()));
        } else if (settings.autoVerify()) {
            requestVerification(doc);
        }
        return DocumentView.of(load(id));
    }

    @Transactional
    public DocumentView verify(Caller caller, String documentId) {
        IdDocument d = load(documentId);
        guard.require(caller, guard.load(d.candidateId()), VERIFY, false);
        if (d.status() == VerificationStatus.SUPERSEDED) {
            throw PlatformException.conflict("DOCUMENT_SUPERSEDED", "A newer document of this type exists");
        }
        requestVerification(d);
        return DocumentView.of(load(documentId));
    }

    @Transactional
    public DocumentView decide(Caller caller, String documentId, String decision, String remarks) {
        IdDocument d = load(documentId);
        guard.require(caller, guard.load(d.candidateId()), VERIFY, false);
        String note = Remarks.clean(remarks, true);
        VerificationStatus s;
        try {
            s = VerificationStatus.valueOf(decision == null ? "" : decision.trim().toUpperCase());
        } catch (IllegalArgumentException e) {
            s = null;
        }
        if (s != VerificationStatus.VERIFIED && s != VerificationStatus.MISMATCH && s != VerificationStatus.FAILED) {
            throw PlatformException.badRequest("DECISION_INVALID", "Decision must be VERIFIED, MISMATCH or FAILED");
        }
        Instant now = clock.instant();
        store.updateStatus(d.id(), null, s, "MANUAL", null, note, s == VerificationStatus.VERIFIED ? now : null, now);
        audit.record("SECURITY", "ID_DOCUMENT_MANUAL_DECISION", "CANDIDATE", d.candidateId(), d.candidateId(), AuditRecorder.SUCCESS,
                note, AuditRecorder.details("documentId", d.id(), "type", d.type(), "decision", s, "previous", d.status()));
        return DocumentView.of(load(documentId));
    }

    @Transactional(readOnly = true)
    public Summary summary(Caller caller, String candidateId) {
        CandidateView c = guard.load(candidateId);
        guard.require(caller, c, VIEW, true);
        List<IdDocument> docs = store.forCandidate(c.id());
        return new Summary(c.id(), VerificationBadge.of(docs), docs.stream().map(DocumentView::of).toList());
    }

    @Transactional(readOnly = true)
    public VerificationBadge badge(String candidateId) {
        return VerificationBadge.of(store.forCandidate(candidateId));
    }

    public Download download(Caller caller, String documentId, String reason) {
        IdDocument d = load(documentId);
        CandidateView c = guard.load(d.candidateId());
        CandidateGuard.Basis basis = guard.require(caller, c, REVEAL, true);
        String why = Remarks.clean(reason, basis == CandidateGuard.Basis.STAFF);
        byte[] content = files.get(d.storageKey()).orElseThrow(() -> PlatformException.notFound("Document content", documentId));
        audit.record("SECURITY", "ID_DOCUMENT_REVEALED", "CANDIDATE", c.id(), c.id(), AuditRecorder.SUCCESS, why,
                AuditRecorder.details("documentId", d.id(), "type", d.type(), "basis", basis));
        return new Download(content, d.contentType(), d.type().name().toLowerCase() + "-" + d.id().substring(0, 8)
                + (d.contentType().equals("application/pdf") ? ".pdf" : d.contentType().equals("image/png") ? ".png" : ".jpg"));
    }

    @Transactional
    public String runVerification(String documentId) {
        IdDocument d = load(documentId);
        if (d.status() != VerificationStatus.VERIFYING) {
            return "SKIPPED_" + d.status();
        }
        String number = files.get(d.storageKey() + ".number").map(b -> new String(b, StandardCharsets.UTF_8))
                .orElseThrow(() -> new IllegalStateException("Encrypted number missing for " + documentId));
        Optional<IdentityHintPort.Hint> hint = hints.hint(d.candidateId());
        IdentityVerificationPort.Result r = verifier.verify(new IdentityVerificationPort.Request(d.id(), d.candidateId(), d.type().name(),
                number, hint.map(IdentityHintPort.Hint::fullName).orElse(null), hint.map(IdentityHintPort.Hint::dateOfBirth).orElse(null)));
        if (r.retryable()) {
            throw new IllegalStateException("Identity verification temporarily unavailable: " + r.message());
        }
        VerificationStatus s = switch (r.status() == null ? "" : r.status()) {
            case "VERIFIED" -> VerificationStatus.VERIFIED;
            case "MISMATCH" -> VerificationStatus.MISMATCH;
            case "NOT_FOUND", "INVALID" -> VerificationStatus.FAILED;
            default -> VerificationStatus.MANUAL_REVIEW;
        };
        Instant now = clock.instant();
        store.updateStatus(d.id(), VerificationStatus.VERIFYING, s, r.provider(), r.verificationRef(), r.message(),
                s == VerificationStatus.VERIFIED ? now : null, now);
        audit.recordQuietly("SECURITY", "ID_DOCUMENT_VERIFICATION_RESULT", "CANDIDATE", d.candidateId(), d.candidateId(),
                s == VerificationStatus.VERIFIED ? AuditRecorder.SUCCESS : AuditRecorder.FAILURE, r.message(),
                AuditRecorder.details("documentId", d.id(), "type", d.type(), "status", s, "provider", r.provider(),
                        "nameMatchScore", r.nameMatchScore()));
        return s.name();
    }

    private void requestVerification(IdDocument d) {
        Instant now = clock.instant();
        store.updateStatus(d.id(), null, VerificationStatus.VERIFYING, null, null, null, null, now);
        outbox.append(VERIFY_EVENT, "ID_DOCUMENT", d.id(), d.candidateId(), null, Map.of("documentId", d.id()));
    }

    private IdDocument load(String id) {
        return store.find(id).orElseThrow(() -> PlatformException.notFound("ID document", id));
    }
}
