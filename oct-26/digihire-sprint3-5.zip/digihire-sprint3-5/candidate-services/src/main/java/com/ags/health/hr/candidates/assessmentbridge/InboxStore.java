package com.ags.health.hr.candidates.assessmentbridge;

import org.springframework.dao.DuplicateKeyException;
import org.springframework.jdbc.core.JdbcTemplate;

import java.sql.Timestamp;
import java.time.Instant;
import java.util.Optional;

public class InboxStore {

    private final JdbcTemplate jdbc;

    public InboxStore(JdbcTemplate jdbc) {
        this.jdbc = jdbc;
    }

    public boolean claim(String eventId, String source, String eventType, Instant at) {
        try {
            return jdbc.update("INSERT INTO cand_p5_inbox (event_id, source, event_type, received_at) VALUES (?, ?, ?, ?)",
                    eventId, source, eventType, Timestamp.from(at)) == 1;
        } catch (DuplicateKeyException e) {
            return false;
        }
    }

    public void complete(String eventId, String outcome, Instant at) {
        jdbc.update("UPDATE cand_p5_inbox SET outcome = ?, processed_at = ? WHERE event_id = ?",
                outcome == null ? null : outcome.length() > 200 ? outcome.substring(0, 200) : outcome, Timestamp.from(at), eventId);
    }

    public void release(String eventId) {
        jdbc.update("DELETE FROM cand_p5_inbox WHERE event_id = ? AND processed_at IS NULL", eventId);
    }

    public Optional<String> outcome(String eventId) {
        return jdbc.queryForList("SELECT outcome FROM cand_p5_inbox WHERE event_id = ?", String.class, eventId).stream().findFirst();
    }
}
