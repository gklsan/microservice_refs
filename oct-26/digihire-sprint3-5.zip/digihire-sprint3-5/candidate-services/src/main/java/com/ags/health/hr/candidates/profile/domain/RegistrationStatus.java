package com.ags.health.hr.candidates.profile.domain;

import com.ags.health.hr.common.platform.validation.FieldViolation;

import java.util.List;

public record RegistrationStatus(String candidateId, boolean complete, int requiredFields, int completedFields,
                                 int percent, List<FieldViolation> missing) {

    public static RegistrationStatus of(String candidateId, int required, List<FieldViolation> missing) {
        int done = Math.max(0, required - missing.size());
        int pct = required == 0 ? 100 : (int) Math.floor(done * 100.0 / required);
        return new RegistrationStatus(candidateId, missing.isEmpty(), required, done, missing.isEmpty() ? 100 : Math.min(99, pct),
                List.copyOf(missing));
    }
}
