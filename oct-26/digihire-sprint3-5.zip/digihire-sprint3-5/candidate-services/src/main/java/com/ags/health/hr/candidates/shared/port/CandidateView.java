package com.ags.health.hr.candidates.shared.port;

import java.time.LocalDate;

public record CandidateView(String id, String smartieUserId, String email, String mobile, String fullName,
                            boolean registered, String taggedRecruiterId, String source, String subSource,
                            LocalDate coolingUntil) {
}
