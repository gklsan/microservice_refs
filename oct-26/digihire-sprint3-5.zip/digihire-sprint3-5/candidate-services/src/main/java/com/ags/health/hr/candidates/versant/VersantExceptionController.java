package com.ags.health.hr.candidates.versant;

import com.ags.health.hr.candidates.assessmentbridge.AssessmentExceptionStore;
import com.ags.health.hr.common.platform.caller.CallerProvider;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@ConditionalOnProperty(prefix = "digihire.candidate.assessment", name = "enabled", havingValue = "true", matchIfMissing = true)
@RestController
public class VersantExceptionController {

    public record ResolveRequest(String action, String remarks) {
    }

    private final VersantExceptionService service;
    private final CallerProvider callers;

    public VersantExceptionController(VersantExceptionService service, CallerProvider callers) {
        this.service = service;
        this.callers = callers;
    }

    @GetMapping("/assessment-exceptions")
    public List<AssessmentExceptionStore.Entry> list(@RequestParam(required = false) String provider,
                                                     @RequestParam(required = false) String status,
                                                     @RequestParam(defaultValue = "100") int limit) {
        return service.list(callers.require(), provider, status, limit);
    }

    @PostMapping("/assessment-exceptions/{exceptionId}/resolve")
    public AssessmentExceptionStore.Entry resolve(@PathVariable String exceptionId, @RequestBody ResolveRequest body) {
        return service.resolve(callers.require(), exceptionId, body.action(), body.remarks());
    }
}
