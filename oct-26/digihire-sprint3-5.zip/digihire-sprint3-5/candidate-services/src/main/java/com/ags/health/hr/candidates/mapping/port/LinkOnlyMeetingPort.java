package com.ags.health.hr.candidates.mapping.port;

import java.time.Instant;
import java.util.List;
import java.util.UUID;

public class LinkOnlyMeetingPort implements MeetingPort {

    private final String baseUrl;

    public LinkOnlyMeetingPort(String baseUrl) {
        this.baseUrl = baseUrl == null ? "" : baseUrl.replaceAll("/+$", "");
    }

    @Override
    public Meeting create(String subject, Instant startsAt, Instant endsAt, String organiserEmail, List<String> attendees) {
        String id = UUID.randomUUID().toString();
        return new Meeting(id, baseUrl.isEmpty() ? null : baseUrl + "/" + id, "LINK");
    }

    @Override
    public void cancel(String externalId) {
    }
}
