package com.ags.health.hr.candidates.profile.domain;

import java.util.List;

public record FieldDefinition(String key, String label, String section, FieldType type, boolean requiredForRegistration,
                              ProfileStage lockedFrom, boolean sensitive, int maxLength, Long min, Long max,
                              List<String> options) {

    public FieldDefinition {
        options = options == null ? List.of() : List.copyOf(options);
        if (maxLength <= 0) {
            maxLength = 200;
        }
    }

    public boolean lockedAt(ProfileStage stage) {
        return lockedFrom != null && stage != null && stage.atLeast(lockedFrom);
    }
}
