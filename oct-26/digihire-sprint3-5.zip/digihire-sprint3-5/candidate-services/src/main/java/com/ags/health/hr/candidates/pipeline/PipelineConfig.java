package com.ags.health.hr.candidates.pipeline;

import com.ags.health.hr.candidates.assessmentbridge.NextStageRouting;
import com.ags.health.hr.candidates.pipeline.domain.CsvBulkRowReader;
import com.ags.health.hr.candidates.pipeline.domain.XlsxBulkRowReader;
import com.ags.health.hr.candidates.pipeline.service.PipelineService;
import com.ags.health.hr.candidates.pipeline.service.StageHistoryGuard;
import com.ags.health.hr.candidates.pipeline.store.BulkJobStore;
import com.ags.health.hr.candidates.shared.config.CandidateP5Properties;
import com.ags.health.hr.candidates.shared.domain.StageCatalog;
import com.ags.health.hr.candidates.shared.port.StageHistoryPort;
import com.ags.health.hr.candidates.shared.service.ApplicantActionGuard;
import com.ags.health.hr.candidates.shared.service.StatusMover;
import com.ags.health.hr.common.platform.assessment.AssessmentPort;
import com.ags.health.hr.common.platform.audit.AuditRecorder;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.transaction.support.TransactionTemplate;

import java.time.Clock;
import java.util.List;

@Configuration
@ConditionalOnProperty(prefix = "digihire.candidate.pipeline", name = "enabled", havingValue = "true", matchIfMissing = true)
public class PipelineConfig {

    @Bean
    public StageHistoryGuard p5StageHistoryGuard(StageHistoryPort history, AssessmentPort assessments,
                                                 NextStageRouting p5NextStageRouting, StageCatalog catalog, Clock p5Clock) {
        return new StageHistoryGuard(history, assessments, p5NextStageRouting, catalog, p5Clock);
    }

    @Bean
    public PipelineService p5PipelineService(StatusMover mover, ApplicantActionGuard guard, StageHistoryPort history,
                                             AssessmentPort assessments, NextStageRouting p5NextStageRouting, StageCatalog catalog,
                                             JdbcTemplate jdbc, TransactionTemplate p5TransactionTemplate, AuditRecorder audit,
                                             Clock p5Clock, CandidateP5Properties props) {
        CandidateP5Properties.Pipeline p = props.getPipeline();
        return new PipelineService(mover, guard, history, assessments, p5NextStageRouting, catalog,
                List.of(new XlsxBulkRowReader(), new CsvBulkRowReader()), new BulkJobStore(jdbc), p5TransactionTemplate, audit, p5Clock,
                new PipelineService.Settings(p.getMaxBulkItems(), p.getMaxUploadBytes()));
    }
}
