package com.ags.health.hr.candidates.photo.web;

import com.ags.health.hr.candidates.photo.domain.PhotoCheck;
import com.ags.health.hr.candidates.photo.service.PhotoVerificationService;
import com.ags.health.hr.common.platform.caller.CallerProvider;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@ConditionalOnProperty(prefix = "digihire.candidate.photo", name = "enabled", havingValue = "true", matchIfMissing = true)
@RestController
public class PhotoController {

    public record DecisionRequest(String decision, String remarks) {
    }

    private final PhotoVerificationService service;
    private final CallerProvider callers;

    public PhotoController(PhotoVerificationService service, CallerProvider callers) {
        this.service = service;
        this.callers = callers;
    }

    @PostMapping("/applicants/{applicationId}/photo-verification")
    public PhotoCheck verify(@PathVariable String applicationId, @RequestBody DecisionRequest body) {
        return service.manual(callers.require(), applicationId, body.decision(), body.remarks());
    }

    @GetMapping("/applicants/{applicationId}/photo-verification")
    public List<PhotoCheck> checks(@PathVariable String applicationId) {
        return service.checks(callers.require(), applicationId);
    }

    @GetMapping("/photo-mismatches")
    public List<PhotoCheck> queue(@RequestParam(required = false) String status, @RequestParam(defaultValue = "100") int limit) {
        return service.reviewQueue(callers.require(), status, limit);
    }

    @PostMapping("/photo-mismatches/{checkId}/review")
    public PhotoCheck review(@PathVariable String checkId, @RequestBody DecisionRequest body) {
        return service.review(callers.require(), checkId, body.decision(), body.remarks());
    }
}
