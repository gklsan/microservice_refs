package com.ags.health.hr.candidates.assessmentbridge;

import com.ags.health.hr.candidates.shared.domain.StageCatalog;
import com.ags.health.hr.candidates.shared.domain.Statuses;
import com.ags.health.hr.candidates.shared.port.ApplicationView;
import com.ags.health.hr.candidates.shared.port.CandidatePort;
import com.ags.health.hr.candidates.shared.port.CandidateView;
import com.ags.health.hr.candidates.shared.service.StatusMoveListener;
import com.ags.health.hr.candidates.shared.service.StatusMovedEvent;
import com.ags.health.hr.common.platform.outbox.OutboxStore;

import java.util.LinkedHashMap;
import java.util.Map;

public class ApplicationEventRelay implements StatusMoveListener {

    public static final String EVENT_TYPE = "APPLICATION_EVENT";

    private final OutboxStore outbox;
    private final CandidatePort candidates;
    private final StageCatalog catalog;

    public ApplicationEventRelay(OutboxStore outbox, CandidatePort candidates, StageCatalog catalog) {
        this.outbox = outbox;
        this.candidates = candidates;
        this.catalog = catalog;
    }

    @Override
    public void onMoved(StatusMovedEvent e) {
        String type;
        if (e.fromStatus() == null) {
            type = "CREATED";
        } else if (Statuses.WALKEDIN.equals(e.toStatus())) {
            type = "WALKED_IN";
        } else if (catalog.isRejected(e.toStatus())) {
            type = "REJECTED";
        } else {
            type = "STAGE_CHANGED";
        }
        ApplicationView a = e.application();
        CandidateView c = candidates.find(a.candidateId()).orElse(null);
        Map<String, Object> p = new LinkedHashMap<>();
        p.put("eventType", type);
        p.put("candidateId", a.candidateId());
        p.put("applicationId", a.id());
        p.put("candidateEmail", c == null ? null : c.email());
        p.put("candidateName", c == null ? null : c.fullName());
        p.put("mobile", c == null ? null : c.mobile());
        p.put("lob", value(e, "lob", a.lob()));
        p.put("roleCode", value(e, "roleCode", a.roleCode()));
        p.put("location", value(e, "location", a.location()));
        p.put("stage", e.toStatus());
        p.put("reason", e.reasonCode());
        outbox.append(EVENT_TYPE, "APPLICATION", a.id(), a.candidateId(), a.id(), p);
    }

    private static Object value(StatusMovedEvent e, String key, String fallback) {
        Object v = e.context().get(key);
        return v == null || "null".equals(v) ? fallback : v;
    }
}
