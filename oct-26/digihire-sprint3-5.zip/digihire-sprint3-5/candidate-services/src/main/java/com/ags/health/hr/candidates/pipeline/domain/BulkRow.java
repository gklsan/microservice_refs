package com.ags.health.hr.candidates.pipeline.domain;

public record BulkRow(int rowNo, String applicationId, String targetStatus, String reasonCode, String remarks) {
}
