package com.ags.health.hr.candidates.mapping.domain;

public enum MappingAction { TAG_AND_MAP, MAP, MAP_ON_HOLD, REMAP, REQUEST_ACCESS, INVITE_TO_REGISTER, NONE }
