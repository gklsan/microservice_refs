package com.ags.health.hr.candidates.mapping.web;

import com.ags.health.hr.candidates.mapping.domain.RejectionReason;
import com.ags.health.hr.candidates.mapping.service.RejectionReasonService;
import com.ags.health.hr.candidates.mapping.service.SchedulingService;
import com.ags.health.hr.candidates.mapping.store.InterviewSlotStore;
import com.ags.health.hr.common.platform.caller.CallerProvider;
import org.springframework.http.HttpStatus;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import java.time.Instant;
import java.util.List;

@ConditionalOnProperty(prefix = "digihire.candidate.mapping", name = "enabled", havingValue = "true", matchIfMissing = true)
@RestController
public class SchedulingController {

    public record CancelRequest(String remarks) {
    }

    private final SchedulingService scheduling;
    private final RejectionReasonService reasons;
    private final CallerProvider callers;

    public SchedulingController(SchedulingService scheduling, RejectionReasonService reasons, CallerProvider callers) {
        this.scheduling = scheduling;
        this.reasons = reasons;
        this.callers = callers;
    }

    @PostMapping("/interview-slots")
    @ResponseStatus(HttpStatus.CREATED)
    public InterviewSlotStore.Slot create(@RequestBody SchedulingService.SlotRequest body) {
        return scheduling.createSlot(callers.require(), body);
    }

    @GetMapping("/interview-slots")
    public List<InterviewSlotStore.Slot> slots(@RequestParam(required = false) String mode,
                                               @RequestParam(required = false) String lob,
                                               @RequestParam(required = false) String location,
                                               @RequestParam(required = false) Instant from,
                                               @RequestParam(required = false) Instant to,
                                               @RequestParam(defaultValue = "true") boolean availableOnly) {
        return scheduling.slots(callers.require(), mode, lob, location, from, to, availableOnly);
    }

    @DeleteMapping("/interview-slots/{slotId}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void deactivate(@PathVariable String slotId) {
        scheduling.deactivateSlot(callers.require(), slotId);
    }

    @PostMapping("/interview-bookings/{bookingId}/cancel")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void cancel(@PathVariable String bookingId, @RequestBody CancelRequest body) {
        scheduling.cancel(callers.require(), bookingId, body.remarks());
    }

    @GetMapping("/rejection-reasons")
    public List<RejectionReason> reasons(@RequestParam(required = false) String stage,
                                         @RequestParam(defaultValue = "false") boolean includeInactive) {
        callers.require();
        return reasons.list(stage, includeInactive);
    }

    @PutMapping("/rejection-reasons/{code}")
    public RejectionReason save(@PathVariable String code, @RequestBody RejectionReason body) {
        return reasons.upsert(callers.require(), new RejectionReason(code, body.label(), body.stage(), body.templateCode(),
                body.remarksRequired(), body.active(), body.sortOrder()));
    }
}
