package com.ags.health.hr.candidates.shared.service;

public interface StatusMoveListener {

    void onMoved(StatusMovedEvent event);
}
