package com.ags.health.hr.candidates.profile.web;

import com.ags.health.hr.candidates.profile.domain.RegistrationStatus;
import com.ags.health.hr.candidates.profile.service.ProfileService;
import com.ags.health.hr.candidates.profile.store.ProfileChangeStore;
import com.ags.health.hr.common.platform.caller.CallerProvider;
import org.springframework.http.CacheControl;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.Map;

@ConditionalOnProperty(prefix = "digihire.candidate.profile", name = "enabled", havingValue = "true", matchIfMissing = true)
@RestController
public class ProfileController {

    public record ProfileChangeRequest(Map<String, Object> changes, String overrideReason) {
    }

    private final ProfileService profiles;
    private final CallerProvider callers;

    public ProfileController(ProfileService profiles, CallerProvider callers) {
        this.profiles = profiles;
        this.callers = callers;
    }

    @GetMapping("/candidates/{candidateId}/profile-fields")
    public ProfileService.ProfileView fields(@PathVariable String candidateId) {
        return profiles.fields(callers.require(), candidateId);
    }

    @PatchMapping("/candidates/{candidateId}/profile")
    public ProfileService.UpdateResult update(@PathVariable String candidateId, @RequestBody ProfileChangeRequest body) {
        return profiles.update(callers.require(), candidateId, body == null ? null : body.changes(),
                body == null ? null : body.overrideReason());
    }

    @GetMapping("/candidates/{candidateId}/profile-completeness")
    public RegistrationStatus completeness(@PathVariable String candidateId) {
        return profiles.completeness(callers.require(), candidateId);
    }

    @GetMapping("/candidates/{candidateId}/profile-changes")
    public List<ProfileChangeStore.Change> history(@PathVariable String candidateId,
                                                   @RequestParam(defaultValue = "100") int limit) {
        return profiles.history(callers.require(), candidateId, limit);
    }

    @GetMapping("/candidates/{candidateId}/profile.pdf")
    public ResponseEntity<byte[]> pdf(@PathVariable String candidateId) {
        byte[] pdf = profiles.exportPdf(callers.require(), candidateId);
        return ResponseEntity.ok()
                .contentType(MediaType.APPLICATION_PDF)
                .cacheControl(CacheControl.noStore())
                .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"candidate-" + candidateId.replaceAll("[^A-Za-z0-9_-]", "_") + ".pdf\"")
                .header("X-Content-Type-Options", "nosniff")
                .body(pdf);
    }
}
