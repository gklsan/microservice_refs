package com.ags.health.hr.candidates.assessmentbridge;

import com.ags.health.hr.common.platform.notify.NotificationRequest;
import com.ags.health.hr.common.platform.outbox.OutboxEvent;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.util.Map;

public class NotificationDispatcher implements OutboxDispatcher {

    private static final TypeReference<Map<String, Object>> MAP = new TypeReference<>() {
    };

    private final NotificationDelivery delivery;
    private final ObjectMapper mapper;

    public NotificationDispatcher(NotificationDelivery delivery, ObjectMapper mapper) {
        this.delivery = delivery;
        this.mapper = mapper;
    }

    @Override
    public String eventType() {
        return OutboxNotificationPort.EVENT_TYPE;
    }

    @Override
    public boolean ready() {
        return delivery != null;
    }

    @Override
    public void deliver(OutboxEvent event) {
        JsonNode p = event.payload();
        Map<String, Object> ctx = p.get("context") == null || p.get("context").isNull() ? Map.of()
                : mapper.convertValue(p.get("context"), MAP);
        delivery.deliver(new NotificationRequest(text(p, "eventType"), text(p, "applicationId"), text(p, "candidateId"),
                text(p, "idempotencyKey"), ctx));
    }

    private static String text(JsonNode p, String f) {
        return p.get(f) == null || p.get(f).isNull() ? null : p.get(f).asText();
    }
}
