package com.ags.health.hr.candidates.profile.service;

import com.ags.health.hr.candidates.profile.domain.FieldCatalog;
import com.ags.health.hr.candidates.profile.domain.FieldDefinition;
import com.ags.health.hr.candidates.profile.domain.FieldType;
import com.ags.health.hr.common.platform.validation.Masking;

import java.time.Instant;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class ProfileDocumentBuilder {

    private static final DateTimeFormatter STAMP = DateTimeFormatter.ofPattern("dd MMM yyyy HH:mm z");

    private final FieldCatalog catalog;
    private final ZoneId zone;

    public ProfileDocumentBuilder(FieldCatalog catalog, ZoneId zone) {
        this.catalog = catalog;
        this.zone = zone;
    }

    public ProfileDocument build(String candidateId, Map<String, Object> values, String generatedBy, Instant at,
                                 boolean revealSensitive) {
        Map<String, List<ProfileDocument.Line>> sections = new LinkedHashMap<>();
        for (FieldDefinition d : catalog.all()) {
            Object v = values == null ? null : values.get(d.key());
            String text = v == null || String.valueOf(v).isBlank() ? "-" : String.valueOf(v);
            if (d.sensitive() && !"-".equals(text) && !revealSensitive) {
                text = mask(d, text);
            }
            sections.computeIfAbsent(d.section(), k -> new ArrayList<>()).add(new ProfileDocument.Line(d.label(), text));
        }
        List<ProfileDocument.Section> out = new ArrayList<>();
        sections.forEach((name, lines) -> out.add(new ProfileDocument.Section(title(name), List.copyOf(lines))));
        String stamp = STAMP.format(at.atZone(zone));
        return new ProfileDocument("Candidate profile", candidateId, generatedBy, at,
                "CONFIDENTIAL - " + generatedBy + " - " + stamp, List.copyOf(out));
    }

    static String mask(FieldDefinition d, String value) {
        if (d.type() == FieldType.EMAIL) {
            return Masking.email(value);
        }
        if (d.type() == FieldType.DOB || d.type() == FieldType.DATE) {
            return value.length() >= 4 ? value.substring(0, 4) + "-**-**" : "****";
        }
        if (d.type() == FieldType.NUMBER) {
            return "******";
        }
        return Masking.lastFour(value);
    }

    private static String title(String section) {
        String s = section.toLowerCase().replace('_', ' ');
        return Character.toUpperCase(s.charAt(0)) + s.substring(1);
    }
}
