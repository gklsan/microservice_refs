package com.ags.health.hr.candidates.photo.port;

import com.ags.health.hr.common.platform.error.PlatformException;
import com.ags.health.hr.common.platform.http.InternalHttp;
import com.fasterxml.jackson.databind.JsonNode;

import java.util.Base64;
import java.util.Map;

public class FaceMatchClient implements FaceMatchPort {

    private final InternalHttp http;
    private final String base;

    public FaceMatchClient(InternalHttp http, String integrationUrl) {
        this.http = http;
        this.base = InternalHttp.trimBase(integrationUrl);
    }

    @Override
    public Result match(byte[] probe, byte[] reference) {
        try {
            JsonNode n = http.post(base + "/internal/face/match", Map.of("probe", Base64.getEncoder().encodeToString(probe),
                    "reference", Base64.getEncoder().encodeToString(reference)));
            return new Result(n.path("score").asDouble(0), n.path("provider").asText(null), n.path("reference").asText(null));
        } catch (InternalHttp.Failure f) {
            throw PlatformException.unavailable("FACE_MATCH_UNAVAILABLE", "Face match failed: " + f.status());
        }
    }
}
