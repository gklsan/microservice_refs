package com.ags.health.hr.candidates.mapping.port;

import java.time.Instant;
import java.util.List;

public interface MeetingPort {

    record Meeting(String externalId, String joinUrl, String provider) {
    }

    Meeting create(String subject, Instant startsAt, Instant endsAt, String organiserEmail, List<String> attendees);

    void cancel(String externalId);
}
