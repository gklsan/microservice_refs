package com.ags.health.hr.candidates.assessmentbridge;

import com.ags.health.hr.common.platform.audit.AuditRecorder;
import com.ags.health.hr.common.platform.error.PlatformException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.transaction.support.TransactionTemplate;

import java.time.Clock;
import java.util.List;

public class AssessmentEventInbox {

    private static final Logger log = LoggerFactory.getLogger(AssessmentEventInbox.class);

    public record Summary(int received, int processed, int duplicates, int ignored, int failed) {
    }

    private final InboxStore inbox;
    private final List<AssessmentEventHandler> handlers;
    private final TransactionTemplate tx;
    private final AuditRecorder audit;
    private final Clock clock;

    public AssessmentEventInbox(InboxStore inbox, List<AssessmentEventHandler> handlers, TransactionTemplate tx,
                                AuditRecorder audit, Clock clock) {
        this.inbox = inbox;
        this.handlers = List.copyOf(handlers);
        this.tx = tx;
        this.audit = audit;
        this.clock = clock;
    }

    public Summary accept(List<AssessmentEvent> events) {
        if (events == null) {
            throw PlatformException.badRequest("EVENTS_REQUIRED", "A list of events is required");
        }
        if (events.size() > 500) {
            throw PlatformException.badRequest("TOO_MANY_EVENTS", "At most 500 events per call");
        }
        int processed = 0;
        int duplicates = 0;
        int ignored = 0;
        int failed = 0;
        for (AssessmentEvent e : events) {
            if (e == null || e.id() == null || e.eventType() == null) {
                ignored++;
                continue;
            }
            String outcome;
            try {
                outcome = tx.execute(status -> {
                    if (!inbox.claim(e.id().toString(), AssessmentOutcomeHandler.SOURCE, e.eventType(), clock.instant())) {
                        return null;
                    }
                    String result = dispatch(e);
                    inbox.complete(e.id().toString(), result, clock.instant());
                    return result;
                });
            } catch (PlatformException pe) {
                if (pe.getStatus() >= 500) {
                    failed++;
                    log.warn("Assessment event {} {} will be retried: {}", e.eventType(), e.id(), pe.getMessage());
                    continue;
                }
                outcome = "REJECTED_" + pe.getCode();
                String rejected = outcome;
                tx.execute(status -> {
                    if (inbox.claim(e.id().toString(), AssessmentOutcomeHandler.SOURCE, e.eventType(), clock.instant())) {
                        inbox.complete(e.id().toString(), rejected, clock.instant());
                    }
                    return null;
                });
                audit.recordQuietly("INTEGRATION", "ASSESSMENT_EVENT_REJECTED", "APPLICATION", e.applicationId(), e.candidateId(),
                        AuditRecorder.FAILURE, pe.getMessage(), AuditRecorder.details("eventId", e.id(), "eventType", e.eventType(),
                                "code", pe.getCode()));
            } catch (RuntimeException ex) {
                failed++;
                log.warn("Assessment event {} {} failed and will be retried: {}", e.eventType(), e.id(), ex.getMessage());
                continue;
            }
            if (outcome == null) {
                duplicates++;
            } else if (outcome.startsWith("IGNORED") || outcome.startsWith("NO_HANDLER")) {
                ignored++;
            } else {
                processed++;
            }
        }
        Summary s = new Summary(events.size(), processed, duplicates, ignored, failed);
        if (failed > 0) {
            throw new PlatformException(503, "EVENTS_PARTIALLY_FAILED", failed + " event(s) failed; resend the batch",
                    List.of(java.util.Map.of("processed", processed, "duplicates", duplicates, "failed", failed)));
        }
        return s;
    }

    private String dispatch(AssessmentEvent e) {
        StringBuilder out = new StringBuilder();
        for (AssessmentEventHandler h : handlers) {
            if (h.supports(e)) {
                if (out.length() > 0) {
                    out.append(';');
                }
                out.append(h.handle(e));
            }
        }
        return out.length() == 0 ? "NO_HANDLER" : out.toString();
    }
}
