package com.ags.health.hr.candidates.shared.port;

public record NewApplication(String candidateId, String requisitionId, String jobId, String hrUserId, String source,
                             String subSource, String status, StatusChange change) {
}
