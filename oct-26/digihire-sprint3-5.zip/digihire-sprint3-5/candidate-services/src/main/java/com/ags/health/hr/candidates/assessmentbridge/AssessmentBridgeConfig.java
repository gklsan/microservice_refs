package com.ags.health.hr.candidates.assessmentbridge;

import com.ags.health.hr.candidates.shared.config.CandidateP5Properties;
import com.ags.health.hr.candidates.shared.domain.StageCatalog;
import com.ags.health.hr.candidates.shared.domain.TabMovementPolicy;
import com.ags.health.hr.candidates.shared.port.ApplicationPort;
import com.ags.health.hr.candidates.shared.port.CandidatePort;
import com.ags.health.hr.candidates.shared.service.ApplicantActionGuard;
import com.ags.health.hr.candidates.shared.service.StatusMover;
import com.ags.health.hr.candidates.versant.VersantExceptionService;
import com.ags.health.hr.common.platform.assessment.AssessmentPort;
import com.ags.health.hr.common.platform.audit.AuditRecorder;
import com.ags.health.hr.common.platform.notify.NotificationPort;
import com.ags.health.hr.common.platform.outbox.OutboxStore;
import com.ags.health.hr.common.platform.time.BusinessClock;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.ObjectProvider;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.transaction.support.TransactionTemplate;

import java.time.Clock;
import java.util.List;

@Configuration
@ConditionalOnProperty(prefix = "digihire.candidate.assessment", name = "enabled", havingValue = "true", matchIfMissing = true)
public class AssessmentBridgeConfig {

    @Bean
    @ConditionalOnMissingBean(NotificationPort.class)
    public NotificationPort p5NotificationPort(OutboxStore p5OutboxStore) {
        return new OutboxNotificationPort(p5OutboxStore);
    }

    @Bean
    public ApplicationEventRelay p5ApplicationEventRelay(OutboxStore p5OutboxStore, CandidatePort candidates, StageCatalog catalog) {
        return new ApplicationEventRelay(p5OutboxStore, candidates, catalog);
    }

    @Bean
    public AssessmentExceptionStore p5AssessmentExceptionStore(JdbcTemplate jdbc) {
        return new AssessmentExceptionStore(jdbc);
    }

    @Bean
    public NextStageRouting p5NextStageRouting(CandidateP5Properties props) {
        CandidateP5Properties.Assessment a = props.getAssessment();
        return new NextStageRouting(a.getVersantRoleCodes(), a.getVersantLobs(), a.isAutoAdvance());
    }

    @Bean
    public AssessmentOutcomeHandler p5AssessmentOutcomeHandler(ApplicationPort applications, StatusMover mover,
                                                               TabMovementPolicy policy, StageCatalog catalog,
                                                               NextStageRouting p5NextStageRouting,
                                                               AssessmentExceptionStore p5AssessmentExceptionStore,
                                                               BusinessClock clock) {
        return new AssessmentOutcomeHandler(applications, mover, policy, catalog, p5NextStageRouting, p5AssessmentExceptionStore, clock);
    }

    @Bean
    public AssessmentEventInbox p5AssessmentEventInbox(JdbcTemplate jdbc, ObjectProvider<AssessmentEventHandler> handlers,
                                                       TransactionTemplate p5TransactionTemplate, AuditRecorder audit,
                                                       Clock p5Clock) {
        return new AssessmentEventInbox(new InboxStore(jdbc), handlers.orderedStream().toList(), p5TransactionTemplate, audit, p5Clock);
    }

    @Bean
    public AssessmentEventDispatcher p5AssessmentEventDispatcher(AssessmentPort assessments, ObjectMapper mapper) {
        return new AssessmentEventDispatcher(assessments, mapper);
    }

    @Bean
    public NotificationDispatcher p5NotificationDispatcher(ObjectProvider<NotificationDelivery> delivery, ObjectMapper mapper) {
        return new NotificationDispatcher(delivery.getIfAvailable(), mapper);
    }

    @Bean
    public OutboxRelay p5OutboxRelay(OutboxStore p5OutboxStore, ObjectProvider<OutboxDispatcher> dispatchers,
                                     CandidateP5Properties props) {
        List<OutboxDispatcher> all = dispatchers.orderedStream().toList();
        return new OutboxRelay(p5OutboxStore, all, props.getOutbox().getBatchSize());
    }

    @Bean
    public VersantExceptionService p5VersantExceptionService(AssessmentExceptionStore p5AssessmentExceptionStore,
                                                             StatusMover mover, ApplicantActionGuard guard, AuditRecorder audit,
                                                             Clock p5Clock) {
        return new VersantExceptionService(p5AssessmentExceptionStore, mover, guard, audit, p5Clock);
    }
}
