package com.ags.health.hr.candidates.shared.service;

import com.ags.health.hr.candidates.shared.port.CandidateAccessPort;
import com.ags.health.hr.candidates.shared.port.CandidatePort;
import com.ags.health.hr.candidates.shared.port.CandidateView;
import com.ags.health.hr.common.platform.caller.Caller;
import com.ags.health.hr.common.platform.error.PlatformException;

public class CandidateGuard {

    public enum Basis { SYSTEM, SELF, STAFF }

    private final CandidatePort candidates;
    private final CandidateAccessPort access;

    public CandidateGuard(CandidatePort candidates, CandidateAccessPort access) {
        this.candidates = candidates;
        this.access = access;
    }

    public CandidateView load(String candidateId) {
        if (candidateId == null || candidateId.isBlank()) {
            throw PlatformException.badRequest("CANDIDATE_REQUIRED", "Candidate id is required");
        }
        return candidates.find(candidateId.trim()).orElseThrow(() -> PlatformException.notFound("Candidate", candidateId));
    }

    public Basis require(Caller caller, CandidateView candidate, String staffPermission, boolean selfAllowed) {
        if (caller == null) {
            throw PlatformException.unauthorized("Authentication required");
        }
        if (caller.system()) {
            return Basis.SYSTEM;
        }
        if (selfAllowed && isSelf(caller, candidate)) {
            return Basis.SELF;
        }
        if (staffPermission == null || !caller.has(staffPermission)) {
            throw PlatformException.forbidden("PERMISSION_DENIED", "Missing permission " + staffPermission);
        }
        if (!access.canView(caller, candidate.id())) {
            throw PlatformException.forbidden("CANDIDATE_OUT_OF_SCOPE", "Candidate is outside your access scope");
        }
        return Basis.STAFF;
    }

    public static boolean isSelf(Caller caller, CandidateView candidate) {
        return caller != null && candidate != null && !caller.system()
                && (caller.is(candidate.smartieUserId()) || caller.is(candidate.id()));
    }
}
