package com.ags.health.hr.candidates.shared.domain;

public final class Reasons {

    public static final String NO_OPENINGS = "NO_OPENINGS";
    public static final String FRESHER_PIPELINE = "FRESHER_PIPELINE";
    public static final String SCORE_EXPIRED = "SCORE_EXPIRED";
    public static final String COOLING_PERIOD = "COOLING_PERIOD";
    public static final String VOICE_FRESHER_RESTRICTED = "VOICE_FRESHER_RESTRICTED";
    public static final String BLACKLISTED = "BLACKLISTED";
    public static final String OFFER_REJECTED = "OFFER_REJECTED";
    public static final String REMAP = "REMAP";
    public static final String REPROCESS = "REPROCESS";
    public static final String BULK = "BULK";
    public static final String WORKFLOW_AUTO = "WORKFLOW_AUTO";

    private Reasons() {
    }
}
