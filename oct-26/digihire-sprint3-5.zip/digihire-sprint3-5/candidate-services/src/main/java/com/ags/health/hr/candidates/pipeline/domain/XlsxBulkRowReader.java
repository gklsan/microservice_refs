package com.ags.health.hr.candidates.pipeline.domain;

import com.ags.health.hr.common.platform.error.PlatformException;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public class XlsxBulkRowReader implements BulkRowReader {

    @Override
    public boolean supports(String fileName) {
        return fileName != null && fileName.toLowerCase(Locale.ROOT).endsWith(".xlsx");
    }

    @Override
    public List<BulkRow> read(byte[] content, int maxRows) {
        if (content.length < 4 || content[0] != 'P' || content[1] != 'K') {
            throw PlatformException.badRequest("FILE_TYPE_NOT_ALLOWED", "The file is not an .xlsx workbook");
        }
        DataFormatter fmt = new DataFormatter();
        List<BulkRow> rows = new ArrayList<>();
        try (Workbook wb = WorkbookFactory.create(new ByteArrayInputStream(content))) {
            Sheet sheet = wb.getSheetAt(0);
            Row header = sheet.getRow(sheet.getFirstRowNum());
            if (header == null) {
                throw PlatformException.badRequest("FILE_EMPTY", "The sheet has no header row");
            }
            List<String> names = new ArrayList<>();
            for (int c = 0; c < header.getLastCellNum(); c++) {
                names.add(header.getCell(c) == null ? "" : fmt.formatCellValue(header.getCell(c)));
            }
            Map<String, Integer> idx = CsvBulkRowReader.index(names);
            for (int r = sheet.getFirstRowNum() + 1; r <= sheet.getLastRowNum(); r++) {
                Row row = sheet.getRow(r);
                if (row == null) {
                    continue;
                }
                List<String> cells = new ArrayList<>();
                for (int c = 0; c < names.size(); c++) {
                    cells.add(row.getCell(c) == null ? "" : fmt.formatCellValue(row.getCell(c)));
                }
                if (cells.stream().allMatch(String::isBlank)) {
                    continue;
                }
                if (rows.size() >= maxRows) {
                    throw PlatformException.badRequest("TOO_MANY_ROWS", "At most " + maxRows + " rows per upload");
                }
                rows.add(new BulkRow(r + 1, CsvBulkRowReader.cell(cells, idx.get(HEADER_APPLICATION)),
                        CsvBulkRowReader.cell(cells, idx.get(HEADER_STATUS)), CsvBulkRowReader.cell(cells, idx.get(HEADER_REASON)),
                        CsvBulkRowReader.cell(cells, idx.get(HEADER_REMARKS))));
            }
        } catch (IOException | RuntimeException e) {
            if (e instanceof PlatformException pe) {
                throw pe;
            }
            throw PlatformException.badRequest("FILE_UNREADABLE", "The workbook could not be read");
        }
        return rows;
    }
}
