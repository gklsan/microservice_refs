package com.ags.health.hr.candidates.profile.domain;

import com.ags.health.hr.candidates.shared.domain.StageCatalog;
import com.ags.health.hr.candidates.shared.domain.Tab;
import com.ags.health.hr.candidates.shared.port.ApplicationView;

import java.util.List;
import java.util.Set;

public class StageEditPolicy {

    private static final Set<Tab> IN_PROCESS_TABS = Set.of(Tab.ASSESSMENT, Tab.VERSANT, Tab.PANEL);
    private static final Set<Tab> OFFER_TABS = Set.of(Tab.OFFER, Tab.JOINED);

    private final StageCatalog catalog;

    public StageEditPolicy(StageCatalog catalog) {
        this.catalog = catalog;
    }

    public ProfileStage stageOf(List<ApplicationView> applications) {
        ProfileStage stage = ProfileStage.REGISTRATION;
        if (applications == null) {
            return stage;
        }
        for (ApplicationView a : applications) {
            ProfileStage s = ProfileStage.APPLICANT;
            if (catalog.known(a.status())) {
                Tab t = catalog.tabOf(a.status());
                if (OFFER_TABS.contains(t)) {
                    s = ProfileStage.OFFER;
                } else if (IN_PROCESS_TABS.contains(t)) {
                    s = ProfileStage.IN_PROCESS;
                }
            }
            if (s.ordinal() > stage.ordinal()) {
                stage = s;
            }
        }
        return stage;
    }

    public boolean editable(FieldDefinition field, ProfileStage stage) {
        return !field.lockedAt(stage);
    }
}
