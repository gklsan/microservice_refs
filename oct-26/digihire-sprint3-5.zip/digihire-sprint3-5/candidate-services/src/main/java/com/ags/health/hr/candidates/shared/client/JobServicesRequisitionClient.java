package com.ags.health.hr.candidates.shared.client;

import com.ags.health.hr.candidates.shared.port.RequisitionPort;
import com.ags.health.hr.candidates.shared.port.RequisitionView;
import com.ags.health.hr.common.platform.error.PlatformException;
import com.ags.health.hr.common.platform.http.InternalHttp;
import com.fasterxml.jackson.databind.JsonNode;

import java.time.LocalDate;
import java.util.Optional;

public class JobServicesRequisitionClient implements RequisitionPort {

    private final InternalHttp http;
    private final String base;

    public JobServicesRequisitionClient(InternalHttp http, String jobServicesUrl) {
        this.http = http;
        this.base = InternalHttp.trimBase(jobServicesUrl);
    }

    @Override
    public Optional<RequisitionView> find(String requisitionId) {
        if (requisitionId == null || requisitionId.isBlank()) {
            return Optional.empty();
        }
        try {
            JsonNode n = http.get(base + "/internal/requisitions/" + InternalHttp.encode(requisitionId.trim()));
            if (n == null || n.isNull() || n.isMissingNode()) {
                return Optional.empty();
            }
            return Optional.of(new RequisitionView(text(n, "requisitionId"), text(n, "jobId"), text(n, "title"), text(n, "lob"),
                    text(n, "location"), text(n, "orcId"), text(n, "roleCode"), text(n, "status"),
                    n.path("active").asBoolean(false), n.path("openings").asInt(0), n.path("filled").asInt(0),
                    text(n, "validTo") == null ? null : LocalDate.parse(text(n, "validTo"))));
        } catch (InternalHttp.Failure f) {
            if (f.status() == 404) {
                return Optional.empty();
            }
            throw PlatformException.unavailable("JOB_SERVICES_UNAVAILABLE", "Requisition lookup failed: " + f.getMessage());
        }
    }

    private static String text(JsonNode n, String f) {
        JsonNode v = n.get(f);
        return v == null || v.isNull() ? null : v.asText();
    }
}
