package com.ags.health.hr.candidates.shared.port;

import java.time.LocalDate;

public record RequisitionView(String requisitionId, String jobId, String title, String lob, String location,
                              String orcId, String roleCode, String status, boolean active, int openings, int filled,
                              LocalDate validTo) {

    public int available() {
        return Math.max(0, openings - filled);
    }
}
