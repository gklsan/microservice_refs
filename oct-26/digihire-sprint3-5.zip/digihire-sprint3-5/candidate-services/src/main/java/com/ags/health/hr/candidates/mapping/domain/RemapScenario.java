package com.ags.health.hr.candidates.mapping.domain;

public enum RemapScenario {
    SAME_ROLE_SAME_LOB,
    SAME_LOB_NEW_ROLE,
    NEW_LOB,
    NEW_LOCATION,
    TARGET_UNAVAILABLE,
    STAGE_LOCKED
}
