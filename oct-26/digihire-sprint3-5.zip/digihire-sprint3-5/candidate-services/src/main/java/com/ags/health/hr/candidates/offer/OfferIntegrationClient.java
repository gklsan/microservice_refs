package com.ags.health.hr.candidates.offer;

import com.ags.health.hr.common.platform.error.PlatformException;
import com.ags.health.hr.common.platform.http.InternalHttp;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonNode;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class OfferIntegrationClient implements OfferIntegrationPort {

    private static final TypeReference<List<Map<String, Object>>> LIST = new TypeReference<>() {
    };
    private static final TypeReference<Map<String, Object>> MAP = new TypeReference<>() {
    };

    private final InternalHttp http;
    private final String base;

    public OfferIntegrationClient(InternalHttp http, String integrationUrl) {
        this.http = http;
        this.base = InternalHttp.trimBase(integrationUrl);
    }

    @Override
    public PushResult push(String applicationId, String candidateId, String requestedBy, Map<String, Object> data) {
        Map<String, Object> body = new LinkedHashMap<>();
        body.put("applicationId", applicationId);
        body.put("candidateId", candidateId);
        body.put("requestedBy", requestedBy);
        body.put("data", data);
        try {
            JsonNode n = http.post(base + "/internal/offers", body);
            return new PushResult(n.path("syncId").asText(null), n.path("status").asText(null), n.path("externalOfferId").asText(null),
                    n.has("errors") ? http.mapper().convertValue(n.get("errors"), LIST) : List.of());
        } catch (InternalHttp.Failure f) {
            if (f.status() == 422) {
                try {
                    JsonNode n = http.mapper().readTree(f.body());
                    return new PushResult(null, "INVALID", null, n.has("errors") ? http.mapper().convertValue(n.get("errors"), LIST) : List.of());
                } catch (Exception e) {
                    return new PushResult(null, "INVALID", null, List.of(Map.of("message", String.valueOf(f.body()))));
                }
            }
            throw PlatformException.unavailable("INTEGRATION_UNAVAILABLE", "Offer push failed: " + f.status());
        }
    }

    @Override
    public Map<String, Object> status(String applicationId) {
        try {
            return http.mapper().convertValue(http.get(base + "/internal/offers/" + InternalHttp.encode(applicationId)), MAP);
        } catch (InternalHttp.Failure f) {
            if (f.status() == 404) {
                return Map.of("applicationId", applicationId, "status", "NOT_PUSHED");
            }
            throw PlatformException.unavailable("INTEGRATION_UNAVAILABLE", "Offer status lookup failed: " + f.status());
        }
    }
}
