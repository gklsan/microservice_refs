package com.ags.health.hr.candidates.mapping.store;

import com.ags.health.hr.candidates.mapping.domain.RejectionReason;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

import java.sql.Timestamp;
import java.time.Instant;
import java.util.List;
import java.util.Optional;

public class RejectionReasonStore {

    private static final String COLUMNS = "code, label, stage, template_code, remarks_required, active, sort_order";
    private static final RowMapper<RejectionReason> ROW = (rs, i) -> new RejectionReason(rs.getString(1), rs.getString(2),
            rs.getString(3), rs.getString(4), rs.getBoolean(5), rs.getBoolean(6), rs.getInt(7));

    private final JdbcTemplate jdbc;

    public RejectionReasonStore(JdbcTemplate jdbc) {
        this.jdbc = jdbc;
    }

    public Optional<RejectionReason> find(String code) {
        return jdbc.query("SELECT " + COLUMNS + " FROM cand_rejection_reason WHERE code = ?", ROW, code).stream().findFirst();
    }

    public List<RejectionReason> list(boolean activeOnly) {
        return jdbc.query("SELECT " + COLUMNS + " FROM cand_rejection_reason" + (activeOnly ? " WHERE active = TRUE" : "")
                + " ORDER BY sort_order, code", ROW);
    }

    public void upsert(RejectionReason r, String actor, Instant at) {
        int updated = jdbc.update("UPDATE cand_rejection_reason SET label = ?, stage = ?, template_code = ?, remarks_required = ?, "
                        + "active = ?, sort_order = ?, updated_by = ?, updated_at = ? WHERE code = ?",
                r.label(), r.stage(), r.templateCode(), r.remarksRequired(), r.active(), r.sortOrder(), actor,
                Timestamp.from(at), r.code());
        if (updated == 0) {
            jdbc.update("INSERT INTO cand_rejection_reason (code, label, stage, template_code, remarks_required, active, "
                            + "sort_order, updated_by, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)",
                    r.code(), r.label(), r.stage(), r.templateCode(), r.remarksRequired(), r.active(), r.sortOrder(), actor,
                    Timestamp.from(at));
        }
    }
}
