package com.ags.health.hr.candidates.shared.config;

import lombok.Getter;
import lombok.Setter;
import org.springframework.boot.context.properties.ConfigurationProperties;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

@Getter
@Setter
@ConfigurationProperties(prefix = "digihire.candidate")
public class CandidateP5Properties {

    private boolean enabled = true;
    private String serviceName = "candidate-services";
    private boolean schemaInit = true;
    private boolean workflowEnabled = false;
    private Security security = new Security();
    private Clients clients = new Clients();
    private Audit audit = new Audit();
    private Stages stages = new Stages();
    private Applicant applicant = new Applicant();
    private Storage storage = new Storage();
    private Jobs jobs = new Jobs();
    private Outbox outbox = new Outbox();
    private Profile profile = new Profile();
    private Mapping mapping = new Mapping();
    private Assessment assessment = new Assessment();
    private Pipeline pipeline = new Pipeline();
    private IdProof idProof = new IdProof();
    private Photo photo = new Photo();
    private HrRound hrRound = new HrRound();
    private Panel panel = new Panel();

    @Getter
    @Setter
    public static class Security {
        private String jwtSecret;
        private String internalKey;
        private String serviceKeys;
        private String outboundKey;
        private int rbacCacheSeconds = 60;
    }

    @Getter
    @Setter
    public static class Clients {
        private String adminUrl = "http://localhost:8989/admin-services";
        private String workflowUrl = "http://localhost:8986/workflow-services";
        private String assessmentUrl = "http://localhost:8990/assessment-services";
        private String jobUrl = "http://localhost:8982/job-services";
        private String integrationUrl = "http://localhost:8991/integration-services";
        private String vendorUrl = "http://localhost:8988/vendor-services";
        private int timeoutSeconds = 10;
    }

    @Getter
    @Setter
    public static class Audit {
        private String table = "audit_log";
        private int detailsLength = 4000;
    }

    @Getter
    @Setter
    public static class Stages {
        private Map<String, String> tabOverrides = new LinkedHashMap<>();
        private Map<String, String> transitionOverrides = new LinkedHashMap<>();
        private List<String> resetReasons = new ArrayList<>(List.of("REMAP", "REPROCESS", "RESCHEDULED", "FRESHER_PIPELINE",
                "OFFER_REJECTED"));
    }

    @Getter
    @Setter
    public static class Applicant {
        private boolean allowScopeAll = false;
        private String rejectStatus = "HR_REJECTED";
        private String remapMode = "IN_PLACE";
        private String rejectTemplate = "APPLICATION_REJECTED";
        private String onHoldTemplate = "APPLICATION_ON_HOLD";
    }

    @Getter
    @Setter
    public static class Storage {
        private String mode = "MEMORY";
        private String bucket;
        private String kmsKeyId;
        private String kekKeys;
        private String kekActive;
        private String prefix = "p5";
        private int urlTtlMinutes = 10;
    }

    @Getter
    @Setter
    public static class Jobs {
        private boolean enabled = true;
        private String zone = "Asia/Kolkata";
        private String outboxCron = "*/30 * * * * *";
        private String reconcileCron = "0 15 * * * *";
    }

    @Getter
    @Setter
    public static class Outbox {
        private int maxAttempts = 10;
        private int backoffBaseSeconds = 30;
        private int backoffMaxSeconds = 3600;
        private int batchSize = 100;
    }

    @Getter
    @Setter
    public static class Profile {
        private boolean enabled = true;
        private int minAge = 18;
        private int maxAge = 60;
    }

    @Getter
    @Setter
    public static class Mapping {
        private boolean enabled = true;
        private boolean remarksRequired = true;
        private boolean eligibilityFailOpen = false;
        private String inviteTemplate = "REGISTRATION_INVITE";
        private String walkInTemplate = "WALK_IN_INVITE";
        private String onlineTemplate = "ONLINE_INTERVIEW_SCHEDULED";
        private String cancelTemplate = "INTERVIEW_CANCELLED";
        private String meetingBaseUrl = "";
        private int maxDaysAhead = 60;
        private boolean adHocWalkInAllowed = true;
        private int maxSlotCapacity = 500;
    }

    @Getter
    @Setter
    public static class Assessment {
        private boolean enabled = true;
        private boolean autoAdvance = true;
        private List<String> versantRoleCodes = new ArrayList<>();
        private List<String> versantLobs = new ArrayList<>();
    }

    @Getter
    @Setter
    public static class Pipeline {
        private boolean enabled = true;
        private int scoreValidityDays = 60;
        private int maxBulkItems = 500;
        private long maxUploadBytes = 2L * 1024 * 1024;
    }

    @Getter
    @Setter
    public static class IdProof {
        private boolean enabled = true;
        private long maxBytes = 5L * 1024 * 1024;
        private String hashPepper;
        private boolean autoVerify = true;
    }

    @Getter
    @Setter
    public static class Photo {
        private boolean enabled = true;
        private int minWidth = 240;
        private int minHeight = 240;
        private long maxBytes = 3L * 1024 * 1024;
        private double matchThreshold = 0.80;
        private double reviewThreshold = 0.60;
    }

    @Getter
    @Setter
    public static class HrRound {
        private boolean enabled = true;
        private int minScreenshots = 1;
        private boolean kioskMatchRequired = true;
        private int maxScreenshotBytes = 2 * 1024 * 1024;
        private double passPercent = 60.0;
    }

    @Getter
    @Setter
    public static class Panel {
        private boolean enabled = true;
        private int orcRestrictionDays = 60;
        private long recordingMaxBytes = 500L * 1024 * 1024;
        private int recordingUrlTtlMinutes = 30;
    }
}
