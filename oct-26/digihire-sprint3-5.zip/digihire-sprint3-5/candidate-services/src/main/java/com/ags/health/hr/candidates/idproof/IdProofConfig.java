package com.ags.health.hr.candidates.idproof;

import com.ags.health.hr.candidates.idproof.port.IdentityHintPort;
import com.ags.health.hr.candidates.idproof.port.IdentityVerificationClient;
import com.ags.health.hr.candidates.idproof.port.IdentityVerificationPort;
import com.ags.health.hr.candidates.idproof.service.IdProofService;
import com.ags.health.hr.candidates.idproof.service.IdVerificationDispatcher;
import com.ags.health.hr.candidates.idproof.store.IdDocumentStore;
import com.ags.health.hr.candidates.shared.config.CandidateP5Properties;
import com.ags.health.hr.candidates.shared.service.CandidateGuard;
import com.ags.health.hr.common.platform.audit.AuditRecorder;
import com.ags.health.hr.common.platform.crypto.IdentifierHasher;
import com.ags.health.hr.common.platform.http.InternalHttp;
import com.ags.health.hr.common.platform.outbox.OutboxStore;
import com.ags.health.hr.common.platform.storage.EnvelopeEncryptingDocumentStore;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.core.JdbcTemplate;

import java.time.Clock;

@Configuration
@ConditionalOnProperty(prefix = "digihire.candidate.id-proof", name = "enabled", havingValue = "true", matchIfMissing = true)
public class IdProofConfig {

    @Bean
    @ConditionalOnMissingBean(IdentityVerificationPort.class)
    public IdentityVerificationPort p5IdentityVerificationPort(InternalHttp p5InternalHttp, CandidateP5Properties props) {
        return new IdentityVerificationClient(p5InternalHttp, props.getClients().getIntegrationUrl());
    }

    @Bean
    @ConditionalOnMissingBean(IdentityHintPort.class)
    public IdentityHintPort p5IdentityHintPort() {
        return candidateId -> java.util.Optional.empty();
    }

    @Bean
    public IdProofService p5IdProofService(JdbcTemplate jdbc, EnvelopeEncryptingDocumentStore p5SecureDocumentStore,
                                           IdentityVerificationPort verifier, IdentityHintPort hints, CandidateGuard guard,
                                           OutboxStore p5OutboxStore, AuditRecorder audit, Clock p5Clock, CandidateP5Properties props) {
        CandidateP5Properties.IdProof p = props.getIdProof();
        if (p.getHashPepper() == null || p.getHashPepper().length() < 16) {
            throw new IllegalStateException("digihire.candidate.id-proof.hash-pepper must be at least 16 characters");
        }
        return new IdProofService(new IdDocumentStore(jdbc), p5SecureDocumentStore, new IdentifierHasher(p.getHashPepper()), verifier,
                hints, guard, p5OutboxStore, audit, p5Clock, new IdProofService.Settings(p.getMaxBytes(), p.isAutoVerify()));
    }

    @Bean
    public IdVerificationDispatcher p5IdVerificationDispatcher(IdProofService p5IdProofService) {
        return new IdVerificationDispatcher(p5IdProofService);
    }
}
