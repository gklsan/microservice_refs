package com.ags.health.hr.candidates.vendorbridge;

import com.ags.health.hr.candidates.shared.service.StatusMoveListener;
import com.ags.health.hr.candidates.shared.service.StatusMovedEvent;
import com.ags.health.hr.common.platform.outbox.OutboxStore;

import java.util.LinkedHashMap;
import java.util.Map;

public class VendorStatusRelay implements StatusMoveListener {

    public static final String EVENT_TYPE = "VENDOR_CANDIDATE_STATUS";

    private final OutboxStore outbox;

    public VendorStatusRelay(OutboxStore outbox) {
        this.outbox = outbox;
    }

    @Override
    public void onMoved(StatusMovedEvent e) {
        if (!"VENDOR".equalsIgnoreCase(e.application().source())) {
            return;
        }
        Map<String, Object> p = new LinkedHashMap<>();
        p.put("applicationId", e.application().id());
        p.put("candidateId", e.application().candidateId());
        p.put("requisitionId", e.application().requisitionId());
        p.put("fromStatus", e.fromStatus());
        p.put("toStatus", e.toStatus());
        p.put("toTab", e.toTab() == null ? null : e.toTab().name());
        p.put("at", e.at().toString());
        outbox.append(EVENT_TYPE, "APPLICATION", e.application().id(), e.application().candidateId(), e.application().id(), p);
    }
}
