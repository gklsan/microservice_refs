package com.ags.health.hr.candidates.assessmentbridge;

import com.ags.health.hr.candidates.shared.domain.Statuses;
import com.ags.health.hr.candidates.shared.port.ApplicationView;

import java.util.Collection;
import java.util.Locale;
import java.util.Set;
import java.util.stream.Collectors;

public class NextStageRouting {

    private final Set<String> versantRoles;
    private final Set<String> versantLobs;
    private final boolean autoAdvance;

    public NextStageRouting(Collection<String> versantRoles, Collection<String> versantLobs, boolean autoAdvance) {
        this.versantRoles = norm(versantRoles);
        this.versantLobs = norm(versantLobs);
        this.autoAdvance = autoAdvance;
    }

    public boolean autoAdvance() {
        return autoAdvance;
    }

    public boolean requiresVersant(String lob, String roleCode) {
        if (versantRoles.contains("*") || versantLobs.contains("*")) {
            return true;
        }
        return (roleCode != null && versantRoles.contains(roleCode.trim().toUpperCase(Locale.ROOT)))
                || (lob != null && versantLobs.contains(lob.trim().toUpperCase(Locale.ROOT)));
    }

    public String afterAssessment(ApplicationView app) {
        return requiresVersant(app.lob(), app.roleCode()) ? Statuses.VERSANT_YET_TO_START : Statuses.PANEL_YET_TO_SCHEDULE;
    }

    public String afterVersant() {
        return Statuses.PANEL_YET_TO_SCHEDULE;
    }

    private static Set<String> norm(Collection<String> values) {
        return values == null ? Set.of() : values.stream().filter(v -> v != null && !v.isBlank())
                .map(v -> v.trim().toUpperCase(Locale.ROOT)).collect(Collectors.toUnmodifiableSet());
    }
}
