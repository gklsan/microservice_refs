package com.ags.health.hr.candidates.idproof.domain;

public enum VerificationStatus { UPLOADED, VERIFYING, VERIFIED, MISMATCH, FAILED, MANUAL_REVIEW, SUPERSEDED }
