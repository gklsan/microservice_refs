package com.ags.health.hr.candidates.mapping.web;

import com.ags.health.hr.candidates.mapping.domain.MappingAssessment;
import com.ags.health.hr.candidates.mapping.domain.SourceChannel;
import com.ags.health.hr.candidates.mapping.service.MappingService;
import com.ags.health.hr.candidates.mapping.store.MappingActionStore;
import com.ags.health.hr.common.platform.caller.CallerProvider;
import org.springframework.http.HttpStatus;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import java.util.Arrays;
import java.util.List;
import java.util.Map;

@ConditionalOnProperty(prefix = "digihire.candidate.mapping", name = "enabled", havingValue = "true", matchIfMissing = true)
@RestController
@RequestMapping("/mapping")
public class MappingController {

    public record InviteRequest(String email, String mobile, String requisitionId, String remarks) {
    }

    private final MappingService mapping;
    private final CallerProvider callers;

    public MappingController(MappingService mapping, CallerProvider callers) {
        this.mapping = mapping;
        this.callers = callers;
    }

    @PostMapping("/assess")
    public MappingAssessment assess(@RequestBody MappingService.AssessRequest body) {
        return mapping.assess(callers.require(), body);
    }

    @PostMapping("/map")
    @ResponseStatus(HttpStatus.CREATED)
    public MappingService.MapOutcome map(@RequestBody MappingService.MapRequest body) {
        return mapping.map(callers.require(), body);
    }

    @PostMapping("/invite")
    @ResponseStatus(HttpStatus.ACCEPTED)
    public void invite(@RequestBody InviteRequest body) {
        mapping.inviteToRegister(callers.require(), body.email(), body.mobile(), body.requisitionId(), body.remarks());
    }

    @GetMapping("/candidates/{candidateId}/actions")
    public List<MappingActionStore.Entry> timeline(@PathVariable String candidateId,
                                                   @RequestParam(defaultValue = "100") int limit) {
        return mapping.timeline(callers.require(), candidateId, limit);
    }

    @GetMapping("/sources")
    public List<Map<String, Object>> sources() {
        return Arrays.stream(SourceChannel.values()).map(s -> Map.<String, Object>of("code", s.name(),
                "subSourceRequired", s.subSourceRequired(), "subSourceLabel", s.subSourceLabel())).toList();
    }
}
