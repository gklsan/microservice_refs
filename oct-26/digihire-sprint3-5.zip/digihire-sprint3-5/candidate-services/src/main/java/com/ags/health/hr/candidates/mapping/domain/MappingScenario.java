package com.ags.health.hr.candidates.mapping.domain;

public enum MappingScenario {
    S1_UNTAGGED_NO_APPLICATION(MappingAction.TAG_AND_MAP),
    S2_TAGGED_TO_ME_NO_APPLICATION(MappingAction.MAP),
    S3_TAGGED_TO_OTHER_NO_APPLICATION(MappingAction.REQUEST_ACCESS),
    S4_OPEN_APPLICATION_MINE(MappingAction.REMAP),
    S5_OPEN_APPLICATION_OTHER(MappingAction.REQUEST_ACCESS),
    S6_NOT_REGISTERED(MappingAction.INVITE_TO_REGISTER);

    private final MappingAction defaultAction;

    MappingScenario(MappingAction defaultAction) {
        this.defaultAction = defaultAction;
    }

    public MappingAction defaultAction() {
        return defaultAction;
    }
}
