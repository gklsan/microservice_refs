package com.ags.health.hr.candidates.hrround;

import com.ags.health.hr.candidates.hrround.service.CompetencyService;
import com.ags.health.hr.candidates.hrround.service.HrRoundService;
import com.ags.health.hr.candidates.hrround.store.CompetencyStore;
import com.ags.health.hr.candidates.hrround.store.HrInterviewStore;
import com.ags.health.hr.candidates.mapping.service.RejectionReasonService;
import com.ags.health.hr.candidates.photo.service.PhotoVerificationService;
import com.ags.health.hr.candidates.shared.config.CandidateP5Properties;
import com.ags.health.hr.candidates.shared.domain.TabMovementPolicy;
import com.ags.health.hr.candidates.shared.service.ApplicantActionGuard;
import com.ags.health.hr.candidates.shared.service.StatusMover;
import com.ags.health.hr.common.platform.audit.AuditRecorder;
import com.ags.health.hr.common.platform.storage.EnvelopeEncryptingDocumentStore;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.core.JdbcTemplate;

import java.time.Clock;

@Configuration
@ConditionalOnProperty(prefix = "digihire.candidate.hr-round", name = "enabled", havingValue = "true", matchIfMissing = true)
public class HrRoundConfig {

    @Bean
    public CompetencyService p5CompetencyService(JdbcTemplate jdbc, AuditRecorder audit, Clock p5Clock) {
        return new CompetencyService(new CompetencyStore(jdbc), audit, p5Clock);
    }

    @Bean
    public HrRoundService p5HrRoundService(JdbcTemplate jdbc, StatusMover mover, ApplicantActionGuard guard, TabMovementPolicy policy,
                                           PhotoVerificationService photos, RejectionReasonService reasons,
                                           EnvelopeEncryptingDocumentStore p5SecureDocumentStore, AuditRecorder audit, Clock p5Clock,
                                           CandidateP5Properties props) {
        CandidateP5Properties.HrRound h = props.getHrRound();
        return new HrRoundService(new HrInterviewStore(jdbc), new CompetencyStore(jdbc), mover, guard, policy, photos, reasons,
                p5SecureDocumentStore, audit, p5Clock, new HrRoundService.Settings(h.getMinScreenshots(), h.isKioskMatchRequired(),
                h.getPassPercent(), h.getMaxScreenshotBytes(), props.getApplicant().getRejectTemplate()));
    }
}
