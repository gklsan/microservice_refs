package com.ags.health.hr.candidates.pipeline.service;

import com.ags.health.hr.candidates.assessmentbridge.NextStageRouting;
import com.ags.health.hr.candidates.pipeline.domain.BulkRow;
import com.ags.health.hr.candidates.pipeline.domain.BulkRowReader;
import com.ags.health.hr.candidates.pipeline.domain.ReprocessPlanner;
import com.ags.health.hr.candidates.pipeline.domain.StageHistoryValidator;
import com.ags.health.hr.candidates.pipeline.store.BulkJobStore;
import com.ags.health.hr.candidates.shared.domain.Reasons;
import com.ags.health.hr.candidates.shared.domain.StageCatalog;
import com.ags.health.hr.candidates.shared.domain.Tab;
import com.ags.health.hr.candidates.shared.port.ApplicationView;
import com.ags.health.hr.candidates.shared.port.StageHistoryPort;
import com.ags.health.hr.candidates.shared.service.ApplicantActionGuard;
import com.ags.health.hr.candidates.shared.service.Remarks;
import com.ags.health.hr.candidates.shared.service.StatusMover;
import com.ags.health.hr.common.platform.assessment.AssessmentPort;
import com.ags.health.hr.common.platform.audit.AuditRecorder;
import com.ags.health.hr.common.platform.bulk.BulkItemResult;
import com.ags.health.hr.common.platform.bulk.BulkSummary;
import com.ags.health.hr.common.platform.caller.Caller;
import com.ags.health.hr.common.platform.error.PlatformException;
import com.ags.health.hr.common.platform.workflow.WorkflowDecision;
import org.springframework.transaction.support.TransactionTemplate;

import java.time.Clock;
import java.time.Instant;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;

public class PipelineService {

    public static final String BULK = "APPLICATION:BULK_UPDATE";
    public static final String REPROCESS = "APPLICATION:REPROCESS";

    public record BulkRequest(List<String> applicationIds, String targetStatus, String reasonCode, String remarks, boolean dryRun) {
    }

    public record ReprocessPreview(String applicationId, String currentStatus, String resumeAt, String basis, boolean scoreReused,
                                   List<String> problems) {
    }

    public record Settings(int maxItems, long maxUploadBytes) {
    }

    private final StatusMover mover;
    private final ApplicantActionGuard guard;
    private final StageHistoryPort history;
    private final AssessmentPort assessments;
    private final NextStageRouting routing;
    private final StageCatalog catalog;
    private final StageHistoryValidator validator;
    private final ReprocessPlanner planner;
    private final List<BulkRowReader> readers;
    private final BulkJobStore jobs;
    private final TransactionTemplate tx;
    private final AuditRecorder audit;
    private final Clock clock;
    private final Settings settings;

    public PipelineService(StatusMover mover, ApplicantActionGuard guard, StageHistoryPort history, AssessmentPort assessments,
                           NextStageRouting routing, StageCatalog catalog, List<BulkRowReader> readers, BulkJobStore jobs,
                           TransactionTemplate tx, AuditRecorder audit, Clock clock, Settings settings) {
        this.mover = mover;
        this.guard = guard;
        this.history = history;
        this.assessments = assessments;
        this.routing = routing;
        this.catalog = catalog;
        this.validator = new StageHistoryValidator();
        this.planner = new ReprocessPlanner();
        this.readers = List.copyOf(readers);
        this.jobs = jobs;
        this.tx = tx;
        this.audit = audit;
        this.clock = clock;
        this.settings = settings;
    }

    public BulkSummary bulk(Caller caller, BulkRequest req) {
        if (!caller.has(BULK)) {
            throw PlatformException.forbidden("PERMISSION_DENIED", "Missing permission " + BULK);
        }
        if (req == null || req.applicationIds() == null || req.applicationIds().isEmpty()) {
            throw PlatformException.badRequest("SELECTION_EMPTY", "Select at least one applicant");
        }
        List<String> ids = new ArrayList<>(new LinkedHashSet<>(req.applicationIds()));
        List<BulkRow> rows = new ArrayList<>();
        for (int i = 0; i < ids.size(); i++) {
            rows.add(new BulkRow(i + 1, ids.get(i), req.targetStatus(), req.reasonCode(), req.remarks()));
        }
        return run(caller, "MULTI_SELECT", rows, req.dryRun());
    }

    public BulkSummary upload(Caller caller, String fileName, byte[] content, boolean dryRun) {
        if (!caller.has(BULK)) {
            throw PlatformException.forbidden("PERMISSION_DENIED", "Missing permission " + BULK);
        }
        if (content == null || content.length == 0 || content.length > settings.maxUploadBytes()) {
            throw PlatformException.badRequest("FILE_SIZE_INVALID", "File must be between 1 byte and " + settings.maxUploadBytes() + " bytes");
        }
        BulkRowReader reader = readers.stream().filter(r -> r.supports(fileName)).findFirst()
                .orElseThrow(() -> PlatformException.badRequest("FILE_TYPE_NOT_ALLOWED", "Upload a .xlsx or .csv file"));
        return run(caller, "EXCEL_UPLOAD", reader.read(content, settings.maxItems()), dryRun);
    }

    public ReprocessPreview previewReprocess(Caller caller, String applicationId) {
        ApplicationView app = mover.load(applicationId);
        guard.require(caller, app, REPROCESS);
        return preview(app);
    }

    public ReprocessPreview reprocess(Caller caller, String applicationId, String remarks) {
        String text = Remarks.clean(remarks, true);
        return tx.execute(status -> {
            ApplicationView app = mover.load(applicationId);
            guard.require(caller, app, REPROCESS);
            ReprocessPreview p = preview(app);
            if (!p.problems().isEmpty()) {
                throw new PlatformException(409, "REPROCESS_BLOCKED", "Applicant can not be re-processed",
                        p.problems().stream().map(x -> Map.<String, Object>of("code", x)).toList());
            }
            mover.move(caller, app, StatusMover.Move.to(app.id(), p.resumeAt(), REPROCESS).reason(Reasons.REPROCESS, text)
                    .asReset().with("basis", p.basis()).with("scoreReused", p.scoreReused()));
            return p;
        });
    }

    private ReprocessPreview preview(ApplicationView app) {
        List<String> problems = new ArrayList<>();
        Tab tab = catalog.tabOf(app.status());
        if (tab != Tab.PIPELINE && tab != Tab.REJECTED) {
            problems.add("NOT_IN_PIPELINE_OR_REJECTED");
        }
        boolean valid = !scores(app.candidateId()).isEmpty();
        ReprocessPlanner.Plan plan = planner.plan(history.history(app.id()), valid, routing.requiresVersant(app.lob(), app.roleCode()),
                clock.instant());
        StageHistoryValidator.Check check = validator.check(plan.resumeAt(), history.history(app.id()), scores(app.candidateId()),
                routing.requiresVersant(app.lob(), app.roleCode()), clock.instant());
        problems.addAll(check.problems());
        return new ReprocessPreview(app.id(), app.status(), plan.resumeAt(), plan.basis(), plan.scoreReused(), List.copyOf(problems));
    }

    private BulkSummary run(Caller caller, String source, List<BulkRow> rows, boolean dryRun) {
        if (rows.isEmpty()) {
            throw PlatformException.badRequest("SELECTION_EMPTY", "No rows to process");
        }
        if (rows.size() > settings.maxItems()) {
            throw PlatformException.badRequest("TOO_MANY_ITEMS", "At most " + settings.maxItems() + " applicants per bulk action");
        }
        String jobId = UUID.randomUUID().toString();
        Instant now = clock.instant();
        String commonTarget = rows.stream().map(BulkRow::targetStatus).distinct().count() == 1 ? rows.get(0).targetStatus() : "MIXED";
        tx.execute(s -> {
            jobs.start(jobId, source, commonTarget, dryRun, rows.size(), caller.userId(), now);
            return null;
        });
        List<BulkItemResult> results = new ArrayList<>();
        for (BulkRow row : rows) {
            BulkItemResult r;
            try {
                r = tx.execute(s -> one(caller, row, dryRun));
            } catch (PlatformException e) {
                r = BulkItemResult.failed(row.rowNo(), row.applicationId(), e.getCode(), e.getMessage());
            } catch (RuntimeException e) {
                r = BulkItemResult.failed(row.rowNo(), row.applicationId(), "ERROR", "Unexpected error");
            }
            BulkItemResult item = r;
            results.add(item);
            tx.execute(s -> {
            jobs.item(jobId, item);
            return null;
        });
        }
        BulkSummary summary = BulkSummary.of(jobId, results);
        tx.execute(s -> {
            jobs.finish(jobId, summary.succeeded(), summary.failed(), clock.instant());
            return null;
        });
        audit.recordQuietly("WORKFLOW_TRANSITION", dryRun ? "BULK_STATUS_VALIDATED" : "BULK_STATUS_UPDATED", "BULK_JOB", jobId, null,
                summary.failed() == 0 ? AuditRecorder.SUCCESS : AuditRecorder.FAILURE, null,
                AuditRecorder.details("source", source, "total", summary.total(), "succeeded", summary.succeeded(),
                        "failed", summary.failed(), "target", commonTarget));
        return summary;
    }

    private BulkItemResult one(Caller caller, BulkRow row, boolean dryRun) {
        if (row.applicationId() == null || row.targetStatus() == null) {
            return BulkItemResult.failed(row.rowNo(), row.applicationId(), "ROW_INCOMPLETE", "applicationId and targetStatus are required");
        }
        String target = row.targetStatus().trim().toUpperCase(Locale.ROOT);
        if (!catalog.known(target)) {
            return BulkItemResult.failed(row.rowNo(), row.applicationId(), "UNKNOWN_STATUS", "Unknown status " + row.targetStatus());
        }
        ApplicationView app = mover.load(row.applicationId().trim());
        guard.require(caller, app, BULK);
        if (catalog.tabOf(app.status()) == Tab.PIPELINE && catalog.tabOf(target) != Tab.PIPELINE && catalog.tabOf(target) != Tab.REJECTED) {
            StageHistoryValidator.Check check = validator.check(target, history.history(app.id()), scores(app.candidateId()),
                    routing.requiresVersant(app.lob(), app.roleCode()), clock.instant());
            if (!check.ok()) {
                return BulkItemResult.failed(row.rowNo(), app.id(), "STAGE_HISTORY_INVALID", String.join(",", check.problems()));
            }
        }
        if (dryRun) {
            WorkflowDecision d = mover.preview(caller, app.id(), target, BULK);
            return d.allowed() ? BulkItemResult.ok(row.rowNo(), app.id(), app.status(), target)
                    : BulkItemResult.failed(row.rowNo(), app.id(), d.code(), d.message());
        }
        String reason = row.reasonCode() == null ? Reasons.BULK : row.reasonCode().trim().toUpperCase(Locale.ROOT);
        StatusMover.Result r = mover.move(caller, app, StatusMover.Move.to(app.id(), target, BULK).reason(reason, row.remarks()));
        return BulkItemResult.ok(row.rowNo(), app.id(), r.fromStatus(), r.toStatus());
    }

    private List<AssessmentPort.ValidScore> scores(String candidateId) {
        try {
            return assessments.validScores(candidateId);
        } catch (RuntimeException e) {
            throw PlatformException.unavailable("ASSESSMENT_UNAVAILABLE", "Assessment scores could not be checked");
        }
    }

    public Map<String, Object> job(Caller caller, String jobId) {
        if (!caller.has(BULK)) {
            throw PlatformException.forbidden("PERMISSION_DENIED", "Missing permission " + BULK);
        }
        Map<String, Object> job = jobs.job(jobId);
        if (job == null) {
            throw PlatformException.notFound("Bulk job", jobId);
        }
        return Map.of("job", job, "items", jobs.items(jobId));
    }
}
