package com.ags.health.hr.candidates.shared.domain;

import java.util.Arrays;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import static com.ags.health.hr.candidates.shared.domain.Statuses.*;

public class TabMovementPolicy {

    private final Map<String, Set<String>> allowed;
    private final StageCatalog catalog;

    public TabMovementPolicy(StageCatalog catalog, Map<String, String> overrides) {
        this.catalog = catalog;
        Map<String, Set<String>> m = new LinkedHashMap<>(defaults());
        if (overrides != null) {
            overrides.forEach((from, targets) -> m.put(StageCatalog.norm(from), Arrays.stream(targets.split("[|,]"))
                    .map(String::trim).filter(s -> !s.isEmpty()).map(StageCatalog::norm)
                    .collect(Collectors.toCollection(LinkedHashSet::new))));
        }
        this.allowed = Collections.unmodifiableMap(m);
    }

    public static TabMovementPolicy standard() {
        return new TabMovementPolicy(StageCatalog.standard(), Map.of());
    }

    public boolean allows(String from, String to) {
        if (from == null || to == null) {
            return false;
        }
        String f = StageCatalog.norm(from);
        String t = StageCatalog.norm(to);
        if (f.equals(t)) {
            return false;
        }
        if (REMAPPED.equals(t)) {
            return catalog.isOpen(f) && !catalog.lockedForRemap(f);
        }
        return allowed.getOrDefault(f, Set.of()).contains(t);
    }

    public List<String> targets(String from) {
        if (from == null) {
            return List.of();
        }
        return List.copyOf(allowed.getOrDefault(StageCatalog.norm(from), Set.of()));
    }

    public static Map<String, Set<String>> defaults() {
        Map<String, Set<String>> m = new LinkedHashMap<>();
        put(m, REGISTERED, CREATED, PIPELINE);
        put(m, CREATED, WALKEDIN, WAITING_FOR_HRROUND, HR_REJECTED, PIPELINE);
        put(m, WALKEDIN, WAITING_FOR_HRROUND, HR_REJECTED, PIPELINE);
        put(m, PIPELINE, CREATED, WAITING_FOR_HRROUND, WAITING_FOR_DEVICE, ASSESEMENT_YET_TO_START, VERSANT_YET_TO_START,
                PANEL_YET_TO_SCHEDULE, SHORTLISTED, HR_REJECTED);
        put(m, WAITING_FOR_HRROUND, INTERVIEW_INPROGRESS, HR_REJECTED, PIPELINE);
        put(m, INTERVIEW_INPROGRESS, WAITING_FOR_DEVICE, ASSESEMENT_YET_TO_START, VERSANT_YET_TO_START,
                PANEL_YET_TO_SCHEDULE, HR_REJECTED, PIPELINE);
        put(m, WAITING_FOR_DEVICE, ASSESEMENT_YET_TO_START, DEVICE_ALLOCATION_FAILED, PIPELINE);
        put(m, DEVICE_ALLOCATION_FAILED, WAITING_FOR_DEVICE, PIPELINE);
        put(m, ASSESEMENT_YET_TO_START, ASSESEMENT_INPROGRESS, ASSESEMENT_COMPLETED, ASSESEMENT_FAILED, PIPELINE);
        put(m, ASSESEMENT_INPROGRESS, ASSESEMENT_COMPLETED, ASSESEMENT_FAILED, ASSESEMENT_YET_TO_START, PIPELINE);
        put(m, ASSESEMENT_COMPLETED, VERSANT_YET_TO_START, VERSANT_COMPLETED, PANEL_YET_TO_SCHEDULE, PIPELINE);
        put(m, ASSESEMENT_FAILED, PIPELINE, ASSESEMENT_YET_TO_START);
        put(m, VERSANT_YET_TO_START, VERSANT_INPROGRESS, VERSANT_COMPLETED, VERSANT_FAILED, VERSANT_NOT_TAKEN, PIPELINE);
        put(m, VERSANT_INPROGRESS, VERSANT_COMPLETED, VERSANT_FAILED, VERSANT_NOT_TAKEN, VERSANT_YET_TO_START, PIPELINE);
        put(m, VERSANT_NOT_TAKEN, VERSANT_YET_TO_START, PIPELINE);
        put(m, VERSANT_COMPLETED, PANEL_YET_TO_SCHEDULE, PIPELINE);
        put(m, VERSANT_FAILED, PIPELINE, VERSANT_YET_TO_START);
        put(m, PANEL_YET_TO_SCHEDULE, PANEL_INPROGRESS, PIPELINE);
        put(m, PANEL_INPROGRESS, PANEL_SELECTED, PANEL_REJECTED, PANEL_ON_HOLD, PANEL_DECLINED, PANEL_YET_TO_SCHEDULE);
        put(m, PANEL_ON_HOLD, PANEL_SELECTED, PANEL_REJECTED, PANEL_YET_TO_SCHEDULE, PIPELINE);
        put(m, PANEL_SELECTED, SHORTLISTED, PIPELINE);
        put(m, SHORTLISTED, OFFERED, PIPELINE);
        put(m, OFFERED, JOINED, SHORTLISTED, DEFERRED, WITHHELD);
        put(m, DEFERRED, OFFERED, PIPELINE);
        put(m, WITHHELD, OFFERED, PIPELINE);
        put(m, HR_REJECTED, PIPELINE);
        put(m, PANEL_REJECTED, PIPELINE);
        put(m, PANEL_DECLINED, PIPELINE);
        return m;
    }

    private static void put(Map<String, Set<String>> m, String from, String... to) {
        m.put(from, new LinkedHashSet<>(List.of(to)));
    }
}
