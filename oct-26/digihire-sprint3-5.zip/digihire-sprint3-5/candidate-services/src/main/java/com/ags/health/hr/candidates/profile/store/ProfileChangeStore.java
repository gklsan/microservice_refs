package com.ags.health.hr.candidates.profile.store;

import org.springframework.jdbc.core.JdbcTemplate;

import java.sql.Timestamp;
import java.time.Instant;
import java.util.List;
import java.util.UUID;

public class ProfileChangeStore {

    public record Change(String id, String candidateId, String fieldKey, String oldValue, String newValue, String actorId,
                         String actorName, String basis, String overrideReason, Instant at) {
    }

    private final JdbcTemplate jdbc;

    public ProfileChangeStore(JdbcTemplate jdbc) {
        this.jdbc = jdbc;
    }

    public void append(List<Change> changes) {
        for (Change c : changes) {
            jdbc.update("INSERT INTO cand_profile_change (id, candidate_id, field_key, old_value, new_value, actor_id, "
                            + "actor_name, basis, override_reason, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
                    c.id() == null ? UUID.randomUUID().toString() : c.id(), c.candidateId(), c.fieldKey(), c.oldValue(),
                    c.newValue(), c.actorId(), c.actorName(), c.basis(), c.overrideReason(), Timestamp.from(c.at()));
        }
    }

    public List<Change> history(String candidateId, int limit) {
        return jdbc.query("SELECT id, candidate_id, field_key, old_value, new_value, actor_id, actor_name, basis, "
                        + "override_reason, created_at FROM cand_profile_change WHERE candidate_id = ? "
                        + "ORDER BY created_at DESC, id LIMIT ?",
                (rs, i) -> new Change(rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5),
                        rs.getString(6), rs.getString(7), rs.getString(8), rs.getString(9), rs.getTimestamp(10).toInstant()),
                candidateId, Math.max(1, Math.min(limit, 500)));
    }
}
