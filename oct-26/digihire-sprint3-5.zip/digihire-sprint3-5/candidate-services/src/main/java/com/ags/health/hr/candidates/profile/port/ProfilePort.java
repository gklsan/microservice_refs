package com.ags.health.hr.candidates.profile.port;

import com.ags.health.hr.candidates.shared.port.StatusChange;

import java.util.Map;
import java.util.Optional;

public interface ProfilePort {

    Optional<Map<String, Object>> load(String candidateId);

    void apply(String candidateId, Map<String, Object> changes, StatusChange actor);

    Optional<String> candidateIdByEmailOrMobile(String email, String mobile);
}
