package com.ags.health.hr.candidates.photo.domain;

public enum PhotoDecision { MATCH, UNSURE, MISMATCH }
