package com.ags.health.hr.candidates.profile.domain;

import java.util.ArrayList;
import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import static com.ags.health.hr.candidates.profile.domain.FieldType.*;
import static com.ags.health.hr.candidates.profile.domain.ProfileStage.*;

public class FieldCatalog {

    public static final List<String> GENDERS = List.of("MALE", "FEMALE", "OTHER", "UNDISCLOSED");
    public static final List<String> QUALIFICATIONS = List.of("SSLC", "HSC", "DIPLOMA", "UG", "PG", "DOCTORATE");
    public static final List<String> EXPERIENCE_TYPES = List.of("FRESHER", "EXPERIENCED");

    private final Map<String, FieldDefinition> fields;

    public FieldCatalog(Collection<FieldDefinition> definitions) {
        Map<String, FieldDefinition> m = new LinkedHashMap<>();
        for (FieldDefinition d : definitions) {
            if (m.put(d.key(), d) != null) {
                throw new IllegalArgumentException("Duplicate profile field " + d.key());
            }
        }
        this.fields = Map.copyOf(m);
        this.order = List.copyOf(m.keySet());
    }

    private final List<String> order;

    public static FieldCatalog standard(int currentYear) {
        List<FieldDefinition> d = new ArrayList<>();
        d.add(f("firstName", "First name", "PERSONAL", NAME, true, APPLICANT, false, 80));
        d.add(f("middleName", "Middle name", "PERSONAL", NAME, false, APPLICANT, false, 80));
        d.add(f("lastName", "Last name", "PERSONAL", NAME, true, APPLICANT, false, 80));
        d.add(f("dateOfBirth", "Date of birth", "PERSONAL", DOB, true, APPLICANT, true, 10));
        d.add(new FieldDefinition("gender", "Gender", "PERSONAL", CHOICE, true, APPLICANT, false, 20, null, null, GENDERS));
        d.add(f("email", "Email", "CONTACT", EMAIL, true, APPLICANT, true, 254));
        d.add(f("mobile", "Mobile", "CONTACT", MOBILE, true, APPLICANT, true, 20));
        d.add(f("alternateMobile", "Alternate mobile", "CONTACT", MOBILE, false, null, true, 20));
        d.add(f("addressLine1", "Address line 1", "ADDRESS", TEXT, true, OFFER, false, 200));
        d.add(f("addressLine2", "Address line 2", "ADDRESS", TEXT, false, OFFER, false, 200));
        d.add(f("city", "City", "ADDRESS", TEXT, true, OFFER, false, 80));
        d.add(f("state", "State", "ADDRESS", TEXT, true, OFFER, false, 80));
        d.add(f("pincode", "PIN code", "ADDRESS", PINCODE, true, OFFER, false, 6));
        d.add(f("panNumber", "PAN", "IDENTITY", PAN, false, APPLICANT, true, 10));
        d.add(f("aadhaarNumber", "Aadhaar", "IDENTITY", AADHAAR, false, APPLICANT, true, 12));
        d.add(f("passportNumber", "Passport", "IDENTITY", PASSPORT, false, APPLICANT, true, 9));
        d.add(new FieldDefinition("highestQualification", "Highest qualification", "EDUCATION", CHOICE, true, IN_PROCESS,
                false, 20, null, null, QUALIFICATIONS));
        d.add(new FieldDefinition("yearOfPassing", "Year of passing", "EDUCATION", NUMBER, true, IN_PROCESS, false, 4,
                1970L, (long) currentYear + 1, List.of()));
        d.add(new FieldDefinition("experienceType", "Fresher / experienced", "EXPERIENCE", CHOICE, true, IN_PROCESS, false,
                20, null, null, EXPERIENCE_TYPES));
        d.add(new FieldDefinition("totalExperienceMonths", "Total experience (months)", "EXPERIENCE", NUMBER, false,
                IN_PROCESS, false, 3, 0L, 600L, List.of()));
        d.add(new FieldDefinition("currentCtc", "Current CTC (annual)", "EXPERIENCE", NUMBER, false, OFFER, true, 10, 0L,
                100_000_000L, List.of()));
        d.add(new FieldDefinition("expectedCtc", "Expected CTC (annual)", "EXPERIENCE", NUMBER, false, OFFER, true, 10, 0L,
                100_000_000L, List.of()));
        d.add(new FieldDefinition("noticePeriodDays", "Notice period (days)", "EXPERIENCE", NUMBER, false, OFFER, false, 3,
                0L, 180L, List.of()));
        d.add(f("preferredLocation", "Preferred location", "PREFERENCES", TEXT, false, IN_PROCESS, false, 80));
        d.add(new FieldDefinition("willingToRelocate", "Willing to relocate", "PREFERENCES", BOOLEAN, false, null, false,
                5, null, null, List.of()));
        return new FieldCatalog(d);
    }

    private static FieldDefinition f(String key, String label, String section, FieldType type, boolean required,
                                     ProfileStage lockedFrom, boolean sensitive, int max) {
        return new FieldDefinition(key, label, section, type, required, lockedFrom, sensitive, max, null, null, List.of());
    }

    public Optional<FieldDefinition> find(String key) {
        return Optional.ofNullable(key == null ? null : fields.get(key));
    }

    public List<FieldDefinition> all() {
        return order.stream().map(fields::get).toList();
    }

    public List<FieldDefinition> requiredForRegistration() {
        return all().stream().filter(FieldDefinition::requiredForRegistration).toList();
    }
}
