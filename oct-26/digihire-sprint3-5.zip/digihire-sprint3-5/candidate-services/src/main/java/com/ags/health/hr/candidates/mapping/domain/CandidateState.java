package com.ags.health.hr.candidates.mapping.domain;

public enum CandidateState { YET_TO_REGISTER, REGISTERED, APPLICATION_CREATED, IN_PROCESS }
