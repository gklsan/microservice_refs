package com.ags.health.hr.candidates.vendorbridge;

import com.ags.health.hr.candidates.shared.config.CandidateP5Properties;
import com.ags.health.hr.common.platform.http.InternalHttp;
import com.ags.health.hr.common.platform.outbox.OutboxStore;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class VendorBridgeConfig {

    @Bean
    public VendorStatusRelay p5VendorStatusRelay(OutboxStore p5OutboxStore) {
        return new VendorStatusRelay(p5OutboxStore);
    }

    @Bean
    public VendorStatusDispatcher p5VendorStatusDispatcher(InternalHttp p5InternalHttp, CandidateP5Properties props) {
        return new VendorStatusDispatcher(p5InternalHttp, props.getClients().getVendorUrl());
    }
}
