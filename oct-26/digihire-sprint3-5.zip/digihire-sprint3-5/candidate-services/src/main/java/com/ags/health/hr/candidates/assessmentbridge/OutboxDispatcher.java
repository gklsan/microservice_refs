package com.ags.health.hr.candidates.assessmentbridge;

import com.ags.health.hr.common.platform.outbox.OutboxEvent;

public interface OutboxDispatcher {

    String eventType();

    boolean ready();

    void deliver(OutboxEvent event);
}
