package com.ags.health.hr.candidates.profile.domain;

import com.ags.health.hr.common.platform.validation.FieldViolation;
import com.ags.health.hr.common.platform.validation.IdentityValidators;
import com.ags.health.hr.common.platform.validation.IdentityValidators.Kind;

import java.time.LocalDate;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Optional;

public class ProfileValidator {

    public record Outcome(Map<String, Object> normalised, List<FieldViolation> violations) {

        public boolean valid() {
            return violations.isEmpty();
        }
    }

    private final FieldCatalog catalog;
    private final int minAge;
    private final int maxAge;

    public ProfileValidator(FieldCatalog catalog, int minAge, int maxAge) {
        this.catalog = catalog;
        this.minAge = minAge;
        this.maxAge = maxAge;
    }

    public Outcome validate(Map<String, Object> changes, Map<String, Object> current, LocalDate today) {
        Map<String, Object> out = new LinkedHashMap<>();
        List<FieldViolation> violations = new ArrayList<>();
        if (changes == null || changes.isEmpty()) {
            violations.add(new FieldViolation("changes", "EMPTY", "No changes were sent"));
            return new Outcome(out, violations);
        }
        for (Map.Entry<String, Object> e : changes.entrySet()) {
            Optional<FieldDefinition> def = catalog.find(e.getKey());
            if (def.isEmpty()) {
                violations.add(new FieldViolation(e.getKey(), "UNKNOWN_FIELD", "Field is not part of the profile"));
                continue;
            }
            check(def.get(), e.getValue(), today, violations).ifPresent(v -> out.put(def.get().key(), v));
            if (!out.containsKey(def.get().key()) && isBlank(e.getValue())) {
                out.put(def.get().key(), null);
            }
        }
        Map<String, Object> merged = new LinkedHashMap<>(current == null ? Map.of() : current);
        merged.putAll(out);
        crossField(merged, out.keySet(), violations);
        return new Outcome(out, violations);
    }

    public List<FieldViolation> missingForRegistration(Map<String, Object> values) {
        List<FieldViolation> missing = new ArrayList<>();
        for (FieldDefinition d : catalog.requiredForRegistration()) {
            if (values == null || isBlank(values.get(d.key()))) {
                missing.add(new FieldViolation(d.key(), "REQUIRED", d.label() + " is required to complete registration"));
            }
        }
        if (values != null && "EXPERIENCED".equals(values.get("experienceType")) && isBlank(values.get("totalExperienceMonths"))) {
            missing.add(new FieldViolation("totalExperienceMonths", "REQUIRED", "Experience is required for experienced candidates"));
        }
        return missing;
    }

    private Optional<Object> check(FieldDefinition d, Object raw, LocalDate today, List<FieldViolation> violations) {
        if (isBlank(raw)) {
            if (d.requiredForRegistration()) {
                violations.add(new FieldViolation(d.key(), "REQUIRED", d.label() + " can not be cleared"));
            }
            return Optional.empty();
        }
        String text = String.valueOf(raw).strip();
        if (text.length() > d.maxLength() && d.type() != FieldType.NUMBER && d.type() != FieldType.BOOLEAN) {
            violations.add(new FieldViolation(d.key(), "TOO_LONG", d.label() + " must be at most " + d.maxLength() + " characters"));
            return Optional.empty();
        }
        switch (d.type()) {
            case NAME, EMAIL, MOBILE, PAN, AADHAAR, PASSPORT, PINCODE -> {
                Kind kind = Kind.valueOf(d.type().name());
                Optional<String> err = IdentityValidators.check(kind, text);
                if (err.isPresent()) {
                    violations.add(new FieldViolation(d.key(), err.get(), d.label() + " is not valid"));
                    return Optional.empty();
                }
                return Optional.of(IdentityValidators.normalise(kind, text));
            }
            case TEXT -> {
                if (text.chars().anyMatch(c -> c < 0x20) || text.contains("<") || text.contains(">")) {
                    violations.add(new FieldViolation(d.key(), "INVALID_TEXT", d.label() + " contains characters that are not allowed"));
                    return Optional.empty();
                }
                return Optional.of(text);
            }
            case DATE, DOB -> {
                LocalDate date;
                try {
                    date = LocalDate.parse(text);
                } catch (DateTimeParseException e) {
                    violations.add(new FieldViolation(d.key(), "INVALID_DATE", d.label() + " must be YYYY-MM-DD"));
                    return Optional.empty();
                }
                if (d.type() == FieldType.DOB) {
                    Optional<String> err = IdentityValidators.checkAge(date, today, minAge, maxAge);
                    if (err.isPresent()) {
                        violations.add(new FieldViolation(d.key(), err.get(), "Age must be between " + minAge + " and " + maxAge));
                        return Optional.empty();
                    }
                }
                return Optional.of(date.toString());
            }
            case CHOICE -> {
                String v = text.toUpperCase(Locale.ROOT);
                if (!d.options().contains(v)) {
                    violations.add(new FieldViolation(d.key(), "INVALID_CHOICE", d.label() + " must be one of " + d.options()));
                    return Optional.empty();
                }
                return Optional.of(v);
            }
            case NUMBER -> {
                long n;
                try {
                    n = raw instanceof Number num ? num.longValue() : Long.parseLong(text);
                } catch (NumberFormatException e) {
                    violations.add(new FieldViolation(d.key(), "INVALID_NUMBER", d.label() + " must be a whole number"));
                    return Optional.empty();
                }
                if ((d.min() != null && n < d.min()) || (d.max() != null && n > d.max())) {
                    violations.add(new FieldViolation(d.key(), "OUT_OF_RANGE", d.label() + " must be between " + d.min()
                            + " and " + d.max()));
                    return Optional.empty();
                }
                return Optional.of(n);
            }
            case BOOLEAN -> {
                if (raw instanceof Boolean b) {
                    return Optional.of(b);
                }
                if (!text.equalsIgnoreCase("true") && !text.equalsIgnoreCase("false")) {
                    violations.add(new FieldViolation(d.key(), "INVALID_BOOLEAN", d.label() + " must be true or false"));
                    return Optional.empty();
                }
                return Optional.of(Boolean.parseBoolean(text));
            }
            default -> {
                return Optional.of(text);
            }
        }
    }

    private static void crossField(Map<String, Object> merged, java.util.Set<String> touched, List<FieldViolation> violations) {
        Object type = merged.get("experienceType");
        Object months = merged.get("totalExperienceMonths");
        if ("FRESHER".equals(type) && months instanceof Number n && n.longValue() > 0
                && (touched.contains("experienceType") || touched.contains("totalExperienceMonths"))) {
            violations.add(new FieldViolation("totalExperienceMonths", "INCONSISTENT", "A fresher can not have experience months"));
        }
        if (merged.get("mobile") != null && merged.get("mobile").equals(merged.get("alternateMobile"))
                && (touched.contains("mobile") || touched.contains("alternateMobile"))) {
            violations.add(new FieldViolation("alternateMobile", "DUPLICATE", "Alternate mobile must differ from mobile"));
        }
        if (merged.get("currentCtc") instanceof Number c && merged.get("expectedCtc") instanceof Number x
                && x.longValue() > 0 && c.longValue() > 0 && x.longValue() > c.longValue() * 5
                && (touched.contains("currentCtc") || touched.contains("expectedCtc"))) {
            violations.add(new FieldViolation("expectedCtc", "IMPLAUSIBLE", "Expected CTC is more than five times the current CTC"));
        }
    }

    static boolean isBlank(Object v) {
        return v == null || (v instanceof String s && s.isBlank());
    }
}
