package com.ags.health.hr.candidates.hrround.domain;

public record Competency(String code, String name, String lob, String roleCode, int weight, int maxRating, int minRating,
                         boolean mandatory, boolean active, int sortOrder) {

    public boolean appliesTo(String lob, String roleCode) {
        return (this.lob == null || this.lob.equalsIgnoreCase(lob)) && (this.roleCode == null || this.roleCode.equalsIgnoreCase(roleCode));
    }
}
