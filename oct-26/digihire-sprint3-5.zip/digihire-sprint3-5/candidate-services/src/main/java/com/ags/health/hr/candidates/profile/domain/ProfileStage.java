package com.ags.health.hr.candidates.profile.domain;

public enum ProfileStage {
    REGISTRATION, APPLICANT, IN_PROCESS, OFFER;

    public boolean atLeast(ProfileStage other) {
        return other != null && ordinal() >= other.ordinal();
    }
}
