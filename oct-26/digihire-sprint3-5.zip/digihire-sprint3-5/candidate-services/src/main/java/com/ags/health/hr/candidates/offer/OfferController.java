package com.ags.health.hr.candidates.offer;

import com.ags.health.hr.common.platform.caller.CallerProvider;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

@RestController
public class OfferController {

    private final OfferService service;
    private final CallerProvider callers;

    public OfferController(OfferService service, CallerProvider callers) {
        this.service = service;
        this.callers = callers;
    }

    @PostMapping("/applicants/{applicationId}/offer/push")
    public OfferIntegrationPort.PushResult push(@PathVariable String applicationId) {
        return service.push(callers.require(), applicationId);
    }

    @GetMapping("/applicants/{applicationId}/offer/status")
    public Map<String, Object> status(@PathVariable String applicationId) {
        return service.status(callers.require(), applicationId);
    }
}
