package com.ags.health.hr.candidates.pipeline.store;

import com.ags.health.hr.common.platform.bulk.BulkItemResult;
import org.springframework.jdbc.core.JdbcTemplate;

import java.sql.Timestamp;
import java.time.Instant;
import java.util.List;
import java.util.Map;

public class BulkJobStore {

    private final JdbcTemplate jdbc;

    public BulkJobStore(JdbcTemplate jdbc) {
        this.jdbc = jdbc;
    }

    public void start(String id, String source, String targetStatus, boolean dryRun, int total, String actor, Instant at) {
        jdbc.update("INSERT INTO cand_bulk_job (id, source, target_status, dry_run, total, succeeded, failed, created_by, created_at) "
                + "VALUES (?, ?, ?, ?, ?, 0, 0, ?, ?)", id, source, targetStatus, dryRun, total, actor, Timestamp.from(at));
    }

    public void item(String jobId, BulkItemResult r) {
        jdbc.update("INSERT INTO cand_bulk_job_item (job_id, row_no, reference, ok, code, message, from_status, to_status) "
                        + "VALUES (?, ?, ?, ?, ?, ?, ?, ?)", jobId, r.rowNo(), r.reference(), r.ok(), r.code(),
                r.message() == null ? null : r.message().length() > 500 ? r.message().substring(0, 500) : r.message(),
                r.fromStatus(), r.toStatus());
    }

    public void finish(String id, int succeeded, int failed, Instant at) {
        jdbc.update("UPDATE cand_bulk_job SET succeeded = ?, failed = ?, finished_at = ? WHERE id = ?", succeeded, failed,
                Timestamp.from(at), id);
    }

    public List<Map<String, Object>> items(String jobId) {
        return jdbc.queryForList("SELECT row_no, reference, ok, code, message, from_status, to_status FROM cand_bulk_job_item "
                + "WHERE job_id = ? ORDER BY row_no", jobId);
    }

    public Map<String, Object> job(String jobId) {
        List<Map<String, Object>> rows = jdbc.queryForList("SELECT id, source, target_status, dry_run, total, succeeded, failed, "
                + "created_by, created_at, finished_at FROM cand_bulk_job WHERE id = ?", jobId);
        return rows.isEmpty() ? null : rows.get(0);
    }
}
