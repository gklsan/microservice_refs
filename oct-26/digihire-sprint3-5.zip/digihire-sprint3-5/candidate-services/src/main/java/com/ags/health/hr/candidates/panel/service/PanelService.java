package com.ags.health.hr.candidates.panel.service;

import com.ags.health.hr.candidates.mapping.domain.RejectionReason;
import com.ags.health.hr.candidates.mapping.port.MeetingPort;
import com.ags.health.hr.candidates.mapping.service.RejectionReasonService;
import com.ags.health.hr.candidates.panel.port.PanelistDirectoryPort;
import com.ags.health.hr.candidates.panel.store.OrcRestrictionStore;
import com.ags.health.hr.candidates.panel.store.PanelStore;
import com.ags.health.hr.candidates.photo.service.PhotoVerificationService;
import com.ags.health.hr.candidates.shared.domain.Statuses;
import com.ags.health.hr.candidates.shared.port.ApplicationPort;
import com.ags.health.hr.candidates.shared.port.ApplicationView;
import com.ags.health.hr.candidates.shared.port.RequisitionPort;
import com.ags.health.hr.candidates.shared.port.RequisitionView;
import com.ags.health.hr.candidates.shared.service.ApplicantActionGuard;
import com.ags.health.hr.candidates.shared.service.Remarks;
import com.ags.health.hr.candidates.shared.service.StatusMover;
import com.ags.health.hr.common.platform.audit.AuditRecorder;
import com.ags.health.hr.common.platform.caller.Caller;
import com.ags.health.hr.common.platform.error.PlatformException;
import com.ags.health.hr.common.platform.storage.DocumentStore;
import com.ags.health.hr.common.platform.storage.FileInspector;
import org.springframework.transaction.annotation.Transactional;

import java.net.URI;
import java.time.Clock;
import java.time.Duration;
import java.time.Instant;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

public class PanelService {

    public static final String SCHEDULE = "INTERVIEW_SCHEDULE:UPDATE";
    public static final String DECIDE = "PANEL:DECIDE";
    public static final String RECORDING_UPLOAD = "PANEL:RECORDING_UPLOAD";
    public static final String RECORDING_VIEW = "PANEL:RECORDING_VIEW";
    public static final String CHANGE_ORC = "PANEL:CHANGE_ORC";
    public static final Set<String> RESCHEDULE_REASONS = Set.of("BUSINESS_NEED", "PANELIST_UNAVAILABLE", "CANDIDATE_REQUEST",
            "TECHNICAL_ISSUE");
    public static final String PHOTO_MISMATCH = "PHOTO_MISMATCH";

    public enum Outcome { SELECT, REJECT, HOLD }

    public enum OrcPath { SAME_PANEL, DIFFERENT_PANEL }

    public record ScheduleRequest(String lob, String location, String orcId, List<String> panelistIds, String mode, Instant startsAt,
                                  Instant endsAt, String remarks) {
    }

    public record RescheduleRequest(Instant startsAt, Instant endsAt, List<String> panelistIds, String reasonCode, String remarks) {
    }

    public record DecisionRequest(String outcome, String reasonCode, String remarks) {
    }

    public record OrcChangeRequest(String requisitionId, String path, String remarks) {
    }

    public record UploadTicket(String recordingId, URI uploadUrl, String contentType, Instant expiresAt) {
    }

    public record Settings(int orcRestrictionDays, long recordingMaxBytes, int recordingUrlTtlMinutes, String rejectTemplate) {
    }

    private final PanelStore store;
    private final OrcRestrictionStore restrictions;
    private final PanelistDirectoryPort panelists;
    private final MeetingPort meetings;
    private final RequisitionPort requisitions;
    private final ApplicationPort applications;
    private final StatusMover mover;
    private final ApplicantActionGuard guard;
    private final RejectionReasonService reasons;
    private final PhotoVerificationService photos;
    private final DocumentStore files;
    private final AuditRecorder audit;
    private final Clock clock;
    private final Settings settings;

    public PanelService(PanelStore store, OrcRestrictionStore restrictions, PanelistDirectoryPort panelists, MeetingPort meetings,
                        RequisitionPort requisitions, ApplicationPort applications, StatusMover mover, ApplicantActionGuard guard, RejectionReasonService reasons,
                        PhotoVerificationService photos, DocumentStore files, AuditRecorder audit, Clock clock, Settings settings) {
        this.store = store;
        this.restrictions = restrictions;
        this.panelists = panelists;
        this.meetings = meetings;
        this.requisitions = requisitions;
        this.applications = applications;
        this.mover = mover;
        this.guard = guard;
        this.reasons = reasons;
        this.photos = photos;
        this.files = files;
        this.audit = audit;
        this.clock = clock;
        this.settings = settings;
    }

    @Transactional
    public PanelStore.Schedule schedule(Caller caller, String applicationId, ScheduleRequest req) {
        ApplicationView app = mover.load(applicationId);
        guard.require(caller, app, SCHEDULE);
        if (req == null) {
            throw PlatformException.badRequest("SCHEDULE_INVALID", "Schedule details are required");
        }
        if (!Statuses.PANEL_YET_TO_SCHEDULE.equals(app.status()) && !Statuses.PANEL_ON_HOLD.equals(app.status())) {
            throw PlatformException.conflict("NOT_READY_FOR_PANEL", "Applicant is at " + app.status());
        }
        if (store.active(app.id()).isPresent()) {
            throw PlatformException.conflict("PANEL_ALREADY_SCHEDULED", "A panel interview is already scheduled; reschedule it instead");
        }
        String lob = required(req.lob(), "LOB");
        String location = required(req.location(), "Location");
        String orc = required(req.orcId(), "ORC id");
        restrictions.activeUntil(app.candidateId(), orc, clock.instant()).ifPresent(until -> {
            throw new PlatformException(409, "ORC_RESTRICTED", "Candidate can not be interviewed for ORC " + orc + " until " + until, null);
        });
        List<String> ids = panelists(req.panelistIds());
        window(req.startsAt(), req.endsAt());
        String mode = req.mode() == null ? "ONLINE" : req.mode().trim().toUpperCase(Locale.ROOT);
        MeetingPort.Meeting meeting = "ONLINE".equals(mode) ? meetings.create("Panel interview", req.startsAt(), req.endsAt(), caller.email(),
                emails(ids)) : null;
        Instant now = clock.instant();
        PanelStore.Schedule s = store.create(app.id(), app.candidateId(), lob, location, orc, ids, mode, req.startsAt(), req.endsAt(),
                meeting == null ? null : meeting.externalId(), meeting == null ? null : meeting.joinUrl(), caller.userId(), now);
        String remarks = Remarks.clean(req.remarks(), false);
        store.history(s.id(), app.id(), "SCHEDULED", null, snapshot(s), null, remarks, caller.userId(), now);
        mover.move(caller, app, StatusMover.Move.to(app.id(), Statuses.PANEL_INPROGRESS, SCHEDULE).reason(null, remarks)
                .with("scheduleId", s.id()).with("orcId", orc).notify("PANEL_INTERVIEW_SCHEDULED").with("startsAt", s.startsAt().toString())
                .with("meetingUrl", s.meetingUrl()));
        return s;
    }

    @Transactional
    public PanelStore.Schedule reschedule(Caller caller, String scheduleId, RescheduleRequest req) {
        PanelStore.Schedule s = schedule(scheduleId);
        ApplicationView app = mover.load(s.applicationId());
        guard.require(caller, app, SCHEDULE);
        if (!"SCHEDULED".equals(s.status())) {
            throw PlatformException.conflict("SCHEDULE_CLOSED", "Panel interview is already " + s.status());
        }
        String reason = req.reasonCode() == null ? null : req.reasonCode().trim().toUpperCase(Locale.ROOT);
        if (!RESCHEDULE_REASONS.contains(reason)) {
            throw PlatformException.badRequest("RESCHEDULE_REASON_INVALID", "Reason must be one of " + RESCHEDULE_REASONS);
        }
        String remarks = Remarks.clean(req.remarks(), true);
        window(req.startsAt(), req.endsAt());
        List<String> ids = req.panelistIds() == null || req.panelistIds().isEmpty() ? s.panelistIds() : panelists(req.panelistIds());
        String meetingId = s.meetingId();
        String meetingUrl = s.meetingUrl();
        if (s.meetingId() != null) {
            meetings.cancel(s.meetingId());
            MeetingPort.Meeting m = meetings.create("Panel interview", req.startsAt(), req.endsAt(), caller.email(), emails(ids));
            meetingId = m.externalId();
            meetingUrl = m.joinUrl();
        }
        Map<String, Object> before = snapshot(s);
        store.reschedule(s.id(), req.startsAt(), req.endsAt(), ids, meetingId, meetingUrl);
        PanelStore.Schedule after = schedule(s.id());
        store.history(s.id(), s.applicationId(), "RESCHEDULED", before, snapshot(after), reason, remarks, caller.userId(), clock.instant());
        audit.record("ACTIVITY", "PANEL_RESCHEDULED", "APPLICATION", s.applicationId(), s.candidateId(), AuditRecorder.SUCCESS, remarks,
                AuditRecorder.details("scheduleId", s.id(), "reason", reason, "before", before, "after", snapshot(after)));
        return after;
    }

    @Transactional
    public PanelStore.Schedule decide(Caller caller, String scheduleId, DecisionRequest req) {
        PanelStore.Schedule s = schedule(scheduleId);
        if (!"SCHEDULED".equals(s.status())) {
            throw PlatformException.conflict("SCHEDULE_CLOSED", "Panel interview is already " + s.status());
        }
        boolean panelist = s.panelistIds().contains(caller.userId());
        if (!panelist && !caller.has(DECIDE)) {
            throw PlatformException.forbidden("NOT_A_PANELIST", "Only a panelist on this interview can record the outcome");
        }
        Outcome outcome;
        try {
            outcome = Outcome.valueOf(req.outcome() == null ? "" : req.outcome().trim().toUpperCase(Locale.ROOT));
        } catch (IllegalArgumentException e) {
            throw PlatformException.badRequest("OUTCOME_INVALID", "Outcome must be SELECT, REJECT or HOLD");
        }
        String remarks = Remarks.clean(req.remarks(), true);
        ApplicationView app = mover.load(s.applicationId());
        Caller actor = panelist ? new Caller(caller.userId(), caller.email(), caller.name(), caller.roles(), caller.permissions(),
                caller.conditionalPermissions(), caller.scopeLevel(), caller.teamUserIds(), caller.lobs(), caller.locations(), true) : caller;
        Instant now = clock.instant();
        switch (outcome) {
            case SELECT -> mover.move(actor, app, StatusMover.Move.to(app.id(), Statuses.PANEL_SELECTED, DECIDE).reason("PANEL_SELECTED", remarks)
                    .with("scheduleId", s.id()).with("decidedBy", caller.userId()));
            case HOLD -> mover.move(actor, app, StatusMover.Move.to(app.id(), Statuses.PANEL_ON_HOLD, DECIDE).reason("PANEL_HOLD", remarks)
                    .with("scheduleId", s.id()).with("decidedBy", caller.userId()));
            case REJECT -> {
                RejectionReason reason = PHOTO_MISMATCH.equalsIgnoreCase(String.valueOf(req.reasonCode()))
                        ? new RejectionReason(PHOTO_MISMATCH, "Photo / identity mismatch", "PANEL", settings.rejectTemplate(), true, true, 0)
                        : reasons.require(req.reasonCode(), "PANEL");
                mover.move(actor, app, StatusMover.Move.to(app.id(), Statuses.PANEL_REJECTED, DECIDE).reason(reason.code(), remarks)
                        .notify(reason.templateCode() != null ? reason.templateCode() : settings.rejectTemplate())
                        .with("scheduleId", s.id()).with("decidedBy", caller.userId()).with("orcId", s.orcId()));
                Instant until = now.plus(Duration.ofDays(settings.orcRestrictionDays()));
                restrictions.restrict(app.candidateId(), s.orcId(), app.id(), now, until, reason.code());
                if (PHOTO_MISMATCH.equals(reason.code())) {
                    photos.flagRejection(caller, app, "PANEL", remarks);
                }
            }
        }
        store.close(s.id(), "COMPLETED", outcome.name());
        store.history(s.id(), s.applicationId(), "DECIDED_" + outcome.name(), null, Map.of("outcome", outcome.name()), req.reasonCode(),
                remarks, caller.userId(), now);
        return schedule(s.id());
    }

    @Transactional
    public PanelStore.Schedule changeOrc(Caller caller, String applicationId, OrcChangeRequest req) {
        ApplicationView app = mover.load(applicationId);
        guard.require(caller, app, CHANGE_ORC);
        OrcPath path;
        try {
            path = OrcPath.valueOf(req.path() == null ? "" : req.path().trim().toUpperCase(Locale.ROOT));
        } catch (IllegalArgumentException e) {
            throw PlatformException.badRequest("ORC_PATH_INVALID", "Path must be SAME_PANEL or DIFFERENT_PANEL");
        }
        if (!Set.of(Statuses.PANEL_SELECTED, Statuses.PANEL_ON_HOLD, Statuses.PANEL_INPROGRESS).contains(app.status())) {
            throw PlatformException.conflict("ORC_CHANGE_NOT_ALLOWED", "ORC can be changed only during or after the panel round");
        }
        String remarks = Remarks.clean(req.remarks(), true);
        RequisitionView target = requisitions.find(req.requisitionId())
                .orElseThrow(() -> PlatformException.notFound("Requisition", req.requisitionId()));
        if (!target.active() || target.available() <= 0) {
            throw PlatformException.conflict("REQUISITION_UNAVAILABLE", "Target requisition is closed or has no openings");
        }
        if (target.orcId() == null || target.orcId().equals(app.orcId())) {
            throw PlatformException.badRequest("ORC_UNCHANGED", "Target requisition has the same ORC");
        }
        restrictions.activeUntil(app.candidateId(), target.orcId(), clock.instant()).ifPresent(until -> {
            throw new PlatformException(409, "ORC_RESTRICTED", "Candidate is restricted for ORC " + target.orcId() + " until " + until, null);
        });
        PanelStore.Schedule last = store.forApplication(app.id()).stream().reduce((a, b) -> b)
                .orElseThrow(() -> PlatformException.conflict("NO_PANEL_ROUND", "No panel round exists for this applicant"));
        if (path == OrcPath.SAME_PANEL && (target.lob() == null || !target.lob().equalsIgnoreCase(last.lob()))) {
            throw PlatformException.badRequest("SAME_PANEL_LOB_MISMATCH", "Same-panel ORC change needs a requisition in the same LOB");
        }
        String fromOrc = app.orcId();
        com.ags.health.hr.candidates.shared.port.StatusChange change = new com.ags.health.hr.candidates.shared.port.StatusChange(
                caller.userId(), caller.displayName(), "ORC_CHANGE", remarks, caller.system());
        applicationRequisition(app, target, change);
        if (path == OrcPath.DIFFERENT_PANEL) {
            store.active(app.id()).ifPresent(s -> store.close(s.id(), "CANCELLED", "ORC_CHANGED"));
            mover.move(caller, mover.load(app.id()), StatusMover.Move.to(app.id(), Statuses.PANEL_YET_TO_SCHEDULE, CHANGE_ORC)
                    .reason("ORC_CHANGE", remarks).asReset().with("toOrcId", target.orcId()));
        } else {
            store.updateOrc(app.id(), target.orcId());
        }
        store.history(last.id(), app.id(), "ORC_CHANGED_" + path.name(), Map.of("orcId", String.valueOf(fromOrc)),
                Map.of("orcId", target.orcId(), "requisitionId", target.requisitionId()), "ORC_CHANGE", remarks, caller.userId(), clock.instant());
        audit.record("WORKFLOW_TRANSITION", "PANEL_ORC_CHANGED", "APPLICATION", app.id(), app.candidateId(), AuditRecorder.SUCCESS, remarks,
                AuditRecorder.details("path", path, "fromOrc", fromOrc, "toOrc", target.orcId(), "requisitionId", target.requisitionId()));
        return schedule(last.id());
    }

    @Transactional
    public UploadTicket recordingUploadUrl(Caller caller, String scheduleId, String contentType) {
        PanelStore.Schedule s = schedule(scheduleId);
        requireRecordingUploader(caller, s);
        String ct = contentType == null ? "video/mp4" : contentType.trim().toLowerCase(Locale.ROOT);
        if (!ct.equals("video/mp4") && !ct.equals("video/webm")) {
            throw PlatformException.badRequest("CONTENT_TYPE_INVALID", "Recordings must be video/mp4 or video/webm");
        }
        Instant now = clock.instant();
        String key = "p5/panel/" + s.applicationId() + "/" + s.id() + "/recording-" + now.toEpochMilli() + (ct.endsWith("mp4") ? ".mp4" : ".webm");
        PanelStore.Recording r = store.addRecording(s.id(), s.applicationId(), key, ct, null, "PENDING_UPLOAD", caller.userId(), now);
        Duration ttl = Duration.ofMinutes(settings.recordingUrlTtlMinutes());
        return new UploadTicket(r.id(), files.uploadUrl(key, ttl, ct), ct, now.plus(ttl));
    }

    @Transactional
    public PanelStore.Recording confirmUpload(Caller caller, String recordingId) {
        PanelStore.Recording r = store.recording(recordingId).orElseThrow(() -> PlatformException.notFound("Recording", recordingId));
        requireRecordingUploader(caller, schedule(r.scheduleId()));
        if (!files.exists(r.storageKey())) {
            throw PlatformException.conflict("RECORDING_NOT_UPLOADED", "The recording has not been uploaded yet");
        }
        long size = files.get(r.storageKey()).map(b -> (long) b.length).orElse(0L);
        store.markUploaded(r.id(), size, clock.instant());
        audit.record("ACTIVITY", "PANEL_RECORDING_UPLOADED", "APPLICATION", r.applicationId(), null,
                AuditRecorder.details("recordingId", r.id(), "scheduleId", r.scheduleId()));
        return store.recording(r.id()).orElseThrow();
    }

    @Transactional
    public PanelStore.Recording uploadRecording(Caller caller, String scheduleId, byte[] content, String fileName) {
        PanelStore.Schedule s = schedule(scheduleId);
        requireRecordingUploader(caller, s);
        FileInspector.Kind kind = FileInspector.require(content, fileName, settings.recordingMaxBytes(),
                Set.of(FileInspector.Kind.MP4, FileInspector.Kind.WEBM));
        Instant now = clock.instant();
        String key = "p5/panel/" + s.applicationId() + "/" + s.id() + "/recording-" + now.toEpochMilli() + "." + kind.extension();
        files.put(key, content, kind.contentType(), Map.of("schedule", s.id()));
        PanelStore.Recording r = store.addRecording(s.id(), s.applicationId(), key, kind.contentType(), (long) content.length, "UPLOADED",
                caller.userId(), now);
        audit.record("ACTIVITY", "PANEL_RECORDING_UPLOADED", "APPLICATION", s.applicationId(), s.candidateId(),
                AuditRecorder.details("recordingId", r.id(), "scheduleId", s.id(), "bytes", content.length));
        return r;
    }

    public URI recordingUrl(Caller caller, String recordingId) {
        if (!caller.has(RECORDING_VIEW)) {
            throw PlatformException.forbidden("PERMISSION_DENIED", "Missing permission " + RECORDING_VIEW);
        }
        PanelStore.Recording r = store.recording(recordingId).orElseThrow(() -> PlatformException.notFound("Recording", recordingId));
        if ("PENDING_UPLOAD".equals(r.status())) {
            throw PlatformException.conflict("RECORDING_NOT_UPLOADED", "The recording has not been uploaded yet");
        }
        URI url = files.temporaryUrl(r.storageKey(), Duration.ofMinutes(settings.recordingUrlTtlMinutes()), null)
                .orElseThrow(() -> PlatformException.notFound("Recording content", recordingId));
        audit.record("SECURITY", "PANEL_RECORDING_VIEWED", "APPLICATION", r.applicationId(), null,
                AuditRecorder.details("recordingId", r.id()));
        return url;
    }

    @Transactional
    public PanelStore.Recording review(Caller caller, String recordingId, String notes) {
        if (!caller.has(RECORDING_VIEW)) {
            throw PlatformException.forbidden("PERMISSION_DENIED", "Missing permission " + RECORDING_VIEW);
        }
        String text = Remarks.clean(notes, true);
        if (!store.review(recordingId, caller.userId(), text, clock.instant())) {
            throw PlatformException.conflict("RECORDING_NOT_REVIEWABLE", "Recording is not uploaded");
        }
        PanelStore.Recording r = store.recording(recordingId).orElseThrow();
        audit.record("ACTIVITY", "PANEL_RECORDING_REVIEWED", "APPLICATION", r.applicationId(), null, AuditRecorder.SUCCESS, text,
                AuditRecorder.details("recordingId", r.id()));
        return r;
    }

    @Transactional(readOnly = true)
    public Map<String, Object> overview(Caller caller, String applicationId) {
        ApplicationView app = mover.load(applicationId);
        if (!caller.hasAny(RECORDING_VIEW, DECIDE)) {
            guard.require(caller, app, SCHEDULE);
        }
        return Map.of("schedules", store.forApplication(app.id()), "history", store.history(app.id()),
                "recordings", store.recordings(app.id()));
    }

    private void applicationRequisition(ApplicationView app, RequisitionView target,
                                        com.ags.health.hr.candidates.shared.port.StatusChange change) {
        applications.changeRequisition(app.id(), target.requisitionId(), target.jobId(), change);
    }

    private void requireRecordingUploader(Caller caller, PanelStore.Schedule s) {
        if (!s.panelistIds().contains(caller.userId()) && !caller.has(RECORDING_UPLOAD)) {
            throw PlatformException.forbidden("PERMISSION_DENIED", "Missing permission " + RECORDING_UPLOAD);
        }
    }

    private PanelStore.Schedule schedule(String id) {
        return store.find(id).orElseThrow(() -> PlatformException.notFound("Panel schedule", id));
    }

    private List<String> panelists(List<String> ids) {
        if (ids == null || ids.isEmpty() || ids.size() > 6) {
            throw PlatformException.badRequest("PANELISTS_INVALID", "Choose between 1 and 6 panelists");
        }
        List<String> unique = List.copyOf(new LinkedHashSet<>(ids));
        for (String id : unique) {
            if (panelists.find(id).filter(PanelistDirectoryPort.Panelist::active).isEmpty()) {
                throw PlatformException.badRequest("PANELIST_INACTIVE", "Panelist " + id + " is not an active panel member");
            }
        }
        return unique;
    }

    private List<String> emails(List<String> ids) {
        return ids.stream().map(panelists::find).filter(java.util.Optional::isPresent).map(o -> o.get().email())
                .filter(e -> e != null).toList();
    }

    private void window(Instant start, Instant end) {
        if (start == null || end == null || !end.isAfter(start) || Duration.between(start, end).toHours() > 4) {
            throw PlatformException.badRequest("TIME_INVALID", "End must be after start and within 4 hours");
        }
        if (!start.isAfter(clock.instant())) {
            throw PlatformException.badRequest("TIME_IN_PAST", "Start time must be in the future");
        }
    }

    private static String required(String v, String label) {
        if (v == null || v.isBlank()) {
            throw PlatformException.badRequest("FIELD_REQUIRED", label + " is required");
        }
        return v.trim().toUpperCase(Locale.ROOT);
    }

    private static Map<String, Object> snapshot(PanelStore.Schedule s) {
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("startsAt", s.startsAt().toString());
        m.put("endsAt", s.endsAt().toString());
        m.put("panelists", s.panelistIds());
        m.put("orcId", s.orcId());
        return m;
    }
}
