package com.ags.health.hr.candidates.mapping.store;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.jdbc.core.JdbcTemplate;

import java.sql.Timestamp;
import java.time.Instant;
import java.util.List;
import java.util.Map;
import java.util.UUID;

public class MappingActionStore {

    public record Entry(String id, String candidateId, String applicationId, String requisitionId, String action,
                        String scenario, String outcome, String source, String subSource, String remarks, String actorId,
                        String actorName, Instant at, String details) {
    }

    private final JdbcTemplate jdbc;
    private final ObjectMapper mapper;

    public MappingActionStore(JdbcTemplate jdbc, ObjectMapper mapper) {
        this.jdbc = jdbc;
        this.mapper = mapper;
    }

    public String append(String candidateId, String applicationId, String requisitionId, String action, String scenario,
                         String outcome, String source, String subSource, String remarks, String actorId, String actorName,
                         Instant at, Map<String, Object> details) {
        String id = UUID.randomUUID().toString();
        jdbc.update("INSERT INTO cand_mapping_action (id, candidate_id, application_id, requisition_id, action, scenario, "
                        + "outcome, source, sub_source, remarks, actor_id, actor_name, created_at, details) "
                        + "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
                id, candidateId, applicationId, requisitionId, action, scenario, outcome, source, subSource, remarks, actorId,
                actorName, Timestamp.from(at), json(details));
        return id;
    }

    public List<Entry> forCandidate(String candidateId, int limit) {
        return jdbc.query("SELECT id, candidate_id, application_id, requisition_id, action, scenario, outcome, source, "
                        + "sub_source, remarks, actor_id, actor_name, created_at, details FROM cand_mapping_action "
                        + "WHERE candidate_id = ? ORDER BY created_at DESC, id LIMIT ?",
                (rs, i) -> new Entry(rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5),
                        rs.getString(6), rs.getString(7), rs.getString(8), rs.getString(9), rs.getString(10),
                        rs.getString(11), rs.getString(12), rs.getTimestamp(13).toInstant(), rs.getString(14)),
                candidateId, Math.max(1, Math.min(limit, 500)));
    }

    private String json(Map<String, Object> details) {
        if (details == null || details.isEmpty()) {
            return null;
        }
        try {
            String s = mapper.writeValueAsString(details);
            return s.length() > 4000 ? s.substring(0, 4000) : s;
        } catch (JsonProcessingException e) {
            return null;
        }
    }
}
