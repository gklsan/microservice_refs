package com.ags.health.hr.candidates.assessmentbridge;

import com.ags.health.hr.common.platform.assessment.AssessmentPort;
import com.ags.health.hr.common.platform.outbox.OutboxEvent;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.util.Map;

public class AssessmentEventDispatcher implements OutboxDispatcher {

    private static final TypeReference<Map<String, Object>> MAP = new TypeReference<>() {
    };

    private final AssessmentPort assessments;
    private final ObjectMapper mapper;

    public AssessmentEventDispatcher(AssessmentPort assessments, ObjectMapper mapper) {
        this.assessments = assessments;
        this.mapper = mapper;
    }

    @Override
    public String eventType() {
        return ApplicationEventRelay.EVENT_TYPE;
    }

    @Override
    public boolean ready() {
        return true;
    }

    @Override
    public void deliver(OutboxEvent event) {
        assessments.applicationEvent(mapper.convertValue(event.payload(), MAP));
    }
}
