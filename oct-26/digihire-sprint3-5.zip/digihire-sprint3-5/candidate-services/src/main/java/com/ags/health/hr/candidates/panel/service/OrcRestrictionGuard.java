package com.ags.health.hr.candidates.panel.service;

import com.ags.health.hr.candidates.mapping.domain.Blocker;
import com.ags.health.hr.candidates.mapping.port.MappingGuardPort;
import com.ags.health.hr.candidates.panel.store.OrcRestrictionStore;
import com.ags.health.hr.candidates.shared.port.CandidateView;
import com.ags.health.hr.candidates.shared.port.RequisitionView;

import java.time.Clock;
import java.util.List;

public class OrcRestrictionGuard implements MappingGuardPort {

    private final OrcRestrictionStore store;
    private final Clock clock;

    public OrcRestrictionGuard(OrcRestrictionStore store, Clock clock) {
        this.store = store;
        this.clock = clock;
    }

    @Override
    public List<Blocker> check(CandidateView candidate, RequisitionView requisition) {
        if (candidate == null || requisition == null || requisition.orcId() == null) {
            return List.of();
        }
        return store.activeUntil(candidate.id(), requisition.orcId(), clock.instant())
                .map(until -> List.of(new Blocker("ORC_RESTRICTED", "Candidate was rejected for ORC " + requisition.orcId()
                        + " and can reapply after the date shown", until)))
                .orElse(List.of());
    }
}
