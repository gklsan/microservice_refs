package com.ags.health.hr.candidates.shared.port;

import java.time.Instant;

public record StageEntry(String status, Instant at, String actorId, boolean system) {
}
