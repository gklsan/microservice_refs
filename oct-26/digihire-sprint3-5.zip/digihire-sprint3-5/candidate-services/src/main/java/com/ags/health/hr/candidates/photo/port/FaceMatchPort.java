package com.ags.health.hr.candidates.photo.port;

public interface FaceMatchPort {

    record Result(double score, String provider, String reference) {
    }

    Result match(byte[] probe, byte[] reference);
}
