package com.ags.health.hr.candidates.panel.port;

import java.util.List;
import java.util.Optional;

public interface PanelistDirectoryPort {

    record Panelist(String id, String email, String name, boolean active) {
    }

    Optional<Panelist> find(String panelistId);

    default List<Panelist> require(List<String> ids) {
        return ids.stream().map(id -> find(id).filter(Panelist::active).orElseThrow(
                () -> new IllegalArgumentException(id))).toList();
    }
}
