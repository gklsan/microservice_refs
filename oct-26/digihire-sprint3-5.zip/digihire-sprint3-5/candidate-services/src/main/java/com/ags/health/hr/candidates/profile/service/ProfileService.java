package com.ags.health.hr.candidates.profile.service;

import com.ags.health.hr.candidates.profile.domain.FieldCatalog;
import com.ags.health.hr.candidates.profile.domain.FieldDefinition;
import com.ags.health.hr.candidates.profile.domain.ProfileStage;
import com.ags.health.hr.candidates.profile.domain.ProfileValidator;
import com.ags.health.hr.candidates.profile.domain.RegistrationStatus;
import com.ags.health.hr.candidates.profile.domain.StageEditPolicy;
import com.ags.health.hr.candidates.profile.port.ProfilePort;
import com.ags.health.hr.candidates.profile.store.ProfileChangeStore;
import com.ags.health.hr.candidates.shared.port.ApplicationPort;
import com.ags.health.hr.candidates.shared.port.CandidateView;
import com.ags.health.hr.candidates.shared.port.StatusChange;
import com.ags.health.hr.candidates.shared.service.CandidateGuard;
import com.ags.health.hr.candidates.shared.service.Remarks;
import com.ags.health.hr.common.platform.audit.AuditRecorder;
import com.ags.health.hr.common.platform.caller.Caller;
import com.ags.health.hr.common.platform.error.PlatformException;
import com.ags.health.hr.common.platform.time.BusinessClock;
import com.ags.health.hr.common.platform.validation.FieldViolation;
import org.springframework.transaction.annotation.Transactional;

import java.time.Instant;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;

public class ProfileService {

    public static final String VIEW = "CANDIDATE:VIEW";
    public static final String UPDATE = "CANDIDATE:UPDATE";
    public static final String UPDATE_LOCKED = "CANDIDATE:UPDATE_LOCKED";
    public static final String EXPORT = "CANDIDATE:EXPORT";
    public static final String VIEW_SENSITIVE = "CANDIDATE:VIEW_SENSITIVE";

    public record FieldState(String key, String label, String section, String type, boolean requiredForRegistration,
                             boolean editable, String lockedFrom, boolean sensitive, int maxLength, List<String> options) {
    }

    public record ProfileView(String candidateId, ProfileStage stage, List<FieldState> fields) {
    }

    public record UpdateResult(String candidateId, ProfileStage stage, List<String> changed, boolean overrideUsed,
                               RegistrationStatus registration) {
    }

    private final FieldCatalog catalog;
    private final ProfileValidator validator;
    private final StageEditPolicy policy;
    private final ProfilePort profiles;
    private final ApplicationPort applications;
    private final CandidateGuard guard;
    private final ProfileChangeStore changes;
    private final ProfileDocumentBuilder documents;
    private final ProfilePdfRenderer renderer;
    private final AuditRecorder audit;
    private final BusinessClock clock;

    public ProfileService(FieldCatalog catalog, ProfileValidator validator, StageEditPolicy policy, ProfilePort profiles,
                          ApplicationPort applications, CandidateGuard guard, ProfileChangeStore changes,
                          ProfileDocumentBuilder documents, ProfilePdfRenderer renderer, AuditRecorder audit,
                          BusinessClock clock) {
        this.catalog = catalog;
        this.validator = validator;
        this.policy = policy;
        this.profiles = profiles;
        this.applications = applications;
        this.guard = guard;
        this.changes = changes;
        this.documents = documents;
        this.renderer = renderer;
        this.audit = audit;
        this.clock = clock;
    }

    @Transactional(readOnly = true)
    public ProfileView fields(Caller caller, String candidateId) {
        CandidateView c = guard.load(candidateId);
        guard.require(caller, c, VIEW, true);
        ProfileStage stage = policy.stageOf(applications.findByCandidate(c.id()));
        boolean override = caller.has(UPDATE_LOCKED) && !CandidateGuard.isSelf(caller, c);
        List<FieldState> out = catalog.all().stream().map(d -> new FieldState(d.key(), d.label(), d.section(), d.type().name(),
                d.requiredForRegistration(), override || policy.editable(d, stage), d.lockedFrom() == null ? null : d.lockedFrom().name(),
                d.sensitive(), d.maxLength(), d.options())).toList();
        return new ProfileView(c.id(), stage, out);
    }

    @Transactional
    public UpdateResult update(Caller caller, String candidateId, Map<String, Object> requested, String overrideReason) {
        CandidateView c = guard.load(candidateId);
        CandidateGuard.Basis basis = guard.require(caller, c, UPDATE, true);
        Map<String, Object> current = profiles.load(c.id()).orElse(Map.of());
        ProfileStage stage = policy.stageOf(applications.findByCandidate(c.id()));
        ProfileValidator.Outcome outcome = validator.validate(requested, current, clock.today());
        List<FieldViolation> violations = new ArrayList<>(outcome.violations());
        Map<String, Object> effective = new LinkedHashMap<>();
        outcome.normalised().forEach((k, v) -> {
            if (!Objects.equals(stringOf(current.get(k)), stringOf(v))) {
                effective.put(k, v);
            }
        });
        List<String> locked = effective.keySet().stream()
                .filter(k -> catalog.find(k).map(d -> !policy.editable(d, stage)).orElse(false)).toList();
        boolean overrideUsed = false;
        String reason = null;
        if (!locked.isEmpty()) {
            boolean mayOverride = basis != CandidateGuard.Basis.SELF && caller.has(UPDATE_LOCKED);
            reason = Remarks.clean(overrideReason, false);
            if (!mayOverride || reason == null) {
                locked.forEach(k -> violations.add(new FieldViolation(k, "FIELD_LOCKED",
                        "Field can not be changed after the " + stage.name().toLowerCase() + " stage"
                                + (mayOverride ? " without an override reason" : ""))));
            } else {
                overrideUsed = true;
            }
        }
        duplicateContact(c.id(), effective, violations);
        if (!violations.isEmpty()) {
            audit.recordQuietly("ACTIVITY", "PROFILE_UPDATE_REJECTED", "CANDIDATE", c.id(), c.id(), AuditRecorder.FAILURE,
                    null, AuditRecorder.details("fields", requested == null ? List.of() : List.copyOf(requested.keySet()),
                            "violations", FieldViolation.asMaps(violations)));
            throw PlatformException.unprocessable("PROFILE_INVALID", "Profile changes are not valid",
                    FieldViolation.asMaps(violations));
        }
        if (effective.isEmpty()) {
            return new UpdateResult(c.id(), stage, List.of(), false, registration(c.id(), current));
        }
        Instant now = clock.now();
        profiles.apply(c.id(), effective, new StatusChange(caller.userId(), caller.displayName(),
                overrideUsed ? "LOCK_OVERRIDE" : null, reason, caller.system()));
        List<ProfileChangeStore.Change> log = new ArrayList<>();
        for (Map.Entry<String, Object> e : effective.entrySet()) {
            FieldDefinition d = catalog.find(e.getKey()).orElseThrow();
            log.add(new ProfileChangeStore.Change(null, c.id(), d.key(), display(d, current.get(d.key())), display(d, e.getValue()),
                    caller.userId(), caller.displayName(), basis.name(), overrideUsed && locked.contains(d.key()) ? reason : null, now));
        }
        changes.append(log);
        audit.record("ACTIVITY", overrideUsed ? "PROFILE_UPDATED_WITH_OVERRIDE" : "PROFILE_UPDATED", "CANDIDATE", c.id(), c.id(),
                AuditRecorder.SUCCESS, reason, AuditRecorder.details("fields", List.copyOf(effective.keySet()), "stage", stage,
                        "basis", basis, "lockedFields", locked));
        Map<String, Object> merged = new LinkedHashMap<>(current);
        merged.putAll(effective);
        return new UpdateResult(c.id(), stage, List.copyOf(effective.keySet()), overrideUsed, registration(c.id(), merged));
    }

    @Transactional(readOnly = true)
    public RegistrationStatus completeness(Caller caller, String candidateId) {
        CandidateView c = guard.load(candidateId);
        guard.require(caller, c, VIEW, true);
        return registration(c.id(), profiles.load(c.id()).orElse(Map.of()));
    }

    @Transactional(readOnly = true)
    public RegistrationStatus registrationOf(String candidateId) {
        return registration(candidateId, profiles.load(candidateId).orElse(Map.of()));
    }

    public void requireRegistered(String candidateId) {
        RegistrationStatus s = registrationOf(candidateId);
        if (!s.complete()) {
            throw PlatformException.unprocessable("REGISTRATION_INCOMPLETE",
                    "Candidate must complete registration before being tagged or mapped", FieldViolation.asMaps(s.missing()));
        }
    }

    @Transactional(readOnly = true)
    public List<ProfileChangeStore.Change> history(Caller caller, String candidateId, int limit) {
        CandidateView c = guard.load(candidateId);
        guard.require(caller, c, VIEW, false);
        return changes.history(c.id(), limit);
    }

    public byte[] exportPdf(Caller caller, String candidateId) {
        CandidateView c = guard.load(candidateId);
        CandidateGuard.Basis basis = guard.require(caller, c, EXPORT, true);
        Map<String, Object> values = profiles.load(c.id()).orElseThrow(() -> PlatformException.notFound("Profile", candidateId));
        boolean reveal = basis == CandidateGuard.Basis.SELF;
        ProfileDocument doc = documents.build(c.id(), values, caller.displayName(), clock.now(), reveal);
        byte[] pdf = renderer.render(doc);
        audit.record("ACTIVITY", "PROFILE_EXPORTED", "CANDIDATE", c.id(), c.id(), AuditRecorder.SUCCESS, null,
                AuditRecorder.details("format", "PDF", "basis", basis, "sensitiveRevealed", reveal, "bytes", pdf.length));
        return pdf;
    }

    private RegistrationStatus registration(String candidateId, Map<String, Object> values) {
        return RegistrationStatus.of(candidateId, catalog.requiredForRegistration().size(), validator.missingForRegistration(values));
    }

    private void duplicateContact(String candidateId, Map<String, Object> effective, List<FieldViolation> violations) {
        String email = effective.get("email") == null ? null : String.valueOf(effective.get("email"));
        String mobile = effective.get("mobile") == null ? null : String.valueOf(effective.get("mobile"));
        if (email == null && mobile == null) {
            return;
        }
        if (email != null) {
            Optional<String> other = profiles.candidateIdByEmailOrMobile(email, null);
            if (other.isPresent() && !other.get().equals(candidateId)) {
                violations.add(new FieldViolation("email", "DUPLICATE", "Email belongs to another candidate"));
            }
        }
        if (mobile != null) {
            Optional<String> other = profiles.candidateIdByEmailOrMobile(null, mobile);
            if (other.isPresent() && !other.get().equals(candidateId)) {
                violations.add(new FieldViolation("mobile", "DUPLICATE", "Mobile belongs to another candidate"));
            }
        }
    }

    private static String display(FieldDefinition d, Object value) {
        if (value == null) {
            return null;
        }
        return d.sensitive() ? ProfileDocumentBuilder.mask(d, String.valueOf(value)) : String.valueOf(value);
    }

    private static String stringOf(Object v) {
        return v == null ? null : String.valueOf(v);
    }
}
