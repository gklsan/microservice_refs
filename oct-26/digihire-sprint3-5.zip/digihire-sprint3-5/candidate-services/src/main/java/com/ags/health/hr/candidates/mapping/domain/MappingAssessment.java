package com.ags.health.hr.candidates.mapping.domain;

import java.util.List;

public record MappingAssessment(String candidateId, CandidateState state, MappingScenario scenario, MappingAction action,
                                String taggedRecruiterId, String openApplicationId, String openApplicationStatus,
                                String requisitionId, int openings, List<Blocker> blockers, List<String> warnings) {

    public MappingAssessment {
        blockers = blockers == null ? List.of() : List.copyOf(blockers);
        warnings = warnings == null ? List.of() : List.copyOf(warnings);
    }

    public boolean blocked() {
        return !blockers.isEmpty();
    }

    public boolean has(String code) {
        return blockers.stream().anyMatch(b -> b.code().equals(code));
    }
}
