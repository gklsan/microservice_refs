package com.ags.health.hr.candidates.assessmentbridge;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

import java.sql.Timestamp;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

public class AssessmentExceptionStore {

    public record Entry(String id, String applicationId, String candidateId, String provider, String assessmentCode,
                        String attemptId, String kind, String status, String details, Instant createdAt, String resolution,
                        String resolvedBy, Instant resolvedAt) {
    }

    private static final String COLUMNS = "id, application_id, candidate_id, provider, assessment_code, attempt_id, kind, status, "
            + "details, created_at, resolution, resolved_by, resolved_at";
    private static final RowMapper<Entry> ROW = (rs, i) -> new Entry(rs.getString(1), rs.getString(2), rs.getString(3),
            rs.getString(4), rs.getString(5), rs.getString(6), rs.getString(7), rs.getString(8), rs.getString(9),
            rs.getTimestamp(10).toInstant(), rs.getString(11), rs.getString(12),
            rs.getTimestamp(13) == null ? null : rs.getTimestamp(13).toInstant());

    private final JdbcTemplate jdbc;

    public AssessmentExceptionStore(JdbcTemplate jdbc) {
        this.jdbc = jdbc;
    }

    public String open(String applicationId, String candidateId, String provider, String assessmentCode, String attemptId,
                       String kind, String details, Instant at) {
        List<String> existing = jdbc.queryForList("SELECT id FROM cand_assessment_exception WHERE attempt_id = ? AND kind = ? "
                + "AND status = 'OPEN'", String.class, attemptId, kind);
        if (!existing.isEmpty()) {
            return existing.get(0);
        }
        String id = UUID.randomUUID().toString();
        jdbc.update("INSERT INTO cand_assessment_exception (id, application_id, candidate_id, provider, assessment_code, attempt_id, "
                        + "kind, status, details, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, 'OPEN', ?, ?)",
                id, applicationId, candidateId, provider, assessmentCode, attemptId, kind,
                details == null ? null : details.length() > 1000 ? details.substring(0, 1000) : details, Timestamp.from(at));
        return id;
    }

    public int resolveForApplication(String applicationId, String provider, String resolution, String actor, Instant at) {
        return jdbc.update("UPDATE cand_assessment_exception SET status = 'RESOLVED', resolution = ?, resolved_by = ?, resolved_at = ? "
                + "WHERE application_id = ? AND provider = ? AND status = 'OPEN'", resolution, actor, Timestamp.from(at),
                applicationId, provider);
    }

    public boolean resolve(String id, String resolution, String actor, Instant at) {
        return jdbc.update("UPDATE cand_assessment_exception SET status = 'RESOLVED', resolution = ?, resolved_by = ?, resolved_at = ? "
                + "WHERE id = ? AND status = 'OPEN'", resolution, actor, Timestamp.from(at), id) == 1;
    }

    public Optional<Entry> find(String id) {
        return jdbc.query("SELECT " + COLUMNS + " FROM cand_assessment_exception WHERE id = ?", ROW, id).stream().findFirst();
    }

    public List<Entry> list(String provider, String status, int limit) {
        StringBuilder sql = new StringBuilder("SELECT " + COLUMNS + " FROM cand_assessment_exception WHERE 1 = 1");
        List<Object> args = new ArrayList<>();
        if (provider != null) {
            sql.append(" AND provider = ?");
            args.add(provider);
        }
        if (status != null) {
            sql.append(" AND status = ?");
            args.add(status);
        }
        sql.append(" ORDER BY created_at DESC LIMIT ?");
        args.add(Math.max(1, Math.min(limit, 500)));
        return jdbc.query(sql.toString(), ROW, args.toArray());
    }
}
