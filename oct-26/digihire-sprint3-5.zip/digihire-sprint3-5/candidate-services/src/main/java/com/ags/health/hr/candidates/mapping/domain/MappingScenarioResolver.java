package com.ags.health.hr.candidates.mapping.domain;

import com.ags.health.hr.candidates.shared.domain.StageCatalog;
import com.ags.health.hr.candidates.shared.domain.Tab;
import com.ags.health.hr.candidates.shared.port.ApplicationView;
import com.ags.health.hr.candidates.shared.port.CandidateView;
import com.ags.health.hr.candidates.shared.port.RequisitionView;
import com.ags.health.hr.common.platform.assessment.EligibilityResult;
import com.ags.health.hr.common.platform.caller.Caller;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Optional;

public class MappingScenarioResolver {

    public static final String RETAG = "CANDIDATE:RETAG";

    private final StageCatalog catalog;

    public MappingScenarioResolver(StageCatalog catalog) {
        this.catalog = catalog;
    }

    public CandidateState stateOf(CandidateView candidate, List<ApplicationView> open) {
        if (candidate == null || !candidate.registered()) {
            return CandidateState.YET_TO_REGISTER;
        }
        if (open == null || open.isEmpty()) {
            return CandidateState.REGISTERED;
        }
        boolean inProcess = open.stream().anyMatch(a -> catalog.known(a.status()) && catalog.tabOf(a.status()) != Tab.APPLICANT
                && catalog.tabOf(a.status()) != Tab.PIPELINE);
        return inProcess ? CandidateState.IN_PROCESS : CandidateState.APPLICATION_CREATED;
    }

    public MappingAssessment resolve(Caller caller, CandidateView candidate, List<ApplicationView> openApplications,
                                     RequisitionView requisition, String requisitionId, EligibilityResult eligibility,
                                     List<Blocker> extraBlockers, LocalDate today) {
        List<ApplicationView> open = openApplications == null ? List.of()
                : openApplications.stream().filter(a -> catalog.isOpen(a.status())).toList();
        CandidateState state = stateOf(candidate, open);
        List<Blocker> blockers = new ArrayList<>();
        List<String> warnings = new ArrayList<>();
        int openings = requisition == null ? 0 : requisition.available();
        boolean noOpenings = false;
        if (requisition == null) {
            blockers.add(Blocker.of("REQUISITION_NOT_FOUND", "Requisition " + requisitionId + " does not exist"));
        } else {
            requisitionProblem(requisition, today).ifPresent(blockers::add);
            noOpenings = blockers.isEmpty() && openings <= 0;
        }
        if (eligibility != null) {
            eligibility.reasons().stream().filter(EligibilityResult.Reason::blocking)
                    .forEach(r -> blockers.add(new Blocker(r.code(), r.message(), r.until())));
            eligibility.reasons().stream().filter(r -> !r.blocking()).forEach(r -> warnings.add(r.code() + ": " + r.message()));
        }
        if (extraBlockers != null) {
            blockers.addAll(extraBlockers);
        }
        if (state == CandidateState.YET_TO_REGISTER) {
            return new MappingAssessment(candidate == null ? null : candidate.id(), state, MappingScenario.S6_NOT_REGISTERED,
                    MappingAction.INVITE_TO_REGISTER, candidate == null ? null : candidate.taggedRecruiterId(), null, null,
                    requisitionId, openings, blockers, warnings);
        }
        Optional<ApplicationView> same = open.stream()
                .filter(a -> requisitionId != null && requisitionId.equalsIgnoreCase(a.requisitionId())).findFirst();
        same.ifPresent(a -> blockers.add(Blocker.of("ALREADY_MAPPED", "Candidate is already mapped to this requisition")));
        if (!open.isEmpty()) {
            ApplicationView current = open.get(0);
            boolean mine = owns(caller, current.hrUserId());
            MappingScenario scenario = mine ? MappingScenario.S4_OPEN_APPLICATION_MINE : MappingScenario.S5_OPEN_APPLICATION_OTHER;
            if (mine && catalog.lockedForRemap(current.status())) {
                blockers.add(Blocker.of("APPLICATION_LOCKED", "Application is at " + current.status() + " and can not be re-mapped"));
            }
            if (!mine) {
                blockers.add(Blocker.of("NOT_OWNER", "Candidate is in process with another recruiter"));
            }
            if (open.size() > 1) {
                warnings.add("MULTIPLE_OPEN_APPLICATIONS: " + open.size());
            }
            return new MappingAssessment(candidate.id(), state, scenario, scenario.defaultAction(), candidate.taggedRecruiterId(),
                    current.id(), current.status(), requisitionId, openings, blockers, warnings);
        }
        String tagged = candidate.taggedRecruiterId();
        MappingScenario scenario;
        MappingAction action;
        if (tagged == null || tagged.isBlank()) {
            scenario = MappingScenario.S1_UNTAGGED_NO_APPLICATION;
            action = MappingAction.TAG_AND_MAP;
        } else if (owns(caller, tagged)) {
            scenario = MappingScenario.S2_TAGGED_TO_ME_NO_APPLICATION;
            action = MappingAction.MAP;
        } else {
            scenario = MappingScenario.S3_TAGGED_TO_OTHER_NO_APPLICATION;
            if (caller != null && caller.hasFull(RETAG)) {
                action = MappingAction.TAG_AND_MAP;
                warnings.add("RETAG: candidate will be re-tagged from " + tagged);
            } else {
                action = MappingAction.REQUEST_ACCESS;
                blockers.add(Blocker.of("TAGGED_TO_OTHER_RECRUITER", "Candidate is tagged to another recruiter"));
            }
        }
        if (noOpenings && (action == MappingAction.MAP || action == MappingAction.TAG_AND_MAP)) {
            warnings.add("NO_OPENINGS: candidate will be moved to Pipeline (On Hold)");
            action = MappingAction.MAP_ON_HOLD;
        }
        return new MappingAssessment(candidate.id(), state, scenario, action, tagged, null, null, requisitionId, openings,
                blockers, warnings);
    }

    public static Optional<Blocker> requisitionProblem(RequisitionView r, LocalDate today) {
        String status = r.status() == null ? "" : r.status().trim().toUpperCase(Locale.ROOT);
        if (!r.active() || !(status.isEmpty() || status.equals("OPEN") || status.equals("ACTIVE") || status.equals("APPROVED"))) {
            return Optional.of(Blocker.of("REQUISITION_INACTIVE", "Requisition " + r.requisitionId() + " is not open (" + r.status() + ")"));
        }
        if (r.validTo() != null && today != null && r.validTo().isBefore(today)) {
            return Optional.of(Blocker.of("REQUISITION_EXPIRED", "Requisition " + r.requisitionId() + " expired on " + r.validTo()));
        }
        return Optional.empty();
    }

    private static boolean owns(Caller caller, String userId) {
        return caller != null && (caller.system() || caller.is(userId) || caller.leads(userId));
    }
}
