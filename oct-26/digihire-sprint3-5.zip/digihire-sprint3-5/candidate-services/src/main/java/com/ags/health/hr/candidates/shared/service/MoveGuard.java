package com.ags.health.hr.candidates.shared.service;

import com.ags.health.hr.candidates.shared.port.ApplicationView;
import com.ags.health.hr.common.platform.caller.Caller;

public interface MoveGuard {

    void check(Caller caller, ApplicationView application, String toStatus, StatusMover.Move move);
}
