package com.ags.health.hr.candidates.pipeline.web;

import com.ags.health.hr.candidates.pipeline.service.PipelineService;
import com.ags.health.hr.common.platform.bulk.BulkSummary;
import com.ags.health.hr.common.platform.caller.CallerProvider;
import com.ags.health.hr.common.platform.error.PlatformException;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.Map;

@ConditionalOnProperty(prefix = "digihire.candidate.pipeline", name = "enabled", havingValue = "true", matchIfMissing = true)
@RestController
public class PipelineController {

    public record RemarksRequest(String remarks) {
    }

    private final PipelineService service;
    private final CallerProvider callers;

    public PipelineController(PipelineService service, CallerProvider callers) {
        this.service = service;
        this.callers = callers;
    }

    @PostMapping("/pipeline/bulk-status")
    public BulkSummary bulk(@RequestBody PipelineService.BulkRequest body) {
        return service.bulk(callers.require(), body);
    }

    @PostMapping(value = "/pipeline/bulk-status/upload", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public BulkSummary upload(@RequestParam MultipartFile file, @RequestParam(defaultValue = "false") boolean dryRun) {
        try {
            return service.upload(callers.require(), file.getOriginalFilename(), file.getBytes(), dryRun);
        } catch (IOException e) {
            throw PlatformException.badRequest("FILE_UNREADABLE", "Uploaded file could not be read");
        }
    }

    @GetMapping("/pipeline/bulk-jobs/{jobId}")
    public Map<String, Object> job(@PathVariable String jobId) {
        return service.job(callers.require(), jobId);
    }

    @GetMapping("/applicants/{applicationId}/reprocess")
    public PipelineService.ReprocessPreview preview(@PathVariable String applicationId) {
        return service.previewReprocess(callers.require(), applicationId);
    }

    @PostMapping("/applicants/{applicationId}/reprocess")
    public PipelineService.ReprocessPreview reprocess(@PathVariable String applicationId, @RequestBody RemarksRequest body) {
        return service.reprocess(callers.require(), applicationId, body.remarks());
    }
}
