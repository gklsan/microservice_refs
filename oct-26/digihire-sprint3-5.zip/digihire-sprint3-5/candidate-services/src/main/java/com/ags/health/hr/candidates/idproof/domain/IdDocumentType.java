package com.ags.health.hr.candidates.idproof.domain;

import com.ags.health.hr.common.platform.error.PlatformException;
import com.ags.health.hr.common.platform.validation.IdentityValidators;

import java.util.Locale;

public enum IdDocumentType {
    PAN(IdentityValidators.Kind.PAN, true),
    AADHAAR(IdentityValidators.Kind.AADHAAR, true),
    PASSPORT(IdentityValidators.Kind.PASSPORT, true),
    VOTER_ID(IdentityValidators.Kind.VOTER_ID, false),
    DRIVING_LICENCE(IdentityValidators.Kind.DRIVING_LICENCE, false);

    private final IdentityValidators.Kind kind;
    private final boolean primary;

    IdDocumentType(IdentityValidators.Kind kind, boolean primary) {
        this.kind = kind;
        this.primary = primary;
    }

    public IdentityValidators.Kind kind() {
        return kind;
    }

    public boolean primary() {
        return primary;
    }

    public static IdDocumentType parse(String raw) {
        try {
            return valueOf(raw == null ? "" : raw.trim().toUpperCase(Locale.ROOT).replace(' ', '_'));
        } catch (IllegalArgumentException e) {
            throw PlatformException.badRequest("ID_TYPE_INVALID", "Document type must be one of PAN, AADHAAR, PASSPORT, VOTER_ID, DRIVING_LICENCE");
        }
    }
}
