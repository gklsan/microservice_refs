package com.ags.health.hr.candidates.idproof.store;

import com.ags.health.hr.candidates.idproof.domain.IdDocument;
import com.ags.health.hr.candidates.idproof.domain.IdDocumentType;
import com.ags.health.hr.candidates.idproof.domain.VerificationStatus;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

import java.sql.Timestamp;
import java.time.Instant;
import java.util.List;
import java.util.Optional;

public class IdDocumentStore {

    private static final String COLUMNS = "id, candidate_id, doc_type, number_hash, number_masked, storage_key, content_type, "
            + "size_bytes, sha256, status, provider, verification_ref, verification_note, verified_at, uploaded_by, uploaded_at, updated_at";
    private static final RowMapper<IdDocument> ROW = (rs, i) -> new IdDocument(rs.getString(1), rs.getString(2),
            IdDocumentType.valueOf(rs.getString(3)), rs.getString(4), rs.getString(5), rs.getString(6), rs.getString(7),
            rs.getLong(8), rs.getString(9), VerificationStatus.valueOf(rs.getString(10)), rs.getString(11), rs.getString(12),
            rs.getString(13), ts(rs.getTimestamp(14)), rs.getString(15), ts(rs.getTimestamp(16)), ts(rs.getTimestamp(17)));

    private final JdbcTemplate jdbc;

    public IdDocumentStore(JdbcTemplate jdbc) {
        this.jdbc = jdbc;
    }

    public void insert(IdDocument d) {
        jdbc.update("INSERT INTO cand_id_document (" + COLUMNS + ") VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
                d.id(), d.candidateId(), d.type().name(), d.numberHash(), d.numberMasked(), d.storageKey(), d.contentType(),
                d.size(), d.sha256(), d.status().name(), d.provider(), d.verificationRef(), d.verificationNote(),
                t(d.verifiedAt()), d.uploadedBy(), t(d.uploadedAt()), t(d.updatedAt()));
    }

    public Optional<IdDocument> find(String id) {
        return jdbc.query("SELECT " + COLUMNS + " FROM cand_id_document WHERE id = ?", ROW, id).stream().findFirst();
    }

    public List<IdDocument> forCandidate(String candidateId) {
        return jdbc.query("SELECT " + COLUMNS + " FROM cand_id_document WHERE candidate_id = ? ORDER BY uploaded_at DESC", ROW, candidateId);
    }

    public List<String> otherCandidatesWithNumber(String numberHash, String candidateId) {
        return jdbc.queryForList("SELECT DISTINCT candidate_id FROM cand_id_document WHERE number_hash = ? AND candidate_id <> ? "
                + "AND status <> 'SUPERSEDED'", String.class, numberHash, candidateId);
    }

    public int supersede(String candidateId, IdDocumentType type, String keepId, Instant at) {
        return jdbc.update("UPDATE cand_id_document SET status = 'SUPERSEDED', updated_at = ? WHERE candidate_id = ? AND doc_type = ? "
                + "AND id <> ? AND status <> 'SUPERSEDED'", Timestamp.from(at), candidateId, type.name(), keepId);
    }

    public boolean updateStatus(String id, VerificationStatus expected, VerificationStatus status, String provider, String ref,
                                String note, Instant verifiedAt, Instant at) {
        return jdbc.update("UPDATE cand_id_document SET status = ?, provider = COALESCE(?, provider), verification_ref = COALESCE(?, "
                        + "verification_ref), verification_note = ?, verified_at = ?, updated_at = ? WHERE id = ?"
                        + (expected == null ? "" : " AND status = '" + expected.name() + "'"),
                status.name(), provider, ref, note, t(verifiedAt), Timestamp.from(at), id) == 1;
    }

    private static Timestamp t(Instant i) {
        return i == null ? null : Timestamp.from(i);
    }

    private static Instant ts(Timestamp t) {
        return t == null ? null : t.toInstant();
    }
}
