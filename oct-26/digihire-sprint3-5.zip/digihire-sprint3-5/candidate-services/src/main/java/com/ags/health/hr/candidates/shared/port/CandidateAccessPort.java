package com.ags.health.hr.candidates.shared.port;

import com.ags.health.hr.common.platform.caller.Caller;

public interface CandidateAccessPort {

    boolean canView(Caller caller, String candidateId);
}
