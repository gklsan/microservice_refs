package com.ags.health.hr.candidates.hrround.domain;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class FeedbackScorer {

    public record Score(double percent, List<String> missing, List<String> belowMinimum, List<String> unknown, List<String> outOfRange) {

        public boolean complete() {
            return missing.isEmpty() && unknown.isEmpty() && outOfRange.isEmpty();
        }
    }

    public Score score(List<Competency> competencies, Map<String, Integer> ratings) {
        List<String> missing = new ArrayList<>();
        List<String> below = new ArrayList<>();
        List<String> unknown = new ArrayList<>();
        List<String> range = new ArrayList<>();
        Map<String, Integer> r = ratings == null ? Map.of() : ratings;
        r.keySet().stream().filter(k -> competencies.stream().noneMatch(c -> c.code().equals(k))).forEach(unknown::add);
        double weighted = 0;
        double weights = 0;
        for (Competency c : competencies) {
            Integer v = r.get(c.code());
            if (v == null) {
                if (c.mandatory()) {
                    missing.add(c.code());
                }
                continue;
            }
            if (v < 1 || v > c.maxRating()) {
                range.add(c.code());
                continue;
            }
            if (c.mandatory() && v < c.minRating()) {
                below.add(c.code());
            }
            weighted += c.weight() * ((double) v / c.maxRating());
            weights += c.weight();
        }
        double pct = weights == 0 ? 0 : Math.round(weighted / weights * 1000.0) / 10.0;
        return new Score(pct, List.copyOf(missing), List.copyOf(below), List.copyOf(unknown), List.copyOf(range));
    }
}
