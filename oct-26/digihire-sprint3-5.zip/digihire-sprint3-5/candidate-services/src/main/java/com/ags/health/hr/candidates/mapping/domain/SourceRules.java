package com.ags.health.hr.candidates.mapping.domain;

import com.ags.health.hr.common.platform.error.PlatformException;

public final class SourceRules {

    public record Source(SourceChannel channel, String subSource) {
    }

    private SourceRules() {
    }

    public static Source resolve(String channel, String subSource, String existingChannel, String existingSubSource) {
        SourceChannel c = SourceChannel.parse(channel)
                .or(() -> SourceChannel.parse(existingChannel))
                .orElseThrow(() -> PlatformException.badRequest("SOURCE_REQUIRED",
                        "Source must be one of ERS, DIRECT, VENDOR, RECRUITER, CAMPUS, SOCIAL"));
        String sub = subSource == null || subSource.isBlank() ? null : subSource.strip();
        if (sub == null && channel == null) {
            sub = existingSubSource;
        }
        if (c.subSourceRequired() && (sub == null || sub.isBlank())) {
            throw PlatformException.badRequest("SUB_SOURCE_REQUIRED", c.subSourceLabel() + " is required for source " + c);
        }
        if (sub != null && (sub.length() > 100 || !sub.matches("[\\p{L}\\p{N} .,&()'/_-]+"))) {
            throw PlatformException.badRequest("SUB_SOURCE_INVALID", "Sub-source has characters that are not allowed");
        }
        return new Source(c, sub);
    }
}
