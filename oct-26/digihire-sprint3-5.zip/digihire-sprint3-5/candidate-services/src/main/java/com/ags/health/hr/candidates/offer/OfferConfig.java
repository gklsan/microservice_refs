package com.ags.health.hr.candidates.offer;

import com.ags.health.hr.candidates.assessmentbridge.AssessmentExceptionStore;
import com.ags.health.hr.candidates.shared.config.CandidateP5Properties;
import com.ags.health.hr.candidates.shared.domain.Statuses;
import com.ags.health.hr.candidates.shared.domain.TabMovementPolicy;
import com.ags.health.hr.candidates.shared.port.ApplicationPort;
import com.ags.health.hr.candidates.shared.service.ApplicantActionGuard;
import com.ags.health.hr.candidates.shared.service.StatusMover;
import com.ags.health.hr.common.platform.audit.AuditRecorder;
import com.ags.health.hr.common.platform.http.InternalHttp;
import org.springframework.beans.factory.ObjectProvider;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.time.Clock;
import java.util.Set;

@Configuration
public class OfferConfig {

    @Bean
    @ConditionalOnMissingBean(OfferIntegrationPort.class)
    public OfferIntegrationPort p5OfferIntegrationPort(InternalHttp p5InternalHttp, CandidateP5Properties props) {
        return new OfferIntegrationClient(p5InternalHttp, props.getClients().getIntegrationUrl());
    }

    @Bean
    public OfferService p5OfferService(StatusMover mover, ApplicantActionGuard guard, ObjectProvider<OfferDataPort> data,
                                       OfferIntegrationPort integration, AuditRecorder audit) {
        return new OfferService(mover, guard, data.getIfAvailable(), integration, audit, Set.of(Statuses.OFFERED));
    }

    @Bean
    public OfferOutcomeHandler p5OfferOutcomeHandler(ApplicationPort applications, StatusMover mover, TabMovementPolicy policy,
                                                     AssessmentExceptionStore p5AssessmentExceptionStore, AuditRecorder audit,
                                                     Clock p5Clock) {
        return new OfferOutcomeHandler(applications, mover, policy, p5AssessmentExceptionStore, audit, p5Clock, Statuses.SHORTLISTED,
                "OFFER_REJECTED");
    }
}
