package com.ags.health.hr.candidates.vendorbridge;

import com.ags.health.hr.candidates.assessmentbridge.OutboxDispatcher;
import com.ags.health.hr.common.platform.http.InternalHttp;
import com.ags.health.hr.common.platform.outbox.OutboxEvent;

import java.util.List;

public class VendorStatusDispatcher implements OutboxDispatcher {

    private final InternalHttp http;
    private final String url;

    public VendorStatusDispatcher(InternalHttp http, String vendorServicesUrl) {
        this.http = http;
        this.url = vendorServicesUrl == null || vendorServicesUrl.isBlank() ? null
                : InternalHttp.trimBase(vendorServicesUrl) + "/internal/candidate-status";
    }

    @Override
    public String eventType() {
        return VendorStatusRelay.EVENT_TYPE;
    }

    @Override
    public boolean ready() {
        return url != null;
    }

    @Override
    public void deliver(OutboxEvent event) {
        http.post(url, List.of(event.payload()));
    }
}
