package com.ags.health.hr.candidates.mapping.domain;

import java.util.Locale;

public record RejectionReason(String code, String label, String stage, String templateCode, boolean remarksRequired,
                              boolean active, int sortOrder) {

    public boolean appliesTo(String stage) {
        return this.stage == null || "ANY".equals(this.stage) || (stage != null && this.stage.equals(stage.toUpperCase(Locale.ROOT)));
    }
}
