package com.ags.health.hr.candidates.assessmentbridge;

import com.ags.health.hr.common.platform.notify.NotificationRequest;

public interface NotificationDelivery {

    void deliver(NotificationRequest request);
}
