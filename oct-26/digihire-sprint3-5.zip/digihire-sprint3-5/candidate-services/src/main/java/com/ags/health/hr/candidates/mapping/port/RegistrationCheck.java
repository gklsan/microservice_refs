package com.ags.health.hr.candidates.mapping.port;

public interface RegistrationCheck {

    void requireRegistered(String candidateId);
}
