package com.ags.health.hr.candidates.shared.port;

public record StatusChange(String actorId, String actorName, String reasonCode, String remarks, boolean system) {
}
