package com.ags.health.hr.candidates.mapping.domain;

import java.util.Locale;
import java.util.Map;
import java.util.Optional;

public enum SourceChannel {
    ERS(true, "Referrer employee id"),
    DIRECT(false, "Drive / walk-in event"),
    VENDOR(true, "Vendor id"),
    RECRUITER(false, "Recruiter sourcing channel"),
    CAMPUS(true, "Campus / institution"),
    SOCIAL(true, "Platform (LinkedIn, Naukri, ...)");

    private static final Map<String, SourceChannel> ALIASES = Map.ofEntries(
            Map.entry("EMPLOYEE_REFERRAL", ERS), Map.entry("REFERRAL", ERS), Map.entry("BUDDY_FINDER", ERS),
            Map.entry("DIRECT_RECRUITMENT", DIRECT), Map.entry("WALK_IN", DIRECT), Map.entry("WALKIN", DIRECT),
            Map.entry("CAREER_PAGE", DIRECT), Map.entry("AGENCY", VENDOR), Map.entry("CONSULTANT", VENDOR),
            Map.entry("SOURCED", RECRUITER), Map.entry("COLLEGE", CAMPUS), Map.entry("SOCIAL_MEDIA", SOCIAL),
            Map.entry("JOB_PORTAL", SOCIAL));

    private final boolean subSourceRequired;
    private final String subSourceLabel;

    SourceChannel(boolean subSourceRequired, String subSourceLabel) {
        this.subSourceRequired = subSourceRequired;
        this.subSourceLabel = subSourceLabel;
    }

    public boolean subSourceRequired() {
        return subSourceRequired;
    }

    public String subSourceLabel() {
        return subSourceLabel;
    }

    public static Optional<SourceChannel> parse(String raw) {
        if (raw == null || raw.isBlank()) {
            return Optional.empty();
        }
        String v = raw.trim().toUpperCase(Locale.ROOT).replace(' ', '_').replace('-', '_');
        for (SourceChannel c : values()) {
            if (c.name().equals(v)) {
                return Optional.of(c);
            }
        }
        return Optional.ofNullable(ALIASES.get(v));
    }
}
