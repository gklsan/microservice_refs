package com.ags.health.hr.candidates.idproof.port;

import java.time.LocalDate;

public interface IdentityVerificationPort {

    record Request(String reference, String candidateId, String documentType, String number, String fullName, LocalDate dateOfBirth) {
    }

    record Result(String status, String provider, String verificationRef, Double nameMatchScore, String message, boolean retryable) {
    }

    Result verify(Request request);
}
