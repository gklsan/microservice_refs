package com.ags.health.hr.candidates.shared.port;

import java.time.Instant;

public record ApplicationView(String id, String candidateId, String jobId, String requisitionId, String status,
                              String hrUserId, String lob, String location, String orcId, String roleCode,
                              String source, Instant statusUpdatedAt) {
}
