package com.ags.health.hr.candidates.mapping.service;

import com.ags.health.hr.candidates.mapping.domain.Blocker;
import com.ags.health.hr.candidates.mapping.domain.MappingAction;
import com.ags.health.hr.candidates.mapping.domain.MappingAssessment;
import com.ags.health.hr.candidates.mapping.domain.MappingScenarioResolver;
import com.ags.health.hr.candidates.mapping.domain.SourceRules;
import com.ags.health.hr.candidates.mapping.port.MappingGuardPort;
import com.ags.health.hr.candidates.mapping.port.RegistrationCheck;
import com.ags.health.hr.candidates.mapping.store.MappingActionStore;
import com.ags.health.hr.candidates.shared.domain.Reasons;
import com.ags.health.hr.candidates.shared.domain.Statuses;
import com.ags.health.hr.candidates.shared.port.ApplicationPort;
import com.ags.health.hr.candidates.shared.port.ApplicationView;
import com.ags.health.hr.candidates.shared.port.CandidatePort;
import com.ags.health.hr.candidates.shared.port.CandidateView;
import com.ags.health.hr.candidates.shared.port.NewApplication;
import com.ags.health.hr.candidates.shared.port.RequisitionPort;
import com.ags.health.hr.candidates.shared.port.RequisitionView;
import com.ags.health.hr.candidates.shared.port.StatusChange;
import com.ags.health.hr.candidates.shared.service.Remarks;
import com.ags.health.hr.candidates.shared.service.StatusMover;
import com.ags.health.hr.common.platform.assessment.AssessmentPort;
import com.ags.health.hr.common.platform.assessment.EligibilityResult;
import com.ags.health.hr.common.platform.audit.AuditRecorder;
import com.ags.health.hr.common.platform.caller.Caller;
import com.ags.health.hr.common.platform.error.PlatformException;
import com.ags.health.hr.common.platform.notify.NotificationPort;
import com.ags.health.hr.common.platform.notify.NotificationRequest;
import com.ags.health.hr.common.platform.time.BusinessClock;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.transaction.annotation.Transactional;

import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;

public class MappingService {

    public static final String MAP = "APPLICATION:MAP";
    public static final String VIEW = "CANDIDATE:VIEW";

    private static final Logger log = LoggerFactory.getLogger(MappingService.class);

    public record AssessRequest(String candidateId, String email, String mobile, String requisitionId) {
    }

    public record MapRequest(String candidateId, String requisitionId, String source, String subSource, String remarks) {
    }

    public record MapOutcome(String candidateId, String applicationId, String requisitionId, String status,
                             MappingAction action, String scenario, boolean tagged, List<String> warnings) {
    }

    public record Settings(boolean remarksRequired, boolean eligibilityFailOpen, String onHoldTemplate,
                           String inviteTemplate) {
    }

    private final CandidatePort candidates;
    private final ApplicationPort applications;
    private final RequisitionPort requisitions;
    private final AssessmentPort assessments;
    private final List<MappingGuardPort> guards;
    private final RegistrationCheck registration;
    private final MappingScenarioResolver resolver;
    private final MappingActionStore actions;
    private final StatusMover mover;
    private final AuditRecorder audit;
    private final NotificationPort notifications;
    private final BusinessClock clock;
    private final Settings settings;

    public MappingService(CandidatePort candidates, ApplicationPort applications, RequisitionPort requisitions,
                          AssessmentPort assessments, List<MappingGuardPort> guards, RegistrationCheck registration,
                          MappingScenarioResolver resolver, MappingActionStore actions, StatusMover mover,
                          AuditRecorder audit, NotificationPort notifications, BusinessClock clock, Settings settings) {
        this.candidates = candidates;
        this.applications = applications;
        this.requisitions = requisitions;
        this.assessments = assessments;
        this.guards = guards == null ? List.of() : List.copyOf(guards);
        this.registration = registration;
        this.resolver = resolver;
        this.actions = actions;
        this.mover = mover;
        this.audit = audit;
        this.notifications = notifications;
        this.clock = clock;
        this.settings = settings;
    }

    @Transactional(readOnly = true)
    public MappingAssessment assess(Caller caller, AssessRequest req) {
        if (!caller.hasAny(MAP, VIEW)) {
            throw PlatformException.forbidden("PERMISSION_DENIED", "Missing permission " + MAP);
        }
        if (req == null || req.requisitionId() == null || req.requisitionId().isBlank()) {
            throw PlatformException.badRequest("REQUISITION_REQUIRED", "Requisition id is required");
        }
        Optional<CandidateView> candidate = locate(req.candidateId(), req.email(), req.mobile());
        return evaluate(caller, candidate.orElse(null), req.requisitionId().trim());
    }

    @Transactional
    public MapOutcome map(Caller caller, MapRequest req) {
        if (!caller.has(MAP)) {
            throw PlatformException.forbidden("PERMISSION_DENIED", "Missing permission " + MAP);
        }
        if (req == null || req.candidateId() == null || req.requisitionId() == null) {
            throw PlatformException.badRequest("MAP_REQUEST_INVALID", "Candidate id and requisition id are required");
        }
        CandidateView c = candidates.find(req.candidateId().trim())
                .orElseThrow(() -> PlatformException.notFound("Candidate", req.candidateId()));
        String requisitionId = req.requisitionId().trim();
        String remarks = Remarks.clean(req.remarks(), settings.remarksRequired());
        Instant now = clock.now();
        MappingAssessment a = evaluate(caller, c, requisitionId);
        if (a.action() == MappingAction.INVITE_TO_REGISTER) {
            log(c.id(), null, requisitionId, a, "BLOCKED", null, null, remarks, caller, now);
            throw PlatformException.unprocessable("REGISTRATION_INCOMPLETE",
                    "Candidate must complete registration before being tagged or mapped", blockers(a));
        }
        registration.requireRegistered(c.id());
        if (a.action() == MappingAction.REMAP) {
            throw new PlatformException(409, "USE_REMAP", "Candidate already has an open application; re-map application "
                    + a.openApplicationId() + " instead", blockers(a));
        }
        if (a.blocked() || a.action() == MappingAction.REQUEST_ACCESS) {
            log(c.id(), a.openApplicationId(), requisitionId, a, "BLOCKED", null, null, remarks, caller, now);
            audit.recordQuietly("ACTIVITY", "CANDIDATE_MAPPING_BLOCKED", "CANDIDATE", c.id(), c.id(), AuditRecorder.DENIED,
                    remarks, AuditRecorder.details("requisitionId", requisitionId, "scenario", a.scenario(), "blockers", a.blockers()));
            throw new PlatformException(409, "MAPPING_BLOCKED", "Candidate can not be mapped to " + requisitionId, blockers(a));
        }
        SourceRules.Source source = SourceRules.resolve(req.source(), req.subSource(), c.source(), c.subSource());
        RequisitionView r = requisitions.find(requisitionId).orElseThrow();
        String tagged = c.taggedRecruiterId();
        boolean tag = tagged == null || tagged.isBlank() || !(caller.is(tagged) || caller.leads(tagged));
        StatusChange change = new StatusChange(caller.userId(), caller.displayName(),
                a.action() == MappingAction.MAP_ON_HOLD ? Reasons.NO_OPENINGS : null, remarks, caller.system());
        String owner = c.taggedRecruiterId();
        if (tag) {
            candidates.tagRecruiter(c.id(), caller.userId(), change);
            owner = caller.userId();
        }
        String status = a.action() == MappingAction.MAP_ON_HOLD ? Statuses.PIPELINE : Statuses.CREATED;
        ApplicationView app = applications.create(new NewApplication(c.id(), r.requisitionId(), r.jobId(), owner,
                source.channel().name(), source.subSource(), status, change));
        log(c.id(), app.id(), requisitionId, a, a.action().name(), source.channel().name(), source.subSource(), remarks, caller, now);
        audit.record("ACTIVITY", tag ? "CANDIDATE_TAGGED_AND_MAPPED" : "CANDIDATE_MAPPED", "APPLICATION", app.id(), c.id(),
                AuditRecorder.SUCCESS, remarks, AuditRecorder.details("requisitionId", requisitionId, "scenario", a.scenario(),
                        "action", a.action(), "status", status, "source", source.channel(), "subSource", source.subSource(),
                        "previousRecruiter", c.taggedRecruiterId()));
        if (a.action() == MappingAction.MAP_ON_HOLD && settings.onHoldTemplate() != null) {
            notify(settings.onHoldTemplate(), app, Map.of("requisitionId", requisitionId, "jobTitle", String.valueOf(r.title()),
                    "reasonCode", Reasons.NO_OPENINGS), now);
        }
        mover.announce(caller, app, null, status, change.reasonCode(), remarks, Map.of("source", source.channel().name(),
                "lob", String.valueOf(r.lob()), "roleCode", String.valueOf(r.roleCode()), "location", String.valueOf(r.location())));
        return new MapOutcome(c.id(), app.id(), requisitionId, status, a.action(), a.scenario().name(), tag, a.warnings());
    }

    @Transactional
    public void inviteToRegister(Caller caller, String email, String mobile, String requisitionId, String remarks) {
        if (!caller.has(MAP)) {
            throw PlatformException.forbidden("PERMISSION_DENIED", "Missing permission " + MAP);
        }
        if ((email == null || email.isBlank()) && (mobile == null || mobile.isBlank())) {
            throw PlatformException.badRequest("CONTACT_REQUIRED", "Email or mobile is required");
        }
        Optional<CandidateView> c = candidates.findByEmailOrMobile(email, mobile);
        if (c.isPresent() && c.get().registered()) {
            throw PlatformException.conflict("ALREADY_REGISTERED", "Candidate is already registered");
        }
        Instant now = clock.now();
        String key = c.map(CandidateView::id).orElse(email != null ? email.trim().toLowerCase() : mobile.trim());
        notifications.trigger(new NotificationRequest(settings.inviteTemplate(), null, c.map(CandidateView::id).orElse(null),
                settings.inviteTemplate() + ":" + key + ":" + clock.today(), Map.of("email", String.valueOf(email),
                "mobile", String.valueOf(mobile), "requisitionId", String.valueOf(requisitionId), "recruiterId", caller.userId())));
        actions.append(c.map(CandidateView::id).orElse(null), null, requisitionId, MappingAction.INVITE_TO_REGISTER.name(),
                "S6_NOT_REGISTERED", "INVITED", null, null, Remarks.clean(remarks, false), caller.userId(), caller.displayName(),
                now, Map.of("email", com.ags.health.hr.common.platform.validation.Masking.email(email)));
    }

    @Transactional(readOnly = true)
    public List<MappingActionStore.Entry> timeline(Caller caller, String candidateId, int limit) {
        if (!caller.hasAny(MAP, VIEW)) {
            throw PlatformException.forbidden("PERMISSION_DENIED", "Missing permission " + VIEW);
        }
        return actions.forCandidate(candidateId, limit);
    }

    MappingAssessment evaluate(Caller caller, CandidateView c, String requisitionId) {
        Optional<RequisitionView> r = requisitions.find(requisitionId);
        List<ApplicationView> open = c == null ? List.of() : applications.findOpenByCandidate(c.id());
        EligibilityResult eligibility = null;
        List<Blocker> extra = new ArrayList<>();
        if (c != null && r.isPresent()) {
            try {
                eligibility = assessments.check(c.id(), c.email(), c.mobile(), null, r.get().lob(), r.get().roleCode(),
                        r.get().location(), "APPLICATION");
            } catch (RuntimeException e) {
                log.warn("Eligibility check for {} failed: {}", c.id(), e.getMessage());
                if (!settings.eligibilityFailOpen()) {
                    extra.add(Blocker.of("ELIGIBILITY_UNAVAILABLE", "Eligibility could not be checked; try again shortly"));
                }
            }
            for (MappingGuardPort g : guards) {
                extra.addAll(g.check(c, r.get()));
            }
        }
        return resolver.resolve(caller, c, open, r.orElse(null), requisitionId, eligibility, extra, clock.today());
    }

    private Optional<CandidateView> locate(String candidateId, String email, String mobile) {
        if (candidateId != null && !candidateId.isBlank()) {
            return candidates.find(candidateId.trim());
        }
        if ((email == null || email.isBlank()) && (mobile == null || mobile.isBlank())) {
            throw PlatformException.badRequest("CANDIDATE_REQUIRED", "Candidate id, email or mobile is required");
        }
        return candidates.findByEmailOrMobile(email, mobile);
    }

    private void log(String candidateId, String applicationId, String requisitionId, MappingAssessment a, String outcome,
                     String source, String subSource, String remarks, Caller caller, Instant at) {
        actions.append(candidateId, applicationId, requisitionId, a.action().name(), a.scenario().name(), outcome, source,
                subSource, remarks, caller.userId(), caller.displayName(), at,
                a.blockers().isEmpty() ? Map.of() : Map.of("blockers", a.blockers().stream().map(Blocker::code).toList()));
    }

    private void notify(String template, ApplicationView app, Map<String, Object> ctx, Instant at) {
        try {
            notifications.trigger(new NotificationRequest(template, app.id(), app.candidateId(), template + ":" + app.id(), ctx));
        } catch (RuntimeException e) {
            log.warn("Notification {} for {} failed: {}", template, app.id(), e.getMessage());
        }
    }

    private static List<Map<String, Object>> blockers(MappingAssessment a) {
        List<Map<String, Object>> out = new ArrayList<>();
        for (Blocker b : a.blockers()) {
            out.add(b.until() == null ? Map.of("code", b.code(), "message", b.message())
                    : Map.of("code", b.code(), "message", b.message(), "until", b.until().toString()));
        }
        out.add(Map.of("scenario", a.scenario().name(), "action", a.action().name()));
        return out;
    }
}
