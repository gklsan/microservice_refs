package com.ags.health.hr.candidates.shared.port;

import java.util.Optional;

public interface RequisitionPort {

    Optional<RequisitionView> find(String requisitionId);
}
