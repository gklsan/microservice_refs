package com.ags.health.hr.candidates.mapping.web;

import com.ags.health.hr.candidates.mapping.domain.RemapPlan;
import com.ags.health.hr.candidates.mapping.service.ApplicantActionService;
import com.ags.health.hr.candidates.mapping.service.SchedulingService;
import com.ags.health.hr.candidates.mapping.store.InterviewSlotStore;
import com.ags.health.hr.common.platform.caller.CallerProvider;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@ConditionalOnProperty(prefix = "digihire.candidate.mapping", name = "enabled", havingValue = "true", matchIfMissing = true)
@RestController
@RequestMapping("/applicants/{applicationId}")
public class ApplicantController {

    public record MoveRequest(String toStatus, String reasonCode, String remarks) {
    }

    public record RemarksRequest(String reasonCode, String remarks) {
    }

    public record RemapRequest(String requisitionId, String remarks) {
    }

    private final ApplicantActionService actions;
    private final SchedulingService scheduling;
    private final CallerProvider callers;

    public ApplicantController(ApplicantActionService actions, SchedulingService scheduling, CallerProvider callers) {
        this.actions = actions;
        this.scheduling = scheduling;
        this.callers = callers;
    }

    @GetMapping("/transitions")
    public List<String> transitions(@PathVariable String applicationId) {
        return actions.transitions(callers.require(), applicationId);
    }

    @PostMapping("/move")
    public ApplicantActionService.ActionResult move(@PathVariable String applicationId, @RequestBody MoveRequest body) {
        return actions.move(callers.require(), applicationId, body.toStatus(), body.reasonCode(), body.remarks());
    }

    @PostMapping("/move-to-hr")
    public ApplicantActionService.ActionResult moveToHr(@PathVariable String applicationId, @RequestBody(required = false) RemarksRequest body) {
        return actions.moveToHr(callers.require(), applicationId, body == null ? null : body.remarks());
    }

    @PostMapping("/move-to-pipeline")
    public ApplicantActionService.ActionResult moveToPipeline(@PathVariable String applicationId, @RequestBody RemarksRequest body) {
        return actions.moveToPipeline(callers.require(), applicationId, body.reasonCode(), body.remarks());
    }

    @PostMapping("/reject")
    public ApplicantActionService.ActionResult reject(@PathVariable String applicationId, @RequestBody RemarksRequest body) {
        return actions.reject(callers.require(), applicationId, body.reasonCode(), body.remarks());
    }

    @PostMapping("/remap/preview")
    public RemapPlan previewRemap(@PathVariable String applicationId, @RequestBody RemapRequest body) {
        return actions.previewRemap(callers.require(), applicationId, body.requisitionId());
    }

    @PostMapping("/remap")
    public ApplicantActionService.RemapResult remap(@PathVariable String applicationId, @RequestBody RemapRequest body) {
        return actions.remap(callers.require(), applicationId, body.requisitionId(), body.remarks());
    }

    @PostMapping("/walk-in")
    public InterviewSlotStore.Booking walkIn(@PathVariable String applicationId, @RequestBody SchedulingService.ScheduleRequest body) {
        return scheduling.scheduleWalkIn(callers.require(), applicationId, body);
    }

    @PostMapping("/online-interview")
    public InterviewSlotStore.Booking online(@PathVariable String applicationId, @RequestBody SchedulingService.ScheduleRequest body) {
        return scheduling.scheduleOnline(callers.require(), applicationId, body);
    }

    @GetMapping("/bookings")
    public List<InterviewSlotStore.Booking> bookings(@PathVariable String applicationId) {
        return scheduling.bookings(callers.require(), applicationId);
    }
}
