package com.ags.health.hr.candidates.panel;

import com.ags.health.hr.candidates.mapping.port.MeetingPort;
import com.ags.health.hr.candidates.mapping.service.RejectionReasonService;
import com.ags.health.hr.candidates.panel.port.PanelistDirectoryPort;
import com.ags.health.hr.candidates.panel.service.OrcRestrictionGuard;
import com.ags.health.hr.candidates.panel.service.PanelService;
import com.ags.health.hr.candidates.panel.store.OrcRestrictionStore;
import com.ags.health.hr.candidates.panel.store.PanelStore;
import com.ags.health.hr.candidates.photo.service.PhotoVerificationService;
import com.ags.health.hr.candidates.shared.config.CandidateP5Properties;
import com.ags.health.hr.candidates.shared.port.ApplicationPort;
import com.ags.health.hr.candidates.shared.port.RequisitionPort;
import com.ags.health.hr.candidates.shared.service.ApplicantActionGuard;
import com.ags.health.hr.candidates.shared.service.StatusMover;
import com.ags.health.hr.common.platform.audit.AuditRecorder;
import com.ags.health.hr.common.platform.storage.DocumentStore;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.core.JdbcTemplate;

import java.time.Clock;

@Configuration
@ConditionalOnProperty(prefix = "digihire.candidate.panel", name = "enabled", havingValue = "true", matchIfMissing = true)
public class PanelConfig {

    @Bean
    public OrcRestrictionStore p5OrcRestrictionStore(JdbcTemplate jdbc) {
        return new OrcRestrictionStore(jdbc);
    }

    @Bean
    public OrcRestrictionGuard p5OrcRestrictionGuard(OrcRestrictionStore p5OrcRestrictionStore, Clock p5Clock) {
        return new OrcRestrictionGuard(p5OrcRestrictionStore, p5Clock);
    }

    @Bean
    public PanelService p5PanelService(JdbcTemplate jdbc, OrcRestrictionStore p5OrcRestrictionStore, PanelistDirectoryPort panelists,
                                       MeetingPort meetings, RequisitionPort requisitions, ApplicationPort applications,
                                       StatusMover mover, ApplicantActionGuard guard, RejectionReasonService reasons,
                                       PhotoVerificationService photos, DocumentStore p5DocumentStore, AuditRecorder audit,
                                       Clock p5Clock, CandidateP5Properties props) {
        CandidateP5Properties.Panel p = props.getPanel();
        return new PanelService(new PanelStore(jdbc), p5OrcRestrictionStore, panelists, meetings, requisitions, applications, mover,
                guard, reasons, photos, p5DocumentStore, audit, p5Clock, new PanelService.Settings(p.getOrcRestrictionDays(),
                p.getRecordingMaxBytes(), p.getRecordingUrlTtlMinutes(), props.getApplicant().getRejectTemplate()));
    }
}
