package com.ags.health.hr.candidates.hrround.service;

import com.ags.health.hr.candidates.hrround.domain.Competency;
import com.ags.health.hr.candidates.hrround.store.CompetencyStore;
import com.ags.health.hr.common.platform.audit.AuditRecorder;
import com.ags.health.hr.common.platform.caller.Caller;
import com.ags.health.hr.common.platform.error.PlatformException;
import org.springframework.transaction.annotation.Transactional;

import java.time.Clock;
import java.util.List;
import java.util.Locale;

public class CompetencyService {

    public static final String MANAGE = "COMPETENCY:MANAGE";

    private final CompetencyStore store;
    private final AuditRecorder audit;
    private final Clock clock;

    public CompetencyService(CompetencyStore store, AuditRecorder audit, Clock clock) {
        this.store = store;
        this.audit = audit;
        this.clock = clock;
    }

    @Transactional(readOnly = true)
    public List<Competency> list(boolean includeInactive) {
        return store.all(!includeInactive);
    }

    @Transactional
    public Competency save(Caller caller, Competency c) {
        if (!caller.has(MANAGE)) {
            throw PlatformException.forbidden("PERMISSION_DENIED", "Missing permission " + MANAGE);
        }
        if (c == null || c.code() == null || !c.code().matches("[A-Za-z0-9_]{2,40}") || c.name() == null || c.name().isBlank()) {
            throw PlatformException.badRequest("COMPETENCY_INVALID", "Code and name are required");
        }
        if (c.weight() < 1 || c.weight() > 100 || c.maxRating() < 2 || c.maxRating() > 10 || c.minRating() < 0
                || c.minRating() > c.maxRating()) {
            throw PlatformException.badRequest("COMPETENCY_INVALID", "Weight 1-100, max rating 2-10, min rating 0-max");
        }
        Competency clean = new Competency(c.code().toUpperCase(Locale.ROOT), c.name().strip(), blank(c.lob()), blank(c.roleCode()),
                c.weight(), c.maxRating(), c.minRating(), c.mandatory(), c.active(), c.sortOrder());
        store.upsert(clean, caller.userId(), clock.instant());
        audit.record("CONFIGURATION", "COMPETENCY_SAVED", "COMPETENCY", clean.code(), null,
                AuditRecorder.details("weight", clean.weight(), "mandatory", clean.mandatory(), "lob", clean.lob(), "active", clean.active()));
        return clean;
    }

    private static String blank(String v) {
        return v == null || v.isBlank() ? null : v.trim().toUpperCase(Locale.ROOT);
    }
}
