package com.ags.health.hr.candidates.assessmentbridge;

import com.ags.health.hr.candidates.shared.domain.Statuses;

public record ProviderStatuses(String yetToStart, String inProgress, String completed, String failed, String notTaken) {

    public static final ProviderStatuses VERSANT = new ProviderStatuses(Statuses.VERSANT_YET_TO_START, Statuses.VERSANT_INPROGRESS,
            Statuses.VERSANT_COMPLETED, Statuses.VERSANT_FAILED, Statuses.VERSANT_NOT_TAKEN);
    public static final ProviderStatuses ASSESSMENT = new ProviderStatuses(Statuses.ASSESEMENT_YET_TO_START,
            Statuses.ASSESEMENT_INPROGRESS, Statuses.ASSESEMENT_COMPLETED, Statuses.ASSESEMENT_FAILED, null);

    public static ProviderStatuses of(String provider) {
        return "VERSANT".equalsIgnoreCase(provider) ? VERSANT : ASSESSMENT;
    }

    public boolean contains(String status) {
        return status != null && (status.equals(yetToStart) || status.equals(inProgress) || status.equals(completed)
                || status.equals(failed) || status.equals(notTaken));
    }
}
