package com.ags.health.hr.candidates.idproof.web;

import com.ags.health.hr.candidates.idproof.service.IdProofService;
import com.ags.health.hr.common.platform.caller.CallerProvider;
import com.ags.health.hr.common.platform.error.PlatformException;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.http.CacheControl;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;

@ConditionalOnProperty(prefix = "digihire.candidate.id-proof", name = "enabled", havingValue = "true", matchIfMissing = true)
@RestController
public class IdProofController {

    public record DecisionRequest(String decision, String remarks) {
    }

    private final IdProofService service;
    private final CallerProvider callers;

    public IdProofController(IdProofService service, CallerProvider callers) {
        this.service = service;
        this.callers = callers;
    }

    @PostMapping(value = "/candidates/{candidateId}/id-documents", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    @ResponseStatus(HttpStatus.CREATED)
    public IdProofService.DocumentView upload(@PathVariable String candidateId, @RequestParam String type,
                                              @RequestParam String number, @RequestParam MultipartFile file) {
        try {
            return service.upload(callers.require(), candidateId, type, number, file.getBytes(), file.getOriginalFilename());
        } catch (IOException e) {
            throw PlatformException.badRequest("FILE_UNREADABLE", "Uploaded file could not be read");
        }
    }

    @GetMapping("/candidates/{candidateId}/id-documents")
    public IdProofService.Summary list(@PathVariable String candidateId) {
        return service.summary(callers.require(), candidateId);
    }

    @PostMapping("/id-documents/{documentId}/verify")
    public IdProofService.DocumentView verify(@PathVariable String documentId) {
        return service.verify(callers.require(), documentId);
    }

    @PostMapping("/id-documents/{documentId}/decision")
    public IdProofService.DocumentView decide(@PathVariable String documentId, @RequestBody DecisionRequest body) {
        return service.decide(callers.require(), documentId, body.decision(), body.remarks());
    }

    @GetMapping("/id-documents/{documentId}/content")
    public ResponseEntity<byte[]> content(@PathVariable String documentId, @RequestParam(required = false) String reason) {
        IdProofService.Download d = service.download(callers.require(), documentId, reason);
        return ResponseEntity.ok()
                .contentType(MediaType.parseMediaType(d.contentType()))
                .cacheControl(CacheControl.noStore())
                .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + d.fileName() + "\"")
                .header("X-Content-Type-Options", "nosniff")
                .body(d.content());
    }
}
