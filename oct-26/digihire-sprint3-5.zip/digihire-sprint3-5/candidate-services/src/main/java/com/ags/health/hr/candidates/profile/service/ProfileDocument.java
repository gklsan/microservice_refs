package com.ags.health.hr.candidates.profile.service;

import java.time.Instant;
import java.util.List;

public record ProfileDocument(String title, String candidateId, String generatedBy, Instant generatedAt, String watermark,
                              List<Section> sections) {

    public record Line(String label, String value) {
    }

    public record Section(String name, List<Line> lines) {
    }
}
