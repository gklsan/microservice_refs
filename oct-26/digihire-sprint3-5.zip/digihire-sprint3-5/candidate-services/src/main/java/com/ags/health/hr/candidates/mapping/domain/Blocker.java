package com.ags.health.hr.candidates.mapping.domain;

import java.time.Instant;

public record Blocker(String code, String message, Instant until) {

    public static Blocker of(String code, String message) {
        return new Blocker(code, message, null);
    }
}
