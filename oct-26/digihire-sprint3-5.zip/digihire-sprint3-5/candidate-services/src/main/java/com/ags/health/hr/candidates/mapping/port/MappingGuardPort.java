package com.ags.health.hr.candidates.mapping.port;

import com.ags.health.hr.candidates.mapping.domain.Blocker;
import com.ags.health.hr.candidates.shared.port.CandidateView;
import com.ags.health.hr.candidates.shared.port.RequisitionView;

import java.util.List;

public interface MappingGuardPort {

    List<Blocker> check(CandidateView candidate, RequisitionView requisition);
}
