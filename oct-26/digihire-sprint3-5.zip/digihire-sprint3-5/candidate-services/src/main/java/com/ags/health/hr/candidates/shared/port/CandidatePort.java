package com.ags.health.hr.candidates.shared.port;

import java.util.Optional;

public interface CandidatePort {

    Optional<CandidateView> find(String candidateId);

    Optional<CandidateView> findByEmailOrMobile(String email, String mobile);

    void tagRecruiter(String candidateId, String hrUserId, StatusChange change);
}
