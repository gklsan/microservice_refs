package com.ags.health.hr.candidates.shared.domain;

public final class Statuses {

    public static final String REGISTERED = "REGISTERED";
    public static final String CREATED = "CREATED";
    public static final String PIPELINE = "PIPELINE";
    public static final String WALKEDIN = "WALKEDIN";
    public static final String DEFERRED = "DEFERRED";
    public static final String WITHHELD = "WITHHELD";
    public static final String WAITING_FOR_HRROUND = "WAITING_FOR_HRROUND";
    public static final String INTERVIEW_INPROGRESS = "INTERVIEW_INPROGRESS";
    public static final String HR_REJECTED = "HR_REJECTED";
    public static final String WAITING_FOR_DEVICE = "WAITING_FOR_DEVICE";
    public static final String DEVICE_ALLOCATION_FAILED = "DEVICE_ALLOCATION_FAILED";
    public static final String ASSESEMENT_YET_TO_START = "ASSESEMENT_YET_TO_START";
    public static final String ASSESEMENT_INPROGRESS = "ASSESEMENT_INPROGRESS";
    public static final String ASSESEMENT_COMPLETED = "ASSESEMENT_COMPLETED";
    public static final String ASSESEMENT_FAILED = "ASSESEMENT_FAILED";
    public static final String VERSANT_YET_TO_START = "VERSANT_YET_TO_START";
    public static final String VERSANT_INPROGRESS = "VERSANT_INPROGRESS";
    public static final String VERSANT_COMPLETED = "VERSANT_COMPLETED";
    public static final String VERSANT_FAILED = "VERSANT_FAILED";
    public static final String VERSANT_NOT_TAKEN = "VERSANT_NOT_TAKEN";
    public static final String PANEL_YET_TO_SCHEDULE = "PANEL_YET_TO_SCHEDULE";
    public static final String PANEL_INPROGRESS = "PANEL_INPROGRESS";
    public static final String PANEL_SELECTED = "PANEL_SELECTED";
    public static final String PANEL_REJECTED = "PANEL_REJECTED";
    public static final String PANEL_DECLINED = "PANEL_DECLINED";
    public static final String PANEL_ON_HOLD = "PANEL_ON_HOLD";
    public static final String SHORTLISTED = "SHORTLISTED";
    public static final String OFFERED = "OFFERED";
    public static final String JOINED = "JOINED";
    public static final String REMAPPED = "REMAPPED";

    private Statuses() {
    }
}
