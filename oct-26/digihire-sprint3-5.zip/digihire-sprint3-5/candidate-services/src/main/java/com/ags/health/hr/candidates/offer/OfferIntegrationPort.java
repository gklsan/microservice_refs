package com.ags.health.hr.candidates.offer;

import java.util.List;
import java.util.Map;

public interface OfferIntegrationPort {

    record PushResult(String syncId, String status, String externalOfferId, List<Map<String, Object>> errors) {
    }

    PushResult push(String applicationId, String candidateId, String requestedBy, Map<String, Object> data);

    Map<String, Object> status(String applicationId);
}
