package com.ags.health.hr.candidates.assessmentbridge;

import com.ags.health.hr.common.platform.jobs.ScheduledJobRunner;
import com.ags.health.hr.common.platform.outbox.OutboxStore;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.stereotype.Component;
import org.springframework.scheduling.annotation.Scheduled;

import java.time.Duration;

@Component
@ConditionalOnProperty(prefix = "digihire.candidate.assessment", name = "enabled", havingValue = "true", matchIfMissing = true)
public class CandidateP5Jobs {

    private static final Logger log = LoggerFactory.getLogger(CandidateP5Jobs.class);

    private final ScheduledJobRunner runner;
    private final OutboxRelay relay;
    private final OutboxStore outbox;

    public CandidateP5Jobs(ScheduledJobRunner p5JobRunner, OutboxRelay p5OutboxRelay, OutboxStore p5OutboxStore) {
        this.runner = p5JobRunner;
        this.relay = p5OutboxRelay;
        this.outbox = p5OutboxStore;
    }

    @Scheduled(cron = "${digihire.candidate.jobs.outbox-cron:*/30 * * * * *}", zone = "${digihire.candidate.jobs.zone:Asia/Kolkata}")
    public void relayOutbox() {
        runner.run("candidate.p5.outbox-relay", Duration.ZERO, () -> {
            OutboxRelay.Result r = relay.relay();
            if (r.delivered() + r.failed() > 0) {
                log.info("Outbox relay delivered={} failed={} waiting={}", r.delivered(), r.failed(), r.waiting());
            }
        });
    }

    public OutboxStore.Stats stats() {
        return outbox.stats();
    }
}
