package com.ags.health.hr.candidates.panel.store;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

import java.sql.Timestamp;
import java.time.Instant;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;

public class PanelStore {

    public record Schedule(String id, String applicationId, String candidateId, int roundNo, String lob, String location, String orcId,
                           List<String> panelistIds, String mode, Instant startsAt, Instant endsAt, String meetingId,
                           String meetingUrl, String status, String outcome, String createdBy, Instant createdAt) {
    }

    public record Recording(String id, String scheduleId, String applicationId, String storageKey, String contentType, Long size,
                            String status, String uploadedBy, Instant uploadedAt, String reviewedBy, Instant reviewedAt,
                            String reviewNotes) {
    }

    private static final String COLUMNS = "id, application_id, candidate_id, round_no, lob, location, orc_id, panelist_ids, mode, "
            + "starts_at, ends_at, meeting_id, meeting_url, status, outcome, created_by, created_at";
    private static final RowMapper<Schedule> ROW = (rs, i) -> new Schedule(rs.getString(1), rs.getString(2), rs.getString(3),
            rs.getInt(4), rs.getString(5), rs.getString(6), rs.getString(7), Arrays.asList(rs.getString(8).split(",")), rs.getString(9),
            rs.getTimestamp(10).toInstant(), rs.getTimestamp(11).toInstant(), rs.getString(12), rs.getString(13), rs.getString(14),
            rs.getString(15), rs.getString(16), rs.getTimestamp(17).toInstant());
    private static final String REC_COLUMNS = "id, schedule_id, application_id, storage_key, content_type, size_bytes, status, "
            + "uploaded_by, uploaded_at, reviewed_by, reviewed_at, review_notes";
    private static final RowMapper<Recording> REC = (rs, i) -> new Recording(rs.getString(1), rs.getString(2), rs.getString(3),
            rs.getString(4), rs.getString(5), rs.getObject(6) == null ? null : rs.getLong(6), rs.getString(7), rs.getString(8),
            rs.getTimestamp(9) == null ? null : rs.getTimestamp(9).toInstant(), rs.getString(10),
            rs.getTimestamp(11) == null ? null : rs.getTimestamp(11).toInstant(), rs.getString(12));

    private final JdbcTemplate jdbc;

    public PanelStore(JdbcTemplate jdbc) {
        this.jdbc = jdbc;
    }

    public Schedule create(String applicationId, String candidateId, String lob, String location, String orcId, List<String> panelists,
                           String mode, Instant startsAt, Instant endsAt, String meetingId, String meetingUrl, String actor, Instant at) {
        Integer round = jdbc.queryForObject("SELECT COALESCE(max(round_no), 0) + 1 FROM cand_panel_schedule WHERE application_id = ?",
                Integer.class, applicationId);
        String id = UUID.randomUUID().toString();
        jdbc.update("INSERT INTO cand_panel_schedule (" + COLUMNS + ") VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'SCHEDULED', NULL, ?, ?)",
                id, applicationId, candidateId, round, lob, location, orcId, String.join(",", panelists), mode, Timestamp.from(startsAt),
                Timestamp.from(endsAt), meetingId, meetingUrl, actor, Timestamp.from(at));
        return find(id).orElseThrow();
    }

    public Optional<Schedule> find(String id) {
        return jdbc.query("SELECT " + COLUMNS + " FROM cand_panel_schedule WHERE id = ?", ROW, id).stream().findFirst();
    }

    public List<Schedule> forApplication(String applicationId) {
        return jdbc.query("SELECT " + COLUMNS + " FROM cand_panel_schedule WHERE application_id = ? ORDER BY round_no", ROW, applicationId);
    }

    public Optional<Schedule> active(String applicationId) {
        return jdbc.query("SELECT " + COLUMNS + " FROM cand_panel_schedule WHERE application_id = ? AND status = 'SCHEDULED'", ROW,
                applicationId).stream().findFirst();
    }

    public void reschedule(String id, Instant startsAt, Instant endsAt, List<String> panelists, String meetingId, String meetingUrl) {
        jdbc.update("UPDATE cand_panel_schedule SET starts_at = ?, ends_at = ?, panelist_ids = ?, meeting_id = ?, meeting_url = ? "
                + "WHERE id = ?", Timestamp.from(startsAt), Timestamp.from(endsAt), String.join(",", panelists), meetingId, meetingUrl, id);
    }

    public boolean close(String id, String status, String outcome) {
        return jdbc.update("UPDATE cand_panel_schedule SET status = ?, outcome = ? WHERE id = ? AND status = 'SCHEDULED'",
                status, outcome, id) == 1;
    }

    public void updateOrc(String applicationId, String orcId) {
        jdbc.update("UPDATE cand_panel_schedule SET orc_id = ? WHERE application_id = ? AND status IN ('SCHEDULED', 'COMPLETED')",
                orcId, applicationId);
    }

    public void history(String scheduleId, String applicationId, String action, Map<String, Object> before, Map<String, Object> after,
                        String reasonCode, String remarks, String actor, Instant at) {
        jdbc.update("INSERT INTO cand_panel_history (id, schedule_id, application_id, action, before_value, after_value, reason_code, "
                        + "remarks, actor_id, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)", UUID.randomUUID().toString(),
                scheduleId, applicationId, action, before == null ? null : before.toString(), after == null ? null : after.toString(),
                reasonCode, remarks, actor, Timestamp.from(at));
    }

    public List<Map<String, Object>> history(String applicationId) {
        return jdbc.queryForList("SELECT schedule_id, action, before_value, after_value, reason_code, remarks, actor_id, created_at "
                + "FROM cand_panel_history WHERE application_id = ? ORDER BY created_at, id", applicationId);
    }

    public Recording addRecording(String scheduleId, String applicationId, String key, String contentType, Long size, String status,
                                  String actor, Instant at) {
        String id = UUID.randomUUID().toString();
        jdbc.update("INSERT INTO cand_panel_recording (" + REC_COLUMNS + ") VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, NULL, NULL, NULL)",
                id, scheduleId, applicationId, key, contentType, size, status, actor, Timestamp.from(at));
        return recording(id).orElseThrow();
    }

    public Optional<Recording> recording(String id) {
        return jdbc.query("SELECT " + REC_COLUMNS + " FROM cand_panel_recording WHERE id = ?", REC, id).stream().findFirst();
    }

    public List<Recording> recordings(String applicationId) {
        return jdbc.query("SELECT " + REC_COLUMNS + " FROM cand_panel_recording WHERE application_id = ? ORDER BY uploaded_at", REC,
                applicationId);
    }

    public boolean markUploaded(String id, long size, Instant at) {
        return jdbc.update("UPDATE cand_panel_recording SET status = 'UPLOADED', size_bytes = ?, uploaded_at = ? WHERE id = ? "
                + "AND status = 'PENDING_UPLOAD'", size, Timestamp.from(at), id) == 1;
    }

    public boolean review(String id, String reviewer, String notes, Instant at) {
        return jdbc.update("UPDATE cand_panel_recording SET status = 'REVIEWED', reviewed_by = ?, reviewed_at = ?, review_notes = ? "
                + "WHERE id = ? AND status IN ('UPLOADED', 'REVIEWED')", reviewer, Timestamp.from(at), notes, id) == 1;
    }
}
