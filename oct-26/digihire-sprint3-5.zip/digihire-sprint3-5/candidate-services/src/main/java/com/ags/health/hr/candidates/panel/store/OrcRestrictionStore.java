package com.ags.health.hr.candidates.panel.store;

import org.springframework.jdbc.core.JdbcTemplate;

import java.sql.Timestamp;
import java.time.Instant;
import java.util.List;
import java.util.Optional;

public class OrcRestrictionStore {

    private final JdbcTemplate jdbc;

    public OrcRestrictionStore(JdbcTemplate jdbc) {
        this.jdbc = jdbc;
    }

    public void restrict(String candidateId, String orcId, String applicationId, Instant from, Instant until, String reason) {
        jdbc.update("INSERT INTO cand_orc_restriction (candidate_id, orc_id, application_id, rejected_at, restricted_until, reason) "
                + "VALUES (?, ?, ?, ?, ?, ?)", candidateId, orcId, applicationId, Timestamp.from(from), Timestamp.from(until), reason);
    }

    public Optional<Instant> activeUntil(String candidateId, String orcId, Instant now) {
        List<Timestamp> t = jdbc.queryForList("SELECT max(restricted_until) FROM cand_orc_restriction WHERE candidate_id = ? "
                + "AND orc_id = ? AND restricted_until > ?", Timestamp.class, candidateId, orcId, Timestamp.from(now));
        return t.isEmpty() || t.get(0) == null ? Optional.empty() : Optional.of(t.get(0).toInstant());
    }
}
