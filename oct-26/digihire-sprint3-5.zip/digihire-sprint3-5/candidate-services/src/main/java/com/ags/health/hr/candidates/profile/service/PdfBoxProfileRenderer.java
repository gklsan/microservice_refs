package com.ags.health.hr.candidates.profile.service;

import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.pdmodel.PDPageContentStream;
import org.apache.pdfbox.pdmodel.common.PDRectangle;
import org.apache.pdfbox.pdmodel.encryption.AccessPermission;
import org.apache.pdfbox.pdmodel.encryption.StandardProtectionPolicy;
import org.apache.pdfbox.pdmodel.font.PDType1Font;
import org.apache.pdfbox.pdmodel.font.Standard14Fonts;
import org.apache.pdfbox.util.Matrix;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.Base64;
import java.util.List;

public class PdfBoxProfileRenderer implements ProfilePdfRenderer {

    private static final float MARGIN = 50f;
    private static final float LEADING = 15f;
    private static final SecureRandom RANDOM = new SecureRandom();

    @Override
    public byte[] render(ProfileDocument doc) {
        PDType1Font regular = new PDType1Font(Standard14Fonts.FontName.HELVETICA);
        PDType1Font bold = new PDType1Font(Standard14Fonts.FontName.HELVETICA_BOLD);
        try (PDDocument pdf = new PDDocument(); ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            List<String[]> rows = new ArrayList<>();
            rows.add(new String[]{"#TITLE", doc.title()});
            rows.add(new String[]{"Candidate", doc.candidateId()});
            for (ProfileDocument.Section s : doc.sections()) {
                rows.add(new String[]{"#SECTION", s.name()});
                for (ProfileDocument.Line l : s.lines()) {
                    rows.add(new String[]{l.label(), l.value()});
                }
            }
            PDPage page = null;
            PDPageContentStream cs = null;
            float y = 0;
            for (String[] row : rows) {
                if (cs == null || y < MARGIN + 40) {
                    if (cs != null) {
                        footer(cs, regular, doc.watermark());
                        cs.close();
                    }
                    page = new PDPage(PDRectangle.A4);
                    pdf.addPage(page);
                    cs = new PDPageContentStream(pdf, page);
                    watermark(cs, bold, page, doc.watermark());
                    y = page.getMediaBox().getHeight() - MARGIN;
                }
                if ("#TITLE".equals(row[0])) {
                    text(cs, bold, 16, MARGIN, y, row[1]);
                    y -= LEADING * 2;
                } else if ("#SECTION".equals(row[0])) {
                    y -= LEADING / 2;
                    text(cs, bold, 12, MARGIN, y, row[1]);
                    y -= LEADING;
                } else {
                    text(cs, bold, 10, MARGIN, y, row[0]);
                    text(cs, regular, 10, MARGIN + 170, y, row[1]);
                    y -= LEADING;
                }
            }
            if (cs != null) {
                footer(cs, regular, doc.watermark());
                cs.close();
            }
            AccessPermission permission = new AccessPermission();
            permission.setCanModify(false);
            permission.setCanExtractContent(false);
            permission.setCanAssembleDocument(false);
            permission.setCanModifyAnnotations(false);
            permission.setCanFillInForm(false);
            permission.setCanPrint(true);
            byte[] owner = new byte[24];
            RANDOM.nextBytes(owner);
            StandardProtectionPolicy policy = new StandardProtectionPolicy(Base64.getEncoder().encodeToString(owner), "", permission);
            policy.setEncryptionKeyLength(256);
            pdf.protect(policy);
            pdf.save(out);
            return out.toByteArray();
        } catch (IOException e) {
            throw new IllegalStateException("Could not render the profile PDF", e);
        }
    }

    private static void watermark(PDPageContentStream cs, PDType1Font font, PDPage page, String text) throws IOException {
        cs.saveGraphicsState();
        cs.setNonStrokingColor(0.88f);
        cs.beginText();
        cs.setFont(font, 28);
        cs.setTextMatrix(Matrix.getRotateInstance(Math.toRadians(35), 90, page.getMediaBox().getHeight() / 4));
        cs.showText(safe(text));
        cs.endText();
        cs.restoreGraphicsState();
    }

    private static void footer(PDPageContentStream cs, PDType1Font font, String text) throws IOException {
        text(cs, font, 8, MARGIN, 25, text);
    }

    private static void text(PDPageContentStream cs, PDType1Font font, float size, float x, float y, String value)
            throws IOException {
        cs.beginText();
        cs.setFont(font, size);
        cs.newLineAtOffset(x, y);
        cs.showText(safe(value));
        cs.endText();
    }

    static String safe(String value) {
        if (value == null) {
            return "";
        }
        StringBuilder sb = new StringBuilder(value.length());
        for (char c : value.toCharArray()) {
            sb.append(c >= 0x20 && c <= 0x7E ? c : (c >= 0xA0 && c <= 0xFF ? c : '?'));
        }
        return sb.length() > 110 ? sb.substring(0, 107) + "..." : sb.toString();
    }
}
