package com.ags.health.hr.candidates.mapping.domain;

import com.ags.health.hr.candidates.shared.domain.StageCatalog;
import com.ags.health.hr.candidates.shared.domain.Statuses;
import com.ags.health.hr.candidates.shared.domain.Tab;
import com.ags.health.hr.candidates.shared.port.ApplicationView;
import com.ags.health.hr.candidates.shared.port.RequisitionView;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Set;

public class RemapPlanner {

    private static final Set<Tab> POST_HR = Set.of(Tab.ASSESSMENT, Tab.VERSANT, Tab.PANEL);

    private final StageCatalog catalog;

    public RemapPlanner(StageCatalog catalog) {
        this.catalog = catalog;
    }

    public RemapPlan plan(ApplicationView app, RequisitionView current, RequisitionView target, String targetId,
                          boolean validScoreAvailable, LocalDate today) {
        List<Blocker> blockers = new ArrayList<>();
        String status = app.status();
        if (catalog.lockedForRemap(status) || !catalog.isOpen(status)) {
            blockers.add(Blocker.of("STAGE_LOCKED", "Application at " + status + " can not be re-mapped"));
            return new RemapPlan(app.id(), app.requisitionId(), targetId, RemapScenario.STAGE_LOCKED, false, status, null,
                    false, blockers, null);
        }
        if (target == null) {
            blockers.add(Blocker.of("REQUISITION_NOT_FOUND", "Requisition " + targetId + " does not exist"));
        } else {
            MappingScenarioResolver.requisitionProblem(target, today).ifPresent(blockers::add);
            if (blockers.isEmpty() && target.available() <= 0) {
                blockers.add(Blocker.of("NO_OPENINGS", "Requisition " + target.requisitionId() + " has no open positions"));
            }
        }
        if (target != null && target.requisitionId().equalsIgnoreCase(String.valueOf(app.requisitionId()))) {
            blockers.add(Blocker.of("SAME_REQUISITION", "Application is already on requisition " + target.requisitionId()));
        }
        if (!blockers.isEmpty()) {
            boolean onlyOpenings = blockers.stream().allMatch(b -> b.code().equals("NO_OPENINGS"));
            return new RemapPlan(app.id(), app.requisitionId(), targetId, RemapScenario.TARGET_UNAVAILABLE, false, status,
                    null, false, blockers, onlyOpenings ? "MOVE_TO_PIPELINE_ON_HOLD" : null);
        }
        Tab tab = catalog.tabOf(status);
        String lobFrom = lob(app, current);
        String lobTo = norm(target.lob());
        String roleFrom = role(app, current);
        String roleTo = norm(target.roleCode());
        String locFrom = location(app, current);
        String locTo = norm(target.location());
        if (!Objects.equals(lobFrom, lobTo)) {
            String next = tab == Tab.APPLICANT || tab == Tab.PIPELINE ? status : Statuses.CREATED;
            return new RemapPlan(app.id(), app.requisitionId(), target.requisitionId(), RemapScenario.NEW_LOB, true, status,
                    next, false, List.of(), null);
        }
        if (!Objects.equals(roleFrom, roleTo)) {
            String next = status;
            boolean reused = false;
            if (POST_HR.contains(tab)) {
                if (validScoreAvailable) {
                    reused = true;
                } else {
                    next = Statuses.ASSESEMENT_YET_TO_START;
                }
            }
            return new RemapPlan(app.id(), app.requisitionId(), target.requisitionId(), RemapScenario.SAME_LOB_NEW_ROLE, true,
                    status, next, reused, List.of(), null);
        }
        if (!Objects.equals(locFrom, locTo)) {
            String next = tab == Tab.HR_INTERVIEW ? Statuses.CREATED : status;
            return new RemapPlan(app.id(), app.requisitionId(), target.requisitionId(), RemapScenario.NEW_LOCATION, true,
                    status, next, POST_HR.contains(tab), List.of(), null);
        }
        return new RemapPlan(app.id(), app.requisitionId(), target.requisitionId(), RemapScenario.SAME_ROLE_SAME_LOB, true,
                status, status, POST_HR.contains(tab), List.of(), null);
    }

    private static String lob(ApplicationView a, RequisitionView r) {
        return norm(a.lob() != null ? a.lob() : r == null ? null : r.lob());
    }

    private static String role(ApplicationView a, RequisitionView r) {
        return norm(a.roleCode() != null ? a.roleCode() : r == null ? null : r.roleCode());
    }

    private static String location(ApplicationView a, RequisitionView r) {
        return norm(a.location() != null ? a.location() : r == null ? null : r.location());
    }

    private static String norm(String v) {
        return v == null || v.isBlank() ? null : v.trim().toUpperCase();
    }
}
