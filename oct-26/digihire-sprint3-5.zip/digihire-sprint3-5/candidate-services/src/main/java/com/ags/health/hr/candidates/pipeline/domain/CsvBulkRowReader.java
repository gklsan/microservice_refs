package com.ags.health.hr.candidates.pipeline.domain;

import com.ags.health.hr.common.platform.error.PlatformException;

import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public class CsvBulkRowReader implements BulkRowReader {

    @Override
    public boolean supports(String fileName) {
        return fileName != null && fileName.toLowerCase(Locale.ROOT).endsWith(".csv");
    }

    @Override
    public List<BulkRow> read(byte[] content, int maxRows) {
        List<BulkRow> rows = new ArrayList<>();
        try (BufferedReader r = new BufferedReader(new InputStreamReader(new ByteArrayInputStream(content), StandardCharsets.UTF_8))) {
            String header = r.readLine();
            if (header == null) {
                throw PlatformException.badRequest("FILE_EMPTY", "The file has no header row");
            }
            Map<String, Integer> idx = index(split(header.replace("﻿", "")));
            String line;
            int rowNo = 1;
            while ((line = r.readLine()) != null) {
                rowNo++;
                if (line.isBlank()) {
                    continue;
                }
                if (rows.size() >= maxRows) {
                    throw PlatformException.badRequest("TOO_MANY_ROWS", "At most " + maxRows + " rows per upload");
                }
                List<String> cells = split(line);
                rows.add(new BulkRow(rowNo, cell(cells, idx.get(HEADER_APPLICATION)), cell(cells, idx.get(HEADER_STATUS)),
                        cell(cells, idx.get(HEADER_REASON)), cell(cells, idx.get(HEADER_REMARKS))));
            }
        } catch (IOException e) {
            throw PlatformException.badRequest("FILE_UNREADABLE", "The file could not be read");
        }
        return rows;
    }

    static Map<String, Integer> index(List<String> headers) {
        Map<String, Integer> idx = new HashMap<>();
        for (int i = 0; i < headers.size(); i++) {
            String h = headers.get(i).trim();
            for (String known : List.of(HEADER_APPLICATION, HEADER_STATUS, HEADER_REASON, HEADER_REMARKS)) {
                if (known.equalsIgnoreCase(h)) {
                    idx.put(known, i);
                }
            }
        }
        if (!idx.containsKey(HEADER_APPLICATION) || !idx.containsKey(HEADER_STATUS)) {
            throw PlatformException.badRequest("HEADER_INVALID", "Columns applicationId and targetStatus are required");
        }
        return idx;
    }

    static String cell(List<String> cells, Integer i) {
        if (i == null || i >= cells.size()) {
            return null;
        }
        String v = cells.get(i).trim();
        if (!v.isEmpty() && "=+-@".indexOf(v.charAt(0)) >= 0 && !v.matches("-?\\d+(\\.\\d+)?")) {
            v = v.substring(1);
        }
        return v.isEmpty() ? null : v;
    }

    static List<String> split(String line) {
        List<String> out = new ArrayList<>();
        StringBuilder cur = new StringBuilder();
        boolean quoted = false;
        for (int i = 0; i < line.length(); i++) {
            char c = line.charAt(i);
            if (quoted) {
                if (c == '"' && i + 1 < line.length() && line.charAt(i + 1) == '"') {
                    cur.append('"');
                    i++;
                } else if (c == '"') {
                    quoted = false;
                } else {
                    cur.append(c);
                }
            } else if (c == '"') {
                quoted = true;
            } else if (c == ',') {
                out.add(cur.toString());
                cur.setLength(0);
            } else {
                cur.append(c);
            }
        }
        out.add(cur.toString());
        return out;
    }
}
