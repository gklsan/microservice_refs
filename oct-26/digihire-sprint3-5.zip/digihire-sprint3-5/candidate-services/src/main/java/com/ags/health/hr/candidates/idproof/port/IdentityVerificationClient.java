package com.ags.health.hr.candidates.idproof.port;

import com.ags.health.hr.common.platform.http.InternalHttp;
import com.fasterxml.jackson.databind.JsonNode;

import java.util.LinkedHashMap;
import java.util.Map;

public class IdentityVerificationClient implements IdentityVerificationPort {

    private final InternalHttp http;
    private final String base;

    public IdentityVerificationClient(InternalHttp http, String integrationUrl) {
        this.http = http;
        this.base = InternalHttp.trimBase(integrationUrl);
    }

    @Override
    public Result verify(Request r) {
        Map<String, Object> body = new LinkedHashMap<>();
        body.put("reference", r.reference());
        body.put("candidateId", r.candidateId());
        body.put("documentType", r.documentType());
        body.put("number", r.number());
        body.put("fullName", r.fullName());
        body.put("dateOfBirth", r.dateOfBirth() == null ? null : r.dateOfBirth().toString());
        try {
            JsonNode n = http.post(base + "/internal/identity/verify", body);
            return new Result(n.path("status").asText("FAILED"), n.path("provider").asText(null), n.path("verificationRef").asText(null),
                    n.hasNonNull("nameMatchScore") ? n.get("nameMatchScore").asDouble() : null, n.path("message").asText(null),
                    n.path("retryable").asBoolean(false));
        } catch (InternalHttp.Failure f) {
            return new Result("ERROR", null, null, null, "Identity verification call failed: " + f.status(), f.isOutage());
        }
    }
}
