package com.ags.health.hr.candidates.idproof.port;

import java.time.LocalDate;
import java.util.Optional;

public interface IdentityHintPort {

    record Hint(String fullName, LocalDate dateOfBirth) {
    }

    Optional<Hint> hint(String candidateId);
}
