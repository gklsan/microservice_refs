package com.ags.health.hr.candidates.idproof.domain;

import java.util.List;

public enum VerificationBadge {
    NONE, PENDING, VERIFIED, ATTENTION;

    public static VerificationBadge of(List<IdDocument> documents) {
        List<IdDocument> live = documents.stream().filter(d -> d.status() != VerificationStatus.SUPERSEDED).toList();
        if (live.isEmpty()) {
            return NONE;
        }
        if (live.stream().anyMatch(d -> d.status() == VerificationStatus.MISMATCH)) {
            return ATTENTION;
        }
        if (live.stream().anyMatch(d -> d.type().primary() && d.status() == VerificationStatus.VERIFIED)) {
            return VERIFIED;
        }
        if (live.stream().anyMatch(d -> d.status() == VerificationStatus.FAILED || d.status() == VerificationStatus.MANUAL_REVIEW)) {
            return ATTENTION;
        }
        return PENDING;
    }
}
