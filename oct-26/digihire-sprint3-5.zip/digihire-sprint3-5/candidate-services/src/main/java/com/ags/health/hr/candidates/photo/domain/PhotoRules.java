package com.ags.health.hr.candidates.photo.domain;

import com.ags.health.hr.common.platform.error.PlatformException;
import com.ags.health.hr.common.platform.storage.FileInspector;
import com.ags.health.hr.common.platform.storage.ImageInspector;

import java.util.Set;

public class PhotoRules {

    private final int minWidth;
    private final int minHeight;
    private final long maxBytes;
    private final double matchThreshold;
    private final double reviewThreshold;

    public PhotoRules(int minWidth, int minHeight, long maxBytes, double matchThreshold, double reviewThreshold) {
        if (reviewThreshold > matchThreshold) {
            throw new IllegalArgumentException("Review threshold must not exceed the match threshold");
        }
        this.minWidth = minWidth;
        this.minHeight = minHeight;
        this.maxBytes = maxBytes;
        this.matchThreshold = matchThreshold;
        this.reviewThreshold = reviewThreshold;
    }

    public FileInspector.Kind validate(byte[] image, String fileName) {
        FileInspector.Kind kind = FileInspector.require(image, fileName, maxBytes, Set.of(FileInspector.Kind.JPEG, FileInspector.Kind.PNG));
        ImageInspector.Dimensions d = ImageInspector.dimensions(image)
                .orElseThrow(() -> PlatformException.badRequest("IMAGE_UNREADABLE", "Image could not be read"));
        if (d.width() < minWidth || d.height() < minHeight) {
            throw PlatformException.badRequest("IMAGE_TOO_SMALL", "Photo must be at least " + minWidth + "x" + minHeight + " pixels");
        }
        if (d.aspect() < 0.5 || d.aspect() > 2.0) {
            throw PlatformException.badRequest("IMAGE_ASPECT_INVALID", "Photo must be roughly portrait or square");
        }
        return kind;
    }

    public PhotoDecision decide(double score) {
        if (score >= matchThreshold) {
            return PhotoDecision.MATCH;
        }
        return score >= reviewThreshold ? PhotoDecision.UNSURE : PhotoDecision.MISMATCH;
    }
}
