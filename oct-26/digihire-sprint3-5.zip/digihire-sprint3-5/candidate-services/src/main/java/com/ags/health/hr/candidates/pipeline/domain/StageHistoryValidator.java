package com.ags.health.hr.candidates.pipeline.domain;

import com.ags.health.hr.candidates.shared.domain.Statuses;
import com.ags.health.hr.candidates.shared.port.StageEntry;
import com.ags.health.hr.common.platform.assessment.AssessmentPort;

import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import static com.ags.health.hr.candidates.shared.domain.Statuses.*;

public class StageHistoryValidator {

    public record Check(boolean ok, List<String> problems) {
    }

    private static final Set<String> HR_CLEARED = Set.of(WAITING_FOR_DEVICE, ASSESEMENT_YET_TO_START, ASSESEMENT_INPROGRESS,
            ASSESEMENT_COMPLETED, VERSANT_YET_TO_START, VERSANT_COMPLETED, PANEL_YET_TO_SCHEDULE, PANEL_INPROGRESS, PANEL_SELECTED);
    private static final Set<String> ASSESSMENT_STAGES = Set.of(WAITING_FOR_DEVICE, ASSESEMENT_YET_TO_START, ASSESEMENT_INPROGRESS);
    private static final Set<String> VERSANT_STAGES = Set.of(VERSANT_YET_TO_START, VERSANT_INPROGRESS);
    private static final Set<String> PANEL_STAGES = Set.of(PANEL_YET_TO_SCHEDULE, PANEL_INPROGRESS);
    private static final Set<String> OFFER_STAGES = Set.of(SHORTLISTED, OFFERED);

    public Check check(String target, List<StageEntry> history, List<AssessmentPort.ValidScore> validScores, boolean versantRequired,
                       Instant now) {
        Set<String> seen = history == null ? Set.of() : history.stream().map(StageEntry::status).collect(Collectors.toSet());
        boolean score = validScores != null && validScores.stream().anyMatch(s -> s.validUntil() == null || s.validUntil().isAfter(now));
        List<String> problems = new ArrayList<>();
        if (ASSESSMENT_STAGES.contains(target) && seen.stream().noneMatch(HR_CLEARED::contains)
                && !seen.contains(INTERVIEW_INPROGRESS)) {
            problems.add("HR_ROUND_NOT_CLEARED");
        }
        if (VERSANT_STAGES.contains(target) || PANEL_STAGES.contains(target)) {
            if (!seen.contains(ASSESEMENT_COMPLETED)) {
                problems.add("ASSESSMENT_NOT_COMPLETED");
            } else if (!score) {
                problems.add("ASSESSMENT_SCORE_EXPIRED");
            }
        }
        if (PANEL_STAGES.contains(target) && versantRequired && !seen.contains(VERSANT_COMPLETED)) {
            problems.add("VERSANT_NOT_COMPLETED");
        }
        if (OFFER_STAGES.contains(target) && !seen.contains(PANEL_SELECTED)) {
            problems.add("PANEL_NOT_SELECTED");
        }
        if (Statuses.JOINED.equals(target) && !seen.contains(OFFERED)) {
            problems.add("NOT_OFFERED");
        }
        return new Check(problems.isEmpty(), List.copyOf(problems));
    }
}
