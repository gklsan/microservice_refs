package com.ags.health.hr.candidates.shared.web;

import com.ags.health.hr.common.platform.error.PlatformException;
import org.slf4j.MDC;
import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.http.HttpStatus;
import org.springframework.http.ProblemDetail;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

@Order(Ordered.HIGHEST_PRECEDENCE)
@RestControllerAdvice(basePackages = {
        "com.ags.health.hr.candidates.shared",
        "com.ags.health.hr.candidates.profile",
        "com.ags.health.hr.candidates.mapping",
        "com.ags.health.hr.candidates.versant",
        "com.ags.health.hr.candidates.assessmentbridge",
        "com.ags.health.hr.candidates.idproof",
        "com.ags.health.hr.candidates.photo",
        "com.ags.health.hr.candidates.pipeline",
        "com.ags.health.hr.candidates.hrround",
        "com.ags.health.hr.candidates.panel"})
public class P5ExceptionAdvice {

    @ExceptionHandler(PlatformException.class)
    public ResponseEntity<ProblemDetail> platform(PlatformException e) {
        return ResponseEntity.status(HttpStatus.valueOf(e.getStatus())).body(problem(e));
    }

    public static ProblemDetail problem(PlatformException e) {
        ProblemDetail p = ProblemDetail.forStatusAndDetail(HttpStatus.valueOf(e.getStatus()), e.getMessage());
        p.setTitle(e.getCode());
        p.setProperty("code", e.getCode());
        String correlation = MDC.get("correlationId") != null ? MDC.get("correlationId") : MDC.get("req-id");
        if (correlation != null) {
            p.setProperty("correlationId", correlation);
        }
        if (e.getDetails() != null && !e.getDetails().isEmpty()) {
            p.setProperty("errors", e.getDetails());
        }
        return p;
    }
}
