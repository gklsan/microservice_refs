package com.ags.health.hr.candidates.assessmentbridge;

import com.ags.health.hr.common.platform.outbox.OutboxEvent;
import com.ags.health.hr.common.platform.outbox.OutboxStore;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class OutboxRelay {

    private static final Logger log = LoggerFactory.getLogger(OutboxRelay.class);

    public record Result(int delivered, int failed, int waiting) {
    }

    private final OutboxStore outbox;
    private final Map<String, OutboxDispatcher> dispatchers = new HashMap<>();
    private final int batchSize;

    public OutboxRelay(OutboxStore outbox, List<OutboxDispatcher> dispatchers, int batchSize) {
        this.outbox = outbox;
        dispatchers.forEach(d -> this.dispatchers.put(d.eventType(), d));
        this.batchSize = Math.max(1, batchSize);
    }

    public Result relay() {
        int delivered = 0;
        int failed = 0;
        int waiting = 0;
        List<String> types = dispatchers.values().stream().filter(OutboxDispatcher::ready).map(OutboxDispatcher::eventType).toList();
        if (types.isEmpty()) {
            return new Result(0, 0, 0);
        }
        for (OutboxEvent e : outbox.due(batchSize, types)) {
            OutboxDispatcher d = dispatchers.get(e.eventType());
            if (d == null || !d.ready()) {
                waiting++;
                continue;
            }
            try {
                d.deliver(e);
                outbox.markPublished(List.of(e));
                delivered++;
            } catch (RuntimeException ex) {
                failed++;
                outbox.markFailed(List.of(e), ex.getMessage());
                log.warn("Outbox event {} {} failed: {}", e.eventType(), e.id(), ex.getMessage());
            }
        }
        return new Result(delivered, failed, waiting);
    }
}
