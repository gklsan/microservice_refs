package com.ags.health.hr.candidates.assessmentbridge;

import com.ags.health.hr.common.platform.notify.NotificationPort;
import com.ags.health.hr.common.platform.notify.NotificationRequest;
import com.ags.health.hr.common.platform.outbox.OutboxStore;

import java.util.LinkedHashMap;
import java.util.Map;

public class OutboxNotificationPort implements NotificationPort {

    public static final String EVENT_TYPE = "NOTIFICATION_REQUESTED";

    private final OutboxStore outbox;

    public OutboxNotificationPort(OutboxStore outbox) {
        this.outbox = outbox;
    }

    @Override
    public void trigger(NotificationRequest r) {
        Map<String, Object> p = new LinkedHashMap<>();
        p.put("eventType", r.eventType());
        p.put("applicationId", r.applicationId());
        p.put("candidateId", r.candidateId());
        p.put("idempotencyKey", r.idempotencyKey());
        p.put("context", r.context());
        outbox.append(EVENT_TYPE, "NOTIFICATION", r.idempotencyKey() == null ? r.eventType() : r.idempotencyKey(),
                r.candidateId(), r.applicationId(), p);
    }
}
