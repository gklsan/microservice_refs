package com.ags.health.hr.candidates.hrround.service;

import com.ags.health.hr.candidates.hrround.domain.Competency;
import com.ags.health.hr.candidates.hrround.domain.FeedbackScorer;
import com.ags.health.hr.candidates.hrround.store.CompetencyStore;
import com.ags.health.hr.candidates.hrround.store.HrInterviewStore;
import com.ags.health.hr.candidates.mapping.domain.RejectionReason;
import com.ags.health.hr.candidates.mapping.service.RejectionReasonService;
import com.ags.health.hr.candidates.photo.domain.PhotoCheck;
import com.ags.health.hr.candidates.photo.domain.PhotoDecision;
import com.ags.health.hr.candidates.photo.service.PhotoVerificationService;
import com.ags.health.hr.candidates.shared.domain.Statuses;
import com.ags.health.hr.candidates.shared.domain.TabMovementPolicy;
import com.ags.health.hr.candidates.shared.port.ApplicationView;
import com.ags.health.hr.candidates.shared.service.ApplicantActionGuard;
import com.ags.health.hr.candidates.shared.service.Remarks;
import com.ags.health.hr.candidates.shared.service.StatusMover;
import com.ags.health.hr.common.platform.audit.AuditRecorder;
import com.ags.health.hr.common.platform.caller.Caller;
import com.ags.health.hr.common.platform.error.PlatformException;
import com.ags.health.hr.common.platform.storage.DocumentStore;
import com.ags.health.hr.common.platform.storage.FileInspector;
import com.ags.health.hr.common.platform.storage.StoredDocument;
import org.springframework.transaction.annotation.Transactional;

import java.time.Clock;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

public class HrRoundService {

    public static final String CONDUCT = "INTERVIEW_FEEDBACK:CREATE";
    public static final String ONLINE = "ONLINE";
    public static final String IN_OFFICE = "IN_OFFICE";
    public static final Set<String> NEXT_STAGES = Set.of(Statuses.WAITING_FOR_DEVICE, Statuses.ASSESEMENT_YET_TO_START,
            Statuses.VERSANT_YET_TO_START, Statuses.PANEL_YET_TO_SCHEDULE);

    public enum Outcome { SELECT, REJECT, HOLD }

    public record FeedbackRequest(Map<String, Integer> ratings, String comments, String outcome, String nextStage,
                                  String rejectionReason, String remarks, String overrideReason) {
    }

    public record FeedbackResult(String interviewId, String outcome, double score, String toStatus, String toTab) {
    }

    public record Settings(int minScreenshots, boolean kioskMatchRequired, double passPercent, int maxEvidenceBytes,
                           String rejectTemplate) {
    }

    private final HrInterviewStore interviews;
    private final CompetencyStore competencies;
    private final FeedbackScorer scorer = new FeedbackScorer();
    private final StatusMover mover;
    private final ApplicantActionGuard guard;
    private final TabMovementPolicy policy;
    private final PhotoVerificationService photos;
    private final RejectionReasonService reasons;
    private final DocumentStore files;
    private final AuditRecorder audit;
    private final Clock clock;
    private final Settings settings;

    public HrRoundService(HrInterviewStore interviews, CompetencyStore competencies, StatusMover mover, ApplicantActionGuard guard,
                          TabMovementPolicy policy, PhotoVerificationService photos, RejectionReasonService reasons,
                          DocumentStore files, AuditRecorder audit, Clock clock, Settings settings) {
        this.interviews = interviews;
        this.competencies = competencies;
        this.mover = mover;
        this.guard = guard;
        this.policy = policy;
        this.photos = photos;
        this.reasons = reasons;
        this.files = files;
        this.audit = audit;
        this.clock = clock;
        this.settings = settings;
    }

    @Transactional
    public HrInterviewStore.Interview start(Caller caller, String applicationId, String mode) {
        if (!caller.has(CONDUCT)) {
            throw PlatformException.forbidden("PERMISSION_DENIED", "Missing permission " + CONDUCT);
        }
        String m = mode == null ? "" : mode.trim().toUpperCase(Locale.ROOT).replace('-', '_');
        if (!ONLINE.equals(m) && !IN_OFFICE.equals(m)) {
            throw PlatformException.badRequest("MODE_INVALID", "Mode must be ONLINE or IN_OFFICE");
        }
        ApplicationView app = mover.load(applicationId);
        if (interviews.openFor(app.id()).isPresent()) {
            throw PlatformException.conflict("INTERVIEW_IN_PROGRESS", "An HR interview is already in progress");
        }
        if (!Statuses.WAITING_FOR_HRROUND.equals(app.status()) && !Statuses.WALKEDIN.equals(app.status())) {
            throw PlatformException.conflict("NOT_READY_FOR_HR_ROUND", "Applicant is at " + app.status());
        }
        mover.move(caller, app, StatusMover.Move.to(app.id(), Statuses.INTERVIEW_INPROGRESS, null).with("mode", m));
        HrInterviewStore.Interview i = interviews.start(app.id(), app.candidateId(), m, caller.userId(), clock.instant());
        audit.record("ACTIVITY", "HR_INTERVIEW_STARTED", "APPLICATION", app.id(), app.candidateId(),
                AuditRecorder.details("interviewId", i.id(), "mode", m));
        return i;
    }

    @Transactional
    public HrInterviewStore.Evidence screenshot(Caller caller, String interviewId, byte[] image, String fileName) {
        HrInterviewStore.Interview i = open(caller, interviewId);
        if (!ONLINE.equals(i.mode())) {
            throw PlatformException.badRequest("MODE_MISMATCH", "Screenshots are captured for online interviews");
        }
        FileInspector.Kind kind = FileInspector.require(image, fileName, settings.maxEvidenceBytes(),
                Set.of(FileInspector.Kind.JPEG, FileInspector.Kind.PNG));
        Instant now = clock.instant();
        String key = "p5/hr/" + i.applicationId() + "/" + i.id() + "/screenshot-" + now.toEpochMilli();
        StoredDocument d = files.put(key, image, kind.contentType(), Map.of("interview", i.id()));
        HrInterviewStore.Evidence e = interviews.addEvidence(i.id(), "SCREENSHOT", key, d.sha256(), image.length, kind.contentType(),
                null, caller.userId(), now);
        audit.record("ACTIVITY", "HR_SCREENSHOT_CAPTURED", "APPLICATION", i.applicationId(), i.candidateId(),
                AuditRecorder.details("interviewId", i.id(), "evidenceId", e.id(), "sha256", d.sha256()));
        return e;
    }

    @Transactional
    public PhotoCheck kioskPhoto(Caller caller, String interviewId, byte[] image, String fileName) {
        HrInterviewStore.Interview i = open(caller, interviewId);
        if (!IN_OFFICE.equals(i.mode())) {
            throw PlatformException.badRequest("MODE_MISMATCH", "Kiosk photos are captured for in-office interviews");
        }
        photos.validatePhoto(image, fileName);
        Instant now = clock.instant();
        String key = "p5/hr/" + i.applicationId() + "/" + i.id() + "/kiosk-" + now.toEpochMilli();
        StoredDocument d = files.put(key, image, FileInspector.detect(image).contentType(), Map.of("interview", i.id()));
        PhotoCheck check = photos.automatic(caller, mover.load(i.applicationId()), "HR_ROUND", image);
        interviews.addEvidence(i.id(), "KIOSK_PHOTO", key, d.sha256(), image.length, FileInspector.detect(image).contentType(),
                check.id(), caller.userId(), now);
        return check;
    }

    @Transactional(readOnly = true)
    public List<Competency> competenciesFor(String applicationId) {
        ApplicationView app = mover.load(applicationId);
        return competencies.all(true).stream().filter(c -> c.appliesTo(app.lob(), app.roleCode())).toList();
    }

    @Transactional
    public FeedbackResult feedback(Caller caller, String interviewId, FeedbackRequest req) {
        HrInterviewStore.Interview i = open(caller, interviewId);
        if (req == null) {
            throw PlatformException.badRequest("FEEDBACK_REQUIRED", "Feedback is required");
        }
        Outcome outcome;
        try {
            outcome = Outcome.valueOf(req.outcome() == null ? "" : req.outcome().trim().toUpperCase(Locale.ROOT));
        } catch (IllegalArgumentException e) {
            throw PlatformException.badRequest("OUTCOME_INVALID", "Outcome must be SELECT, REJECT or HOLD");
        }
        ApplicationView app = mover.load(i.applicationId());
        List<Competency> applicable = competencies.all(true).stream().filter(c -> c.appliesTo(app.lob(), app.roleCode())).toList();
        FeedbackScorer.Score score = scorer.score(applicable, req.ratings());
        List<Map<String, Object>> problems = new ArrayList<>();
        score.missing().forEach(c -> problems.add(Map.of("competency", c, "code", "RATING_REQUIRED")));
        score.unknown().forEach(c -> problems.add(Map.of("competency", c, "code", "UNKNOWN_COMPETENCY")));
        score.outOfRange().forEach(c -> problems.add(Map.of("competency", c, "code", "RATING_OUT_OF_RANGE")));
        String override = Remarks.clean(req.overrideReason(), false);
        evidenceProblems(i, override).forEach(p -> problems.add(Map.of("code", p)));
        if (outcome == Outcome.SELECT) {
            if (score.percent() < settings.passPercent()) {
                problems.add(Map.of("code", "SCORE_BELOW_PASS", "score", score.percent(), "pass", settings.passPercent()));
            }
            score.belowMinimum().forEach(c -> problems.add(Map.of("competency", c, "code", "MANDATORY_BELOW_MINIMUM")));
        }
        if (!problems.isEmpty()) {
            throw PlatformException.unprocessable("FEEDBACK_INVALID", "HR feedback can not be submitted", problems);
        }
        String comments = Remarks.clean(req.comments(), outcome != Outcome.SELECT);
        StatusMover.Move move;
        switch (outcome) {
            case SELECT -> {
                String next = req.nextStage() == null ? null : req.nextStage().trim().toUpperCase(Locale.ROOT);
                if (next == null || !NEXT_STAGES.contains(next) || !policy.allows(app.status(), next)) {
                    throw PlatformException.badRequest("NEXT_STAGE_INVALID", "Next stage must be one of " + NEXT_STAGES);
                }
                move = StatusMover.Move.to(app.id(), next, null).reason("HR_SELECTED", comments);
            }
            case REJECT -> {
                RejectionReason reason = reasons.require(req.rejectionReason(), "HR_INTERVIEW");
                move = StatusMover.Move.to(app.id(), Statuses.HR_REJECTED, null).reason(reason.code(), comments)
                        .notify(reason.templateCode() != null ? reason.templateCode() : settings.rejectTemplate())
                        .with("roleCode", app.roleCode()).with("location", app.location());
            }
            default -> move = StatusMover.Move.to(app.id(), Statuses.PIPELINE, null).reason("HR_HOLD", comments);
        }
        Instant now = clock.instant();
        interviews.saveFeedback(i.id(), req.ratings() == null ? Map.of() : req.ratings(), comments, caller.userId(), now);
        StatusMover.Result r = mover.move(caller, app, move.with("interviewId", i.id()).with("score", score.percent()));
        interviews.complete(i.id(), outcome.name(), score.percent(), r.toStatus(), now);
        audit.record("ACTIVITY", "HR_FEEDBACK_SUBMITTED", "APPLICATION", app.id(), app.candidateId(), AuditRecorder.SUCCESS, comments,
                AuditRecorder.details("interviewId", i.id(), "outcome", outcome, "score", score.percent(), "toStatus", r.toStatus(),
                        "override", override));
        return new FeedbackResult(i.id(), outcome.name(), score.percent(), r.toStatus(), r.toTab().name());
    }

    @Transactional(readOnly = true)
    public Map<String, Object> details(Caller caller, String applicationId) {
        ApplicationView app = mover.load(applicationId);
        if (!caller.has(CONDUCT)) {
            guard.require(caller, app, "INTERVIEW_FEEDBACK:VIEW");
        }
        List<Map<String, Object>> out = new ArrayList<>();
        for (HrInterviewStore.Interview i : interviews.forApplication(app.id())) {
            out.add(Map.of("interview", i, "evidence", interviews.evidence(i.id()), "feedback", interviews.feedback(i.id())));
        }
        return Map.of("applicationId", app.id(), "interviews", out);
    }

    private List<String> evidenceProblems(HrInterviewStore.Interview i, String override) {
        List<HrInterviewStore.Evidence> ev = interviews.evidence(i.id());
        List<String> problems = new ArrayList<>();
        if (ONLINE.equals(i.mode()) && ev.stream().filter(e -> e.kind().equals("SCREENSHOT")).count() < settings.minScreenshots()) {
            problems.add("SCREENSHOT_REQUIRED");
        }
        if (IN_OFFICE.equals(i.mode()) && settings.kioskMatchRequired()) {
            List<String> checkIds = ev.stream().filter(e -> e.kind().equals("KIOSK_PHOTO")).map(HrInterviewStore.Evidence::photoCheckId).toList();
            if (checkIds.isEmpty()) {
                problems.add("KIOSK_PHOTO_REQUIRED");
            } else {
                boolean mismatch = photos.checks(Caller.system("hr-round"), i.applicationId()).stream()
                        .filter(c -> checkIds.contains(c.id())).reduce((a, b) -> b).map(c -> c.decision() == PhotoDecision.MISMATCH)
                        .orElse(false);
                if (mismatch && override == null) {
                    problems.add("KIOSK_PHOTO_MISMATCH");
                }
            }
        }
        return problems;
    }

    private HrInterviewStore.Interview open(Caller caller, String interviewId) {
        HrInterviewStore.Interview i = interviews.find(interviewId).orElseThrow(() -> PlatformException.notFound("HR interview", interviewId));
        if (!"IN_PROGRESS".equals(i.status())) {
            throw PlatformException.conflict("INTERVIEW_CLOSED", "Interview is already " + i.status());
        }
        if (!caller.has(CONDUCT)) {
            throw PlatformException.forbidden("PERMISSION_DENIED", "Missing permission " + CONDUCT);
        }
        if (!caller.is(i.interviewerId()) && !caller.system()) {
            guard.require(caller, mover.load(i.applicationId()), CONDUCT);
        }
        return i;
    }
}
