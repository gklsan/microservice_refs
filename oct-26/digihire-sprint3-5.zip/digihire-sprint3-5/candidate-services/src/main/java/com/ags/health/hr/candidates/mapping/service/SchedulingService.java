package com.ags.health.hr.candidates.mapping.service;

import com.ags.health.hr.candidates.mapping.port.MeetingPort;
import com.ags.health.hr.candidates.mapping.store.InterviewSlotStore;
import com.ags.health.hr.candidates.mapping.store.MappingActionStore;
import com.ags.health.hr.candidates.shared.domain.StageCatalog;
import com.ags.health.hr.candidates.shared.domain.Statuses;
import com.ags.health.hr.candidates.shared.domain.Tab;
import com.ags.health.hr.candidates.shared.port.ApplicationView;
import com.ags.health.hr.candidates.shared.port.CandidatePort;
import com.ags.health.hr.candidates.shared.port.CandidateView;
import com.ags.health.hr.candidates.shared.service.ApplicantActionGuard;
import com.ags.health.hr.candidates.shared.service.Remarks;
import com.ags.health.hr.candidates.shared.service.StatusMover;
import com.ags.health.hr.common.platform.audit.AuditRecorder;
import com.ags.health.hr.common.platform.caller.Caller;
import com.ags.health.hr.common.platform.error.PlatformException;
import com.ags.health.hr.common.platform.notify.NotificationPort;
import com.ags.health.hr.common.platform.notify.NotificationRequest;
import com.ags.health.hr.common.platform.time.BusinessClock;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.transaction.annotation.Transactional;

import java.time.Duration;
import java.time.Instant;
import java.time.format.DateTimeFormatter;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

public class SchedulingService {

    public static final String SCHEDULE = "APPLICATION:SCHEDULE_INTERVIEW";
    public static final String MANAGE_SLOTS = "INTERVIEW_SLOT:MANAGE";
    public static final String WALK_IN = "WALK_IN";
    public static final String ONLINE = "ONLINE";

    private static final Logger log = LoggerFactory.getLogger(SchedulingService.class);
    private static final Set<Tab> SCHEDULABLE = Set.of(Tab.APPLICANT, Tab.PIPELINE, Tab.HR_INTERVIEW);
    private static final Set<String> MOVE_TO_HR_FROM = Set.of(Statuses.CREATED, Statuses.WALKEDIN, Statuses.PIPELINE);
    private static final DateTimeFormatter DATE = DateTimeFormatter.ofPattern("dd MMM yyyy");
    private static final DateTimeFormatter TIME = DateTimeFormatter.ofPattern("hh:mm a");

    public record SlotRequest(String mode, String lob, String location, String venue, Instant startsAt, Instant endsAt,
                              Integer capacity) {
    }

    public record ScheduleRequest(String slotId, Instant startsAt, Instant endsAt, String venue, String interviewerEmail,
                                  String remarks) {
    }

    public record Settings(String walkInTemplate, String onlineTemplate, String cancelTemplate, int maxDaysAhead,
                           boolean adHocWalkInAllowed, int maxSlotCapacity) {
    }

    private final InterviewSlotStore store;
    private final StatusMover mover;
    private final ApplicantActionGuard guard;
    private final CandidatePort candidates;
    private final MeetingPort meetings;
    private final MappingActionStore actions;
    private final StageCatalog catalog;
    private final AuditRecorder audit;
    private final NotificationPort notifications;
    private final BusinessClock clock;
    private final Settings settings;

    public SchedulingService(InterviewSlotStore store, StatusMover mover, ApplicantActionGuard guard, CandidatePort candidates,
                             MeetingPort meetings, MappingActionStore actions, StageCatalog catalog, AuditRecorder audit,
                             NotificationPort notifications, BusinessClock clock, Settings settings) {
        this.store = store;
        this.mover = mover;
        this.guard = guard;
        this.candidates = candidates;
        this.meetings = meetings;
        this.actions = actions;
        this.catalog = catalog;
        this.audit = audit;
        this.notifications = notifications;
        this.clock = clock;
        this.settings = settings;
    }

    @Transactional
    public InterviewSlotStore.Slot createSlot(Caller caller, SlotRequest req) {
        if (!caller.has(MANAGE_SLOTS)) {
            throw PlatformException.forbidden("PERMISSION_DENIED", "Missing permission " + MANAGE_SLOTS);
        }
        if (req == null) {
            throw PlatformException.badRequest("SLOT_INVALID", "Slot details are required");
        }
        String mode = mode(req.mode());
        window(req.startsAt(), req.endsAt(), true);
        int capacity = req.capacity() == null ? 1 : req.capacity();
        if (capacity < 1 || capacity > settings.maxSlotCapacity()) {
            throw PlatformException.badRequest("CAPACITY_INVALID", "Capacity must be between 1 and " + settings.maxSlotCapacity());
        }
        if (WALK_IN.equals(mode) && (blank(req.location()) || blank(req.venue()))) {
            throw PlatformException.badRequest("VENUE_REQUIRED", "Walk-in slots need a location and venue");
        }
        InterviewSlotStore.Slot slot = store.createSlot(mode, upper(req.lob()), upper(req.location()), text(req.venue(), 300),
                req.startsAt(), req.endsAt(), capacity, caller.userId(), clock.now());
        audit.record("ACTIVITY", "INTERVIEW_SLOT_CREATED", "INTERVIEW_SLOT", slot.id(), null,
                AuditRecorder.details("mode", mode, "lob", slot.lob(), "location", slot.location(), "startsAt", slot.startsAt(),
                        "capacity", capacity));
        return slot;
    }

    @Transactional(readOnly = true)
    public List<InterviewSlotStore.Slot> slots(Caller caller, String mode, String lob, String location, Instant from,
                                               Instant to, boolean availableOnly) {
        if (!caller.hasAny(SCHEDULE, MANAGE_SLOTS)) {
            throw PlatformException.forbidden("PERMISSION_DENIED", "Missing permission " + SCHEDULE);
        }
        Instant start = from == null ? clock.now() : from;
        Instant end = to == null ? start.plus(Duration.ofDays(14)) : to;
        if (end.isBefore(start) || Duration.between(start, end).toDays() > 92) {
            throw PlatformException.badRequest("RANGE_INVALID", "Range must be at most 92 days");
        }
        return store.slots(mode == null ? null : mode(mode), upper(lob), upper(location), start, end, availableOnly);
    }

    @Transactional
    public void deactivateSlot(Caller caller, String slotId) {
        if (!caller.has(MANAGE_SLOTS)) {
            throw PlatformException.forbidden("PERMISSION_DENIED", "Missing permission " + MANAGE_SLOTS);
        }
        InterviewSlotStore.Slot slot = store.findSlot(slotId).orElseThrow(() -> PlatformException.notFound("Interview slot", slotId));
        if (slot.booked() > 0) {
            throw PlatformException.conflict("SLOT_HAS_BOOKINGS", "Cancel or move the " + slot.booked() + " booking(s) first");
        }
        store.deactivate(slotId);
        audit.record("ACTIVITY", "INTERVIEW_SLOT_DEACTIVATED", "INTERVIEW_SLOT", slotId, null, Map.of());
    }

    @Transactional
    public InterviewSlotStore.Booking scheduleWalkIn(Caller caller, String applicationId, ScheduleRequest req) {
        ApplicationView app = schedulable(caller, applicationId);
        String remarks = Remarks.clean(req == null ? null : req.remarks(), false);
        Instant now = clock.now();
        InterviewSlotStore.Slot slot = null;
        Instant startsAt;
        Instant endsAt;
        String venue;
        if (req != null && !blank(req.slotId())) {
            slot = reserve(req.slotId(), WALK_IN);
            startsAt = slot.startsAt();
            endsAt = slot.endsAt();
            venue = slot.venue();
        } else {
            if (!settings.adHocWalkInAllowed()) {
                throw PlatformException.badRequest("SLOT_REQUIRED", "Choose a walk-in slot");
            }
            if (req == null || blank(req.venue())) {
                throw PlatformException.badRequest("VENUE_REQUIRED", "Venue is required for a walk-in");
            }
            window(req.startsAt(), req.endsAt() == null ? req.startsAt() == null ? null : req.startsAt().plus(Duration.ofHours(1))
                    : req.endsAt(), false);
            startsAt = req.startsAt();
            endsAt = req.endsAt();
            venue = text(req.venue(), 300);
        }
        cancelExisting(caller, app, "Rescheduled", now);
        InterviewSlotStore.Booking booking = store.book(slot == null ? null : slot.id(), app.id(), app.candidateId(), WALK_IN,
                startsAt, endsAt, venue, null, null, remarks, caller.userId(), now);
        Map<String, Object> ctx = context(app, booking);
        notify(settings.walkInTemplate(), app, booking, ctx);
        record(caller, app, booking, "WALK_IN_SCHEDULED", remarks, now);
        return booking;
    }

    @Transactional
    public InterviewSlotStore.Booking scheduleOnline(Caller caller, String applicationId, ScheduleRequest req) {
        ApplicationView app = schedulable(caller, applicationId);
        if (req == null) {
            throw PlatformException.badRequest("SCHEDULE_INVALID", "Schedule details are required");
        }
        String remarks = Remarks.clean(req.remarks(), false);
        Instant now = clock.now();
        InterviewSlotStore.Slot slot = null;
        Instant startsAt;
        Instant endsAt;
        if (!blank(req.slotId())) {
            slot = reserve(req.slotId(), ONLINE);
            startsAt = slot.startsAt();
            endsAt = slot.endsAt();
        } else {
            window(req.startsAt(), req.endsAt(), false);
            startsAt = req.startsAt();
            endsAt = req.endsAt();
        }
        CandidateView candidate = candidates.find(app.candidateId()).orElse(null);
        MeetingPort.Meeting meeting = meetings.create("Interview - " + (candidate == null ? app.candidateId() : candidate.fullName()),
                startsAt, endsAt, caller.email(), candidate == null || candidate.email() == null ? List.of()
                        : req.interviewerEmail() == null ? List.of(candidate.email()) : List.of(candidate.email(), req.interviewerEmail()));
        try {
            cancelExisting(caller, app, "Rescheduled", now);
            InterviewSlotStore.Booking booking = store.book(slot == null ? null : slot.id(), app.id(), app.candidateId(), ONLINE,
                    startsAt, endsAt, null, meeting.externalId(), meeting.joinUrl(), remarks, caller.userId(), now);
            if (MOVE_TO_HR_FROM.contains(app.status())) {
                mover.move(caller, app, StatusMover.Move.to(app.id(), Statuses.WAITING_FOR_HRROUND, SCHEDULE)
                        .reason("ONLINE_INTERVIEW_SCHEDULED", remarks).with("bookingId", booking.id()));
            }
            Map<String, Object> ctx = context(app, booking);
            ctx.put("joinUrl", meeting.joinUrl());
            notify(settings.onlineTemplate(), app, booking, ctx);
            record(caller, app, booking, "ONLINE_INTERVIEW_SCHEDULED", remarks, now);
            return booking;
        } catch (RuntimeException e) {
            try {
                meetings.cancel(meeting.externalId());
            } catch (RuntimeException ignored) {
                log.warn("Could not cancel meeting {} after a failed booking", meeting.externalId());
            }
            throw e;
        }
    }

    @Transactional
    public void cancel(Caller caller, String bookingId, String remarks) {
        InterviewSlotStore.Booking b = store.findBooking(bookingId).orElseThrow(() -> PlatformException.notFound("Booking", bookingId));
        ApplicationView app = mover.load(b.applicationId());
        guard.require(caller, app, SCHEDULE);
        String r = Remarks.clean(remarks, true);
        Instant now = clock.now();
        if (!cancelOne(b, caller.userId(), r, now)) {
            throw PlatformException.conflict("BOOKING_NOT_ACTIVE", "Booking is already " + b.status());
        }
        if (settings.cancelTemplate() != null) {
            notify(settings.cancelTemplate(), app, b, context(app, b));
        }
        record(caller, app, b, "INTERVIEW_CANCELLED", r, now);
    }

    @Transactional(readOnly = true)
    public List<InterviewSlotStore.Booking> bookings(Caller caller, String applicationId) {
        ApplicationView app = mover.load(applicationId);
        guard.require(caller, app, SCHEDULE);
        return store.bookings(app.id());
    }

    private ApplicationView schedulable(Caller caller, String applicationId) {
        ApplicationView app = mover.load(applicationId);
        guard.require(caller, app, SCHEDULE);
        if (!catalog.isOpen(app.status()) || !SCHEDULABLE.contains(catalog.tabOf(app.status()))) {
            throw PlatformException.conflict("NOT_SCHEDULABLE", "Interviews can not be scheduled at " + app.status());
        }
        return app;
    }

    private InterviewSlotStore.Slot reserve(String slotId, String mode) {
        InterviewSlotStore.Slot slot = store.findSlot(slotId).orElseThrow(() -> PlatformException.notFound("Interview slot", slotId));
        if (!slot.mode().equals(mode)) {
            throw PlatformException.badRequest("SLOT_MODE_MISMATCH", "Slot is for " + slot.mode() + " interviews");
        }
        if (slot.startsAt().isBefore(clock.now())) {
            throw PlatformException.conflict("SLOT_IN_PAST", "Slot has already started");
        }
        if (!store.reserve(slotId)) {
            throw PlatformException.conflict("SLOT_FULL", "Slot is full or no longer active");
        }
        return slot;
    }

    private void cancelExisting(Caller caller, ApplicationView app, String reason, Instant now) {
        for (InterviewSlotStore.Booking b : store.activeBookings(app.id())) {
            cancelOne(b, caller.userId(), reason, now);
        }
    }

    private boolean cancelOne(InterviewSlotStore.Booking b, String actor, String reason, Instant now) {
        boolean cancelled = store.cancel(b.id(), "CANCELLED", actor, reason, now);
        if (cancelled && b.slotId() != null) {
            store.release(b.slotId());
        }
        if (cancelled && b.meetingId() != null) {
            try {
                meetings.cancel(b.meetingId());
            } catch (RuntimeException e) {
                log.warn("Could not cancel meeting {}: {}", b.meetingId(), e.getMessage());
            }
        }
        return cancelled;
    }

    private void window(Instant startsAt, Instant endsAt, boolean slot) {
        if (startsAt == null || endsAt == null) {
            throw PlatformException.badRequest("TIME_REQUIRED", "Start and end time are required");
        }
        Instant now = clock.now();
        if (!startsAt.isAfter(now)) {
            throw PlatformException.badRequest("TIME_IN_PAST", "Start time must be in the future");
        }
        if (startsAt.isAfter(now.plus(Duration.ofDays(settings.maxDaysAhead())))) {
            throw PlatformException.badRequest("TIME_TOO_FAR", "Start time must be within " + settings.maxDaysAhead() + " days");
        }
        if (!endsAt.isAfter(startsAt) || Duration.between(startsAt, endsAt).toHours() > (slot ? 12 : 8)) {
            throw PlatformException.badRequest("DURATION_INVALID", "End must be after start and within " + (slot ? 12 : 8) + " hours");
        }
    }

    private Map<String, Object> context(ApplicationView app, InterviewSlotStore.Booking b) {
        Map<String, Object> ctx = new LinkedHashMap<>();
        ctx.put("bookingId", b.id());
        ctx.put("mode", b.mode());
        ctx.put("date", DATE.format(clock.zoned(b.startsAt())));
        ctx.put("time", TIME.format(clock.zoned(b.startsAt())));
        ctx.put("startsAt", b.startsAt().toString());
        ctx.put("venue", b.venue());
        ctx.put("requisitionId", app.requisitionId());
        return ctx;
    }

    private void notify(String template, ApplicationView app, InterviewSlotStore.Booking b, Map<String, Object> ctx) {
        if (template == null) {
            return;
        }
        try {
            notifications.trigger(new NotificationRequest(template, app.id(), app.candidateId(), template + ":" + b.id(), ctx));
        } catch (RuntimeException e) {
            log.warn("Notification {} for booking {} failed: {}", template, b.id(), e.getMessage());
            audit.recordQuietly("NOTIFICATION", "NOTIFICATION_TRIGGER_FAILED", "APPLICATION", app.id(), app.candidateId(),
                    AuditRecorder.FAILURE, e.getMessage(), AuditRecorder.details("eventType", template, "bookingId", b.id()));
        }
    }

    private void record(Caller caller, ApplicationView app, InterviewSlotStore.Booking b, String action, String remarks, Instant now) {
        actions.append(app.candidateId(), app.id(), app.requisitionId(), action, null, "DONE", null, null, remarks,
                caller.userId(), caller.displayName(), now, Map.of("bookingId", b.id(), "mode", b.mode(),
                        "startsAt", b.startsAt().toString()));
        audit.record("ACTIVITY", action, "APPLICATION", app.id(), app.candidateId(), AuditRecorder.SUCCESS, remarks,
                AuditRecorder.details("bookingId", b.id(), "mode", b.mode(), "slotId", b.slotId(), "startsAt", b.startsAt(),
                        "venue", b.venue()));
    }

    private static String mode(String raw) {
        String m = raw == null ? "" : raw.trim().toUpperCase(Locale.ROOT).replace('-', '_');
        if ("WALKIN".equals(m)) {
            m = WALK_IN;
        }
        if (!WALK_IN.equals(m) && !ONLINE.equals(m)) {
            throw PlatformException.badRequest("MODE_INVALID", "Mode must be WALK_IN or ONLINE");
        }
        return m;
    }

    private static String upper(String v) {
        return blank(v) ? null : v.trim().toUpperCase(Locale.ROOT);
    }

    private static String text(String v, int max) {
        if (blank(v)) {
            return null;
        }
        String t = v.strip();
        if (t.length() > max) {
            throw PlatformException.badRequest("TEXT_TOO_LONG", "Text must be at most " + max + " characters");
        }
        return t;
    }

    private static boolean blank(String v) {
        return v == null || v.isBlank();
    }
}
