package com.ags.health.hr.candidates.assessmentbridge;

import com.ags.health.hr.common.platform.caller.InternalKeyVerifier;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@ConditionalOnProperty(prefix = "digihire.candidate.assessment", name = "enabled", havingValue = "true", matchIfMissing = true)
@RestController
public class AssessmentInboxController {

    private final AssessmentEventInbox inbox;
    private final InternalKeyVerifier keys;

    public AssessmentInboxController(AssessmentEventInbox inbox, InternalKeyVerifier keys) {
        this.inbox = inbox;
        this.keys = keys;
    }

    @PostMapping("/internal/assessment-events")
    public AssessmentEventInbox.Summary receive(HttpServletRequest request, @RequestBody List<AssessmentEvent> events) {
        keys.require(request);
        return inbox.accept(events);
    }

    @PostMapping("/internal/integration-events")
    public AssessmentEventInbox.Summary receiveIntegration(HttpServletRequest request, @RequestBody List<AssessmentEvent> events) {
        keys.require(request);
        return inbox.accept(events);
    }
}
