package com.ags.health.hr.candidates.shared.service;

import com.ags.health.hr.candidates.shared.domain.StageCatalog;
import com.ags.health.hr.candidates.shared.domain.Tab;
import com.ags.health.hr.candidates.shared.domain.TabMovementPolicy;
import com.ags.health.hr.candidates.shared.port.ApplicationPort;
import com.ags.health.hr.candidates.shared.port.ApplicationView;
import com.ags.health.hr.candidates.shared.port.StatusChange;
import com.ags.health.hr.common.platform.audit.AuditRecorder;
import com.ags.health.hr.common.platform.caller.Caller;
import com.ags.health.hr.common.platform.error.PlatformException;
import com.ags.health.hr.common.platform.notify.NotificationPort;
import com.ags.health.hr.common.platform.notify.NotificationRequest;
import com.ags.health.hr.common.platform.workflow.WorkflowDecision;
import com.ags.health.hr.common.platform.workflow.WorkflowPort;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.time.Clock;
import java.time.Instant;
import java.util.Collections;
import java.util.Set;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public class StatusMover {

    public static final String ENTITY = "APPLICATION";
    public static final String CATEGORY = "WORKFLOW_TRANSITION";

    private static final Logger log = LoggerFactory.getLogger(StatusMover.class);

    public record Move(String applicationId, String toStatus, String permission, String reasonCode, String remarks,
                       boolean remarksRequired, String notificationEvent, boolean reset, Map<String, Object> context) {

        public Move {
            context = context == null ? Map.of() : Collections.unmodifiableMap(new LinkedHashMap<>(context));
        }

        public static Move to(String applicationId, String toStatus, String permission) {
            return new Move(applicationId, toStatus, permission, null, null, false, null, false, Map.of());
        }

        public Move reason(String code, String text) {
            return new Move(applicationId, toStatus, permission, code, text, remarksRequired, notificationEvent, reset, context);
        }

        public Move requireRemarks() {
            return new Move(applicationId, toStatus, permission, reasonCode, remarks, true, notificationEvent, reset, context);
        }

        public Move notify(String eventType) {
            return new Move(applicationId, toStatus, permission, reasonCode, remarks, remarksRequired, eventType, reset, context);
        }

        public Move asReset() {
            return new Move(applicationId, toStatus, permission, reasonCode, remarks, remarksRequired, notificationEvent, true, context);
        }

        public Move with(String key, Object value) {
            Map<String, Object> c = new LinkedHashMap<>(context);
            if (value != null) {
                c.put(key, value);
            }
            return new Move(applicationId, toStatus, permission, reasonCode, remarks, remarksRequired, notificationEvent, reset, c);
        }
    }

    public record Result(ApplicationView before, String fromStatus, String toStatus, Tab fromTab, Tab toTab,
                         ApplicantActionGuard.Basis basis, Instant at) {
    }

    private final ApplicationPort applications;
    private final ApplicantActionGuard guard;
    private final WorkflowPort workflow;
    private final TabMovementPolicy policy;
    private final StageCatalog catalog;
    private final AuditRecorder audit;
    private final NotificationPort notifications;
    private final List<StatusMoveListener> listeners;
    private final Clock clock;
    private final Set<String> resetReasons;
    private final List<MoveGuard> moveGuards;

    public StatusMover(ApplicationPort applications, ApplicantActionGuard guard, WorkflowPort workflow,
                       TabMovementPolicy policy, StageCatalog catalog, AuditRecorder audit, NotificationPort notifications,
                       List<StatusMoveListener> listeners, Clock clock, Set<String> resetReasons, List<MoveGuard> moveGuards) {
        this.applications = applications;
        this.guard = guard;
        this.workflow = workflow;
        this.policy = policy;
        this.catalog = catalog;
        this.audit = audit;
        this.notifications = notifications;
        this.listeners = listeners == null ? List.of() : List.copyOf(listeners);
        this.clock = clock;
        this.resetReasons = resetReasons == null ? Set.of() : Set.copyOf(resetReasons);
        this.moveGuards = moveGuards == null ? List.of() : List.copyOf(moveGuards);
    }

    public ApplicationView load(String applicationId) {
        return applications.find(applicationId).orElseThrow(() -> PlatformException.notFound("Application", applicationId));
    }

    public WorkflowDecision preview(Caller caller, String applicationId, String toStatus, String permission) {
        ApplicationView app = load(applicationId);
        guard.require(caller, app, permission);
        return decide(app, norm(toStatus), Map.of());
    }

    public Result move(Caller caller, Move move) {
        return move(caller, load(move.applicationId()), move);
    }

    public Result move(Caller caller, ApplicationView app, Move move) {
        String to = norm(move.toStatus());
        if (!catalog.known(to)) {
            throw PlatformException.badRequest("UNKNOWN_STATUS", "Unknown target status " + move.toStatus());
        }
        String remarks = Remarks.clean(move.remarks(), move.remarksRequired());
        ApplicantActionGuard.Basis basis;
        try {
            basis = guard.require(caller, app, move.permission());
        } catch (PlatformException e) {
            audit.recordQuietly(CATEGORY, "STATUS_CHANGE_DENIED", ENTITY, app.id(), app.candidateId(), AuditRecorder.DENIED,
                    e.getMessage(), AuditRecorder.details("from", app.status(), "to", to, "code", e.getCode()));
            throw e;
        }
        String from = app.status();
        Map<String, Object> ctx = new LinkedHashMap<>(move.context());
        ctx.put("reasonCode", move.reasonCode());
        ctx.put("actorId", caller.userId());
        if (move.reset() && (move.reasonCode() == null || !resetReasons.contains(move.reasonCode()))) {
            throw PlatformException.badRequest("RESET_NOT_ALLOWED", "Reason " + move.reasonCode() + " can not reset a stage");
        }
        if (from != null && from.equalsIgnoreCase(to)) {
            throw PlatformException.conflict("ALREADY_IN_STATUS", "Application is already " + to);
        }
        WorkflowDecision decision = move.reset() ? WorkflowDecision.allow(from, to) : decide(app, to, ctx);
        if (!decision.allowed()) {
            audit.recordQuietly(CATEGORY, "STATUS_CHANGE_BLOCKED", ENTITY, app.id(), app.candidateId(), AuditRecorder.DENIED,
                    decision.message(), AuditRecorder.details("from", from, "to", to, "code", decision.code(),
                            "allowedTargets", decision.allowedTargets()));
            throw new PlatformException(409, decision.code() == null ? "TRANSITION_NOT_ALLOWED" : decision.code(),
                    decision.message() == null ? "Moving from " + from + " to " + to + " is not allowed" : decision.message(),
                    List.of(Map.of("from", String.valueOf(from), "to", to, "allowedTargets", decision.allowedTargets())));
        }
        if (!move.reset()) {
            for (MoveGuard g : moveGuards) {
                try {
                    g.check(caller, app, to, move);
                } catch (PlatformException e) {
                    audit.recordQuietly(CATEGORY, "STATUS_CHANGE_BLOCKED", ENTITY, app.id(), app.candidateId(), AuditRecorder.DENIED,
                            e.getMessage(), AuditRecorder.details("from", from, "to", to, "code", e.getCode()));
                    throw e;
                }
            }
        }
        Instant at = clock.instant();
        applications.changeStatus(app.id(), to, new StatusChange(caller.userId(), caller.displayName(), move.reasonCode(),
                remarks, caller.system()));
        Tab fromTab = catalog.tabOf(from);
        Tab toTab = catalog.tabOf(to);
        if (workflow != null) {
            try {
                workflow.moved(ENTITY, app.id(), from, to, ctx);
            } catch (RuntimeException e) {
                log.warn("Workflow history for {} {}->{} not recorded: {}", app.id(), from, to, e.getMessage());
            }
        }
        audit.record(CATEGORY, move.reset() ? "STATUS_RESET" : "STATUS_CHANGED", ENTITY, app.id(), app.candidateId(), AuditRecorder.SUCCESS, remarks,
                AuditRecorder.details("from", from, "to", to, "fromTab", fromTab, "toTab", toTab, "reasonCode",
                        move.reasonCode(), "basis", basis, "requisitionId", app.requisitionId(), "context", move.context()));
        if (move.notificationEvent() != null && notifications != null) {
            Map<String, Object> nctx = new LinkedHashMap<>(move.context());
            nctx.put("fromStatus", from);
            nctx.put("toStatus", to);
            nctx.put("reasonCode", move.reasonCode());
            nctx.put("requisitionId", app.requisitionId());
            try {
                notifications.trigger(new NotificationRequest(move.notificationEvent(), app.id(), app.candidateId(),
                        move.notificationEvent() + ":" + app.id() + ":" + to + ":" + at.toEpochMilli(), nctx));
            } catch (RuntimeException e) {
                log.warn("Notification {} for {} failed: {}", move.notificationEvent(), app.id(), e.getMessage());
                audit.recordQuietly("NOTIFICATION", "NOTIFICATION_TRIGGER_FAILED", ENTITY, app.id(), app.candidateId(),
                        AuditRecorder.FAILURE, e.getMessage(), AuditRecorder.details("eventType", move.notificationEvent()));
            }
        }
        StatusMovedEvent event = new StatusMovedEvent(app, from, to, fromTab, toTab, move.reasonCode(), remarks,
                caller.userId(), caller.system(), at, move.context());
        for (StatusMoveListener l : listeners) {
            l.onMoved(event);
        }
        return new Result(app, from, to, fromTab, toTab, basis, at);
    }

    public void announce(Caller caller, ApplicationView app, String from, String to, String reasonCode, String remarks,
                         Map<String, Object> context) {
        StatusMovedEvent event = new StatusMovedEvent(app, from, to, from == null ? null : catalog.tabOf(from),
                catalog.tabOf(to), reasonCode, remarks, caller.userId(), caller.system(), clock.instant(), context);
        for (StatusMoveListener l : listeners) {
            l.onMoved(event);
        }
    }

    public List<String> targets(ApplicationView app) {
        return policy.targets(app.status());
    }

    private WorkflowDecision decide(ApplicationView app, String to, Map<String, Object> ctx) {
        String from = app.status();
        if (workflow != null) {
            return workflow.check(ENTITY, app.id(), from, to, ctx);
        }
        return policy.allows(from, to) ? WorkflowDecision.allow(from, to)
                : WorkflowDecision.deny("TRANSITION_NOT_ALLOWED", "Moving from " + from + " to " + to + " is not allowed",
                from, to, policy.targets(from));
    }

    private static String norm(String status) {
        if (status == null || status.isBlank()) {
            throw PlatformException.badRequest("STATUS_REQUIRED", "Target status is required");
        }
        return status.trim().toUpperCase(Locale.ROOT);
    }
}
