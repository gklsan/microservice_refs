package com.ags.health.hr.candidates.assessmentbridge;

import com.fasterxml.jackson.databind.JsonNode;

import java.time.Instant;
import java.util.UUID;

public record AssessmentEvent(long seq, UUID id, String eventType, String aggregateType, String aggregateId,
                              String candidateId, String applicationId, JsonNode payload, Instant createdAt,
                              String correlationId, int attempts) {

    public String text(String field) {
        if (payload == null || payload.get(field) == null || payload.get(field).isNull()) {
            return null;
        }
        return payload.get(field).asText();
    }

    public String provider() {
        String p = text("provider");
        return p == null ? null : p.trim().toUpperCase();
    }
}
