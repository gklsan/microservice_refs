package com.ags.health.hr.candidates.photo.service;

import com.ags.health.hr.candidates.photo.domain.PhotoCheck;
import com.ags.health.hr.candidates.photo.domain.PhotoDecision;
import com.ags.health.hr.candidates.photo.domain.PhotoRules;
import com.ags.health.hr.candidates.photo.port.FaceMatchPort;
import com.ags.health.hr.candidates.photo.port.ProfilePhotoPort;
import com.ags.health.hr.candidates.photo.store.PhotoCheckStore;
import com.ags.health.hr.candidates.shared.domain.StageCatalog;
import com.ags.health.hr.candidates.shared.port.ApplicationView;
import com.ags.health.hr.candidates.shared.service.Remarks;
import com.ags.health.hr.candidates.shared.service.StatusMover;
import com.ags.health.hr.common.platform.audit.AuditRecorder;
import com.ags.health.hr.common.platform.caller.Caller;
import com.ags.health.hr.common.platform.error.PlatformException;
import org.springframework.transaction.annotation.Transactional;

import java.time.Clock;
import java.time.Instant;
import java.util.List;
import java.util.Locale;
import java.util.UUID;

public class PhotoVerificationService {

    public static final String VERIFY = "CANDIDATE_PHOTO:VERIFY";
    public static final String REVIEW = "AUDIT_LOG:VIEW";
    public static final String OPEN = "OPEN";
    public static final String NOT_FLAGGED = "NOT_FLAGGED";

    private final PhotoCheckStore store;
    private final PhotoRules rules;
    private final FaceMatchPort faces;
    private final ProfilePhotoPort photos;
    private final StatusMover mover;
    private final StageCatalog catalog;
    private final AuditRecorder audit;
    private final Clock clock;

    public PhotoVerificationService(PhotoCheckStore store, PhotoRules rules, FaceMatchPort faces, ProfilePhotoPort photos,
                                    StatusMover mover, StageCatalog catalog, AuditRecorder audit, Clock clock) {
        this.store = store;
        this.rules = rules;
        this.faces = faces;
        this.photos = photos;
        this.mover = mover;
        this.catalog = catalog;
        this.audit = audit;
        this.clock = clock;
    }

    public void validatePhoto(byte[] image, String fileName) {
        rules.validate(image, fileName);
    }

    @Transactional
    public PhotoCheck manual(Caller caller, String applicationId, String decision, String remarks) {
        if (!caller.has(VERIFY)) {
            throw PlatformException.forbidden("PERMISSION_DENIED", "Missing permission " + VERIFY);
        }
        ApplicationView app = mover.load(applicationId);
        PhotoDecision d = parse(decision);
        String text = Remarks.clean(remarks, d != PhotoDecision.MATCH);
        return record(caller, app, catalog.tabOf(app.status()).name(), "MANUAL", d, null, text);
    }

    @Transactional
    public PhotoCheck automatic(Caller caller, ApplicationView app, String stage, byte[] probe) {
        byte[] reference = photos.referencePhoto(app.candidateId())
                .orElseThrow(() -> PlatformException.conflict("REFERENCE_PHOTO_MISSING", "Candidate has no profile photo to compare with"));
        FaceMatchPort.Result r = faces.match(probe, reference);
        return record(caller, app, stage, "AUTO:" + (r.provider() == null ? "UNKNOWN" : r.provider()), rules.decide(r.score()), r.score(), null);
    }

    @Transactional(readOnly = true)
    public List<PhotoCheck> checks(Caller caller, String applicationId) {
        if (!caller.hasAny(VERIFY, REVIEW)) {
            throw PlatformException.forbidden("PERMISSION_DENIED", "Missing permission " + VERIFY);
        }
        return store.forApplication(applicationId);
    }

    @Transactional(readOnly = true)
    public List<PhotoCheck> reviewQueue(Caller caller, String status, int limit) {
        if (!caller.has(REVIEW)) {
            throw PlatformException.forbidden("PERMISSION_DENIED", "Missing permission " + REVIEW);
        }
        return store.flagged(status == null ? OPEN : status.trim().toUpperCase(Locale.ROOT), limit);
    }

    @Transactional
    public PhotoCheck review(Caller caller, String checkId, String outcome, String remarks) {
        if (!caller.has(REVIEW)) {
            throw PlatformException.forbidden("PERMISSION_DENIED", "Missing permission " + REVIEW);
        }
        String o = outcome == null ? "" : outcome.trim().toUpperCase(Locale.ROOT);
        if (!o.equals("CLEARED") && !o.equals("CONFIRMED_MISMATCH")) {
            throw PlatformException.badRequest("REVIEW_OUTCOME_INVALID", "Outcome must be CLEARED or CONFIRMED_MISMATCH");
        }
        String text = Remarks.clean(remarks, true);
        PhotoCheck c = store.find(checkId).orElseThrow(() -> PlatformException.notFound("Photo check", checkId));
        if (!store.review(checkId, o, caller.userId(), text, clock.instant())) {
            throw PlatformException.conflict("REVIEW_NOT_OPEN", "Photo check is not waiting for review");
        }
        audit.record("SECURITY", "PHOTO_MISMATCH_REVIEWED", "APPLICATION", c.applicationId(), c.candidateId(), AuditRecorder.SUCCESS,
                text, AuditRecorder.details("checkId", checkId, "outcome", o));
        return store.find(checkId).orElseThrow();
    }

    public PhotoCheck flagRejection(Caller caller, ApplicationView app, String stage, String remarks) {
        return record(caller, app, stage, "REJECTION", PhotoDecision.MISMATCH, null, remarks);
    }

    private PhotoCheck record(Caller caller, ApplicationView app, String stage, String method, PhotoDecision d, Double score,
                              String remarks) {
        boolean flagged = d == PhotoDecision.MISMATCH;
        Instant now = clock.instant();
        PhotoCheck c = new PhotoCheck(UUID.randomUUID().toString(), app.id(), app.candidateId(), stage, method, d, score,
                caller.userId(), remarks, flagged, flagged ? OPEN : NOT_FLAGGED, null, null, null, now);
        store.insert(c);
        audit.record(flagged ? "SECURITY" : "ACTIVITY", flagged ? "PHOTO_MISMATCH_FLAGGED" : "PHOTO_VERIFIED", "APPLICATION",
                app.id(), app.candidateId(), flagged ? AuditRecorder.FAILURE : AuditRecorder.SUCCESS, remarks,
                AuditRecorder.details("checkId", c.id(), "stage", stage, "method", method, "decision", d, "score", score));
        return c;
    }

    private static PhotoDecision parse(String decision) {
        try {
            return PhotoDecision.valueOf(decision == null ? "" : decision.trim().toUpperCase(Locale.ROOT));
        } catch (IllegalArgumentException e) {
            throw PlatformException.badRequest("DECISION_INVALID", "Decision must be MATCH, UNSURE or MISMATCH");
        }
    }
}
