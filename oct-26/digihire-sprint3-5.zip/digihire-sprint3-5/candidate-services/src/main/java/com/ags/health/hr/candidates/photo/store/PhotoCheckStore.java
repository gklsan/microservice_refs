package com.ags.health.hr.candidates.photo.store;

import com.ags.health.hr.candidates.photo.domain.PhotoCheck;
import com.ags.health.hr.candidates.photo.domain.PhotoDecision;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

import java.sql.Timestamp;
import java.time.Instant;
import java.util.List;
import java.util.Optional;

public class PhotoCheckStore {

    private static final String COLUMNS = "id, application_id, candidate_id, stage, method, decision, score, checked_by, remarks, "
            + "flagged, review_status, reviewed_by, review_remarks, reviewed_at, created_at";
    private static final RowMapper<PhotoCheck> ROW = (rs, i) -> new PhotoCheck(rs.getString(1), rs.getString(2), rs.getString(3),
            rs.getString(4), rs.getString(5), PhotoDecision.valueOf(rs.getString(6)), rs.getObject(7) == null ? null : rs.getDouble(7),
            rs.getString(8), rs.getString(9), rs.getBoolean(10), rs.getString(11), rs.getString(12), rs.getString(13),
            rs.getTimestamp(14) == null ? null : rs.getTimestamp(14).toInstant(), rs.getTimestamp(15).toInstant());

    private final JdbcTemplate jdbc;

    public PhotoCheckStore(JdbcTemplate jdbc) {
        this.jdbc = jdbc;
    }

    public void insert(PhotoCheck c) {
        jdbc.update("INSERT INTO cand_photo_check (" + COLUMNS + ") VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
                c.id(), c.applicationId(), c.candidateId(), c.stage(), c.method(), c.decision().name(), c.score(), c.checkedBy(),
                c.remarks(), c.flagged(), c.reviewStatus(), c.reviewedBy(), c.reviewRemarks(),
                c.reviewedAt() == null ? null : Timestamp.from(c.reviewedAt()), Timestamp.from(c.createdAt()));
    }

    public Optional<PhotoCheck> find(String id) {
        return jdbc.query("SELECT " + COLUMNS + " FROM cand_photo_check WHERE id = ?", ROW, id).stream().findFirst();
    }

    public List<PhotoCheck> forApplication(String applicationId) {
        return jdbc.query("SELECT " + COLUMNS + " FROM cand_photo_check WHERE application_id = ? ORDER BY created_at DESC", ROW, applicationId);
    }

    public List<PhotoCheck> flagged(String reviewStatus, int limit) {
        return jdbc.query("SELECT " + COLUMNS + " FROM cand_photo_check WHERE flagged = TRUE AND review_status = ? "
                + "ORDER BY created_at LIMIT ?", ROW, reviewStatus, Math.max(1, Math.min(limit, 500)));
    }

    public boolean review(String id, String status, String reviewer, String remarks, Instant at) {
        return jdbc.update("UPDATE cand_photo_check SET review_status = ?, reviewed_by = ?, review_remarks = ?, reviewed_at = ? "
                + "WHERE id = ? AND flagged = TRUE AND review_status = 'OPEN'", status, reviewer, remarks, Timestamp.from(at), id) == 1;
    }
}
