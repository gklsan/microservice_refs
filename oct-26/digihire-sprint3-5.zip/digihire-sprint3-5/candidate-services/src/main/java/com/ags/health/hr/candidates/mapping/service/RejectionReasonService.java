package com.ags.health.hr.candidates.mapping.service;

import com.ags.health.hr.candidates.mapping.domain.RejectionReason;
import com.ags.health.hr.candidates.mapping.store.RejectionReasonStore;
import com.ags.health.hr.common.platform.audit.AuditRecorder;
import com.ags.health.hr.common.platform.caller.Caller;
import com.ags.health.hr.common.platform.error.PlatformException;
import org.springframework.transaction.annotation.Transactional;

import java.time.Clock;
import java.util.List;
import java.util.Locale;
import java.util.Set;

public class RejectionReasonService {

    public static final String MANAGE = "REJECTION_REASON:MANAGE";
    private static final Set<String> STAGES = Set.of("ANY", "MAP_CANDIDATE", "APPLICANT", "HR_INTERVIEW", "ASSESSMENT",
            "VERSANT", "PANEL", "PIPELINE", "OFFER");

    private final RejectionReasonStore store;
    private final AuditRecorder audit;
    private final Clock clock;

    public RejectionReasonService(RejectionReasonStore store, AuditRecorder audit, Clock clock) {
        this.store = store;
        this.audit = audit;
        this.clock = clock;
    }

    @Transactional(readOnly = true)
    public List<RejectionReason> list(String stage, boolean includeInactive) {
        return store.list(!includeInactive).stream().filter(r -> stage == null || r.appliesTo(stage)).toList();
    }

    @Transactional(readOnly = true)
    public RejectionReason require(String code, String stage) {
        if (code == null || code.isBlank()) {
            throw PlatformException.badRequest("REJECTION_REASON_REQUIRED", "A standard rejection reason is required");
        }
        RejectionReason r = store.find(code.trim().toUpperCase(Locale.ROOT))
                .filter(RejectionReason::active)
                .orElseThrow(() -> PlatformException.badRequest("REJECTION_REASON_INVALID", "Unknown or inactive rejection reason " + code));
        if (!r.appliesTo(stage)) {
            throw PlatformException.badRequest("REJECTION_REASON_NOT_FOR_STAGE", "Reason " + r.code() + " can not be used at " + stage);
        }
        return r;
    }

    @Transactional
    public RejectionReason upsert(Caller caller, RejectionReason r) {
        if (!caller.has(MANAGE)) {
            throw PlatformException.forbidden("PERMISSION_DENIED", "Missing permission " + MANAGE);
        }
        if (r == null || r.code() == null || !r.code().matches("[A-Za-z0-9_]{2,40}") || r.label() == null
                || r.label().isBlank() || r.label().length() > 150) {
            throw PlatformException.badRequest("REJECTION_REASON_INVALID", "Code (2-40 letters, digits, _) and label (max 150) are required");
        }
        String stage = r.stage() == null ? "ANY" : r.stage().trim().toUpperCase(Locale.ROOT);
        if (!STAGES.contains(stage)) {
            throw PlatformException.badRequest("STAGE_INVALID", "Stage must be one of " + STAGES);
        }
        if (r.templateCode() != null && !r.templateCode().matches("[A-Z0-9_]{2,60}")) {
            throw PlatformException.badRequest("TEMPLATE_INVALID", "Template code must be upper case letters, digits and _");
        }
        RejectionReason clean = new RejectionReason(r.code().toUpperCase(Locale.ROOT), r.label().strip(), stage, r.templateCode(),
                r.remarksRequired(), r.active(), r.sortOrder());
        store.upsert(clean, caller.userId(), clock.instant());
        audit.record("CONFIGURATION", "REJECTION_REASON_SAVED", "REJECTION_REASON", clean.code(), null,
                AuditRecorder.details("label", clean.label(), "stage", stage, "template", clean.templateCode(), "active", clean.active()));
        return clean;
    }
}
