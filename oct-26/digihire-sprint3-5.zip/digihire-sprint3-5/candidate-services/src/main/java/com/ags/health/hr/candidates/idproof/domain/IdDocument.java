package com.ags.health.hr.candidates.idproof.domain;

import java.time.Instant;

public record IdDocument(String id, String candidateId, IdDocumentType type, String numberHash, String numberMasked,
                         String storageKey, String contentType, long size, String sha256, VerificationStatus status,
                         String provider, String verificationRef, String verificationNote, Instant verifiedAt,
                         String uploadedBy, Instant uploadedAt, Instant updatedAt) {
}
