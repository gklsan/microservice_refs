package com.ags.health.hr.candidates.mapping;

import com.ags.health.hr.candidates.mapping.domain.MappingScenarioResolver;
import com.ags.health.hr.candidates.mapping.domain.RemapPlanner;
import com.ags.health.hr.candidates.mapping.port.LinkOnlyMeetingPort;
import com.ags.health.hr.candidates.mapping.port.MappingGuardPort;
import com.ags.health.hr.candidates.mapping.port.MeetingPort;
import com.ags.health.hr.candidates.mapping.port.RegistrationCheck;
import com.ags.health.hr.candidates.mapping.service.ApplicantActionService;
import com.ags.health.hr.candidates.mapping.service.MappingService;
import com.ags.health.hr.candidates.mapping.service.RejectionReasonService;
import com.ags.health.hr.candidates.mapping.service.SchedulingService;
import com.ags.health.hr.candidates.mapping.store.InterviewSlotStore;
import com.ags.health.hr.candidates.mapping.store.MappingActionStore;
import com.ags.health.hr.candidates.mapping.store.RejectionReasonStore;
import com.ags.health.hr.candidates.shared.config.CandidateP5Properties;
import com.ags.health.hr.candidates.shared.domain.StageCatalog;
import com.ags.health.hr.candidates.shared.port.ApplicationPort;
import com.ags.health.hr.candidates.shared.port.CandidatePort;
import com.ags.health.hr.candidates.shared.port.RequisitionPort;
import com.ags.health.hr.candidates.shared.service.ApplicantActionGuard;
import com.ags.health.hr.candidates.shared.service.StatusMover;
import com.ags.health.hr.common.platform.assessment.AssessmentPort;
import com.ags.health.hr.common.platform.audit.AuditRecorder;
import com.ags.health.hr.common.platform.notify.NotificationPort;
import com.ags.health.hr.common.platform.time.BusinessClock;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.ObjectProvider;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.core.JdbcTemplate;

import java.time.Clock;
import java.util.Locale;

@Configuration
@ConditionalOnProperty(prefix = "digihire.candidate.mapping", name = "enabled", havingValue = "true", matchIfMissing = true)
public class MappingConfig {

    @Bean
    public MappingActionStore p5MappingActionStore(JdbcTemplate jdbc, ObjectMapper mapper) {
        return new MappingActionStore(jdbc, mapper);
    }

    @Bean
    @ConditionalOnMissingBean(MeetingPort.class)
    public MeetingPort p5MeetingPort(CandidateP5Properties props) {
        return new LinkOnlyMeetingPort(props.getMapping().getMeetingBaseUrl());
    }

    @Bean
    public RejectionReasonService p5RejectionReasonService(JdbcTemplate jdbc, AuditRecorder audit, Clock p5Clock) {
        return new RejectionReasonService(new RejectionReasonStore(jdbc), audit, p5Clock);
    }

    @Bean
    public MappingService p5MappingService(CandidatePort candidates, ApplicationPort applications, RequisitionPort requisitions,
                                           AssessmentPort assessments, ObjectProvider<MappingGuardPort> guards,
                                           RegistrationCheck registration, StageCatalog catalog,
                                           MappingActionStore p5MappingActionStore, StatusMover mover, AuditRecorder audit,
                                           NotificationPort notifications, BusinessClock clock, CandidateP5Properties props) {
        CandidateP5Properties.Mapping m = props.getMapping();
        return new MappingService(candidates, applications, requisitions, assessments, guards.orderedStream().toList(),
                registration, new MappingScenarioResolver(catalog), p5MappingActionStore, mover, audit, notifications, clock,
                new MappingService.Settings(m.isRemarksRequired(), m.isEligibilityFailOpen(),
                        props.getApplicant().getOnHoldTemplate(), m.getInviteTemplate()));
    }

    @Bean
    public ApplicantActionService p5ApplicantActionService(StatusMover mover, ApplicantActionGuard guard,
                                                           ApplicationPort applications, RequisitionPort requisitions,
                                                           AssessmentPort assessments, StageCatalog catalog,
                                                           RejectionReasonService p5RejectionReasonService,
                                                           MappingActionStore p5MappingActionStore, AuditRecorder audit,
                                                           BusinessClock clock, CandidateP5Properties props) {
        CandidateP5Properties.Applicant a = props.getApplicant();
        return new ApplicantActionService(mover, guard, applications, requisitions, assessments, new RemapPlanner(catalog),
                p5RejectionReasonService, p5MappingActionStore, catalog, audit, clock,
                new ApplicantActionService.Settings(a.getRejectStatus(),
                        ApplicantActionService.RemapMode.valueOf(a.getRemapMode().toUpperCase(Locale.ROOT)),
                        a.getRejectTemplate(), a.getOnHoldTemplate()));
    }

    @Bean
    public SchedulingService p5SchedulingService(JdbcTemplate jdbc, StatusMover mover, ApplicantActionGuard guard,
                                                 CandidatePort candidates, MeetingPort meetings,
                                                 MappingActionStore p5MappingActionStore, StageCatalog catalog,
                                                 AuditRecorder audit, NotificationPort notifications, BusinessClock clock,
                                                 CandidateP5Properties props) {
        CandidateP5Properties.Mapping m = props.getMapping();
        return new SchedulingService(new InterviewSlotStore(jdbc), mover, guard, candidates, meetings, p5MappingActionStore,
                catalog, audit, notifications, clock, new SchedulingService.Settings(m.getWalkInTemplate(), m.getOnlineTemplate(),
                m.getCancelTemplate(), m.getMaxDaysAhead(), m.isAdHocWalkInAllowed(), m.getMaxSlotCapacity()));
    }
}
