package com.ags.health.hr.candidates.hrround.web;

import com.ags.health.hr.candidates.hrround.domain.Competency;
import com.ags.health.hr.candidates.hrround.service.CompetencyService;
import com.ags.health.hr.candidates.hrround.service.HrRoundService;
import com.ags.health.hr.candidates.hrround.store.HrInterviewStore;
import com.ags.health.hr.candidates.photo.domain.PhotoCheck;
import com.ags.health.hr.common.platform.caller.CallerProvider;
import com.ags.health.hr.common.platform.error.PlatformException;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.List;
import java.util.Map;

@ConditionalOnProperty(prefix = "digihire.candidate.hr-round", name = "enabled", havingValue = "true", matchIfMissing = true)
@RestController
public class HrRoundController {

    public record StartRequest(String mode) {
    }

    private final HrRoundService hr;
    private final CompetencyService competencies;
    private final CallerProvider callers;

    public HrRoundController(HrRoundService hr, CompetencyService competencies, CallerProvider callers) {
        this.hr = hr;
        this.competencies = competencies;
        this.callers = callers;
    }

    @PostMapping("/applicants/{applicationId}/hr-interview")
    public HrInterviewStore.Interview start(@PathVariable String applicationId, @RequestBody StartRequest body) {
        return hr.start(callers.require(), applicationId, body.mode());
    }

    @GetMapping("/applicants/{applicationId}/hr-interview")
    public Map<String, Object> details(@PathVariable String applicationId) {
        return hr.details(callers.require(), applicationId);
    }

    @GetMapping("/applicants/{applicationId}/hr-interview/competencies")
    public List<Competency> applicable(@PathVariable String applicationId) {
        callers.require();
        return hr.competenciesFor(applicationId);
    }

    @PostMapping(value = "/hr-interviews/{interviewId}/screenshots", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public HrInterviewStore.Evidence screenshot(@PathVariable String interviewId, @RequestParam MultipartFile file) {
        return hr.screenshot(callers.require(), interviewId, bytes(file), file.getOriginalFilename());
    }

    @PostMapping(value = "/hr-interviews/{interviewId}/kiosk-photo", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public PhotoCheck kiosk(@PathVariable String interviewId, @RequestParam MultipartFile file) {
        return hr.kioskPhoto(callers.require(), interviewId, bytes(file), file.getOriginalFilename());
    }

    @PostMapping("/hr-interviews/{interviewId}/feedback")
    public HrRoundService.FeedbackResult feedback(@PathVariable String interviewId, @RequestBody HrRoundService.FeedbackRequest body) {
        return hr.feedback(callers.require(), interviewId, body);
    }

    @GetMapping("/competencies")
    public List<Competency> competencies(@RequestParam(defaultValue = "false") boolean includeInactive) {
        callers.require();
        return competencies.list(includeInactive);
    }

    @PutMapping("/competencies/{code}")
    public Competency save(@PathVariable String code, @RequestBody Competency body) {
        return competencies.save(callers.require(), new Competency(code, body.name(), body.lob(), body.roleCode(), body.weight(),
                body.maxRating(), body.minRating(), body.mandatory(), body.active(), body.sortOrder()));
    }

    private static byte[] bytes(MultipartFile file) {
        try {
            return file.getBytes();
        } catch (IOException e) {
            throw PlatformException.badRequest("FILE_UNREADABLE", "Uploaded file could not be read");
        }
    }
}
