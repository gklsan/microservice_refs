package com.ags.health.hr.candidates.shared.service;

import com.ags.health.hr.candidates.shared.domain.Tab;
import com.ags.health.hr.candidates.shared.port.ApplicationView;

import java.time.Instant;
import java.util.Map;

public record StatusMovedEvent(ApplicationView application, String fromStatus, String toStatus, Tab fromTab, Tab toTab,
                               String reasonCode, String remarks, String actorId, boolean system, Instant at,
                               Map<String, Object> context) {

    public StatusMovedEvent {
        context = context == null ? Map.of() : java.util.Collections.unmodifiableMap(new java.util.LinkedHashMap<>(context));
    }
}
