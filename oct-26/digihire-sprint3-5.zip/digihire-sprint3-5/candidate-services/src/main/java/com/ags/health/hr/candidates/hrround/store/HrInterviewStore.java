package com.ags.health.hr.candidates.hrround.store;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

import java.sql.Timestamp;
import java.time.Instant;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;

public class HrInterviewStore {

    public record Interview(String id, String applicationId, String candidateId, String mode, String interviewerId, String status,
                            Instant startedAt, Instant completedAt, String outcome, Double score, String nextStatus) {
    }

    public record Evidence(String id, String interviewId, String kind, String storageKey, String sha256, long size,
                           String contentType, String photoCheckId, String capturedBy, Instant capturedAt) {
    }

    private static final String COLUMNS = "id, application_id, candidate_id, mode, interviewer_id, status, started_at, completed_at, "
            + "outcome, score, next_status";
    private static final RowMapper<Interview> ROW = (rs, i) -> new Interview(rs.getString(1), rs.getString(2), rs.getString(3),
            rs.getString(4), rs.getString(5), rs.getString(6), rs.getTimestamp(7).toInstant(),
            rs.getTimestamp(8) == null ? null : rs.getTimestamp(8).toInstant(), rs.getString(9),
            rs.getObject(10) == null ? null : rs.getDouble(10), rs.getString(11));
    private static final RowMapper<Evidence> EVIDENCE = (rs, i) -> new Evidence(rs.getString(1), rs.getString(2), rs.getString(3),
            rs.getString(4), rs.getString(5), rs.getLong(6), rs.getString(7), rs.getString(8), rs.getString(9),
            rs.getTimestamp(10).toInstant());

    private final JdbcTemplate jdbc;

    public HrInterviewStore(JdbcTemplate jdbc) {
        this.jdbc = jdbc;
    }

    public Interview start(String applicationId, String candidateId, String mode, String interviewerId, Instant at) {
        String id = UUID.randomUUID().toString();
        jdbc.update("INSERT INTO cand_hr_interview (id, application_id, candidate_id, mode, interviewer_id, status, started_at) "
                + "VALUES (?, ?, ?, ?, ?, 'IN_PROGRESS', ?)", id, applicationId, candidateId, mode, interviewerId, Timestamp.from(at));
        return find(id).orElseThrow();
    }

    public Optional<Interview> find(String id) {
        return jdbc.query("SELECT " + COLUMNS + " FROM cand_hr_interview WHERE id = ?", ROW, id).stream().findFirst();
    }

    public Optional<Interview> openFor(String applicationId) {
        return jdbc.query("SELECT " + COLUMNS + " FROM cand_hr_interview WHERE application_id = ? AND status = 'IN_PROGRESS'", ROW,
                applicationId).stream().findFirst();
    }

    public List<Interview> forApplication(String applicationId) {
        return jdbc.query("SELECT " + COLUMNS + " FROM cand_hr_interview WHERE application_id = ? ORDER BY started_at DESC", ROW,
                applicationId);
    }

    public boolean complete(String id, String outcome, double score, String nextStatus, Instant at) {
        return jdbc.update("UPDATE cand_hr_interview SET status = 'COMPLETED', outcome = ?, score = ?, next_status = ?, completed_at = ? "
                + "WHERE id = ? AND status = 'IN_PROGRESS'", outcome, score, nextStatus, Timestamp.from(at), id) == 1;
    }

    public Evidence addEvidence(String interviewId, String kind, String storageKey, String sha256, long size, String contentType,
                                String photoCheckId, String actor, Instant at) {
        String id = UUID.randomUUID().toString();
        jdbc.update("INSERT INTO cand_hr_evidence (id, interview_id, kind, storage_key, sha256, size_bytes, content_type, photo_check_id, "
                        + "captured_by, captured_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)", id, interviewId, kind, storageKey, sha256,
                size, contentType, photoCheckId, actor, Timestamp.from(at));
        return new Evidence(id, interviewId, kind, storageKey, sha256, size, contentType, photoCheckId, actor, at);
    }

    public List<Evidence> evidence(String interviewId) {
        return jdbc.query("SELECT id, interview_id, kind, storage_key, sha256, size_bytes, content_type, photo_check_id, captured_by, "
                + "captured_at FROM cand_hr_evidence WHERE interview_id = ? ORDER BY captured_at", EVIDENCE, interviewId);
    }

    public void saveFeedback(String interviewId, Map<String, Integer> ratings, String comments, String actor, Instant at) {
        for (Map.Entry<String, Integer> e : ratings.entrySet()) {
            jdbc.update("INSERT INTO cand_hr_feedback (interview_id, competency_code, rating, comments, given_by, given_at) "
                    + "VALUES (?, ?, ?, ?, ?, ?)", interviewId, e.getKey(), e.getValue(), comments, actor, Timestamp.from(at));
        }
    }

    public List<Map<String, Object>> feedback(String interviewId) {
        return jdbc.queryForList("SELECT competency_code, rating, comments, given_by, given_at FROM cand_hr_feedback "
                + "WHERE interview_id = ? ORDER BY competency_code", interviewId);
    }
}
