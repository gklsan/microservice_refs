package com.ags.health.hr.candidates.mapping.store;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

import java.sql.Timestamp;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

public class InterviewSlotStore {

    public record Slot(String id, String mode, String lob, String location, String venue, Instant startsAt, Instant endsAt,
                       int capacity, int booked, boolean active, String createdBy, Instant createdAt) {

        public int remaining() {
            return Math.max(0, capacity - booked);
        }
    }

    public record Booking(String id, String slotId, String applicationId, String candidateId, String mode, String status,
                          Instant startsAt, Instant endsAt, String venue, String meetingId, String meetingUrl,
                          String remarks, String createdBy, Instant createdAt, String cancelledBy, Instant cancelledAt) {
    }

    private static final String SLOT_COLUMNS = "id, mode, lob, location, venue, starts_at, ends_at, capacity, booked, active, "
            + "created_by, created_at";
    private static final RowMapper<Slot> SLOT = (rs, i) -> new Slot(rs.getString(1), rs.getString(2), rs.getString(3),
            rs.getString(4), rs.getString(5), rs.getTimestamp(6).toInstant(), rs.getTimestamp(7).toInstant(), rs.getInt(8),
            rs.getInt(9), rs.getBoolean(10), rs.getString(11), rs.getTimestamp(12).toInstant());
    private static final String BOOKING_COLUMNS = "id, slot_id, application_id, candidate_id, mode, status, starts_at, ends_at, "
            + "venue, meeting_id, meeting_url, remarks, created_by, created_at, cancelled_by, cancelled_at";
    private static final RowMapper<Booking> BOOKING = (rs, i) -> new Booking(rs.getString(1), rs.getString(2), rs.getString(3),
            rs.getString(4), rs.getString(5), rs.getString(6), rs.getTimestamp(7).toInstant(),
            rs.getTimestamp(8) == null ? null : rs.getTimestamp(8).toInstant(), rs.getString(9), rs.getString(10),
            rs.getString(11), rs.getString(12), rs.getString(13), rs.getTimestamp(14).toInstant(), rs.getString(15),
            rs.getTimestamp(16) == null ? null : rs.getTimestamp(16).toInstant());

    private final JdbcTemplate jdbc;

    public InterviewSlotStore(JdbcTemplate jdbc) {
        this.jdbc = jdbc;
    }

    public Slot createSlot(String mode, String lob, String location, String venue, Instant startsAt, Instant endsAt,
                           int capacity, String actor, Instant at) {
        String id = UUID.randomUUID().toString();
        jdbc.update("INSERT INTO cand_interview_slot (" + SLOT_COLUMNS + ") VALUES (?, ?, ?, ?, ?, ?, ?, ?, 0, TRUE, ?, ?)",
                id, mode, lob, location, venue, Timestamp.from(startsAt), Timestamp.from(endsAt), capacity, actor,
                Timestamp.from(at));
        return findSlot(id).orElseThrow();
    }

    public Optional<Slot> findSlot(String id) {
        return jdbc.query("SELECT " + SLOT_COLUMNS + " FROM cand_interview_slot WHERE id = ?", SLOT, id).stream().findFirst();
    }

    public List<Slot> slots(String mode, String lob, String location, Instant from, Instant to, boolean availableOnly) {
        StringBuilder sql = new StringBuilder("SELECT " + SLOT_COLUMNS + " FROM cand_interview_slot WHERE active = TRUE "
                + "AND starts_at >= ? AND starts_at < ?");
        List<Object> args = new ArrayList<>(List.of(Timestamp.from(from), Timestamp.from(to)));
        if (mode != null) {
            sql.append(" AND mode = ?");
            args.add(mode);
        }
        if (lob != null) {
            sql.append(" AND lob = ?");
            args.add(lob);
        }
        if (location != null) {
            sql.append(" AND location = ?");
            args.add(location);
        }
        if (availableOnly) {
            sql.append(" AND booked < capacity");
        }
        sql.append(" ORDER BY starts_at, id LIMIT 500");
        return jdbc.query(sql.toString(), SLOT, args.toArray());
    }

    public boolean reserve(String slotId) {
        return jdbc.update("UPDATE cand_interview_slot SET booked = booked + 1 WHERE id = ? AND active = TRUE AND booked < capacity",
                slotId) == 1;
    }

    public void release(String slotId) {
        jdbc.update("UPDATE cand_interview_slot SET booked = booked - 1 WHERE id = ? AND booked > 0", slotId);
    }

    public boolean deactivate(String slotId) {
        return jdbc.update("UPDATE cand_interview_slot SET active = FALSE WHERE id = ? AND active = TRUE", slotId) == 1;
    }

    public Booking book(String slotId, String applicationId, String candidateId, String mode, Instant startsAt, Instant endsAt,
                        String venue, String meetingId, String meetingUrl, String remarks, String actor, Instant at) {
        String id = UUID.randomUUID().toString();
        jdbc.update("INSERT INTO cand_interview_booking (id, slot_id, application_id, candidate_id, mode, status, starts_at, "
                        + "ends_at, venue, meeting_id, meeting_url, remarks, created_by, created_at) "
                        + "VALUES (?, ?, ?, ?, ?, 'BOOKED', ?, ?, ?, ?, ?, ?, ?, ?)",
                id, slotId, applicationId, candidateId, mode, Timestamp.from(startsAt),
                endsAt == null ? null : Timestamp.from(endsAt), venue, meetingId, meetingUrl, remarks, actor, Timestamp.from(at));
        return findBooking(id).orElseThrow();
    }

    public Optional<Booking> findBooking(String id) {
        return jdbc.query("SELECT " + BOOKING_COLUMNS + " FROM cand_interview_booking WHERE id = ?", BOOKING, id)
                .stream().findFirst();
    }

    public List<Booking> activeBookings(String applicationId) {
        return jdbc.query("SELECT " + BOOKING_COLUMNS + " FROM cand_interview_booking WHERE application_id = ? "
                + "AND status = 'BOOKED' ORDER BY starts_at", BOOKING, applicationId);
    }

    public List<Booking> bookings(String applicationId) {
        return jdbc.query("SELECT " + BOOKING_COLUMNS + " FROM cand_interview_booking WHERE application_id = ? "
                + "ORDER BY created_at DESC", BOOKING, applicationId);
    }

    public boolean cancel(String bookingId, String status, String actor, String remarks, Instant at) {
        return jdbc.update("UPDATE cand_interview_booking SET status = ?, cancelled_by = ?, cancelled_at = ?, "
                        + "remarks = COALESCE(?, remarks) WHERE id = ? AND status = 'BOOKED'",
                status, actor, Timestamp.from(at), remarks, bookingId) == 1;
    }
}
