package com.ags.health.hr.candidates.versant;

import com.ags.health.hr.candidates.assessmentbridge.AssessmentExceptionStore;
import com.ags.health.hr.candidates.shared.domain.Statuses;
import com.ags.health.hr.candidates.shared.port.ApplicationView;
import com.ags.health.hr.candidates.shared.service.ApplicantActionGuard;
import com.ags.health.hr.candidates.shared.service.Remarks;
import com.ags.health.hr.candidates.shared.service.StatusMover;
import com.ags.health.hr.common.platform.audit.AuditRecorder;
import com.ags.health.hr.common.platform.caller.Caller;
import com.ags.health.hr.common.platform.error.PlatformException;
import org.springframework.transaction.annotation.Transactional;

import java.time.Clock;
import java.util.List;
import java.util.Locale;

public class VersantExceptionService {

    public static final String VIEW = "ASSESSMENT:VIEW";
    public static final String RESOLVE = "APPLICATION:MOVE_STAGE";
    public static final String PROVIDER = "VERSANT";

    public enum Resolution { MOVE_TO_PIPELINE, RESCHEDULE_REQUESTED, CLOSE }

    private final AssessmentExceptionStore store;
    private final StatusMover mover;
    private final ApplicantActionGuard guard;
    private final AuditRecorder audit;
    private final Clock clock;

    public VersantExceptionService(AssessmentExceptionStore store, StatusMover mover, ApplicantActionGuard guard,
                                   AuditRecorder audit, Clock clock) {
        this.store = store;
        this.mover = mover;
        this.guard = guard;
        this.audit = audit;
        this.clock = clock;
    }

    @Transactional(readOnly = true)
    public List<AssessmentExceptionStore.Entry> list(Caller caller, String provider, String status, int limit) {
        if (!caller.has(VIEW)) {
            throw PlatformException.forbidden("PERMISSION_DENIED", "Missing permission " + VIEW);
        }
        String p = provider == null || provider.isBlank() ? PROVIDER : provider.trim().toUpperCase(Locale.ROOT);
        String s = status == null || status.isBlank() ? "OPEN" : status.trim().toUpperCase(Locale.ROOT);
        return store.list("ALL".equals(p) ? null : p, "ALL".equals(s) ? null : s, limit);
    }

    @Transactional
    public AssessmentExceptionStore.Entry resolve(Caller caller, String exceptionId, String action, String remarks) {
        AssessmentExceptionStore.Entry e = store.find(exceptionId)
                .orElseThrow(() -> PlatformException.notFound("Assessment exception", exceptionId));
        if (!"OPEN".equals(e.status())) {
            throw PlatformException.conflict("EXCEPTION_CLOSED", "Exception is already " + e.status());
        }
        Resolution r;
        try {
            r = Resolution.valueOf(action == null ? "" : action.trim().toUpperCase(Locale.ROOT));
        } catch (IllegalArgumentException ex) {
            throw PlatformException.badRequest("RESOLUTION_INVALID", "Action must be one of " + List.of(Resolution.values()));
        }
        String text = Remarks.clean(remarks, true);
        ApplicationView app = mover.load(e.applicationId());
        guard.require(caller, app, RESOLVE);
        if (r == Resolution.MOVE_TO_PIPELINE) {
            mover.move(caller, app, StatusMover.Move.to(app.id(), Statuses.PIPELINE, RESOLVE)
                    .reason(e.provider() + "_" + e.kind(), text).with("exceptionId", e.id()));
        }
        store.resolve(e.id(), r.name(), caller.userId(), clock.instant());
        audit.record("WORKFLOW_TRANSITION", "ASSESSMENT_EXCEPTION_RESOLVED", "APPLICATION", app.id(), app.candidateId(),
                AuditRecorder.SUCCESS, text, AuditRecorder.details("exceptionId", e.id(), "kind", e.kind(), "provider",
                        e.provider(), "resolution", r, "attemptId", e.attemptId()));
        return store.find(e.id()).orElseThrow();
    }
}
