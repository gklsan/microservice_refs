package com.ags.health.hr.candidates.photo.domain;

import java.time.Instant;

public record PhotoCheck(String id, String applicationId, String candidateId, String stage, String method, PhotoDecision decision,
                         Double score, String checkedBy, String remarks, boolean flagged, String reviewStatus, String reviewedBy,
                         String reviewRemarks, Instant reviewedAt, Instant createdAt) {
}
