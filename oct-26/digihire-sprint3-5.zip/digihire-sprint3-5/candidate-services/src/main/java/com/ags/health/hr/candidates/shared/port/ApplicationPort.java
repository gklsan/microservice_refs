package com.ags.health.hr.candidates.shared.port;

import java.util.List;
import java.util.Optional;

public interface ApplicationPort {

    Optional<ApplicationView> find(String applicationId);

    List<ApplicationView> findOpenByCandidate(String candidateId);

    List<ApplicationView> findByCandidate(String candidateId);

    ApplicationView create(NewApplication application);

    void changeStatus(String applicationId, String toStatus, StatusChange change);

    void retag(String applicationId, String hrUserId, StatusChange change);

    void changeRequisition(String applicationId, String requisitionId, String jobId, StatusChange change);
}
