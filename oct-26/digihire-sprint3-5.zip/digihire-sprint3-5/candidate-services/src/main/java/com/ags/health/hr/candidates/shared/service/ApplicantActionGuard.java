package com.ags.health.hr.candidates.shared.service;

import com.ags.health.hr.candidates.shared.port.ApplicationView;
import com.ags.health.hr.common.platform.caller.Caller;
import com.ags.health.hr.common.platform.error.PlatformException;

public class ApplicantActionGuard {

    public enum Basis { SYSTEM, TAGGED_RECRUITER, TEAM_LEAD, SCOPE_ALL, UNTAGGED_FULL_GRANT }

    private final boolean allowScopeAll;

    public ApplicantActionGuard(boolean allowScopeAll) {
        this.allowScopeAll = allowScopeAll;
    }

    public Basis require(Caller caller, ApplicationView app, String permission) {
        if (caller == null) {
            throw PlatformException.unauthorized("Authentication required");
        }
        if (caller.system()) {
            return Basis.SYSTEM;
        }
        if (permission != null && !caller.has(permission)) {
            throw PlatformException.forbidden("PERMISSION_DENIED", "Missing permission " + permission);
        }
        String owner = app.hrUserId();
        if (caller.is(owner)) {
            return Basis.TAGGED_RECRUITER;
        }
        if (caller.leads(owner)) {
            return Basis.TEAM_LEAD;
        }
        if (allowScopeAll && caller.scopeAll() && (permission == null || caller.hasFull(permission))) {
            return Basis.SCOPE_ALL;
        }
        if ((owner == null || owner.isBlank()) && permission != null && caller.hasFull(permission)) {
            return Basis.UNTAGGED_FULL_GRANT;
        }
        throw PlatformException.forbidden("NOT_TAGGED_RECRUITER",
                "Only the tagged recruiter or their team lead can act on this applicant");
    }

    public boolean allowed(Caller caller, ApplicationView app, String permission) {
        try {
            require(caller, app, permission);
            return true;
        } catch (PlatformException e) {
            return false;
        }
    }
}
