package com.ags.health.hr.candidates.profile.service;

public interface ProfilePdfRenderer {

    byte[] render(ProfileDocument document);
}
