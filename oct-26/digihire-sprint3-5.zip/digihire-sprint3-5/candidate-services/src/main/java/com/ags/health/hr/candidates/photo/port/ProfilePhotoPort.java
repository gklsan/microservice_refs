package com.ags.health.hr.candidates.photo.port;

import java.util.Optional;

public interface ProfilePhotoPort {

    Optional<byte[]> referencePhoto(String candidateId);
}
