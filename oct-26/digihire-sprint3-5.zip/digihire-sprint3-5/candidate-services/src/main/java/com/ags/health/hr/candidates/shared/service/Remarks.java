package com.ags.health.hr.candidates.shared.service;

import com.ags.health.hr.common.platform.error.PlatformException;

public final class Remarks {

    public static final int MAX = 1000;

    private Remarks() {
    }

    public static String clean(String remarks, boolean required) {
        String r = remarks == null ? null : remarks.strip();
        if (r != null && r.isEmpty()) {
            r = null;
        }
        if (required && r == null) {
            throw PlatformException.badRequest("REMARKS_REQUIRED", "Remarks are required for this action");
        }
        if (r != null && r.length() > MAX) {
            throw PlatformException.badRequest("REMARKS_TOO_LONG", "Remarks must be at most " + MAX + " characters");
        }
        if (r != null && r.chars().anyMatch(c -> c < 0x20 && c != '\n' && c != '\r' && c != '\t')) {
            throw PlatformException.badRequest("REMARKS_INVALID", "Remarks contain control characters");
        }
        return r;
    }
}
