package com.ags.health.hr.candidates.mapping.domain;

import java.util.List;

public record RemapPlan(String applicationId, String fromRequisitionId, String toRequisitionId, RemapScenario scenario,
                        boolean allowed, String currentStatus, String resultingStatus, boolean scoresReused,
                        List<Blocker> blockers, String suggestion) {

    public RemapPlan {
        blockers = blockers == null ? List.of() : List.copyOf(blockers);
    }

    public boolean statusChanges() {
        return resultingStatus != null && !resultingStatus.equals(currentStatus);
    }
}
