package com.ags.health.hr.candidates.photo;

import com.ags.health.hr.candidates.photo.domain.PhotoRules;
import com.ags.health.hr.candidates.photo.port.FaceMatchClient;
import com.ags.health.hr.candidates.photo.port.FaceMatchPort;
import com.ags.health.hr.candidates.photo.port.ProfilePhotoPort;
import com.ags.health.hr.candidates.photo.service.PhotoVerificationService;
import com.ags.health.hr.candidates.photo.store.PhotoCheckStore;
import com.ags.health.hr.candidates.shared.config.CandidateP5Properties;
import com.ags.health.hr.candidates.shared.domain.StageCatalog;
import com.ags.health.hr.candidates.shared.service.StatusMover;
import com.ags.health.hr.common.platform.audit.AuditRecorder;
import com.ags.health.hr.common.platform.http.InternalHttp;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.core.JdbcTemplate;

import java.time.Clock;

@Configuration
@ConditionalOnProperty(prefix = "digihire.candidate.photo", name = "enabled", havingValue = "true", matchIfMissing = true)
public class PhotoConfig {

    @Bean
    @ConditionalOnMissingBean(FaceMatchPort.class)
    public FaceMatchPort p5FaceMatchPort(InternalHttp p5InternalHttp, CandidateP5Properties props) {
        return new FaceMatchClient(p5InternalHttp, props.getClients().getIntegrationUrl());
    }

    @Bean
    public PhotoVerificationService p5PhotoVerificationService(JdbcTemplate jdbc, FaceMatchPort faces, ProfilePhotoPort photos,
                                                               StatusMover mover, StageCatalog catalog, AuditRecorder audit,
                                                               Clock p5Clock, CandidateP5Properties props) {
        CandidateP5Properties.Photo p = props.getPhoto();
        return new PhotoVerificationService(new PhotoCheckStore(jdbc), new PhotoRules(p.getMinWidth(), p.getMinHeight(), p.getMaxBytes(),
                p.getMatchThreshold(), p.getReviewThreshold()), faces, photos, mover, catalog, audit, p5Clock);
    }
}
