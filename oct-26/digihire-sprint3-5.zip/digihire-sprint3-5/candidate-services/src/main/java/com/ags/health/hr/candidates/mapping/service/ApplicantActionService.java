package com.ags.health.hr.candidates.mapping.service;

import com.ags.health.hr.candidates.mapping.domain.RejectionReason;
import com.ags.health.hr.candidates.mapping.domain.RemapPlan;
import com.ags.health.hr.candidates.mapping.domain.RemapPlanner;
import com.ags.health.hr.candidates.mapping.store.MappingActionStore;
import com.ags.health.hr.candidates.shared.domain.Reasons;
import com.ags.health.hr.candidates.shared.domain.StageCatalog;
import com.ags.health.hr.candidates.shared.domain.Statuses;
import com.ags.health.hr.candidates.shared.port.ApplicationPort;
import com.ags.health.hr.candidates.shared.port.ApplicationView;
import com.ags.health.hr.candidates.shared.port.NewApplication;
import com.ags.health.hr.candidates.shared.port.RequisitionPort;
import com.ags.health.hr.candidates.shared.port.RequisitionView;
import com.ags.health.hr.candidates.shared.port.StatusChange;
import com.ags.health.hr.candidates.shared.service.ApplicantActionGuard;
import com.ags.health.hr.candidates.shared.service.Remarks;
import com.ags.health.hr.candidates.shared.service.StatusMover;
import com.ags.health.hr.common.platform.assessment.AssessmentPort;
import com.ags.health.hr.common.platform.audit.AuditRecorder;
import com.ags.health.hr.common.platform.caller.Caller;
import com.ags.health.hr.common.platform.error.PlatformException;
import com.ags.health.hr.common.platform.time.BusinessClock;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

public class ApplicantActionService {

    public static final String MOVE = "APPLICATION:MOVE_STAGE";
    public static final String HOLD = "APPLICATION:HOLD";
    public static final String REJECT = "APPLICATION:REJECT";
    public static final String REMAP = "APPLICATION:REMAP";

    private static final Logger log = LoggerFactory.getLogger(ApplicantActionService.class);
    private static final Set<String> HOLD_REASONS = Set.of("ON_HOLD", Reasons.NO_OPENINGS, "CANDIDATE_REQUEST", "DOCUMENTS_PENDING",
            "BUSINESS_HOLD");

    public enum RemapMode { IN_PLACE, NEW_APPLICATION }

    public record Settings(String rejectStatus, RemapMode remapMode, String defaultRejectTemplate, String onHoldTemplate) {
    }

    public record ActionResult(String applicationId, String fromStatus, String toStatus, String fromTab, String toTab) {

        static ActionResult of(StatusMover.Result r) {
            return new ActionResult(r.before().id(), r.fromStatus(), r.toStatus(), String.valueOf(r.fromTab()), String.valueOf(r.toTab()));
        }
    }

    public record RemapResult(RemapPlan plan, String applicationId, String newApplicationId, String status) {
    }

    private final StatusMover mover;
    private final ApplicantActionGuard guard;
    private final ApplicationPort applications;
    private final RequisitionPort requisitions;
    private final AssessmentPort assessments;
    private final RemapPlanner planner;
    private final RejectionReasonService reasons;
    private final MappingActionStore actions;
    private final StageCatalog catalog;
    private final AuditRecorder audit;
    private final BusinessClock clock;
    private final Settings settings;

    public ApplicantActionService(StatusMover mover, ApplicantActionGuard guard, ApplicationPort applications,
                                  RequisitionPort requisitions, AssessmentPort assessments, RemapPlanner planner,
                                  RejectionReasonService reasons, MappingActionStore actions, StageCatalog catalog,
                                  AuditRecorder audit, BusinessClock clock, Settings settings) {
        this.mover = mover;
        this.guard = guard;
        this.applications = applications;
        this.requisitions = requisitions;
        this.assessments = assessments;
        this.planner = planner;
        this.reasons = reasons;
        this.actions = actions;
        this.catalog = catalog;
        this.audit = audit;
        this.clock = clock;
        this.settings = settings;
    }

    @Transactional(readOnly = true)
    public List<String> transitions(Caller caller, String applicationId) {
        ApplicationView app = mover.load(applicationId);
        guard.require(caller, app, MOVE);
        return mover.targets(app);
    }

    @Transactional
    public ActionResult move(Caller caller, String applicationId, String toStatus, String reasonCode, String remarks) {
        String reason = reasonCode == null || reasonCode.isBlank() ? null : reasonCode.trim().toUpperCase(Locale.ROOT);
        StatusMover.Result r = mover.move(caller, StatusMover.Move.to(applicationId, toStatus, MOVE).reason(reason, remarks));
        logAction(caller, r.before(), "MOVE_" + r.toStatus(), reason, remarks);
        return ActionResult.of(r);
    }

    @Transactional
    public ActionResult moveToHr(Caller caller, String applicationId, String remarks) {
        StatusMover.Result r = mover.move(caller, StatusMover.Move.to(applicationId, Statuses.WAITING_FOR_HRROUND, MOVE)
                .reason(null, remarks));
        logAction(caller, r.before(), "MOVE_TO_HR", null, remarks);
        return ActionResult.of(r);
    }

    @Transactional
    public ActionResult moveToPipeline(Caller caller, String applicationId, String reasonCode, String remarks) {
        String reason = reasonCode == null || reasonCode.isBlank() ? "ON_HOLD" : reasonCode.trim().toUpperCase(Locale.ROOT);
        if (!HOLD_REASONS.contains(reason)) {
            throw PlatformException.badRequest("HOLD_REASON_INVALID", "Hold reason must be one of " + HOLD_REASONS);
        }
        StatusMover.Move move = StatusMover.Move.to(applicationId, Statuses.PIPELINE, HOLD).reason(reason, remarks).requireRemarks();
        if (settings.onHoldTemplate() != null) {
            move = move.notify(settings.onHoldTemplate());
        }
        StatusMover.Result r = mover.move(caller, move);
        logAction(caller, r.before(), "MOVE_TO_PIPELINE", reason, remarks);
        return ActionResult.of(r);
    }

    @Transactional
    public ActionResult reject(Caller caller, String applicationId, String reasonCode, String remarks) {
        ApplicationView app = mover.load(applicationId);
        String stage = catalog.tabOf(app.status()).name();
        RejectionReason reason = reasons.require(reasonCode, stage);
        String template = reason.templateCode() != null ? reason.templateCode() : settings.defaultRejectTemplate();
        StatusMover.Move move = StatusMover.Move.to(app.id(), settings.rejectStatus(), REJECT)
                .reason(reason.code(), remarks).with("reasonLabel", reason.label()).with("stage", stage)
                .with("roleCode", app.roleCode()).with("location", app.location()).with("lob", app.lob());
        if (reason.remarksRequired()) {
            move = move.requireRemarks();
        }
        if (template != null) {
            move = move.notify(template);
        }
        StatusMover.Result r = mover.move(caller, app, move);
        logAction(caller, app, "REJECT", reason.code(), remarks);
        return ActionResult.of(r);
    }

    @Transactional(readOnly = true)
    public RemapPlan previewRemap(Caller caller, String applicationId, String requisitionId) {
        ApplicationView app = mover.load(applicationId);
        guard.require(caller, app, REMAP);
        return plan(app, requisitionId);
    }

    @Transactional
    public RemapResult remap(Caller caller, String applicationId, String requisitionId, String remarks) {
        ApplicationView app = mover.load(applicationId);
        guard.require(caller, app, REMAP);
        String cleanRemarks = Remarks.clean(remarks, true);
        RemapPlan plan = plan(app, requisitionId);
        if (!plan.allowed()) {
            actions.append(app.candidateId(), app.id(), requisitionId, "REMAP", plan.scenario().name(), "BLOCKED", app.source(),
                    null, cleanRemarks, caller.userId(), caller.displayName(), clock.now(),
                    Map.of("blockers", plan.blockers().stream().map(b -> b.code()).toList()));
            List<Map<String, Object>> details = new ArrayList<>();
            plan.blockers().forEach(b -> details.add(Map.of("code", b.code(), "message", b.message())));
            if (plan.suggestion() != null) {
                details.add(Map.of("suggestion", plan.suggestion()));
            }
            throw new PlatformException(409, "REMAP_BLOCKED", "Application can not be re-mapped to " + requisitionId, details);
        }
        RequisitionView target = requisitions.find(plan.toRequisitionId()).orElseThrow();
        StatusChange change = new StatusChange(caller.userId(), caller.displayName(), Reasons.REMAP, cleanRemarks, caller.system());
        Map<String, Object> ctx = Map.of("fromRequisitionId", String.valueOf(app.requisitionId()), "toRequisitionId",
                target.requisitionId(), "scenario", plan.scenario().name(), "lob", String.valueOf(target.lob()),
                "roleCode", String.valueOf(target.roleCode()), "location", String.valueOf(target.location()));
        String newApplicationId = null;
        String finalStatus;
        if (settings.remapMode() == RemapMode.NEW_APPLICATION) {
            mover.move(caller, app, StatusMover.Move.to(app.id(), Statuses.REMAPPED, REMAP).reason(Reasons.REMAP, cleanRemarks)
                    .with("toRequisitionId", target.requisitionId()));
            ApplicationView created = applications.create(new NewApplication(app.candidateId(), target.requisitionId(),
                    target.jobId(), app.hrUserId(), app.source(), null, plan.resultingStatus(), change));
            newApplicationId = created.id();
            finalStatus = created.status();
            mover.announce(caller, created, null, finalStatus, Reasons.REMAP, cleanRemarks, ctx);
        } else {
            applications.changeRequisition(app.id(), target.requisitionId(), target.jobId(), change);
            ApplicationView moved = applications.find(app.id()).orElseThrow();
            if (plan.statusChanges()) {
                mover.move(caller, moved, StatusMover.Move.to(app.id(), plan.resultingStatus(), REMAP)
                        .reason(Reasons.REMAP, cleanRemarks).asReset().with("scenario", plan.scenario().name())
                        .with("toRequisitionId", target.requisitionId()));
            } else {
                mover.announce(caller, moved, moved.status(), moved.status(), Reasons.REMAP, cleanRemarks, ctx);
            }
            finalStatus = plan.resultingStatus();
        }
        actions.append(app.candidateId(), newApplicationId != null ? newApplicationId : app.id(), target.requisitionId(), "REMAP",
                plan.scenario().name(), "DONE", app.source(), null, cleanRemarks, caller.userId(), caller.displayName(), clock.now(),
                Map.of("fromRequisitionId", String.valueOf(app.requisitionId()), "fromStatus", app.status(), "toStatus", finalStatus,
                        "scoresReused", plan.scoresReused()));
        audit.record("WORKFLOW_TRANSITION", "APPLICATION_REMAPPED", "APPLICATION", app.id(), app.candidateId(),
                AuditRecorder.SUCCESS, cleanRemarks, AuditRecorder.details("scenario", plan.scenario(), "fromRequisitionId",
                        app.requisitionId(), "toRequisitionId", target.requisitionId(), "fromStatus", app.status(),
                        "toStatus", finalStatus, "mode", settings.remapMode(), "newApplicationId", newApplicationId));
        return new RemapResult(plan, app.id(), newApplicationId, finalStatus);
    }

    private RemapPlan plan(ApplicationView app, String requisitionId) {
        if (requisitionId == null || requisitionId.isBlank()) {
            throw PlatformException.badRequest("REQUISITION_REQUIRED", "Target requisition id is required");
        }
        String id = requisitionId.trim();
        RequisitionView current = app.requisitionId() == null ? null : requisitions.find(app.requisitionId()).orElse(null);
        RequisitionView target = requisitions.find(id).orElse(null);
        boolean validScore = false;
        try {
            validScore = !assessments.validScores(app.candidateId()).isEmpty();
        } catch (RuntimeException e) {
            log.warn("Valid scores for {} unavailable: {}", app.candidateId(), e.getMessage());
        }
        return planner.plan(app, current, target, id, validScore, clock.today());
    }

    private void logAction(Caller caller, ApplicationView app, String action, String reason, String remarks) {
        actions.append(app.candidateId(), app.id(), app.requisitionId(), action, null, "DONE", app.source(), null,
                remarks == null ? null : remarks.strip(), caller.userId(), caller.displayName(), clock.now(),
                reason == null ? Map.of() : Map.of("reasonCode", reason));
    }
}
