package com.ags.health.hr.candidates.profile;

import com.ags.health.hr.candidates.mapping.port.RegistrationCheck;
import com.ags.health.hr.candidates.profile.domain.FieldCatalog;
import com.ags.health.hr.candidates.profile.domain.ProfileValidator;
import com.ags.health.hr.candidates.profile.domain.StageEditPolicy;
import com.ags.health.hr.candidates.profile.port.ProfilePort;
import com.ags.health.hr.candidates.profile.service.PdfBoxProfileRenderer;
import com.ags.health.hr.candidates.profile.service.ProfileDocumentBuilder;
import com.ags.health.hr.candidates.profile.service.ProfilePdfRenderer;
import com.ags.health.hr.candidates.profile.service.ProfileService;
import com.ags.health.hr.candidates.profile.store.ProfileChangeStore;
import com.ags.health.hr.candidates.shared.config.CandidateP5Properties;
import com.ags.health.hr.candidates.shared.domain.StageCatalog;
import com.ags.health.hr.candidates.shared.port.ApplicationPort;
import com.ags.health.hr.candidates.shared.service.CandidateGuard;
import com.ags.health.hr.common.platform.audit.AuditRecorder;
import com.ags.health.hr.common.platform.time.BusinessClock;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.core.JdbcTemplate;

@Configuration
@ConditionalOnProperty(prefix = "digihire.candidate.profile", name = "enabled", havingValue = "true", matchIfMissing = true)
public class ProfileConfig {

    @Bean
    @ConditionalOnMissingBean(FieldCatalog.class)
    public FieldCatalog p5FieldCatalog(BusinessClock clock) {
        return FieldCatalog.standard(clock.today().getYear());
    }

    @Bean
    @ConditionalOnMissingBean(ProfilePdfRenderer.class)
    public ProfilePdfRenderer p5ProfilePdfRenderer() {
        return new PdfBoxProfileRenderer();
    }

    @Bean
    public ProfileService p5ProfileService(FieldCatalog catalog, StageCatalog stages, ProfilePort profiles,
                                           ApplicationPort applications, CandidateGuard guard, JdbcTemplate jdbc,
                                           ProfilePdfRenderer renderer, AuditRecorder audit, BusinessClock clock,
                                           CandidateP5Properties props) {
        return new ProfileService(catalog, new ProfileValidator(catalog, props.getProfile().getMinAge(), props.getProfile().getMaxAge()),
                new StageEditPolicy(stages), profiles, applications, guard, new ProfileChangeStore(jdbc),
                new ProfileDocumentBuilder(catalog, clock.zone()), renderer, audit, clock);
    }

    @Bean
    @ConditionalOnMissingBean(RegistrationCheck.class)
    public RegistrationCheck p5RegistrationCheck(ProfileService p5ProfileService) {
        return p5ProfileService::requireRegistered;
    }
}
