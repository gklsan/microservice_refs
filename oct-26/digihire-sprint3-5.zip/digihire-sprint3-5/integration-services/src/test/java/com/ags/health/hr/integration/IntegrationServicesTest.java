package com.ags.health.hr.integration;

import com.ags.health.hr.common.platform.audit.AuditRecorder;
import com.ags.health.hr.common.platform.audit.LocalAuditLogTable;
import com.ags.health.hr.common.platform.audit.SharedAuditLogSink;
import com.ags.health.hr.common.platform.db.SchemaInitializer;
import com.ags.health.hr.common.platform.error.PlatformException;
import com.ags.health.hr.common.platform.outbox.OutboxEvent;
import com.ags.health.hr.common.platform.outbox.OutboxStore;
import com.ags.health.hr.integration.calllog.CallLog;
import com.ags.health.hr.integration.config.IntegrationProperties;
import com.ags.health.hr.integration.identity.IdentityService;
import com.ags.health.hr.integration.identity.IdentityVerificationProvider;
import com.ags.health.hr.integration.identity.RateLimiter;
import com.ags.health.hr.integration.identity.StubIdentityVerificationProvider;
import com.ags.health.hr.integration.offer.OfferPayloadMapper;
import com.ags.health.hr.integration.offer.OfferSyncService;
import com.ags.health.hr.integration.offer.OfferSyncStore;
import com.ags.health.hr.integration.offer.OfferValidator;
import com.ags.health.hr.integration.offer.StubOracleOfferClient;
import com.ags.health.hr.integration.web.OracleCallbackController;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.transaction.support.TransactionTemplate;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
import java.nio.charset.StandardCharsets;
import java.time.Clock;
import java.time.Duration;
import java.time.Instant;
import java.time.ZoneId;
import java.time.ZoneOffset;
import java.util.HexFormat;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

class IntegrationServicesTest {

    private static final Instant NOW = Instant.parse("2026-10-20T05:30:00Z");
    private final ObjectMapper mapper = new ObjectMapper();
    private final MutableClock clock = new MutableClock(NOW);
    private JdbcTemplate jdbc;
    private OutboxStore outbox;
    private OfferSyncStore store;
    private final StubOracleOfferClient oracle = new StubOracleOfferClient();
    private OfferSyncService offers;
    private AuditRecorder audit;
    private CallLog calls;

    static final class MutableClock extends Clock {
        Instant now;

        MutableClock(Instant now) {
            this.now = now;
        }

        @Override
        public ZoneId getZone() {
            return ZoneOffset.UTC;
        }

        @Override
        public Clock withZone(ZoneId zone) {
            return Clock.fixed(now, zone);
        }

        @Override
        public Instant instant() {
            return now;
        }
    }

    @BeforeEach
    void setUp() {
        DriverManagerDataSource ds = TestDatabase.create("integ", List.of("db/schema-integration.sql"));
        jdbc = new JdbcTemplate(ds);
        audit = new AuditRecorder(List.of(SharedAuditLogSink.create(jdbc, mapper, "audit_log", 4000)), Optional::empty, "integration", clock);
        outbox = new OutboxStore(jdbc, mapper, clock, "integ_outbox", new OutboxStore.Policy(5, 30, 600));
        store = new OfferSyncStore(jdbc);
        calls = new CallLog(jdbc, clock);
        offers = new OfferSyncService(store, new OfferPayloadMapper(Map.of()), new OfferValidator(180), oracle, calls, outbox, audit,
                new TransactionTemplate(new DataSourceTransactionManager(ds)), mapper, clock, ZoneId.of("Asia/Kolkata"), 3);
    }

    private Map<String, Object> data() {
        Map<String, Object> d = new LinkedHashMap<>();
        d.put("firstName", "Asha");
        d.put("lastName", "Kumar");
        d.put("email", "Asha@Mail.com");
        d.put("mobile", "9876543210");
        d.put("dateOfBirth", "1998-02-01");
        d.put("panNumber", "abcpe1234f");
        d.put("requisitionId", "REQ-1");
        d.put("designation", "AR Analyst");
        d.put("location", "Chennai");
        d.put("offeredCtc", "3,60,000");
        d.put("joiningDate", "2026-11-15");
        return d;
    }

    private List<String> events() {
        return outbox.due(100).stream().map(OutboxEvent::eventType).toList();
    }

    @Test
    void validOfferIsMappedPushedAndAnnounced() {
        OfferSyncService.Accepted a = offers.accept("A1", "C1", "rec1", data());
        assertThat(a.status()).isEqualTo("PUSHED");
        assertThat(a.externalOfferId()).startsWith("OFR-");
        String payload = store.find(a.syncId()).orElseThrow().payload();
        assertThat(payload).contains("\"Email\":\"asha@mail.com\"", "\"NationalId\":\"ABCPE1234F\"", "\"SalaryCurrency\":\"INR\"");
        assertThat(events()).containsExactly("OFFER_PUSHED");
        assertThat(offers.accept("A1", "C1", "rec1", data()).syncId()).isEqualTo(a.syncId());
        assertThat(calls.recent("ORACLE_OFFER", null, 10)).hasSize(1);
        assertThat(jdbc.queryForObject("SELECT request_masked FROM integ_call_log", String.class)).doesNotContain("ABCPE1234F");
    }

    @Test
    void invalidOfferIsRejectedBeforeOracle() {
        Map<String, Object> d = data();
        d.remove("designation");
        d.put("joiningDate", "2026-01-01");
        d.put("panNumber", "BAD");
        assertThatThrownBy(() -> offers.accept("A1", "C1", "rec1", d)).isInstanceOf(PlatformException.class)
                .satisfies(e -> assertThat(((PlatformException) e).getDetails().toString()).contains("JobTitle", "OUT_OF_RANGE", "INVALID_PAN"));
        assertThat(calls.recent(null, null, 10)).isEmpty();
    }

    @Test
    void outagesAreRetriedThenParkedAndAnnounced() {
        oracle.failNext(10);
        OfferSyncService.Accepted a = offers.accept("A1", "C1", "rec1", data());
        assertThat(a.status()).isEqualTo("RETRY");
        clock.now = clock.now.plus(Duration.ofHours(2));
        offers.retryDue(10);
        clock.now = clock.now.plus(Duration.ofHours(2));
        offers.retryDue(10);
        assertThat(store.find(a.syncId()).orElseThrow().status()).isEqualTo("PARKED");
        assertThat(events()).containsExactly("OFFER_PARKED");
        oracle.failNext(0);
        offers.requeue(a.syncId());
        assertThat(store.find(a.syncId()).orElseThrow().status()).isEqualTo("PUSHED");
    }

    @Test
    void statusChangesFromPollCallbackAndReconciliationAreDeduplicated() throws Exception {
        OfferSyncService.Accepted a = offers.accept("A1", "C1", "rec1", data());
        oracle.setStatus(a.externalOfferId(), "ACCEPTED");
        assertThat(offers.poll(10)).isEqualTo(1);
        assertThat(offers.poll(10)).isZero();
        IntegrationProperties props = new IntegrationProperties();
        props.getOffer().setCallbackSecret("s3cret");
        OracleCallbackController callback = new OracleCallbackController(offers, mapper, props);
        String body = "{\"OfferId\":\"" + a.externalOfferId() + "\",\"OfferStatus\":\"DECLINED\"}";
        assertThatThrownBy(() -> callback.callback("deadbeef", body)).hasMessageContaining("signature");
        Mac mac = Mac.getInstance("HmacSHA256");
        mac.init(new SecretKeySpec("s3cret".getBytes(StandardCharsets.UTF_8), "HmacSHA256"));
        String sig = HexFormat.of().formatHex(mac.doFinal(body.getBytes(StandardCharsets.UTF_8)));
        assertThat(callback.callback(sig, body)).containsEntry("changed", true);
        assertThat(events()).containsExactly("OFFER_PUSHED", "OFFER_ACCEPTED", "OFFER_REJECTED");
        assertThat(store.find(a.syncId()).orElseThrow().status()).isEqualTo("CLOSED");
        OfferSyncService.Accepted b = offers.accept("A2", "C2", "rec1", data());
        oracle.setStatus(b.externalOfferId(), "HIRED");
        assertThat(offers.reconcile(10)).containsEntry("corrected", 1);
        assertThat(events()).last().isEqualTo("CANDIDATE_HIRED");
    }

    @Test
    void identityVerificationIsRateLimitedAndLoggedWithoutTheNumber() {
        IdentityService idv = new IdentityService(new StubIdentityVerificationProvider(), new RateLimiter(2, clock), calls, audit);
        IdentityVerificationProvider.Request ok = new IdentityVerificationProvider.Request("D1", "C1", "PAN", "ABCPE1234F", "Asha", null);
        assertThat(idv.verify(ok).status()).isEqualTo("VERIFIED");
        assertThat(idv.verify(new IdentityVerificationProvider.Request("D2", "C1", "PAN", "XYZ", null, null)).status())
                .isEqualTo("INVALID");
        assertThat(idv.verify(ok).retryable()).isTrue();
        assertThat(jdbc.queryForList("SELECT request_masked FROM integ_call_log", String.class)).noneMatch(s -> s.contains("ABCPE1234F"));
        clock.now = clock.now.plusSeconds(60);
        assertThat(idv.verify(ok).status()).isEqualTo("VERIFIED");
    }
}
