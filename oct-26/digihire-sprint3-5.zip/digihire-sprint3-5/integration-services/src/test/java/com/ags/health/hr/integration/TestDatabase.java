package com.ags.health.hr.integration;

import com.ags.health.hr.common.platform.audit.LocalAuditLogTable;
import com.ags.health.hr.common.platform.db.SchemaInitializer;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.datasource.DriverManagerDataSource;

import java.util.List;
import java.util.UUID;

public final class TestDatabase {

    public static final String PG_URL = "p5.test.pg.url";

    private TestDatabase() {
    }

    public static DriverManagerDataSource create(String prefix, List<String> scripts) {
        String pg = System.getProperty(PG_URL);
        DriverManagerDataSource ds;
        if (pg != null && !pg.isBlank()) {
            ds = new DriverManagerDataSource(pg, System.getProperty("p5.test.pg.user", "p5"), System.getProperty("p5.test.pg.password", "p5"));
            JdbcTemplate jdbc = new JdbcTemplate(ds);
            jdbc.execute("DROP SCHEMA IF EXISTS public CASCADE");
            jdbc.execute("CREATE SCHEMA public");
            jdbc.execute("CREATE TABLE audit_log (id BIGSERIAL PRIMARY KEY, event_time TIMESTAMP WITH TIME ZONE NOT NULL, "
                    + "event_type VARCHAR(255) NOT NULL CHECK (event_type IN ('ACTIVITY', 'TIMESTAMP', 'APPROVAL', 'WORKFLOW_TRANSITION')), "
                    + "action VARCHAR(255) NOT NULL, status VARCHAR(255) NOT NULL, actor_id VARCHAR(255), actor_email VARCHAR(255), "
                    + "candidate_id VARCHAR(255), target_type VARCHAR(255), target_id VARCHAR(255), correlation_id VARCHAR(64), "
                    + "service_name VARCHAR(100), description VARCHAR(1000), details JSONB, created_at TIMESTAMP WITH TIME ZONE)");
        } else {
            ds = new DriverManagerDataSource("jdbc:h2:mem:" + prefix + "_" + UUID.randomUUID() + ";DB_CLOSE_DELAY=-1", "sa", "");
        }
        new SchemaInitializer(ds, scripts).run();
        if (pg == null || pg.isBlank()) {
            LocalAuditLogTable.createIfMissingOnH2(new JdbcTemplate(ds), "audit_log");
        }
        return ds;
    }
}
