package com.ags.health.hr.integration.config;

import lombok.Getter;
import lombok.Setter;
import org.springframework.boot.context.properties.ConfigurationProperties;

import java.util.LinkedHashMap;
import java.util.Map;

@Getter
@Setter
@ConfigurationProperties(prefix = "digihire.integration")
public class IntegrationProperties {

    private String serviceName = "integration-services";
    private String jwtSecret;
    private String internalKey;
    private String serviceKeys;
    private String adminUrl;
    private String candidateEventsUrl;
    private String candidateEventsKey;
    private String auditTable = "audit_log";
    private String zone = "Asia/Kolkata";
    private boolean jobsEnabled = true;
    private int timeoutSeconds = 20;
    private Offer offer = new Offer();
    private Identity identity = new Identity();
    private Face face = new Face();

    @Getter
    @Setter
    public static class Offer {
        private String mode = "STUB";
        private String baseUrl;
        private String username;
        private String password;
        private String callbackSecret;
        private int maxAttempts = 8;
        private int joiningWindowDays = 180;
        private Map<String, String> fieldMap = new LinkedHashMap<>();
        private String retryCron = "0 */5 * * * *";
        private String pollCron = "0 */20 * * * *";
        private String reconcileCron = "0 15 1 * * *";
    }

    @Getter
    @Setter
    public static class Identity {
        private String mode = "STUB";
        private String url;
        private String apiKey;
        private String apiKeyHeader = "x-api-key";
        private int requestsPerMinute = 60;
    }

    @Getter
    @Setter
    public static class Face {
        private String mode = "STUB";
        private String url;
        private String apiKey;
        private int maxImageBytes = 3 * 1024 * 1024;
    }
}
