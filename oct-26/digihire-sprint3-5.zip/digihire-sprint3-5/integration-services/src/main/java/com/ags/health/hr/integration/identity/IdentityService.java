package com.ags.health.hr.integration.identity;

import com.ags.health.hr.common.platform.audit.AuditRecorder;
import com.ags.health.hr.common.platform.error.PlatformException;
import com.ags.health.hr.integration.calllog.CallLog;

public class IdentityService {

    private final IdentityVerificationProvider provider;
    private final RateLimiter limiter;
    private final CallLog calls;
    private final AuditRecorder audit;

    public IdentityService(IdentityVerificationProvider provider, RateLimiter limiter, CallLog calls, AuditRecorder audit) {
        this.provider = provider;
        this.limiter = limiter;
        this.calls = calls;
        this.audit = audit;
    }

    public IdentityVerificationProvider.Result verify(IdentityVerificationProvider.Request r) {
        if (r == null || r.number() == null || r.documentType() == null) {
            throw PlatformException.badRequest("IDV_REQUEST_INVALID", "Document type and number are required");
        }
        if (!limiter.tryAcquire()) {
            return new IdentityVerificationProvider.Result("ERROR", provider.code(), null, null, "Rate limit reached", true);
        }
        IdentityVerificationProvider.Result result = calls.call("IDENTITY", "VERIFY", r.reference(),
                "{\"documentType\":\"" + r.documentType() + "\",\"number\":\"" + r.number() + "\"}",
                () -> new CallLog.Outcome<>(provider.verify(r), null), x -> x.status() + ":" + x.message());
        audit.recordQuietly("INTEGRATION", "IDENTITY_VERIFICATION_CALLED", "ID_DOCUMENT", r.reference(), r.candidateId(),
                "VERIFIED".equals(result.status()) ? AuditRecorder.SUCCESS : AuditRecorder.FAILURE, result.message(),
                AuditRecorder.details("provider", result.provider(), "status", result.status(), "documentType", r.documentType()));
        return result;
    }
}
