package com.ags.health.hr.integration.offer;

import com.ags.health.hr.common.platform.http.InternalHttp;
import com.ags.health.hr.common.platform.outbox.OutboxEvent;
import com.ags.health.hr.common.platform.outbox.OutboxStore;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class IntegrationEventRelay {

    private final OutboxStore outbox;
    private final InternalHttp http;
    private final String url;

    public IntegrationEventRelay(OutboxStore outbox, InternalHttp http, String url) {
        this.outbox = outbox;
        this.http = http;
        this.url = url;
    }

    public int relay(int batch) {
        if (url == null || url.isBlank()) {
            return 0;
        }
        List<OutboxEvent> events = outbox.due(batch);
        if (events.isEmpty()) {
            return 0;
        }
        List<Map<String, Object>> body = events.stream().map(e -> {
            Map<String, Object> m = new LinkedHashMap<>();
            m.put("seq", e.seq());
            m.put("id", e.id().toString());
            m.put("eventType", e.eventType());
            m.put("aggregateType", e.aggregateType());
            m.put("aggregateId", e.aggregateId());
            m.put("candidateId", e.candidateId());
            m.put("applicationId", e.applicationId());
            m.put("payload", e.payload());
            m.put("createdAt", e.createdAt() == null ? null : e.createdAt().toString());
            m.put("correlationId", e.correlationId());
            m.put("attempts", e.attempts());
            return m;
        }).toList();
        try {
            http.post(url, body);
            outbox.markPublished(events);
            return events.size();
        } catch (RuntimeException ex) {
            outbox.markFailed(events, ex.getMessage());
            return 0;
        }
    }
}
