package com.ags.health.hr.integration.offer;

import com.ags.health.hr.common.platform.validation.FieldViolation;
import com.ags.health.hr.common.platform.validation.IdentityValidators;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class OfferValidator {

    private static final Set<String> REQUIRED = Set.of("CandidateNumber", "FirstName", "LastName", "Email", "PhoneNumber",
            "RequisitionNumber", "JobTitle", "WorkLocation", "SalaryAmount", "StartDate");

    private final int joiningWindowDays;

    public OfferValidator(int joiningWindowDays) {
        this.joiningWindowDays = joiningWindowDays;
    }

    public List<FieldViolation> validate(Map<String, Object> payload, LocalDate today) {
        List<FieldViolation> v = new ArrayList<>();
        for (String f : REQUIRED) {
            if (!payload.containsKey(f)) {
                v.add(new FieldViolation(f, "REQUIRED", f + " is required by the Oracle offer interface"));
            }
        }
        check(v, payload, "Email", IdentityValidators.Kind.EMAIL);
        check(v, payload, "PhoneNumber", IdentityValidators.Kind.MOBILE);
        check(v, payload, "FirstName", IdentityValidators.Kind.NAME);
        check(v, payload, "LastName", IdentityValidators.Kind.NAME);
        check(v, payload, "NationalId", IdentityValidators.Kind.PAN);
        Object salary = payload.get("SalaryAmount");
        if (salary != null && (!(salary instanceof BigDecimal || salary instanceof Number)
                || new BigDecimal(String.valueOf(salary)).signum() <= 0)) {
            v.add(new FieldViolation("SalaryAmount", "INVALID_AMOUNT", "Salary must be a positive number"));
        }
        LocalDate start = date(v, payload, "StartDate");
        if (start != null && (start.isBefore(today) || start.isAfter(today.plusDays(joiningWindowDays)))) {
            v.add(new FieldViolation("StartDate", "OUT_OF_RANGE", "Joining date must be within the next " + joiningWindowDays + " days"));
        }
        LocalDate dob = date(v, payload, "DateOfBirth");
        if (dob != null) {
            IdentityValidators.checkAge(dob, today, 18, 65).ifPresent(code ->
                    v.add(new FieldViolation("DateOfBirth", code, "Candidate age is outside the allowed range")));
        }
        return v;
    }

    private static void check(List<FieldViolation> v, Map<String, Object> p, String field, IdentityValidators.Kind kind) {
        Object value = p.get(field);
        if (value != null) {
            IdentityValidators.check(kind, String.valueOf(value)).ifPresent(code ->
                    v.add(new FieldViolation(field, code, field + " is not valid")));
        }
    }

    private static LocalDate date(List<FieldViolation> v, Map<String, Object> p, String field) {
        Object value = p.get(field);
        if (value == null) {
            return null;
        }
        try {
            return LocalDate.parse(String.valueOf(value));
        } catch (DateTimeParseException e) {
            v.add(new FieldViolation(field, "INVALID_DATE", field + " must be YYYY-MM-DD"));
            return null;
        }
    }
}
