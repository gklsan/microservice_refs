package com.ags.health.hr.integration.face;

public interface FaceMatchProvider {

    String code();

    double score(byte[] probe, byte[] reference);
}
