package com.ags.health.hr.integration.face;

import com.ags.health.hr.common.platform.error.PlatformException;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;
import java.util.Base64;
import java.util.Map;

public class RestFaceMatchProvider implements FaceMatchProvider {

    private final HttpClient client;
    private final ObjectMapper mapper;
    private final String url;
    private final String apiKey;
    private final Duration timeout;

    public RestFaceMatchProvider(ObjectMapper mapper, String url, String apiKey, Duration timeout) {
        this.client = HttpClient.newBuilder().connectTimeout(timeout).build();
        this.mapper = mapper;
        this.url = url;
        this.apiKey = apiKey;
        this.timeout = timeout;
    }

    @Override
    public String code() {
        return "REST";
    }

    @Override
    public double score(byte[] probe, byte[] reference) {
        try {
            String body = mapper.writeValueAsString(Map.of("image1", Base64.getEncoder().encodeToString(probe), "image2",
                    Base64.getEncoder().encodeToString(reference)));
            HttpResponse<String> r = client.send(HttpRequest.newBuilder(URI.create(url)).timeout(timeout).header("Content-Type", "application/json")
                    .header("x-api-key", apiKey).POST(HttpRequest.BodyPublishers.ofString(body)).build(), HttpResponse.BodyHandlers.ofString());
            if (r.statusCode() / 100 != 2) {
                throw PlatformException.unavailable("FACE_PROVIDER_ERROR", "Face match provider returned " + r.statusCode());
            }
            double s = mapper.readTree(r.body()).path("confidence").asDouble(-1);
            if (s < 0) {
                throw PlatformException.unavailable("FACE_PROVIDER_ERROR", "Face match provider gave no confidence");
            }
            return s > 1 ? s / 100.0 : s;
        } catch (IOException e) {
            throw PlatformException.unavailable("FACE_PROVIDER_ERROR", "Face match call failed: " + e.getMessage());
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            throw PlatformException.unavailable("FACE_PROVIDER_ERROR", "Face match call interrupted");
        }
    }
}
