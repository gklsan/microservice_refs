package com.ags.health.hr.integration.face;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

public class StubFaceMatchProvider implements FaceMatchProvider {

    private final double differentScore;

    public StubFaceMatchProvider(double differentScore) {
        this.differentScore = differentScore;
    }

    @Override
    public String code() {
        return "STUB";
    }

    @Override
    public double score(byte[] probe, byte[] reference) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            return MessageDigest.isEqual(md.digest(probe), MessageDigest.getInstance("SHA-256").digest(reference)) ? 1.0 : differentScore;
        } catch (NoSuchAlgorithmException e) {
            throw new IllegalStateException(e);
        }
    }
}
