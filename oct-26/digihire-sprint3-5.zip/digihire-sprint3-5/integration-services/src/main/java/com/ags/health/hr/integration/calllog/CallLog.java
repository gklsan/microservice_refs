package com.ags.health.hr.integration.calllog;

import org.slf4j.MDC;
import org.springframework.jdbc.core.JdbcTemplate;

import java.sql.Timestamp;
import java.time.Clock;
import java.time.Duration;
import java.time.Instant;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.function.Supplier;
import java.util.regex.Pattern;

public class CallLog {

    private static final Pattern SECRETS = Pattern.compile("(?i)(\"(?:number|pan|aadhaar|passport|password|token|apiKey|probe|reference|nationalId|phoneNumber|documentNumber|"
            + "dateOfBirth|mobile|email)\"\\s*:\\s*\")([^\"]*)(\")");

    public record Outcome<T>(T value, Integer httpStatus) {
    }

    private final JdbcTemplate jdbc;
    private final Clock clock;

    public CallLog(JdbcTemplate jdbc, Clock clock) {
        this.jdbc = jdbc;
        this.clock = clock;
    }

    public <T> T call(String integration, String operation, String reference, String request, Supplier<Outcome<T>> work,
                      java.util.function.Function<T, String> responseText) {
        Instant start = clock.instant();
        String id = UUID.randomUUID().toString();
        try {
            Outcome<T> o = work.get();
            write(id, integration, operation, reference, "SUCCESS", o.httpStatus(), start, request,
                    o.value() == null ? null : responseText.apply(o.value()), null);
            return o.value();
        } catch (RuntimeException e) {
            write(id, integration, operation, reference, "FAILURE", null, start, request, null, e.getMessage());
            throw e;
        }
    }

    private void write(String id, String integration, String operation, String reference, String status, Integer http, Instant start,
                       String request, String response, String error) {
        Instant end = clock.instant();
        jdbc.update("INSERT INTO integ_call_log (id, integration, operation, reference, status, http_status, duration_ms, request_masked, "
                        + "response_masked, error, correlation_id, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)", id, integration,
                operation, reference, status, http, Duration.between(start, end).toMillis(), cut(mask(request), 4000), cut(mask(response), 4000),
                cut(error, 500), MDC.get("correlationId"), Timestamp.from(end));
    }

    public List<Map<String, Object>> recent(String integration, String status, int limit) {
        StringBuilder sql = new StringBuilder("SELECT id, integration, operation, reference, status, http_status, duration_ms, error, "
                + "correlation_id, created_at FROM integ_call_log WHERE 1 = 1");
        java.util.List<Object> args = new java.util.ArrayList<>();
        if (integration != null) {
            sql.append(" AND integration = ?");
            args.add(integration);
        }
        if (status != null) {
            sql.append(" AND status = ?");
            args.add(status);
        }
        sql.append(" ORDER BY created_at DESC LIMIT ?");
        args.add(Math.min(Math.max(limit, 1), 500));
        return jdbc.queryForList(sql.toString(), args.toArray());
    }

    public static String mask(String text) {
        if (text == null) {
            return null;
        }
        return SECRETS.matcher(text).replaceAll(m -> m.group(1) + (m.group(2).length() <= 4 ? "****"
                : "****" + m.group(2).substring(Math.max(0, m.group(2).length() - 4)).replaceAll("[^A-Za-z0-9]", "")) + m.group(3));
    }

    private static String cut(String s, int max) {
        return s == null ? null : s.length() > max ? s.substring(0, max) : s;
    }
}
