package com.ags.health.hr.integration.offer;

import com.ags.health.hr.common.platform.audit.AuditRecorder;
import com.ags.health.hr.common.platform.error.PlatformException;
import com.ags.health.hr.common.platform.outbox.OutboxBackoff;
import com.ags.health.hr.common.platform.outbox.OutboxStore;
import com.ags.health.hr.common.platform.validation.FieldViolation;
import com.ags.health.hr.integration.calllog.CallLog;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.transaction.support.TransactionTemplate;

import java.time.Clock;
import java.time.Instant;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class OfferSyncService {

    public static final String INTEGRATION = "ORACLE_OFFER";
    private static final TypeReference<Map<String, Object>> MAP = new TypeReference<>() {
    };

    public record Accepted(String syncId, String status, String externalOfferId, List<Map<String, Object>> errors) {
    }

    private final OfferSyncStore store;
    private final OfferPayloadMapper mapper;
    private final OfferValidator validator;
    private final OracleOfferClient oracle;
    private final CallLog calls;
    private final OutboxStore outbox;
    private final AuditRecorder audit;
    private final TransactionTemplate tx;
    private final ObjectMapper json;
    private final Clock clock;
    private final ZoneId zone;
    private final int maxAttempts;

    public OfferSyncService(OfferSyncStore store, OfferPayloadMapper mapper, OfferValidator validator, OracleOfferClient oracle, CallLog calls,
                            OutboxStore outbox, AuditRecorder audit, TransactionTemplate tx, ObjectMapper json, Clock clock, ZoneId zone,
                            int maxAttempts) {
        this.store = store;
        this.mapper = mapper;
        this.validator = validator;
        this.oracle = oracle;
        this.calls = calls;
        this.outbox = outbox;
        this.audit = audit;
        this.tx = tx;
        this.json = json;
        this.clock = clock;
        this.zone = zone;
        this.maxAttempts = maxAttempts;
    }

    public Accepted accept(String applicationId, String candidateId, String requestedBy, Map<String, Object> data) {
        if (applicationId == null || applicationId.isBlank()) {
            throw PlatformException.badRequest("APPLICATION_REQUIRED", "Application id is required");
        }
        Map<String, Object> source = new LinkedHashMap<>(data == null ? Map.of() : data);
        source.putIfAbsent("candidateId", candidateId);
        Map<String, Object> payload = mapper.map(source);
        List<FieldViolation> violations = validator.validate(payload, LocalDate.now(clock.withZone(zone)));
        if (!violations.isEmpty()) {
            audit.recordQuietly("INTEGRATION", "OFFER_VALIDATION_FAILED", "APPLICATION", applicationId, candidateId, AuditRecorder.FAILURE,
                    null, AuditRecorder.details("violations", FieldViolation.asMaps(violations)));
            throw PlatformException.unprocessable("OFFER_INVALID", "Offer failed pre-push validation", FieldViolation.asMaps(violations));
        }
        OfferSyncStore.Record existing = store.latestFor(applicationId).orElse(null);
        if (existing != null && ("PUSHED".equals(existing.status()) || "PENDING".equals(existing.status()) || "RETRY".equals(existing.status()))) {
            return new Accepted(existing.id(), existing.status(), existing.externalOfferId(), List.of());
        }
        String body = write(payload);
        OfferSyncStore.Record r = tx.execute(s -> store.create(applicationId, candidateId, body, requestedBy, clock.instant()));
        attempt(r);
        OfferSyncStore.Record after = store.find(r.id()).orElseThrow();
        return new Accepted(after.id(), after.status(), after.externalOfferId(), List.of());
    }

    public int retryDue(int limit) {
        int n = 0;
        for (OfferSyncStore.Record r : store.due(clock.instant(), limit)) {
            attempt(r);
            n++;
        }
        return n;
    }

    public void requeue(String syncId) {
        store.find(syncId).orElseThrow(() -> PlatformException.notFound("Offer sync", syncId));
        tx.execute(s -> {
            store.requeue(syncId, clock.instant());
            return null;
        });
        store.find(syncId).filter(r -> "RETRY".equals(r.status())).ifPresent(this::attempt);
    }

    public int poll(int limit) {
        int changed = 0;
        for (OfferSyncStore.Record r : store.inFlight(limit)) {
            try {
                OracleOfferClient.StatusResponse s = calls.call(INTEGRATION, "STATUS", r.externalOfferId(), r.externalOfferId(),
                        () -> {
                            OracleOfferClient.StatusResponse x = oracle.status(r.externalOfferId());
                            return new CallLog.Outcome<>(x, x.httpStatus());
                        }, x -> x.status());
                if (statusChanged(r, s.status(), "POLL")) {
                    changed++;
                }
            } catch (RuntimeException e) {
                audit.recordQuietly("INTEGRATION", "OFFER_STATUS_POLL_FAILED", "APPLICATION", r.applicationId(), r.candidateId(),
                        AuditRecorder.FAILURE, e.getMessage(), AuditRecorder.details("syncId", r.id()));
            }
        }
        return changed;
    }

    public boolean callback(String externalOfferId, String oracleStatus) {
        OfferSyncStore.Record r = store.byExternalId(externalOfferId)
                .orElseThrow(() -> PlatformException.notFound("Offer", externalOfferId));
        return statusChanged(r, oracleStatus, "CALLBACK");
    }

    public Map<String, Integer> reconcile(int limit) {
        int matched = 0;
        int corrected = 0;
        int failed = 0;
        Instant now = clock.instant();
        for (OfferSyncStore.Record r : store.inFlight(limit)) {
            try {
                OracleOfferClient.StatusResponse s = oracle.status(r.externalOfferId());
                if (s.status() != null && s.status().equalsIgnoreCase(r.oracleStatus())) {
                    matched++;
                    tx.execute(x -> {
                        store.reconciliation(r.id(), r.applicationId(), r.oracleStatus(), s.status(), "MATCHED", now);
                        return null;
                    });
                } else {
                    corrected++;
                    statusChanged(r, s.status(), "RECONCILIATION");
                    tx.execute(x -> {
                        store.reconciliation(r.id(), r.applicationId(), r.oracleStatus(), s.status(), "CORRECTED", now);
                        return null;
                    });
                }
            } catch (RuntimeException e) {
                failed++;
                tx.execute(x -> {
                    store.reconciliation(r.id(), r.applicationId(), r.oracleStatus(), null, "ERROR: " + e.getMessage(), now);
                    return null;
                });
            }
        }
        audit.recordQuietly("INTEGRATION", "OFFER_RECONCILIATION_COMPLETED", "INTEGRATION", INTEGRATION, null, AuditRecorder.SUCCESS, null,
                AuditRecorder.details("matched", matched, "corrected", corrected, "failed", failed));
        return Map.of("matched", matched, "corrected", corrected, "failed", failed);
    }

    private boolean statusChanged(OfferSyncStore.Record r, String oracleStatus, String via) {
        if (oracleStatus == null) {
            return false;
        }
        boolean terminal = OfferStatusMapper.terminal(oracleStatus);
        Boolean changed = tx.execute(s -> {
            if (!store.oracleStatus(r.id(), oracleStatus, terminal, clock.instant())) {
                return false;
            }
            Map<String, Object> p = new LinkedHashMap<>();
            p.put("syncId", r.id());
            p.put("externalOfferId", r.externalOfferId());
            p.put("oracleStatus", oracleStatus);
            p.put("via", via);
            outbox.append(OfferStatusMapper.eventFor(oracleStatus), "OFFER", r.id(), r.candidateId(), r.applicationId(), p);
            return true;
        });
        if (Boolean.TRUE.equals(changed)) {
            audit.recordQuietly("INTEGRATION", "OFFER_STATUS_SYNCED", "APPLICATION", r.applicationId(), r.candidateId(), AuditRecorder.SUCCESS,
                    oracleStatus, AuditRecorder.details("syncId", r.id(), "via", via, "terminal", terminal));
        }
        return Boolean.TRUE.equals(changed);
    }

    private void attempt(OfferSyncStore.Record r) {
        Map<String, Object> payload = read(r.payload());
        int attempts = r.attempts() + 1;
        Instant now = clock.instant();
        try {
            OracleOfferClient.PushResponse resp = calls.call(INTEGRATION, "PUSH", r.applicationId(), r.payload(), () -> {
                OracleOfferClient.PushResponse x = oracle.push("offer-" + r.id(), payload);
                return new CallLog.Outcome<>(x, x.httpStatus());
            }, x -> x.externalOfferId() + ":" + x.status());
            tx.execute(s -> {
                store.pushed(r.id(), resp.externalOfferId(), resp.status(), attempts, now);
                outbox.append("OFFER_PUSHED", "OFFER", r.id(), r.candidateId(), r.applicationId(),
                        Map.of("syncId", r.id(), "externalOfferId", String.valueOf(resp.externalOfferId()), "oracleStatus",
                                String.valueOf(resp.status())));
                return null;
            });
            audit.recordQuietly("INTEGRATION", "OFFER_PUSHED", "APPLICATION", r.applicationId(), r.candidateId(), AuditRecorder.SUCCESS, null,
                    AuditRecorder.details("syncId", r.id(), "externalOfferId", resp.externalOfferId(), "attempts", attempts));
        } catch (OracleOfferClient.OracleException e) {
            boolean park = !e.retryable() || OutboxBackoff.shouldPark(attempts, maxAttempts);
            tx.execute(s -> {
                store.failed(r.id(), park ? "PARKED" : "RETRY", attempts, park ? null : now.plus(OutboxBackoff.delay(attempts, 60, 3600)),
                        e.getMessage(), now);
                if (park) {
                    outbox.append(attempts == 1 && !e.retryable() ? "OFFER_PUSH_FAILED" : "OFFER_PARKED", "OFFER", r.id(), r.candidateId(),
                            r.applicationId(), Map.of("syncId", r.id(), "error", String.valueOf(e.getMessage()), "attempts", attempts));
                }
                return null;
            });
            audit.recordQuietly("INTEGRATION", park ? "OFFER_PUSH_PARKED" : "OFFER_PUSH_RETRY", "APPLICATION", r.applicationId(),
                    r.candidateId(), AuditRecorder.FAILURE, e.getMessage(), AuditRecorder.details("syncId", r.id(), "attempts", attempts));
        }
    }

    private String write(Map<String, Object> payload) {
        try {
            return json.writeValueAsString(payload);
        } catch (Exception e) {
            throw new IllegalStateException(e);
        }
    }

    private Map<String, Object> read(String payload) {
        try {
            return json.readValue(payload, MAP);
        } catch (Exception e) {
            throw new IllegalStateException(e);
        }
    }
}
