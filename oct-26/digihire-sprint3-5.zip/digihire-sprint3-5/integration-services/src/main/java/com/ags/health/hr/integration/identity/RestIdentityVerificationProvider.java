package com.ags.health.hr.integration.identity;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;
import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;

public class RestIdentityVerificationProvider implements IdentityVerificationProvider {

    private final HttpClient client;
    private final ObjectMapper mapper;
    private final String url;
    private final String apiKeyHeader;
    private final String apiKey;
    private final Duration timeout;

    public RestIdentityVerificationProvider(ObjectMapper mapper, String url, String apiKeyHeader, String apiKey, Duration timeout) {
        this.client = HttpClient.newBuilder().connectTimeout(timeout).build();
        this.mapper = mapper;
        this.url = url;
        this.apiKeyHeader = apiKeyHeader;
        this.apiKey = apiKey;
        this.timeout = timeout;
    }

    @Override
    public String code() {
        return "REST";
    }

    @Override
    public Result verify(Request r) {
        Map<String, Object> body = new LinkedHashMap<>();
        body.put("referenceId", r.reference());
        body.put("documentType", r.documentType());
        body.put("documentNumber", r.number());
        body.put("name", r.fullName());
        body.put("dob", r.dateOfBirth() == null ? null : r.dateOfBirth().toString());
        try {
            HttpResponse<String> resp = client.send(HttpRequest.newBuilder(URI.create(url)).timeout(timeout)
                    .header("Content-Type", "application/json").header(apiKeyHeader, apiKey)
                    .POST(HttpRequest.BodyPublishers.ofString(mapper.writeValueAsString(body))).build(), HttpResponse.BodyHandlers.ofString());
            if (resp.statusCode() == 429 || resp.statusCode() >= 500) {
                return new Result("ERROR", code(), null, null, "Provider returned " + resp.statusCode(), true);
            }
            JsonNode n = mapper.readTree(resp.body());
            if (resp.statusCode() / 100 != 2) {
                return new Result("INVALID", code(), null, null, n.path("message").asText("Provider rejected the request"), false);
            }
            String status = n.path("status").asText("").toUpperCase(Locale.ROOT);
            String mapped = switch (status) {
                case "VALID", "VERIFIED", "SUCCESS" -> "VERIFIED";
                case "NAME_MISMATCH", "MISMATCH" -> "MISMATCH";
                case "NOT_FOUND", "INVALID" -> "NOT_FOUND";
                default -> "MANUAL_REVIEW";
            };
            return new Result(mapped, code(), n.path("requestId").asText(null),
                    n.hasNonNull("nameMatchScore") ? n.get("nameMatchScore").asDouble() : null, n.path("message").asText(null), false);
        } catch (IOException e) {
            return new Result("ERROR", code(), null, null, "Provider call failed: " + e.getMessage(), true);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            return new Result("ERROR", code(), null, null, "Provider call interrupted", true);
        }
    }
}
