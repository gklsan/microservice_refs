package com.ags.health.hr.integration.identity;

import com.ags.health.hr.common.platform.validation.IdentityValidators;

import java.util.Locale;
import java.util.UUID;

public class StubIdentityVerificationProvider implements IdentityVerificationProvider {

    @Override
    public String code() {
        return "STUB";
    }

    @Override
    public Result verify(Request r) {
        IdentityValidators.Kind kind;
        try {
            kind = IdentityValidators.Kind.valueOf(r.documentType().toUpperCase(Locale.ROOT));
        } catch (RuntimeException e) {
            return new Result("INVALID", code(), null, null, "Unsupported document type", false);
        }
        if (IdentityValidators.check(kind, r.number()).isPresent()) {
            return new Result("INVALID", code(), null, null, "Number failed format check", false);
        }
        String n = IdentityValidators.normalise(kind, r.number());
        if (n.endsWith("0000")) {
            return new Result("NOT_FOUND", code(), "STUB-" + UUID.randomUUID(), null, "No record found", false);
        }
        if (n.endsWith("9999")) {
            return new Result("MISMATCH", code(), "STUB-" + UUID.randomUUID(), 0.2, "Name does not match", false);
        }
        return new Result("VERIFIED", code(), "STUB-" + UUID.randomUUID(), r.fullName() == null ? null : 1.0, "Verified by stub", false);
    }
}
