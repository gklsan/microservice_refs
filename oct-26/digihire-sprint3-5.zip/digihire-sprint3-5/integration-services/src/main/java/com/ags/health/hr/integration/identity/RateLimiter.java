package com.ags.health.hr.integration.identity;

import java.time.Clock;

public class RateLimiter {

    private final int perMinute;
    private final Clock clock;
    private double tokens;
    private long lastNanosMillis;

    public RateLimiter(int perMinute, Clock clock) {
        this.perMinute = Math.max(1, perMinute);
        this.clock = clock;
        this.tokens = this.perMinute;
        this.lastNanosMillis = clock.millis();
    }

    public synchronized boolean tryAcquire() {
        long now = clock.millis();
        tokens = Math.min(perMinute, tokens + (now - lastNanosMillis) * perMinute / 60000.0);
        lastNanosMillis = now;
        if (tokens >= 1) {
            tokens -= 1;
            return true;
        }
        return false;
    }
}
