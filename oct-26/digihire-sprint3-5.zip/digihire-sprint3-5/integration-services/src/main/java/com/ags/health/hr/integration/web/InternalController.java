package com.ags.health.hr.integration.web;

import com.ags.health.hr.common.platform.error.PlatformException;
import com.ags.health.hr.integration.face.FaceMatchProvider;
import com.ags.health.hr.integration.identity.IdentityService;
import com.ags.health.hr.integration.identity.IdentityVerificationProvider;
import com.ags.health.hr.integration.offer.OfferSyncService;
import com.ags.health.hr.integration.offer.OfferSyncStore;
import com.ags.health.hr.integration.calllog.CallLog;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import java.time.LocalDate;
import java.util.Base64;
import java.util.LinkedHashMap;
import java.util.Map;

@RestController
public class InternalController {

    public record OfferRequest(String applicationId, String candidateId, String requestedBy, Map<String, Object> data) {
    }

    public record VerifyRequest(String reference, String candidateId, String documentType, String number, String fullName,
                                String dateOfBirth) {
    }

    public record FaceRequest(String probe, String reference) {
    }

    private final OfferSyncService offers;
    private final OfferSyncStore offerStore;
    private final IdentityService identity;
    private final FaceMatchProvider faces;
    private final CallLog calls;
    private final int maxImageBytes;

    public InternalController(OfferSyncService offers, OfferSyncStore offerStore, IdentityService identity, FaceMatchProvider faces,
                              CallLog calls, com.ags.health.hr.integration.config.IntegrationProperties props) {
        this.offers = offers;
        this.offerStore = offerStore;
        this.identity = identity;
        this.faces = faces;
        this.calls = calls;
        this.maxImageBytes = props.getFace().getMaxImageBytes();
    }

    @PostMapping("/internal/offers")
    @ResponseStatus(HttpStatus.ACCEPTED)
    public OfferSyncService.Accepted pushOffer(@RequestBody OfferRequest body) {
        return offers.accept(body.applicationId(), body.candidateId(), body.requestedBy(), body.data());
    }

    @GetMapping("/internal/offers/{applicationId}")
    public Map<String, Object> offerStatus(@PathVariable String applicationId) {
        OfferSyncStore.Record r = offerStore.latestFor(applicationId).orElseThrow(() -> PlatformException.notFound("Offer", applicationId));
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("applicationId", r.applicationId());
        m.put("syncId", r.id());
        m.put("status", r.status());
        m.put("externalOfferId", r.externalOfferId());
        m.put("oracleStatus", r.oracleStatus());
        m.put("attempts", r.attempts());
        m.put("lastError", r.lastError());
        m.put("updatedAt", r.updatedAt().toString());
        return m;
    }

    @PostMapping("/internal/identity/verify")
    public IdentityVerificationProvider.Result verify(@RequestBody VerifyRequest body) {
        return identity.verify(new IdentityVerificationProvider.Request(body.reference(), body.candidateId(), body.documentType(),
                body.number(), body.fullName(), body.dateOfBirth() == null ? null : LocalDate.parse(body.dateOfBirth())));
    }

    @PostMapping("/internal/face/match")
    public Map<String, Object> face(@RequestBody FaceRequest body) {
        byte[] probe = decode(body.probe());
        byte[] reference = decode(body.reference());
        double score = calls.call("FACE", "MATCH", null, "{\"probe\":\"" + probe.length + " bytes\"}",
                () -> new CallLog.Outcome<>(faces.score(probe, reference), null), String::valueOf);
        return Map.of("score", score, "provider", faces.code());
    }

    private byte[] decode(String b64) {
        if (b64 == null || b64.isBlank() || b64.length() > maxImageBytes * 4L / 3 + 16) {
            throw PlatformException.badRequest("IMAGE_INVALID", "Image is missing or larger than " + maxImageBytes + " bytes");
        }
        try {
            return Base64.getDecoder().decode(b64);
        } catch (IllegalArgumentException e) {
            throw PlatformException.badRequest("IMAGE_INVALID", "Image must be base64");
        }
    }
}
