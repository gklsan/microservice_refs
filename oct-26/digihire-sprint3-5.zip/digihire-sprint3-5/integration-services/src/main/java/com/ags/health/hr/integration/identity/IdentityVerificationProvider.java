package com.ags.health.hr.integration.identity;

import java.time.LocalDate;

public interface IdentityVerificationProvider {

    record Request(String reference, String candidateId, String documentType, String number, String fullName, LocalDate dateOfBirth) {
    }

    record Result(String status, String provider, String verificationRef, Double nameMatchScore, String message, boolean retryable) {
    }

    String code();

    Result verify(Request request);
}
