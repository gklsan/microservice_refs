package com.ags.health.hr.integration.web;

import com.ags.health.hr.common.platform.caller.Caller;
import com.ags.health.hr.common.platform.caller.CallerProvider;
import com.ags.health.hr.common.platform.error.PlatformException;
import com.ags.health.hr.integration.calllog.CallLog;
import com.ags.health.hr.integration.offer.OfferSyncService;
import com.ags.health.hr.integration.offer.OfferSyncStore;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.Map;

@RestController
public class AdminController {

    public static final String VIEW = "INTEGRATION:VIEW";
    public static final String RETRY = "INTEGRATION:RETRY";

    private final CallLog calls;
    private final OfferSyncStore offers;
    private final OfferSyncService service;
    private final CallerProvider callers;

    public AdminController(CallLog calls, OfferSyncStore offers, OfferSyncService service, CallerProvider callers) {
        this.calls = calls;
        this.offers = offers;
        this.service = service;
        this.callers = callers;
    }

    @GetMapping("/call-log")
    public List<Map<String, Object>> callLog(@RequestParam(required = false) String integration,
                                             @RequestParam(required = false) String status, @RequestParam(defaultValue = "100") int limit) {
        require(VIEW);
        return calls.recent(integration, status, limit);
    }

    @GetMapping("/offers")
    public List<OfferSyncStore.Record> offers(@RequestParam(defaultValue = "PARKED") String status, @RequestParam(defaultValue = "100") int limit) {
        require(VIEW);
        return offers.byStatus(status.toUpperCase(), Math.min(limit, 500));
    }

    @PostMapping("/offers/{syncId}/retry")
    public OfferSyncStore.Record retry(@PathVariable String syncId) {
        require(RETRY);
        service.requeue(syncId);
        return offers.find(syncId).orElseThrow();
    }

    @PostMapping("/offers/reconcile")
    public Map<String, Integer> reconcile() {
        require(RETRY);
        return service.reconcile(500);
    }

    @GetMapping("/offers/reconciliation")
    public List<Map<String, Object>> reconciliation(@RequestParam(defaultValue = "200") int limit) {
        require(VIEW);
        return offers.reconciliationReport(Math.min(limit, 1000));
    }

    private Caller require(String permission) {
        Caller c = callers.require();
        if (!c.has(permission)) {
            throw PlatformException.forbidden("PERMISSION_DENIED", "Missing permission " + permission);
        }
        return c;
    }
}
