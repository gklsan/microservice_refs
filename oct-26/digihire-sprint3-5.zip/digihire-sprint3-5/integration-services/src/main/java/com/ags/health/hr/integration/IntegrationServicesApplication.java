package com.ags.health.hr.integration;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableScheduling;

@SpringBootApplication
@EnableScheduling
public class IntegrationServicesApplication {

    public static void main(String[] args) {
        SpringApplication.run(IntegrationServicesApplication.class, args);
    }
}
