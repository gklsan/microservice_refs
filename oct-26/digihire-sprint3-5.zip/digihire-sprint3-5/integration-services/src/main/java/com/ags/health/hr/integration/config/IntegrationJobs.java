package com.ags.health.hr.integration.config;

import com.ags.health.hr.common.platform.jobs.ScheduledJobRunner;
import com.ags.health.hr.integration.offer.IntegrationEventRelay;
import com.ags.health.hr.integration.offer.OfferSyncService;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.time.Duration;

@Component
public class IntegrationJobs {

    private final ScheduledJobRunner runner;
    private final OfferSyncService offers;
    private final IntegrationEventRelay relay;

    public IntegrationJobs(ScheduledJobRunner integJobRunner, OfferSyncService offers, IntegrationEventRelay relay) {
        this.runner = integJobRunner;
        this.offers = offers;
        this.relay = relay;
    }

    @Scheduled(cron = "${digihire.integration.offer.retry-cron:0 */5 * * * *}", zone = "${digihire.integration.zone:Asia/Kolkata}")
    public void retry() {
        runner.run("integration.offer-retry", Duration.ZERO, () -> offers.retryDue(100));
    }

    @Scheduled(cron = "${digihire.integration.offer.poll-cron:0 */20 * * * *}", zone = "${digihire.integration.zone:Asia/Kolkata}")
    public void poll() {
        runner.run("integration.offer-poll", Duration.ZERO, () -> offers.poll(200));
    }

    @Scheduled(cron = "${digihire.integration.offer.reconcile-cron:0 15 1 * * *}", zone = "${digihire.integration.zone:Asia/Kolkata}")
    public void reconcile() {
        runner.run("integration.offer-reconcile", Duration.ofMinutes(5), () -> offers.reconcile(2000));
    }

    @Scheduled(cron = "*/30 * * * * *", zone = "${digihire.integration.zone:Asia/Kolkata}")
    public void relay() {
        runner.run("integration.event-relay", Duration.ZERO, () -> relay.relay(100));
    }
}
