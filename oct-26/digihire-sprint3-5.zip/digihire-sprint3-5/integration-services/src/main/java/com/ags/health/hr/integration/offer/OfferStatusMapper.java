package com.ags.health.hr.integration.offer;

import java.util.Locale;

public final class OfferStatusMapper {

    private OfferStatusMapper() {
    }

    public static String eventFor(String oracleStatus) {
        if (oracleStatus == null) {
            return null;
        }
        return switch (oracleStatus.trim().toUpperCase(Locale.ROOT).replace(' ', '_')) {
            case "ACCEPTED", "ORA_ACCEPTED" -> "OFFER_ACCEPTED";
            case "REJECTED", "DECLINED", "CANDIDATE_DECLINED", "ORA_REJECTED" -> "OFFER_REJECTED";
            case "WITHDRAWN", "RESCINDED", "CANCELLED", "CANCELED" -> "OFFER_WITHDRAWN";
            case "HIRED", "PROCESSED", "HR_PROCESSED" -> "CANDIDATE_HIRED";
            case "EXTENDED", "SUBMITTED", "PENDING", "DRAFT", "APPROVED" -> "OFFER_STATUS_CHANGED";
            default -> "OFFER_STATUS_CHANGED";
        };
    }

    public static boolean terminal(String oracleStatus) {
        String e = eventFor(oracleStatus);
        return "OFFER_REJECTED".equals(e) || "OFFER_WITHDRAWN".equals(e) || "CANDIDATE_HIRED".equals(e);
    }
}
