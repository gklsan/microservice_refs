package com.ags.health.hr.integration.security;

import com.ags.health.hr.common.platform.caller.InternalKeyVerifier;
import com.ags.health.hr.common.platform.error.PlatformException;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.web.filter.OncePerRequestFilter;

import java.io.IOException;

public class InternalKeyFilter extends OncePerRequestFilter {

    private final InternalKeyVerifier keys;

    public InternalKeyFilter(InternalKeyVerifier keys) {
        this.keys = keys;
    }

    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain chain)
            throws ServletException, IOException {
        String path = request.getRequestURI().substring(request.getContextPath() == null ? 0 : request.getContextPath().length());
        if (path.startsWith("/internal/")) {
            try {
                keys.require(request);
            } catch (PlatformException e) {
                response.setStatus(e.getStatus());
                response.setContentType("application/problem+json");
                response.getWriter().write("{\"title\":\"" + e.getCode() + "\",\"status\":" + e.getStatus() + "}");
                return;
            }
        }
        chain.doFilter(request, response);
    }
}
