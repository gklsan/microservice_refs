package com.ags.health.hr.integration.offer;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

import java.sql.Timestamp;
import java.time.Instant;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

public class OfferSyncStore {

    public record Record(String id, String applicationId, String candidateId, String payload, String status, String externalOfferId,
                         String oracleStatus, int attempts, Instant nextAttemptAt, String lastError, String requestedBy,
                         Instant createdAt, Instant updatedAt) {
    }

    private static final String COLUMNS = "id, application_id, candidate_id, payload, status, external_offer_id, oracle_status, attempts, "
            + "next_attempt_at, last_error, requested_by, created_at, updated_at";
    private static final RowMapper<Record> ROW = (rs, i) -> new Record(rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4),
            rs.getString(5), rs.getString(6), rs.getString(7), rs.getInt(8), rs.getTimestamp(9) == null ? null : rs.getTimestamp(9).toInstant(),
            rs.getString(10), rs.getString(11), rs.getTimestamp(12).toInstant(), rs.getTimestamp(13).toInstant());

    private final JdbcTemplate jdbc;

    public OfferSyncStore(JdbcTemplate jdbc) {
        this.jdbc = jdbc;
    }

    public Record create(String applicationId, String candidateId, String payload, String requestedBy, Instant at) {
        String id = UUID.randomUUID().toString();
        jdbc.update("INSERT INTO integ_offer_sync (" + COLUMNS + ") VALUES (?, ?, ?, ?, 'PENDING', NULL, NULL, 0, ?, NULL, ?, ?, ?)", id,
                applicationId, candidateId, payload, Timestamp.from(at), requestedBy, Timestamp.from(at), Timestamp.from(at));
        return find(id).orElseThrow();
    }

    public Optional<Record> find(String id) {
        return jdbc.query("SELECT " + COLUMNS + " FROM integ_offer_sync WHERE id = ?", ROW, id).stream().findFirst();
    }

    public Optional<Record> latestFor(String applicationId) {
        return jdbc.query("SELECT " + COLUMNS + " FROM integ_offer_sync WHERE application_id = ? ORDER BY created_at DESC LIMIT 1", ROW,
                applicationId).stream().findFirst();
    }

    public Optional<Record> byExternalId(String externalOfferId) {
        return jdbc.query("SELECT " + COLUMNS + " FROM integ_offer_sync WHERE external_offer_id = ?", ROW, externalOfferId).stream().findFirst();
    }

    public List<Record> due(Instant now, int limit) {
        return jdbc.query("SELECT " + COLUMNS + " FROM integ_offer_sync WHERE status IN ('PENDING', 'RETRY') AND next_attempt_at <= ? "
                + "ORDER BY next_attempt_at LIMIT ?", ROW, Timestamp.from(now), limit);
    }

    public List<Record> inFlight(int limit) {
        return jdbc.query("SELECT " + COLUMNS + " FROM integ_offer_sync WHERE status = 'PUSHED' ORDER BY updated_at LIMIT ?", ROW, limit);
    }

    public List<Record> byStatus(String status, int limit) {
        return jdbc.query("SELECT " + COLUMNS + " FROM integ_offer_sync WHERE status = ? ORDER BY updated_at DESC LIMIT ?", ROW, status, limit);
    }

    public void pushed(String id, String externalOfferId, String oracleStatus, int attempts, Instant at) {
        jdbc.update("UPDATE integ_offer_sync SET status = 'PUSHED', external_offer_id = ?, oracle_status = ?, attempts = ?, "
                + "next_attempt_at = NULL, last_error = NULL, updated_at = ? WHERE id = ?", externalOfferId, oracleStatus, attempts,
                Timestamp.from(at), id);
    }

    public void failed(String id, String status, int attempts, Instant next, String error, Instant at) {
        jdbc.update("UPDATE integ_offer_sync SET status = ?, attempts = ?, next_attempt_at = ?, last_error = ?, updated_at = ? WHERE id = ?",
                status, attempts, next == null ? null : Timestamp.from(next), error == null ? null : error.length() > 500 ? error.substring(0, 500)
                        : error, Timestamp.from(at), id);
    }

    public boolean oracleStatus(String id, String oracleStatus, boolean terminal, Instant at) {
        return jdbc.update("UPDATE integ_offer_sync SET oracle_status = ?, status = ?, updated_at = ? WHERE id = ? AND "
                        + "(oracle_status IS NULL OR oracle_status <> ?)", oracleStatus, terminal ? "CLOSED" : "PUSHED", Timestamp.from(at), id,
                oracleStatus) == 1;
    }

    public void requeue(String id, Instant at) {
        jdbc.update("UPDATE integ_offer_sync SET status = 'RETRY', next_attempt_at = ?, updated_at = ? WHERE id = ? AND status = 'PARKED'",
                Timestamp.from(at), Timestamp.from(at), id);
    }

    public void reconciliation(String syncId, String applicationId, String ourStatus, String oracleStatus, String result, Instant at) {
        jdbc.update("INSERT INTO integ_offer_reconciliation (sync_id, application_id, our_status, oracle_status, result, checked_at) "
                + "VALUES (?, ?, ?, ?, ?, ?)", syncId, applicationId, ourStatus, oracleStatus, result, Timestamp.from(at));
    }

    public List<java.util.Map<String, Object>> reconciliationReport(int limit) {
        return jdbc.queryForList("SELECT sync_id, application_id, our_status, oracle_status, result, checked_at FROM "
                + "integ_offer_reconciliation ORDER BY checked_at DESC LIMIT ?", limit);
    }
}
