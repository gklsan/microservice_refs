package com.ags.health.hr.integration.web;

import com.ags.health.hr.common.platform.error.PlatformException;
import com.ags.health.hr.integration.offer.OfferSyncService;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RestController;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.HexFormat;
import java.util.Map;

@RestController
public class OracleCallbackController {

    private final OfferSyncService offers;
    private final ObjectMapper mapper;
    private final byte[] secret;

    public OracleCallbackController(OfferSyncService offers, ObjectMapper mapper,
                                    com.ags.health.hr.integration.config.IntegrationProperties props) {
        this.offers = offers;
        this.mapper = mapper;
        String s = props.getOffer().getCallbackSecret();
        this.secret = s == null || s.isBlank() ? null : s.getBytes(StandardCharsets.UTF_8);
    }

    @PostMapping("/callbacks/oracle/offers")
    public Map<String, Object> callback(@RequestHeader(value = "X-Signature", required = false) String signature, @RequestBody String body) {
        if (secret == null) {
            throw PlatformException.unavailable("CALLBACK_DISABLED", "Oracle callbacks are not configured");
        }
        if (body == null || body.length() > 65536) {
            throw PlatformException.badRequest("BODY_INVALID", "Callback body is missing or too large");
        }
        if (signature == null || !MessageDigest.isEqual(sign(body).getBytes(StandardCharsets.US_ASCII),
                signature.trim().toLowerCase().getBytes(StandardCharsets.US_ASCII))) {
            throw PlatformException.unauthorized("Invalid callback signature");
        }
        JsonNode n;
        try {
            n = mapper.readTree(body);
        } catch (Exception e) {
            throw PlatformException.badRequest("BODY_INVALID", "Callback body is not JSON");
        }
        String offerId = n.path("OfferId").asText(n.path("offerId").asText(null));
        String status = n.path("OfferStatus").asText(n.path("status").asText(null));
        if (offerId == null || status == null) {
            throw PlatformException.badRequest("BODY_INVALID", "OfferId and OfferStatus are required");
        }
        return Map.of("changed", offers.callback(offerId, status));
    }

    String sign(String body) {
        try {
            Mac mac = Mac.getInstance("HmacSHA256");
            mac.init(new SecretKeySpec(secret, "HmacSHA256"));
            return HexFormat.of().formatHex(mac.doFinal(body.getBytes(StandardCharsets.UTF_8)));
        } catch (Exception e) {
            throw new IllegalStateException(e);
        }
    }
}
