package com.ags.health.hr.integration.offer;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.Base64;
import java.util.Map;

public class RestOracleOfferClient implements OracleOfferClient {

    private final HttpClient client;
    private final ObjectMapper mapper;
    private final String baseUrl;
    private final String authorization;
    private final Duration timeout;

    public RestOracleOfferClient(ObjectMapper mapper, String baseUrl, String username, String password, Duration timeout) {
        this.client = HttpClient.newBuilder().connectTimeout(timeout).build();
        this.mapper = mapper;
        this.baseUrl = baseUrl.replaceAll("/+$", "");
        this.authorization = "Basic " + Base64.getEncoder().encodeToString((username + ":" + password).getBytes(StandardCharsets.UTF_8));
        this.timeout = timeout;
    }

    @Override
    public PushResponse push(String idempotencyKey, Map<String, Object> payload) {
        try {
            HttpResponse<String> r = client.send(HttpRequest.newBuilder(URI.create(baseUrl + "/recruitingCandidateOffers"))
                    .timeout(timeout).header("Authorization", authorization).header("Content-Type", "application/json")
                    .header("Idempotency-Key", idempotencyKey)
                    .POST(HttpRequest.BodyPublishers.ofString(mapper.writeValueAsString(payload))).build(), HttpResponse.BodyHandlers.ofString());
            JsonNode body = r.body() == null || r.body().isBlank() ? mapper.createObjectNode() : mapper.readTree(r.body());
            if (r.statusCode() / 100 != 2) {
                throw new OracleException("Oracle offer push returned " + r.statusCode() + ": " + body.path("title").asText(""),
                        r.statusCode(), r.statusCode() >= 500 || r.statusCode() == 429);
            }
            return new PushResponse(body.path("OfferId").asText(body.path("offerId").asText(null)),
                    body.path("OfferStatus").asText("SUBMITTED"), r.statusCode());
        } catch (IOException e) {
            throw new OracleException("Oracle offer push failed: " + e.getMessage(), 0, true);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            throw new OracleException("Oracle offer push interrupted", 0, true);
        }
    }

    @Override
    public StatusResponse status(String externalOfferId) {
        try {
            HttpResponse<String> r = client.send(HttpRequest.newBuilder(URI.create(baseUrl + "/recruitingCandidateOffers/" + externalOfferId))
                    .timeout(timeout).header("Authorization", authorization).GET().build(), HttpResponse.BodyHandlers.ofString());
            if (r.statusCode() / 100 != 2) {
                throw new OracleException("Oracle offer status returned " + r.statusCode(), r.statusCode(), r.statusCode() >= 500);
            }
            JsonNode body = mapper.readTree(r.body());
            return new StatusResponse(externalOfferId, body.path("OfferStatus").asText(null), r.statusCode());
        } catch (IOException e) {
            throw new OracleException("Oracle offer status failed: " + e.getMessage(), 0, true);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            throw new OracleException("Oracle offer status interrupted", 0, true);
        }
    }
}
