package com.ags.health.hr.integration.offer;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicInteger;

public class StubOracleOfferClient implements OracleOfferClient {

    private final Map<String, String> offers = new ConcurrentHashMap<>();
    private final Map<String, String> byKey = new ConcurrentHashMap<>();
    private final AtomicInteger seq = new AtomicInteger(1000);
    private volatile int failNext;

    public void failNext(int times) {
        this.failNext = times;
    }

    public void setStatus(String externalOfferId, String status) {
        offers.put(externalOfferId, status);
    }

    @Override
    public PushResponse push(String idempotencyKey, Map<String, Object> payload) {
        if (failNext > 0) {
            failNext--;
            throw new OracleException("Stub outage", 503, true);
        }
        String id = byKey.computeIfAbsent(idempotencyKey, k -> "OFR-" + seq.incrementAndGet());
        offers.putIfAbsent(id, "EXTENDED");
        return new PushResponse(id, offers.get(id), 201);
    }

    @Override
    public StatusResponse status(String externalOfferId) {
        String s = offers.get(externalOfferId);
        if (s == null) {
            throw new OracleException("Unknown offer " + externalOfferId, 404, false);
        }
        return new StatusResponse(externalOfferId, s, 200);
    }
}
