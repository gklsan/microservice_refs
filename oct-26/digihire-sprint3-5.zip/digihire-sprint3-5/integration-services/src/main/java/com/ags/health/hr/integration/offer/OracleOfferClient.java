package com.ags.health.hr.integration.offer;

import java.util.Map;

public interface OracleOfferClient {

    record PushResponse(String externalOfferId, String status, int httpStatus) {
    }

    record StatusResponse(String externalOfferId, String status, int httpStatus) {
    }

    class OracleException extends RuntimeException {

        private final boolean retryable;
        private final int status;

        public OracleException(String message, int status, boolean retryable) {
            super(message);
            this.status = status;
            this.retryable = retryable;
        }

        public boolean retryable() {
            return retryable;
        }

        public int status() {
            return status;
        }
    }

    PushResponse push(String idempotencyKey, Map<String, Object> payload);

    StatusResponse status(String externalOfferId);
}
