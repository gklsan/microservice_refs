package com.ags.health.hr.integration.web;

import com.ags.health.hr.common.platform.error.PlatformException;
import org.slf4j.MDC;
import org.springframework.http.HttpStatus;
import org.springframework.http.ProblemDetail;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

@RestControllerAdvice
public class IntegrationExceptionAdvice {

    @ExceptionHandler(PlatformException.class)
    public ResponseEntity<ProblemDetail> platform(PlatformException e) {
        ProblemDetail p = ProblemDetail.forStatusAndDetail(HttpStatus.valueOf(e.getStatus()), e.getMessage());
        p.setTitle(e.getCode());
        p.setProperty("code", e.getCode());
        if (MDC.get("correlationId") != null) {
            p.setProperty("correlationId", MDC.get("correlationId"));
        }
        if (e.getDetails() != null && !e.getDetails().isEmpty()) {
            p.setProperty("errors", e.getDetails());
        }
        return ResponseEntity.status(HttpStatus.valueOf(e.getStatus())).body(p);
    }
}
