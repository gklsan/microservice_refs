package com.ags.health.hr.integration.config;

import com.ags.health.hr.common.platform.audit.AuditRecorder;
import com.ags.health.hr.common.platform.audit.AuditTableInspector;
import com.ags.health.hr.common.platform.audit.LocalAuditLogTable;
import com.ags.health.hr.common.platform.audit.SharedAuditLogSink;
import com.ags.health.hr.common.platform.caller.CallerProvider;
import com.ags.health.hr.common.platform.caller.InternalKeyVerifier;
import com.ags.health.hr.common.platform.caller.JwtCallerProvider;
import com.ags.health.hr.common.platform.db.SchemaInitializer;
import com.ags.health.hr.common.platform.http.InternalHttp;
import com.ags.health.hr.common.platform.jobs.JobLock;
import com.ags.health.hr.common.platform.jobs.ScheduledJobRunner;
import com.ags.health.hr.common.platform.outbox.OutboxStore;
import com.ags.health.hr.integration.calllog.CallLog;
import com.ags.health.hr.integration.face.FaceMatchProvider;
import com.ags.health.hr.integration.face.RestFaceMatchProvider;
import com.ags.health.hr.integration.face.StubFaceMatchProvider;
import com.ags.health.hr.integration.identity.IdentityService;
import com.ags.health.hr.integration.identity.IdentityVerificationProvider;
import com.ags.health.hr.integration.identity.RateLimiter;
import com.ags.health.hr.integration.identity.RestIdentityVerificationProvider;
import com.ags.health.hr.integration.identity.StubIdentityVerificationProvider;
import com.ags.health.hr.integration.offer.IntegrationEventRelay;
import com.ags.health.hr.integration.offer.OfferPayloadMapper;
import com.ags.health.hr.integration.offer.OfferSyncService;
import com.ags.health.hr.integration.offer.OfferSyncStore;
import com.ags.health.hr.integration.offer.OfferValidator;
import com.ags.health.hr.integration.offer.OracleOfferClient;
import com.ags.health.hr.integration.offer.RestOracleOfferClient;
import com.ags.health.hr.integration.offer.StubOracleOfferClient;
import com.ags.health.hr.integration.security.CorrelationFilter;
import com.ags.health.hr.integration.security.InternalKeyFilter;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.Ordered;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.support.TransactionTemplate;

import javax.sql.DataSource;
import java.time.Clock;
import java.time.Duration;
import java.time.ZoneId;
import java.util.List;
import java.util.Map;

@Configuration
@EnableConfigurationProperties(IntegrationProperties.class)
public class IntegrationConfig {

    @Bean
    public Clock integClock() {
        return Clock.systemUTC();
    }

    @Bean(initMethod = "run")
    public SchemaInitializer integSchemaInitializer(DataSource dataSource) {
        return new SchemaInitializer(dataSource, List.of("db/schema-integration.sql"));
    }

    @Bean
    public InternalKeyVerifier integInternalKeyVerifier(IntegrationProperties props) {
        return new InternalKeyVerifier(props.getInternalKey(), props.getServiceKeys());
    }

    @Bean
    public FilterRegistrationBean<CorrelationFilter> integCorrelationFilter() {
        FilterRegistrationBean<CorrelationFilter> r = new FilterRegistrationBean<>(new CorrelationFilter());
        r.setOrder(Ordered.HIGHEST_PRECEDENCE);
        return r;
    }

    @Bean
    public FilterRegistrationBean<InternalKeyFilter> integInternalKeyFilter(InternalKeyVerifier keys) {
        FilterRegistrationBean<InternalKeyFilter> r = new FilterRegistrationBean<>(new InternalKeyFilter(keys));
        r.setOrder(Ordered.HIGHEST_PRECEDENCE + 10);
        return r;
    }

    @Bean
    public InternalHttp integInternalHttp(ObjectMapper mapper, IntegrationProperties props) {
        String key = props.getCandidateEventsKey() != null && !props.getCandidateEventsKey().isBlank() ? props.getCandidateEventsKey()
                : props.getInternalKey();
        return new InternalHttp(mapper, Duration.ofSeconds(props.getTimeoutSeconds()), key == null
                ? Map.of(InternalKeyVerifier.CALLER_HEADER, props.getServiceName())
                : Map.of(InternalKeyVerifier.HEADER, key, InternalKeyVerifier.CALLER_HEADER, props.getServiceName()));
    }

    @Bean
    @ConditionalOnMissingBean(CallerProvider.class)
    public CallerProvider integCallerProvider(InternalHttp integInternalHttp, IntegrationProperties props, Clock integClock) {
        return new JwtCallerProvider(props.getJwtSecret(), integInternalHttp, props.getAdminUrl(), Duration.ofSeconds(60), integClock);
    }

    @Bean
    public AuditRecorder integAuditRecorder(JdbcTemplate jdbc, ObjectMapper mapper, CallerProvider callers, IntegrationProperties props,
                                            Clock integClock) {
        if (AuditTableInspector.isH2(jdbc)) {
            LocalAuditLogTable.createIfMissingOnH2(jdbc, props.getAuditTable());
        }
        return new AuditRecorder(List.of(SharedAuditLogSink.create(jdbc, mapper, props.getAuditTable(), 4000)), callers,
                props.getServiceName(), integClock);
    }

    @Bean
    public TransactionTemplate integTransactionTemplate(PlatformTransactionManager tm) {
        return new TransactionTemplate(tm);
    }

    @Bean
    public ScheduledJobRunner integJobRunner(JdbcTemplate jdbc, Clock integClock, IntegrationProperties props) {
        return new ScheduledJobRunner(new JobLock(jdbc, integClock, "integ_job_lock"), props::isJobsEnabled, Duration.ofMinutes(15));
    }

    @Bean
    public OutboxStore integOutboxStore(JdbcTemplate jdbc, ObjectMapper mapper, Clock integClock) {
        return new OutboxStore(jdbc, mapper, integClock, "integ_outbox", new OutboxStore.Policy(12, 30, 3600));
    }

    @Bean
    public CallLog integCallLog(JdbcTemplate jdbc, Clock integClock) {
        return new CallLog(jdbc, integClock);
    }

    @Bean
    @ConditionalOnMissingBean(OracleOfferClient.class)
    public OracleOfferClient integOracleOfferClient(ObjectMapper mapper, IntegrationProperties props) {
        IntegrationProperties.Offer o = props.getOffer();
        if ("REST".equalsIgnoreCase(o.getMode())) {
            return new RestOracleOfferClient(mapper, o.getBaseUrl(), o.getUsername(), o.getPassword(), Duration.ofSeconds(props.getTimeoutSeconds()));
        }
        return new StubOracleOfferClient();
    }

    @Bean
    public OfferSyncStore integOfferSyncStore(JdbcTemplate jdbc) {
        return new OfferSyncStore(jdbc);
    }

    @Bean
    public OfferSyncService integOfferSyncService(OfferSyncStore store, OracleOfferClient oracle, CallLog calls, OutboxStore integOutboxStore,
                                                  AuditRecorder audit, TransactionTemplate tx, ObjectMapper mapper, Clock integClock,
                                                  IntegrationProperties props) {
        IntegrationProperties.Offer o = props.getOffer();
        return new OfferSyncService(store, new OfferPayloadMapper(o.getFieldMap()), new OfferValidator(o.getJoiningWindowDays()), oracle, calls,
                integOutboxStore, audit, tx, mapper, integClock, ZoneId.of(props.getZone()), o.getMaxAttempts());
    }

    @Bean
    public IntegrationEventRelay integEventRelay(OutboxStore integOutboxStore, InternalHttp integInternalHttp, IntegrationProperties props) {
        return new IntegrationEventRelay(integOutboxStore, integInternalHttp, props.getCandidateEventsUrl());
    }

    @Bean
    @ConditionalOnMissingBean(IdentityVerificationProvider.class)
    public IdentityVerificationProvider integIdentityProvider(ObjectMapper mapper, IntegrationProperties props) {
        IntegrationProperties.Identity i = props.getIdentity();
        if ("REST".equalsIgnoreCase(i.getMode())) {
            return new RestIdentityVerificationProvider(mapper, i.getUrl(), i.getApiKeyHeader(), i.getApiKey(),
                    Duration.ofSeconds(props.getTimeoutSeconds()));
        }
        return new StubIdentityVerificationProvider();
    }

    @Bean
    public IdentityService integIdentityService(IdentityVerificationProvider provider, CallLog calls, AuditRecorder audit, Clock integClock,
                                                IntegrationProperties props) {
        return new IdentityService(provider, new RateLimiter(props.getIdentity().getRequestsPerMinute(), integClock), calls, audit);
    }

    @Bean
    @ConditionalOnMissingBean(FaceMatchProvider.class)
    public FaceMatchProvider integFaceProvider(ObjectMapper mapper, IntegrationProperties props) {
        IntegrationProperties.Face f = props.getFace();
        if ("REST".equalsIgnoreCase(f.getMode())) {
            return new RestFaceMatchProvider(mapper, f.getUrl(), f.getApiKey(), Duration.ofSeconds(props.getTimeoutSeconds()));
        }
        return new StubFaceMatchProvider(0.85);
    }
}
