package com.ags.health.hr.integration.offer;

import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;

public class OfferPayloadMapper {

    public static final Map<String, String> DEFAULTS = defaults();

    private final Map<String, String> mapping;

    public OfferPayloadMapper(Map<String, String> overrides) {
        Map<String, String> m = new LinkedHashMap<>(DEFAULTS);
        if (overrides != null) {
            m.putAll(overrides);
        }
        this.mapping = Map.copyOf(m);
    }

    private static Map<String, String> defaults() {
        Map<String, String> m = new LinkedHashMap<>();
        m.put("CandidateNumber", "candidateId");
        m.put("FirstName", "firstName");
        m.put("LastName", "lastName");
        m.put("Email", "email|lower");
        m.put("PhoneNumber", "mobile");
        m.put("DateOfBirth", "dateOfBirth");
        m.put("NationalId", "panNumber|upper");
        m.put("RequisitionNumber", "requisitionId");
        m.put("JobTitle", "designation");
        m.put("Department", "lob|upper");
        m.put("WorkLocation", "location|upper");
        m.put("Grade", "grade");
        m.put("SalaryAmount", "offeredCtc|number");
        m.put("SalaryCurrency", "currency|default:INR");
        m.put("StartDate", "joiningDate");
        m.put("RecruiterEmail", "recruiterEmail|lower");
        m.put("HiringManagerEmail", "hiringManagerEmail|lower");
        return m;
    }

    public Map<String, Object> map(Map<String, Object> data) {
        Map<String, Object> out = new LinkedHashMap<>();
        mapping.forEach((target, spec) -> {
            String[] parts = spec.split("\\|");
            Object v = data == null ? null : data.get(parts[0]);
            for (int i = 1; i < parts.length; i++) {
                v = transform(v, parts[i]);
            }
            if (v != null && !(v instanceof String s && s.isBlank())) {
                out.put(target, v);
            }
        });
        return out;
    }

    public Map<String, String> mapping() {
        return mapping;
    }

    private static Object transform(Object v, String op) {
        if (op.startsWith("default:")) {
            return v == null || String.valueOf(v).isBlank() ? op.substring(8) : v;
        }
        if (v == null) {
            return null;
        }
        return switch (op) {
            case "upper" -> String.valueOf(v).trim().toUpperCase(Locale.ROOT);
            case "lower" -> String.valueOf(v).trim().toLowerCase(Locale.ROOT);
            case "number" -> v instanceof Number n ? n : parse(String.valueOf(v));
            default -> v;
        };
    }

    private static Object parse(String s) {
        try {
            return new java.math.BigDecimal(s.replace(",", "").trim());
        } catch (NumberFormatException e) {
            return s;
        }
    }
}
