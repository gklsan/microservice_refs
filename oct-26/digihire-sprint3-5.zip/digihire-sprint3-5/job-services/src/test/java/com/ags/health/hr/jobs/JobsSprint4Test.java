package com.ags.health.hr.jobs;

import com.ags.health.hr.common.platform.approval.ApprovalChain;
import com.ags.health.hr.common.platform.approval.ApprovalPort;
import com.ags.health.hr.common.platform.audit.AuditRecorder;
import com.ags.health.hr.common.platform.audit.LocalAuditLogTable;
import com.ags.health.hr.common.platform.audit.SharedAuditLogSink;
import com.ags.health.hr.common.platform.caller.Caller;
import com.ags.health.hr.common.platform.db.SchemaInitializer;
import com.ags.health.hr.common.platform.error.PlatformException;
import com.ags.health.hr.common.platform.time.BusinessClock;
import com.ags.health.hr.jobs.jdedit.JdChangeStore;
import com.ags.health.hr.jobs.jdedit.JdEditService;
import com.ags.health.hr.jobs.jdedit.JdSanitizer;
import com.ags.health.hr.jobs.listing.JobVisibilityPolicy;
import com.ags.health.hr.jobs.listing.ListingService;
import com.ags.health.hr.jobs.listing.LocalPublicationPort;
import com.ags.health.hr.jobs.listing.PublicationStore;
import com.ags.health.hr.jobs.listing.RequisitionRecord;
import com.ags.health.hr.jobs.listing.RequisitionStore;
import com.ags.health.hr.jobs.sync.FieldMapping;
import com.ags.health.hr.jobs.sync.RequisitionSyncService;
import com.ags.health.hr.jobs.sync.StubOracleRequisitionSource;
import com.ags.health.hr.jobs.sync.SyncStore;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.transaction.support.TransactionTemplate;

import java.time.Clock;
import java.time.Instant;
import java.time.ZoneId;
import java.time.ZoneOffset;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

class JobsSprint4Test {

    private static final Instant NOW = Instant.parse("2026-10-20T05:30:00Z");
    private final ObjectMapper mapper = new ObjectMapper();
    private JdbcTemplate jdbc;
    private TransactionTemplate tx;
    private AuditRecorder audit;
    private RequisitionStore store;
    private ListingService listing;
    private SyncStore syncStore;
    private final StubOracleRequisitionSource oracle = new StubOracleRequisitionSource();
    private RequisitionSyncService sync;
    private final Clock clock = Clock.fixed(NOW, ZoneOffset.UTC);

    private static Caller user(String id, String... perms) {
        return new Caller(id, id + "@agshealth.com", id, Set.of("RECRUITER"), Set.of(perms), Set.of(), "OWN", Set.of(), Set.of(), Set.of(), false);
    }

    @BeforeEach
    void setUp() {
        DriverManagerDataSource ds = TestDatabase.create("jobs", List.of("db/p5/job-p5-schema.sql"));
        jdbc = new JdbcTemplate(ds);
        tx = new TransactionTemplate(new DataSourceTransactionManager(ds));
        audit = new AuditRecorder(List.of(SharedAuditLogSink.create(jdbc, mapper, "audit_log", 4000)), Optional::empty, "job-services", clock);
        store = new RequisitionStore(jdbc);
        listing = new ListingService(store, new PublicationStore(jdbc), List.of(new LocalPublicationPort("CAREER_PAGE"),
                new LocalPublicationPort("BUDDY_FINDER")), new JobVisibilityPolicy(), audit, new BusinessClock(clock, ZoneId.of("Asia/Kolkata")));
        syncStore = new SyncStore(jdbc);
        sync = new RequisitionSyncService(oracle, new FieldMapping(Map.of()), syncStore, store, listing, List.of(), tx, audit, mapper, clock,
                new RequisitionSyncService.Settings(25, 100, 3));
    }

    private ObjectNode req(String number, String lob, String status, int openings, int hired, String updated) {
        ObjectNode n = mapper.createObjectNode();
        n.put("RequisitionNumber", number).put("RequisitionId", "ORC" + number).put("Title", "Analyst " + number)
                .put("OrganizationName", lob).put("PrimaryLocation", "Chennai").put("CurrentPhaseCode", status)
                .put("NumberOfOpenings", openings).put("HiredCount", hired).put("LastUpdateDate", updated).put("JobFamilyName", "AR");
        return n;
    }

    @Test
    void fullSyncPagesThroughOracleAndHidesInvalidJobs() {
        for (int i = 0; i < 60; i++) {
            oracle.add(req("R" + i, "LOB1", "OPEN", 2, 0, "2026-10-1" + (i % 9) + "T00:00:00Z"));
        }
        oracle.add(req("FULL", "LOB1", "OPEN", 1, 1, "2026-10-19T00:00:00Z"));
        oracle.add(req("CLOSED", "LOB1", "CLOSED", 1, 0, "2026-10-19T00:00:00Z"));
        oracle.add(req("BAD", "LOB1", "SOMETHING", 1, 0, "2026-10-19T00:00:00Z"));
        RequisitionSyncService.RunResult r = sync.run(true, "TEST");
        assertThat(r.fetched()).isEqualTo(63);
        assertThat(r.hidden()).isEqualTo(3);
        assertThat(store.find("FULL").orElseThrow().hiddenReason()).isEqualTo("NO_OPENINGS");
        assertThat(store.find("BAD").orElseThrow().hiddenReason()).isEqualTo("MAPPING_INCONSISTENT");
        assertThat(syncStore.openIssues(10)).extracting(m -> m.get("CODE") != null ? m.get("CODE") : m.get("code")).contains("UNKNOWN_STATUS");
        assertThat(listing.search(user("rec", "JOB:VIEW"), new RequisitionStore.Filter(null, null, null, null, null, null), 0, 25, false)
                .total()).isEqualTo(60);
    }

    @Test
    void incrementalUsesTheWatermarkAndFailuresAreRetried() {
        oracle.add(req("A", "LOB1", "OPEN", 2, 0, "2026-10-10T00:00:00Z"));
        sync.run(false, "TEST");
        oracle.clear();
        oracle.add(req("A", "LOB1", "OPEN", 2, 0, "2026-10-10T00:00:00Z"));
        ObjectNode broken = req("B", "LOB1", "OPEN", 2, 0, "2026-10-12T00:00:00Z");
        broken.put("NumberOfOpenings", "many");
        oracle.add(broken);
        RequisitionSyncService.RunResult r = sync.run(false, "TEST");
        assertThat(r.fetched()).isEqualTo(1);
        assertThat(store.find("B").orElseThrow().visible()).isFalse();
        oracle.failWith(new IllegalStateException("Oracle 503"));
        assertThat(sync.run(false, "TEST").status()).isEqualTo("FAILED");
        assertThat(syncStore.watermark(RequisitionSyncService.KIND)).contains(Instant.parse("2026-10-12T00:00:00Z"));
    }

    @Test
    void unknownLobIsInconsistentOnceTheLobMasterIsLoaded() {
        oracle.addLob(mapper.createObjectNode().put("OrganizationName", "LOB1").put("Status", "ACTIVE"));
        sync.syncLobs();
        oracle.add(req("X", "LOB9", "OPEN", 1, 0, "2026-10-12T00:00:00Z"));
        sync.run(true, "TEST");
        assertThat(store.find("X").orElseThrow().hiddenReason()).isEqualTo("MAPPING_INCONSISTENT");
    }

    @Test
    void publishingNeedsPermissionAndHiddenJobsAreWithdrawnAutomatically() {
        oracle.add(req("P", "LOB1", "OPEN", 1, 0, "2026-10-12T00:00:00Z"));
        sync.run(true, "TEST");
        assertThatThrownBy(() -> listing.publish(user("rec", "JOB:VIEW"), "P", "CAREER_PAGE")).hasMessageContaining("JOB:PUBLISH");
        Caller tl = user("tl", "JOB:PUBLISH", "JOB:VIEW");
        listing.publish(tl, "P", "CAREER_PAGE");
        listing.publish(tl, "P", "buddy_finder");
        oracle.clear();
        oracle.add(req("P", "LOB1", "OPEN", 1, 1, "2026-10-13T00:00:00Z"));
        sync.run(false, "TEST");
        assertThat(listing.details(tl, "P").get("publications").toString()).contains("UNPUBLISHED", "AUTO_NO_OPENINGS");
        assertThatThrownBy(() -> listing.publish(tl, "P", "CAREER_PAGE")).hasMessageContaining("hidden");
    }

    @Test
    void jdEditNeedsTaHeadApprovalAndAppliesOnFinalLevel() {
        oracle.add(req("J", "LOB1", "OPEN", 1, 0, "2026-10-12T00:00:00Z"));
        sync.run(true, "TEST");
        ApprovalPort approvals = new ApprovalPort() {
            @Override
            public ApprovalChain resolve(String flow, String id, String email, String lob, String location) {
                return new ApprovalChain(flow, 1, List.of(List.of("head")), true);
            }

            @Override
            public boolean canApprove(String flow, int level, String approverId, String email, String requesterId, String requesterEmail,
                                      String lob, String location) {
                return "head".equals(approverId);
            }
        };
        String[] applied = new String[1];
        JdEditService jd = new JdEditService(new JdChangeStore(jdbc), store, approvals, (r, j, text, v) -> applied[0] = text + "#" + v,
                listing, audit, clock, 20000);
        Caller rec = user("rec", "JOB:EDIT_JD");
        JdChangeStore.Change c = jd.request(rec, "J", "<p onclick=\"x()\">New <script>alert(1)</script>JD</p>", "Client asked");
        assertThat(c.proposedJd()).isEqualTo("<p>New JD</p>");
        assertThatThrownBy(() -> jd.request(rec, "J", "again", "x")).hasMessageContaining("already waiting");
        assertThatThrownBy(() -> jd.decide(user("other"), c.id(), "APPROVE", null)).isInstanceOf(PlatformException.class);
        assertThat(jd.inbox(user("head"))).hasSize(1);
        jd.decide(user("head"), c.id(), "APPROVE", "ok");
        assertThat(store.find("J").orElseThrow().jd()).isEqualTo("<p>New JD</p>");
        assertThat(applied[0]).isEqualTo("<p>New JD</p>#1");
        assertThat(JdSanitizer.clean("<a href=\"javascript:alert(1)\">x</a><b>ok</b>", 100)).isEqualTo("x<b>ok</b>");
    }

    @Test
    void manualRecordKeepsItsApprovedJdOnSync() {
        store.upsert(new RequisitionRecord("K", "J1", "T", "LOB1", "CHENNAI", "ORC", "AR", "OPEN", 1, 0, null, null, "approved", 2, "ORACLE",
                null, true, null, NOW));
        ObjectNode n = req("K", "LOB1", "OPEN", 1, 0, "2026-10-12T00:00:00Z");
        n.put("ExternalDescriptionStr", "oracle text");
        oracle.add(n);
        sync.run(true, "TEST");
        assertThat(store.find("K").orElseThrow().jd()).isEqualTo("approved");
    }
}
