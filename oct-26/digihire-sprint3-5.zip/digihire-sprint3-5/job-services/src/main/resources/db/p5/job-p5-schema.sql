CREATE TABLE IF NOT EXISTS job_p5_job_lock (
    name            VARCHAR(80)   PRIMARY KEY,
    locked_until    TIMESTAMP WITH TIME ZONE  NOT NULL,
    locked_at       TIMESTAMP WITH TIME ZONE  NOT NULL,
    locked_by       VARCHAR(160)  NOT NULL
)@@

CREATE TABLE IF NOT EXISTS job_p5_requisition (
    requisition_id     VARCHAR(64)   PRIMARY KEY,
    job_id             VARCHAR(64),
    title              VARCHAR(300),
    lob                VARCHAR(100),
    location           VARCHAR(100),
    orc_id             VARCHAR(64),
    role_code          VARCHAR(100),
    status             VARCHAR(30),
    openings           INT           NOT NULL DEFAULT 0,
    filled             INT           NOT NULL DEFAULT 0,
    valid_to           DATE,
    recruiter_id       VARCHAR(64),
    jd                 TEXT,
    jd_version         INT           NOT NULL DEFAULT 0,
    source             VARCHAR(20)   NOT NULL,
    source_updated_at  TIMESTAMP WITH TIME ZONE,
    visible            BOOLEAN       NOT NULL DEFAULT FALSE,
    hidden_reason      VARCHAR(40),
    updated_at         TIMESTAMP WITH TIME ZONE  NOT NULL
)@@
CREATE INDEX IF NOT EXISTS ix_job_p5_req_visible ON job_p5_requisition (visible, updated_at)@@
CREATE INDEX IF NOT EXISTS ix_job_p5_req_lob ON job_p5_requisition (lob, location)@@
CREATE INDEX IF NOT EXISTS ix_job_p5_req_updated ON job_p5_requisition (updated_at)@@

CREATE TABLE IF NOT EXISTS job_p5_publication (
    requisition_id  VARCHAR(64)   NOT NULL,
    channel         VARCHAR(30)   NOT NULL,
    status          VARCHAR(20)   NOT NULL,
    external_ref    VARCHAR(200),
    published_by    VARCHAR(64),
    published_at    TIMESTAMP WITH TIME ZONE,
    unpublished_at  TIMESTAMP WITH TIME ZONE,
    reason          VARCHAR(60),
    PRIMARY KEY (requisition_id, channel)
)@@

CREATE TABLE IF NOT EXISTS job_p5_jd_change (
    id                  VARCHAR(36)   PRIMARY KEY,
    requisition_id      VARCHAR(64)   NOT NULL,
    base_version        INT           NOT NULL,
    proposed_jd         TEXT          NOT NULL,
    reason              VARCHAR(1000) NOT NULL,
    status              VARCHAR(20)   NOT NULL,
    current_level       INT           NOT NULL,
    total_levels        INT           NOT NULL,
    requested_by        VARCHAR(64)   NOT NULL,
    requested_by_email  VARCHAR(254),
    requested_at        TIMESTAMP WITH TIME ZONE  NOT NULL,
    decided_at          TIMESTAMP WITH TIME ZONE
)@@
CREATE INDEX IF NOT EXISTS ix_job_p5_jd_change ON job_p5_jd_change (status, requisition_id)@@

CREATE TABLE IF NOT EXISTS job_p5_jd_change_action (
    change_id    VARCHAR(36)   NOT NULL REFERENCES job_p5_jd_change (id),
    level_no     INT           NOT NULL,
    approver_id  VARCHAR(64)   NOT NULL,
    decision     VARCHAR(20)   NOT NULL,
    remarks      VARCHAR(1000),
    decided_at   TIMESTAMP WITH TIME ZONE  NOT NULL
)@@

CREATE TABLE IF NOT EXISTS job_p5_sync_run (
    id              VARCHAR(36)   PRIMARY KEY,
    kind            VARCHAR(20)   NOT NULL,
    trigger_source  VARCHAR(100)  NOT NULL,
    status          VARCHAR(20)   NOT NULL,
    watermark_from  TIMESTAMP WITH TIME ZONE,
    watermark_to    TIMESTAMP WITH TIME ZONE,
    started_at      TIMESTAMP WITH TIME ZONE  NOT NULL,
    finished_at     TIMESTAMP WITH TIME ZONE,
    fetched         INT           NOT NULL,
    upserted        INT           NOT NULL,
    failed          INT           NOT NULL,
    hidden          INT           NOT NULL,
    error           VARCHAR(500)
)@@

CREATE TABLE IF NOT EXISTS job_p5_sync_state (
    kind        VARCHAR(40)   PRIMARY KEY,
    watermark   TIMESTAMP WITH TIME ZONE,
    updated_at  TIMESTAMP WITH TIME ZONE  NOT NULL
)@@

CREATE TABLE IF NOT EXISTS job_p5_sync_failure (
    id               VARCHAR(36)   PRIMARY KEY,
    run_id           VARCHAR(36),
    external_id      VARCHAR(64)   NOT NULL,
    payload          VARCHAR(8000),
    error            VARCHAR(500),
    attempts         INT           NOT NULL,
    status           VARCHAR(20)   NOT NULL,
    next_attempt_at  TIMESTAMP WITH TIME ZONE,
    created_at       TIMESTAMP WITH TIME ZONE  NOT NULL,
    updated_at       TIMESTAMP WITH TIME ZONE  NOT NULL
)@@
CREATE INDEX IF NOT EXISTS ix_job_p5_sync_failure ON job_p5_sync_failure (status, next_attempt_at)@@

CREATE TABLE IF NOT EXISTS job_p5_sync_issue (
    external_id  VARCHAR(64)   NOT NULL,
    run_id       VARCHAR(36),
    field_name   VARCHAR(60)   NOT NULL,
    code         VARCHAR(40)   NOT NULL,
    message      VARCHAR(500),
    critical     BOOLEAN       NOT NULL,
    created_at   TIMESTAMP WITH TIME ZONE  NOT NULL
)@@
CREATE INDEX IF NOT EXISTS ix_job_p5_sync_issue ON job_p5_sync_issue (external_id)@@

CREATE TABLE IF NOT EXISTS job_p5_lob (
    code        VARCHAR(100)  PRIMARY KEY,
    name        VARCHAR(200),
    active      BOOLEAN       NOT NULL,
    updated_at  TIMESTAMP WITH TIME ZONE  NOT NULL
)@@
