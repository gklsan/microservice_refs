package com.ags.health.hr.jobs.sync;

import com.fasterxml.jackson.databind.JsonNode;

import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

public class StubOracleRequisitionSource implements OracleRequisitionSource {

    private final List<JsonNode> requisitions = new CopyOnWriteArrayList<>();
    private final List<JsonNode> lobs = new CopyOnWriteArrayList<>();
    private volatile RuntimeException failure;

    public void add(JsonNode requisition) {
        requisitions.add(requisition);
    }

    public void addLob(JsonNode lob) {
        lobs.add(lob);
    }

    public void clear() {
        requisitions.clear();
    }

    public void failWith(RuntimeException e) {
        this.failure = e;
    }

    @Override
    public Page requisitions(Instant updatedAfter, int offset, int limit) {
        if (failure != null) {
            throw failure;
        }
        List<JsonNode> matching = new ArrayList<>();
        for (JsonNode n : requisitions) {
            String u = n.path("LastUpdateDate").asText(null);
            if (updatedAfter == null || u == null || Instant.parse(u).isAfter(updatedAfter)) {
                matching.add(n);
            }
        }
        int to = Math.min(matching.size(), offset + limit);
        List<JsonNode> page = offset >= matching.size() ? List.of() : matching.subList(offset, to);
        return new Page(List.copyOf(page), to < matching.size(), (long) matching.size());
    }

    @Override
    public List<JsonNode> lobs() {
        return List.copyOf(lobs);
    }
}
