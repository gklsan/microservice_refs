package com.ags.health.hr.jobs.jdedit;

import com.ags.health.hr.common.platform.caller.CallerProvider;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.Map;

@ConditionalOnProperty(prefix = "digihire.jobs", name = "enabled", havingValue = "true", matchIfMissing = true)
@RestController
public class JdEditController {

    public record JdRequest(String jd, String reason) {
    }

    public record DecisionRequest(String decision, String remarks) {
    }

    private final JdEditService service;
    private final CallerProvider callers;

    public JdEditController(JdEditService service, CallerProvider callers) {
        this.service = service;
        this.callers = callers;
    }

    @PostMapping("/requisitions/{requisitionId}/jd-changes")
    public JdChangeStore.Change request(@PathVariable String requisitionId, @RequestBody JdRequest body) {
        return service.request(callers.require(), requisitionId, body.jd(), body.reason());
    }

    @GetMapping("/jd-changes/inbox")
    public List<JdChangeStore.Change> inbox() {
        return service.inbox(callers.require());
    }

    @GetMapping("/jd-changes/{changeId}")
    public Map<String, Object> details(@PathVariable String changeId) {
        return service.details(callers.require(), changeId);
    }

    @PostMapping("/jd-changes/{changeId}/decision")
    public JdChangeStore.Change decide(@PathVariable String changeId, @RequestBody DecisionRequest body) {
        return service.decide(callers.require(), changeId, body.decision(), body.remarks());
    }
}
