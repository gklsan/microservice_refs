package com.ags.health.hr.jobs.p5shared;

import lombok.Getter;
import lombok.Setter;
import org.springframework.boot.context.properties.ConfigurationProperties;

import java.util.LinkedHashMap;
import java.util.Map;

@Getter
@Setter
@ConfigurationProperties(prefix = "digihire.jobs")
public class JobsP5Properties {

    private boolean enabled = true;
    private String serviceName = "job-services";
    private boolean schemaInit = true;
    private String jwtSecret;
    private String internalKey;
    private String serviceKeys;
    private String adminUrl = "http://localhost:8989/admin-services";
    private int timeoutSeconds = 15;
    private String auditTable = "audit_log";
    private String zone = "Asia/Kolkata";
    private boolean jobsEnabled = true;
    private int maxJdLength = 20000;
    private Oracle oracle = new Oracle();

    @Getter
    @Setter
    public static class Oracle {
        private String mode = "STUB";
        private String requisitionsUrl;
        private String lobUrl;
        private String username;
        private String password;
        private int pageSize = 25;
        private int maxPages = 400;
        private int maxAttempts = 6;
        private Map<String, String> fieldMap = new LinkedHashMap<>();
        private String incrementalCron = "0 */15 * * * *";
        private String retryCron = "0 5 * * * *";
        private String lobCron = "0 30 2 * * *";
    }
}
