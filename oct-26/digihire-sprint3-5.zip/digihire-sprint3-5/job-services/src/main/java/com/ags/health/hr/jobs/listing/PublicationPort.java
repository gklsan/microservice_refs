package com.ags.health.hr.jobs.listing;

public interface PublicationPort {

    String channel();

    String publish(RequisitionRecord requisition);

    void unpublish(RequisitionRecord requisition, String externalRef);
}
