package com.ags.health.hr.jobs.sync;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.io.IOException;
import java.net.URI;
import java.net.URLEncoder;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.time.Instant;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Base64;
import java.util.List;

public class RestOracleRequisitionSource implements OracleRequisitionSource {

    private final HttpClient client;
    private final ObjectMapper mapper;
    private final String requisitionsUrl;
    private final String lobUrl;
    private final String authorization;
    private final Duration timeout;

    public RestOracleRequisitionSource(ObjectMapper mapper, String requisitionsUrl, String lobUrl, String username, String password,
                                       Duration timeout) {
        this.client = HttpClient.newBuilder().connectTimeout(timeout).build();
        this.mapper = mapper;
        this.requisitionsUrl = requisitionsUrl;
        this.lobUrl = lobUrl;
        this.authorization = "Basic " + Base64.getEncoder().encodeToString((username + ":" + password).getBytes(StandardCharsets.UTF_8));
        this.timeout = timeout;
    }

    @Override
    public Page requisitions(Instant updatedAfter, int offset, int limit) {
        StringBuilder url = new StringBuilder(requisitionsUrl);
        url.append(requisitionsUrl.contains("?") ? "&" : "?").append("totalResults=true&limit=").append(limit).append("&offset=").append(offset);
        if (updatedAfter != null) {
            String q = "LastUpdateDate>\"" + DateTimeFormatter.ISO_INSTANT.format(updatedAfter) + "\"";
            url.append("&q=").append(URLEncoder.encode(q, StandardCharsets.UTF_8));
        }
        JsonNode body = get(url.toString());
        List<JsonNode> items = new ArrayList<>();
        body.path("items").forEach(items::add);
        return new Page(items, body.path("hasMore").asBoolean(false), body.hasNonNull("totalResults") ? body.get("totalResults").asLong() : null);
    }

    @Override
    public List<JsonNode> lobs() {
        if (lobUrl == null || lobUrl.isBlank()) {
            return List.of();
        }
        List<JsonNode> out = new ArrayList<>();
        int offset = 0;
        while (offset < 10_000) {
            JsonNode body = get(lobUrl + (lobUrl.contains("?") ? "&" : "?") + "limit=200&offset=" + offset);
            body.path("items").forEach(out::add);
            if (!body.path("hasMore").asBoolean(false)) {
                break;
            }
            offset += 200;
        }
        return out;
    }

    private JsonNode get(String url) {
        try {
            HttpResponse<String> r = client.send(HttpRequest.newBuilder(URI.create(url)).timeout(timeout).header("Authorization", authorization)
                    .header("Accept", "application/json").GET().build(), HttpResponse.BodyHandlers.ofString());
            if (r.statusCode() / 100 != 2) {
                throw new OracleCallException(r.statusCode(), "Oracle returned " + r.statusCode());
            }
            return mapper.readTree(r.body());
        } catch (IOException e) {
            throw new OracleCallException(0, "Oracle call failed: " + e.getMessage());
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            throw new OracleCallException(0, "Oracle call interrupted");
        }
    }

    public static class OracleCallException extends RuntimeException {

        private final int status;

        public OracleCallException(int status, String message) {
            super(message);
            this.status = status;
        }

        public int status() {
            return status;
        }
    }
}
