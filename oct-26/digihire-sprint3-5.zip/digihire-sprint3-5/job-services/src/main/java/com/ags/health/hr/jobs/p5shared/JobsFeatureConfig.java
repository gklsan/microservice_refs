package com.ags.health.hr.jobs.p5shared;

import com.ags.health.hr.common.platform.approval.ApprovalPort;
import com.ags.health.hr.common.platform.audit.AuditRecorder;
import com.ags.health.hr.common.platform.time.BusinessClock;
import com.ags.health.hr.jobs.jdedit.JdChangeStore;
import com.ags.health.hr.jobs.jdedit.JdEditService;
import com.ags.health.hr.jobs.jdedit.JdPort;
import com.ags.health.hr.jobs.listing.JobVisibilityPolicy;
import com.ags.health.hr.jobs.listing.ListingService;
import com.ags.health.hr.jobs.listing.LocalPublicationPort;
import com.ags.health.hr.jobs.listing.PublicationPort;
import com.ags.health.hr.jobs.listing.PublicationStore;
import com.ags.health.hr.jobs.listing.RequisitionStore;
import com.ags.health.hr.jobs.sync.FieldMapping;
import com.ags.health.hr.jobs.sync.OracleRequisitionSource;
import com.ags.health.hr.jobs.sync.RequisitionSink;
import com.ags.health.hr.jobs.sync.RequisitionSyncService;
import com.ags.health.hr.jobs.sync.RestOracleRequisitionSource;
import com.ags.health.hr.jobs.sync.StubOracleRequisitionSource;
import com.ags.health.hr.jobs.sync.SyncStore;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.ObjectProvider;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.transaction.support.TransactionTemplate;

import java.time.Clock;
import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.stream.Collectors;

@Configuration
@ConditionalOnProperty(prefix = "digihire.jobs", name = "enabled", havingValue = "true", matchIfMissing = true)
public class JobsFeatureConfig {

    @Bean
    public RequisitionStore p5RequisitionStore(JdbcTemplate jdbc) {
        return new RequisitionStore(jdbc);
    }

    @Bean
    public SyncStore p5SyncStore(JdbcTemplate jdbc) {
        return new SyncStore(jdbc);
    }

    @Bean
    public ListingService p5ListingService(RequisitionStore p5RequisitionStore, JdbcTemplate jdbc, ObjectProvider<PublicationPort> ports,
                                           AuditRecorder audit, BusinessClock clock) {
        List<PublicationPort> all = new ArrayList<>(ports.orderedStream().toList());
        Set<String> have = all.stream().map(p -> p.channel().toUpperCase(Locale.ROOT)).collect(Collectors.toSet());
        for (String ch : List.of("CAREER_PAGE", "BUDDY_FINDER")) {
            if (!have.contains(ch)) {
                all.add(new LocalPublicationPort(ch));
            }
        }
        return new ListingService(p5RequisitionStore, new PublicationStore(jdbc), all, new JobVisibilityPolicy(), audit, clock);
    }

    @Bean
    @ConditionalOnMissingBean(JdPort.class)
    public JdPort p5JdPort() {
        return (requisitionId, jobId, jd, version) -> {
        };
    }

    @Bean
    public JdEditService p5JdEditService(JdbcTemplate jdbc, RequisitionStore p5RequisitionStore, ApprovalPort approvals, JdPort jdPort,
                                         ListingService p5ListingService, AuditRecorder audit, Clock p5Clock, JobsP5Properties props) {
        return new JdEditService(new JdChangeStore(jdbc), p5RequisitionStore, approvals, jdPort, p5ListingService, audit, p5Clock,
                props.getMaxJdLength());
    }

    @Bean
    @ConditionalOnMissingBean(OracleRequisitionSource.class)
    public OracleRequisitionSource p5OracleRequisitionSource(ObjectMapper mapper, JobsP5Properties props) {
        JobsP5Properties.Oracle o = props.getOracle();
        if ("REST".equalsIgnoreCase(o.getMode())) {
            if (o.getRequisitionsUrl() == null || o.getUsername() == null || o.getPassword() == null) {
                throw new IllegalStateException("digihire.jobs.oracle.mode=REST needs requisitions-url, username and password");
            }
            return new RestOracleRequisitionSource(mapper, o.getRequisitionsUrl(), o.getLobUrl(), o.getUsername(), o.getPassword(),
                    Duration.ofSeconds(props.getTimeoutSeconds()));
        }
        return new StubOracleRequisitionSource();
    }

    @Bean
    public RequisitionSyncService p5RequisitionSyncService(OracleRequisitionSource source, SyncStore p5SyncStore,
                                                           RequisitionStore p5RequisitionStore, ListingService p5ListingService,
                                                           ObjectProvider<RequisitionSink> sinks, TransactionTemplate p5TransactionTemplate,
                                                           AuditRecorder audit, ObjectMapper mapper, Clock p5Clock, JobsP5Properties props) {
        JobsP5Properties.Oracle o = props.getOracle();
        return new RequisitionSyncService(source, new FieldMapping(o.getFieldMap()), p5SyncStore, p5RequisitionStore, p5ListingService,
                sinks.orderedStream().toList(), p5TransactionTemplate, audit, mapper, p5Clock,
                new RequisitionSyncService.Settings(o.getPageSize(), o.getMaxPages(), o.getMaxAttempts()));
    }
}
