package com.ags.health.hr.jobs.sync;

import com.fasterxml.jackson.databind.JsonNode;

import java.time.Instant;
import java.time.LocalDate;
import java.time.OffsetDateTime;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

public class FieldMapping {

    public record Issue(String field, String code, String message, boolean critical) {
    }

    public record Mapped(Map<String, Object> values, List<Issue> issues) {

        public boolean consistent() {
            return issues.stream().noneMatch(Issue::critical);
        }

        public String text(String key) {
            Object v = values.get(key);
            return v == null ? null : String.valueOf(v);
        }
    }

    public static final Map<String, String> DEFAULTS = defaults();
    private static final Set<String> REQUIRED = Set.of("requisitionId", "title", "lob", "location", "status");
    private static final Set<String> NUMBERS = Set.of("openings", "filled");
    private static final Set<String> DATES = Set.of("validTo");
    private static final Set<String> STATUSES = Set.of("OPEN", "APPROVED", "ACTIVE", "POSTED", "DRAFT", "ON_HOLD", "CLOSED", "FILLED",
            "CANCELLED", "CANCELED");

    private final Map<String, String> paths;

    public FieldMapping(Map<String, String> overrides) {
        Map<String, String> m = new LinkedHashMap<>(DEFAULTS);
        if (overrides != null) {
            m.putAll(overrides);
        }
        this.paths = Map.copyOf(m);
    }

    private static Map<String, String> defaults() {
        Map<String, String> m = new LinkedHashMap<>();
        m.put("requisitionId", "RequisitionNumber");
        m.put("jobId", "RequisitionId");
        m.put("orcId", "RequisitionId");
        m.put("title", "Title");
        m.put("lob", "OrganizationName");
        m.put("location", "PrimaryLocation");
        m.put("roleCode", "JobFamilyName");
        m.put("status", "CurrentPhaseCode");
        m.put("openings", "NumberOfOpenings");
        m.put("filled", "HiredCount");
        m.put("validTo", "ExternalPostingEndDate");
        m.put("recruiterId", "RecruiterPersonNumber");
        m.put("jd", "ExternalDescriptionStr");
        m.put("sourceUpdatedAt", "LastUpdateDate");
        return m;
    }

    public Mapped map(JsonNode source, Set<String> knownLobs) {
        Map<String, Object> out = new LinkedHashMap<>();
        List<Issue> issues = new ArrayList<>();
        for (Map.Entry<String, String> e : paths.entrySet()) {
            JsonNode v = at(source, e.getValue());
            String text = v == null || v.isNull() || v.isMissingNode() ? null : v.asText().strip();
            if (text != null && text.isEmpty()) {
                text = null;
            }
            String field = e.getKey();
            if (text == null) {
                if (REQUIRED.contains(field)) {
                    issues.add(new Issue(field, "MISSING", e.getValue() + " is empty", true));
                }
                continue;
            }
            if (NUMBERS.contains(field)) {
                try {
                    int n = (int) Math.round(Double.parseDouble(text));
                    if (n < 0) {
                        throw new NumberFormatException();
                    }
                    out.put(field, n);
                } catch (NumberFormatException ex) {
                    issues.add(new Issue(field, "NOT_A_NUMBER", e.getValue() + " = " + text, true));
                }
            } else if (DATES.contains(field)) {
                try {
                    out.put(field, text.length() > 10 ? OffsetDateTime.parse(text).toLocalDate() : LocalDate.parse(text));
                } catch (DateTimeParseException ex) {
                    issues.add(new Issue(field, "NOT_A_DATE", e.getValue() + " = " + text, false));
                }
            } else if ("sourceUpdatedAt".equals(field)) {
                try {
                    out.put(field, OffsetDateTime.parse(text).toInstant());
                } catch (DateTimeParseException ex) {
                    try {
                        out.put(field, Instant.parse(text));
                    } catch (DateTimeParseException ex2) {
                        issues.add(new Issue(field, "NOT_A_TIMESTAMP", e.getValue() + " = " + text, false));
                    }
                }
            } else {
                out.put(field, text.length() > 20000 ? text.substring(0, 20000) : text);
            }
        }
        Object status = out.get("status");
        if (status != null) {
            String s = String.valueOf(status).toUpperCase(Locale.ROOT).replace(' ', '_');
            out.put("status", s);
            if (!STATUSES.contains(s)) {
                issues.add(new Issue("status", "UNKNOWN_STATUS", s, true));
            }
        }
        Object lob = out.get("lob");
        if (lob != null) {
            out.put("lob", String.valueOf(lob).toUpperCase(Locale.ROOT));
            if (knownLobs != null && !knownLobs.isEmpty() && !knownLobs.contains(String.valueOf(lob).toUpperCase(Locale.ROOT))) {
                issues.add(new Issue("lob", "UNKNOWN_LOB", String.valueOf(lob), true));
            }
        }
        if (out.get("location") != null) {
            out.put("location", String.valueOf(out.get("location")).toUpperCase(Locale.ROOT));
        }
        if (out.get("openings") instanceof Integer o && out.get("filled") instanceof Integer f && f > o) {
            issues.add(new Issue("filled", "FILLED_EXCEEDS_OPENINGS", f + " > " + o, false));
        }
        return new Mapped(out, List.copyOf(issues));
    }

    static JsonNode at(JsonNode node, String path) {
        JsonNode cur = node;
        for (String part : path.split("\\.")) {
            if (cur == null) {
                return null;
            }
            cur = cur.get(part);
        }
        return cur;
    }
}
