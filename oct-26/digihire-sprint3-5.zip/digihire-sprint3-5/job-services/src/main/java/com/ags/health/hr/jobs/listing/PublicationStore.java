package com.ags.health.hr.jobs.listing;

import org.springframework.jdbc.core.JdbcTemplate;

import java.sql.Timestamp;
import java.time.Instant;
import java.util.List;
import java.util.Map;
import java.util.Optional;

public class PublicationStore {

    private final JdbcTemplate jdbc;

    public PublicationStore(JdbcTemplate jdbc) {
        this.jdbc = jdbc;
    }

    public void published(String requisitionId, String channel, String ref, String actor, Instant at) {
        int n = jdbc.update("UPDATE job_p5_publication SET status = 'PUBLISHED', external_ref = ?, published_by = ?, published_at = ?, "
                + "unpublished_at = NULL, reason = NULL WHERE requisition_id = ? AND channel = ?", ref, actor, Timestamp.from(at),
                requisitionId, channel);
        if (n == 0) {
            jdbc.update("INSERT INTO job_p5_publication (requisition_id, channel, status, external_ref, published_by, published_at) "
                    + "VALUES (?, ?, 'PUBLISHED', ?, ?, ?)", requisitionId, channel, ref, actor, Timestamp.from(at));
        }
    }

    public void unpublished(String requisitionId, String channel, String reason, Instant at) {
        jdbc.update("UPDATE job_p5_publication SET status = 'UNPUBLISHED', unpublished_at = ?, reason = ? WHERE requisition_id = ? "
                + "AND channel = ?", Timestamp.from(at), reason, requisitionId, channel);
    }

    public Optional<String> activeRef(String requisitionId, String channel) {
        return jdbc.queryForList("SELECT external_ref FROM job_p5_publication WHERE requisition_id = ? AND channel = ? "
                + "AND status = 'PUBLISHED'", String.class, requisitionId, channel).stream().findFirst();
    }

    public List<Map<String, Object>> forRequisition(String requisitionId) {
        return jdbc.queryForList("SELECT channel, status, external_ref, published_by, published_at, unpublished_at, reason "
                + "FROM job_p5_publication WHERE requisition_id = ? ORDER BY channel", requisitionId);
    }

    public List<String> publishedChannels(String requisitionId) {
        return jdbc.queryForList("SELECT channel FROM job_p5_publication WHERE requisition_id = ? AND status = 'PUBLISHED'",
                String.class, requisitionId);
    }
}
