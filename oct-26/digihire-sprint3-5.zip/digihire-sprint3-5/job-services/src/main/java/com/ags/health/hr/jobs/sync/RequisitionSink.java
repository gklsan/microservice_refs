package com.ags.health.hr.jobs.sync;

import com.ags.health.hr.jobs.listing.RequisitionRecord;

public interface RequisitionSink {

    void upsert(RequisitionRecord record);
}
