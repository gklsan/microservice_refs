package com.ags.health.hr.jobs.listing;

import com.ags.health.hr.common.platform.audit.AuditRecorder;
import com.ags.health.hr.common.platform.caller.Caller;
import com.ags.health.hr.common.platform.error.PlatformException;
import com.ags.health.hr.common.platform.page.PageResult;
import com.ags.health.hr.common.platform.time.BusinessClock;
import org.springframework.transaction.annotation.Transactional;

import java.time.Instant;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

public class ListingService {

    public static final String VIEW = "JOB:VIEW";
    public static final String PUBLISH = "JOB:PUBLISH";

    private final RequisitionStore store;
    private final PublicationStore publications;
    private final Map<String, PublicationPort> channels;
    private final JobVisibilityPolicy visibility;
    private final AuditRecorder audit;
    private final BusinessClock clock;

    public ListingService(RequisitionStore store, PublicationStore publications, List<PublicationPort> channels,
                          JobVisibilityPolicy visibility, AuditRecorder audit, BusinessClock clock) {
        this.store = store;
        this.publications = publications;
        this.channels = channels.stream().collect(Collectors.toMap(c -> c.channel().toUpperCase(Locale.ROOT), Function.identity()));
        this.visibility = visibility;
        this.audit = audit;
        this.clock = clock;
    }

    @Transactional(readOnly = true)
    public PageResult<RequisitionRecord> search(Caller caller, RequisitionStore.Filter filter, int page, int size, boolean includeHidden) {
        require(caller, VIEW);
        RequisitionStore.Filter f = new RequisitionStore.Filter(filter.q(), filter.lob(), filter.location(), filter.status(),
                filter.recruiterId(), includeHidden ? filter.visible() : Boolean.TRUE);
        return store.search(f, PageResult.safePage(page), PageResult.safeSize(size, 200));
    }

    @Transactional(readOnly = true)
    public Map<String, Object> details(Caller caller, String requisitionId) {
        require(caller, VIEW);
        RequisitionRecord r = load(requisitionId);
        Map<String, Object> out = new LinkedHashMap<>();
        out.put("requisition", r);
        out.put("publications", publications.forRequisition(r.requisitionId()));
        return out;
    }

    @Transactional(readOnly = true)
    public Map<String, Object> changes(Caller caller, Instant since, int limit) {
        require(caller, VIEW);
        Instant from = since == null ? clock.now().minusSeconds(3600) : since;
        List<RequisitionRecord> items = store.changedSince(from, Math.max(1, Math.min(limit, 500)));
        Instant cursor = items.isEmpty() ? from : items.get(items.size() - 1).updatedAt();
        return Map.of("items", items, "cursor", cursor.toString());
    }

    @Transactional
    public List<Map<String, Object>> publish(Caller caller, String requisitionId, String channel) {
        require(caller, PUBLISH);
        RequisitionRecord r = load(requisitionId);
        PublicationPort port = port(channel);
        if (!r.visible()) {
            throw PlatformException.conflict("REQUISITION_NOT_PUBLISHABLE", "Requisition is hidden: " + r.hiddenReason());
        }
        String ref = port.publish(r);
        publications.published(r.requisitionId(), port.channel(), ref, caller.userId(), clock.now());
        audit.record("ACTIVITY", "JOB_PUBLISHED", "REQUISITION", r.requisitionId(), null,
                AuditRecorder.details("channel", port.channel(), "externalRef", ref));
        return publications.forRequisition(r.requisitionId());
    }

    @Transactional
    public List<Map<String, Object>> unpublish(Caller caller, String requisitionId, String channel, String reason) {
        require(caller, PUBLISH);
        RequisitionRecord r = load(requisitionId);
        PublicationPort port = port(channel);
        withdraw(r, port, reason == null ? "MANUAL" : reason);
        audit.record("ACTIVITY", "JOB_UNPUBLISHED", "REQUISITION", r.requisitionId(), null,
                AuditRecorder.details("channel", port.channel(), "reason", reason));
        return publications.forRequisition(r.requisitionId());
    }

    public RequisitionRecord applyVisibility(RequisitionRecord r, boolean mappingConsistent) {
        String reason = visibility.hiddenReason(r, clock.today(), mappingConsistent).orElse(null);
        RequisitionRecord out = r.withVisibility(reason == null, reason, clock.now());
        if (reason != null) {
            for (String ch : publications.publishedChannels(r.requisitionId())) {
                PublicationPort port = channels.get(ch.toUpperCase(Locale.ROOT));
                if (port != null) {
                    withdraw(out, port, "AUTO_" + reason);
                }
            }
        }
        return out;
    }

    public void republish(RequisitionRecord r) {
        for (String ch : publications.publishedChannels(r.requisitionId())) {
            PublicationPort port = channels.get(ch.toUpperCase(Locale.ROOT));
            if (port != null) {
                publications.published(r.requisitionId(), port.channel(), port.publish(r), "system", clock.now());
            }
        }
    }

    private void withdraw(RequisitionRecord r, PublicationPort port, String reason) {
        publications.activeRef(r.requisitionId(), port.channel()).ifPresent(ref -> {
            port.unpublish(r, ref);
            publications.unpublished(r.requisitionId(), port.channel(), reason, clock.now());
        });
    }

    private PublicationPort port(String channel) {
        PublicationPort p = channel == null ? null : channels.get(channel.trim().toUpperCase(Locale.ROOT));
        if (p == null) {
            throw PlatformException.badRequest("CHANNEL_INVALID", "Channel must be one of " + channels.keySet());
        }
        return p;
    }

    private RequisitionRecord load(String id) {
        return store.find(id).orElseThrow(() -> PlatformException.notFound("Requisition", id));
    }

    private static void require(Caller caller, String permission) {
        if (!caller.has(permission)) {
            throw PlatformException.forbidden("PERMISSION_DENIED", "Missing permission " + permission);
        }
    }
}
