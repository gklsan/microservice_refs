package com.ags.health.hr.jobs.sync;

import com.ags.health.hr.common.platform.audit.AuditRecorder;
import com.ags.health.hr.common.platform.error.PlatformException;
import com.ags.health.hr.common.platform.outbox.OutboxBackoff;
import com.ags.health.hr.jobs.listing.ListingService;
import com.ags.health.hr.jobs.listing.RequisitionRecord;
import com.ags.health.hr.jobs.listing.RequisitionStore;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.transaction.support.TransactionTemplate;

import java.time.Clock;
import java.time.Instant;
import java.time.LocalDate;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class RequisitionSyncService {

    public static final String KIND = "ORACLE_REQUISITION";
    public static final String LOB_KIND = "ORACLE_LOB";

    private static final Logger log = LoggerFactory.getLogger(RequisitionSyncService.class);

    public record RunResult(String runId, String status, int fetched, int upserted, int failed, int hidden, Instant watermark) {
    }

    public record Settings(int pageSize, int maxPages, int maxAttempts) {
    }

    private final OracleRequisitionSource source;
    private final FieldMapping mapping;
    private final SyncStore sync;
    private final RequisitionStore requisitions;
    private final ListingService listing;
    private final List<RequisitionSink> sinks;
    private final TransactionTemplate tx;
    private final AuditRecorder audit;
    private final ObjectMapper mapper;
    private final Clock clock;
    private final Settings settings;

    public RequisitionSyncService(OracleRequisitionSource source, FieldMapping mapping, SyncStore sync, RequisitionStore requisitions,
                                  ListingService listing, List<RequisitionSink> sinks, TransactionTemplate tx, AuditRecorder audit,
                                  ObjectMapper mapper, Clock clock, Settings settings) {
        this.source = source;
        this.mapping = mapping;
        this.sync = sync;
        this.requisitions = requisitions;
        this.listing = listing;
        this.sinks = List.copyOf(sinks);
        this.tx = tx;
        this.audit = audit;
        this.mapper = mapper;
        this.clock = clock;
        this.settings = settings;
    }

    public RunResult run(boolean full, String trigger) {
        Instant from = full ? null : sync.watermark(KIND).orElse(null);
        Instant started = clock.instant();
        String runId = tx.execute(s -> sync.startRun(full ? "FULL" : "INCREMENTAL", trigger, from, started));
        Set<String> lobs = sync.activeLobs();
        int fetched = 0;
        int upserted = 0;
        int failed = 0;
        int hidden = 0;
        Instant max = from;
        String error = null;
        int offset = 0;
        try {
            for (int page = 0; page < settings.maxPages(); page++) {
                OracleRequisitionSource.Page p = source.requisitions(from, offset, settings.pageSize());
                for (JsonNode item : p.items()) {
                    fetched++;
                    Outcome o = process(runId, item, lobs);
                    if (o.ok) {
                        upserted++;
                        if (!o.visible) {
                            hidden++;
                        }
                        if (o.updatedAt != null && (max == null || o.updatedAt.isAfter(max))) {
                            max = o.updatedAt;
                        }
                    } else {
                        failed++;
                    }
                }
                offset += p.items().size();
                if (!p.hasMore() || p.items().isEmpty()) {
                    break;
                }
            }
        } catch (RuntimeException e) {
            error = e.getMessage();
            log.warn("Oracle requisition sync {} stopped: {}", runId, e.getMessage());
        }
        String status = error != null ? "FAILED" : failed > 0 ? "PARTIAL" : "SUCCESS";
        Instant watermark = max;
        if (error == null && watermark != null) {
            tx.execute(s -> {
                sync.saveWatermark(KIND, watermark, clock.instant());
                return null;
            });
        }
        int f = fetched;
        int u = upserted;
        int fl = failed;
        int h = hidden;
        String err = error;
        tx.execute(s -> {
            sync.finishRun(runId, status, f, u, fl, h, watermark, err, clock.instant());
            return null;
        });
        audit.recordQuietly("INTEGRATION", "REQUISITION_SYNC_" + status, "SYNC_RUN", runId, null,
                error == null ? AuditRecorder.SUCCESS : AuditRecorder.FAILURE, error,
                AuditRecorder.details("fetched", fetched, "upserted", upserted, "failed", failed, "hidden", hidden, "full", full,
                        "trigger", trigger));
        return new RunResult(runId, status, fetched, upserted, failed, hidden, watermark);
    }

    public int retryDue(int limit) {
        Set<String> lobs = sync.activeLobs();
        int resolved = 0;
        for (SyncStore.Failure fl : sync.due(clock.instant(), limit)) {
            if (retry(fl, lobs)) {
                resolved++;
            }
        }
        return resolved;
    }

    public boolean retryOne(String failureId) {
        SyncStore.Failure fl = sync.findFailure(failureId).orElseThrow(() -> PlatformException.notFound("Sync failure", failureId));
        tx.execute(s -> {
            sync.requeue(failureId, clock.instant());
            return null;
        });
        return retry(fl, sync.activeLobs());
    }

    private boolean retry(SyncStore.Failure fl, Set<String> lobs) {
        Instant now = clock.instant();
        try {
            JsonNode item = mapper.readTree(fl.payload());
            Outcome o = process(null, item, lobs);
            if (o.ok) {
                return true;
            }
            int attempts = fl.attempts() + 1;
            boolean park = OutboxBackoff.shouldPark(attempts, settings.maxAttempts());
            tx.execute(s -> {
                sync.retried(fl.id(), false, o.error, attempts, park, park ? null : now.plus(OutboxBackoff.delay(attempts, 300, 21600)), now);
                return null;
            });
            return false;
        } catch (Exception e) {
            tx.execute(s -> {
                sync.retried(fl.id(), false, "Unreadable payload: " + e.getMessage(), fl.attempts() + 1, true, null, now);
                return null;
            });
            return false;
        }
    }

    private record Outcome(boolean ok, boolean visible, Instant updatedAt, String error) {
    }

    private Outcome process(String runId, JsonNode item, Set<String> lobs) {
        FieldMapping.Mapped m = mapping.map(item, lobs);
        String externalId = m.text("requisitionId") != null ? m.text("requisitionId") : String.valueOf(item.path("RequisitionId").asText("UNKNOWN"));
        Instant now = clock.instant();
        try {
            return tx.execute(s -> {
                sync.issues(runId, externalId, m.issues(), now);
                if (m.text("requisitionId") == null) {
                    throw new IllegalStateException("Requisition number is missing");
                }
                RequisitionRecord existing = requisitions.find(externalId).orElse(null);
                RequisitionRecord r = new RequisitionRecord(externalId, m.text("jobId"), m.text("title"), m.text("lob"), m.text("location"),
                        m.text("orcId"), m.text("roleCode"), m.text("status"), m.values().get("openings") instanceof Integer i ? i : 0,
                        m.values().get("filled") instanceof Integer i ? i : 0, (LocalDate) m.values().get("validTo"), m.text("recruiterId"),
                        existing != null && existing.jdVersion() > 0 ? existing.jd() : m.text("jd"),
                        existing == null ? 0 : existing.jdVersion(), "ORACLE", (Instant) m.values().get("sourceUpdatedAt"), true, null, now);
                RequisitionRecord withVisibility = listing.applyVisibility(r, m.consistent());
                requisitions.upsert(withVisibility);
                for (RequisitionSink sink : sinks) {
                    sink.upsert(withVisibility);
                }
                sync.resolveFor(externalId, now);
                return new Outcome(true, withVisibility.visible(), r.sourceUpdatedAt(), null);
            });
        } catch (RuntimeException e) {
            String err = e.getMessage();
            tx.execute(s -> {
                sync.failure(runId, externalId, item.toString(), err, now.plus(OutboxBackoff.delay(1, 300, 21600)), now);
                return null;
            });
            return new Outcome(false, false, null, err);
        }
    }

    public Map<String, Object> syncLobs() {
        Instant now = clock.instant();
        List<JsonNode> items = source.lobs();
        Set<String> seen = new HashSet<>();
        tx.execute(s -> {
            for (JsonNode n : items) {
                String code = text(n, "OrganizationName", "Name", "code");
                if (code == null) {
                    continue;
                }
                code = code.trim().toUpperCase();
                seen.add(code);
                boolean active = !"INACTIVE".equalsIgnoreCase(text(n, "Status", "status", "ActiveStatus"));
                sync.upsertLob(code, text(n, "DisplayName", "Name", "name"), active, now);
            }
            return null;
        });
        int deactivated = items.isEmpty() ? 0 : tx.execute(s -> sync.deactivateLobsNotIn(seen, now));
        audit.recordQuietly("INTEGRATION", "LOB_SYNC_COMPLETED", "SYNC_RUN", LOB_KIND, null, AuditRecorder.SUCCESS, null,
                AuditRecorder.details("received", items.size(), "deactivated", deactivated));
        return Map.of("received", items.size(), "active", seen.size(), "deactivated", deactivated);
    }

    private static String text(JsonNode n, String... fields) {
        for (String f : fields) {
            JsonNode v = n.get(f);
            if (v != null && !v.isNull() && !v.asText().isBlank()) {
                return v.asText();
            }
        }
        return null;
    }
}
