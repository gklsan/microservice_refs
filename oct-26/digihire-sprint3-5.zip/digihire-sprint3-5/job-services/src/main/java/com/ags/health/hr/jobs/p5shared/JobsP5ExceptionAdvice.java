package com.ags.health.hr.jobs.p5shared;

import com.ags.health.hr.common.platform.error.PlatformException;
import org.slf4j.MDC;
import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.http.HttpStatus;
import org.springframework.http.ProblemDetail;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

@Order(Ordered.HIGHEST_PRECEDENCE)
@RestControllerAdvice(basePackages = {"com.ags.health.hr.jobs.p5shared", "com.ags.health.hr.jobs.listing",
        "com.ags.health.hr.jobs.jdedit", "com.ags.health.hr.jobs.sync"})
public class JobsP5ExceptionAdvice {

    @ExceptionHandler(PlatformException.class)
    public ResponseEntity<ProblemDetail> platform(PlatformException e) {
        ProblemDetail p = ProblemDetail.forStatusAndDetail(HttpStatus.valueOf(e.getStatus()), e.getMessage());
        p.setTitle(e.getCode());
        p.setProperty("code", e.getCode());
        String correlation = MDC.get("correlationId") != null ? MDC.get("correlationId") : MDC.get("req-id");
        if (correlation != null) {
            p.setProperty("correlationId", correlation);
        }
        if (e.getDetails() != null && !e.getDetails().isEmpty()) {
            p.setProperty("errors", e.getDetails());
        }
        return ResponseEntity.status(HttpStatus.valueOf(e.getStatus())).body(p);
    }
}
