package com.ags.health.hr.jobs.listing;

import com.ags.health.hr.common.platform.page.PageResult;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

import java.sql.Date;
import java.sql.Timestamp;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Optional;

public class RequisitionStore {

    public record Filter(String q, String lob, String location, String status, String recruiterId, Boolean visible) {
    }

    private static final String COLUMNS = "requisition_id, job_id, title, lob, location, orc_id, role_code, status, openings, filled, "
            + "valid_to, recruiter_id, jd, jd_version, source, source_updated_at, visible, hidden_reason, updated_at";
    private static final RowMapper<RequisitionRecord> ROW = (rs, i) -> new RequisitionRecord(rs.getString(1), rs.getString(2),
            rs.getString(3), rs.getString(4), rs.getString(5), rs.getString(6), rs.getString(7), rs.getString(8), rs.getInt(9),
            rs.getInt(10), rs.getDate(11) == null ? null : rs.getDate(11).toLocalDate(), rs.getString(12), rs.getString(13),
            rs.getInt(14), rs.getString(15), rs.getTimestamp(16) == null ? null : rs.getTimestamp(16).toInstant(), rs.getBoolean(17),
            rs.getString(18), rs.getTimestamp(19).toInstant());

    private final JdbcTemplate jdbc;

    public RequisitionStore(JdbcTemplate jdbc) {
        this.jdbc = jdbc;
    }

    public void upsert(RequisitionRecord r) {
        Object[] values = {r.jobId(), r.title(), r.lob(), r.location(), r.orcId(), r.roleCode(), r.status(), r.openings(), r.filled(),
                r.validTo() == null ? null : Date.valueOf(r.validTo()), r.recruiterId(), r.jd(), r.jdVersion(), r.source(),
                r.sourceUpdatedAt() == null ? null : Timestamp.from(r.sourceUpdatedAt()), r.visible(), r.hiddenReason(),
                Timestamp.from(r.updatedAt()), r.requisitionId()};
        int n = jdbc.update("UPDATE job_p5_requisition SET job_id = ?, title = ?, lob = ?, location = ?, orc_id = ?, role_code = ?, "
                + "status = ?, openings = ?, filled = ?, valid_to = ?, recruiter_id = ?, jd = ?, jd_version = ?, source = ?, "
                + "source_updated_at = ?, visible = ?, hidden_reason = ?, updated_at = ? WHERE requisition_id = ?", values);
        if (n == 0) {
            jdbc.update("INSERT INTO job_p5_requisition (job_id, title, lob, location, orc_id, role_code, status, openings, filled, "
                    + "valid_to, recruiter_id, jd, jd_version, source, source_updated_at, visible, hidden_reason, updated_at, requisition_id) "
                    + "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)", values);
        }
    }

    public Optional<RequisitionRecord> find(String requisitionId) {
        return jdbc.query("SELECT " + COLUMNS + " FROM job_p5_requisition WHERE requisition_id = ?", ROW, requisitionId).stream().findFirst();
    }

    public PageResult<RequisitionRecord> search(Filter f, int page, int size) {
        StringBuilder where = new StringBuilder(" WHERE 1 = 1");
        List<Object> args = new ArrayList<>();
        if (f.q() != null && !f.q().isBlank()) {
            where.append(" AND (LOWER(title) LIKE ? OR LOWER(requisition_id) LIKE ? OR LOWER(orc_id) LIKE ?)");
            String like = "%" + f.q().trim().toLowerCase(Locale.ROOT).replace("%", "").replace("_", "") + "%";
            args.add(like);
            args.add(like);
            args.add(like);
        }
        eq(where, args, "lob", f.lob());
        eq(where, args, "location", f.location());
        eq(where, args, "status", f.status());
        eq(where, args, "recruiter_id", f.recruiterId());
        if (f.visible() != null) {
            where.append(" AND visible = ?");
            args.add(f.visible());
        }
        Long total = jdbc.queryForObject("SELECT count(*) FROM job_p5_requisition" + where, Long.class, args.toArray());
        List<Object> pageArgs = new ArrayList<>(args);
        pageArgs.add(size);
        pageArgs.add((long) page * size);
        List<RequisitionRecord> items = jdbc.query("SELECT " + COLUMNS + " FROM job_p5_requisition" + where
                + " ORDER BY updated_at DESC, requisition_id LIMIT ? OFFSET ?", ROW, pageArgs.toArray());
        return new PageResult<>(items, page, size, total == null ? 0 : total);
    }

    public List<RequisitionRecord> changedSince(Instant since, int limit) {
        return jdbc.query("SELECT " + COLUMNS + " FROM job_p5_requisition WHERE updated_at > ? ORDER BY updated_at, requisition_id LIMIT ?",
                ROW, Timestamp.from(since), limit);
    }

    public List<RequisitionRecord> visible() {
        return jdbc.query("SELECT " + COLUMNS + " FROM job_p5_requisition WHERE visible = TRUE", ROW);
    }

    private static void eq(StringBuilder where, List<Object> args, String column, String value) {
        if (value != null && !value.isBlank()) {
            where.append(" AND UPPER(").append(column).append(") = ?");
            args.add(value.trim().toUpperCase(Locale.ROOT));
        }
    }
}
