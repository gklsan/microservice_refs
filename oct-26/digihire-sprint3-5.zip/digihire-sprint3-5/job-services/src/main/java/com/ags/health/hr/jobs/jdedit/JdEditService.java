package com.ags.health.hr.jobs.jdedit;

import com.ags.health.hr.common.platform.approval.ApprovalChain;
import com.ags.health.hr.common.platform.approval.ApprovalPort;
import com.ags.health.hr.common.platform.audit.AuditRecorder;
import com.ags.health.hr.common.platform.caller.Caller;
import com.ags.health.hr.common.platform.error.PlatformException;
import com.ags.health.hr.jobs.listing.ListingService;
import com.ags.health.hr.jobs.listing.RequisitionRecord;
import com.ags.health.hr.jobs.listing.RequisitionStore;
import org.springframework.transaction.annotation.Transactional;

import java.time.Clock;
import java.time.Instant;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public class JdEditService {

    public static final String EDIT = "JOB:EDIT_JD";
    public static final String FLOW = "JD_EDIT";

    private final JdChangeStore changes;
    private final RequisitionStore requisitions;
    private final ApprovalPort approvals;
    private final JdPort jdPort;
    private final ListingService listing;
    private final AuditRecorder audit;
    private final Clock clock;
    private final int maxLength;

    public JdEditService(JdChangeStore changes, RequisitionStore requisitions, ApprovalPort approvals, JdPort jdPort,
                         ListingService listing, AuditRecorder audit, Clock clock, int maxLength) {
        this.changes = changes;
        this.requisitions = requisitions;
        this.approvals = approvals;
        this.jdPort = jdPort;
        this.listing = listing;
        this.audit = audit;
        this.clock = clock;
        this.maxLength = maxLength;
    }

    @Transactional
    public JdChangeStore.Change request(Caller caller, String requisitionId, String jd, String reason) {
        if (!caller.has(EDIT)) {
            throw PlatformException.forbidden("PERMISSION_DENIED", "Missing permission " + EDIT);
        }
        RequisitionRecord r = requisitions.find(requisitionId).orElseThrow(() -> PlatformException.notFound("Requisition", requisitionId));
        if (changes.pendingFor(r.requisitionId()).isPresent()) {
            throw PlatformException.conflict("JD_CHANGE_PENDING", "A JD change is already waiting for approval");
        }
        if (reason == null || reason.isBlank() || reason.length() > 1000) {
            throw PlatformException.badRequest("REASON_REQUIRED", "A reason (max 1000 characters) is required");
        }
        String clean = JdSanitizer.clean(jd, maxLength);
        ApprovalChain chain = approvals.resolve(FLOW, caller.userId(), caller.email(), r.lob(), r.location());
        if (!chain.resolved() || chain.levels() < 1) {
            throw PlatformException.conflict("APPROVERS_NOT_CONFIGURED", "No TA Head approver is configured for " + r.lob());
        }
        JdChangeStore.Change c = changes.create(r.requisitionId(), r.jdVersion(), clean, reason.strip(), chain.levels(), caller.userId(),
                caller.email(), clock.instant());
        audit.record("APPROVAL", "JD_CHANGE_REQUESTED", "REQUISITION", r.requisitionId(), null, AuditRecorder.SUCCESS, reason,
                AuditRecorder.details("changeId", c.id(), "levels", chain.levels(), "baseVersion", r.jdVersion()));
        return c;
    }

    @Transactional
    public JdChangeStore.Change decide(Caller caller, String changeId, String decision, String remarks) {
        JdChangeStore.Change c = changes.find(changeId).orElseThrow(() -> PlatformException.notFound("JD change", changeId));
        if (!"PENDING".equals(c.status())) {
            throw PlatformException.conflict("JD_CHANGE_CLOSED", "JD change is already " + c.status());
        }
        String d = decision == null ? "" : decision.trim().toUpperCase(Locale.ROOT);
        if (!d.equals("APPROVE") && !d.equals("REJECT")) {
            throw PlatformException.badRequest("DECISION_INVALID", "Decision must be APPROVE or REJECT");
        }
        if (caller.is(c.requestedBy())) {
            throw PlatformException.forbidden("SELF_APPROVAL", "You can not approve your own JD change");
        }
        RequisitionRecord r = requisitions.find(c.requisitionId()).orElseThrow();
        if (!approvals.canApprove(FLOW, c.currentLevel(), caller.userId(), caller.email(), c.requestedBy(), c.requestedByEmail(),
                r.lob(), r.location())) {
            throw PlatformException.forbidden("NOT_AN_APPROVER", "You are not an approver for level " + c.currentLevel());
        }
        if ("REJECT".equals(d) && (remarks == null || remarks.isBlank())) {
            throw PlatformException.badRequest("REMARKS_REQUIRED", "Remarks are required to reject");
        }
        Instant now = clock.instant();
        changes.action(c.id(), c.currentLevel(), caller.userId(), d, remarks, now);
        if ("REJECT".equals(d)) {
            changes.close(c.id(), c.currentLevel(), "REJECTED", now);
            audit.record("APPROVAL", "JD_CHANGE_REJECTED", "REQUISITION", c.requisitionId(), null, AuditRecorder.SUCCESS, remarks,
                    AuditRecorder.details("changeId", c.id(), "level", c.currentLevel()));
        } else if (c.currentLevel() < c.totalLevels()) {
            changes.advance(c.id(), c.currentLevel());
            audit.record("APPROVAL", "JD_CHANGE_LEVEL_APPROVED", "REQUISITION", c.requisitionId(), null, AuditRecorder.SUCCESS, remarks,
                    AuditRecorder.details("changeId", c.id(), "level", c.currentLevel()));
        } else {
            if (r.jdVersion() != c.baseVersion()) {
                changes.close(c.id(), c.currentLevel(), "STALE", now);
                throw PlatformException.conflict("JD_CHANGED_MEANWHILE", "The JD changed after this request; raise a new request");
            }
            changes.close(c.id(), c.currentLevel(), "APPROVED", now);
            RequisitionRecord updated = r.withJd(c.proposedJd(), r.jdVersion() + 1, now);
            requisitions.upsert(updated);
            jdPort.apply(r.requisitionId(), r.jobId(), c.proposedJd(), updated.jdVersion());
            listing.republish(updated);
            audit.record("APPROVAL", "JD_CHANGE_APPROVED", "REQUISITION", c.requisitionId(), null, AuditRecorder.SUCCESS, remarks,
                    AuditRecorder.details("changeId", c.id(), "version", updated.jdVersion()));
        }
        return changes.find(c.id()).orElseThrow();
    }

    @Transactional(readOnly = true)
    public List<JdChangeStore.Change> inbox(Caller caller) {
        return changes.pending(200).stream().filter(c -> !caller.is(c.requestedBy())).filter(c -> requisitions.find(c.requisitionId())
                .map(r -> approvals.canApprove(FLOW, c.currentLevel(), caller.userId(), caller.email(), c.requestedBy(),
                        c.requestedByEmail(), r.lob(), r.location())).orElse(false)).toList();
    }

    @Transactional(readOnly = true)
    public Map<String, Object> details(Caller caller, String changeId) {
        if (!caller.hasAny(EDIT, "JOB:VIEW")) {
            throw PlatformException.forbidden("PERMISSION_DENIED", "Missing permission JOB:VIEW");
        }
        JdChangeStore.Change c = changes.find(changeId).orElseThrow(() -> PlatformException.notFound("JD change", changeId));
        return Map.of("change", c, "actions", changes.actions(c.id()));
    }
}
