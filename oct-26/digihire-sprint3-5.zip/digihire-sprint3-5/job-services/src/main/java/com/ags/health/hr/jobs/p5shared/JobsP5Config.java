package com.ags.health.hr.jobs.p5shared;

import com.ags.health.hr.common.platform.approval.AdminApprovalClient;
import com.ags.health.hr.common.platform.approval.ApprovalPort;
import com.ags.health.hr.common.platform.audit.AuditRecorder;
import com.ags.health.hr.common.platform.audit.AuditTableInspector;
import com.ags.health.hr.common.platform.audit.LocalAuditLogTable;
import com.ags.health.hr.common.platform.audit.SharedAuditLogSink;
import com.ags.health.hr.common.platform.caller.CallerProvider;
import com.ags.health.hr.common.platform.caller.InternalKeyVerifier;
import com.ags.health.hr.common.platform.caller.JwtCallerProvider;
import com.ags.health.hr.common.platform.db.SchemaInitializer;
import com.ags.health.hr.common.platform.http.InternalHttp;
import com.ags.health.hr.common.platform.jobs.JobLock;
import com.ags.health.hr.common.platform.jobs.ScheduledJobRunner;
import com.ags.health.hr.common.platform.time.BusinessClock;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.support.TransactionTemplate;

import javax.sql.DataSource;
import java.time.Clock;
import java.time.Duration;
import java.time.ZoneId;
import java.util.List;
import java.util.Map;

@Configuration
@EnableScheduling
@EnableConfigurationProperties(JobsP5Properties.class)
@ConditionalOnProperty(prefix = "digihire.jobs", name = "enabled", havingValue = "true", matchIfMissing = true)
public class JobsP5Config {

    @Bean
    public Clock p5Clock() {
        return Clock.systemUTC();
    }

    @Bean
    public BusinessClock p5BusinessClock(Clock p5Clock, JobsP5Properties props) {
        return new BusinessClock(p5Clock, ZoneId.of(props.getZone()));
    }

    @Bean(initMethod = "run")
    @ConditionalOnProperty(prefix = "digihire.jobs", name = "schema-init", havingValue = "true", matchIfMissing = true)
    public SchemaInitializer p5SchemaInitializer(DataSource dataSource) {
        return new SchemaInitializer(dataSource, List.of("db/p5/job-p5-schema.sql"));
    }

    @Bean
    public InternalHttp p5InternalHttp(ObjectMapper mapper, JobsP5Properties props) {
        return new InternalHttp(mapper, Duration.ofSeconds(props.getTimeoutSeconds()), props.getInternalKey() == null
                ? Map.of(InternalKeyVerifier.CALLER_HEADER, props.getServiceName())
                : Map.of(InternalKeyVerifier.HEADER, props.getInternalKey(), InternalKeyVerifier.CALLER_HEADER, props.getServiceName()));
    }

    @Bean
    @ConditionalOnMissingBean(CallerProvider.class)
    public CallerProvider p5CallerProvider(InternalHttp p5InternalHttp, JobsP5Properties props, Clock p5Clock) {
        return new JwtCallerProvider(props.getJwtSecret(), p5InternalHttp, props.getAdminUrl(), Duration.ofSeconds(60), p5Clock);
    }

    @Bean
    public InternalKeyVerifier p5InternalKeyVerifier(JobsP5Properties props) {
        return new InternalKeyVerifier(props.getInternalKey(), props.getServiceKeys());
    }

    @Bean
    public AuditRecorder p5AuditRecorder(JdbcTemplate jdbc, ObjectMapper mapper, CallerProvider callers, JobsP5Properties props,
                                         Clock p5Clock) {
        if (AuditTableInspector.isH2(jdbc)) {
            LocalAuditLogTable.createIfMissingOnH2(jdbc, props.getAuditTable());
        }
        return new AuditRecorder(List.of(SharedAuditLogSink.create(jdbc, mapper, props.getAuditTable(), 4000)), callers,
                props.getServiceName(), p5Clock);
    }

    @Bean
    public ApprovalPort p5ApprovalPort(InternalHttp p5InternalHttp, JobsP5Properties props) {
        return new AdminApprovalClient(p5InternalHttp, props.getAdminUrl());
    }

    @Bean
    public JobLock p5JobLock(JdbcTemplate jdbc, Clock p5Clock) {
        return new JobLock(jdbc, p5Clock, "job_p5_job_lock");
    }

    @Bean
    public ScheduledJobRunner p5JobRunner(JobLock p5JobLock, JobsP5Properties props) {
        return new ScheduledJobRunner(p5JobLock, props::isJobsEnabled, Duration.ofMinutes(30));
    }

    @Bean
    public TransactionTemplate p5TransactionTemplate(PlatformTransactionManager tm) {
        return new TransactionTemplate(tm);
    }
}
