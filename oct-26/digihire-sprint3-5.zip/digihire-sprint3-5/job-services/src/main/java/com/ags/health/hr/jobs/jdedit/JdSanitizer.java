package com.ags.health.hr.jobs.jdedit;

import com.ags.health.hr.common.platform.error.PlatformException;

import java.util.regex.Pattern;

public final class JdSanitizer {

    private static final Pattern BLOCKS = Pattern.compile("(?is)<\\s*(script|style|iframe|object|embed|form)\\b[^>]*>.*?<\\s*/\\s*\\1\\s*>");
    private static final Pattern DANGEROUS = Pattern.compile("(?is)<\\s*(script|iframe|object|embed|style|link|meta|form)\\b.*?(>|$)");
    private static final Pattern HANDLERS = Pattern.compile("(?i)\\son\\w+\\s*=\\s*(\"[^\"]*\"|'[^']*'|[^\\s>]+)");
    private static final Pattern JS_URL = Pattern.compile("(?i)(href|src)\\s*=\\s*([\"']?)\\s*javascript:");
    private static final Pattern TAG = Pattern.compile("(?i)</?\\s*([a-z0-9]+)[^>]*>");
    private static final java.util.Set<String> ALLOWED = java.util.Set.of("p", "br", "ul", "ol", "li", "b", "strong", "i", "em", "h3",
            "h4", "u");

    private JdSanitizer() {
    }

    public static String clean(String jd, int maxLength) {
        if (jd == null || jd.isBlank()) {
            throw PlatformException.badRequest("JD_REQUIRED", "Job description is required");
        }
        if (jd.length() > maxLength) {
            throw PlatformException.badRequest("JD_TOO_LONG", "Job description must be at most " + maxLength + " characters");
        }
        String out = BLOCKS.matcher(jd).replaceAll("");
        out = DANGEROUS.matcher(out).replaceAll("");
        out = HANDLERS.matcher(out).replaceAll("");
        out = JS_URL.matcher(out).replaceAll("$1=$2#");
        StringBuilder sb = new StringBuilder();
        java.util.regex.Matcher m = TAG.matcher(out);
        int last = 0;
        while (m.find()) {
            sb.append(out, last, m.start());
            String name = m.group(1).toLowerCase();
            if (ALLOWED.contains(name)) {
                sb.append(m.group().startsWith("</") ? "</" + name + ">" : "<" + name + ">");
            }
            last = m.end();
        }
        sb.append(out.substring(last));
        return sb.toString().strip();
    }
}
