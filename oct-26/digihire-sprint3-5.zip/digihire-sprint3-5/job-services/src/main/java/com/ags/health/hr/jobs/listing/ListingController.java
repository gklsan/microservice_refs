package com.ags.health.hr.jobs.listing;

import com.ags.health.hr.common.platform.caller.CallerProvider;
import com.ags.health.hr.common.platform.caller.InternalKeyVerifier;
import com.ags.health.hr.common.platform.error.PlatformException;
import com.ags.health.hr.common.platform.page.PageResult;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.time.Instant;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

@ConditionalOnProperty(prefix = "digihire.jobs", name = "enabled", havingValue = "true", matchIfMissing = true)
@RestController
public class ListingController {

    private final ListingService listing;
    private final RequisitionStore store;
    private final CallerProvider callers;
    private final InternalKeyVerifier keys;

    public ListingController(ListingService listing, RequisitionStore store, CallerProvider callers, InternalKeyVerifier keys) {
        this.listing = listing;
        this.store = store;
        this.callers = callers;
        this.keys = keys;
    }

    @GetMapping("/requisitions/open")
    public PageResult<RequisitionRecord> open(@RequestParam(required = false) String q, @RequestParam(required = false) String lob,
                                              @RequestParam(required = false) String location,
                                              @RequestParam(required = false) String recruiterId,
                                              @RequestParam(defaultValue = "false") boolean includeHidden,
                                              @RequestParam(defaultValue = "0") int page, @RequestParam(defaultValue = "25") int size) {
        return listing.search(callers.require(), new RequisitionStore.Filter(q, lob, location, null, recruiterId, null), page, size,
                includeHidden);
    }

    @GetMapping("/requisitions/changes")
    public Map<String, Object> changes(@RequestParam(required = false) Instant since, @RequestParam(defaultValue = "200") int limit) {
        return listing.changes(callers.require(), since, limit);
    }

    @GetMapping("/requisitions/{requisitionId}/details")
    public Map<String, Object> details(@PathVariable String requisitionId) {
        return listing.details(callers.require(), requisitionId);
    }

    @PostMapping("/requisitions/{requisitionId}/publications/{channel}")
    public List<Map<String, Object>> publish(@PathVariable String requisitionId, @PathVariable String channel) {
        return listing.publish(callers.require(), requisitionId, channel);
    }

    @DeleteMapping("/requisitions/{requisitionId}/publications/{channel}")
    public List<Map<String, Object>> unpublish(@PathVariable String requisitionId, @PathVariable String channel,
                                               @RequestParam(required = false) String reason) {
        return listing.unpublish(callers.require(), requisitionId, channel, reason);
    }

    @GetMapping("/internal/requisitions/{requisitionId}")
    public Map<String, Object> internal(HttpServletRequest request, @PathVariable String requisitionId) {
        keys.require(request);
        RequisitionRecord r = store.find(requisitionId).orElseThrow(() -> PlatformException.notFound("Requisition", requisitionId));
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("requisitionId", r.requisitionId());
        m.put("jobId", r.jobId());
        m.put("title", r.title());
        m.put("lob", r.lob());
        m.put("location", r.location());
        m.put("orcId", r.orcId());
        m.put("roleCode", r.roleCode());
        m.put("status", r.status());
        m.put("active", r.visible() || "NO_OPENINGS".equals(r.hiddenReason()));
        m.put("openings", r.openings());
        m.put("filled", r.filled());
        m.put("validTo", r.validTo() == null ? null : r.validTo().toString());
        m.put("hiddenReason", r.hiddenReason());
        return m;
    }
}
