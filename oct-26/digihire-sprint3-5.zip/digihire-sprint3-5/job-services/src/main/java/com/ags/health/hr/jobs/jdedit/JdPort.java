package com.ags.health.hr.jobs.jdedit;

public interface JdPort {

    void apply(String requisitionId, String jobId, String jd, int version);
}
