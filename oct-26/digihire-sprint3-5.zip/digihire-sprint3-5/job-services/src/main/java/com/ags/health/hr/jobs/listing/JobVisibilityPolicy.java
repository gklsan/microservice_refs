package com.ags.health.hr.jobs.listing;

import java.time.LocalDate;
import java.util.Locale;
import java.util.Optional;
import java.util.Set;

public class JobVisibilityPolicy {

    public static final Set<String> OPEN = Set.of("OPEN", "APPROVED", "ACTIVE", "POSTED");

    public Optional<String> hiddenReason(RequisitionRecord r, LocalDate today, boolean mappingConsistent) {
        if (!mappingConsistent) {
            return Optional.of("MAPPING_INCONSISTENT");
        }
        if (blank(r.title()) || blank(r.lob()) || blank(r.location())) {
            return Optional.of("MISSING_FIELDS");
        }
        if (r.status() == null || !OPEN.contains(r.status().toUpperCase(Locale.ROOT))) {
            return Optional.of("INACTIVE");
        }
        if (r.validTo() != null && r.validTo().isBefore(today)) {
            return Optional.of("EXPIRED");
        }
        if (r.available() <= 0) {
            return Optional.of("NO_OPENINGS");
        }
        return Optional.empty();
    }

    private static boolean blank(String v) {
        return v == null || v.isBlank();
    }
}
