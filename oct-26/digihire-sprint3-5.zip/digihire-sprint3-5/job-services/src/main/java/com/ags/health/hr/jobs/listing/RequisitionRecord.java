package com.ags.health.hr.jobs.listing;

import java.time.Instant;
import java.time.LocalDate;

public record RequisitionRecord(String requisitionId, String jobId, String title, String lob, String location, String orcId,
                                String roleCode, String status, int openings, int filled, LocalDate validTo, String recruiterId,
                                String jd, int jdVersion, String source, Instant sourceUpdatedAt, boolean visible,
                                String hiddenReason, Instant updatedAt) {

    public int available() {
        return Math.max(0, openings - filled);
    }

    public RequisitionRecord withVisibility(boolean visible, String reason, Instant at) {
        return new RequisitionRecord(requisitionId, jobId, title, lob, location, orcId, roleCode, status, openings, filled, validTo,
                recruiterId, jd, jdVersion, source, sourceUpdatedAt, visible, reason, at);
    }

    public RequisitionRecord withJd(String text, int version, Instant at) {
        return new RequisitionRecord(requisitionId, jobId, title, lob, location, orcId, roleCode, status, openings, filled, validTo,
                recruiterId, text, version, source, sourceUpdatedAt, visible, hiddenReason, at);
    }
}
