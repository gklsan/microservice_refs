package com.ags.health.hr.jobs.sync;

import com.ags.health.hr.common.platform.jobs.ScheduledJobRunner;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.time.Duration;

@Component
@ConditionalOnProperty(prefix = "digihire.jobs", name = "enabled", havingValue = "true", matchIfMissing = true)
public class SyncJobs {

    private final ScheduledJobRunner runner;
    private final RequisitionSyncService sync;

    public SyncJobs(ScheduledJobRunner p5JobRunner, RequisitionSyncService sync) {
        this.runner = p5JobRunner;
        this.sync = sync;
    }

    @Scheduled(cron = "${digihire.jobs.oracle.incremental-cron:0 */15 * * * *}", zone = "${digihire.jobs.zone:Asia/Kolkata}")
    public void incremental() {
        runner.run("jobs.p5.requisition-sync", Duration.ofMinutes(1), () -> sync.run(false, "SCHEDULE"));
    }

    @Scheduled(cron = "${digihire.jobs.oracle.retry-cron:0 5 * * * *}", zone = "${digihire.jobs.zone:Asia/Kolkata}")
    public void retry() {
        runner.run("jobs.p5.requisition-retry", Duration.ofMinutes(1), () -> sync.retryDue(200));
    }

    @Scheduled(cron = "${digihire.jobs.oracle.lob-cron:0 30 2 * * *}", zone = "${digihire.jobs.zone:Asia/Kolkata}")
    public void lobs() {
        runner.run("jobs.p5.lob-sync", Duration.ofMinutes(1), sync::syncLobs);
    }
}
