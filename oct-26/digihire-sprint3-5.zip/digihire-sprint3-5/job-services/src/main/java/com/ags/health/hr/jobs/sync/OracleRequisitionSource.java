package com.ags.health.hr.jobs.sync;

import com.fasterxml.jackson.databind.JsonNode;

import java.time.Instant;
import java.util.List;

public interface OracleRequisitionSource {

    record Page(List<JsonNode> items, boolean hasMore, Long total) {
    }

    Page requisitions(Instant updatedAfter, int offset, int limit);

    List<JsonNode> lobs();
}
