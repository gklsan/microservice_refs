package com.ags.health.hr.jobs.sync;

import org.springframework.jdbc.core.JdbcTemplate;

import java.sql.Timestamp;
import java.time.Instant;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;

public class SyncStore {

    public record Failure(String id, String externalId, String payload, String error, int attempts, Instant nextAttemptAt) {
    }

    private final JdbcTemplate jdbc;

    public SyncStore(JdbcTemplate jdbc) {
        this.jdbc = jdbc;
    }

    public String startRun(String kind, String trigger, Instant watermark, Instant at) {
        String id = UUID.randomUUID().toString();
        jdbc.update("INSERT INTO job_p5_sync_run (id, kind, trigger_source, status, watermark_from, started_at, fetched, upserted, failed, "
                + "hidden) VALUES (?, ?, ?, 'RUNNING', ?, ?, 0, 0, 0, 0)", id, kind, trigger, watermark == null ? null : Timestamp.from(watermark),
                Timestamp.from(at));
        return id;
    }

    public void finishRun(String id, String status, int fetched, int upserted, int failed, int hidden, Instant watermarkTo, String error,
                          Instant at) {
        jdbc.update("UPDATE job_p5_sync_run SET status = ?, fetched = ?, upserted = ?, failed = ?, hidden = ?, watermark_to = ?, error = ?, "
                        + "finished_at = ? WHERE id = ?", status, fetched, upserted, failed, hidden,
                watermarkTo == null ? null : Timestamp.from(watermarkTo), error == null ? null : error.length() > 500 ? error.substring(0, 500)
                        : error, Timestamp.from(at), id);
    }

    public Optional<Instant> watermark(String kind) {
        List<Timestamp> t = jdbc.queryForList("SELECT watermark FROM job_p5_sync_state WHERE kind = ?", Timestamp.class, kind);
        return t.isEmpty() || t.get(0) == null ? Optional.empty() : Optional.of(t.get(0).toInstant());
    }

    public void saveWatermark(String kind, Instant watermark, Instant at) {
        int n = jdbc.update("UPDATE job_p5_sync_state SET watermark = ?, updated_at = ? WHERE kind = ?", Timestamp.from(watermark),
                Timestamp.from(at), kind);
        if (n == 0) {
            jdbc.update("INSERT INTO job_p5_sync_state (kind, watermark, updated_at) VALUES (?, ?, ?)", kind, Timestamp.from(watermark),
                    Timestamp.from(at));
        }
    }

    public void failure(String runId, String externalId, String payload, String error, Instant nextAttemptAt, Instant at) {
        List<Map<String, Object>> existing = jdbc.queryForList("SELECT id, attempts FROM job_p5_sync_failure WHERE external_id = ? "
                + "AND status IN ('PENDING', 'PARKED')", externalId);
        String p = payload == null ? null : payload.length() > 8000 ? payload.substring(0, 8000) : payload;
        String e = error == null ? null : error.length() > 500 ? error.substring(0, 500) : error;
        if (existing.isEmpty()) {
            jdbc.update("INSERT INTO job_p5_sync_failure (id, run_id, external_id, payload, error, attempts, status, next_attempt_at, "
                            + "created_at, updated_at) VALUES (?, ?, ?, ?, ?, 1, 'PENDING', ?, ?, ?)", UUID.randomUUID().toString(), runId,
                    externalId, p, e, Timestamp.from(nextAttemptAt), Timestamp.from(at), Timestamp.from(at));
        } else {
            jdbc.update("UPDATE job_p5_sync_failure SET run_id = ?, payload = ?, error = ?, updated_at = ? WHERE id = ?", runId, p, e,
                    Timestamp.from(at), existing.get(0).get("id"));
        }
    }

    public List<Failure> due(Instant now, int limit) {
        return jdbc.query("SELECT id, external_id, payload, error, attempts, next_attempt_at FROM job_p5_sync_failure WHERE status = 'PENDING' "
                        + "AND next_attempt_at <= ? ORDER BY next_attempt_at LIMIT ?",
                (rs, i) -> new Failure(rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getInt(5),
                        rs.getTimestamp(6).toInstant()), Timestamp.from(now), limit);
    }

    public Optional<Failure> findFailure(String id) {
        return jdbc.query("SELECT id, external_id, payload, error, attempts, next_attempt_at FROM job_p5_sync_failure WHERE id = ?",
                (rs, i) -> new Failure(rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getInt(5),
                        rs.getTimestamp(6) == null ? null : rs.getTimestamp(6).toInstant()), id).stream().findFirst();
    }

    public void retried(String id, boolean ok, String error, int attempts, boolean park, Instant next, Instant at) {
        jdbc.update("UPDATE job_p5_sync_failure SET status = ?, attempts = ?, error = COALESCE(?, error), next_attempt_at = ?, updated_at = ? "
                        + "WHERE id = ?", ok ? "RESOLVED" : park ? "PARKED" : "PENDING", attempts, error,
                next == null ? null : Timestamp.from(next), Timestamp.from(at), id);
    }

    public void resolveFor(String externalId, Instant at) {
        jdbc.update("UPDATE job_p5_sync_failure SET status = 'RESOLVED', updated_at = ? WHERE external_id = ? AND status IN ('PENDING', 'PARKED')",
                Timestamp.from(at), externalId);
    }

    public void requeue(String id, Instant at) {
        jdbc.update("UPDATE job_p5_sync_failure SET status = 'PENDING', next_attempt_at = ?, updated_at = ? WHERE id = ? AND status = 'PARKED'",
                Timestamp.from(at), Timestamp.from(at), id);
    }

    public void issues(String runId, String externalId, List<FieldMapping.Issue> issues, Instant at) {
        jdbc.update("DELETE FROM job_p5_sync_issue WHERE external_id = ?", externalId);
        for (FieldMapping.Issue i : issues) {
            jdbc.update("INSERT INTO job_p5_sync_issue (external_id, run_id, field_name, code, message, critical, created_at) "
                    + "VALUES (?, ?, ?, ?, ?, ?, ?)", externalId, runId, i.field(), i.code(), i.message(), i.critical(), Timestamp.from(at));
        }
    }

    public List<Map<String, Object>> runs(int limit) {
        return jdbc.queryForList("SELECT id, kind, trigger_source, status, watermark_from, watermark_to, started_at, finished_at, fetched, "
                + "upserted, failed, hidden, error FROM job_p5_sync_run ORDER BY started_at DESC LIMIT ?", limit);
    }

    public List<Map<String, Object>> failures(String status, int limit) {
        return jdbc.queryForList("SELECT id, external_id, error, attempts, status, next_attempt_at, updated_at FROM job_p5_sync_failure "
                + "WHERE status = ? ORDER BY updated_at DESC LIMIT ?", status, limit);
    }

    public List<Map<String, Object>> openIssues(int limit) {
        return jdbc.queryForList("SELECT external_id, field_name, code, message, critical, created_at FROM job_p5_sync_issue "
                + "ORDER BY created_at DESC LIMIT ?", limit);
    }

    public Set<String> activeLobs() {
        return Set.copyOf(jdbc.queryForList("SELECT code FROM job_p5_lob WHERE active = TRUE", String.class));
    }

    public void upsertLob(String code, String name, boolean active, Instant at) {
        int n = jdbc.update("UPDATE job_p5_lob SET name = ?, active = ?, updated_at = ? WHERE code = ?", name, active, Timestamp.from(at), code);
        if (n == 0) {
            jdbc.update("INSERT INTO job_p5_lob (code, name, active, updated_at) VALUES (?, ?, ?, ?)", code, name, active, Timestamp.from(at));
        }
    }

    public int deactivateLobsNotIn(Set<String> codes, Instant at) {
        int n = 0;
        for (String code : jdbc.queryForList("SELECT code FROM job_p5_lob WHERE active = TRUE", String.class)) {
            if (!codes.contains(code)) {
                n += jdbc.update("UPDATE job_p5_lob SET active = FALSE, updated_at = ? WHERE code = ?", Timestamp.from(at), code);
            }
        }
        return n;
    }

    public List<Map<String, Object>> lobs() {
        return jdbc.queryForList("SELECT code, name, active, updated_at FROM job_p5_lob ORDER BY code");
    }
}
