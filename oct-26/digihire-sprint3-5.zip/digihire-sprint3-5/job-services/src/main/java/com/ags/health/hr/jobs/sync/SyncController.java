package com.ags.health.hr.jobs.sync;

import com.ags.health.hr.common.platform.caller.Caller;
import com.ags.health.hr.common.platform.caller.CallerProvider;
import com.ags.health.hr.common.platform.error.PlatformException;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.Map;

@ConditionalOnProperty(prefix = "digihire.jobs", name = "enabled", havingValue = "true", matchIfMissing = true)
@RestController
public class SyncController {

    public static final String SYNC = "JOB:SYNC";

    private final RequisitionSyncService service;
    private final SyncStore store;
    private final CallerProvider callers;

    public SyncController(RequisitionSyncService service, SyncStore store, CallerProvider callers) {
        this.service = service;
        this.store = store;
        this.callers = callers;
    }

    @PostMapping("/requisition-sync/run")
    public RequisitionSyncService.RunResult run(@RequestParam(defaultValue = "false") boolean full) {
        Caller c = require();
        return service.run(full, "MANUAL:" + c.userId());
    }

    @PostMapping("/lob-sync/run")
    public Map<String, Object> lobs() {
        require();
        return service.syncLobs();
    }

    @GetMapping("/requisition-sync/runs")
    public List<Map<String, Object>> runs(@RequestParam(defaultValue = "50") int limit) {
        require();
        return store.runs(Math.min(limit, 500));
    }

    @GetMapping("/requisition-sync/failures")
    public List<Map<String, Object>> failures(@RequestParam(defaultValue = "PENDING") String status,
                                              @RequestParam(defaultValue = "100") int limit) {
        require();
        return store.failures(status.toUpperCase(), Math.min(limit, 500));
    }

    @PostMapping("/requisition-sync/failures/{failureId}/retry")
    public Map<String, Object> retry(@PathVariable String failureId) {
        require();
        return Map.of("resolved", service.retryOne(failureId));
    }

    @GetMapping("/requisition-sync/issues")
    public List<Map<String, Object>> issues(@RequestParam(defaultValue = "200") int limit) {
        require();
        return store.openIssues(Math.min(limit, 1000));
    }

    @GetMapping("/lobs")
    public List<Map<String, Object>> lobList() {
        callers.require();
        return store.lobs();
    }

    private Caller require() {
        Caller c = callers.require();
        if (!c.has(SYNC)) {
            throw PlatformException.forbidden("PERMISSION_DENIED", "Missing permission " + SYNC);
        }
        return c;
    }
}
