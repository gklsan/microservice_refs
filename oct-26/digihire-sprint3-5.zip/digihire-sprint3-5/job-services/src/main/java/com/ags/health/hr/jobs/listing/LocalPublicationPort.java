package com.ags.health.hr.jobs.listing;

public class LocalPublicationPort implements PublicationPort {

    private final String channel;

    public LocalPublicationPort(String channel) {
        this.channel = channel;
    }

    @Override
    public String channel() {
        return channel;
    }

    @Override
    public String publish(RequisitionRecord requisition) {
        return channel + ":" + requisition.requisitionId();
    }

    @Override
    public void unpublish(RequisitionRecord requisition, String externalRef) {
    }
}
