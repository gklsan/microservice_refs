package com.ags.health.hr.jobs.jdedit;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

import java.sql.Timestamp;
import java.time.Instant;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;

public class JdChangeStore {

    public record Change(String id, String requisitionId, int baseVersion, String proposedJd, String reason, String status,
                         int currentLevel, int totalLevels, String requestedBy, String requestedByEmail, Instant requestedAt,
                         Instant decidedAt) {
    }

    private static final String COLUMNS = "id, requisition_id, base_version, proposed_jd, reason, status, current_level, total_levels, "
            + "requested_by, requested_by_email, requested_at, decided_at";
    private static final RowMapper<Change> ROW = (rs, i) -> new Change(rs.getString(1), rs.getString(2), rs.getInt(3), rs.getString(4),
            rs.getString(5), rs.getString(6), rs.getInt(7), rs.getInt(8), rs.getString(9), rs.getString(10),
            rs.getTimestamp(11).toInstant(), rs.getTimestamp(12) == null ? null : rs.getTimestamp(12).toInstant());

    private final JdbcTemplate jdbc;

    public JdChangeStore(JdbcTemplate jdbc) {
        this.jdbc = jdbc;
    }

    public Change create(String requisitionId, int baseVersion, String jd, String reason, int levels, String by, String byEmail, Instant at) {
        String id = UUID.randomUUID().toString();
        jdbc.update("INSERT INTO job_p5_jd_change (" + COLUMNS + ") VALUES (?, ?, ?, ?, ?, 'PENDING', 1, ?, ?, ?, ?, NULL)", id,
                requisitionId, baseVersion, jd, reason, levels, by, byEmail, Timestamp.from(at));
        return find(id).orElseThrow();
    }

    public Optional<Change> find(String id) {
        return jdbc.query("SELECT " + COLUMNS + " FROM job_p5_jd_change WHERE id = ?", ROW, id).stream().findFirst();
    }

    public Optional<Change> pendingFor(String requisitionId) {
        return jdbc.query("SELECT " + COLUMNS + " FROM job_p5_jd_change WHERE requisition_id = ? AND status = 'PENDING'", ROW,
                requisitionId).stream().findFirst();
    }

    public List<Change> pending(int limit) {
        return jdbc.query("SELECT " + COLUMNS + " FROM job_p5_jd_change WHERE status = 'PENDING' ORDER BY requested_at LIMIT ?", ROW, limit);
    }

    public boolean advance(String id, int fromLevel) {
        return jdbc.update("UPDATE job_p5_jd_change SET current_level = current_level + 1 WHERE id = ? AND status = 'PENDING' "
                + "AND current_level = ?", id, fromLevel) == 1;
    }

    public boolean close(String id, int atLevel, String status, Instant at) {
        return jdbc.update("UPDATE job_p5_jd_change SET status = ?, decided_at = ? WHERE id = ? AND status = 'PENDING' AND current_level = ?",
                status, Timestamp.from(at), id, atLevel) == 1;
    }

    public void action(String changeId, int level, String approverId, String decision, String remarks, Instant at) {
        jdbc.update("INSERT INTO job_p5_jd_change_action (change_id, level_no, approver_id, decision, remarks, decided_at) "
                + "VALUES (?, ?, ?, ?, ?, ?)", changeId, level, approverId, decision, remarks, Timestamp.from(at));
    }

    public List<Map<String, Object>> actions(String changeId) {
        return jdbc.queryForList("SELECT level_no, approver_id, decision, remarks, decided_at FROM job_p5_jd_change_action "
                + "WHERE change_id = ? ORDER BY decided_at", changeId);
    }
}
