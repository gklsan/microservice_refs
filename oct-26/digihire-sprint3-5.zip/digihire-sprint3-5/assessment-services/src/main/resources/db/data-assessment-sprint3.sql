INSERT INTO asm_assessment_mapping (id, lob, role_code, location, assessment_code, sequence_no, trigger_event, trigger_stage, mandatory, active, created_by)
SELECT CAST('7a000000-0000-4000-8000-000000000301' AS UUID), NULL, NULL, NULL, 'VERSANT_GSE', 1, 'STAGE_ENTERED', 'VERSANT_YET_TO_START', TRUE, TRUE, 'db-seed'
WHERE EXISTS (SELECT 1 FROM asm_assessment_definition WHERE code = 'VERSANT_GSE')
  AND NOT EXISTS (SELECT 1 FROM asm_assessment_mapping WHERE trigger_event = 'STAGE_ENTERED' AND trigger_stage = 'VERSANT_YET_TO_START'
                  AND assessment_code = 'VERSANT_GSE')@@
