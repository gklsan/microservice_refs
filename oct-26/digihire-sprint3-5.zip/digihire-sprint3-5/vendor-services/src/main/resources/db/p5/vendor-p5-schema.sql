CREATE TABLE IF NOT EXISTS vend_p5_job_lock (
    name            VARCHAR(80)   PRIMARY KEY,
    locked_until    TIMESTAMP WITH TIME ZONE  NOT NULL,
    locked_at       TIMESTAMP WITH TIME ZONE  NOT NULL,
    locked_by       VARCHAR(160)  NOT NULL
)@@

CREATE TABLE IF NOT EXISTS vend_p5_onboarding (
    id             VARCHAR(36)   PRIMARY KEY,
    legal_name     VARCHAR(200)  NOT NULL,
    email          VARCHAR(254)  NOT NULL,
    mobile         VARCHAR(20),
    contact_name   VARCHAR(200),
    gstin          VARCHAR(15),
    pan            VARCHAR(10),
    address        VARCHAR(500),
    ifsc           VARCHAR(11),
    status         VARCHAR(20)   NOT NULL,
    token_hash     VARCHAR(64),
    register_by    DATE          NOT NULL,
    invited_at     TIMESTAMP WITH TIME ZONE  NOT NULL,
    registered_at  TIMESTAMP WITH TIME ZONE,
    submitted_at   TIMESTAMP WITH TIME ZONE,
    decided_at     TIMESTAMP WITH TIME ZONE,
    current_level  INT           NOT NULL,
    total_levels   INT           NOT NULL,
    vendor_id      VARCHAR(64),
    created_by     VARCHAR(64)   NOT NULL,
    updated_at     TIMESTAMP WITH TIME ZONE  NOT NULL
)@@
CREATE UNIQUE INDEX IF NOT EXISTS ux_vend_p5_onboarding_token ON vend_p5_onboarding (token_hash)@@
CREATE INDEX IF NOT EXISTS ix_vend_p5_onboarding_status ON vend_p5_onboarding (status, register_by)@@

CREATE TABLE IF NOT EXISTS vend_p5_document (
    id             VARCHAR(36)   PRIMARY KEY,
    onboarding_id  VARCHAR(36)   NOT NULL REFERENCES vend_p5_onboarding (id),
    doc_type       VARCHAR(40)   NOT NULL,
    storage_key    VARCHAR(300)  NOT NULL,
    content_type   VARCHAR(60)   NOT NULL,
    size_bytes     BIGINT        NOT NULL,
    sha256         VARCHAR(64)   NOT NULL,
    status         VARCHAR(20)   NOT NULL,
    uploaded_at    TIMESTAMP WITH TIME ZONE  NOT NULL,
    reviewed_by    VARCHAR(64),
    review_note    VARCHAR(1000)
)@@

CREATE TABLE IF NOT EXISTS vend_p5_approval_action (
    onboarding_id  VARCHAR(36)   NOT NULL REFERENCES vend_p5_onboarding (id),
    level_no       INT           NOT NULL,
    actor_id       VARCHAR(64)   NOT NULL,
    decision       VARCHAR(20)   NOT NULL,
    remarks        VARCHAR(1000),
    decided_at     TIMESTAMP WITH TIME ZONE  NOT NULL
)@@

CREATE TABLE IF NOT EXISTS vend_p5_vendor_user (
    user_id    VARCHAR(64)   NOT NULL,
    vendor_id  VARCHAR(64)   NOT NULL,
    active     BOOLEAN       NOT NULL,
    mapped_by  VARCHAR(64)   NOT NULL,
    mapped_at  TIMESTAMP WITH TIME ZONE  NOT NULL,
    PRIMARY KEY (user_id, vendor_id)
)@@

CREATE TABLE IF NOT EXISTS vend_p5_task (
    id               VARCHAR(36)   PRIMARY KEY,
    vendor_id        VARCHAR(64)   NOT NULL,
    requisition_id   VARCHAR(64)   NOT NULL,
    target_count     INT           NOT NULL,
    max_submissions  INT           NOT NULL,
    submitted        INT           NOT NULL,
    valid_from       DATE          NOT NULL,
    valid_to         DATE          NOT NULL,
    status           VARCHAR(20)   NOT NULL,
    created_by       VARCHAR(64)   NOT NULL,
    created_at       TIMESTAMP WITH TIME ZONE  NOT NULL,
    CONSTRAINT ck_vend_p5_task_limit CHECK (submitted <= max_submissions)
)@@
CREATE INDEX IF NOT EXISTS ix_vend_p5_task_vendor ON vend_p5_task (vendor_id, status)@@
CREATE INDEX IF NOT EXISTS ix_vend_p5_task_req ON vend_p5_task (requisition_id, status)@@

CREATE TABLE IF NOT EXISTS vend_p5_candidate_link (
    id              VARCHAR(36)   PRIMARY KEY,
    vendor_id       VARCHAR(64)   NOT NULL,
    task_id         VARCHAR(36)   NOT NULL REFERENCES vend_p5_task (id),
    requisition_id  VARCHAR(64)   NOT NULL,
    email_key       VARCHAR(64)   NOT NULL,
    mobile_key      VARCHAR(64)   NOT NULL,
    candidate_name  VARCHAR(200)  NOT NULL,
    candidate_id    VARCHAR(64),
    application_id  VARCHAR(64),
    status          VARCHAR(40)   NOT NULL,
    submitted_at    TIMESTAMP WITH TIME ZONE  NOT NULL,
    updated_at      TIMESTAMP WITH TIME ZONE  NOT NULL
)@@
CREATE INDEX IF NOT EXISTS ix_vend_p5_link_email ON vend_p5_candidate_link (email_key, submitted_at)@@
CREATE INDEX IF NOT EXISTS ix_vend_p5_link_mobile ON vend_p5_candidate_link (mobile_key, submitted_at)@@
CREATE INDEX IF NOT EXISTS ix_vend_p5_link_app ON vend_p5_candidate_link (application_id)@@
CREATE INDEX IF NOT EXISTS ix_vend_p5_link_vendor ON vend_p5_candidate_link (vendor_id, submitted_at)@@
