package com.ags.health.hr.common.platform.audit;

import org.junit.jupiter.api.Test;

import java.sql.Types;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

class AuditLogColumnPlanTest {

    static ColumnInfo text(String name, int size, boolean nullable) {
        return new ColumnInfo(name, Types.VARCHAR, "VARCHAR", size, nullable, false, false);
    }

    static List<ColumnInfo> core() {
        List<ColumnInfo> c = new ArrayList<>();
        c.add(new ColumnInfo("event_time", Types.TIMESTAMP_WITH_TIMEZONE, "timestamptz", 35, false, false, false));
        c.add(text("event_type", 255, false));
        c.add(text("action", 255, false));
        c.add(text("status", 255, false));
        return c;
    }

    static AuditEvent event(String outcome) {
        return new AuditEvent("SECURITY", "CANDIDATE_BLACKLISTED", "BLACKLIST", "b-1", "cand-1", outcome, "x".repeat(300),
                Map.of("k", "v"), "u-1", "Asha", "asha@agshealth.com", "RECRUITMENT_MANAGER", "corr-1", "assessment-services",
                "10.0.0.1", "POST", "/assessment-services/blacklist", Instant.parse("2026-10-08T10:00:00Z"));
    }

    @Test
    void uuidPrimaryKeyIsGeneratedAndOptionalColumnsFollowTheTable() {
        List<ColumnInfo> cols = core();
        cols.add(0, new ColumnInfo("id", Types.OTHER, "uuid", 2147483647, false, false, false));
        cols.add(text("candidate_id", 255, true));
        cols.add(text("description", 255, true));
        AuditLogColumnPlan plan = AuditLogColumnPlan.from("audit_log", cols, false, 4000);
        assertThat(plan.idMode()).isEqualTo(AuditLogColumnPlan.IdMode.UUID_OBJECT);
        assertThat(plan.columns()).contains("id", "event_type", "candidate_id", "description");
        Object[] values = plan.values(event("SUCCESS"), null);
        assertThat(values.length).isEqualTo(plan.columns().size());
        assertThat(((String) values[plan.columns().indexOf("description")]).length()).isEqualTo(255);
    }

    @Test
    void identityKeysAreLeftToTheDatabaseAndMissingNewColumnsAreSkipped() {
        List<ColumnInfo> cols = core();
        cols.add(0, new ColumnInfo("id", Types.BIGINT, "int8", 19, false, true, true));
        AuditLogColumnPlan plan = AuditLogColumnPlan.from("audit_log", cols, false, 4000);
        assertThat(plan.idMode()).isEqualTo(AuditLogColumnPlan.IdMode.DATABASE);
        assertThat(plan.columns()).doesNotContain("id", "candidate_id");
        assertThat(plan.sql()).startsWith("INSERT INTO audit_log (event_time, event_type, action, status)");
    }

    @Test
    void anythingButSuccessIsStoredAsFailure() {
        AuditLogColumnPlan plan = AuditLogColumnPlan.from("audit_log", core(), false, 4000);
        int status = plan.columns().indexOf("status");
        assertThat(plan.values(event("DENIED"), null)[status]).isEqualTo("FAILURE");
        assertThat(plan.values(event("SUCCESS"), null)[status]).isEqualTo("SUCCESS");
    }

    @Test
    void jsonDetailsUseACastOnPostgresAndFormatJsonOnH2() {
        List<ColumnInfo> cols = core();
        cols.add(new ColumnInfo("details", Types.OTHER, "json", 2147483647, true, false, false));
        assertThat(AuditLogColumnPlan.from("audit_log", cols, false, 4000).sql()).contains("CAST(? AS JSON)");
        assertThat(AuditLogColumnPlan.from("audit_log", cols, true, 4000).sql()).contains("? FORMAT JSON");
    }

    @Test
    void detailsLimitComesFromTheColumn() {
        List<ColumnInfo> cols = core();
        cols.add(text("details", 255, true));
        assertThat(AuditLogColumnPlan.from("audit_log", cols, false, 4000).detailsMaxLength()).isEqualTo(255);
        List<ColumnInfo> unbounded = core();
        unbounded.add(new ColumnInfo("details", Types.VARCHAR, "text", 2147483647, true, false, false));
        assertThat(AuditLogColumnPlan.from("audit_log", unbounded, false, 4000).detailsMaxLength()).isEqualTo(4000);
    }

    @Test
    void refusesTablesItCanNotWriteSafely() {
        assertThatThrownBy(() -> AuditLogColumnPlan.from("audit_log", List.of(), false, 4000))
                .hasMessageContaining("does not exist");
        List<ColumnInfo> ordinal = core();
        ordinal.set(1, new ColumnInfo("event_type", Types.SMALLINT, "int2", 5, false, false, false));
        assertThatThrownBy(() -> AuditLogColumnPlan.from("audit_log", ordinal, false, 4000)).hasMessageContaining("ORDINAL");
        List<ColumnInfo> strict = core();
        strict.add(text("tenant_id", 36, false));
        assertThatThrownBy(() -> AuditLogColumnPlan.from("audit_log", strict, false, 4000)).hasMessageContaining("tenant_id");
        List<ColumnInfo> missing = core();
        missing.remove(3);
        assertThatThrownBy(() -> AuditLogColumnPlan.from("audit_log", missing, false, 4000)).hasMessageContaining("status");
        List<ColumnInfo> numericId = core();
        numericId.add(new ColumnInfo("id", Types.BIGINT, "int8", 19, false, false, false));
        assertThatThrownBy(() -> AuditLogColumnPlan.from("audit_log", numericId, false, 4000))
                .hasMessageContaining("no database default");
    }

    @Test
    void categoriesTheTableDoesNotAllowAreStoredAsActivity() {
        AuditLogColumnPlan plan = AuditLogColumnPlan.from("audit_log", core(), false, 4000,
                java.util.Set.of("ACTIVITY", "TIMESTAMP", "APPROVAL", "WORKFLOW_TRANSITION"));
        int type = plan.columns().indexOf("event_type");
        assertThat(plan.values(event("SUCCESS"), null)[type]).isEqualTo("ACTIVITY");
        assertThat(plan.storedEventType("APPROVAL")).isEqualTo("APPROVAL");
        assertThatThrownBy(() -> AuditLogColumnPlan.from("audit_log", core(), false, 4000, java.util.Set.of("APPROVAL")))
                .hasMessageContaining("ACTIVITY");
    }
}
