package com.ags.health.hr.common.platform.audit;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.Test;

import java.util.Map;

import static org.assertj.core.api.Assertions.assertThat;

class AuditJsonTest {

    private final ObjectMapper mapper = new ObjectMapper();

    @Test
    void oversizedDetailsBecomeAValidTruncationMarker() throws Exception {
        String json = AuditJson.write(mapper, Map.of("big", "y".repeat(5000)), 255);
        assertThat(json.length()).isLessThanOrEqualTo(255);
        assertThat(mapper.readTree(json).get("truncated").asBoolean()).isTrue();
        assertThat(mapper.readTree(json).get("originalLength").asInt()).isGreaterThan(5000);
    }

    @Test
    void smallDetailsAreUntouched() {
        assertThat(AuditJson.write(mapper, Map.of("a", 1), 255)).isEqualTo("{\"a\":1}");
        assertThat(AuditJson.write(mapper, Map.of(), 255)).isNull();
    }
}
