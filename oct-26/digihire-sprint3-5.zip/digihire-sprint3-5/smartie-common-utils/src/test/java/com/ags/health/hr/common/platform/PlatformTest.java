package com.ags.health.hr.common.platform;

import com.ags.health.hr.common.platform.approval.AdminApprovalClient;
import com.ags.health.hr.common.platform.approval.ApprovalChain;
import com.ags.health.hr.common.platform.caller.Caller;
import com.ags.health.hr.common.platform.caller.InternalKeyVerifier;
import com.ags.health.hr.common.platform.crypto.IdentifierHasher;
import com.ags.health.hr.common.platform.error.PlatformException;
import com.ags.health.hr.common.platform.http.InternalHttp;
import com.ags.health.hr.common.platform.jobs.JobLock;
import com.ags.health.hr.common.platform.outbox.OutboxEvent;
import com.ags.health.hr.common.platform.outbox.OutboxStore;
import com.ags.health.hr.common.platform.storage.EnvelopeEncryptingDocumentStore;
import com.ags.health.hr.common.platform.storage.FileInspector;
import com.ags.health.hr.common.platform.storage.InMemoryDocumentStore;
import com.ags.health.hr.common.platform.storage.StaticKeyEncryptionKeyProvider;
import com.ags.health.hr.common.platform.time.BusinessDays;
import com.ags.health.hr.common.platform.validation.IdentityValidators;
import com.ags.health.hr.common.platform.validation.IdentityValidators.Kind;
import com.ags.health.hr.common.platform.validation.Masking;
import com.ags.health.hr.common.platform.workflow.WorkflowDecision;
import com.ags.health.hr.common.platform.workflow.WorkflowHttpClient;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.sun.net.httpserver.HttpServer;
import org.junit.jupiter.api.Test;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.datasource.DriverManagerDataSource;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.charset.StandardCharsets;
import java.time.Clock;
import java.time.DayOfWeek;
import java.time.Duration;
import java.time.Instant;
import java.time.LocalDate;
import java.time.ZoneOffset;
import java.util.Base64;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

class PlatformTest {

    @Test
    void identityValidatorsFollowIndianFormats() {
        assertThat(IdentityValidators.check(Kind.PAN, " abcpe1234f ")).isEmpty();
        assertThat(IdentityValidators.check(Kind.PAN, "ABCDE1234F")).contains("INVALID_PAN");
        assertThat(IdentityValidators.check(Kind.AADHAAR, "2341 2341 2346")).isEmpty();
        assertThat(IdentityValidators.check(Kind.AADHAAR, "234123412345")).contains("INVALID_AADHAAR");
        assertThat(IdentityValidators.check(Kind.GSTIN, "33ABCPE1234F1Z5")).isEmpty();
        assertThat(IdentityValidators.check(Kind.MOBILE, "+91 98765 43210")).isEmpty();
        assertThat(IdentityValidators.check(Kind.MOBILE, "12345")).contains("INVALID_MOBILE");
        assertThat(IdentityValidators.check(Kind.EMAIL, "a@b")).contains("INVALID_EMAIL");
        assertThat(IdentityValidators.checkAge(LocalDate.of(2010, 1, 1), LocalDate.of(2026, 10, 1), 18, 60)).contains("AGE_BELOW_MINIMUM");
        assertThat(Masking.lastFour("ABCPE1234F")).isEqualTo("******234F");
        assertThat(Masking.email("asha@mail.com")).isEqualTo("as**@mail.com");
    }

    @Test
    void identifierHashIsStableAndNormalised() {
        IdentifierHasher h = new IdentifierHasher("pepper-for-tests-123");
        assertThat(h.hash(Kind.EMAIL, "A@Mail.com")).isEqualTo(h.hash(Kind.EMAIL, "a@mail.com"));
        assertThat(h.hash(Kind.PAN, "ABCPE1234F")).isNotEqualTo(h.hash(Kind.EMAIL, "ABCPE1234F"));
        assertThatThrownBy(() -> new IdentifierHasher("short")).isInstanceOf(IllegalStateException.class);
    }

    @Test
    void businessDaysSkipWeekendsAndHolidays() {
        BusinessDays d = new BusinessDays(List.of(DayOfWeek.SATURDAY, DayOfWeek.SUNDAY), List.of(LocalDate.of(2026, 10, 20)));
        assertThat(d.plus(LocalDate.of(2026, 10, 16), 7)).isEqualTo(LocalDate.of(2026, 10, 28));
        assertThat(d.between(LocalDate.of(2026, 10, 16), LocalDate.of(2026, 10, 23))).isEqualTo(4);
    }

    @Test
    void envelopeEncryptionRoundTripsAndDetectsTampering() {
        InMemoryDocumentStore raw = new InMemoryDocumentStore();
        String k1 = Base64.getEncoder().encodeToString(new byte[32]);
        byte[] k2bytes = new byte[32];
        k2bytes[0] = 7;
        String k2 = Base64.getEncoder().encodeToString(k2bytes);
        EnvelopeEncryptingDocumentStore v1 = new EnvelopeEncryptingDocumentStore(raw, new StaticKeyEncryptionKeyProvider("k1:" + k1, "k1"));
        byte[] secret = "id proof".getBytes(StandardCharsets.UTF_8);
        v1.put("doc", secret, "application/pdf", Map.of());
        assertThat(raw.get("doc").orElseThrow()).isNotEqualTo(secret);
        EnvelopeEncryptingDocumentStore rotated = new EnvelopeEncryptingDocumentStore(raw,
                new StaticKeyEncryptionKeyProvider("k1:" + k1 + ",k2:" + k2, "k2"));
        assertThat(rotated.get("doc").orElseThrow()).isEqualTo(secret);
        byte[] tampered = raw.get("doc").orElseThrow().clone();
        tampered[tampered.length - 1] ^= 1;
        raw.put("doc", tampered, "x", Map.of());
        assertThatThrownBy(() -> v1.get("doc")).isInstanceOf(RuntimeException.class);
    }

    @Test
    void internalKeysPreferServiceKeysAndCompareSafely() {
        InternalKeyVerifier v = new InternalKeyVerifier("shared-key", "candidate-services=cand-key,job-services=job-key");
        assertThat(v.verify("cand-key", "spoofed")).contains("candidate-services");
        assertThat(v.verify("shared-key", "assessment-services")).contains("assessment-services");
        assertThat(v.verify("wrong", "x")).isEmpty();
        assertThatThrownBy(() -> new InternalKeyVerifier(null, "")).isInstanceOf(IllegalStateException.class);
    }

    @Test
    void callerPermissionsAndTeamRules() {
        Caller tl = new Caller("tl", "tl@a.com", "TL", Set.of("RECRUITMENT_MANAGER"), Set.of("A:X", "A:Y"), Set.of("A:Y"), "TEAM",
                Set.of("r1"), Set.of(), Set.of(), false);
        assertThat(tl.has("A:Y")).isTrue();
        assertThat(tl.hasFull("A:Y")).isFalse();
        assertThat(tl.leads("r1")).isTrue();
        assertThat(tl.leads("tl")).isFalse();
        assertThat(Caller.system("svc").scopeAll()).isTrue();
    }

    @Test
    void fileInspectorChecksMagicBytesExtensionsAndActivePdf() {
        byte[] pdf = "%PDF-1.4 plain document".getBytes(StandardCharsets.ISO_8859_1);
        assertThat(FileInspector.require(pdf, "a.pdf", 1000, Set.of(FileInspector.Kind.PDF))).isEqualTo(FileInspector.Kind.PDF);
        assertThatThrownBy(() -> FileInspector.require(pdf, "a.png", 1000, Set.of(FileInspector.Kind.PDF))).hasMessageContaining("extension");
        assertThatThrownBy(() -> FileInspector.require(pdf, "../a.pdf", 1000, Set.of(FileInspector.Kind.PDF))).hasMessageContaining("name");
        assertThatThrownBy(() -> FileInspector.require("%PDF-1.4 /OpenAction".getBytes(), "a.pdf", 1000, Set.of(FileInspector.Kind.PDF)))
                .hasMessageContaining("scripts");
        assertThatThrownBy(() -> FileInspector.require(pdf, "a.pdf", 5, Set.of(FileInspector.Kind.PDF))).hasMessageContaining("larger");
    }

    @Test
    void outboxAndJobLockWorkOnH2() {
        DriverManagerDataSource ds = new DriverManagerDataSource("jdbc:h2:mem:plat_" + UUID.randomUUID() + ";DB_CLOSE_DELAY=-1", "sa", "");
        JdbcTemplate jdbc = new JdbcTemplate(ds);
        jdbc.execute("CREATE TABLE t_outbox (seq BIGINT GENERATED BY DEFAULT AS IDENTITY PRIMARY KEY, id UUID NOT NULL UNIQUE, "
                + "event_type VARCHAR(60) NOT NULL, aggregate_type VARCHAR(40) NOT NULL, aggregate_id VARCHAR(200) NOT NULL, "
                + "candidate_id VARCHAR(64), application_id VARCHAR(64), payload VARCHAR(8000) NOT NULL, created_at TIMESTAMP WITH TIME ZONE "
                + "NOT NULL, published_at TIMESTAMP WITH TIME ZONE, publish_attempts INT NOT NULL DEFAULT 0, last_error VARCHAR(500), "
                + "correlation_id VARCHAR(64), next_attempt_at TIMESTAMP WITH TIME ZONE, parked_at TIMESTAMP WITH TIME ZONE)");
        jdbc.execute("CREATE TABLE t_lock (name VARCHAR(80) PRIMARY KEY, locked_until TIMESTAMP WITH TIME ZONE NOT NULL, "
                + "locked_at TIMESTAMP WITH TIME ZONE NOT NULL, locked_by VARCHAR(160) NOT NULL)");
        Clock clock = Clock.fixed(Instant.parse("2026-10-20T00:00:00Z"), ZoneOffset.UTC);
        OutboxStore o = new OutboxStore(jdbc, new ObjectMapper(), clock, "t_outbox", new OutboxStore.Policy(2, 30, 60));
        o.append("A", "X", "1", "C1", "APP1", Map.of("k", "v"));
        o.append("B", "X", "2", null, null, Map.of());
        assertThat(o.due(10, List.of("B"))).extracting(OutboxEvent::eventType).containsExactly("B");
        List<OutboxEvent> due = o.due(10);
        o.markFailed(List.of(due.get(0)), "boom");
        o.markPublished(List.of(due.get(1)));
        assertThat(o.stats().pending()).isEqualTo(1);
        OutboxEvent e = due.get(0);
        o.markFailed(List.of(new OutboxEvent(e.seq(), e.id(), e.eventType(), e.aggregateType(), e.aggregateId(), e.candidateId(),
                e.applicationId(), e.payload(), e.createdAt(), e.correlationId(), 1)), "boom");
        assertThat(o.stats().parked()).isEqualTo(1);
        assertThat(o.requeueParked()).isEqualTo(1);
        JobLock lock = new JobLock(jdbc, clock, "t_lock");
        assertThat(lock.tryAcquire("job", Duration.ofMinutes(5))).isPresent();
        assertThat(lock.tryAcquire("job", Duration.ofMinutes(5))).isEmpty();
    }

    @Test
    void httpClientsTalkToAdminAndWorkflowContracts() throws IOException {
        HttpServer server = HttpServer.create(new InetSocketAddress("127.0.0.1", 0), 0);
        server.createContext("/admin/internal/approvals/JD_EDIT/resolve", ex -> reply(ex, 200,
                "{\"active\":true,\"levels\":[{\"levelNo\":1,\"unresolved\":false,\"approvers\":[{\"smartieUserId\":\"u1\"},{\"email\":\"b@a.com\"}]}]}"));
        server.createContext("/admin/internal/approvals/NOPE/resolve", ex -> reply(ex, 404, "{}"));
        server.createContext("/wf/internal/runtime/instances/APPLICATION/A1/move/validate", ex -> reply(ex, 409,
                "{\"code\":\"NOT_ALLOWED\",\"message\":\"no\",\"allowedTargets\":[\"PIPELINE\"]}"));
        server.createContext("/wf/internal/runtime/instances/APPLICATION/A2/move/validate", ex -> reply(ex, 404, "{}"));
        server.start();
        try {
            String base = "http://127.0.0.1:" + server.getAddress().getPort();
            InternalHttp http = new InternalHttp(new ObjectMapper(), Duration.ofSeconds(5), Map.of("X-Internal-Key", "k"));
            AdminApprovalClient admin = new AdminApprovalClient(http, base + "/admin");
            ApprovalChain chain = admin.resolve("JD_EDIT", "r", "r@a.com", "LOB", "CHN");
            assertThat(chain.resolved()).isTrue();
            assertThat(chain.approverIdsByLevel().get(0)).containsExactly("u1", "b@a.com");
            assertThatThrownBy(() -> admin.resolve("NOPE", "r", null, null, null)).isInstanceOf(PlatformException.class)
                    .hasMessageContaining("not configured");
            WorkflowHttpClient wf = new WorkflowHttpClient(http, base + "/wf");
            WorkflowDecision d = wf.check("APPLICATION", "A1", "CREATED", "OFFERED", Map.of());
            assertThat(d.allowed()).isFalse();
            assertThat(d.allowedTargets()).containsExactly("PIPELINE");
            assertThat(wf.check("APPLICATION", "A2", "CREATED", "PIPELINE", Map.of()).allowed()).isTrue();
        } finally {
            server.stop(0);
        }
    }

    private static void reply(com.sun.net.httpserver.HttpExchange ex, int status, String body) throws IOException {
        byte[] b = body.getBytes(StandardCharsets.UTF_8);
        ex.getResponseHeaders().add("Content-Type", "application/json");
        ex.sendResponseHeaders(status, b.length);
        ex.getResponseBody().write(b);
        ex.close();
    }
}
