package com.ags.health.hr.common.platform.time;

import java.time.Clock;
import java.time.Instant;
import java.time.LocalDate;
import java.time.ZoneId;
import java.time.ZonedDateTime;

public class BusinessClock {

    public static final ZoneId INDIA = ZoneId.of("Asia/Kolkata");

    private final Clock clock;
    private final ZoneId zone;

    public BusinessClock(Clock clock, ZoneId zone) {
        this.clock = clock;
        this.zone = zone == null ? INDIA : zone;
    }

    public static BusinessClock india() {
        return new BusinessClock(Clock.systemUTC(), INDIA);
    }

    public Instant now() {
        return clock.instant();
    }

    public LocalDate today() {
        return LocalDate.ofInstant(clock.instant(), zone);
    }

    public LocalDate dateOf(Instant instant) {
        return instant == null ? null : LocalDate.ofInstant(instant, zone);
    }

    public Instant startOf(LocalDate date) {
        return date.atStartOfDay(zone).toInstant();
    }

    public Instant endOf(LocalDate date) {
        return date.plusDays(1).atStartOfDay(zone).toInstant().minusMillis(1);
    }

    public ZonedDateTime zoned(Instant instant) {
        return instant.atZone(zone);
    }

    public ZoneId zone() {
        return zone;
    }

    public Clock clock() {
        return clock;
    }
}
