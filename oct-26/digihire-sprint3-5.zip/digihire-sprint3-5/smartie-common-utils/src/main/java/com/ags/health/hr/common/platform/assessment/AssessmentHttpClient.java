package com.ags.health.hr.common.platform.assessment;

import com.ags.health.hr.common.platform.error.PlatformException;
import com.ags.health.hr.common.platform.http.InternalHttp;
import com.fasterxml.jackson.databind.JsonNode;

import java.time.Instant;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class AssessmentHttpClient implements AssessmentPort {

    private final InternalHttp http;
    private final String base;

    public AssessmentHttpClient(InternalHttp http, String baseUrl) {
        this.http = http;
        this.base = InternalHttp.trimBase(baseUrl);
    }

    @Override
    public EligibilityResult check(String candidateId, String email, String mobile, String assessmentCode, String lob,
                                   String roleCode, String location, String purpose) {
        Map<String, Object> body = new LinkedHashMap<>();
        body.put("candidateId", candidateId);
        body.put("email", email);
        body.put("mobile", mobile);
        body.put("assessmentCode", assessmentCode);
        body.put("lob", lob);
        body.put("roleCode", roleCode);
        body.put("location", location);
        body.put("purpose", purpose);
        JsonNode node;
        try {
            node = http.post(base + "/internal/eligibility/check", body);
        } catch (InternalHttp.Failure f) {
            throw PlatformException.unavailable("ELIGIBILITY_UNAVAILABLE", "Eligibility can not be checked right now");
        }
        List<EligibilityResult.Reason> reasons = new ArrayList<>();
        node.path("reasons").forEach(r -> reasons.add(new EligibilityResult.Reason(r.path("code").asText(),
                r.path("message").asText(null), instant(r.path("until")), r.path("blocking").asBoolean(true))));
        return new EligibilityResult(node.path("eligible").asBoolean(false), reasons);
    }

    @Override
    public List<ValidScore> validScores(String candidateId) {
        JsonNode node;
        try {
            node = http.get(base + "/internal/candidates/" + InternalHttp.encode(candidateId) + "/valid-scores");
        } catch (InternalHttp.Failure f) {
            throw PlatformException.unavailable("ASSESSMENT_UNAVAILABLE", "Assessment scores can not be loaded right now");
        }
        List<ValidScore> out = new ArrayList<>();
        node.forEach(a -> out.add(new ValidScore(a.path("id").asText(), a.path("assessmentCode").asText(),
                a.path("grade").asText(null), a.path("score").isNumber() ? a.path("score").asDouble() : null,
                instant(a.path("completedAt")), instant(a.path("validUntil")))));
        return out;
    }

    @Override
    public void applicationEvent(Map<String, Object> event) {
        http.post(base + "/internal/events/application", event);
    }

    private static Instant instant(JsonNode n) {
        if (n == null || n.isNull() || n.isMissingNode() || n.asText().isBlank()) {
            return null;
        }
        try {
            return Instant.parse(n.asText());
        } catch (RuntimeException e) {
            return null;
        }
    }
}
