package com.ags.health.hr.common.platform.validation;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public record FieldViolation(String field, String code, String message) {

    public Map<String, Object> asMap() {
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("field", field);
        m.put("code", code);
        m.put("message", message);
        return m;
    }

    public static List<Map<String, Object>> asMaps(List<FieldViolation> violations) {
        return violations.stream().map(FieldViolation::asMap).toList();
    }
}
