package com.ags.health.hr.common.platform.caller;

import com.ags.health.hr.common.platform.error.PlatformException;

import java.util.Optional;

public interface CallerProvider {

    Optional<Caller> current();

    default Caller require() {
        return current().orElseThrow(() -> PlatformException.unauthorized("Login required"));
    }

    default Caller currentOrSystem(String service) {
        return current().orElseGet(() -> Caller.system(service));
    }
}
