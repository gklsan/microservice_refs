package com.ags.health.hr.common.platform.storage;

import com.amazonaws.HttpMethod;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.model.GeneratePresignedUrlRequest;
import com.amazonaws.services.s3.model.ObjectMetadata;
import com.amazonaws.services.s3.model.PutObjectRequest;
import com.amazonaws.services.s3.model.ResponseHeaderOverrides;
import com.amazonaws.services.s3.model.S3Object;
import com.amazonaws.services.s3.model.SSEAwsKeyManagementParams;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.URI;
import java.net.URISyntaxException;
import java.time.Duration;
import java.util.Date;
import java.util.Map;
import java.util.Optional;

public class S3DocumentStore implements DocumentStore {

    private final AmazonS3 s3;
    private final String bucket;
    private final String kmsKeyId;

    public S3DocumentStore(AmazonS3 s3, String bucket, String kmsKeyId) {
        this.s3 = s3;
        this.bucket = bucket;
        this.kmsKeyId = kmsKeyId == null || kmsKeyId.isBlank() ? null : kmsKeyId.trim();
    }

    @Override
    public StoredDocument put(String key, byte[] content, String contentType, Map<String, String> metadata) {
        ObjectMetadata meta = new ObjectMetadata();
        meta.setContentLength(content.length);
        if (contentType != null) {
            meta.setContentType(contentType);
        }
        if (metadata != null) {
            metadata.forEach(meta::addUserMetadata);
        }
        PutObjectRequest req = new PutObjectRequest(bucket, key, new ByteArrayInputStream(content), meta);
        if (kmsKeyId != null) {
            req.setSSEAwsKeyManagementParams(new SSEAwsKeyManagementParams(kmsKeyId));
        } else {
            meta.setSSEAlgorithm(ObjectMetadata.AES_256_SERVER_SIDE_ENCRYPTION);
        }
        s3.putObject(req);
        return new StoredDocument(key, contentType, content.length, Digests.sha256(content), false);
    }

    @Override
    public Optional<byte[]> get(String key) {
        if (!s3.doesObjectExist(bucket, key)) {
            return Optional.empty();
        }
        try (S3Object object = s3.getObject(bucket, key); InputStream in = object.getObjectContent()) {
            return Optional.of(in.readAllBytes());
        } catch (IOException e) {
            throw new IllegalStateException("Could not read " + key, e);
        }
    }

    @Override
    public Optional<URI> temporaryUrl(String key, Duration ttl, String downloadName) {
        if (!s3.doesObjectExist(bucket, key)) {
            return Optional.empty();
        }
        GeneratePresignedUrlRequest req = new GeneratePresignedUrlRequest(bucket, key)
                .withMethod(HttpMethod.GET)
                .withExpiration(new Date(System.currentTimeMillis() + ttl.toMillis()));
        if (downloadName != null) {
            req.setResponseHeaders(new ResponseHeaderOverrides()
                    .withContentDisposition("attachment; filename=\"" + downloadName.replaceAll("[^A-Za-z0-9._-]", "_") + "\""));
        }
        return Optional.of(toUri(s3.generatePresignedUrl(req)));
    }

    @Override
    public URI uploadUrl(String key, Duration ttl, String contentType) {
        GeneratePresignedUrlRequest req = new GeneratePresignedUrlRequest(bucket, key)
                .withMethod(HttpMethod.PUT)
                .withExpiration(new Date(System.currentTimeMillis() + ttl.toMillis()));
        if (contentType != null) {
            req.setContentType(contentType);
        }
        if (kmsKeyId != null) {
            req.setSSEAlgorithm("aws:kms");
            req.setKmsCmkId(kmsKeyId);
        }
        return toUri(s3.generatePresignedUrl(req));
    }

    @Override
    public void delete(String key) {
        s3.deleteObject(bucket, key);
    }

    @Override
    public boolean exists(String key) {
        return s3.doesObjectExist(bucket, key);
    }

    private static URI toUri(java.net.URL url) {
        try {
            return url.toURI();
        } catch (URISyntaxException e) {
            throw new IllegalStateException(e);
        }
    }
}
