package com.ags.health.hr.common.platform.assessment;

import java.time.Instant;
import java.util.List;
import java.util.Map;

public interface AssessmentPort {

    record ValidScore(String attemptId, String assessmentCode, String grade, Double score, Instant completedAt,
                      Instant validUntil) {
    }

    EligibilityResult check(String candidateId, String email, String mobile, String assessmentCode, String lob,
                            String roleCode, String location, String purpose);

    List<ValidScore> validScores(String candidateId);

    void applicationEvent(Map<String, Object> event);
}
