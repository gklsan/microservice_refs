package com.ags.health.hr.common.platform.outbox;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

import java.sql.Timestamp;
import java.time.Clock;
import java.time.Instant;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.regex.Pattern;

public class OutboxStore {

    public record Policy(int maxAttempts, int backoffBaseSeconds, int backoffMaxSeconds) {
    }

    public record Stats(long pending, long parked, Instant oldestPendingAt) {
    }

    private static final Logger log = LoggerFactory.getLogger(OutboxStore.class);
    private static final Pattern TABLE = Pattern.compile("[A-Za-z_][A-Za-z0-9_]{0,62}");

    private final JdbcTemplate jdbc;
    private final ObjectMapper mapper;
    private final Clock clock;
    private final String table;
    private final Policy policy;

    public OutboxStore(JdbcTemplate jdbc, ObjectMapper mapper, Clock clock, String table, Policy policy) {
        if (table == null || !TABLE.matcher(table).matches()) {
            throw new IllegalArgumentException("Invalid outbox table " + table);
        }
        this.jdbc = jdbc;
        this.mapper = mapper;
        this.clock = clock;
        this.table = table;
        this.policy = policy;
    }

    public UUID append(String eventType, String aggregateType, Object aggregateId, String candidateId, String applicationId,
                       Map<String, ?> payload) {
        String json;
        try {
            json = mapper.writeValueAsString(payload == null ? Map.of() : payload);
        } catch (JsonProcessingException e) {
            throw new IllegalStateException("Event payload is not serialisable", e);
        }
        if (json.length() > 8000) {
            throw new IllegalArgumentException("Event payload is larger than 8000 characters: " + eventType);
        }
        UUID id = UUID.randomUUID();
        String correlation = MDC.get("req-id") != null ? MDC.get("req-id") : MDC.get("correlationId");
        jdbc.update("INSERT INTO " + table + " (id, event_type, aggregate_type, aggregate_id, candidate_id, application_id, "
                        + "payload, created_at, correlation_id) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)",
                id, eventType, aggregateType, String.valueOf(aggregateId), candidateId, applicationId, json,
                Timestamp.from(clock.instant()), correlation);
        return id;
    }

    public List<OutboxEvent> due(int limit) {
        return jdbc.query("SELECT seq, id, event_type, aggregate_type, aggregate_id, candidate_id, application_id, payload, "
                        + "created_at, correlation_id, publish_attempts FROM " + table + " WHERE published_at IS NULL "
                        + "AND parked_at IS NULL AND (next_attempt_at IS NULL OR next_attempt_at <= ?) ORDER BY seq LIMIT ?",
                rows(), Timestamp.from(clock.instant()), Math.max(1, limit));
    }

    public List<OutboxEvent> due(int limit, java.util.Collection<String> eventTypes) {
        if (eventTypes == null || eventTypes.isEmpty()) {
            return due(limit);
        }
        List<Object> args = new java.util.ArrayList<>();
        args.add(Timestamp.from(clock.instant()));
        StringBuilder in = new StringBuilder();
        for (String t : eventTypes) {
            in.append(in.length() == 0 ? "?" : ", ?");
            args.add(t);
        }
        args.add(Math.max(1, limit));
        return jdbc.query("SELECT seq, id, event_type, aggregate_type, aggregate_id, candidate_id, application_id, payload, "
                        + "created_at, correlation_id, publish_attempts FROM " + table + " WHERE published_at IS NULL "
                        + "AND parked_at IS NULL AND (next_attempt_at IS NULL OR next_attempt_at <= ?) AND event_type IN ("
                        + in + ") ORDER BY seq LIMIT ?", rows(), args.toArray());
    }

    public void markPublished(List<OutboxEvent> events) {
        Timestamp now = Timestamp.from(clock.instant());
        for (OutboxEvent e : events) {
            jdbc.update("UPDATE " + table + " SET published_at = ?, publish_attempts = publish_attempts + 1, last_error = NULL, "
                    + "next_attempt_at = NULL WHERE seq = ?", now, e.seq());
        }
    }

    public int markFailed(List<OutboxEvent> events, String error) {
        String e = error == null ? null : error.length() > 500 ? error.substring(0, 500) : error;
        Instant now = clock.instant();
        int parked = 0;
        for (OutboxEvent event : events) {
            int attempt = event.attempts() + 1;
            if (OutboxBackoff.shouldPark(attempt, policy.maxAttempts())) {
                jdbc.update("UPDATE " + table + " SET publish_attempts = ?, last_error = ?, parked_at = ?, next_attempt_at = NULL "
                        + "WHERE seq = ?", attempt, e, Timestamp.from(now), event.seq());
                parked++;
                log.error("OUTBOX_EVENT_PARKED table={} seq={} type={} attempts={} lastError={}", table, event.seq(),
                        event.eventType(), attempt, e);
            } else {
                Instant next = now.plus(OutboxBackoff.delay(attempt, policy.backoffBaseSeconds(), policy.backoffMaxSeconds()));
                jdbc.update("UPDATE " + table + " SET publish_attempts = ?, last_error = ?, next_attempt_at = ? WHERE seq = ?",
                        attempt, e, Timestamp.from(next), event.seq());
            }
        }
        return parked;
    }

    public int requeueParked() {
        return jdbc.update("UPDATE " + table + " SET parked_at = NULL, next_attempt_at = NULL, publish_attempts = 0 "
                + "WHERE parked_at IS NOT NULL AND published_at IS NULL");
    }

    public Stats stats() {
        Long pending = jdbc.queryForObject("SELECT count(*) FROM " + table + " WHERE published_at IS NULL AND parked_at IS NULL",
                Long.class);
        Long parked = jdbc.queryForObject("SELECT count(*) FROM " + table + " WHERE parked_at IS NOT NULL AND published_at IS NULL",
                Long.class);
        Timestamp oldest = jdbc.queryForObject("SELECT min(created_at) FROM " + table + " WHERE published_at IS NULL "
                + "AND parked_at IS NULL", Timestamp.class);
        return new Stats(pending == null ? 0 : pending, parked == null ? 0 : parked, oldest == null ? null : oldest.toInstant());
    }

    private RowMapper<OutboxEvent> rows() {
        return (rs, i) -> {
            Timestamp at = rs.getTimestamp("created_at");
            return new OutboxEvent(rs.getLong("seq"), UUID.fromString(rs.getString("id")), rs.getString("event_type"),
                    rs.getString("aggregate_type"), rs.getString("aggregate_id"), rs.getString("candidate_id"),
                    rs.getString("application_id"), parse(rs.getString("payload")), at == null ? null : at.toInstant(),
                    rs.getString("correlation_id"), rs.getInt("publish_attempts"));
        };
    }

    private JsonNode parse(String json) {
        try {
            return mapper.readTree(json);
        } catch (JsonProcessingException e) {
            return null;
        }
    }
}
