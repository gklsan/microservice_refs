package com.ags.health.hr.common.platform.storage;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import java.net.URI;
import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;
import java.security.GeneralSecurityException;
import java.security.SecureRandom;
import java.time.Duration;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Optional;

public class EnvelopeEncryptingDocumentStore implements DocumentStore {

    public static final String CONTENT_TYPE = "application/x-digihire-envelope";

    private static final byte[] MAGIC = "DHE1".getBytes(StandardCharsets.US_ASCII);
    private static final int IV = 12;
    private static final int TAG = 128;

    private final DocumentStore delegate;
    private final KeyEncryptionKeyProvider keys;
    private final SecureRandom random = new SecureRandom();

    public EnvelopeEncryptingDocumentStore(DocumentStore delegate, KeyEncryptionKeyProvider keys) {
        this.delegate = delegate;
        this.keys = keys;
    }

    @Override
    public StoredDocument put(String key, byte[] content, String contentType, Map<String, String> metadata) {
        try {
            KeyGenerator gen = KeyGenerator.getInstance("AES");
            gen.init(256, random);
            SecretKey dek = gen.generateKey();
            String keyId = keys.activeKeyId();
            byte[] wrapped = seal(keys.key(keyId), dek.getEncoded(), aad(key, "dek"));
            byte[] body = seal(dek, content, aad(key, contentType == null ? "" : contentType));
            byte[] id = keyId.getBytes(StandardCharsets.UTF_8);
            byte[] type = (contentType == null ? "" : contentType).getBytes(StandardCharsets.UTF_8);
            ByteBuffer out = ByteBuffer.allocate(MAGIC.length + 2 + id.length + 2 + type.length + 4 + wrapped.length + body.length);
            out.put(MAGIC).putShort((short) id.length).put(id).putShort((short) type.length).put(type)
                    .putInt(wrapped.length).put(wrapped).put(body);
            Map<String, String> meta = metadata == null ? new LinkedHashMap<>() : new LinkedHashMap<>(metadata);
            meta.put("digihire-kek", keyId);
            delegate.put(key, out.array(), CONTENT_TYPE, meta);
            return new StoredDocument(key, contentType, content.length, Digests.sha256(content), true);
        } catch (GeneralSecurityException e) {
            throw new IllegalStateException("Document encryption failed", e);
        }
    }

    @Override
    public Optional<byte[]> get(String key) {
        return delegate.get(key).map(raw -> open(key, raw));
    }

    public Optional<String> contentType(String key) {
        return delegate.get(key).map(raw -> {
            ByteBuffer in = ByteBuffer.wrap(raw);
            byte[] magic = new byte[MAGIC.length];
            in.get(magic);
            in.position(in.position() + in.getShort());
            byte[] type = new byte[in.getShort()];
            in.get(type);
            return new String(type, StandardCharsets.UTF_8);
        });
    }

    @Override
    public Optional<URI> temporaryUrl(String key, Duration ttl, String downloadName) {
        return Optional.empty();
    }

    @Override
    public URI uploadUrl(String key, Duration ttl, String contentType) {
        throw new UnsupportedOperationException("Encrypted documents are uploaded through the service");
    }

    @Override
    public void delete(String key) {
        delegate.delete(key);
    }

    @Override
    public boolean exists(String key) {
        return delegate.exists(key);
    }

    private byte[] open(String key, byte[] raw) {
        try {
            ByteBuffer in = ByteBuffer.wrap(raw);
            byte[] magic = new byte[MAGIC.length];
            in.get(magic);
            if (!java.util.Arrays.equals(magic, MAGIC)) {
                throw new IllegalStateException("Not an encrypted DigiHire document: " + key);
            }
            byte[] id = new byte[in.getShort()];
            in.get(id);
            byte[] type = new byte[in.getShort()];
            in.get(type);
            byte[] wrapped = new byte[in.getInt()];
            in.get(wrapped);
            byte[] body = new byte[in.remaining()];
            in.get(body);
            SecretKey kek = keys.key(new String(id, StandardCharsets.UTF_8));
            SecretKey dek = new SecretKeySpec(unseal(kek, wrapped, aad(key, "dek")), "AES");
            return unseal(dek, body, aad(key, new String(type, StandardCharsets.UTF_8)));
        } catch (GeneralSecurityException e) {
            throw new IllegalStateException("Document can not be decrypted: " + key, e);
        }
    }

    private byte[] seal(SecretKey key, byte[] plain, byte[] aad) throws GeneralSecurityException {
        byte[] iv = new byte[IV];
        random.nextBytes(iv);
        Cipher c = Cipher.getInstance("AES/GCM/NoPadding");
        c.init(Cipher.ENCRYPT_MODE, key, new GCMParameterSpec(TAG, iv));
        c.updateAAD(aad);
        byte[] ct = c.doFinal(plain);
        return ByteBuffer.allocate(IV + ct.length).put(iv).put(ct).array();
    }

    private static byte[] unseal(SecretKey key, byte[] sealed, byte[] aad) throws GeneralSecurityException {
        Cipher c = Cipher.getInstance("AES/GCM/NoPadding");
        c.init(Cipher.DECRYPT_MODE, key, new GCMParameterSpec(TAG, sealed, 0, IV));
        c.updateAAD(aad);
        return c.doFinal(sealed, IV, sealed.length - IV);
    }

    private static byte[] aad(String key, String part) {
        return (key + "|" + part).getBytes(StandardCharsets.UTF_8);
    }
}
