package com.ags.health.hr.common.platform.bulk;

import java.util.List;

public record BulkSummary(String jobId, int total, int succeeded, int failed, List<BulkItemResult> items) {

    public static BulkSummary of(String jobId, List<BulkItemResult> items) {
        int ok = (int) items.stream().filter(BulkItemResult::ok).count();
        return new BulkSummary(jobId, items.size(), ok, items.size() - ok, List.copyOf(items));
    }
}
