package com.ags.health.hr.common.platform.db;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.io.ClassPathResource;
import org.springframework.jdbc.datasource.init.ResourceDatabasePopulator;

import javax.sql.DataSource;
import java.util.List;

public class SchemaInitializer {

    private static final Logger log = LoggerFactory.getLogger(SchemaInitializer.class);

    private final DataSource dataSource;
    private final List<String> scripts;

    public SchemaInitializer(DataSource dataSource, List<String> scripts) {
        this.dataSource = dataSource;
        this.scripts = List.copyOf(scripts);
    }

    public void run() {
        for (String script : scripts) {
            ResourceDatabasePopulator populator = new ResourceDatabasePopulator(new ClassPathResource(script));
            populator.setSeparator("@@");
            populator.setContinueOnError(false);
            populator.execute(dataSource);
            log.info("Applied schema script {}", script);
        }
    }
}
