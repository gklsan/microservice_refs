package com.ags.health.hr.common.platform.jobs;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;

import java.time.Duration;
import java.util.Locale;
import java.util.Optional;
import java.util.UUID;
import java.util.function.BooleanSupplier;

public class ScheduledJobRunner {

    private static final Logger log = LoggerFactory.getLogger(ScheduledJobRunner.class);

    private final JobLock lock;
    private final BooleanSupplier enabled;
    private final Duration atMostFor;

    public ScheduledJobRunner(JobLock lock, BooleanSupplier enabled, Duration atMostFor) {
        this.lock = lock;
        this.enabled = enabled;
        this.atMostFor = atMostFor;
    }

    public boolean run(String name, Duration atLeastFor, Runnable work) {
        if (!enabled.getAsBoolean()) {
            return false;
        }
        Optional<JobLock.Lease> lease = lock.tryAcquire(name, atMostFor);
        if (lease.isEmpty()) {
            return false;
        }
        String id = name.toLowerCase(Locale.ROOT).replaceAll("[^a-z0-9_-]", "-");
        id = (id.length() > 26 ? id.substring(0, 26) : id) + "-" + UUID.randomUUID().toString().replace("-", "").substring(0, 20);
        boolean setPrimary = MDC.get("req-id") == null;
        if (setPrimary) {
            MDC.put("req-id", id);
            MDC.put("correlationId", id);
        }
        try {
            work.run();
            return true;
        } catch (RuntimeException e) {
            log.error("JOB_FAILED job={} error={}", name, e.getMessage(), e);
            return false;
        } finally {
            lock.release(lease.get(), atLeastFor);
            if (setPrimary) {
                MDC.remove("req-id");
                MDC.remove("correlationId");
            }
        }
    }
}
