package com.ags.health.hr.common.platform.audit;

import org.springframework.jdbc.core.JdbcTemplate;

public final class LocalAuditLogTable {

    private LocalAuditLogTable() {
    }

    public static boolean createIfMissingOnH2(JdbcTemplate jdbc, String table) {
        if (!AuditTableInspector.isH2(jdbc) || !AuditTableInspector.columns(jdbc, table).isEmpty()) {
            return false;
        }
        jdbc.execute("CREATE TABLE IF NOT EXISTS " + table + " ("
                + "id UUID PRIMARY KEY, "
                + "event_time TIMESTAMP WITH TIME ZONE NOT NULL, "
                + "event_type VARCHAR(40) NOT NULL, "
                + "action VARCHAR(255) NOT NULL, "
                + "service_name VARCHAR(255), "
                + "actor_id VARCHAR(255), "
                + "actor_role VARCHAR(255), "
                + "actor_email VARCHAR(255), "
                + "actor_name VARCHAR(255), "
                + "target_type VARCHAR(255), "
                + "target_id VARCHAR(255), "
                + "candidate_id VARCHAR(255), "
                + "http_method VARCHAR(16), "
                + "endpoint VARCHAR(512), "
                + "source_ip VARCHAR(64), "
                + "correlation_id VARCHAR(64), "
                + "status VARCHAR(16) NOT NULL, "
                + "description VARCHAR(2000), "
                + "details VARCHAR(4000), "
                + "created_at TIMESTAMP WITH TIME ZONE)");
        jdbc.execute("CREATE INDEX IF NOT EXISTS ix_" + table + "_event_time ON " + table + " (event_time)");
        jdbc.execute("CREATE INDEX IF NOT EXISTS ix_" + table + "_candidate ON " + table + " (candidate_id)");
        jdbc.execute("CREATE INDEX IF NOT EXISTS ix_" + table + "_correlation ON " + table + " (correlation_id)");
        jdbc.execute("CREATE INDEX IF NOT EXISTS ix_" + table + "_target ON " + table + " (target_type, target_id)");
        return true;
    }
}
