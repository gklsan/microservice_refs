package com.ags.health.hr.common.platform.time;

import java.time.DayOfWeek;
import java.time.LocalDate;
import java.util.Collection;
import java.util.EnumSet;
import java.util.Set;

public class BusinessDays {

    private final Set<DayOfWeek> weekend;
    private final Set<LocalDate> holidays;

    public BusinessDays(Collection<DayOfWeek> weekend, Collection<LocalDate> holidays) {
        this.weekend = weekend == null || weekend.isEmpty() ? EnumSet.of(DayOfWeek.SATURDAY, DayOfWeek.SUNDAY)
                : EnumSet.copyOf(weekend);
        this.holidays = holidays == null ? Set.of() : Set.copyOf(holidays);
    }

    public boolean isBusinessDay(LocalDate date) {
        return !weekend.contains(date.getDayOfWeek()) && !holidays.contains(date);
    }

    public LocalDate plus(LocalDate start, int businessDays) {
        LocalDate d = start;
        int added = 0;
        while (added < businessDays) {
            d = d.plusDays(1);
            if (isBusinessDay(d)) {
                added++;
            }
        }
        return d;
    }

    public int between(LocalDate fromExclusive, LocalDate toInclusive) {
        int count = 0;
        LocalDate d = fromExclusive;
        while (d.isBefore(toInclusive)) {
            d = d.plusDays(1);
            if (isBusinessDay(d)) {
                count++;
            }
        }
        return count;
    }
}
