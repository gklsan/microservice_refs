package com.ags.health.hr.common.platform.audit;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.jdbc.core.JdbcTemplate;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class SharedAuditLogSink implements AuditSink {

    private static final Logger log = LoggerFactory.getLogger(SharedAuditLogSink.class);
    private static final List<String> EMITTED = List.of("ACTIVITY", "APPROVAL", "WORKFLOW_TRANSITION", "CONFIG_CHANGE",
            "SECURITY", "NOTIFICATION");

    private final JdbcTemplate jdbc;
    private final ObjectMapper mapper;
    private final AuditLogColumnPlan plan;

    public SharedAuditLogSink(JdbcTemplate jdbc, ObjectMapper mapper, AuditLogColumnPlan plan) {
        this.jdbc = jdbc;
        this.mapper = mapper;
        this.plan = plan;
    }

    public static SharedAuditLogSink create(JdbcTemplate jdbc, ObjectMapper mapper, String table, int defaultDetailsLength) {
        boolean h2 = AuditTableInspector.isH2(jdbc);
        Set<String> allowed = AuditTableInspector.allowedValues(jdbc, table, "event_type").orElse(null);
        AuditLogColumnPlan plan = AuditLogColumnPlan.from(table, AuditTableInspector.columns(jdbc, table), h2,
                defaultDetailsLength, allowed);
        if (allowed != null) {
            List<String> refused = EMITTED.stream().filter(c -> !allowed.contains(c)).toList();
            if (!refused.isEmpty()) {
                log.warn("AUDIT_EVENT_TYPE_CONSTRAINT table={} allowed={} - {} events are stored as {} with "
                        + "details.category; widen the event_type check constraint", table, allowed, refused,
                        AuditLogColumnPlan.FALLBACK_EVENT_TYPE);
            }
        }
        return new SharedAuditLogSink(jdbc, mapper, plan);
    }

    public AuditLogColumnPlan plan() {
        return plan;
    }

    @Override
    public String name() {
        return "AUDIT_LOG(" + plan.table() + ")";
    }

    @Override
    public void write(AuditEvent event) {
        Map<String, Object> details = event.details() == null ? new LinkedHashMap<>() : new LinkedHashMap<>(event.details());
        if (!event.succeeded() && !AuditEvent.FAILURE.equalsIgnoreCase(event.outcome())) {
            details.putIfAbsent("outcome", event.outcome());
        }
        String stored = plan.storedEventType(event.category());
        if (stored != null && !stored.equals(event.category())) {
            details.putIfAbsent("category", event.category());
        }
        String json = AuditJson.write(mapper, details, plan.detailsMaxLength());
        jdbc.update(plan.sql(), plan.values(event, json));
    }
}
