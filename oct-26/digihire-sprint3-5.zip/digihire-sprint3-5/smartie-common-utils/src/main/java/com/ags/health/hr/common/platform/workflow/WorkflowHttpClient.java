package com.ags.health.hr.common.platform.workflow;

import com.ags.health.hr.common.platform.http.InternalHttp;
import com.fasterxml.jackson.databind.JsonNode;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class WorkflowHttpClient implements WorkflowPort {

    private final InternalHttp http;
    private final String base;

    public WorkflowHttpClient(InternalHttp http, String baseUrl) {
        this.http = http;
        this.base = InternalHttp.trimBase(baseUrl);
    }

    @Override
    public WorkflowDecision check(String entityType, String entityId, String fromState, String toState,
                                  Map<String, Object> context) {
        Map<String, Object> body = new LinkedHashMap<>();
        body.put("targetState", toState);
        body.put("payload", context == null ? Map.of() : context);
        try {
            JsonNode node = http.post(url(entityType, entityId) + "/move/validate", body);
            boolean allowed = node.path("allowed").asBoolean(false);
            List<String> targets = new ArrayList<>();
            node.path("allowedTargets").forEach(t -> targets.add(t.asText()));
            return allowed ? WorkflowDecision.allow(fromState, toState)
                    : WorkflowDecision.deny(node.path("code").asText("TRANSITION_NOT_ALLOWED"),
                    node.path("message").asText("Move not allowed by the workflow"), fromState, toState, targets);
        } catch (InternalHttp.Failure f) {
            if (f.status() == 404) {
                return WorkflowDecision.allow(fromState, toState);
            }
            if (f.status() == 409 || f.status() == 422) {
                List<String> targets = new ArrayList<>();
                String code = "TRANSITION_NOT_ALLOWED";
                String message = "Move not allowed by the workflow";
                try {
                    JsonNode body2 = http.mapper().readTree(f.body() == null ? "{}" : f.body());
                    body2.path("allowedTargets").forEach(t -> targets.add(t.asText()));
                    code = body2.path("code").asText(code);
                    message = body2.path("message").asText(body2.path("detail").asText(message));
                } catch (Exception ignored) {
                    targets.clear();
                }
                return WorkflowDecision.deny(code, message, fromState, toState, targets);
            }
            throw f;
        }
    }

    @Override
    public void moved(String entityType, String entityId, String fromState, String toState, Map<String, Object> context) {
        Map<String, Object> body = new LinkedHashMap<>();
        body.put("targetState", toState);
        body.put("payload", context == null ? Map.of() : context);
        try {
            http.post(url(entityType, entityId) + "/move", body);
        } catch (InternalHttp.Failure f) {
            if (f.status() != 404) {
                throw f;
            }
        }
    }

    private String url(String entityType, String entityId) {
        return base + "/internal/runtime/instances/" + InternalHttp.encode(entityType) + "/" + InternalHttp.encode(entityId);
    }
}
