package com.ags.health.hr.common.platform.approval;

import com.ags.health.hr.common.platform.error.PlatformException;
import com.ags.health.hr.common.platform.http.InternalHttp;
import com.fasterxml.jackson.databind.JsonNode;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class AdminApprovalClient implements ApprovalPort {

    private final InternalHttp http;
    private final String base;

    public AdminApprovalClient(InternalHttp http, String adminBaseUrl) {
        this.http = http;
        this.base = InternalHttp.trimBase(adminBaseUrl);
    }

    @Override
    public ApprovalChain resolve(String flowCode, String requesterId, String requesterEmail, String lob, String location) {
        Map<String, Object> q = new LinkedHashMap<>();
        q.put("requesterId", requesterId);
        q.put("requesterEmail", requesterEmail);
        q.put("lob", lob);
        q.put("location", location);
        JsonNode node = call(InternalHttp.query(base + "/internal/approvals/" + InternalHttp.encode(flowCode) + "/resolve", q));
        List<List<String>> levels = new ArrayList<>();
        boolean[] resolved = {node.path("active").asBoolean(true)};
        node.path("levels").forEach(level -> {
            List<String> ids = new ArrayList<>();
            level.path("approvers").forEach(a -> {
                String id = a.path("smartieUserId").asText("");
                ids.add(id.isBlank() ? a.path("email").asText() : id);
            });
            if (level.path("unresolved").asBoolean(false) || ids.isEmpty()) {
                resolved[0] = false;
            }
            levels.add(ids);
        });
        return new ApprovalChain(flowCode, levels.size(), levels, resolved[0] && !levels.isEmpty());
    }

    @Override
    public boolean canApprove(String flowCode, int level, String approverId, String approverEmail, String requesterId,
                              String requesterEmail, String lob, String location) {
        Map<String, Object> q = new LinkedHashMap<>();
        q.put("level", level);
        q.put("approverId", approverId);
        q.put("approverEmail", approverEmail);
        q.put("requesterId", requesterId);
        q.put("requesterEmail", requesterEmail);
        q.put("lob", lob);
        q.put("location", location);
        JsonNode node = call(InternalHttp.query(base + "/internal/approvals/" + InternalHttp.encode(flowCode) + "/can-approve", q));
        return node.path("allowed").asBoolean(false);
    }

    private JsonNode call(String url) {
        try {
            return http.get(url);
        } catch (InternalHttp.Failure f) {
            if (f.status() == 404) {
                throw PlatformException.badRequest("APPROVAL_FLOW_MISSING", "The approval flow is not configured in admin-services");
            }
            throw PlatformException.unavailable("APPROVAL_SERVICE_UNAVAILABLE", "Approval hierarchy can not be loaded right now");
        }
    }
}
