package com.ags.health.hr.common.platform.storage;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.util.Optional;

public final class ImageInspector {

    public record Dimensions(int width, int height) {

        public double aspect() {
            return height == 0 ? 0 : (double) width / height;
        }
    }

    private ImageInspector() {
    }

    public static Optional<Dimensions> dimensions(byte[] content) {
        try {
            BufferedImage img = ImageIO.read(new ByteArrayInputStream(content));
            return img == null ? Optional.empty() : Optional.of(new Dimensions(img.getWidth(), img.getHeight()));
        } catch (IOException | RuntimeException e) {
            return Optional.empty();
        }
    }
}
