package com.ags.health.hr.common.platform.audit;

public interface AuditSink {

    String name();

    void write(AuditEvent event);
}
