package com.ags.health.hr.common.platform.audit;

public record ColumnInfo(String name, int jdbcType, String typeName, int size, boolean nullable, boolean autoIncrement,
                         boolean hasDefault) {
}
