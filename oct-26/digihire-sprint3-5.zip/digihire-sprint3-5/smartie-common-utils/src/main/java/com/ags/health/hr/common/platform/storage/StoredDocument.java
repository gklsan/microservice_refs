package com.ags.health.hr.common.platform.storage;

public record StoredDocument(String key, String contentType, long size, String sha256, boolean encrypted) {
}
