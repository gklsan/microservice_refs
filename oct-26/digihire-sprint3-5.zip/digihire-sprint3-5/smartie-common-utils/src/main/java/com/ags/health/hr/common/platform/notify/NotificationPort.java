package com.ags.health.hr.common.platform.notify;

public interface NotificationPort {

    void trigger(NotificationRequest request);
}
