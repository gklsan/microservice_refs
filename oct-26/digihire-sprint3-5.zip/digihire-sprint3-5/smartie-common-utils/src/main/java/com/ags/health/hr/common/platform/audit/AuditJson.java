package com.ags.health.hr.common.platform.audit;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.util.LinkedHashMap;
import java.util.Map;

public final class AuditJson {

    private AuditJson() {
    }

    public static String write(ObjectMapper mapper, Map<String, ?> details, int maxLength) {
        if (details == null || details.isEmpty()) {
            return null;
        }
        String json;
        try {
            json = mapper.writeValueAsString(details);
        } catch (JsonProcessingException e) {
            json = "{\"serialisationError\":true}";
        }
        if (maxLength <= 0 || json.length() <= maxLength) {
            return json;
        }
        Map<String, Object> cut = new LinkedHashMap<>();
        cut.put("truncated", true);
        cut.put("originalLength", json.length());
        int room = maxLength - 80;
        if (room > 0) {
            cut.put("preview", json.substring(0, Math.min(room, json.length())));
        }
        try {
            String shortened = mapper.writeValueAsString(cut);
            while (shortened.length() > maxLength && room > 0) {
                room = room - Math.max(16, shortened.length() - maxLength);
                if (room > 0) {
                    cut.put("preview", json.substring(0, room));
                } else {
                    cut.remove("preview");
                }
                shortened = mapper.writeValueAsString(cut);
            }
            return shortened.length() <= maxLength ? shortened : null;
        } catch (JsonProcessingException e) {
            return null;
        }
    }

    public static String cut(String value, int max) {
        if (value == null || max <= 0 || value.length() <= max) {
            return value;
        }
        return value.substring(0, max);
    }
}
