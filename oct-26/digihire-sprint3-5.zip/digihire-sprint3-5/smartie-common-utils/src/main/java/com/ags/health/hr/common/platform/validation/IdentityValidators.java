package com.ags.health.hr.common.platform.validation;

import java.time.LocalDate;
import java.time.Period;
import java.util.Locale;
import java.util.Optional;
import java.util.regex.Pattern;

public final class IdentityValidators {

    public enum Kind { PAN, AADHAAR, PASSPORT, VOTER_ID, DRIVING_LICENCE, MOBILE, EMAIL, PINCODE, NAME, GSTIN, IFSC, TEXT }

    private static final Pattern PAN = Pattern.compile("[A-Z]{3}[ABCFGHLJPT][A-Z][0-9]{4}[A-Z]");
    private static final Pattern AADHAAR = Pattern.compile("[2-9][0-9]{11}");
    private static final Pattern PASSPORT = Pattern.compile("[A-PR-WY][1-9][0-9]{5}[1-9]");
    private static final Pattern VOTER_ID = Pattern.compile("[A-Z]{3}[0-9]{7}");
    private static final Pattern DRIVING_LICENCE = Pattern.compile("[A-Z]{2}[0-9]{2}[0-9]{4}[0-9]{7}");
    private static final Pattern MOBILE_IN = Pattern.compile("[6-9][0-9]{9}");
    private static final Pattern MOBILE_E164 = Pattern.compile("\\+[1-9][0-9]{7,14}");
    private static final Pattern EMAIL = Pattern.compile("[A-Za-z0-9._%+-]{1,64}@[A-Za-z0-9-]+(\\.[A-Za-z0-9-]+)*\\.[A-Za-z]{2,24}");
    private static final Pattern PINCODE = Pattern.compile("[1-9][0-9]{5}");
    private static final Pattern NAME = Pattern.compile("[\\p{L}][\\p{L} .'-]{0,99}");
    private static final Pattern GSTIN = Pattern.compile("[0-9]{2}[A-Z]{5}[0-9]{4}[A-Z][1-9A-Z]Z[0-9A-Z]");
    private static final Pattern IFSC = Pattern.compile("[A-Z]{4}0[A-Z0-9]{6}");

    private static final int[][] D = {
            {0, 1, 2, 3, 4, 5, 6, 7, 8, 9}, {1, 2, 3, 4, 0, 6, 7, 8, 9, 5}, {2, 3, 4, 0, 1, 7, 8, 9, 5, 6},
            {3, 4, 0, 1, 2, 8, 9, 5, 6, 7}, {4, 0, 1, 2, 3, 9, 5, 6, 7, 8}, {5, 9, 8, 7, 6, 0, 4, 3, 2, 1},
            {6, 5, 9, 8, 7, 1, 0, 4, 3, 2}, {7, 6, 5, 9, 8, 2, 1, 0, 4, 3}, {8, 7, 6, 5, 9, 3, 2, 1, 0, 4},
            {9, 8, 7, 6, 5, 4, 3, 2, 1, 0}};
    private static final int[][] P = {
            {0, 1, 2, 3, 4, 5, 6, 7, 8, 9}, {1, 5, 7, 6, 2, 8, 3, 0, 9, 4}, {5, 8, 0, 3, 7, 9, 6, 1, 4, 2},
            {8, 9, 1, 6, 0, 4, 3, 5, 2, 7}, {9, 4, 5, 3, 1, 2, 6, 8, 7, 0}, {4, 2, 8, 6, 5, 7, 3, 9, 0, 1},
            {2, 7, 9, 3, 8, 0, 6, 4, 1, 5}, {7, 0, 4, 6, 9, 1, 3, 2, 5, 8}};

    private IdentityValidators() {
    }

    public static String normalise(Kind kind, String value) {
        if (value == null) {
            return null;
        }
        String v = value.trim();
        return switch (kind) {
            case PAN, PASSPORT, VOTER_ID, DRIVING_LICENCE, GSTIN, IFSC -> v.replaceAll("[\\s-]", "").toUpperCase(Locale.ROOT);
            case AADHAAR, PINCODE -> v.replaceAll("[\\s-]", "");
            case MOBILE -> {
                String digits = v.replaceAll("[\\s()-]", "");
                if (digits.startsWith("+91") && digits.length() == 13) {
                    yield digits.substring(3);
                }
                if (digits.startsWith("0") && digits.length() == 11) {
                    yield digits.substring(1);
                }
                yield digits;
            }
            case EMAIL -> v.toLowerCase(Locale.ROOT);
            case NAME, TEXT -> v.replaceAll("\\s+", " ");
        };
    }

    public static Optional<String> check(Kind kind, String raw) {
        String v = normalise(kind, raw);
        if (v == null || v.isEmpty()) {
            return Optional.of("REQUIRED");
        }
        boolean ok = switch (kind) {
            case PAN -> PAN.matcher(v).matches();
            case AADHAAR -> AADHAAR.matcher(v).matches() && verhoeff(v);
            case PASSPORT -> PASSPORT.matcher(v).matches();
            case VOTER_ID -> VOTER_ID.matcher(v).matches();
            case DRIVING_LICENCE -> DRIVING_LICENCE.matcher(v).matches();
            case MOBILE -> MOBILE_IN.matcher(v).matches() || MOBILE_E164.matcher(v).matches();
            case EMAIL -> v.length() <= 254 && EMAIL.matcher(v).matches();
            case PINCODE -> PINCODE.matcher(v).matches();
            case NAME -> NAME.matcher(v).matches();
            case GSTIN -> GSTIN.matcher(v).matches();
            case IFSC -> IFSC.matcher(v).matches();
            case TEXT -> v.length() <= 2000;
        };
        return ok ? Optional.empty() : Optional.of("INVALID_" + kind.name());
    }

    public static Optional<String> checkAge(LocalDate dob, LocalDate today, int minYears, int maxYears) {
        if (dob == null) {
            return Optional.of("REQUIRED");
        }
        if (dob.isAfter(today)) {
            return Optional.of("DOB_IN_FUTURE");
        }
        int years = Period.between(dob, today).getYears();
        if (years < minYears) {
            return Optional.of("AGE_BELOW_MINIMUM");
        }
        if (years > maxYears) {
            return Optional.of("AGE_ABOVE_MAXIMUM");
        }
        return Optional.empty();
    }

    public static boolean verhoeff(String digits) {
        int c = 0;
        int len = digits.length();
        for (int i = 0; i < len; i++) {
            int d = digits.charAt(len - 1 - i) - '0';
            if (d < 0 || d > 9) {
                return false;
            }
            c = D[c][P[i % 8][d]];
        }
        return c == 0;
    }
}
