package com.ags.health.hr.common.platform.storage;

import com.ags.health.hr.common.platform.error.PlatformException;

import java.nio.charset.StandardCharsets;
import java.util.Locale;
import java.util.Set;

public final class FileInspector {

    public enum Kind {
        PDF("application/pdf", "pdf"), JPEG("image/jpeg", "jpg"), PNG("image/png", "png"), MP4("video/mp4", "mp4"),
        WEBM("video/webm", "webm");

        private final String contentType;
        private final String extension;

        Kind(String contentType, String extension) {
            this.contentType = contentType;
            this.extension = extension;
        }

        public String contentType() {
            return contentType;
        }

        public String extension() {
            return extension;
        }
    }

    private static final String[] PDF_ACTIVE = {"/JavaScript", "/JS", "/Launch", "/EmbeddedFile", "/OpenAction", "/RichMedia"};

    private FileInspector() {
    }

    public static Kind detect(byte[] content) {
        if (content == null || content.length < 12) {
            return null;
        }
        if (content[0] == '%' && content[1] == 'P' && content[2] == 'D' && content[3] == 'F' && content[4] == '-') {
            return Kind.PDF;
        }
        if ((content[0] & 0xFF) == 0xFF && (content[1] & 0xFF) == 0xD8 && (content[2] & 0xFF) == 0xFF) {
            return Kind.JPEG;
        }
        if ((content[0] & 0xFF) == 0x89 && content[1] == 'P' && content[2] == 'N' && content[3] == 'G') {
            return Kind.PNG;
        }
        if (content[4] == 'f' && content[5] == 't' && content[6] == 'y' && content[7] == 'p') {
            return Kind.MP4;
        }
        if ((content[0] & 0xFF) == 0x1A && (content[1] & 0xFF) == 0x45 && (content[2] & 0xFF) == 0xDF && (content[3] & 0xFF) == 0xA3) {
            return Kind.WEBM;
        }
        return null;
    }

    public static Kind require(byte[] content, String fileName, long maxBytes, Set<Kind> allowed) {
        if (content == null || content.length == 0) {
            throw PlatformException.badRequest("FILE_EMPTY", "File is empty");
        }
        if (content.length > maxBytes) {
            throw PlatformException.badRequest("FILE_TOO_LARGE", "File is larger than " + (maxBytes / 1024) + " KB");
        }
        Kind kind = detect(content);
        if (kind == null || !allowed.contains(kind)) {
            throw PlatformException.badRequest("FILE_TYPE_NOT_ALLOWED", "Allowed file types: " + allowed);
        }
        if (fileName != null) {
            String name = fileName.toLowerCase(Locale.ROOT);
            if (name.contains("..") || name.contains("/") || name.contains("\\") || name.chars().filter(c -> c == '.').count() > 1) {
                throw PlatformException.badRequest("FILE_NAME_INVALID", "File name is not allowed");
            }
            String ext = name.contains(".") ? name.substring(name.lastIndexOf('.') + 1) : "";
            boolean extOk = ext.equals(kind.extension()) || (kind == Kind.JPEG && ext.equals("jpeg"));
            if (!extOk) {
                throw PlatformException.badRequest("FILE_EXTENSION_MISMATCH", "File extension does not match its content");
            }
        }
        if (kind == Kind.PDF) {
            String head = new String(content, StandardCharsets.ISO_8859_1);
            for (String marker : PDF_ACTIVE) {
                if (head.contains(marker)) {
                    throw PlatformException.badRequest("PDF_ACTIVE_CONTENT", "PDF files with scripts, actions or attachments are not allowed");
                }
            }
        }
        return kind;
    }
}
