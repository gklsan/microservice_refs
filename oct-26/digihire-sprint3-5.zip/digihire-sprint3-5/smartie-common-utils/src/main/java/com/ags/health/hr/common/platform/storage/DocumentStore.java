package com.ags.health.hr.common.platform.storage;

import java.net.URI;
import java.time.Duration;
import java.util.Map;
import java.util.Optional;

public interface DocumentStore {

    StoredDocument put(String key, byte[] content, String contentType, Map<String, String> metadata);

    Optional<byte[]> get(String key);

    Optional<URI> temporaryUrl(String key, Duration ttl, String downloadName);

    URI uploadUrl(String key, Duration ttl, String contentType);

    void delete(String key);

    boolean exists(String key);
}
