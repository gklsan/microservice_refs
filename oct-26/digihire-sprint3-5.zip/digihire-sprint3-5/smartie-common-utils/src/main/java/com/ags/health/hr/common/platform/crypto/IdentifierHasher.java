package com.ags.health.hr.common.platform.crypto;

import com.ags.health.hr.common.platform.validation.IdentityValidators;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
import java.nio.charset.StandardCharsets;
import java.security.GeneralSecurityException;
import java.util.HexFormat;

public class IdentifierHasher {

    private final byte[] pepper;

    public IdentifierHasher(String pepper) {
        if (pepper == null || pepper.length() < 16) {
            throw new IllegalStateException("Identifier pepper must be at least 16 characters");
        }
        this.pepper = pepper.getBytes(StandardCharsets.UTF_8);
    }

    public String hash(IdentityValidators.Kind kind, String value) {
        String v = IdentityValidators.normalise(kind, value);
        if (v == null || v.isEmpty()) {
            return null;
        }
        try {
            Mac mac = Mac.getInstance("HmacSHA256");
            mac.init(new SecretKeySpec(pepper, "HmacSHA256"));
            return HexFormat.of().formatHex(mac.doFinal((kind.name() + ":" + v).getBytes(StandardCharsets.UTF_8)));
        } catch (GeneralSecurityException e) {
            throw new IllegalStateException(e);
        }
    }
}
