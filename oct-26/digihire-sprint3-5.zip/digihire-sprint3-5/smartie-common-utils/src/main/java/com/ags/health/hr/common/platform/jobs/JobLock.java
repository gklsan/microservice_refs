package com.ags.health.hr.common.platform.jobs;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.dao.DataAccessException;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.jdbc.core.JdbcTemplate;

import java.lang.management.ManagementFactory;
import java.sql.Timestamp;
import java.time.Clock;
import java.time.Duration;
import java.time.Instant;
import java.util.Optional;
import java.util.UUID;
import java.util.regex.Pattern;

public class JobLock {

    public record Lease(String name, String owner, Instant acquiredAt) {
    }

    private static final Logger log = LoggerFactory.getLogger(JobLock.class);
    private static final Pattern TABLE = Pattern.compile("[A-Za-z_][A-Za-z0-9_]{0,62}");

    private final JdbcTemplate jdbc;
    private final Clock clock;
    private final String table;
    private final String instance;

    public JobLock(JdbcTemplate jdbc, Clock clock, String table) {
        if (table == null || !TABLE.matcher(table).matches()) {
            throw new IllegalArgumentException("Invalid lock table " + table);
        }
        this.jdbc = jdbc;
        this.clock = clock;
        this.table = table;
        String host;
        try {
            host = ManagementFactory.getRuntimeMXBean().getName();
        } catch (RuntimeException e) {
            host = "unknown";
        }
        this.instance = (host.length() > 80 ? host.substring(0, 80) : host) + "/" + UUID.randomUUID().toString().substring(0, 8);
    }

    public Optional<Lease> tryAcquire(String name, Duration atMostFor) {
        Instant now = clock.instant();
        Timestamp until = Timestamp.from(now.plus(atMostFor));
        Timestamp at = Timestamp.from(now);
        String owner = instance + "/" + UUID.randomUUID().toString().substring(0, 8);
        try {
            int updated = jdbc.update("UPDATE " + table + " SET locked_until = ?, locked_at = ?, locked_by = ? "
                    + "WHERE name = ? AND locked_until <= ?", until, at, owner, name, at);
            if (updated == 1) {
                return Optional.of(new Lease(name, owner, now));
            }
            Integer existing = jdbc.queryForObject("SELECT count(*) FROM " + table + " WHERE name = ?", Integer.class, name);
            if (existing != null && existing > 0) {
                return Optional.empty();
            }
            jdbc.update("INSERT INTO " + table + " (name, locked_until, locked_at, locked_by) VALUES (?, ?, ?, ?)",
                    name, until, at, owner);
            return Optional.of(new Lease(name, owner, now));
        } catch (DuplicateKeyException e) {
            return Optional.empty();
        } catch (DataAccessException e) {
            log.warn("Job lock {} could not be taken: {}", name, e.getMessage());
            return Optional.empty();
        }
    }

    public void release(Lease lease, Duration atLeastFor) {
        Instant now = clock.instant();
        Instant earliest = lease.acquiredAt().plus(atLeastFor == null ? Duration.ZERO : atLeastFor);
        Instant until = earliest.isAfter(now) ? earliest : now;
        try {
            jdbc.update("UPDATE " + table + " SET locked_until = ? WHERE name = ? AND locked_by = ?",
                    Timestamp.from(until), lease.name(), lease.owner());
        } catch (DataAccessException e) {
            log.warn("Job lock {} could not be released; it expires on its own: {}", lease.name(), e.getMessage());
        }
    }
}
