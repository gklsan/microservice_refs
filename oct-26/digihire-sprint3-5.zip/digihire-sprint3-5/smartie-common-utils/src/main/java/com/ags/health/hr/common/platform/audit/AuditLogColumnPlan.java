package com.ags.health.hr.common.platform.audit;

import java.sql.Timestamp;
import java.sql.Types;
import java.time.Instant;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.StringJoiner;
import java.util.UUID;
import java.util.function.BiFunction;

public final class AuditLogColumnPlan {

    public enum IdMode { UUID_OBJECT, UUID_STRING, DATABASE, ABSENT }

    public static final Set<String> REQUIRED = Set.of("event_time", "event_type", "action", "status");
    public static final String FALLBACK_EVENT_TYPE = "ACTIVITY";

    private static final Map<String, BiFunction<AuditEvent, String, Object>> SOURCES = new LinkedHashMap<>();

    static {
        SOURCES.put("event_time", (e, d) -> Timestamp.from(e.occurredAt()));
        SOURCES.put("event_type", (e, d) -> e.category());
        SOURCES.put("action", (e, d) -> e.action());
        SOURCES.put("service_name", (e, d) -> e.serviceName());
        SOURCES.put("actor_id", (e, d) -> e.actorId());
        SOURCES.put("actor_role", (e, d) -> e.actorRoles());
        SOURCES.put("actor_roles", (e, d) -> e.actorRoles());
        SOURCES.put("actor_email", (e, d) -> e.actorEmail());
        SOURCES.put("actor_name", (e, d) -> e.actorName());
        SOURCES.put("target_type", (e, d) -> e.entityType());
        SOURCES.put("target_id", (e, d) -> e.entityId());
        SOURCES.put("candidate_id", (e, d) -> e.candidateId());
        SOURCES.put("http_method", (e, d) -> e.httpMethod());
        SOURCES.put("endpoint", (e, d) -> e.endpoint());
        SOURCES.put("source_ip", (e, d) -> e.clientIp());
        SOURCES.put("correlation_id", (e, d) -> e.correlationId());
        SOURCES.put("status", (e, d) -> e.succeeded() ? AuditEvent.SUCCESS : AuditEvent.FAILURE);
        SOURCES.put("outcome", (e, d) -> e.outcome() == null ? AuditEvent.SUCCESS : e.outcome());
        SOURCES.put("description", (e, d) -> e.description());
        SOURCES.put("details", (e, d) -> d);
        SOURCES.put("created_at", (e, d) -> Timestamp.from(Instant.now()));
    }

    private record Slot(ColumnInfo column, BiFunction<AuditEvent, String, Object> source, boolean json, boolean uuid) {
    }

    private final String table;
    private final IdMode idMode;
    private final ColumnInfo idColumn;
    private final List<Slot> slots;
    private final String sql;
    private final int detailsMaxLength;
    private final Set<String> allowedEventTypes;

    private AuditLogColumnPlan(String table, IdMode idMode, ColumnInfo idColumn, List<Slot> slots, String sql,
                               int detailsMaxLength, Set<String> allowedEventTypes) {
        this.table = table;
        this.idMode = idMode;
        this.idColumn = idColumn;
        this.slots = slots;
        this.sql = sql;
        this.detailsMaxLength = detailsMaxLength;
        this.allowedEventTypes = allowedEventTypes;
    }

    public static AuditLogColumnPlan from(String table, List<ColumnInfo> columns, boolean h2, int defaultDetailsLength) {
        return from(table, columns, h2, defaultDetailsLength, null);
    }

    public static AuditLogColumnPlan from(String table, List<ColumnInfo> columns, boolean h2, int defaultDetailsLength,
                                          Set<String> allowedEventTypes) {
        if (columns == null || columns.isEmpty()) {
            throw new IllegalStateException("Audit table " + table + " does not exist or has no columns");
        }
        Map<String, ColumnInfo> byName = new LinkedHashMap<>();
        for (ColumnInfo c : columns) {
            byName.putIfAbsent(c.name().toLowerCase(Locale.ROOT), c);
        }
        List<String> missing = REQUIRED.stream().filter(r -> !byName.containsKey(r)).sorted().toList();
        if (!missing.isEmpty()) {
            throw new IllegalStateException("Audit table " + table + " is missing column(s) " + missing);
        }
        for (String textual : List.of("event_type", "status")) {
            if (isNumeric(byName.get(textual).jdbcType())) {
                throw new IllegalStateException("Audit table " + table + "." + textual
                        + " is numeric (enum stored as ORDINAL); it must be stored as text");
            }
        }
        ColumnInfo id = byName.get("id");
        IdMode mode = idMode(table, id);
        List<Slot> slots = new ArrayList<>();
        List<String> unfillable = new ArrayList<>();
        for (Map.Entry<String, ColumnInfo> e : byName.entrySet()) {
            String name = e.getKey();
            ColumnInfo c = e.getValue();
            if ("id".equals(name)) {
                continue;
            }
            BiFunction<AuditEvent, String, Object> source = SOURCES.get(name);
            if (source == null) {
                if (!c.nullable() && !c.hasDefault() && !c.autoIncrement()) {
                    unfillable.add(name);
                }
                continue;
            }
            slots.add(new Slot(c, source, isJsonType(c.typeName()), isUuidType(c.typeName())));
        }
        if (!unfillable.isEmpty()) {
            throw new IllegalStateException("Audit table " + table + " has NOT NULL column(s) this service can not fill: "
                    + unfillable);
        }
        StringJoiner names = new StringJoiner(", ");
        StringJoiner params = new StringJoiner(", ");
        if (mode == IdMode.UUID_OBJECT || mode == IdMode.UUID_STRING) {
            names.add(id.name());
            params.add("?");
        }
        for (Slot s : slots) {
            names.add(s.column().name());
            params.add(s.json() ? (h2 ? "? FORMAT JSON" : "CAST(? AS JSON)") : "?");
        }
        ColumnInfo details = byName.get("details");
        int detailsMax = details == null ? 0 : textLimit(details, defaultDetailsLength);
        String sql = "INSERT INTO " + table + " (" + names + ") VALUES (" + params + ")";
        Set<String> allowed = allowedEventTypes == null || allowedEventTypes.isEmpty() ? null : Set.copyOf(allowedEventTypes);
        if (allowed != null && !allowed.contains(FALLBACK_EVENT_TYPE)) {
            throw new IllegalStateException("Audit table " + table + ".event_type only allows " + allowed
                    + " and not " + FALLBACK_EVENT_TYPE);
        }
        return new AuditLogColumnPlan(table, mode, id, List.copyOf(slots), sql, detailsMax, allowed);
    }

    public String storedEventType(String category) {
        if (allowedEventTypes == null || category == null || allowedEventTypes.contains(category)) {
            return category;
        }
        return FALLBACK_EVENT_TYPE;
    }

    public Set<String> allowedEventTypes() {
        return allowedEventTypes;
    }

    public String sql() {
        return sql;
    }

    public String table() {
        return table;
    }

    public IdMode idMode() {
        return idMode;
    }

    public int detailsMaxLength() {
        return detailsMaxLength;
    }

    public List<String> columns() {
        List<String> out = new ArrayList<>();
        if (idMode == IdMode.UUID_OBJECT || idMode == IdMode.UUID_STRING) {
            out.add(idColumn.name().toLowerCase(Locale.ROOT));
        }
        slots.forEach(s -> out.add(s.column().name().toLowerCase(Locale.ROOT)));
        return out;
    }

    public Object[] values(AuditEvent event, String detailsJson) {
        List<Object> out = new ArrayList<>();
        if (idMode == IdMode.UUID_OBJECT) {
            out.add(UUID.randomUUID());
        } else if (idMode == IdMode.UUID_STRING) {
            out.add(UUID.randomUUID().toString());
        }
        for (Slot s : slots) {
            Object v = s.source().apply(event, detailsJson);
            if ("event_type".equalsIgnoreCase(s.column().name())) {
                v = storedEventType(event.category());
            }
            if (v instanceof String text && s.uuid()) {
                v = toUuid(text);
            } else if (v instanceof String text && !s.json()) {
                v = AuditJson.cut(text, textLimit(s.column(), 0));
            }
            out.add(v);
        }
        return out.toArray();
    }

    private static IdMode idMode(String table, ColumnInfo id) {
        if (id == null) {
            return IdMode.ABSENT;
        }
        if (id.autoIncrement() || id.hasDefault()) {
            return IdMode.DATABASE;
        }
        String type = id.typeName() == null ? "" : id.typeName().toLowerCase(Locale.ROOT);
        if (type.contains("uuid") || id.jdbcType() == Types.OTHER || id.jdbcType() == Types.BINARY) {
            return IdMode.UUID_OBJECT;
        }
        if (isText(id.jdbcType())) {
            if (id.size() > 0 && id.size() < 36) {
                throw new IllegalStateException("Audit table " + table + ".id is text shorter than a UUID");
            }
            return IdMode.UUID_STRING;
        }
        throw new IllegalStateException("Audit table " + table + ".id (" + id.typeName()
                + ") has no database default and is not a UUID column");
    }

    private static int textLimit(ColumnInfo c, int fallback) {
        if (!isText(c.jdbcType()) || isJsonType(c.typeName()) || isUuidType(c.typeName())) {
            return fallback;
        }
        int size = c.size();
        return size <= 0 || size >= 1_000_000 ? fallback : size;
    }

    private static Object toUuid(String text) {
        try {
            return UUID.fromString(text.trim());
        } catch (IllegalArgumentException e) {
            return null;
        }
    }

    private static boolean isUuidType(String typeName) {
        return typeName != null && typeName.toLowerCase(Locale.ROOT).contains("uuid");
    }

    private static boolean isJsonType(String typeName) {
        if (typeName == null) {
            return false;
        }
        String t = typeName.toLowerCase(Locale.ROOT);
        return t.equals("json") || t.equals("jsonb");
    }

    private static boolean isText(int jdbcType) {
        return jdbcType == Types.VARCHAR || jdbcType == Types.CHAR || jdbcType == Types.LONGVARCHAR
                || jdbcType == Types.NVARCHAR || jdbcType == Types.NCHAR || jdbcType == Types.LONGNVARCHAR
                || jdbcType == Types.CLOB || jdbcType == Types.NCLOB;
    }

    private static boolean isNumeric(int jdbcType) {
        return jdbcType == Types.INTEGER || jdbcType == Types.SMALLINT || jdbcType == Types.TINYINT
                || jdbcType == Types.BIGINT || jdbcType == Types.NUMERIC || jdbcType == Types.DECIMAL;
    }
}
