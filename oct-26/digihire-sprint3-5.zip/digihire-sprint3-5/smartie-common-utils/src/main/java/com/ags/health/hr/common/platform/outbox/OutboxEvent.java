package com.ags.health.hr.common.platform.outbox;

import com.fasterxml.jackson.databind.JsonNode;

import java.time.Instant;
import java.util.UUID;

public record OutboxEvent(long seq, UUID id, String eventType, String aggregateType, String aggregateId,
                          String candidateId, String applicationId, JsonNode payload, Instant createdAt,
                          String correlationId, int attempts) {
}
