package com.ags.health.hr.common.platform.validation;

public final class Masking {

    private Masking() {
    }

    public static String lastFour(String value) {
        if (value == null || value.isBlank()) {
            return value;
        }
        String v = value.replaceAll("\\s", "");
        if (v.length() <= 4) {
            return "*".repeat(v.length());
        }
        return "*".repeat(v.length() - 4) + v.substring(v.length() - 4);
    }

    public static String email(String email) {
        if (email == null || !email.contains("@")) {
            return email;
        }
        int at = email.indexOf('@');
        String local = email.substring(0, at);
        String keep = local.length() <= 2 ? local.substring(0, 1) : local.substring(0, 2);
        return keep + "*".repeat(Math.max(1, local.length() - keep.length())) + email.substring(at);
    }
}
