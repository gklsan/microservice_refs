package com.ags.health.hr.common.platform.error;

import java.util.List;
import java.util.Map;

public class PlatformException extends RuntimeException {

    private final int status;
    private final String code;
    private final List<Map<String, Object>> details;

    public PlatformException(int status, String code, String message, List<Map<String, Object>> details) {
        super(message);
        this.status = status;
        this.code = code;
        this.details = details == null ? List.of() : List.copyOf(details);
    }

    public int getStatus() {
        return status;
    }

    public String getCode() {
        return code;
    }

    public List<Map<String, Object>> getDetails() {
        return details;
    }

    public static PlatformException badRequest(String code, String message) {
        return new PlatformException(400, code, message, null);
    }

    public static PlatformException unauthorized(String message) {
        return new PlatformException(401, "UNAUTHORIZED", message, null);
    }

    public static PlatformException forbidden(String code, String message) {
        return new PlatformException(403, code, message, null);
    }

    public static PlatformException notFound(String what, Object id) {
        return new PlatformException(404, "NOT_FOUND", what + " not found: " + id, null);
    }

    public static PlatformException conflict(String code, String message) {
        return new PlatformException(409, code, message, null);
    }

    public static PlatformException unprocessable(String code, String message, List<Map<String, Object>> details) {
        return new PlatformException(422, code, message, details);
    }

    public static PlatformException unavailable(String code, String message) {
        return new PlatformException(503, code, message, null);
    }
}
