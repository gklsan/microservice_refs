package com.ags.health.hr.common.platform.audit;

import java.time.Instant;
import java.util.Map;

public record AuditEvent(String category, String action, String entityType, String entityId, String candidateId,
                         String outcome, String description, Map<String, Object> details, String actorId, String actorName,
                         String actorEmail, String actorRoles, String correlationId, String serviceName, String clientIp,
                         String httpMethod, String endpoint, Instant occurredAt) {

    public static final String SUCCESS = "SUCCESS";
    public static final String FAILURE = "FAILURE";

    public boolean succeeded() {
        return outcome == null || SUCCESS.equalsIgnoreCase(outcome);
    }
}
