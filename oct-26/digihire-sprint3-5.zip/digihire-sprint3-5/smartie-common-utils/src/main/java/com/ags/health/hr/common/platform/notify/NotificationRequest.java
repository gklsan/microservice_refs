package com.ags.health.hr.common.platform.notify;

import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;

public record NotificationRequest(String eventType, String applicationId, String candidateId, String idempotencyKey,
                                  Map<String, Object> context) {

    public NotificationRequest {
        context = context == null ? Map.of() : Collections.unmodifiableMap(new LinkedHashMap<>(context));
    }
}
