package com.ags.health.hr.common.platform.page;

import java.util.List;

public record PageResult<T>(List<T> items, int page, int size, long total) {

    public PageResult {
        items = items == null ? List.of() : List.copyOf(items);
    }

    public static int safeSize(int size, int max) {
        return Math.max(1, Math.min(size <= 0 ? 20 : size, max));
    }

    public static int safePage(int page) {
        return Math.max(0, page);
    }
}
