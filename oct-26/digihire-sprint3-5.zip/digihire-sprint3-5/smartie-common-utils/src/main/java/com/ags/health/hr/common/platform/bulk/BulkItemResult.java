package com.ags.health.hr.common.platform.bulk;

public record BulkItemResult(int rowNo, String reference, boolean ok, String code, String message, String fromStatus,
                             String toStatus) {

    public static BulkItemResult ok(int rowNo, String reference, String from, String to) {
        return new BulkItemResult(rowNo, reference, true, "OK", null, from, to);
    }

    public static BulkItemResult failed(int rowNo, String reference, String code, String message) {
        return new BulkItemResult(rowNo, reference, false, code, message, null, null);
    }
}
