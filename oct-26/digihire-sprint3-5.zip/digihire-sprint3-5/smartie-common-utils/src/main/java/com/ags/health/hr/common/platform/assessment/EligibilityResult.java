package com.ags.health.hr.common.platform.assessment;

import java.time.Instant;
import java.util.List;

public record EligibilityResult(boolean eligible, List<Reason> reasons) {

    public record Reason(String code, String message, Instant until, boolean blocking) {
    }

    public EligibilityResult {
        reasons = reasons == null ? List.of() : List.copyOf(reasons);
    }

    public static EligibilityResult ok() {
        return new EligibilityResult(true, List.of());
    }

    public boolean has(String code) {
        return reasons.stream().anyMatch(r -> r.code().equals(code));
    }
}
