package com.ags.health.hr.common.platform.audit;

import org.springframework.jdbc.core.ConnectionCallback;
import org.springframework.jdbc.core.JdbcTemplate;

import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Optional;
import java.util.Set;
import java.util.TreeSet;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public final class AuditTableInspector {

    private static final Pattern LITERAL = Pattern.compile("'([A-Za-z0-9_]+)'");

    private AuditTableInspector() {
    }

    public static boolean isH2(JdbcTemplate jdbc) {
        String product = jdbc.execute((ConnectionCallback<String>) c -> c.getMetaData().getDatabaseProductName());
        return product != null && product.toLowerCase(Locale.ROOT).contains("h2");
    }

    public static List<ColumnInfo> columns(JdbcTemplate jdbc, String table) {
        return jdbc.execute((ConnectionCallback<List<ColumnInfo>>) c -> read(c, table));
    }

    public static Optional<Set<String>> allowedValues(JdbcTemplate jdbc, String table, String column) {
        String bare = table.contains(".") ? table.substring(table.indexOf('.') + 1) : table;
        try {
            List<String> clauses = jdbc.queryForList("SELECT cc.check_clause FROM information_schema.constraint_column_usage u "
                    + "JOIN information_schema.check_constraints cc ON cc.constraint_name = u.constraint_name "
                    + "AND cc.constraint_schema = u.constraint_schema "
                    + "WHERE lower(u.table_name) = lower(?) AND lower(u.column_name) = lower(?) "
                    + "AND lower(u.table_schema) = lower(current_schema)", String.class, bare, column);
            for (String clause : clauses) {
                Set<String> values = new TreeSet<>();
                Matcher m = LITERAL.matcher(clause == null ? "" : clause);
                while (m.find()) {
                    values.add(m.group(1));
                }
                if (!values.isEmpty()) {
                    return Optional.of(values);
                }
            }
        } catch (RuntimeException e) {
            return Optional.empty();
        }
        return Optional.empty();
    }

    private static List<ColumnInfo> read(Connection c, String table) throws SQLException {
        DatabaseMetaData meta = c.getMetaData();
        String schema = null;
        String bare = table;
        String[] schemas;
        int dot = table.indexOf('.');
        if (dot > 0) {
            String explicit = table.substring(0, dot);
            bare = table.substring(dot + 1);
            schemas = new String[]{explicit, explicit.toLowerCase(Locale.ROOT), explicit.toUpperCase(Locale.ROOT)};
        } else {
            try {
                schema = c.getSchema();
            } catch (SQLException | AbstractMethodError e) {
                schema = null;
            }
            schemas = schema == null ? new String[]{null} : new String[]{schema, null};
        }
        Set<String> names = new LinkedHashSet<>(List.of(bare, bare.toLowerCase(Locale.ROOT), bare.toUpperCase(Locale.ROOT)));
        for (String schemaCandidate : schemas) {
            for (String name : names) {
                List<ColumnInfo> found = new ArrayList<>();
                try (ResultSet rs = meta.getColumns(c.getCatalog(), schemaCandidate, name, null)) {
                    String firstSchema = null;
                    while (rs.next()) {
                        String colSchema = rs.getString("TABLE_SCHEM");
                        if (firstSchema == null) {
                            firstSchema = colSchema;
                        } else if (colSchema != null && !colSchema.equals(firstSchema)) {
                            continue;
                        }
                        found.add(new ColumnInfo(rs.getString("COLUMN_NAME"), rs.getInt("DATA_TYPE"), rs.getString("TYPE_NAME"),
                                rs.getInt("COLUMN_SIZE"), rs.getInt("NULLABLE") != DatabaseMetaData.columnNoNulls,
                                "YES".equalsIgnoreCase(rs.getString("IS_AUTOINCREMENT")),
                                rs.getString("COLUMN_DEF") != null));
                    }
                }
                if (!found.isEmpty()) {
                    return found;
                }
            }
        }
        return List.of();
    }
}
