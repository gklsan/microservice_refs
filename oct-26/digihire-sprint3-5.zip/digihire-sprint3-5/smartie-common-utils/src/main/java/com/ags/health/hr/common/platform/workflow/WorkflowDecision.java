package com.ags.health.hr.common.platform.workflow;

import java.util.List;

public record WorkflowDecision(boolean allowed, String code, String message, String fromState, String toState,
                               List<String> allowedTargets) {

    public WorkflowDecision {
        allowedTargets = allowedTargets == null ? List.of() : List.copyOf(allowedTargets);
    }

    public static WorkflowDecision allow(String from, String to) {
        return new WorkflowDecision(true, "ALLOWED", null, from, to, List.of());
    }

    public static WorkflowDecision deny(String code, String message, String from, String to, List<String> targets) {
        return new WorkflowDecision(false, code, message, from, to, targets);
    }
}
