package com.ags.health.hr.common.platform.caller;

import com.ags.health.hr.common.platform.error.PlatformException;
import com.ags.health.hr.common.platform.http.InternalHttp;
import com.fasterxml.jackson.databind.JsonNode;
import io.jsonwebtoken.Claims;
import io.jsonwebtoken.JwtException;
import io.jsonwebtoken.JwtParser;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.io.Decoders;
import io.jsonwebtoken.security.Keys;
import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import java.time.Clock;
import java.time.Duration;
import java.time.Instant;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

public class JwtCallerProvider implements CallerProvider {

    public static final String REQUEST_ATTRIBUTE = JwtCallerProvider.class.getName() + ".caller";

    private record Cached(Caller caller, Instant expiresAt) {
    }

    private final JwtParser parser;
    private final InternalHttp http;
    private final String adminBase;
    private final Duration ttl;
    private final Clock clock;
    private final Map<String, Cached> cache = new ConcurrentHashMap<>();

    public JwtCallerProvider(String base64Secret, InternalHttp http, String adminBaseUrl, Duration ttl, Clock clock) {
        if (base64Secret == null || base64Secret.isBlank()) {
            throw new IllegalStateException("JWT_SECRET must be set");
        }
        byte[] key = Decoders.BASE64.decode(base64Secret.trim());
        if (key.length < 32) {
            throw new IllegalStateException("JWT_SECRET must decode to at least 256 bits");
        }
        this.parser = Jwts.parserBuilder().setSigningKey(Keys.hmacShaKeyFor(key)).build();
        this.http = http;
        this.adminBase = InternalHttp.trimBase(adminBaseUrl);
        this.ttl = ttl;
        this.clock = clock;
    }

    @Override
    public Optional<Caller> current() {
        if (!(RequestContextHolder.getRequestAttributes() instanceof ServletRequestAttributes attrs)) {
            return Optional.empty();
        }
        HttpServletRequest request = attrs.getRequest();
        Object cached = request.getAttribute(REQUEST_ATTRIBUTE);
        if (cached instanceof Caller c) {
            return Optional.of(c);
        }
        String token = token(request);
        if (token == null) {
            return Optional.empty();
        }
        Claims claims;
        try {
            claims = parser.parseClaimsJws(token).getBody();
        } catch (JwtException | IllegalArgumentException e) {
            throw PlatformException.unauthorized("Session expired or token invalid");
        }
        String userId = claims.get("userId") == null ? null : String.valueOf(claims.get("userId"));
        String email = claims.get("email") != null ? String.valueOf(claims.get("email")) : claims.getSubject();
        String userType = claims.get("userType") == null ? null : String.valueOf(claims.get("userType"));
        String name = claims.get("userName") == null ? null : String.valueOf(claims.get("userName"));
        Caller caller = resolve(userId, email, userType, name);
        request.setAttribute(REQUEST_ATTRIBUTE, caller);
        return Optional.of(caller);
    }

    public void evict() {
        cache.clear();
    }

    private Caller resolve(String userId, String email, String userType, String name) {
        String key = userId + "|" + email + "|" + userType;
        Instant now = clock.instant();
        Cached c = cache.get(key);
        if (c != null && c.expiresAt().isAfter(now)) {
            return c.caller();
        }
        Map<String, Object> q = new LinkedHashMap<>();
        q.put("userId", userId);
        q.put("email", email);
        q.put("userType", userType);
        JsonNode node;
        try {
            node = http.get(InternalHttp.query(adminBase + "/internal/rbac/effective", q));
        } catch (InternalHttp.Failure f) {
            throw PlatformException.unavailable("ACCESS_SERVICE_UNAVAILABLE", "Access rules can not be loaded right now");
        }
        boolean active = node.path("active").asBoolean(false);
        JsonNode scope = node.path("scope");
        Caller caller = new Caller(userId != null ? userId : node.path("userId").asText(null), email, name,
                active ? set(node.path("roles")) : Set.of(), active ? set(node.path("permissions")) : Set.of(),
                set(node.path("conditionalPermissions")), active ? scope.path("level").asText("NONE") : "NONE",
                set(scope.path("teamUserIds")), set(scope.path("lobs")), set(scope.path("locations")), false);
        if (cache.size() > 10_000) {
            cache.clear();
        }
        cache.put(key, new Cached(caller, now.plus(ttl)));
        return caller;
    }

    private static String token(HttpServletRequest request) {
        String header = request.getHeader("Authorization");
        if (header != null && !header.isBlank()) {
            return header.startsWith("Bearer ") ? header.substring(7).trim() : header.trim();
        }
        Cookie[] cookies = request.getCookies();
        if (cookies != null) {
            for (Cookie cookie : cookies) {
                if ("token".equals(cookie.getName()) && cookie.getValue() != null && !cookie.getValue().isBlank()) {
                    return cookie.getValue();
                }
            }
        }
        return null;
    }

    private static Set<String> set(JsonNode array) {
        Set<String> out = new HashSet<>();
        if (array != null && array.isArray()) {
            array.forEach(v -> out.add(v.asText()));
        }
        return out;
    }
}
