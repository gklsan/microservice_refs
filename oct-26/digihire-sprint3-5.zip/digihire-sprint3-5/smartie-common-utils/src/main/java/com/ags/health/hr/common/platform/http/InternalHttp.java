package com.ags.health.hr.common.platform.http;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.slf4j.MDC;

import java.io.IOException;
import java.net.URI;
import java.net.URLEncoder;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.StringJoiner;
import java.util.regex.Pattern;

public class InternalHttp {

    public static class Failure extends RuntimeException {

        private final int status;
        private final String body;

        public Failure(int status, String body, String message, Throwable cause) {
            super(message, cause);
            this.status = status;
            this.body = body;
        }

        public int status() {
            return status;
        }

        public String body() {
            return body;
        }

        public boolean isOutage() {
            return status == 0 || status >= 500 || status == 429;
        }
    }

    private static final Pattern CORRELATION = Pattern.compile("[A-Za-z0-9_-]{1,64}");

    private final HttpClient client;
    private final ObjectMapper mapper;
    private final Duration timeout;
    private final Map<String, String> defaultHeaders;

    public InternalHttp(ObjectMapper mapper, Duration timeout, Map<String, String> defaultHeaders) {
        this(HttpClient.newBuilder().connectTimeout(timeout).followRedirects(HttpClient.Redirect.NEVER).build(), mapper,
                timeout, defaultHeaders);
    }

    public InternalHttp(HttpClient client, ObjectMapper mapper, Duration timeout, Map<String, String> defaultHeaders) {
        this.client = client;
        this.mapper = mapper;
        this.timeout = timeout;
        Map<String, String> h = new LinkedHashMap<>();
        if (defaultHeaders != null) {
            defaultHeaders.forEach((k, v) -> {
                if (k != null && v != null && !v.isBlank()) {
                    h.put(k, v);
                }
            });
        }
        this.defaultHeaders = Map.copyOf(h);
    }

    public ObjectMapper mapper() {
        return mapper;
    }

    public JsonNode get(String url) {
        return send("GET", url, null);
    }

    public JsonNode post(String url, Object body) {
        return send("POST", url, body);
    }

    public JsonNode put(String url, Object body) {
        return send("PUT", url, body);
    }

    public <T> T read(JsonNode node, Class<T> type) {
        try {
            return mapper.treeToValue(node, type);
        } catch (IOException | IllegalArgumentException e) {
            throw new Failure(200, null, "Unreadable response for " + type.getSimpleName(), e);
        }
    }

    public JsonNode send(String method, String url, Object body) {
        String payload;
        try {
            payload = body == null ? null : body instanceof String s ? s : mapper.writeValueAsString(body);
        } catch (IOException e) {
            throw new Failure(0, null, "Request body is not serialisable", e);
        }
        HttpRequest.Builder b = HttpRequest.newBuilder(URI.create(url)).timeout(timeout).header("Accept", "application/json");
        defaultHeaders.forEach(b::header);
        String correlation = MDC.get("req-id") != null ? MDC.get("req-id") : MDC.get("correlationId");
        if (correlation != null && CORRELATION.matcher(correlation).matches()) {
            b.header("X-Correlation-Id", correlation);
        }
        if (payload != null) {
            b.header("Content-Type", "application/json");
            b.method(method, HttpRequest.BodyPublishers.ofString(payload, StandardCharsets.UTF_8));
        } else {
            b.method(method, HttpRequest.BodyPublishers.noBody());
        }
        HttpResponse<String> res;
        try {
            res = client.send(b.build(), HttpResponse.BodyHandlers.ofString(StandardCharsets.UTF_8));
        } catch (IOException e) {
            throw new Failure(0, null, method + " " + path(url) + " failed: " + e.getClass().getSimpleName(), e);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            throw new Failure(0, null, method + " " + path(url) + " interrupted", e);
        }
        if (res.statusCode() < 200 || res.statusCode() >= 300) {
            throw new Failure(res.statusCode(), res.body(), method + " " + path(url) + " returned " + res.statusCode(), null);
        }
        String text = res.body();
        if (text == null || text.isBlank()) {
            return mapper.createObjectNode();
        }
        try {
            return mapper.readTree(text);
        } catch (IOException e) {
            throw new Failure(res.statusCode(), text, method + " " + path(url) + " returned non-JSON", e);
        }
    }

    public static String query(String base, Map<String, ?> params) {
        StringJoiner q = new StringJoiner("&");
        if (params != null) {
            params.forEach((k, v) -> {
                if (v != null && !String.valueOf(v).isBlank()) {
                    q.add(encode(k) + "=" + encode(String.valueOf(v)));
                }
            });
        }
        return q.length() == 0 ? base : base + (base.contains("?") ? "&" : "?") + q;
    }

    public static String encode(String v) {
        return URLEncoder.encode(v, StandardCharsets.UTF_8);
    }

    public static String trimBase(String url) {
        String u = url == null ? "" : url.trim();
        return u.endsWith("/") ? u.substring(0, u.length() - 1) : u;
    }

    private static String path(String url) {
        int q = url.indexOf('?');
        return q < 0 ? url : url.substring(0, q);
    }
}
