package com.ags.health.hr.common.platform.storage;

import javax.crypto.SecretKey;
import javax.crypto.spec.SecretKeySpec;
import java.util.Base64;
import java.util.LinkedHashMap;
import java.util.Map;

public class StaticKeyEncryptionKeyProvider implements KeyEncryptionKeyProvider {

    private final Map<String, SecretKey> keys;
    private final String active;

    public StaticKeyEncryptionKeyProvider(String spec, String activeKeyId) {
        Map<String, SecretKey> parsed = new LinkedHashMap<>();
        if (spec != null) {
            for (String part : spec.split(",")) {
                String p = part.trim();
                if (p.isEmpty()) {
                    continue;
                }
                int colon = p.indexOf(':');
                if (colon <= 0) {
                    throw new IllegalStateException("Key spec must be id:base64");
                }
                byte[] raw = Base64.getDecoder().decode(p.substring(colon + 1).trim());
                if (raw.length != 32) {
                    throw new IllegalStateException("Key " + p.substring(0, colon) + " must be 32 bytes");
                }
                parsed.put(p.substring(0, colon).trim(), new SecretKeySpec(raw, "AES"));
            }
        }
        if (parsed.isEmpty()) {
            throw new IllegalStateException("No key-encryption keys configured");
        }
        String a = activeKeyId == null || activeKeyId.isBlank() ? parsed.keySet().iterator().next() : activeKeyId.trim();
        if (!parsed.containsKey(a)) {
            throw new IllegalStateException("Active key id " + a + " is not configured");
        }
        this.keys = Map.copyOf(parsed);
        this.active = a;
    }

    @Override
    public String activeKeyId() {
        return active;
    }

    @Override
    public SecretKey key(String keyId) {
        SecretKey k = keys.get(keyId);
        if (k == null) {
            throw new IllegalStateException("Unknown key id " + keyId);
        }
        return k;
    }
}
