package com.ags.health.hr.common.platform.approval;

public interface ApprovalPort {

    ApprovalChain resolve(String flowCode, String requesterId, String requesterEmail, String lob, String location);

    boolean canApprove(String flowCode, int level, String approverId, String approverEmail, String requesterId,
                       String requesterEmail, String lob, String location);
}
