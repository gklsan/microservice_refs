package com.ags.health.hr.common.platform.caller;

import com.ags.health.hr.common.platform.error.PlatformException;
import jakarta.servlet.http.HttpServletRequest;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Optional;

public class InternalKeyVerifier {

    public static final String HEADER = "X-Internal-Key";
    public static final String CALLER_HEADER = "X-Caller-Service";

    private final byte[] sharedKey;
    private final Map<String, byte[]> serviceKeys;

    public InternalKeyVerifier(String sharedKey, String serviceKeysSpec) {
        this.sharedKey = sharedKey == null || sharedKey.isBlank() ? null : sharedKey.getBytes(StandardCharsets.UTF_8);
        Map<String, byte[]> keys = new LinkedHashMap<>();
        if (serviceKeysSpec != null) {
            for (String part : serviceKeysSpec.split(",")) {
                int eq = part.indexOf('=');
                if (eq > 0 && eq < part.length() - 1) {
                    keys.put(part.substring(0, eq).trim(), part.substring(eq + 1).trim().getBytes(StandardCharsets.UTF_8));
                }
            }
        }
        this.serviceKeys = Map.copyOf(keys);
        if (this.sharedKey == null && this.serviceKeys.isEmpty()) {
            throw new IllegalStateException("No internal API key configured");
        }
    }

    public Optional<String> verify(String presentedKey, String declaredCaller) {
        if (presentedKey == null || presentedKey.isBlank()) {
            return Optional.empty();
        }
        byte[] presented = presentedKey.getBytes(StandardCharsets.UTF_8);
        for (Map.Entry<String, byte[]> e : serviceKeys.entrySet()) {
            if (MessageDigest.isEqual(presented, e.getValue())) {
                return Optional.of(e.getKey());
            }
        }
        if (sharedKey != null && MessageDigest.isEqual(presented, sharedKey)) {
            return Optional.of(declaredCaller == null || declaredCaller.isBlank() ? "internal" : declaredCaller.trim());
        }
        return Optional.empty();
    }

    public String require(HttpServletRequest request) {
        return verify(request.getHeader(HEADER), request.getHeader(CALLER_HEADER))
                .orElseThrow(() -> PlatformException.forbidden("INTERNAL_KEY_REQUIRED", "A valid internal service key is required"));
    }
}
