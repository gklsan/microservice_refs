package com.ags.health.hr.common.platform.storage;

import java.net.URI;
import java.time.Duration;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;

public class InMemoryDocumentStore implements DocumentStore {

    private final Map<String, byte[]> objects = new ConcurrentHashMap<>();
    private final Map<String, String> types = new ConcurrentHashMap<>();

    @Override
    public StoredDocument put(String key, byte[] content, String contentType, Map<String, String> metadata) {
        objects.put(key, content.clone());
        if (contentType != null) {
            types.put(key, contentType);
        }
        return new StoredDocument(key, contentType, content.length, Digests.sha256(content), false);
    }

    @Override
    public Optional<byte[]> get(String key) {
        byte[] v = objects.get(key);
        return v == null ? Optional.empty() : Optional.of(v.clone());
    }

    @Override
    public Optional<URI> temporaryUrl(String key, Duration ttl, String downloadName) {
        return objects.containsKey(key) ? Optional.of(URI.create("memory://" + key)) : Optional.empty();
    }

    @Override
    public URI uploadUrl(String key, Duration ttl, String contentType) {
        return URI.create("memory://upload/" + key);
    }

    @Override
    public void delete(String key) {
        objects.remove(key);
        types.remove(key);
    }

    @Override
    public boolean exists(String key) {
        return objects.containsKey(key);
    }
}
