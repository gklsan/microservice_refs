package com.ags.health.hr.common.platform.workflow;

import java.util.Map;

public interface WorkflowPort {

    WorkflowDecision check(String entityType, String entityId, String fromState, String toState, Map<String, Object> context);

    void moved(String entityType, String entityId, String fromState, String toState, Map<String, Object> context);
}
