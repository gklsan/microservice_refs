package com.ags.health.hr.common.platform.audit;

import com.ags.health.hr.common.platform.caller.Caller;
import com.ags.health.hr.common.platform.caller.CallerProvider;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;

import java.time.Clock;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeSet;

public class AuditRecorder {

    public static final String SUCCESS = AuditEvent.SUCCESS;
    public static final String FAILURE = AuditEvent.FAILURE;
    public static final String DENIED = "DENIED";

    private static final Logger fallback = LoggerFactory.getLogger("AUDIT_FALLBACK");

    private final List<AuditSink> sinks;
    private final CallerProvider callers;
    private final String serviceName;
    private final Clock clock;

    public AuditRecorder(List<AuditSink> sinks, CallerProvider callers, String serviceName, Clock clock) {
        this.sinks = List.copyOf(sinks);
        this.callers = callers;
        this.serviceName = serviceName;
        this.clock = clock;
    }

    public void record(String category, String action, String entityType, Object entityId, String candidateId,
                       Map<String, ?> details) {
        record(category, action, entityType, entityId, candidateId, SUCCESS, null, details);
    }

    public void record(String category, String action, String entityType, Object entityId, String candidateId,
                       String outcome, String description, Map<String, ?> details) {
        AuditEvent event = event(category, action, entityType, entityId, candidateId, outcome, description, details);
        for (AuditSink sink : sinks) {
            sink.write(event);
        }
    }

    public void recordQuietly(String category, String action, String entityType, Object entityId, String candidateId,
                              String outcome, String description, Map<String, ?> details) {
        AuditEvent event = event(category, action, entityType, entityId, candidateId, outcome, description, details);
        try {
            for (AuditSink sink : sinks) {
                sink.write(event);
            }
        } catch (RuntimeException e) {
            fallback.error("AUDIT_WRITE_FAILED cause={} event={}", e.getMessage(), event);
        }
    }

    public AuditEvent event(String category, String action, String entityType, Object entityId, String candidateId,
                            String outcome, String description, Map<String, ?> details) {
        Caller c = callers == null ? null : callers.current().orElse(null);
        Map<String, Object> copy = details == null ? null : new LinkedHashMap<>(details);
        String correlation = MDC.get("req-id") != null ? MDC.get("req-id") : MDC.get("correlationId");
        return new AuditEvent(category, action, entityType, entityId == null ? null : String.valueOf(entityId), candidateId,
                outcome == null ? SUCCESS : outcome, description, copy, c == null ? "system" : c.userId(),
                c == null ? null : c.displayName(), c == null || c.system() ? null : c.email(),
                c == null || c.roles().isEmpty() ? null : String.join(",", new TreeSet<>(c.roles())), correlation,
                serviceName, null, null, null, clock.instant());
    }

    public static Map<String, Object> details(Object... kv) {
        Map<String, Object> m = new LinkedHashMap<>();
        for (int i = 0; i + 1 < kv.length; i += 2) {
            m.put(String.valueOf(kv[i]), kv[i + 1]);
        }
        return m;
    }
}
