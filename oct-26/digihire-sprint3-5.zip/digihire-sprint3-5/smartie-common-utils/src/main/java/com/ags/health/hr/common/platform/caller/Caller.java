package com.ags.health.hr.common.platform.caller;

import java.util.Arrays;
import java.util.Set;

public record Caller(String userId, String email, String name, Set<String> roles, Set<String> permissions,
                     Set<String> conditionalPermissions, String scopeLevel, Set<String> teamUserIds, Set<String> lobs,
                     Set<String> locations, boolean system) {

    public static final String SCOPE_ALL = "ALL";

    public Caller {
        roles = roles == null ? Set.of() : Set.copyOf(roles);
        permissions = permissions == null ? Set.of() : Set.copyOf(permissions);
        conditionalPermissions = conditionalPermissions == null ? Set.of() : Set.copyOf(conditionalPermissions);
        teamUserIds = teamUserIds == null ? Set.of() : Set.copyOf(teamUserIds);
        lobs = lobs == null ? Set.of() : Set.copyOf(lobs);
        locations = locations == null ? Set.of() : Set.copyOf(locations);
    }

    public static Caller system(String service) {
        return new Caller("system", null, service, Set.of("SYSTEM"), Set.of(), Set.of(), SCOPE_ALL, Set.of(), Set.of(),
                Set.of(), true);
    }

    public boolean has(String permission) {
        return system || permissions.contains(permission);
    }

    public boolean hasFull(String permission) {
        return system || permissions.contains(permission) && !conditionalPermissions.contains(permission);
    }

    public boolean hasAny(String... permission) {
        return Arrays.stream(permission).anyMatch(this::has);
    }

    public boolean hasRole(String role) {
        return roles.contains(role);
    }

    public boolean is(String otherUserId) {
        return otherUserId != null && otherUserId.equals(userId);
    }

    public boolean leads(String otherUserId) {
        return otherUserId != null && teamUserIds.contains(otherUserId) && !otherUserId.equals(userId);
    }

    public boolean scopeAll() {
        return system || SCOPE_ALL.equals(scopeLevel);
    }

    public String displayName() {
        return name != null ? name : email != null ? email : userId;
    }
}
