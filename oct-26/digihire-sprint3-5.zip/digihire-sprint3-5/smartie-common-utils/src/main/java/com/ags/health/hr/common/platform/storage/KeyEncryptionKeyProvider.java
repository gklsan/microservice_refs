package com.ags.health.hr.common.platform.storage;

import javax.crypto.SecretKey;

public interface KeyEncryptionKeyProvider {

    String activeKeyId();

    SecretKey key(String keyId);
}
