package com.ags.health.hr.common.platform.outbox;

import java.time.Duration;

public final class OutboxBackoff {

    private OutboxBackoff() {
    }

    public static Duration delay(int attempt, int baseSeconds, int maxSeconds) {
        long base = Math.max(1, baseSeconds);
        long max = Math.max(base, maxSeconds);
        int exponent = Math.max(0, Math.min(attempt - 1, 30));
        long seconds = base << exponent;
        if (seconds <= 0 || seconds > max) {
            seconds = max;
        }
        return Duration.ofSeconds(seconds);
    }

    public static boolean shouldPark(int attempt, int maxAttempts) {
        return maxAttempts > 0 && attempt >= maxAttempts;
    }
}
