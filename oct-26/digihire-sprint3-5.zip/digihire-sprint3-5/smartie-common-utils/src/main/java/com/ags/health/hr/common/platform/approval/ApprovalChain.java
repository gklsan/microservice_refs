package com.ags.health.hr.common.platform.approval;

import java.util.List;

public record ApprovalChain(String flowCode, int levels, List<List<String>> approverIdsByLevel, boolean resolved) {

    public ApprovalChain {
        approverIdsByLevel = approverIdsByLevel == null ? List.of() : List.copyOf(approverIdsByLevel);
    }
}
