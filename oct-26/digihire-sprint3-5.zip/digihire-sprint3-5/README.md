# DigiHire Phase 5: Sprint 3, 4 and 5 backend

This package has the backend code for all 95 tasks in P5-S3, P5-S4 and P5-S5 of the sprint tracker. It also explains where each piece goes in `smartie-core` and the pattern every new class follows.

Contents:

1. [What is in the package](#1-what-is-in-the-package)
2. [The placement pattern](#2-the-placement-pattern)
3. [Where every folder goes](#3-where-every-folder-goes)
4. [Integration steps per service](#4-integration-steps-per-service)
5. [Adapters the team implements](#5-adapters-the-team-implements)
6. [Cross-cutting rules (how the code behaves)](#6-cross-cutting-rules)
7. [Task to code map (95 tasks)](#7-task-to-code-map)
8. [Dependencies (DEP-S3/S4/S5) to adapter or config](#8-dependencies-to-adapter-or-config)
9. [Data model](#9-data-model)
10. [Statuses, tabs and transitions](#10-statuses-tabs-and-transitions)
11. [Permissions and approval flows](#11-permissions-and-approval-flows)
12. [Endpoints](#12-endpoints)
13. [Assumptions waiting for sign-off](#13-assumptions-waiting-for-sign-off)
14. [Verification](#14-verification)
15. [Checklist for adding more code in this pattern](#15-checklist-for-adding-more-code-in-this-pattern)

---

## 1. What is in the package

| Folder | Kind | What it holds |
| :--- | :--- | :--- |
| `smartie-common-utils` | Addition to the shared library | `com.ags.health.hr.common.platform`: caller and RBAC, internal keys, audit writer, outbox, job lock, storage and encryption, validation, business time, HTTP clients for admin / workflow / assessment |
| `candidate-services` | Drop-in packages | Profile, Map Candidate, Applicant actions, scheduling, Versant / assessment bridge, ID proof, photo verification, pipeline and bulk, offer bridge, HR round, panel, vendor bridge |
| `job-services` | Drop-in packages | Recruiter job listing, Career Page / Buddy Finder publishing, JD edit with TA Head approval, Oracle requisition and LOB sync |
| `vendor-services` | Drop-in packages | Vendor onboarding, documents, approvals, task allocation and limits, candidate linkage, performance dashboard, auto-archive |
| `integration-services` | New service | Oracle offer push / status sync / reconciliation, identity verification, face match, call log, retry |
| `admin-services` | SQL patch | `data-admin-sprint3-5.sql`: 18 new permissions, role defaults, changeset `rbac-seed-v4`, approval flows `JD_EDIT` and `VENDOR_ONBOARDING` |
| `assessment-services` | SQL patch | `data-assessment-sprint3.sql`: Versant trigger when an applicant enters `VERSANT_YET_TO_START` |
| `config` | Snippets | `application.yml` blocks per service, Maven dependencies |

Size: 266 main classes (16,300 lines) and 25 test classes (2,650 lines, 91 tests).

Three decisions shape everything below:

* **Drop-in modules plus one new service.** New code lives in its own packages inside the existing services. It never edits a legacy class. It reaches legacy data only through small interfaces (ports) that the team implements once (section 5).
* **Backend only.** No Angular code. Every screen in the tracker has an endpoint (section 12).
* **Rules real, vendors pluggable.** Business rules, validation, workflow, audit and retry are fully coded and tested. Every external system (Oracle, IDV provider, face match, Teams, Career Page, Buddy Finder, email) sits behind an interface with a REST implementation and a stub, chosen by configuration.

---

## 2. The placement pattern

### 2.1 One feature, one package

Every feature is a package directly under the service's root package, next to the legacy `controllers`, `services`, `entities` folders:

```
com.ags.health.hr.candidates
├── controllers/            legacy, unchanged
├── services/               legacy, unchanged
├── entities/               legacy, unchanged
├── shared/                 new: things every new feature uses
├── profile/                new feature
│   ├── ProfileConfig.java          the only place beans are created
│   ├── domain/                     rules: plain Java, no Spring, no database
│   ├── port/                       interfaces to legacy code or other systems
│   ├── service/                    use cases: permission, transaction, audit
│   ├── store/                      JdbcTemplate access to the feature's own tables
│   └── web/                        thin controllers
├── mapping/
└── ...
```

What goes in each sub-package:

| Sub-package | Contains | May depend on | Must not |
| :--- | :--- | :--- | :--- |
| `domain` | Records, enums, rule classes (`MappingScenarioResolver`, `RemapPlanner`, `StageHistoryValidator`, `FeedbackScorer`) | JDK, `common.platform` value types | Use Spring, JDBC, HTTP, the clock directly (time is passed in) |
| `port` | Interfaces for data the feature does not own (`ApplicationPort`, `ProfilePort`, `MeetingPort`) and HTTP clients for other services | `domain`, `common.platform.http` | Contain business rules |
| `service` | One class per use case group. Checks permission and scope, opens the transaction, calls domain rules, writes stores, records audit, triggers notifications | everything above | Build SQL, parse HTTP requests |
| `store` | `JdbcTemplate` code for tables the feature owns, one class per aggregate | Spring JDBC | Call other services, hold rules |
| `web` | `@RestController` classes. Read the caller with `CallerProvider.require()`, call one service method, return its result | `service` | Check permissions, hold logic, touch stores |
| `XxxConfig` | `@Configuration` that creates the feature's beans with constructor arguments | everything | Be split across files |

Small features (`versant`, `assessmentbridge`, `offer`, `vendorbridge`) keep the same roles but put the few classes directly in the feature package.

### 2.2 Naming

| Item | Rule | Example |
| :--- | :--- | :--- |
| Bean names | `p5` prefix in candidate / job / vendor services, `integ` in integration-services | `p5StatusMover`, `p5OutboxStore` |
| Tables | Owning service prefix plus feature | `cand_mapping_action`, `job_p5_requisition`, `vend_p5_task`, `integ_offer_sync` |
| Config keys | `digihire.<service>.<feature>.*` | `digihire.candidate.panel.orc-restriction-days` |
| Permission codes | `OBJECT:ACTION`, same as admin-services | `APPLICATION:REMAP` |
| Audit actions | Past tense, upper snake case | `APPLICATION_REMAPPED`, `ID_DOCUMENT_REVEALED` |
| Error codes | Upper snake case in `PlatformException` | `NOT_TAGGED_RECRUITER`, `TASK_LIMIT_REACHED` |
| SQL scripts | `db/p5/<service>-p5-schema.sql`, statement separator `@@` | `candidate-p5-schema.sql` |

### 2.3 Code style

The same style as the Sprint 2 `assessment-services` and `admin-services` code:

* Java 20 records for DTOs and value objects; request records nested in the controller or service that uses them.
* Constructor injection. Lombok only for `@ConfigurationProperties` getters and setters.
* No JPA entities for new tables. New tables use `JdbcTemplate`, so Hibernate `ddl-auto: update` never touches them and the same SQL runs on H2 and PostgreSQL.
* Every new table is created by an idempotent script (`CREATE TABLE IF NOT EXISTS`, `INSERT ... WHERE NOT EXISTS`) run at start-up by `SchemaInitializer`.
* `@Transactional` on service methods; read methods are `readOnly = true`. Bulk work uses `TransactionTemplate` per item so one bad row does not undo the others.
* No code comments, by request.

---

## 3. Where every folder goes

Copy the folders into `smartie-core` at the same relative paths:

```
smartie-core/
├── smartie-common-utils/src/main/java/com/ags/health/hr/common/platform/     NEW package, copy whole
│   ├── approval/  assessment/  audit/  bulk/  caller/  crypto/  db/  error/
│   ├── http/  jobs/  notify/  outbox/  page/  storage/  time/  validation/  workflow/
├── smartie-common-utils/src/test/java/com/ags/health/hr/common/platform/     tests
│
├── candidate-services/src/main/java/com/ags/health/hr/candidates/
│   ├── shared/            Sprint 3, needed by everything below
│   ├── profile/           Sprint 3
│   ├── mapping/           Sprint 3
│   ├── assessmentbridge/  Sprint 3
│   ├── versant/           Sprint 3
│   ├── idproof/           Sprint 4
│   ├── photo/             Sprint 4
│   ├── pipeline/          Sprint 4
│   ├── offer/             Sprint 4
│   ├── hrround/           Sprint 5
│   ├── panel/             Sprint 5
│   ├── vendorbridge/      Sprint 5
│   └── adapters/          YOU create this: implementations of the ports (section 5)
├── candidate-services/src/main/resources/db/p5/candidate-p5-schema.sql
├── candidate-services/src/main/resources/db/p5/candidate-p5-data.sql
│
├── job-services/src/main/java/com/ags/health/hr/jobs/
│   ├── p5shared/  listing/  jdedit/  sync/
├── job-services/src/main/resources/db/p5/job-p5-schema.sql
│
├── vendor-services/src/main/java/com/ags/health/hr/vendor/
│   ├── p5shared/  onboarding/  allocation/  performance/
├── vendor-services/src/main/resources/db/p5/vendor-p5-schema.sql
│
├── integration-services/                                                     NEW module, copy whole
│
├── admin-services/src/main/resources/db/data-admin-sprint3-5.sql             append to data-admin.sql
└── assessment-services/src/main/resources/db/data-assessment-sprint3.sql     append to data-assessment.sql
```

Sprint order matters only inside candidate-services: `shared` first, then Sprint 3, then 4, then 5. Each feature can be switched off with `digihire.candidate.<feature>.enabled=false`. The dependencies between features are:

| Feature | Needs |
| :--- | :--- |
| `mapping` | `shared`, a `RegistrationCheck` (from `profile`, or your own bean) |
| `assessmentbridge`, `versant` | `shared` |
| `pipeline` | `assessmentbridge` (`NextStageRouting`) |
| `offer` | `assessmentbridge` (inbox, exception store) |
| `hrround` | `photo`, `mapping` (`RejectionReasonService`) |
| `panel` | `photo`, `mapping` (`MeetingPort`, `RejectionReasonService`) |

---

## 4. Integration steps per service

### 4.1 smartie-common-utils

1. Copy `common/platform` (main and test).
2. Add the dependencies from `config/pom-dependencies.xml` that the library does not have yet (`jjwt-api`, `spring-jdbc`, `spring-web`, `jakarta.servlet-api` as `provided`, `aws-java-sdk-s3` as `optional`).
3. `mvn install` first, as today.

Nothing in `platform` is a Spring bean. Each service builds what it needs in its own `@Configuration`, so adding the package changes nothing in services that do not use it.

### 4.2 candidate-services

1. Copy the packages and `db/p5` scripts (section 3).
2. Add `pdfbox` 3.0.x and `poi-ooxml` from `config/pom-dependencies.xml` if they are missing.
3. Merge `config/candidate-services.yml` into `application.yml` and set the secrets: `JWT_SECRET`, `INTERNAL_SERVICE_KEYS`, `P5_KEK_KEYS` (`k1:<base64 of 32 random bytes>`), `P5_KEK_ACTIVE` (`k1`), `P5_ID_HASH_PEPPER` (16+ characters).
4. Add `PANEL_ON_HOLD` and `REMAPPED` to the `ApplicationStatus` enum (section 10).
5. Implement the ports in a new `adapters` package (section 5). The service does not start until `ApplicationPort`, `CandidatePort`, `CandidateAccessPort`, `StageHistoryPort`, `ProfilePort`, `ProfilePhotoPort` and `PanelistDirectoryPort` have a bean.
6. If candidate-services has Spring Security, `permitAll()` for `/internal/**`. Those endpoints check `X-Internal-Key` themselves.
7. Point assessment-services' event webhook at the inbox: `config/assessment-services.yml`.

### 4.3 job-services

1. Copy `p5shared`, `listing`, `jdedit`, `sync` and `db/p5/job-p5-schema.sql`.
2. Merge `config/job-services.yml`. Leave `oracle.mode: STUB` until DEP-S4-11 credentials arrive, then set `REST` and the URLs.
3. Optional adapters: `PublicationPort` for `CAREER_PAGE` and `BUDDY_FINDER` (default records the publication locally), `JdPort` (write the approved JD to the legacy `JobPosting`), `RequisitionSink` (also write synced requisitions into the legacy `job_requisition` / `jobposting` tables).
4. The mirror table `job_p5_requisition` is filled by the sync. Run `POST /requisition-sync/run?full=true` once after deployment.

### 4.4 vendor-services

1. Copy `p5shared`, `onboarding`, `allocation`, `performance` and `db/p5/vendor-p5-schema.sql`.
2. Merge `config/vendor-services.yml`; set `P5_VENDOR_PEPPER`.
3. Adapters: `VendorProvisioningPort` (create the legacy `Vendor` row on final approval and return its id), `InvitePort` (send the registration link email), `CandidateLookupPort` (ask candidate-services whether an email / mobile is already in process).
4. Add `/vendor-services/public/vendor-registration/**` to the gateway `RouteValidator` open list. The registration token is the credential there.

### 4.5 integration-services (new)

1. Copy the module. Port 8991, context path `/integration-services`.
2. Add a gateway route for `/integration-services/**` but block `/integration-services/internal/**` at the gateway; only the callback (`/callbacks/oracle/offers`) and the admin screens (`/call-log`, `/offers/**`) are public routes.
3. Configure Oracle offer, IDV and face match with `*_MODE=REST` and their URLs / secrets once the DEP-S4 items arrive. Until then the stubs answer.
4. Set `CANDIDATE_EVENTS_URL` to `.../candidate-services/internal/integration-events`.

### 4.6 admin-services and assessment-services

Append the two SQL files. Both are idempotent and guarded by changeset ids (`rbac-seed-v4`, `approval-seed-v2`). Then add the approvers per LOB for `JD_EDIT` and `VENDOR_ONBOARDING` in the Approval Hierarchy screen (DEP-S4-15, DEP-S5-09).

---

## 5. Adapters the team implements

Ports are the only link between new code and legacy code. Put the implementations in `candidate-services/.../candidates/adapters` and annotate them `@Component`.

| Port | Package | Purpose | Legacy source |
| :--- | :--- | :--- | :--- |
| `ApplicationPort` | `shared.port` | Read, create, change status, re-tag, change requisition | `ApplicationsService`, `Application`, `ApplicationStatusLog` |
| `CandidatePort` | `shared.port` | Read candidate, find by email / mobile, tag recruiter | `CandidatesService`, `Candidate` |
| `CandidateAccessPort` | `shared.port` | Is this candidate in the caller's scope | `CandidateAccessGuard` / `AccessEvaluator` |
| `StageHistoryPort` | `shared.port` | Status history of an application | `application_status_log` |
| `RequisitionPort` | `shared.port` | Requisition by id | Default: HTTP to job-services `/internal/requisitions/{id}` |
| `ProfilePort` | `profile.port` | Flat profile map in, changes out | `PersonalInformation`, address, education, `IdProofDetails` |
| `ProfilePhotoPort` | `photo.port` | Reference photo bytes | `S3Util` profile image |
| `PanelistDirectoryPort` | `panel.port` | Active panel members | `PanelMember` |
| `MeetingPort` | `mapping.port` | Teams meeting create / cancel | Default: link only; real one wraps the `PanelEventService` Teams call |
| `NotificationDelivery` | `assessmentbridge` | Send a queued notification | Task 5 email trigger engine / `NotificationTriggerEvent` |
| `OfferDataPort` | `offer` | Offer fields for an application | Salary approval / CTC data on `Application` |
| `IdentityHintPort` | `idproof.port` | Name and DOB for IDV | Profile |

Only the first seven are required to start. The others have defaults.

`ApplicationPort` adapter, as a starting point (adjust repository and field names to the real ones):

```java
package com.ags.health.hr.candidates.adapters;

@Component
@RequiredArgsConstructor
public class LegacyApplicationAdapter implements ApplicationPort, StageHistoryPort {

    private final ApplicationRepository applications;
    private final ApplicationStatusLogRepository logs;
    private final ApplicationsService legacy;

    @Override
    public Optional<ApplicationView> find(String id) {
        return applications.findById(UUID.fromString(id)).map(this::view);
    }

    @Override
    public List<ApplicationView> findOpenByCandidate(String candidateId) {
        return applications.findByCandidateId(UUID.fromString(candidateId)).stream()
                .map(this::view).filter(a -> StageCatalog.standard().isOpen(a.status())).toList();
    }

    @Override
    public List<ApplicationView> findByCandidate(String candidateId) {
        return applications.findByCandidateId(UUID.fromString(candidateId)).stream().map(this::view).toList();
    }

    @Override
    @Transactional
    public ApplicationView create(NewApplication n) {
        Application a = legacy.createApplicationForRequisition(UUID.fromString(n.candidateId()), n.requisitionId(), n.jobId(),
                n.hrUserId(), n.source(), n.subSource(), ApplicationStatus.valueOf(n.status()));
        legacy.updateApplicationStatusLog(a, n.status(), n.change().remarks(), n.change().actorId(), n.change().system());
        return view(a);
    }

    @Override
    @Transactional
    public void changeStatus(String id, String toStatus, StatusChange c) {
        Application a = applications.findById(UUID.fromString(id)).orElseThrow();
        a.setStatus(ApplicationStatus.valueOf(toStatus));
        legacy.updateApplicationStatusLog(a, toStatus, c.remarks(), c.actorId(), c.system());
    }

    @Override
    public List<StageEntry> history(String applicationId) {
        return logs.findByApplicationIdOrderByCreatedDateAsc(UUID.fromString(applicationId)).stream()
                .map(l -> new StageEntry(l.getStatus().name(), l.getCreatedDate(), l.getUserId(), l.isSystemUpdate())).toList();
    }

    private ApplicationView view(Application a) {
        return new ApplicationView(a.getId().toString(), a.getCandidate().getId().toString(), a.getJobId(), a.getRequisitionId(),
                a.getStatus().name(), a.getHrUserId(), a.getLob(), a.getLocation(), a.getOrcId(), a.getRoleCode(), a.getSource(),
                a.getUpdatedDate());
    }
}
```

Rules for adapters:

* `changeStatus` must write `application_status_log` the same way legacy code does, so the existing history screens keep working.
* Adapters do not check permissions or rules; `StatusMover` and the services already did.
* Adapters join the caller's transaction (`@Transactional` with default propagation), so the status change, the audit row and the outbox event commit or roll back together.
* `ProfilePort.load` returns the keys of `FieldCatalog` (`firstName`, `dateOfBirth` as `YYYY-MM-DD`, `panNumber`, ...). `apply` receives the same keys.

`NotificationDelivery` adapter:

```java
@Component
@RequiredArgsConstructor
public class EmailEngineDelivery implements NotificationDelivery {

    private final ApplicationEventPublisher events;

    @Override
    public void deliver(NotificationRequest r) {
        events.publishEvent(new NotificationTriggerEvent(r.eventType(), r.applicationId(), r.candidateId(), r.idempotencyKey(), r.context()));
    }
}
```

Until this bean exists, notifications wait in `cand_p5_outbox` (visible in the outbox stats) and are delivered once it is added. Nothing is lost.

---

## 6. Cross-cutting rules

### 6.1 Every status change goes through `StatusMover`

`shared.service.StatusMover` is the single place an application status changes. In order it:

1. checks remarks (required where the action needs them, max 1000 characters, no control characters);
2. checks the actor: system, tagged recruiter, or that recruiter's team lead (`ApplicantActionGuard`, task S3-12); scope ALL is off by default (`applicant.allow-scope-all`);
3. asks workflow-services (`workflow-enabled: true`) or the built-in `TabMovementPolicy` whether the move is allowed (task S3-13);
4. runs the `MoveGuard`s (today: `StageHistoryGuard`, task S4-22);
5. calls `ApplicationPort.changeStatus`;
6. writes `STATUS_CHANGED` to `audit_log` with from / to status, tab, reason, remarks and basis (task S3-14);
7. queues the notification, if the action has one;
8. tells the listeners (assessment relay, vendor relay) through the outbox.

Denied and blocked attempts are also audited (`STATUS_CHANGE_DENIED`, `STATUS_CHANGE_BLOCKED`). Moves that must skip the transition table (re-map, re-process, expired score, offer rejection, ORC change) are marked `asReset()` and are only accepted with a reason listed in `stages.reset-reasons`; they are audited as `STATUS_RESET`.

New code must not call `ApplicationPort.changeStatus` directly.

### 6.2 Errors

Services throw `PlatformException(status, code, message, details)`. `P5ExceptionAdvice` (scoped to the new packages, so legacy error handling is unchanged) turns it into RFC 7807 `ProblemDetail` with `code`, `correlationId` and `errors`. Validation problems return 422 with one entry per field.

### 6.3 Security

* `CallerProvider.require()` verifies the HS256 JWT (header or `token` cookie) and loads roles, permissions and scope from admin-services `/internal/rbac/effective` (cached 60 s).
* Permission checks are in the services, not the controllers, so the same rule applies to every entry point.
* Candidate data needs either the candidate themselves or the staff permission plus `CandidateAccessPort.canView` (`CandidateGuard`).
* Vendor users are limited to their own vendor through `vend_p5_vendor_user` (`VendorScope`).
* `/internal/**` endpoints require `X-Internal-Key`, compared in constant time; per-service keys (`INTERNAL_SERVICE_KEYS`) identify the caller.
* The Oracle callback requires an HMAC-SHA256 signature of the body.

### 6.4 Audit

`AuditRecorder` writes to the shared `audit_log` table (the Sprint 1 decision). It adapts to the real table: id strategy, missing optional columns, column lengths, JSON / JSONB details, and an old `event_type` check constraint (unknown categories are stored as `ACTIVITY` with the category in the details). `record(...)` fails the transaction if the row can not be written; `recordQuietly(...)` is used only for denials and background jobs and falls back to the `AUDIT_FALLBACK` log.

### 6.5 Events between services

* Outgoing: write to the service's outbox table in the same transaction (`OutboxStore.append`), then a scheduled relay delivers it with backoff and parking (`OutboxRelay`, `IntegrationEventRelay`).
* Incoming: `AssessmentEventInbox` stores each event id in `cand_p5_inbox` before handling it, so a resent batch is not applied twice. If a handler fails, the claim is released and the endpoint answers 503 so the sender resends.
* Flows: candidate → assessment-services (`APPLICATION_EVENT`: created, walked in, stage changed, rejected); assessment-services → candidate (`ASSESSMENT_*`); integration-services → candidate (`OFFER_*`, `CANDIDATE_HIRED`); candidate → vendor-services (`VENDOR_CANDIDATE_STATUS`).

### 6.6 Notifications

`NotificationPort.trigger` writes `NOTIFICATION_REQUESTED` to the outbox. The email therefore goes out only if the business transaction commits, and every request has an idempotency key (`template:application:status:time`).

### 6.7 Files and encryption

* `DocumentStore` (S3 with SSE-KMS, or memory for local runs) for vendor documents and panel recordings.
* `EnvelopeEncryptingDocumentStore` on top of it for ID documents, ID numbers, HR screenshots and kiosk photos: AES-256-GCM with a random data key per file, wrapped by a key-encryption key that can be rotated (`kek-keys: k1:...,k2:...`, `kek-active: k2`; old files stay readable).
* ID numbers are kept only as an HMAC (for duplicate checks) and a masked value; the clear number is in the encrypted store.
* `FileInspector` checks magic bytes, size, a single matching extension, and rejects PDFs with scripts, actions or attachments.

### 6.8 Time

`BusinessClock` works in Asia/Kolkata. Vendor deadlines use `BusinessDays` (Saturday, Sunday and configured holidays skipped).

### 6.9 Scheduled jobs

Each job runs through `ScheduledJobRunner`, which takes a database lock (`*_job_lock` table) so only one instance runs it, and sets a correlation id for its logs. All jobs can be switched off with `jobs.enabled=false` per service.

---

## 7. Task to code map

### P5-S3 (Weeks 15-16)

| # | Task | Code |
| :--- | :--- | :--- |
| 1 | Registration form fields | `profile.domain.FieldCatalog` (25 fields, sections, required flags, options); `GET /candidates/{id}/profile-fields` |
| 2 | Identity and contact validation | `profile.domain.ProfileValidator` with `platform.validation.IdentityValidators` (PAN, Aadhaar with Verhoeff, passport, mobile, email, PIN code, names), age 18-60, cross-field checks, duplicate email / mobile |
| 3 | Stage-based update validation | `profile.domain.StageEditPolicy` (registration, applicant, in process, offer) and `ProfileService.update` |
| 4 | Field lock after applicant creation | `FieldDefinition.lockedFrom`; override only for staff with `CANDIDATE:UPDATE_LOCKED` and a reason; every change in `cand_profile_change` with masked old / new values |
| 5 | Secure PDF export | `ProfileDocumentBuilder` (sensitive values masked for staff) and `PdfBoxProfileRenderer` (watermark with user and time, AES-256, print only, no copy / edit); `GET /candidates/{id}/profile.pdf`, `Cache-Control: no-store`, audited |
| 6 | Registration completion gate | `ProfileService.requireRegistered`, used by `MappingService` through `RegistrationCheck`; `GET /candidates/{id}/profile-completeness` |
| 7 | Job re-mapping, 6 scenarios | `mapping.domain.RemapPlanner` (`SAME_ROLE_SAME_LOB`, `SAME_LOB_NEW_ROLE`, `NEW_LOB`, `NEW_LOCATION`, `TARGET_UNAVAILABLE`, `STAGE_LOCKED`), `ApplicantActionService.previewRemap / remap`, modes `IN_PLACE` and `NEW_APPLICATION` |
| 8 | Walk-in scheduling | `SchedulingService.scheduleWalkIn`, slots with capacity (`cand_interview_slot`), reschedule releases the seat |
| 9 | Online interview scheduling | `SchedulingService.scheduleOnline` with `MeetingPort`, moves to `WAITING_FOR_HRROUND` |
| 10 | Reject with template and remarks | `ApplicantActionService.reject` with `RejectionReasonService` (reason per stage, remarks where required, template per reason) |
| 11 | Move to HR Interview tab | `ApplicantActionService.moveToHr` |
| 12 | Tagged recruiter and TL only | `shared.service.ApplicantActionGuard` |
| 13 | Workflow-driven tab movement | `StatusMover` with `WorkflowHttpClient` or `TabMovementPolicy`; `GET /applicants/{id}/transitions` |
| 14 | Mandatory logging | `StatusMover` audit, `cand_mapping_action`, booking audit rows |
| 15 | Versant automated triggers | `assessmentbridge.NextStageRouting` (Versant roles / LOBs), `ApplicationEventRelay`, assessment seed `data-assessment-sprint3.sql` |
| 16 | Versant exception handling | `AssessmentOutcomeHandler` (not taken, link expired, invite failed), `cand_assessment_exception`, `VersantExceptionService.resolve` |
| 17 | Versant reschedule approval | Sprint 2 `assessment-services` `RescheduleService` (approval inbox); candidate side reacts to `ASSESSMENT_RESCHEDULED` |
| 18 | Versant cooling rules | Sprint 2 `CoolingPolicy` (15 / 45 / 180) refuses new attempts during cooling; `ASSESSMENT_FAILED` carries `coolingUntil`; Map Candidate shows the cooling period as a warning |
| 19 | Voice Fresher restriction | Sprint 2 `VoiceFresherService`; `REJECTED` events carry role and location; mapping blocks `VOICE_FRESHER_RESTRICTED` |
| 20 | Source management | `mapping.domain.SourceChannel` (ERS, DIRECT, VENDOR, RECRUITER, CAMPUS, SOCIAL, with aliases) and `SourceRules` |
| 21 | Candidate status identification | `MappingScenarioResolver.stateOf`: Yet to register, Registered, Application created, In process |
| 22 | Mapping scenarios 1-3 | `MappingScenarioResolver` S1, S2, S3 |
| 23 | Mapping scenarios 4-6 | `MappingScenarioResolver` S4, S5, S6 |
| 24 | Tag and Map | `MappingService.map` (`TAG_AND_MAP`) |
| 25 | On Hold when no positions | `MAP_ON_HOLD` creates the application in `PIPELINE` with reason `NO_OPENINGS` and sends `APPLICATION_ON_HOLD` |
| 26 | Standard rejection reason and email | `ApplicantActionService.reject`, `cand_rejection_reason` (10 seeded reasons) |
| 27 | Timestamps and remarks on mapping | `MappingActionStore` (every attempt, including blocked ones); remarks required by default |
| 28 | Walk-in email | `WALK_IN_INVITE` with date, time and venue |
| 29 | Online scheduling from Map Candidate | Same endpoint, called with the new application id |
| 30 | Pipeline movement | `ApplicantActionService.moveToPipeline` (hold reasons) |
| 31 | Active requisition validation | `MappingScenarioResolver.requisitionProblem` (inactive, expired, not found) using job-services `/internal/requisitions/{id}` |

### P5-S4 (Weeks 17-18)

| # | Task | Code |
| :--- | :--- | :--- |
| 1 | ID proof upload, secure storage | `IdProofService.upload`: file checks, envelope encryption, supersedes the previous file of the same type |
| 2 | External IDV API | `IdentityVerificationClient` → integration-services `/internal/identity/verify` → `IdentityVerificationProvider` (REST / stub), rate limited; run asynchronously through the outbox with retry |
| 3 | Validation badge | `VerificationBadge` (NONE, PENDING, VERIFIED, ATTENTION) in `GET /candidates/{id}/id-documents` |
| 4 | Role-restricted ID access | `CANDIDATE_ID_DOC:VIEW` (masked metadata), `CANDIDATE_ID_DOC:REVEAL` (file, reason required), scope check, `ID_DOCUMENT_REVEALED` audit |
| 5 | Encryption at rest and in transit | AES-256-GCM envelope with rotating KEK, S3 SSE-KMS, HMAC for numbers, TLS through the gateway |
| 6 | Manual photo verification screen | `PhotoController` endpoints and `PhotoVerificationService.manual` |
| 7 | Panelist confirm / reject identity | Same, and `PanelService.decide` with reason `PHOTO_MISMATCH` |
| 8 | Auto-highlight photo mismatch | Mismatches flagged into `GET /photo-mismatches` for audit review, `PHOTO_MISMATCH_FLAGGED` security audit |
| 9 | Oracle offer field mapping | `integration.offer.OfferPayloadMapper` (configurable `offer.field-map`, transforms upper / lower / number / default) |
| 10 | Offer push | `OfferSyncService.accept`, `OracleOfferClient` (REST with idempotency key / stub); candidate side `OfferService.push` |
| 11 | Pre-push validation | `OfferValidator` (required fields, formats, salary, joining date window, age); 422 with field errors back to the recruiter |
| 12 | Oracle status to DigiHire | Signed callback and 20-minute poll → outbox → candidate `/internal/integration-events` → `OfferOutcomeHandler` |
| 13 | Result sync and reconciliation | `OfferSyncService.reconcile` (nightly job and on demand), `integ_offer_reconciliation` |
| 14 | Rejected offer auto-revert | `OfferOutcomeHandler`: `OFFER_REJECTED` / `WITHDRAWN` → `SHORTLISTED` immediately, with notification |
| 15 | Offer error handling and retry log | `integ_call_log` (masked), retry with backoff, park after 8 attempts, `OFFER_PARKED` event, admin retry endpoint |
| 16 | Bulk status update | `PipelineService.bulk`: each item in its own transaction, job and per-row results in `cand_bulk_job*` |
| 17 | Re-processing by prior stage | `ReprocessPlanner` and `PipelineService.reprocess` |
| 18 | Re-evaluation on expired score | `ReprocessPlanner` sends expired scores back to `ASSESEMENT_YET_TO_START` |
| 19 | Expired score to Fresher Pipeline | `AssessmentOutcomeHandler` on `ASSESSMENT_SCORE_EXPIRED` (emitted by the Sprint 2 60-day job) |
| 20 | Bulk via multi-select | `POST /pipeline/bulk-status` with ids, `dryRun` |
| 21 | Bulk via Excel upload | `XlsxBulkRowReader` and `CsvBulkRowReader` (columns `applicationId, targetStatus, reasonCode, remarks`, formula cells neutralised) |
| 22 | Stage-history validation | `StageHistoryValidator` plus `StageHistoryGuard`, applied to every move out of Pipeline |
| 23 | Recruiter view of open jobs | `jobs.listing.ListingService.search`, `GET /requisitions/open` |
| 24 | Search, filter, pagination | Same endpoint: `q`, `lob`, `location`, `recruiterId`, `page`, `size` |
| 25 | Publish to Career Page | `PublicationPort` channel `CAREER_PAGE`, `JOB:PUBLISH` |
| 26 | Publish to Buddy Finder | `PublicationPort` channel `BUDDY_FINDER` |
| 27 | JD edit with TA Head approval | `jdedit.JdEditService` with flow `JD_EDIT`, HTML sanitised, version check, approved JD republished |
| 28 | Oracle requisition sync | `sync.RequisitionSyncService.run`, pages of 25 |
| 29 | LOB sync | `RequisitionSyncService.syncLobs`, `job_p5_lob` |
| 30 | Incremental sync | Watermark in `job_p5_sync_state` (`LastUpdateDate`), moves only after a clean run |
| 31 | Real-time listing update | 15-minute schedule, manual run, `GET /requisitions/changes?since=` cursor for the UI |
| 32 | Hide invalid / expired jobs | `JobVisibilityPolicy`, automatic unpublish, `active=false` on the internal endpoint |
| 33 | Field mapping consistency | `sync.FieldMapping` (configurable), issues in `job_p5_sync_issue`, critical issues hide the job |
| 34 | Sync failure log and retry | `job_p5_sync_run`, `job_p5_sync_failure`, hourly retry, park, manual retry |

### P5-S5 (Weeks 19-20)

| # | Task | Code |
| :--- | :--- | :--- |
| 1 | Online interview mode | `hrround.service.HrRoundService.start(mode=ONLINE)` |
| 2 | In-office interview mode | Same, `IN_OFFICE` |
| 3 | Screenshot capture | `HrRoundService.screenshot` (encrypted, hash recorded); feedback blocked until the minimum is captured |
| 4 | Kiosk photo matching | `HrRoundService.kioskPhoto` → `FaceMatchPort` → `PhotoRules` thresholds; mismatch blocks feedback unless an override reason is given |
| 5 | Competency feedback configuration | `CompetencyService`, `cand_competency` (by LOB / role, weight, scale, minimum, mandatory) |
| 6 | Feedback entry and scoring | `FeedbackScorer` (weighted percentage, missing / out of range / below minimum) |
| 7 | Move to Panel | `SELECT` with `nextStage=PANEL_YET_TO_SCHEDULE` |
| 8 | Move to Assessment | `SELECT` with `ASSESEMENT_YET_TO_START`, `WAITING_FOR_DEVICE` or `VERSANT_YET_TO_START` |
| 9 | Rejected to Rejected tab | `REJECT` moves to `HR_REJECTED` at once, with reason and template |
| 10 | Valid next stage only | Allowed set and the transition policy both checked |
| 11 | Panel schedule | `panel.service.PanelService.schedule` (LOB, location, ORC id, 1-6 active panelists, Teams link) |
| 12 | Recording upload | Presigned upload URL then confirm, or multipart (MP4 / WebM checked) |
| 13 | Recording review | `PANEL:RECORDING_VIEW`, short-lived URL, every view audited, review notes |
| 14 | Select / Reject / Hold | `PanelService.decide` (panelists of that interview, or `PANEL:DECIDE`) |
| 15 | ORC change, same panel | `PanelService.changeOrc(SAME_PANEL)`: same LOB, outcome kept |
| 16 | ORC change, different panel | `changeOrc(DIFFERENT_PANEL)`: new round, back to `PANEL_YET_TO_SCHEDULE` |
| 17 | 60-day same-ORC restriction | `cand_orc_restriction` on panel rejection; `OrcRestrictionGuard` blocks mapping; scheduling and ORC change check it too |
| 18 | Reschedule with remarks history | `PanelService.reschedule` (reason codes, remarks required), before / after in `cand_panel_history` |
| 19 | Vendor onboarding and registration | `vendor.onboarding.OnboardingService.invite / register` (token link, GSTIN / PAN / IFSC checks) |
| 20 | Vendor documents | `OnboardingService.upload` (checklist, file checks, S3) |
| 21 | Vendor approval workflow | `submit` and `decide` (approve / reject / send back) on flow `VENDOR_ONBOARDING` |
| 22 | End-to-end approval logging | `vend_p5_approval_action` plus `APPROVAL` audit for every step, including auto-archive |
| 23 | Vendor performance dashboard | `performance.PerformanceService` (submitted, mapped, shortlisted, offered, joined, rejected, conversion, target attainment, days to join) |
| 24 | Vendor task allocation | `allocation.AllocationService.allocate` |
| 25 | Target-based restrictions | Total targets per requisition limited to `over-allocation-factor` × open positions |
| 26 | Task limit enforcement | Atomic submission counter (`submitted < max_submissions`), active task cap per vendor, database check constraint |
| 27 | Auto-archive after 7 business days | `OnboardingService.archiveExpired` (nightly), token invalidated |
| 28 | Vendor-sourced candidate linkage | `AllocationService.submit` (90-day ownership on hashed email / mobile, already-in-process check), `attach`, status relay from candidate-services |
| 29 | Vendor role and permission mapping | `VendorScope`, `vend_p5_vendor_user`, VENDOR role permissions |
| 30 | Three end-to-end scenarios | `VendorEndToEndScenariosTest` (happy path, auto-archive, limits / duplicates / scope) |

---

## 8. Dependencies to adapter or config

| Dependency | Where it plugs in |
| :--- | :--- |
| DEP-S3-01 Registration field list | `FieldCatalog.standard` (or a `FieldCatalog` bean of your own) |
| DEP-S3-02 Editable field matrix | `FieldDefinition.lockedFrom` per field |
| DEP-S3-03 PDF template | `ProfilePdfRenderer` bean (replace `PdfBoxProfileRenderer`) |
| DEP-S3-04 Versant API | Sprint 2 assessment-services `VersantProvider` |
| DEP-S3-05 Email templates | Template codes in `candidate.mapping.*-template`, `applicant.*-template`, rejection reasons |
| DEP-S3-06 Six mapping scenarios | `MappingScenarioResolver` and `RemapPlanner` (section 13) |
| DEP-S3-07 Slot master | `POST /interview-slots` or a data load into `cand_interview_slot` |
| DEP-S3-08 Source master / ERS feed | `SourceChannel` aliases; sub-source rules in `SourceRules` |
| DEP-S3-09 Rejection reasons | `candidate-p5-data.sql` and `PUT /rejection-reasons/{code}` |
| DEP-S3-10 Requisition validity feed | job-services sync (`validTo`, status) |
| DEP-S4-01 IDV API | integration-services `identity.mode=REST`, `IDV_URL`, `IDV_API_KEY`, `requests-per-minute` |
| DEP-S4-02 Secure storage | `storage.mode=S3`, bucket, KMS key, `kek-keys` |
| DEP-S4-03 Privacy / retention | Retention job not included; `DocumentStore.delete` is ready |
| DEP-S4-04 Photo verification sign-off | `photo.match-threshold`, `photo.review-threshold` |
| DEP-S4-05 / 06 / 07 / 08 Oracle offer | `offer.mode=REST`, base URL, credentials, `offer.field-map`, `ORACLE_CALLBACK_SECRET`, poll cron |
| DEP-S4-09 60-day validity | Sprint 2 assessment-services |
| DEP-S4-10 Excel template | Column names in `BulkRowReader` |
| DEP-S4-11 / 12 Oracle job sync and mapping | `jobs.oracle.*`, `jobs.oracle.field-map` |
| DEP-S4-13 / 14 Career Page, Buddy Finder | `PublicationPort` beans |
| DEP-S4-15 JD approval | `JD_EDIT` flow levels and approvers in admin-services |
| DEP-S5-01 Kiosk SDK | Kiosk app posts the photo to `/hr-interviews/{id}/kiosk-photo` |
| DEP-S5-02 Online interview platform | `MeetingPort` bean |
| DEP-S5-03 Recording storage | S3 bucket, `panel.recording-max-bytes`, lifecycle rule on `p5/panel/` |
| DEP-S5-04 Competency framework | `cand_competency` (5 seeded) and `PUT /competencies/{code}` |
| DEP-S5-05 / 06 ORC, panel, calendar masters | `PanelistDirectoryPort`, requisition `orcId` |
| DEP-S5-07 Vendor master / targets | Task allocation inputs |
| DEP-S5-08 Document checklist | `vendor.required-documents`, `optional-documents` |
| DEP-S5-09 Vendor approval hierarchy | `VENDOR_ONBOARDING` flow levels and approvers |

---

## 9. Data model

All tables are created by the scripts in each service; no Hibernate entity maps them.

| Service | Tables |
| :--- | :--- |
| candidate-services | `cand_p5_job_lock`, `cand_p5_outbox`, `cand_p5_inbox`, `cand_profile_change`, `cand_mapping_action`, `cand_rejection_reason`, `cand_interview_slot`, `cand_interview_booking`, `cand_assessment_exception`, `cand_id_document`, `cand_photo_check`, `cand_bulk_job`, `cand_bulk_job_item`, `cand_competency`, `cand_hr_interview`, `cand_hr_evidence`, `cand_hr_feedback`, `cand_panel_schedule`, `cand_panel_history`, `cand_panel_recording`, `cand_orc_restriction` |
| job-services | `job_p5_job_lock`, `job_p5_requisition`, `job_p5_publication`, `job_p5_jd_change`, `job_p5_jd_change_action`, `job_p5_sync_run`, `job_p5_sync_state`, `job_p5_sync_failure`, `job_p5_sync_issue`, `job_p5_lob` |
| vendor-services | `vend_p5_job_lock`, `vend_p5_onboarding`, `vend_p5_document`, `vend_p5_approval_action`, `vend_p5_vendor_user`, `vend_p5_task`, `vend_p5_candidate_link` |
| integration-services | `integ_job_lock`, `integ_outbox`, `integ_call_log`, `integ_offer_sync`, `integ_offer_reconciliation` |
| shared | `audit_log` (existing) |

---

## 10. Statuses, tabs and transitions

Add to `ApplicationStatus`:

| Status | Used for |
| :--- | :--- |
| `PANEL_ON_HOLD` | Panel Hold outcome (S5-14) |
| `REMAPPED` | Old application when `remap-mode: NEW_APPLICATION` |

`StageCatalog` maps each status to a tab (`MAP_CANDIDATE`, `APPLICANT`, `HR_INTERVIEW`, `ASSESSMENT`, `VERSANT`, `PANEL`, `PIPELINE`, `OFFER`, `JOINED`, `REJECTED`, `CLOSED`); override with `stages.tab-overrides`. `TabMovementPolicy` holds the allowed moves when workflow-services is not used; override one source status with `stages.transition-overrides: { PIPELINE: "CREATED|WAITING_FOR_HRROUND" }`. When `workflow-enabled: true`, workflow-services decides and the table is not used.

Applicant and Map Candidate rejections use `applicant.reject-status` (default `HR_REJECTED`); the HR round always rejects to `HR_REJECTED` and the panel to `PANEL_REJECTED`.

---

## 11. Permissions and approval flows

New permissions (admin seed `rbac-seed-v4`):

| Code | Default roles |
| :--- | :--- |
| `APPLICATION:REMAP`, `APPLICATION:REPROCESS` | Recruiter, Recruitment Manager, TA Head |
| `CANDIDATE:RETAG` | Recruitment Manager, TA Head |
| `CANDIDATE:UPDATE_LOCKED` | TA Head |
| `INTERVIEW_SLOT:MANAGE` | Recruitment Manager, TA Head |
| `REJECTION_REASON:MANAGE`, `COMPETENCY:MANAGE` | TA Head, Super Admin |
| `CANDIDATE_ID_DOC:VIEW` | Recruiter, Recruitment Manager, TA Head |
| `CANDIDATE_ID_DOC:VERIFY` | Recruitment Manager, TA Head |
| `CANDIDATE_ID_DOC:REVEAL` | TA Head |
| `CANDIDATE_PHOTO:VERIFY` | Recruiter, Recruitment Manager, TA Head, Interviewer |
| `OFFER:PUSH` | Recruitment Manager, TA Head |
| `JOB:SYNC`, `INTEGRATION:RETRY` | TA Head, Super Admin |
| `PANEL:DECIDE` | TA Head |
| `PANEL:RECORDING_UPLOAD` | Interviewer |
| `PANEL:RECORDING_VIEW`, `PANEL:CHANGE_ORC` | Recruitment Manager, TA Head |

Existing permissions reused: `APPLICATION:MAP`, `APPLICATION:REJECT`, `APPLICATION:MOVE_STAGE`, `APPLICATION:HOLD`, `APPLICATION:SCHEDULE_INTERVIEW`, `APPLICATION:BULK_UPDATE`, `CANDIDATE:VIEW`, `CANDIDATE:UPDATE`, `CANDIDATE:EXPORT`, `INTERVIEW_FEEDBACK:CREATE`, `INTERVIEW_SCHEDULE:UPDATE`, `JOB:VIEW`, `JOB:PUBLISH`, `JOB:EDIT_JD`, `VENDOR:*`, `VENDOR_TASK:*`, `CANDIDATE_SUBMISSION:CREATE`, `OFFER:VIEW`, `INTEGRATION:VIEW`, `ASSESSMENT:VIEW`, `AUDIT_LOG:VIEW`.

Approval flows (`approval-seed-v2`):

| Flow | Levels |
| :--- | :--- |
| `JD_EDIT` | 1: TA Head |
| `VENDOR_ONBOARDING` | 1: Recruitment Manager (fallback TA Head), 2: TA Head |

The requester can never approve their own JD change.

---

## 12. Endpoints

Paths are relative to each service's context path.

**candidate-services**

| Method | Path | Task |
| :--- | :--- | :--- |
| GET | `/candidates/{id}/profile-fields` | S3-1, 3 |
| PATCH | `/candidates/{id}/profile` | S3-2, 3, 4 |
| GET | `/candidates/{id}/profile-completeness` | S3-6 |
| GET | `/candidates/{id}/profile-changes` | S3-4 |
| GET | `/candidates/{id}/profile.pdf` | S3-5 |
| POST | `/mapping/assess` | S3-21, 22, 23, 31 |
| POST | `/mapping/map` | S3-20, 24, 25 |
| POST | `/mapping/invite` | S3-23 (S6) |
| GET | `/mapping/candidates/{id}/actions` | S3-27 |
| GET | `/mapping/sources` | S3-20 |
| GET | `/applicants/{id}/transitions` | S3-13 |
| POST | `/applicants/{id}/move`, `/move-to-hr`, `/move-to-pipeline`, `/reject` | S3-10, 11, 26, 30 |
| POST | `/applicants/{id}/remap/preview`, `/remap` | S3-7 |
| POST | `/applicants/{id}/walk-in`, `/online-interview`; GET `/bookings` | S3-8, 9, 28, 29 |
| POST, GET, DELETE | `/interview-slots` | S3-8 |
| POST | `/interview-bookings/{id}/cancel` | S3-8 |
| GET, PUT | `/rejection-reasons` | S3-26 |
| GET | `/assessment-exceptions`; POST `/{id}/resolve` | S3-16 |
| POST | `/internal/assessment-events`, `/internal/integration-events` | S3-15..19, S4-12, 14 |
| POST, GET | `/candidates/{id}/id-documents` | S4-1, 3 |
| POST | `/id-documents/{id}/verify`, `/decision`; GET `/content` | S4-2, 4 |
| POST, GET | `/applicants/{id}/photo-verification` | S4-6, 7 |
| GET | `/photo-mismatches`; POST `/{id}/review` | S4-8 |
| POST | `/pipeline/bulk-status`, `/pipeline/bulk-status/upload`; GET `/pipeline/bulk-jobs/{id}` | S4-16, 20, 21 |
| GET, POST | `/applicants/{id}/reprocess` | S4-17, 18 |
| POST | `/applicants/{id}/offer/push`; GET `/offer/status` | S4-10, 11 |
| POST, GET | `/applicants/{id}/hr-interview`; GET `/competencies` | S5-1, 2 |
| POST | `/hr-interviews/{id}/screenshots`, `/kiosk-photo`, `/feedback` | S5-3, 4, 6..10 |
| GET, PUT | `/competencies` | S5-5 |
| POST, GET | `/applicants/{id}/panel`; POST `/panel/orc-change` | S5-11, 15, 16 |
| POST | `/panel-schedules/{id}/reschedule`, `/decision`, `/recordings/upload-url`, `/recordings` | S5-12, 14, 18 |
| POST | `/panel-recordings/{id}/confirm`, `/review`; GET `/url` | S5-12, 13 |

**job-services**: `GET /requisitions/open`, `GET /requisitions/changes`, `GET /requisitions/{id}/details`, `POST|DELETE /requisitions/{id}/publications/{channel}`, `POST /requisitions/{id}/jd-changes`, `GET /jd-changes/inbox`, `GET /jd-changes/{id}`, `POST /jd-changes/{id}/decision`, `POST /requisition-sync/run`, `POST /lob-sync/run`, `GET /requisition-sync/runs|failures|issues`, `POST /requisition-sync/failures/{id}/retry`, `GET /lobs`, `GET /internal/requisitions/{id}`.

**vendor-services**: `POST /vendor-onboarding/invitations`, `GET /vendor-onboarding`, `GET /vendor-onboarding/{id}`, `POST /vendor-onboarding/{id}/decision`, `PUT /public/vendor-registration`, `POST /public/vendor-registration/documents`, `POST /public/vendor-registration/submit`, `POST /vendors/{id}/users`, `POST /vendor-tasks`, `GET /vendors/{id}/tasks`, `POST /vendor-tasks/{id}/close`, `POST /vendor-tasks/{id}/candidates`, `GET /vendor-performance`, `POST /internal/vendor-links/{id}/application`, `POST /internal/candidate-status`.

**integration-services**: `POST /internal/offers`, `GET /internal/offers/{applicationId}`, `POST /internal/identity/verify`, `POST /internal/face/match`, `POST /callbacks/oracle/offers`, `GET /call-log`, `GET /offers`, `POST /offers/{id}/retry`, `POST /offers/reconcile`, `GET /offers/reconciliation`.

---

## 13. Assumptions waiting for sign-off

Each is one class or one config value, so changing it later is local.

**Six mapping scenarios (DEP-S3-06)**, `MappingScenarioResolver`:

| Scenario | Situation | Action |
| :--- | :--- | :--- |
| S1 | Registered, not tagged, no open application | Tag and Map |
| S2 | Tagged to the caller or the caller's team, no open application | Map |
| S3 | Tagged to another recruiter, no open application | Request access (Tag and Map for `CANDIDATE:RETAG`) |
| S4 | Open application owned by the caller / team | Re-map that application |
| S5 | Open application owned by someone else | Request access |
| S6 | Not registered or registration incomplete | Invite to register |

Blockers on top of the scenario: requisition missing / inactive / expired, already mapped to the same requisition, application past panel selection, blacklist, cooling, Voice Fresher restriction, 60-day ORC restriction, eligibility service unavailable (fail closed; `eligibility-fail-open` to change). No open positions turns Map into Map On Hold.

**Six re-mapping scenarios**, `RemapPlanner`: same role and LOB keeps the stage; new role in the same LOB keeps the stage before assessment and restarts assessment after it unless a valid score exists; new LOB restarts at `CREATED` after the applicant tab; new location restarts the HR round if it was in progress; unavailable targets are blocked with a suggestion to move to Pipeline On Hold; applications at panel selected or later are locked.

Other defaults to confirm: registration fields and lock stages (`FieldCatalog`), 10 rejection reasons, 5 competencies with a 60% pass mark, photo thresholds 0.80 / 0.60, rejected offers revert to `SHORTLISTED`, Oracle field names in `FieldMapping` and `OfferPayloadMapper`, vendor over-allocation 3×, submission limit 3× target, 90-day vendor ownership window, Versant role / LOB list (empty until DEP-S2-09).

---

## 14. Verification

Run here, outside a full Maven build (the build environment could not reach Maven Central):

* All five modules type-checked against the real Jackson, SLF4J, H2, PostgreSQL driver and Spring JDBC jars, with compile stubs for the Spring web / Boot / security, jjwt, PDFBox, POI and AWS SDK APIs.
* 91 tests passed on H2: smartie-common-utils 22, candidate-services 55, job-services 6, integration-services 5, vendor-services 3.
* The same candidate, job, integration and vendor suites passed on **PostgreSQL 16**, including the `audit_log` check-constraint fallback and JSONB details. Run them yourself with `-Dp5.test.pg.url=jdbc:postgresql://host:5432/db -Dp5.test.pg.user=... -Dp5.test.pg.password=...` (the schema `public` of that database is dropped and recreated).
* Every schema and seed script (candidate, job, vendor, integration, admin v4 on top of the Sprint 2 admin seed, assessment Sprint 3 on top of the Sprint 2 assessment seed) ran twice on PostgreSQL 16 without errors or duplicate rows.

Not verified here: the Spring application contexts (bean wiring with your adapters), PDFBox output, Excel parsing with real POI, and the REST providers against real Oracle / IDV / face-match endpoints. Run `mvn verify` after adding the adapters, and smoke-test each `*_MODE=REST` provider in STG.

---

## 15. Checklist for adding more code in this pattern

1. New feature → new package under the service root with `domain`, `port`, `service`, `store`, `web` and one `XxxConfig`.
2. Rules in `domain`, testable without Spring.
3. Legacy data only through a port; implementation in `adapters`.
4. Status changes only through `StatusMover`; add a `MoveGuard` for any new pre-condition.
5. Permission and scope checks in the service, using `Caller`, `CandidateGuard`, `ApplicantActionGuard` or `VendorScope`.
6. New tables in the service's `db/p5` script, idempotent, `@@` separator, prefixed names; access only through a store class.
7. Every state change audited with `AuditRecorder.record` in the same transaction.
8. Emails and cross-service messages through the outbox, never a direct call inside the transaction.
9. Errors as `PlatformException` with a stable code.
10. Config under `digihire.<service>.<feature>`, with a feature `enabled` flag on the config and controller.
11. Tests: rule classes with plain JUnit, services with the in-memory fakes in `support/Fakes` and `TestDatabase` (H2 by default, PostgreSQL with the system property).
