package com.ags.health.hr.common.rbac;

import org.junit.jupiter.api.Test;

import java.util.Map;
import java.util.Set;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

class ScopeFilterTest {

    private static EffectiveAccess access(ScopeLevel level, Set<String> conditional, Set<String> team, Set<String> lobs,
                                          Set<String> locations, Map<String, Set<String>> shared) {
        return new EffectiveAccess("me", null, "me@agshealth.com", true, true, Set.of("RECRUITMENT_MANAGER"),
                Set.of("CANDIDATE:VIEW", "CANDIDATE:DELETE"), conditional,
                new DataScope(level, "me", team, lobs, locations, shared));
    }

    @Test
    void missingPermissionDeniesEverything() {
        ScopeFilter f = ScopeFilter.of(access(ScopeLevel.ALL, Set.of(), Set.of(), Set.of(), Set.of(), Map.of()),
                "JOB:VIEW", "JOB");
        assertTrue(f.denyAll());
    }

    @Test
    void teamSeesOwnAndReports() {
        ScopeFilter f = ScopeFilter.of(access(ScopeLevel.TEAM, Set.of(), Set.of("r1"), Set.of(), Set.of(), Map.of()),
                "CANDIDATE:VIEW", "CANDIDATE");
        assertTrue(f.matches("r1", null, "c1", null, null));
        assertTrue(f.matches("me", null, "c2", null, null));
        assertFalse(f.matches("r9", null, "c3", null, null));
    }

    @Test
    void lobWithLocationNarrowing() {
        ScopeFilter f = ScopeFilter.of(access(ScopeLevel.LOB, Set.of(), Set.of(), Set.of("VOICE"), Set.of("CHENNAI"), Map.of()),
                "CANDIDATE:VIEW", "CANDIDATE");
        assertTrue(f.matches("x", null, "c1", "VOICE", "CHENNAI"));
        assertFalse(f.matches("x", null, "c1", "VOICE", "TRICHY"));
        assertFalse(f.matches("x", null, "c1", "CODING", "CHENNAI"));
    }

    @Test
    void conditionalIgnoresWideScopeButHonoursShares() {
        ScopeFilter f = ScopeFilter.of(access(ScopeLevel.ALL, Set.of("CANDIDATE:DELETE"), Set.of(), Set.of(), Set.of(),
                Map.of("CANDIDATE", Set.of("c7"))), "CANDIDATE:DELETE", "CANDIDATE");
        assertFalse(f.unrestricted());
        assertFalse(f.matches("x", null, "c1", null, null));
        assertTrue(f.matches("me", null, "c1", null, null));
        assertTrue(f.matches("x", Set.of("me"), "c1", null, null));
        assertTrue(f.matches("x", null, "c7", null, null));
    }
}
