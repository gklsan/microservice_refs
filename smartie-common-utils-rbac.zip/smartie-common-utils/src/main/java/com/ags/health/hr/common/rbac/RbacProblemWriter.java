package com.ags.health.hr.common.rbac;

import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.nio.charset.StandardCharsets;

/** 401 / 403 bodies in the same RFC 7807 shape admin-services returns: {status, title, detail, code}. */
final class RbacProblemWriter {

    private RbacProblemWriter() {
    }

    static void write(HttpServletResponse response, int status, String title, String code, String detail) throws IOException {
        response.setStatus(status);
        response.setContentType("application/problem+json");
        response.setCharacterEncoding(StandardCharsets.UTF_8.name());
        response.getWriter().write("{\"type\":\"about:blank\",\"status\":" + status + ",\"title\":\"" + title
                + "\",\"detail\":\"" + detail + "\",\"code\":\"" + code + "\"}");
    }
}
