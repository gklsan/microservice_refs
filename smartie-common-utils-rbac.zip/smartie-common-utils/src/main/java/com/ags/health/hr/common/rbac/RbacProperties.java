package com.ags.health.hr.common.rbac;

import org.springframework.boot.context.properties.ConfigurationProperties;

import java.time.Duration;
import java.util.ArrayList;
import java.util.List;

/**
 * smartie.rbac.* - OFF by default, so adding this library changes nothing until a service opts in.
 * <pre>
 * smartie:
 *   rbac:
 *     enabled: true
 *     jwt-secret: ${JWT_SECRET}
 *     internal-api-key: ${INTERNAL_API_KEY}
 *     admin-service-url: ${ADMIN_SERVICE_URL:http://localhost:8989/admin-services}
 *     public-paths: [/jobs/public/**]
 * </pre>
 */
@ConfigurationProperties(prefix = "smartie.rbac")
public class RbacProperties {

    private boolean enabled = false;
    /** Base64 HS256 secret - the same value auth-services JwtService and gateway JwtUtil use. */
    private String jwtSecret;
    /** X-Internal-Key shared with admin-services. */
    private String internalApiKey;
    private String adminServiceUrl = "http://localhost:8989/admin-services";
    /** How long a user's access is reused. A revoke reaches this service within this time. */
    private Duration cacheTtl = Duration.ofMinutes(2);
    /** While admin-services is down, one retry per user per this period; the user gets no permissions meanwhile. */
    private Duration failureTtl = Duration.ofSeconds(30);
    private int cacheMaxSize = 20_000;
    private Duration connectTimeout = Duration.ofSeconds(2);
    private Duration readTimeout = Duration.ofSeconds(3);
    /** Ant paths without authentication (login, registration, public job pages, kiosk ...). Relative to the context path. */
    private List<String> publicPaths = new ArrayList<>();

    public boolean isEnabled() { return enabled; }
    public void setEnabled(boolean enabled) { this.enabled = enabled; }
    public String getJwtSecret() { return jwtSecret; }
    public void setJwtSecret(String jwtSecret) { this.jwtSecret = jwtSecret; }
    public String getInternalApiKey() { return internalApiKey; }
    public void setInternalApiKey(String internalApiKey) { this.internalApiKey = internalApiKey; }
    public String getAdminServiceUrl() { return adminServiceUrl; }
    public void setAdminServiceUrl(String adminServiceUrl) { this.adminServiceUrl = adminServiceUrl; }
    public Duration getCacheTtl() { return cacheTtl; }
    public void setCacheTtl(Duration cacheTtl) { this.cacheTtl = cacheTtl; }
    public Duration getFailureTtl() { return failureTtl; }
    public void setFailureTtl(Duration failureTtl) { this.failureTtl = failureTtl; }
    public int getCacheMaxSize() { return cacheMaxSize; }
    public void setCacheMaxSize(int cacheMaxSize) { this.cacheMaxSize = cacheMaxSize; }
    public Duration getConnectTimeout() { return connectTimeout; }
    public void setConnectTimeout(Duration connectTimeout) { this.connectTimeout = connectTimeout; }
    public Duration getReadTimeout() { return readTimeout; }
    public void setReadTimeout(Duration readTimeout) { this.readTimeout = readTimeout; }
    public List<String> getPublicPaths() { return publicPaths; }
    public void setPublicPaths(List<String> publicPaths) { this.publicPaths = publicPaths; }
}
