package com.ags.health.hr.common.rbac;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.JwtException;
import io.jsonwebtoken.JwtParser;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.io.Decoders;
import io.jsonwebtoken.security.Keys;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.filter.OncePerRequestFilter;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * Verifies the auth-services JWT (HS256, Base64-decoded secret - same as JwtService and gateway JwtUtil),
 * loads the user's access from admin-services and exposes it as Spring authorities:
 * {@code ROLE_<role>} and {@code <OBJECT>:<ACTION>}. Works with the header the gateway forwards and with the
 * HttpOnly {@code token} cookie when a service is called directly.
 */
public class RbacAuthenticationFilter extends OncePerRequestFilter {

    private static final String[] COOKIES = {"token", "jwtToken", "authToken"};

    private final JwtParser parser;
    private final RbacAccessClient accessClient;

    public RbacAuthenticationFilter(String base64Secret, RbacAccessClient accessClient) {
        if (base64Secret == null || base64Secret.isBlank()) {
            throw new IllegalStateException("smartie.rbac.jwt-secret (env JWT_SECRET) must be set when smartie.rbac.enabled=true");
        }
        this.parser = Jwts.parserBuilder().setSigningKey(Keys.hmacShaKeyFor(Decoders.BASE64.decode(base64Secret))).build();
        this.accessClient = accessClient;
    }

    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain chain)
            throws ServletException, IOException {
        String token = token(request);
        if (token == null || SecurityContextHolder.getContext().getAuthentication() != null) {
            chain.doFilter(request, response);
            return;
        }
        Claims claims;
        try {
            claims = parser.parseClaimsJws(token).getBody();
        } catch (JwtException | IllegalArgumentException ex) {
            RbacProblemWriter.write(response, 401, "Unauthorized", "INVALID_TOKEN", "Session expired or token invalid");
            return;
        }
        String userId = claims.get("userId") == null ? null : String.valueOf(claims.get("userId"));
        String email = claims.get("email", String.class) != null ? claims.get("email", String.class) : claims.getSubject();
        String userType = claims.get("userType") == null ? null : String.valueOf(claims.get("userType"));
        String name = claims.get("userName", String.class);

        EffectiveAccess access = accessClient.resolve(userId, email, userType);
        List<GrantedAuthority> authorities = new ArrayList<>();
        if (access.active()) {
            access.roles().forEach(r -> authorities.add(new SimpleGrantedAuthority("ROLE_" + r)));
            access.permissions().forEach(p -> authorities.add(new SimpleGrantedAuthority(p)));
        }
        SecurityContextHolder.getContext().setAuthentication(new RbacAuthentication(
                new CurrentUser(userId != null ? userId : access.userId(), email, name, userType, access), authorities));
        chain.doFilter(request, response);
    }

    private static String token(HttpServletRequest request) {
        String header = request.getHeader("Authorization");
        if (header != null && !header.isBlank()) {
            return header.startsWith("Bearer ") ? header.substring(7).trim() : header.trim();
        }
        if (request.getCookies() != null) {
            for (jakarta.servlet.http.Cookie c : request.getCookies()) {
                for (String name : COOKIES) {
                    if (name.equals(c.getName()) && c.getValue() != null && !c.getValue().isBlank()) {
                        return c.getValue();
                    }
                }
            }
        }
        return null;
    }
}
