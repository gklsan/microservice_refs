package com.ags.health.hr.common.rbac;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.AutoConfiguration;
import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.autoconfigure.condition.ConditionalOnWebApplication;
import org.springframework.boot.autoconfigure.security.servlet.SecurityAutoConfiguration;
import org.springframework.boot.autoconfigure.security.servlet.UserDetailsServiceAutoConfiguration;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.http.HttpMethod;
import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;

import java.util.ArrayList;
import java.util.List;

/**
 * Opt-in RBAC for any smartie-core service (rollout one service at a time):
 * <ol>
 *   <li>add spring-boot-starter-security and jjwt (api / impl / jackson 0.11.5) to the service pom</li>
 *   <li>set smartie.rbac.enabled=true, jwt-secret, internal-api-key, admin-service-url, public-paths</li>
 *   <li>put @PreAuthorize("hasAuthority('CANDIDATE:VIEW')") on endpoints; use AccessEvaluator / ScopeFilter for records</li>
 * </ol>
 * Picked up through META-INF/spring/...AutoConfiguration.imports - the same mechanism that already loads
 * TomcatSecurityConfig, so no package scanning is needed. Does nothing unless enabled, so auth-services and
 * services without Spring Security are not affected.
 */
@AutoConfiguration(before = {SecurityAutoConfiguration.class, UserDetailsServiceAutoConfiguration.class})
@ConditionalOnWebApplication(type = ConditionalOnWebApplication.Type.SERVLET)
@ConditionalOnClass(name = {"org.springframework.security.web.SecurityFilterChain", "io.jsonwebtoken.Jwts"})
@ConditionalOnProperty(prefix = "smartie.rbac", name = "enabled", havingValue = "true")
@EnableConfigurationProperties(RbacProperties.class)
@EnableMethodSecurity
public class RbacSecurityAutoConfiguration {

    private static final List<String> ALWAYS_PUBLIC = List.of("/actuator/health/**", "/actuator/info", "/error");

    @Bean
    @ConditionalOnMissingBean
    public RbacAccessClient rbacAccessClient(RbacProperties properties,
                                             @Value("${spring.application.name:unknown}") String applicationName) {
        return new RbacAccessClient(properties, applicationName);
    }

    @Bean
    @ConditionalOnMissingBean(SecurityFilterChain.class)
    public SecurityFilterChain rbacSecurityFilterChain(HttpSecurity http, RbacProperties properties,
                                                       RbacAccessClient accessClient) throws Exception {
        List<String> publicPaths = new ArrayList<>(ALWAYS_PUBLIC);
        publicPaths.addAll(properties.getPublicPaths());
        http.csrf(c -> c.disable())
            .cors(c -> c.disable())
            .httpBasic(b -> b.disable())
            .formLogin(f -> f.disable())
            .sessionManagement(s -> s.sessionCreationPolicy(SessionCreationPolicy.STATELESS))
            .authorizeHttpRequests(auth -> auth
                    .requestMatchers(HttpMethod.OPTIONS, "/**").permitAll()
                    .requestMatchers(publicPaths.toArray(String[]::new)).permitAll()
                    .anyRequest().authenticated())
            .exceptionHandling(e -> e
                    .authenticationEntryPoint((req, res, ex) ->
                            RbacProblemWriter.write(res, 401, "Unauthorized", "UNAUTHORIZED", "Login required"))
                    .accessDeniedHandler((req, res, ex) ->
                            RbacProblemWriter.write(res, 403, "Forbidden", "ACCESS_DENIED", "You do not have permission for this action")))
            .addFilterBefore(new RbacAuthenticationFilter(properties.getJwtSecret(), accessClient),
                    UsernamePasswordAuthenticationFilter.class);
        return http.build();
    }
}
