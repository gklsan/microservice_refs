package com.ags.health.hr.common.rbac;

import java.util.HashSet;
import java.util.Set;

/**
 * List-query visibility (tracker #5 / #7): turn a user's access into a filter for SQL, JPA or Elasticsearch.
 * A record is visible when ANY of these holds:
 * <pre>
 * unrestricted
 * owner_id IN ownerIds          (me + my team)
 * assignee contains me          (panel member, assigned recruiter) - use {@link #me()}
 * id IN sharedIds               (approved override, tracker #6 / #8)
 * lob IN lobs AND (locations empty OR location IN locations)      when lobs is not empty
 * location IN locations                                            when lobs is empty and locationOnly
 * </pre>
 * Elasticsearch: a bool "should" with terms queries on the same fields and minimum_should_match 1.
 * denyAll = return an empty page without querying.
 */
public record ScopeFilter(boolean denyAll, boolean unrestricted, String me, Set<String> ownerIds,
                          Set<String> sharedIds, Set<String> lobs, Set<String> locations, boolean locationOnly) {

    public static ScopeFilter of(EffectiveAccess access, String permission, String objectType) {
        if (access == null || !access.has(permission)) {
            return new ScopeFilter(true, false, null, Set.of(), Set.of(), Set.of(), Set.of(), false);
        }
        DataScope scope = access.scope();
        String me = access.userId();
        Set<String> shared = scope.sharedIds(objectType);
        Set<String> owners = new HashSet<>();
        if (me != null) {
            owners.add(me);
        }
        if (access.isConditional(permission)) {
            // "C": only records the user owns / is assigned to / was granted - scope does not widen it
            return new ScopeFilter(false, false, me, Set.copyOf(owners), shared, Set.of(), Set.of(), false);
        }
        return switch (scope.level()) {
            case ALL -> new ScopeFilter(false, true, me, Set.of(), Set.of(), Set.of(), Set.of(), false);
            case NONE -> new ScopeFilter(true, false, me, Set.of(), Set.of(), Set.of(), Set.of(), false);
            case OWN -> new ScopeFilter(false, false, me, Set.copyOf(owners), shared, Set.of(), Set.of(), false);
            case TEAM -> {
                owners.addAll(scope.teamUserIds());
                yield new ScopeFilter(false, false, me, Set.copyOf(owners), shared, Set.of(), Set.of(), false);
            }
            case LOB -> {
                owners.addAll(scope.teamUserIds());
                yield new ScopeFilter(false, false, me, Set.copyOf(owners), shared, scope.lobs(), scope.locations(), false);
            }
            case LOCATION -> {
                owners.addAll(scope.teamUserIds());
                yield new ScopeFilter(false, false, me, Set.copyOf(owners), shared, Set.of(), scope.locations(), true);
            }
        };
    }

    /** In-memory check with the same rules (handy for tests and small lists). */
    public boolean matches(String ownerId, Set<String> assigneeIds, String objectId, String lob, String location) {
        if (denyAll) {
            return false;
        }
        if (unrestricted) {
            return true;
        }
        if (ownerId != null && ownerIds.contains(ownerId)) {
            return true;
        }
        if (me != null && assigneeIds != null && assigneeIds.contains(me)) {
            return true;
        }
        if (objectId != null && sharedIds.contains(objectId)) {
            return true;
        }
        if (!lobs.isEmpty() && lob != null && lobs.contains(lob)
                && (locations.isEmpty() || location == null || locations.contains(location))) {
            return true;
        }
        return locationOnly && location != null && locations.contains(location);
    }
}
