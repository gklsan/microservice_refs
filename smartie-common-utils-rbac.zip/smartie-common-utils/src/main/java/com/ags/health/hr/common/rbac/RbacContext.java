package com.ags.health.hr.common.rbac;

import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;

import java.util.Optional;

/**
 * The caller in service code. Always use this, never a user id from the request body.
 * <pre>
 * EffectiveAccess access = RbacContext.requireUser().access();
 * </pre>
 */
public final class RbacContext {

    private RbacContext() {
    }

    public static Optional<CurrentUser> currentUser() {
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        if (auth != null && auth.getPrincipal() instanceof CurrentUser user) {
            return Optional.of(user);
        }
        return Optional.empty();
    }

    public static CurrentUser requireUser() {
        return currentUser().orElseThrow(() -> new IllegalStateException("No authenticated user in this request"));
    }
}
