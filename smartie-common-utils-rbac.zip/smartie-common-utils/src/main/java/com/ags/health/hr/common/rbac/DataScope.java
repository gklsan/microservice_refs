package com.ags.health.hr.common.rbac;

import java.util.Collections;
import java.util.Map;
import java.util.Set;

/** Copy of admin-services' DataScope JSON contract. Unknown extra fields are ignored when reading. */
public record DataScope(ScopeLevel level, String userId, Set<String> teamUserIds, Set<String> lobs,
                        Set<String> locations, Map<String, Set<String>> sharedObjects) {

    public DataScope {
        level = level == null ? ScopeLevel.NONE : level;
        teamUserIds = teamUserIds == null ? Set.of() : Set.copyOf(teamUserIds);
        lobs = lobs == null ? Set.of() : Set.copyOf(lobs);
        locations = locations == null ? Set.of() : Set.copyOf(locations);
        sharedObjects = sharedObjects == null ? Map.of() : Map.copyOf(sharedObjects);
    }

    public static DataScope none(String userId) {
        return new DataScope(ScopeLevel.NONE, userId, Set.of(), Set.of(), Set.of(), Map.of());
    }

    public Set<String> sharedIds(String objectType) {
        return objectType == null ? Collections.emptySet() : sharedObjects.getOrDefault(objectType, Collections.emptySet());
    }
}
