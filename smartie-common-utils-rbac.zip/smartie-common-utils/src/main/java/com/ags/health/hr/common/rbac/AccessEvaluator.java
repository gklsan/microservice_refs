package com.ags.health.hr.common.rbac;



import java.util.Set;

/**
 * Record-level decision: "may this user do PERMISSION on THIS record?".
 * Evaluation order follows the RABAC overview: identity -> permission -> condition -> scope; deny wins.
 * <pre>
 * A (unconditional) : allowed on any record inside the user's data scope
 * C (conditional)   : allowed only on records the user owns or is assigned to - a wide scope does NOT help.
 *                     e.g. Recruiter CANDIDATE_PROFILE:DELETE = only candidates the recruiter owns;
 *                     Interviewer INTERVIEW:EDIT = only interviews where they are on the panel.
 * </pre>
 * Services pass ownerId (e.g. application.hr) and assigneeIds (e.g. panel member ids) from their own data.
 */
public final class AccessEvaluator {

    private AccessEvaluator() {
    }

    public record Target(String objectType, String objectId, String ownerId, Set<String> assigneeIds,
                         String lob, String location) {
        public Target {
            assigneeIds = assigneeIds == null ? Set.of() : Set.copyOf(assigneeIds);
        }

        boolean isEmpty() {
            return objectId == null && ownerId == null && assigneeIds.isEmpty() && lob == null && location == null;
        }
    }

    public record Decision(boolean allowed, String reason) {
    }

    public static Decision check(EffectiveAccess access, String permission, Target target) {
        if (access == null || !access.active()) {
            return new Decision(false, "INACTIVE_OR_UNKNOWN_USER");
        }
        if (permission == null || !access.has(permission)) {
            return new Decision(false, "MISSING_PERMISSION");
        }
        if (target == null || target.isEmpty()) {
            return new Decision(true, access.isConditional(permission) ? "PERMISSION_CONDITIONAL" : "PERMISSION");
        }
        String me = access.userId();
        boolean ownerOrAssignee = me != null && (me.equals(target.ownerId()) || target.assigneeIds().contains(me));
        if (!ownerOrAssignee && target.objectId() != null
                && access.scope().sharedIds(target.objectType()).contains(target.objectId())) {
            return new Decision(true, "SHARED_BY_APPROVAL");   // BRD 4.3 "shared via approved workflows"
        }
        if (access.isConditional(permission)) {
            return ownerOrAssignee
                    ? new Decision(true, "CONDITION_OWNER_OR_ASSIGNEE")
                    : new Decision(false, "CONDITION_NOT_MET");
        }
        if (ownerOrAssignee) {
            return new Decision(true, "OWNER_OR_ASSIGNEE");
        }
        DataScope scope = access.scope();
        ScopeLevel level = scope.level();
        if (level == ScopeLevel.ALL) {
            return new Decision(true, "SCOPE_ALL");
        }
        if (level == ScopeLevel.NONE || level == ScopeLevel.OWN) {
            return new Decision(false, "OUT_OF_SCOPE");
        }
        if (target.ownerId() != null && scope.teamUserIds().contains(target.ownerId())) {
            return new Decision(true, "SCOPE_TEAM");
        }
        if (level == ScopeLevel.LOB && target.lob() != null && scope.lobs().contains(target.lob())
                && (scope.locations().isEmpty() || target.location() == null || scope.locations().contains(target.location()))) {
            return new Decision(true, "SCOPE_LOB");
        }
        if (level == ScopeLevel.LOCATION && target.location() != null && scope.locations().contains(target.location())) {
            return new Decision(true, "SCOPE_LOCATION");
        }
        return new Decision(false, "OUT_OF_SCOPE");
    }
}
