package com.ags.health.hr.common.rbac;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import java.util.Set;
import java.util.UUID;

/** What a user can do - the answer of admin-services GET /internal/rbac/effective. */
@JsonIgnoreProperties(ignoreUnknown = true)
public record EffectiveAccess(String userId,
                              UUID adminUserId,
                              String email,
                              boolean active,
                              boolean configured,
                              Set<String> roles,
                              Set<String> permissions,
                              Set<String> conditionalPermissions,
                              DataScope scope) {

    public EffectiveAccess {
        roles = roles == null ? Set.of() : Set.copyOf(roles);
        permissions = permissions == null ? Set.of() : Set.copyOf(permissions);
        conditionalPermissions = conditionalPermissions == null ? Set.of() : Set.copyOf(conditionalPermissions);
        scope = scope == null ? DataScope.none(userId) : scope;
    }

    /** Used when admin-services can not be reached: identity is known, nothing is allowed (fail closed). */
    public static EffectiveAccess nothing(String userId, String email) {
        return new EffectiveAccess(userId, null, email, true, false, Set.of(), Set.of(), Set.of(), DataScope.none(userId));
    }

    public boolean has(String permission) {
        return active && permissions.contains(permission);
    }

    public boolean isConditional(String permission) {
        return conditionalPermissions.contains(permission);
    }

    public boolean hasRole(String role) {
        return active && roles.contains(role);
    }
}
