package com.ags.health.hr.common.rbac;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.client.SimpleClientHttpRequestFactory;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import java.net.URI;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Asks admin-services "what can this user do?" and keeps the answer for cacheTtl (default 2 minutes).
 * Fail closed: if admin-services is unreachable the user keeps the identity but gets no role and no
 * permission, so protected endpoints answer 403 - never a silent allow.
 */
public class RbacAccessClient {

    private static final Logger log = LoggerFactory.getLogger(RbacAccessClient.class);

    private record Entry(EffectiveAccess access, long expiresAt) {
    }

    private final RbacProperties properties;
    private final String callerService;
    private final RestTemplate rest;
    private final Map<String, Entry> cache = new ConcurrentHashMap<>();

    public RbacAccessClient(RbacProperties properties, String callerService) {
        this.properties = properties;
        this.callerService = callerService;
        SimpleClientHttpRequestFactory factory = new SimpleClientHttpRequestFactory();
        factory.setConnectTimeout((int) properties.getConnectTimeout().toMillis());
        factory.setReadTimeout((int) properties.getReadTimeout().toMillis());
        this.rest = new RestTemplate(factory);
    }

    public EffectiveAccess resolve(String userId, String email, String userType) {
        String key = Objects.toString(userId, "") + "|" + Objects.toString(email, "").toLowerCase();
        long now = System.currentTimeMillis();
        Entry hit = cache.get(key);
        if (hit != null && hit.expiresAt() > now) {
            return hit.access();
        }
        try {
            URI url = UriComponentsBuilder.fromUriString(properties.getAdminServiceUrl())
                    .path("/internal/rbac/effective")
                    .queryParam("userId", "{userId}")
                    .queryParam("email", "{email}")
                    .queryParam("userType", "{userType}")
                    .encode()
                    .buildAndExpand(Objects.toString(userId, ""), Objects.toString(email, ""), Objects.toString(userType, ""))
                    .toUri();
            HttpHeaders headers = new HttpHeaders();
            headers.set("X-Internal-Key", properties.getInternalApiKey());
            headers.set("X-Caller-Service", callerService);
            EffectiveAccess access = rest.exchange(url, HttpMethod.GET, new HttpEntity<>(headers), EffectiveAccess.class).getBody();
            if (access != null) {
                put(key, access, now + properties.getCacheTtl().toMillis());
                return access;
            }
        } catch (RuntimeException ex) {
            log.warn("admin-services unreachable - user {} gets no permissions for {}: {}", email,
                    properties.getFailureTtl(), ex.getMessage());
        }
        EffectiveAccess nothing = EffectiveAccess.nothing(userId, email);
        put(key, nothing, now + properties.getFailureTtl().toMillis());
        return nothing;
    }

    /** Drop everything (e.g. from an admin "refresh" endpoint). */
    public void evictAll() {
        cache.clear();
    }

    private void put(String key, EffectiveAccess access, long expiresAt) {
        if (cache.size() >= properties.getCacheMaxSize()) {
            long now = System.currentTimeMillis();
            cache.entrySet().removeIf(e -> e.getValue().expiresAt() <= now);
            if (cache.size() >= properties.getCacheMaxSize()) {
                cache.clear();
            }
        }
        cache.put(key, new Entry(access, expiresAt));
    }
}
