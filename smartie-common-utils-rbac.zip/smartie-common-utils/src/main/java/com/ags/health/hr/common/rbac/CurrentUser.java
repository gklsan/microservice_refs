package com.ags.health.hr.common.rbac;

/** Authenticated caller: identity from the verified JWT + access from admin-services. */
public record CurrentUser(String userId, String email, String name, String userType, EffectiveAccess access) {
}
