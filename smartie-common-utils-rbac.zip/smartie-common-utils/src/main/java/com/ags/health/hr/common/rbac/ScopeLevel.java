package com.ags.health.hr.common.rbac;

/** Row-level visibility, narrowest to widest. Same values as admin-services. */
public enum ScopeLevel { NONE, OWN, TEAM, LOB, LOCATION, ALL }
