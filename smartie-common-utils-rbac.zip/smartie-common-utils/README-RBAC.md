# smartie-common-utils - RBAC client (opt-in)

New package `com.ags.health.hr.common.rbac`. Off by default: adding it to the library changes nothing for any
service until that service sets `smartie.rbac.enabled=true`.

## 1. Library pom (smartie-common-utils/pom.xml) - add, all optional

```xml
<dependency>
  <groupId>org.springframework.boot</groupId>
  <artifactId>spring-boot-starter-security</artifactId>
  <version>3.1.1</version>
  <optional>true</optional>
</dependency>
<dependency>
  <groupId>org.springframework.boot</groupId>
  <artifactId>spring-boot-starter-web</artifactId>
  <version>3.1.1</version>
  <optional>true</optional>
</dependency>
<dependency>
  <groupId>io.jsonwebtoken</groupId>
  <artifactId>jjwt-api</artifactId>
  <version>0.11.5</version>
  <optional>true</optional>
</dependency>
```

`optional` = not pulled into services that do not ask for it. The existing `TomcatSecurityConfig` line stays in
`META-INF/spring/org.springframework.boot.autoconfigure.AutoConfiguration.imports`; the RBAC line is added below it.

## 2. Service that opts in (e.g. job-services first)

pom:

```xml
<dependency><groupId>org.springframework.boot</groupId><artifactId>spring-boot-starter-security</artifactId></dependency>
<dependency><groupId>io.jsonwebtoken</groupId><artifactId>jjwt-api</artifactId><version>0.11.5</version></dependency>
<dependency><groupId>io.jsonwebtoken</groupId><artifactId>jjwt-impl</artifactId><version>0.11.5</version><scope>runtime</scope></dependency>
<dependency><groupId>io.jsonwebtoken</groupId><artifactId>jjwt-jackson</artifactId><version>0.11.5</version><scope>runtime</scope></dependency>
```

application.yml:

```yaml
smartie:
  rbac:
    enabled: ${RBAC_ENABLED:true}
    jwt-secret: ${JWT_SECRET}
    internal-api-key: ${INTERNAL_API_KEY}
    admin-service-url: ${ADMIN_SERVICE_URL:http://localhost:8989/admin-services}
    cache-ttl: 2m
    public-paths:            # everything that must work without login - check each service
      - /jobs/seo/**
```

Controller:

```java
@GetMapping("/candidates/{id}")
@PreAuthorize("hasAuthority('CANDIDATE:VIEW')")
public CandidateDto get(@PathVariable UUID id) {
    Candidate c = service.find(id);
    EffectiveAccess access = RbacContext.requireUser().access();
    AccessEvaluator.Decision d = AccessEvaluator.check(access, "CANDIDATE:VIEW",
            new AccessEvaluator.Target("CANDIDATE", id.toString(), c.getHrId(), Set.of(), c.getLob(), c.getLocation()));
    if (!d.allowed()) throw new APIException("FORBIDDEN", d.reason());
    return CandidateDto.of(c);
}
```

List screens (tracker #5 / #7):

```java
ScopeFilter f = ScopeFilter.of(RbacContext.requireUser().access(), "CANDIDATE:VIEW", "CANDIDATE");
if (f.denyAll()) return Page.empty();
if (!f.unrestricted()) {
    // Elasticsearch: bool.should( terms(hrId, f.ownerIds()), terms(panelIds, [f.me()]), terms(_id, f.sharedIds()),
    //                             terms(lob, f.lobs()) [+ filter terms(location, f.locations())] ), minimum_should_match 1
}
```

## 3. Rollout order

1. Library first (this change), `RBAC_ENABLED=false` everywhere.
2. job-services -> candidate-services -> vendor-services, one per deploy. For each: list public paths,
   add `@PreAuthorize` to every endpoint, copy `EndpointSecurityTest` from admin-services, then flip `RBAC_ENABLED`.
3. Record-level checks (AccessEvaluator / ScopeFilter) per screen.

Notes

- A change in admin-services reaches a service within `cache-ttl` (2 minutes). Deactivation is immediate in admin-services.
- If admin-services is down the user gets no permissions for 30 seconds, then it retries (fail closed, never fail open).
- auth-services keeps its own security config and must NOT enable this (login / register are public).
