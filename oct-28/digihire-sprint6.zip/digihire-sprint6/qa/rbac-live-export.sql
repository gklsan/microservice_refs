SELECT p.code AS permission, r.code AS role, CASE WHEN rp.conditional THEN 'C' ELSE 'Y' END AS grant_type
FROM adm_role_permission rp
JOIN adm_role r ON r.id = rp.role_id
JOIN adm_permission p ON p.code = rp.permission_code
ORDER BY p.code, r.code;
