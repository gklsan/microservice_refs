# Sprint 6 regression suite

This suite covers tasks S6-18 to S6-23: end-to-end, integration, RBAC, rule, audit and performance regression. Run it on UAT with masked production-like data (DEP-S6-07) after every build that goes to UAT, and in full before the go-live decision.

Record results in the `Result` column of `rbac-regression-matrix.xlsx` for RBAC, and in your test management tool for the rest, using the IDs below.

## Entry criteria

- The build is deployed to UAT through the pipeline, and `/internal/readiness` returns 200 on candidate-services and job-services.
- The report facts were rebuilt for the UAT data (`POST /reports/facts/rebuild` with the date range of the copy).
- Test users exist for every role: Recruiter, Recruitment Manager (TL), TA Head, Interviewer, Vendor, Super Admin.

## End-to-end: sourcing to onboarding (S6-18)

| ID | Scenario | Steps | Expected |
| :--- | :--- | :--- | :--- |
| E2E-01 | Direct walk-in to joined | Register candidate, Map (S1), walk-in, HR round select, assessment pass, panel select, offer push, Oracle accept, joined | Every tab move succeeds; funnel shows the candidate at each stage; 1 audit row per move |
| E2E-02 | Online interview path | Map, schedule online interview, Teams link sent, HR feedback, move to assessment | Meeting link in the email; HR feedback stored; Versant triggered for Versant roles |
| E2E-03 | Rejection at HR round | Map, HR round reject with standard reason | Candidate in Rejected tab at once; rejection email with template; funnel drop at HR_ROUND |
| E2E-04 | On hold when no openings | Map against a requisition with 0 available | Application in Pipeline with reason NO_OPENINGS; On Hold email |
| E2E-05 | Re-map scenarios | Run all 6 re-map scenarios from README section 13 | Stage kept or restarted exactly as the table says; locked stages refused |
| E2E-06 | Vendor sourced candidate | Vendor submits candidate on a task, recruiter maps, candidate joins | Vendor link carries the application; vendor report counts 1 joined |
| E2E-07 | Offer rejected by candidate | Push offer, Oracle reports rejected | Application back in SHORTLISTED with notification |
| E2E-08 | Bulk movement | Excel upload of 50 rows to PIPELINE with 3 bad rows | 47 moved, 3 failed with row-level reasons; bulk job visible |
| E2E-09 | Requisition upload | TL uploads 10 CREATE and 5 UPDATE rows | Created requisitions visible in Job Listing; Oracle-owned field changes refused per row |
| E2E-10 | Dashboard to drill-down | TA Head opens dashboard, clicks every widget bucket | Each drill list matches the bucket count |

## Integration regression (S6-19)

| ID | Integration | Check | Expected |
| :--- | :--- | :--- | :--- |
| INT-01 | Oracle requisitions | Full sync, then incremental sync after a change in Oracle | Changed requisition updated within 15 minutes; watermark moves only after a clean run |
| INT-02 | Oracle requisitions | Expired or closed requisition in Oracle | Job hidden from mapping and unpublished from Career Page and Buddy Finder |
| INT-03 | Oracle offer | Push offer with a missing mandatory field | 422 with field errors; nothing sent to Oracle |
| INT-04 | Oracle offer | Oracle unavailable during push | Retries with backoff; parked after 8 attempts; admin retry works |
| INT-05 | Oracle status | Callback with a bad signature | Rejected and logged; no status change |
| INT-06 | SHL | Result callback with wrong credentials or malformed XML | Rejected with 401; no score stored (fix from the 22-Oct review) |
| INT-07 | SHL | Valid result callback | Score stored; 60-day validity applied; next stage routing correct |
| INT-08 | Versant | Not taken, link expired, invite failed | Exception created with the right type and visible to HR |
| INT-09 | ID verification | Verify PAN and Aadhaar; provider down | Badge VERIFIED; on outage the request stays queued and retries |
| INT-10 | Face match | Kiosk photo below the review threshold | Feedback blocked unless an override reason is given |
| INT-11 | Email | Every template in P5-S1 rows 15 to 18 | Placeholders filled; SPF/DKIM pass |
| INT-12 | Requisition push | Change openings on an Oracle requisition with push in REST mode | Oracle updated first, then DigiHire; in STUB mode the row stays PENDING_PUSH |

## RBAC and permission regression (S6-20)

Use `rbac-regression-matrix.xlsx`.

- **Role x permission sheet:** compare the live grants with the expected ones. Run `rbac-live-export.sql` on UAT and diff it against the `Y` and `C` cells. Every difference is a defect or an approved change.
- **Sprint 6 endpoints sheet:** call each endpoint with a token for each role and compare the HTTP status with the expected value.
- **Scope checks:** these apply to every list endpoint, Sprint 3 to 6.
  - A recruiter sees only their own records.
  - A Recruitment Manager sees their team.
  - LOB-scoped users see their LOBs only.
  - A record outside scope returns 403, or is absent from lists.
- **Self-approval:** a user can never approve their own request. This covers JD edit, vendor onboarding, access requests and technical reschedule.

## Rule verification (S6-21)

| ID | Rule | Case | Expected |
| :--- | :--- | :--- | :--- |
| RULE-01 | SHL cooling | Fail attempt 1, try again on day 6 and on day 7 | Day 6 refused with cooling date; day 7 allowed (7/30/180 ladder) |
| RULE-02 | SHL cooling | Third failure | Next attempt only after 180 days |
| RULE-03 | Versant cooling | Same as RULE-01 with 15/45/180 | As configured |
| RULE-04 | 60-day score validity | Score taken 61 days ago, candidate re-applies | Expired score; candidate routed to Fresher Pipeline or re-assessment |
| RULE-05 | ORC restriction | Panel rejects candidate for ORC X; map again to ORC X on day 59 and on day 61 | Day 59 refused with ORC_RESTRICTED; day 61 allowed |
| RULE-06 | ORC change | Same-panel and different-panel ORC change | Outcome kept for same panel; new round for a different panel |
| RULE-07 | Voice Fresher Chennai | Rejected Voice Fresher in Chennai maps to another Voice Fresher role in Chennai | Refused with VOICE_FRESHER_RESTRICTED |
| RULE-08 | Technical reschedule | First reschedule request by HR | Goes to the approver; HR can not approve their own request |
| RULE-09 | Registration gate | Map a candidate with incomplete registration | Refused with REGISTRATION_INCOMPLETE; invite sent |
| RULE-10 | Field lock | Change PAN after applicant creation without UPDATE_LOCKED | Refused; with the permission and a reason it is allowed and audited |

## Audit completeness (S6-22, NFR5)

- Run `POST /reports/quality/audit-completeness` for every UAT test day. It must report status `PASS` with `missing = 0`.
- Spot-check the audit viewer for 10 records each. Records: application moves, ID document reveal, report export, requisition upload, approval decisions, secret reveal.
- No PII appears in the logs: grep the UAT log files for PAN, Aadhaar and mobile patterns.

## Report accuracy (S6-9, target 99% or better)

- Run `POST /reports/quality/accuracy` with `repair=false` for the UAT date range. The score must be 99.0 or higher.
- Pick 20 random applications from the funnel drill-down and compare stage, recruiter and dates with the Applicant screen.
- Compare the recruiter report totals with a manual count for two recruiters.

## Performance re-test (S6-23, NFR1 and NFR4)

Scripts are in `perf/k6`.

- **Load:**
  - `dashboard.js` at 60 virtual users and `worklist.js` at 150.
  - `map-candidate.js` at 80.
  - All three run together on the 5x data set seeded by `perf/seed`.
  - Pass: p95 under 3 s, error rate under 0.5%.
- **Soak:** `soak.js` for 4 hours at 20 requests per second. Pass: no error spikes, no memory growth in the service metrics, and readiness stays `PASS`.
- **Uptime:** record the readiness probe every minute during UAT. Target 99.5% or better.

## Exit criteria

- No open Sev1 or Sev2 defects (see `docs/defect-triage.md`).
- 100% of RBAC rows and Sprint 6 endpoint rows executed. Every failure is fixed or has an approved exception.
- Report accuracy is 99% or better, and audit completeness has no missing rows.
- Performance thresholds are met on the 5x data set.
