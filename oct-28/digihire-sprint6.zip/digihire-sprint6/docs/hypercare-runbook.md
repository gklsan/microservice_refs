# Hypercare runbook (S6-27)

Hypercare runs for 2 weeks after go-live: 08:00 to 22:00 IST on working days, with an on-call engineer outside those hours for Sev1. The roster and the escalation matrix are in DEP-S6-13.

## Daily routine

| Time | Task | Tool |
| :--- | :--- | :--- |
| 08:30 | Readiness on candidate-services and job-services; note any WARN or FAIL | `GET /ops/readiness` |
| 08:45 | Overnight jobs: requisition sync, accuracy check, audit completeness | `GET /requisition-sync/runs`, `GET /reports/quality/accuracy`, `GET /reports/quality/audit-completeness` |
| 09:00 | Parked outbox events and integration failures; retry or raise | `GET /call-log`, `POST /offers/{id}/retry`, outbox stats |
| 09:15 | Defect triage call (see `defect-triage.md`) | Defect tracker |
| 13:00 | Error rate and p95 latency per service | Monitoring |
| 17:30 | Daily status note to TA Head: defects opened / closed, incidents, data fixes | Email |

## Common issues

| Symptom | Likely cause | Action |
| :--- | :--- | :--- |
| Dashboard numbers look wrong for one application | Fact not updated after a move | `POST /reports/facts/rebuild` with the application id; check `report-dirty` in readiness |
| Dashboard numbers wrong for many applications | Projection failing | Check logs for `REPORT_FACT_PROJECTION_FAILED`; fix the cause, then rebuild the date range |
| Readiness `report-accuracy` FAIL | Facts drifted from the source | Run accuracy with `repair=true` for the range; open a defect with the sample ids |
| Readiness `audit-completeness` FAIL | A status change path is not audited | Take the sample ids, find the code path, raise Sev2 |
| User gets 409 STALE_STATUS | Someone else moved the application first | Expected; the user refreshes and retries |
| User gets 409 REQUEST_IN_PROGRESS | Double click or a slow first request with the same Idempotency-Key | Wait a few seconds and retry |
| Requisition upload rows PENDING_PUSH | Oracle push not configured or Oracle down | Check `oracle-push` readiness; re-upload the rows once Oracle is up |
| Requisitions not updating | Oracle sync failing | `GET /requisition-sync/runs` and failures; retry; check credentials |
| Offer stuck | Oracle offer API failing | `GET /call-log`; retry from the offers screen |
| Login loop for one role | Missing permission or stale RBAC cache | Check grants against the RBAC matrix; cache expires in 60 s |

## Incident handling

1. Open an incident with the severity from `defect-triage.md`.
2. For Sev1: page the on-call engineer and inform the TA Head within 15 minutes.
3. Contain the issue: disable the feature flag if one exists (`digihire.s6.*.enabled`, `digihire.*.jobs-enabled`), or roll back the service.
4. Fix, deploy through the pipeline with an expedited approval, and verify.
5. Write a short incident note within 2 working days: cause, impact, fix, and prevention.

## Exit criteria

- No Sev1 or Sev2 open for 5 working days.
- Readiness PASS every day for 5 days.
- Accuracy and audit checks PASS every night for 5 nights.
- Hand-over of open Sev3 and Sev4 items to the support team.
