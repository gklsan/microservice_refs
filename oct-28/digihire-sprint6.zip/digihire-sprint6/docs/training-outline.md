# Training outline (S6-25)

Each session is 60 to 90 minutes, hands-on in the training environment (DEP-S6-12), with a one-page quick reference card per role. Trainees use their own role logins so they see their real scope.

## Recruiter

| Module | Covers |
| :--- | :--- |
| Map Candidate | Search by email or mobile, the six mapping scenarios, Tag & Map, On Hold, blockers (cooling, ORC, Voice Fresher, blacklist) |
| Applicant tabs | Worklist paging and filters, moving stages, remarks rules, reject with reason, walk-in and online scheduling |
| Profile | Mandatory fields, locked fields after applicant creation, secure PDF |
| Assessments | Versant and SHL status, exceptions, reschedule request (approval from the first attempt) |
| HR round | Online and in-office modes, screenshot and kiosk photo, competency feedback |
| Dashboard | My pipeline, aging, moves today, drill-down |

## Recruitment Manager (TL)

All Recruiter modules, plus:

| Module | Covers |
| :--- | :--- |
| Team view | Team dashboard, recruiter performance report, reassigning work |
| Bulk actions | Bulk status update by selection and by Excel, reading the result file |
| Requisitions | Requisition upload template, CREATE and UPDATE rows, dry run, Oracle-owned fields, PENDING_PUSH |
| Reports | Funnel with breakdowns, exports and their audit |
| Approvals | Vendor onboarding level 1, technical reschedule approvals |

## TA Head

All Recruitment Manager modules, plus:

| Module | Covers |
| :--- | :--- |
| Governance | JD edit approvals, vendor approvals, ID document reveal rules, panel decisions |
| Reports | Vendor performance, report accuracy and audit completeness checks, readiness page |
| Access | Reading the RBAC matrix; HR tag change permission; what to ask Admin for |

## Interviewer / Panelist

| Module | Covers |
| :--- | :--- |
| Panel | Schedule view, photo verification, decision (Select / Reject / Hold), recording upload |

## Vendor

| Module | Covers |
| :--- | :--- |
| Registration | Invitation link, documents, agreement, status of approval |
| Tasks | Task limits, submitting candidates, 90-day ownership, status updates |

## Super Admin

| Module | Covers |
| :--- | :--- |
| Users and roles | Add User from Smartie users, role and permission grants, deactivation |
| Configuration | Approval flows, secrets, enterprise configuration, audit log viewer |
| Operations | Readiness page, report fact rebuild, what to check during hypercare |

## Materials

- Quick reference card per role, 1 page, with screenshots from the training environment.
- Short screen recordings (3 to 5 minutes) for Map Candidate, bulk upload, requisition upload and reports.
- A FAQ built from UAT defects and hypercare tickets, updated weekly.
