# Defect triage (S6-16, S6-17)

Triage runs daily during UAT and hypercare. The attendees are the QA lead, the dev lead, a TA representative and the PM.

## Severity

| Severity | Definition | Examples | Response | Fix target |
| :--- | :--- | :--- | :--- | :--- |
| Sev1 | Production down or data loss / security exposure; no workaround | Login down for all users; PII exposed; wrong candidate status at scale | 15 min | Same day (hotfix) |
| Sev2 | Core flow blocked for a role or a site; workaround is costly | Mapping fails for one LOB; offers not reaching Oracle; reports wrong for TA Head | 1 h | 2 working days |
| Sev3 | Feature wrong but a reasonable workaround exists | Export column order wrong; one filter ignored | 1 day | Next planned release |
| Sev4 | Cosmetic or minor | Label text, alignment | 2 days | Backlog |

## Rules

- **Exit gates:** Sev1 and Sev2 must be closed before go-live and before hypercare exit.
- **Security:** a security finding is at least Sev2, and Sev1 if it is exploitable without login.
- **Wrong numbers:** a wrong number in a report counts as Sev2 when it drives a hiring decision (funnel, recruiter or vendor performance). Otherwise it is Sev3.
- **Reproduction:** every defect needs steps, the expected and actual result, the user role, and the record id. The record id lets the dev team rebuild facts or check audit rows.
- **Re-test:** a fixed defect is re-tested by QA on UAT and closed only by QA.

## Known items carried into Sprint 6

The 22-Oct code review on the Sprint 2 branch is the starting list for "known defect fixes across existing flows" (S6-17). Its Critical and High findings are tracked in P5-S3 rows 33 to 35 of the tracker:

- SHL webhook authentication.
- The internal-key fallback.
- The OTP bypass profile.
- OTP and JWT values in logs.
- The gateway path match.
- Self-approval.
- The Bootstrap SRI hash.
- The SHL iframe allowlist.
- JWT rotation.
- First-attempt approval for technical reschedule.

Re-test them as part of the regression suite.
