# Go-live readiness checklist (S6-26)

Every item needs an owner and evidence before the go / no-go call. The automated checks come from `GET /ops/readiness` on candidate-services and job-services. Attach both JSON reports to the change request.

## Automated (readiness endpoint)

| Check | Service | Pass condition |
| :--- | :--- | :--- |
| database, schema | both | Database reachable; all Sprint 3 to 6 tables present |
| jwt-secret, internal-key, kek-keys | both | Set in the production secret store, not in files |
| document-storage | candidate | Mode is S3, not MEMORY |
| service-urls | candidate | No service URL points to localhost |
| outbox-backlog, outbox-parked | candidate | Backlog under 200; nothing parked |
| report-dirty | candidate | Under 50 facts waiting for rebuild |
| report-accuracy | candidate | Last run within 48 h, status PASS (99% or better) |
| audit-completeness | candidate | Last run within 48 h, no missing rows |
| oracle-requisitions | job | Mode is REST |
| last-sync, sync-parked | job | Last requisition sync within 60 minutes and not FAILED; nothing parked |

## Manual

| Area | Item | Owner | Evidence |
| :--- | :--- | :--- | :--- |
| Security | All Critical and High findings from the 22-Oct code review closed and re-tested | Dev lead | Review sign-off |
| Security | JWT secret rotated; old secret removed from every environment | AGS Security | Rotation record |
| Security | VAPT re-test passed on the release build | AGS Security | VAPT report |
| Security | OTP bypass list empty in production profile | Dev lead | Config screenshot |
| Data | Masters loaded: roles, LOB, location, rejection reasons, competencies, ORC / panel, interview slots, vendor master | TA Ops | Row counts |
| Data | Report facts built for history (`POST /reports/facts/rebuild` by month) and accuracy PASS | Dev lead | Check run ids |
| Data | Database indexes applied (`db-tuning/legacy-indexes-pg.sql`) and ANALYZE done | DBA | Script output |
| Integrations | Production credentials for Oracle, Versant, SHL, ID verification, email in the secret store | AGS IT | Readiness PASS |
| Integrations | Oracle callback URL and signature secret registered | Oracle team | Test callback |
| RBAC | Production role grants match `qa/rbac-regression-matrix.xlsx` | TA Head | Diff output |
| Quality | Regression suite exit criteria met | QA lead | Test summary |
| Quality | Performance re-test passed on 5x data | QA lead | k6 summaries |
| Operations | Monitoring dashboards and alerts on readiness, error rate, latency and outbox backlog | AGS IT | Alert test |
| Operations | Backups verified with a test restore in the last 7 days | DBA | Restore log |
| Operations | Rollback package of the previous release ready | DevOps | Artifact ids |
| People | UAT sign-off by TA Head | TA Head | Signed form |
| People | Training complete for all roles; quick reference cards published | L&D | Attendance |
| People | Hypercare roster and escalation matrix shared | PM | Roster |
| Governance | CAB approval and downtime window agreed (DEP-S6-10, DEP-S6-11) | AGS IT Governance | CAB ticket |

## Go / no-go rule

Go only if every automated check is PASS in production and every manual item has evidence. One WARN is allowed if the owner and the TA Head accept it in writing. Any FAIL is a no-go.
