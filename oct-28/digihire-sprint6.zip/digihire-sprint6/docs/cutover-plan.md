# Cutover plan (S6-26, S6-27)

The plan assumes a Saturday evening window of 4 hours, IST. Times are offsets from the start of the window (T). Move the window only through CAB.

## T-7 days to T-1 day

| When | Step | Owner |
| :--- | :--- | :--- |
| T-7d | Freeze code for the release; tag the release candidate | Dev lead |
| T-7d | Final UAT regression on the release candidate | QA lead |
| T-5d | CAB approval; send downtime notice to TA, HR and vendors | PM |
| T-3d | Load production masters; rehearse cutover on a production copy, timing every step | DevOps, DBA |
| T-2d | Confirm production secrets and integration endpoints; run readiness on the rehearsal copy | AGS IT |
| T-1d | Go / no-go meeting with the checklist in `go-live-checklist.md` | TA Head, PM |

## Cutover window

| When | Step | Check | Owner |
| :--- | :--- | :--- | :--- |
| T+0:00 | Put the UI in maintenance mode; stop schedulers (`digihire.*.jobs-enabled=false`) | Banner visible | DevOps |
| T+0:10 | Database backup and snapshot | Backup id recorded | DBA |
| T+0:30 | Apply database changes: Sprint 3 to 6 schema scripts (idempotent), admin seeds, `legacy-indexes-pg.sql` | Script logs clean | DBA |
| T+1:00 | Deploy services in order: common-utils based builds of discovery, gateway, admin, auth, job, assessment, integration, candidate, vendor, notification, workflow | All instances healthy | DevOps |
| T+1:30 | Deploy the frontend bundle | Version shown in the footer | DevOps |
| T+1:40 | Run readiness on both services | Overall PASS | Dev lead |
| T+1:50 | Rebuild report facts for the last 180 days, one month per call | Result counts logged | Dev lead |
| T+2:30 | Accuracy check for the rebuilt range; audit completeness for yesterday | Both PASS | Dev lead |
| T+2:45 | Smoke test with real users: login per role, map one test candidate, move one stage, open dashboard, export a report, upload one requisition row (dry run) | All pass | QA lead, TA users |
| T+3:15 | Enable schedulers; trigger an Oracle requisition sync | Sync SUCCESS | DevOps |
| T+3:30 | Remove maintenance mode; announce go-live | Users can log in | PM |

## Rollback

Decide by T+3:00. Roll back if any smoke test fails and can not be fixed within 15 minutes, or if readiness is FAIL.

1. Put the UI back in maintenance mode.
2. Redeploy the previous release artifacts.
3. The Sprint 3 to 6 tables are additive, so the old release ignores them. Restore the snapshot only if a legacy table was changed.
4. Run readiness and the smoke test on the old release.
5. Send the rollback notice and book a new window through CAB.
