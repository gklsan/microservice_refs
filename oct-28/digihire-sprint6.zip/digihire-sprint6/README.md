# DigiHire Phase 5: Sprint 6 (Dashboard, Optimization, Stabilization, Go-Live)

This package adds Sprint 6 (weeks 21-22, 30-Nov to 11-Dec-2026) on top of the Sprint 3-5 package. It follows the same placement pattern:

- one feature per package
- ports for anything legacy
- JdbcTemplate stores and one `XxxConfig` per feature
- no edits to existing classes

Every file is new. No Sprint 1-5 file is changed.

| Area | What you get |
| :--- | :--- |
| Dashboard and reporting (S6-1 to S6-9) | A reporting read model fed by `StatusMover`. It provides the dashboard with drill-down, filter options, hiring funnel, recruiter and vendor performance, Excel / CSV / PDF export, and an accuracy check with self-repair. |
| Requisition upload / modify (S6-8) | TL-and-above create and update of requisitions, by form or Excel / CSV upload. Oracle-owned fields are protected, and changes are pushed to the Oracle Jobs API. |
| Optimization (S6-10 to S6-15) | Keyset-paged applicant worklist, batch Map Candidate checks with a requisition cache, a dashboard cache, legacy index script, row lock and stale-status guard, idempotency keys, and a 5x volume seed with k6 scripts. |
| Stabilization (S6-16 to S6-27) | RBAC regression matrix, regression suite, audit completeness check, readiness endpoints, go-live checklist, cutover plan, hypercare runbook, defect triage, training outline. |

Size:

- 88 main classes (about 6,700 lines) and 7 test classes (about 1,000 lines).
- 3 SQL schema / seed files and 2 database tuning scripts.
- 4 k6 scripts and a volume seed.
- QA and go-live documents.

---

## 1. Before you start

Sprint 6 builds on the Sprint 3-5 classes (`StatusMover`, `StageCatalog`, ports, `common.platform`). Integrate in this order:

1. Close the Sprint 2 review fixes and rebase. These are tracker rows P5-S3 33 to 37 and DEP-S3-11 to DEP-S3-15.
2. Drop in Sprint 3-5 as its README describes.
3. Drop in this package.

The reporting projection listens to `StatusMover`. Moves made by legacy code that bypasses `StatusMover` are not seen until the nightly accuracy job repairs them, or until you point `ReportSourcePort` at the legacy tables (section 5).

---

## 2. Where every folder goes

| Package folder | Goes to | Notes |
| :--- | :--- | :--- |
| `smartie-common-utils/.../common/platform/export` | same path | `ReportTable`, `XlsxReportWriter`, `XlsxSheetReader`, `CsvReportWriter`, `CellSafety`. Pure Java; no POI needed to write or read .xlsx |
| `smartie-common-utils/.../common/platform/cache` | same path | `TtlCache` with single-flight loading |
| `smartie-common-utils/.../common/platform/concurrency` | same path | `IdempotencyStore`, `IdempotentExecutor` |
| `smartie-common-utils/.../common/platform/readiness` | same path | `ReadinessService`, `ReadinessCheck`, `Checks` |
| `smartie-common-utils/.../common/platform/db/JdbcValues.java` | same path | Timestamp / OffsetDateTime normalisation (H2 vs PostgreSQL) |
| `candidate-services/.../candidates/s6shared` | same path | `CandidateS6Properties` (`digihire.s6.*`), `CandidateS6Config` (schema), `S6Permissions`, `S6ExceptionAdvice` |
| `candidate-services/.../candidates/reporting` | same path | `domain`, `port`, `client`, `store`, `service`, `web`, `ReportingConfig` |
| `candidate-services/.../candidates/worklist` | same path | Applicant worklist, batch Map Candidate checks, requisition cache |
| `candidate-services/.../candidates/concurrency` | same path | `ApplicationMutexGuard` (a `MoveGuard`), `IdempotencyFilter` |
| `candidate-services/.../candidates/ops` | same path | Readiness checks and `/ops/readiness` |
| `candidate-services/src/main/resources/db/p6` | same path | `candidate-p6-schema.sql` |
| `job-services/.../jobs/requisition` | same path | Upload / modify service, file reader, Oracle push port, override sink, config |
| `job-services/.../jobs/ops` | same path | Readiness for job-services |
| `job-services/src/main/resources/db/p6` | same path | `job-p6-schema.sql` |
| `vendor-services/.../vendor/directory` | same path | Internal vendor names and application links for reports |
| `admin-services/src/main/resources/db/data-admin-sprint6.sql` | same path | Permissions and role defaults (`rbac-seed-v5`) |
| `config-s6/*.yml` | merge into each service's `application.yml` | All keys have safe defaults |
| `db-tuning/` | run by the DBA | Index script and slow query report for legacy tables |
| `perf/` | QA / performance team | k6 scripts and volume seed |
| `qa/`, `docs/` | project share | Regression suite, RBAC matrix, go-live documents |

---

## 3. Integration steps per service

### 3.1 smartie-common-utils

Copy the four new packages and `JdbcValues`. There are no new dependencies: the XLSX writer and reader use `java.util.zip` and StAX.

### 3.2 candidate-services

1. Copy the five packages and `db/p6`. `CandidateS6Config` creates the tables at start-up, using the same `SchemaInitializer` and `@@` separator as Sprint 3-5. Turn it off with `digihire.s6.schema-init=false` once Flyway owns the scripts.
2. Merge `config-s6/candidate-services-s6.yml`.
3. Check the beans that are picked up automatically:
   - **`FactProjector`:** it is a `StatusMoveListener`, so `StatusMover` calls it after every move.
   - **`ApplicationMutexGuard`:** it is a `MoveGuard`, so every move is checked for a stale status.
   - **`p6CachingRequisitionPort`:** it is `@Primary`. Mapping uses the cached requisition lookups, and the Sprint 3-5 `p5RequisitionPort` is not used. Set `digihire.s6.worklist.cache-requisitions=false` to switch it off.
   - **`IdempotencyFilter`:** registered for the POST paths in `digihire.s6.concurrency.idempotent-paths`.
4. Build history once after deploy: `POST /reports/facts/rebuild` with `{ "from": "...", "to": "..." }`, one month per call, as TA Head or Super Admin.

### 3.3 job-services

Copy `requisition`, `ops` and `db/p6`, and merge `config-s6/job-services-s6.yml`. `LocalOverrideSink` registers as a `RequisitionSink`, so a recruiter re-assignment made in DigiHire survives the next Oracle sync.

### 3.4 vendor-services

Copy `directory`. It adds two internal endpoints for the reports. Both are protected by `X-Internal-Key`.

### 3.5 admin-services

Append `data-admin-sprint6.sql` to the admin seed run. It is idempotent.

---

## 4. Patterns used in Sprint 6

### 4.1 Reporting read model

```
StatusMover.move/announce
   -> FactProjector (after commit, own transaction)
        -> cand_p6_stage_event   one row per move
        -> cand_p6_app_fact      one row per application (current state + first time each stage was reached)
   on failure -> cand_p6_fact_dirty -> ReportJobs.repairDirty (every 5 min) -> FactRebuildService
nightly    -> ReportAccuracyService compares facts with ReportSourcePort, repairs drift, stores the score
```

- **Reports read only the fact table.** They never scan the legacy application tables, which is what keeps the dashboard fast.
- **Projection runs after commit.** A failure in reporting can never block or roll back a status change.
- **Funnel definition:** an application counts at a stage if it reached that stage *or any later stage*. So the funnel never increases, even when optional stages such as Versant are skipped.
  - `Rejected here` counts applications now in the Rejected tab, grouped by the furthest stage they had reached.
  - `Open here` counts applications sitting at that stage now.
- **Cohort dates:** date filters apply to the applied date, so a range is a cohort of applications. The dashboard pipeline, aging and requisition widgets show current state; they use the date filter only when one is given.

### 4.2 Scope

`ReportScope.of(caller, permission)` turns the caller's RBAC scope into SQL filters:

| Scope | Sees |
| :--- | :--- |
| `ALL` | Everything |
| `LOB` / `LOCATION` | Applications in the caller's LOBs / locations |
| `TEAM` | Applications of the caller and their team |
| `OWN` (default) | The caller's own applications |

`Where` builds every filter with bind parameters and whitelisted column names only.

### 4.3 Exports

Every export:

- checks `REPORT:EXPORT` plus the report's own permission
- is capped (100,000 rows for Excel / CSV, 2,000 for PDF)
- neutralises formula injection (`=`, `+`, `-`, `@` are prefixed with `'`)
- is logged in `cand_p6_export_log`
- is audited as `REPORT_EXPORTED`

Exporting a candidate list (drill-down) also needs `CANDIDATE:EXPORT`.

### 4.4 Concurrency

- **`ApplicationMutexGuard`:** inside a transaction, it locks one row per application (`SELECT ... FOR UPDATE` on `cand_p6_app_mutex`). It then refuses the move with `409 STALE_STATUS` if the application changed since the user loaded it.
- **`Idempotency-Key`:** on the configured POST paths, the header makes double submits safe.
  - The same key and body replays the first response.
  - The same key with a different body returns `422`.
  - A request still running returns `409 REQUEST_IN_PROGRESS`.
  - Keys are scoped per user.
- **job-services:** `POST /requisitions` and `PATCH /requisitions/{id}` use the same mechanism through `IdempotentExecutor`.

### 4.5 Readiness

`ReadinessService` runs named checks in parallel with a timeout and returns PASS / WARN / FAIL per check. Settings that are optional in DEV become FAIL when `digihire.s6.environment` starts with `prod`.

- `GET /ops/readiness` needs `OPS:READINESS`.
- `GET /internal/readiness` needs the internal key and answers 503 when the overall status is FAIL, so it can back a load-balancer or pipeline gate.

---

## 5. Ports the team can override

| Port | Default | Override when |
| :--- | :--- | :--- |
| `ReportSourcePort` | `PortBackedReportSource`: loads through `ApplicationPort`, `StageHistoryPort`, `CandidatePort`; finds changed applications from `cand_p6_stage_event` | You want the accuracy job to also catch moves made outside `StatusMover`. Implement `applicationIdsChangedBetween` with a query on `application` / `application_status_log` |
| `UserDirectoryPort` | `AdminUserDirectory`: admin-services `/internal/users/by-role/{role}`, cached 10 min | Recruiter ids in applications are not admin user ids, emails or employee codes |
| `VendorDirectoryPort` | `VendorServicesDirectory`: vendor-services `/internal/vendors/names` and `/internal/vendor-links/by-application/{id}` | Vendor names live in a legacy vendor master |
| `ReportPdfRenderer` | `PdfBoxReportRenderer` (A4 landscape table, footer with user and time) | You want branding (DEP-S3-03 template) |
| `RequisitionPushPort` | `StubRequisitionPush` (nothing sent; Oracle-owned numbers stay `PENDING_PUSH`) | `push-mode: REST` with `push-create-url`, `push-update-url` and the Oracle credentials of `digihire.jobs.oracle` |

Every default is `@ConditionalOnMissingBean`. Declare your own bean and the default steps aside.

---

## 6. Task to code map

| # | Task | Code |
| :--- | :--- | :--- |
| 1 | Dashboard search and filter | `ReportFilter` (date range, LOB, location, recruiter, vendor, source, requisition, role, tab, status, free text), `FilterOptionsService`, `GET /reports/filter-options` |
| 2 | Drill-down from widgets | Every bucket carries a `drill` key; `DrillDownService` (`pipeline:`, `aging:`, `movements:`, `funnel:`, `dropped:`, `requisition:`, `recruiter:`) |
| 3 | Hiring funnel report | `FunnelReportService`: reached, conversion from previous and from applied, rejected here, open here, average days; breakdown by LOB, location, source, recruiter, vendor, role or requisition |
| 4 | Vendor performance report | `PerformanceReportService.vendors` plus vendor names from vendor-services |
| 5 | Recruiter performance report | `PerformanceReportService.recruiters`: applications, HR round, selected, offered, joined, rejected, open, actions taken, conversion, offer acceptance, days to offer and to join |
| 6 | Export Excel / PDF | `ReportExportService`, `XlsxReportWriter`, `CsvReportWriter`, `PdfBoxReportRenderer`, `POST /reports/export` |
| 7 | Role-based dashboard and report access | `REPORT:*` permissions plus `ReportScope` |
| 8 | TL and above requisition upload / modify | job-services `RequisitionChangeService`, `RequisitionFileReader`, `RequisitionPushPort`, `LocalOverrideSink`, template download |
| 9 | Report accuracy 99% or better | `ReportAccuracyService` (nightly, with repair), `cand_p6_check_run`, readiness check `report-accuracy` |
| 10 | Map Candidate page | `POST /mapping/assess/batch` (up to 25 candidates in parallel), `CachingRequisitionPort` |
| 11 | Applicant page | `WorklistService`: keyset pagination over the fact table, capped counts, scope in SQL |
| 12 | Dashboard load time | Read model plus `TtlCache` (60 s per scope and filter) plus fact indexes |
| 13 | Indexing and query tuning | `db-tuning/legacy-indexes-pg.sql` (only creates an index when the table and columns exist), `slow-queries-pg.sql` |
| 14 | Concurrency | `ApplicationMutexGuard`, `IdempotencyFilter`, `IdempotentExecutor` |
| 15 | Scalability to 5x | `perf/seed/seed-report-volume-pg.sql`, `perf/k6/*`, `ReportVolumeCheckTest` |
| 16, 17 | Defect triage, known defects | `docs/defect-triage.md` (severity, SLA, review findings to re-test) |
| 18, 19 | End-to-end and integration regression | `qa/regression-suite.md` |
| 20 | RBAC regression matrix | `qa/rbac-regression-matrix.xlsx` (155 permissions x 8 roles from the seeded database, plus Sprint 6 endpoints), `qa/rbac-live-export.sql` |
| 21 | Rule verification | `qa/regression-suite.md` RULE-01 to RULE-10 |
| 22 | Audit log completeness | `AuditCompletenessService`: matches every move to an audit row, nightly, with readiness check |
| 23 | Performance re-test | `perf/k6/dashboard.js`, `worklist.js`, `map-candidate.js`, `soak.js` (p95 < 3 s, errors < 0.5%) |
| 24 | UAT support | `docs/hypercare-runbook.md` routine and common issues apply to UAT too |
| 25 | Training material | `docs/training-outline.md` |
| 26 | Go-live checklist and cutover | `docs/go-live-checklist.md`, `docs/cutover-plan.md`, readiness endpoints |
| 27 | Production deployment and hypercare | `docs/cutover-plan.md`, `docs/hypercare-runbook.md` |

---

## 7. Endpoints

**candidate-services**

| Method | Path | Permission |
| :--- | :--- | :--- |
| GET | `/reports/dashboard` | `REPORT:VIEW` |
| GET | `/reports/dashboard/drill?drill=...&page&size&sort` | `REPORT:VIEW` + `CANDIDATE:VIEW` |
| GET | `/reports/filter-options` | `REPORT:VIEW` |
| GET | `/reports/funnel?breakdown=lob` | `REPORT:FUNNEL` |
| GET | `/reports/recruiters` | `REPORT:RECRUITER` |
| GET | `/reports/vendors` | `REPORT:VENDOR` |
| POST | `/reports/export` `{report: FUNNEL / RECRUITER / VENDOR / DRILL, format: XLSX / CSV / PDF, filter, breakdown, drill}` | `REPORT:EXPORT` (+ `CANDIDATE:EXPORT` for DRILL) |
| POST, GET | `/reports/quality/accuracy` | `REPORT:QUALITY` |
| POST, GET | `/reports/quality/audit-completeness` | `REPORT:QUALITY` |
| POST | `/reports/facts/rebuild` `{applicationIds}` or `{from, to}` | `REPORT:QUALITY` |
| GET | `/worklist/applicants?tab&status&lob&location&recruiter&requisition&q&sort&cursor&size&count` | `CANDIDATE:VIEW` |
| POST | `/mapping/assess/batch` `{items: [AssessRequest]}` | as `/mapping/assess` |
| GET | `/ops/readiness` | `OPS:READINESS` |
| GET | `/internal/readiness` | internal key |

Filters on report endpoints are query parameters:

- `from`, `to` as `YYYY-MM-DD`.
- `lob`, `location`, `recruiter`, `vendor`, `source`, `requisition`, `role`, `tab`, `status`, each comma separated.
- `q`, a free-text search.

**job-services**

| Method | Path | Permission |
| :--- | :--- | :--- |
| POST | `/requisition-uploads` (multipart `file`, `dryRun`) | `REQUISITION:UPLOAD` / `REQUISITION:MODIFY` per row |
| GET | `/requisition-uploads/template` | logged in |
| GET | `/requisition-uploads/{id}` | uploader or ALL scope |
| POST | `/requisitions` | `REQUISITION:UPLOAD` |
| PATCH | `/requisitions/{id}` | `REQUISITION:MODIFY` |
| GET | `/requisitions/{id}/change-history` | `JOB:VIEW` |
| GET | `/ops/readiness`, `/internal/readiness` | `OPS:READINESS` / internal key |

**vendor-services**: `GET /internal/vendors/names?ids=`, `GET /internal/vendor-links/by-application/{applicationId}` (internal key).

### Requisition upload rules

- **Columns:** `Action, Requisition Id, Title, LOB, Location, ORC Id, Role, Openings, Valid To, Recruiter Id, Status`.
- **Action:** `CREATE` or `UPDATE`.
- **CREATE rows:**
  - Title, LOB, Location, Role, Openings and Valid To are required.
  - The id is generated as `DH-yyMMdd-XXXXX` when blank.
  - The source is `DIGIHIRE`.
- **UPDATE rows:** blank cells keep their value.
- **Oracle requisitions:**
  - Title, LOB, Location, ORC Id and Role are refused.
  - Openings, Valid To and Status go to Oracle first and are applied only when Oracle accepts them; otherwise the row is `PENDING_PUSH`.
  - Recruiter Id is applied at once and kept through later syncs.
- **Value checks:**
  - Openings must be 1 to 500 and never below the number already filled.
  - Valid To must be from today to 365 days ahead.
  - Status must be `OPEN`, `ON_HOLD` or `CLOSED`.
  - The LOB must be in `job_p5_lob` when that table has rows.
- **Scope:** callers without ALL scope can only touch their LOBs.
- **Formula injection:** cells that look like formulas are refused.
- **Dry run:** `dryRun=true` validates every row and changes nothing.

---

## 8. Permissions (`rbac-seed-v5`)

| Code | Default roles |
| :--- | :--- |
| `REPORT:VIEW` (existing) | Recruiter, Recruitment Manager, TA Head |
| `REPORT:FUNNEL`, `REPORT:RECRUITER`, `REPORT:VENDOR`, `REPORT:EXPORT` | Recruitment Manager, TA Head |
| `REPORT:QUALITY`, `OPS:READINESS` | TA Head, Super Admin |
| `REQUISITION:UPLOAD`, `REQUISITION:MODIFY` | Recruitment Manager, TA Head |

The dashboard reuses the existing `REPORT:VIEW`. The roles stay as they are; "TL and above" is Recruitment Manager and TA Head in the current role list.

---

## 9. Data model

| Service | Tables |
| :--- | :--- |
| candidate-services | `cand_p6_app_fact`, `cand_p6_stage_event`, `cand_p6_fact_dirty`, `cand_p6_check_run`, `cand_p6_export_log`, `cand_p6_app_mutex`, `cand_p6_idempotency` |
| job-services | `job_p6_upload`, `job_p6_requisition_change`, `job_p6_requisition_override`, `job_p6_idempotency` |

All scripts are idempotent (`IF NOT EXISTS`) and run on H2 and PostgreSQL. No Hibernate entity maps these tables.

---

## 10. Performance measured

Measurements were taken on PostgreSQL 16 in a small container: a single user, cold cache, against `cand_p6_app_fact` seeded by `perf/seed`. Each figure is the second run of the call.

| Call | 200,000 applications | 1,000,000 applications |
| :--- | ---: | ---: |
| Funnel, 90 days, all, breakdown by LOB | 244 ms | 706 ms |
| Funnel, 180 days, all, breakdown by recruiter | 293 ms | 1,112 ms |
| Recruiter performance, 90 days | 185 ms | 666 ms |
| Vendor performance, 180 days | 47 ms | 193 ms |
| Dashboard, ALL scope, no cache | 353 ms | 1,108 ms |
| Dashboard, TEAM scope, no cache | 145 ms | 296 ms |
| Drill-down, aging over 30 days, page 6 | 110 ms | 412 ms |
| Worklist page 1 with capped count | 85 ms | 226 ms |
| Worklist page 2 (keyset) | 59 ms | 212 ms |
| Worklist free-text search | 115 ms | 507 ms |

Every call stays under the 3-second NFR at 1,000,000 applications, which is well above 5x current volume. Concurrency and uptime still need the k6 runs on UAT hardware.

Re-run the check:

```
psql -v rows=1000000 -f perf/seed/seed-report-volume-pg.sql
mvn -pl candidate-services test -Dtest=ReportVolumeCheckTest -Dp6.volume.url=jdbc:postgresql://host:5432/db
psql -f perf/seed/cleanup-report-volume-pg.sql
```

k6:

```
k6 run -e BASE_URL=https://uat.../candidate-services -e TOKEN=... -e PEAK_VUS=60 perf/k6/dashboard.js
```

`slow-queries-pg.sql` needs the `pg_stat_statements` extension.

---

## 11. Verification

- **Platform (6 tests):**
  - The XLSX writer output reads back through the reader with types intact. The same file was also opened in openpyxl and LibreOffice, with number formats kept.
  - Zip-bomb and row limits hold.
  - CSV quoting and the injection guard work.
  - `TtlCache` expiry and the error path work.
  - Idempotency replays, refuses reuse, is per user, and releases after a failure.
  - Readiness aggregates and times out slow checks.
- **Reporting (8 tests):**
  - Funnel numbers, drop stage and average days.
  - Scope for OWN, TEAM and LOB, and permission errors.
  - Recruiter and vendor reports.
  - Dashboard cache and all drill types.
  - XLSX export read back, CSV injection guard, `CANDIDATE:EXPORT` guard, export log and audit.
  - The accuracy check finds and repairs a changed and a missing fact (50% score), then passes.
  - Audit completeness matches 11 moves and catches a deleted audit row.
  - Dirty facts are repaired.
- **Worklist and concurrency (3 tests):**
  - 23 applications across 3 keyset pages with no duplicates; OWN scope count; bad cursor.
  - Stale status refused and the row lock taken.
  - Readiness FAIL for missing secrets, localhost URLs and a stale accuracy run, then PASS after a run.
- **Requisitions (5 tests):**
  - CSV upload with created, refused and Oracle-owned rows.
  - Formula cell refused.
  - Generated id.
  - `PENDING_PUSH` until Oracle accepts.
  - Recruiter override survives an Oracle sync.
  - LOB scope, permission and LOB master checks.
  - XLSX dry run, then a real upload with status and visibility.
  - Template readable.
  - Readiness flags a stub Oracle and a missing sync.
- **Vendor directory (1 test).**
- **Volume check (1 test):** runs only with `-Dp6.volume.url`.

All 24 tests pass on H2. With `-Dp5.test.pg.url` pointing at PostgreSQL 16, every test that uses `TestDatabase` (reporting, worklist, requisitions, vendor directory) passes there too. The Sprint 3-5 suites still pass unchanged:

| Module | Tests |
| :--- | ---: |
| common | 22 |
| candidate | 55 |
| job | 6 |
| vendor | 3 |
| integration | 5 |

The schema scripts were run twice on PostgreSQL. The admin seed was run twice on top of the Sprint 1-5 seeds, and the resulting grants are the ones in the RBAC matrix.

Not verified here:

- the Spring application context in the real services
- PDF rendering with real PDFBox
- the Oracle Jobs REST push against a real Oracle endpoint
- the k6 runs

---

## 12. Defaults waiting for sign-off

| Item | Default | Owner / dependency |
| :--- | :--- | :--- |
| Report KPI definitions | Funnel stages as in section 4.1; conversion = joined / applications; offer acceptance = joined / offered | TA Head, DEP-S6-01 |
| Report date basis | Applied date (cohort) | TA Head, DEP-S6-01 |
| Accuracy target | 99.0%, nightly for the last two days, with repair | TA Head |
| Export limits | 100,000 rows Excel / CSV, 2,000 rows PDF | TA Head, AGS Security |
| Requisition fields owned by Oracle | Title, LOB, Location, ORC Id, Role | Oracle team, DEP-S4-12 |
| Oracle Jobs Create / Update API | Not called until `push-mode: REST` and URLs are given (Oracle sheet: Jobs Create API, Update API) | Oracle team, DEP-S4-11 |
| Report PDF branding | Plain table | Marketing, DEP-S3-03 |
| GitLab gates for go-live | Protected environments need GitLab Premium, or the protected-tag workaround | AGS IT, DEP-S6-14 |

---

## 13. Checklist for adding more code in this pattern

- Put the new feature in its own package, with sub-packages only when it grows past about 10 classes.
- Read legacy data through a port. Give the port a default implementation, marked `@ConditionalOnMissingBean`.
- Every query uses bind parameters. Column names come only from whitelists.
- Every write that matters is audited through `AuditRecorder`. Every status change goes through `StatusMover`.
- New tables use the `cand_p6_` / `job_p6_` prefix, sit in an idempotent script and work on both H2 and PostgreSQL.
- Add the readiness check for any new external dependency.
- Add a test that runs on H2 and on PostgreSQL (`-Dp5.test.pg.url`).
