CREATE TABLE IF NOT EXISTS job_p6_upload (
    id             VARCHAR(36)   PRIMARY KEY,
    file_name      VARCHAR(200),
    dry_run        BOOLEAN       NOT NULL,
    total          INT           NOT NULL,
    applied        INT           NOT NULL DEFAULT 0,
    pending        INT           NOT NULL DEFAULT 0,
    rejected       INT           NOT NULL DEFAULT 0,
    created_by     VARCHAR(64)   NOT NULL,
    created_at     TIMESTAMP WITH TIME ZONE NOT NULL,
    finished_at    TIMESTAMP WITH TIME ZONE
)@@

CREATE TABLE IF NOT EXISTS job_p6_requisition_change (
    id               VARCHAR(36)   PRIMARY KEY,
    upload_id        VARCHAR(36),
    row_no           INT,
    requisition_id   VARCHAR(64),
    action           VARCHAR(10)   NOT NULL,
    status           VARCHAR(20)   NOT NULL,
    changes          VARCHAR(4000),
    message          VARCHAR(1000),
    external_ref     VARCHAR(200),
    actor_id         VARCHAR(64)   NOT NULL,
    created_at       TIMESTAMP WITH TIME ZONE NOT NULL
)@@
CREATE INDEX IF NOT EXISTS ix_job_p6_change_req ON job_p6_requisition_change (requisition_id, created_at)@@
CREATE INDEX IF NOT EXISTS ix_job_p6_change_upload ON job_p6_requisition_change (upload_id, row_no)@@

CREATE TABLE IF NOT EXISTS job_p6_requisition_override (
    requisition_id   VARCHAR(64)   NOT NULL,
    field_name       VARCHAR(40)   NOT NULL,
    field_value      VARCHAR(300),
    set_by           VARCHAR(64)   NOT NULL,
    set_at           TIMESTAMP WITH TIME ZONE NOT NULL,
    PRIMARY KEY (requisition_id, field_name)
)@@

CREATE TABLE IF NOT EXISTS job_p6_idempotency (
    idem_key         VARCHAR(64)   PRIMARY KEY,
    request_hash     VARCHAR(64)   NOT NULL,
    state            VARCHAR(12)   NOT NULL,
    status_code      INT,
    content_type     VARCHAR(100),
    body             TEXT,
    created_at       TIMESTAMP WITH TIME ZONE NOT NULL,
    expires_at       TIMESTAMP WITH TIME ZONE NOT NULL
)@@
