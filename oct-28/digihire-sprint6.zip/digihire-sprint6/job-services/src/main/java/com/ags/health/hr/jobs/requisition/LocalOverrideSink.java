package com.ags.health.hr.jobs.requisition;

import com.ags.health.hr.jobs.listing.RequisitionRecord;
import com.ags.health.hr.jobs.listing.RequisitionStore;
import com.ags.health.hr.jobs.sync.RequisitionSink;

import java.util.Objects;

public class LocalOverrideSink implements RequisitionSink {

    public static final String RECRUITER = "recruiter_id";

    private final RequisitionChangeStore changes;
    private final RequisitionStore store;

    public LocalOverrideSink(RequisitionChangeStore changes, RequisitionStore store) {
        this.changes = changes;
        this.store = store;
    }

    @Override
    public void upsert(RequisitionRecord r) {
        changes.overrideValue(r.requisitionId(), RECRUITER).filter(v -> !Objects.equals(v, r.recruiterId())).ifPresent(v ->
                store.upsert(new RequisitionRecord(r.requisitionId(), r.jobId(), r.title(), r.lob(), r.location(), r.orcId(), r.roleCode(),
                        r.status(), r.openings(), r.filled(), r.validTo(), v, r.jd(), r.jdVersion(), r.source(), r.sourceUpdatedAt(),
                        r.visible(), r.hiddenReason(), r.updatedAt())));
    }
}
