package com.ags.health.hr.jobs.requisition;

import com.ags.health.hr.common.platform.audit.AuditRecorder;
import com.ags.health.hr.common.platform.caller.Caller;
import com.ags.health.hr.common.platform.error.PlatformException;
import com.ags.health.hr.common.platform.export.ReportTable;
import com.ags.health.hr.common.platform.export.XlsxReportWriter;
import com.ags.health.hr.common.platform.time.BusinessClock;
import com.ags.health.hr.jobs.listing.ListingService;
import com.ags.health.hr.jobs.listing.RequisitionRecord;
import com.ags.health.hr.jobs.listing.RequisitionStore;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.transaction.support.TransactionTemplate;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.security.SecureRandom;
import java.time.Instant;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;

public class RequisitionChangeService {

    public static final String UPLOAD = "REQUISITION:UPLOAD";
    public static final String MODIFY = "REQUISITION:MODIFY";
    public static final String SOURCE = "DIGIHIRE";
    static final Set<String> ORACLE_OWNED = Set.of("title", "lob", "location", "orcId", "roleCode");
    static final Set<String> STATUSES = Set.of("OPEN", "ON_HOLD", "CLOSED");
    private static final SecureRandom RANDOM = new SecureRandom();
    private static final String ALPHABET = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";

    public record Settings(int maxOpenings, int maxValidDays, boolean pushLocalToOracle) {
    }

    public record RowResult(int rowNo, String action, String requisitionId, String outcome, String message, Map<String, Object> changes) {
    }

    public record UploadResult(String uploadId, boolean dryRun, int total, int applied, int pending, int rejected, List<String> fileProblems,
                               List<RowResult> rows) {
    }

    private final RequisitionStore store;
    private final RequisitionChangeStore changes;
    private final ListingService listing;
    private final RequisitionPushPort push;
    private final RequisitionFileReader reader;
    private final JdbcTemplate jdbc;
    private final TransactionTemplate tx;
    private final AuditRecorder audit;
    private final BusinessClock clock;
    private final ObjectMapper mapper;
    private final Settings settings;

    public RequisitionChangeService(RequisitionStore store, RequisitionChangeStore changes, ListingService listing, RequisitionPushPort push,
                                    RequisitionFileReader reader, JdbcTemplate jdbc, TransactionTemplate tx, AuditRecorder audit,
                                    BusinessClock clock, ObjectMapper mapper, Settings settings) {
        this.store = store;
        this.changes = changes;
        this.listing = listing;
        this.push = push;
        this.reader = reader;
        this.jdbc = jdbc;
        this.tx = tx;
        this.audit = audit;
        this.clock = clock;
        this.mapper = mapper;
        this.settings = settings;
    }

    public UploadResult upload(Caller caller, String fileName, byte[] content, boolean dryRun) {
        if (!caller.hasAny(UPLOAD, MODIFY)) {
            throw PlatformException.forbidden("PERMISSION_DENIED", "Missing permission " + UPLOAD + " or " + MODIFY);
        }
        RequisitionFileReader.Parsed parsed = reader.read(fileName, content);
        String uploadId = UUID.randomUUID().toString();
        changes.startUpload(uploadId, fileName, dryRun, parsed.rows().size(), caller.userId(), clock.now());
        List<RowResult> results = new ArrayList<>();
        int applied = 0;
        int pending = 0;
        int rejected = 0;
        for (RequisitionInput in : parsed.rows()) {
            RowResult r = processSafely(caller, in, uploadId, dryRun);
            results.add(r);
            switch (r.outcome()) {
                case "APPLIED", "VALID", "UNCHANGED" -> applied++;
                case "PENDING_PUSH" -> pending++;
                default -> rejected++;
            }
        }
        changes.finishUpload(uploadId, applied, pending, rejected, clock.now());
        audit.record("ACTIVITY", dryRun ? "REQUISITION_UPLOAD_VALIDATED" : "REQUISITION_UPLOADED", "REQUISITION_UPLOAD", uploadId, null,
                AuditRecorder.details("file", fileName, "rows", parsed.rows().size(), "applied", applied, "pending", pending, "rejected", rejected));
        return new UploadResult(uploadId, dryRun, parsed.rows().size(), applied, pending, rejected, parsed.problems(), results);
    }

    public RowResult create(Caller caller, RequisitionInput in) {
        RowResult r = process(caller, new RequisitionInput(0, "CREATE", in.requisitionId(), in.title(), in.lob(), in.location(), in.orcId(),
                in.roleCode(), in.openings(), in.validTo(), in.recruiterId(), in.status()), null, false);
        return failIfRejected(r);
    }

    public RowResult modify(Caller caller, String requisitionId, RequisitionInput in) {
        RowResult r = process(caller, new RequisitionInput(0, "UPDATE", requisitionId, in.title(), in.lob(), in.location(), in.orcId(),
                in.roleCode(), in.openings(), in.validTo(), in.recruiterId(), in.status()), null, false);
        return failIfRejected(r);
    }

    public Map<String, Object> upload(Caller caller, String uploadId) {
        if (!caller.hasAny(UPLOAD, MODIFY)) {
            throw PlatformException.forbidden("PERMISSION_DENIED", "Missing permission " + UPLOAD);
        }
        Map<String, Object> u = changes.upload(uploadId);
        if (u == null) {
            throw PlatformException.notFound("Upload", uploadId);
        }
        if (!caller.scopeAll() && !caller.userId().equals(u.get("created_by"))) {
            throw PlatformException.forbidden("NOT_YOUR_UPLOAD", "Only the uploader can view this upload");
        }
        Map<String, Object> out = new LinkedHashMap<>(u);
        out.put("rows", changes.uploadRows(uploadId));
        return out;
    }

    public List<Map<String, Object>> history(Caller caller, String requisitionId) {
        if (!caller.hasAny(UPLOAD, MODIFY, "JOB:VIEW")) {
            throw PlatformException.forbidden("PERMISSION_DENIED", "Missing permission JOB:VIEW");
        }
        RequisitionRecord r = store.find(requisitionId).orElseThrow(() -> PlatformException.notFound("Requisition", requisitionId));
        if (!inScope(caller, r.lob())) {
            throw PlatformException.forbidden("OUT_OF_SCOPE", "Requisition is outside your LOB scope");
        }
        return changes.history(requisitionId, 100);
    }

    public byte[] template() {
        List<ReportTable.Column> cols = new ArrayList<>();
        for (String h : RequisitionFileReader.HEADERS) {
            cols.add(h.equals("Valid To") ? ReportTable.Column.date(h, h) : h.equals("Openings") ? ReportTable.Column.integer(h, h)
                    : ReportTable.Column.text(h, h, 18));
        }
        List<List<Object>> rows = List.of(
                Arrays.asList("CREATE", null, "Analyst - AR Calling", "LOB-NAME", "Chennai", "ORC-1001", "AR_CALLER", 5,
                        clock.today().plusDays(60), null, "OPEN"),
                Arrays.asList("UPDATE", "REQ-12345", null, null, null, null, null, 8, null, "rec.user@agshealth.com", null));
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        try {
            new XlsxReportWriter(clock.zone()).write(new ReportTable("Requisitions", cols, rows, Map.of(
                    "CREATE", "Title, LOB, Location, Role, Openings and Valid To are required; Requisition Id is generated when blank",
                    "UPDATE", "Fill only the cells to change; blank cells keep their value",
                    "Oracle requisitions", "Title, LOB, Location, ORC Id and Role are owned by Oracle; Openings, Valid To and Status go to Oracle first",
                    "Status", "OPEN, ON_HOLD or CLOSED")), out);
        } catch (IOException e) {
            throw new IllegalStateException(e);
        }
        return out.toByteArray();
    }

    private RowResult failIfRejected(RowResult r) {
        if ("REJECTED".equals(r.outcome())) {
            throw PlatformException.unprocessable("REQUISITION_REJECTED", r.message(), List.of(Map.of("requisitionId",
                    String.valueOf(r.requisitionId()))));
        }
        return r;
    }

    private RowResult processSafely(Caller caller, RequisitionInput in, String uploadId, boolean dryRun) {
        try {
            return process(caller, in, uploadId, dryRun);
        } catch (PlatformException e) {
            return reject(in, uploadId, caller, e.getMessage(), dryRun);
        }
    }

    RowResult process(Caller caller, RequisitionInput in, String uploadId, boolean dryRun) {
        String action = action(in.action());
        if (action == null) {
            return reject(in, uploadId, caller, "Action must be CREATE or UPDATE", dryRun);
        }
        if (!caller.has("CREATE".equals(action) ? UPLOAD : MODIFY)) {
            return reject(in, uploadId, caller, "Missing permission " + ("CREATE".equals(action) ? UPLOAD : MODIFY), dryRun);
        }
        RowResult r = tx.execute(s -> "CREATE".equals(action) ? doCreate(caller, in, uploadId, dryRun) : doUpdate(caller, in, uploadId, dryRun));
        return r;
    }

    private RowResult doCreate(Caller caller, RequisitionInput in, String uploadId, boolean dryRun) {
        List<String> problems = new ArrayList<>();
        require(problems, "Title", in.title());
        require(problems, "LOB", in.lob());
        require(problems, "Location", in.location());
        require(problems, "Role", in.roleCode());
        if (in.openings() == null) {
            problems.add("Openings is required");
        }
        if (in.validTo() == null) {
            problems.add("Valid To is required");
        }
        validateValues(problems, in, 0);
        if (in.lob() != null && !inScope(caller, in.lob())) {
            problems.add("LOB " + in.lob() + " is outside your scope");
        }
        String id = in.requisitionId() == null ? generateId() : in.requisitionId().trim();
        if (!id.matches("[A-Za-z0-9._-]{3,64}")) {
            problems.add("Requisition Id may hold letters, digits, dot, dash and underscore only (3-64)");
        } else if (store.find(id).isPresent()) {
            problems.add("Requisition " + id + " already exists; use UPDATE");
        }
        if (!problems.isEmpty()) {
            return reject(in.withRow(in.rowNo()), id, uploadId, caller, String.join("; ", problems), dryRun);
        }
        Instant now = clock.now();
        String status = in.status() == null ? "OPEN" : in.status();
        RequisitionRecord rec = new RequisitionRecord(id, null, in.title().trim(), in.lob().trim(), in.location().trim(), trim(in.orcId()),
                in.roleCode().trim(), status, in.openings(), 0, in.validTo(), trim(in.recruiterId()), null, 0, SOURCE, now, true, null, now);
        Map<String, Object> diff = new LinkedHashMap<>();
        diff.put("title", rec.title());
        diff.put("lob", rec.lob());
        diff.put("location", rec.location());
        diff.put("roleCode", rec.roleCode());
        diff.put("openings", rec.openings());
        diff.put("validTo", String.valueOf(rec.validTo()));
        diff.put("status", rec.status());
        if (dryRun) {
            return result(in, id, "VALID", "Ready to create", diff, uploadId, caller, null, true);
        }
        RequisitionRecord visible = listing.applyVisibility(rec, true);
        store.upsert(visible);
        String ref = null;
        String message = "Created";
        if (settings.pushLocalToOracle()) {
            RequisitionPushPort.PushResult p = push.create(visible);
            ref = p.externalRef();
            message = p.pushed() ? "Created and sent to Oracle" : "Created; Oracle push not done: " + p.message();
        }
        audit.record("ACTIVITY", "REQUISITION_CREATED", "REQUISITION", id, null, AuditRecorder.details("changes", diff, "uploadId", uploadId));
        return result(in, id, "APPLIED", message, diff, uploadId, caller, ref, false);
    }

    private RowResult doUpdate(Caller caller, RequisitionInput in, String uploadId, boolean dryRun) {
        if (in.requisitionId() == null) {
            return reject(in, uploadId, caller, "Requisition Id is required for UPDATE", dryRun);
        }
        Optional<RequisitionRecord> found = store.find(in.requisitionId().trim());
        if (found.isEmpty()) {
            return reject(in, uploadId, caller, "Requisition " + in.requisitionId() + " not found", dryRun);
        }
        RequisitionRecord cur = found.get();
        List<String> problems = new ArrayList<>();
        if (!inScope(caller, cur.lob()) || (in.lob() != null && !inScope(caller, in.lob()))) {
            problems.add("Requisition is outside your LOB scope");
        }
        validateValues(problems, in, cur.filled());
        Map<String, Object> diff = new LinkedHashMap<>();
        diff(diff, "title", cur.title(), in.title());
        diff(diff, "lob", cur.lob(), in.lob());
        diff(diff, "location", cur.location(), in.location());
        diff(diff, "orcId", cur.orcId(), in.orcId());
        diff(diff, "roleCode", cur.roleCode(), in.roleCode());
        diff(diff, "openings", cur.openings(), in.openings());
        diff(diff, "validTo", cur.validTo() == null ? null : cur.validTo().toString(), in.validTo() == null ? null : in.validTo().toString());
        diff(diff, "status", cur.status() == null ? null : cur.status().toUpperCase(Locale.ROOT), in.status());
        diff(diff, "recruiterId", cur.recruiterId(), in.recruiterId());
        boolean oracle = "ORACLE".equalsIgnoreCase(cur.source());
        if (oracle) {
            List<String> owned = diff.keySet().stream().filter(ORACLE_OWNED::contains).toList();
            if (!owned.isEmpty()) {
                problems.add("Fields owned by Oracle can not be changed here: " + String.join(", ", owned));
            }
        }
        if (!problems.isEmpty()) {
            return reject(in, cur.requisitionId(), uploadId, caller, String.join("; ", problems), dryRun);
        }
        if (diff.isEmpty()) {
            return result(in, cur.requisitionId(), "UNCHANGED", "Nothing to change", diff, uploadId, caller, null, dryRun);
        }
        if (dryRun) {
            return result(in, cur.requisitionId(), "VALID", "Ready to update", diff, uploadId, caller, null, true);
        }
        Instant now = clock.now();
        Map<String, Object> toOracle = new LinkedHashMap<>();
        for (String f : List.of("openings", "validTo", "status")) {
            if (diff.containsKey(f)) {
                toOracle.put(f, ((Map<?, ?>) diff.get(f)).get("to"));
            }
        }
        String outcome = "APPLIED";
        String message = "Updated";
        String ref = null;
        boolean applyPushable = true;
        if (!toOracle.isEmpty() && (oracle || settings.pushLocalToOracle())) {
            RequisitionPushPort.PushResult p = push.update(cur.requisitionId(), toOracle);
            ref = p.externalRef();
            if (!p.pushed() && oracle) {
                applyPushable = false;
                outcome = "PENDING_PUSH";
                message = "Waiting for Oracle: " + p.message();
            } else if (p.pushed()) {
                message = "Updated in Oracle and DigiHire";
            }
        }
        String recruiter = diff.containsKey("recruiterId") ? in.recruiterId() : cur.recruiterId();
        if (diff.containsKey("recruiterId") && oracle) {
            changes.override(cur.requisitionId(), LocalOverrideSink.RECRUITER, in.recruiterId(), caller.userId(), now);
            if (!applyPushable) {
                message += "; recruiter change applied";
            }
        }
        RequisitionRecord next = new RequisitionRecord(cur.requisitionId(), cur.jobId(), pick(in.title(), cur.title()), pick(in.lob(), cur.lob()),
                pick(in.location(), cur.location()), pick(in.orcId(), cur.orcId()), pick(in.roleCode(), cur.roleCode()),
                applyPushable ? pick(in.status(), cur.status()) : cur.status(),
                applyPushable && in.openings() != null ? in.openings() : cur.openings(), cur.filled(),
                applyPushable && in.validTo() != null ? in.validTo() : cur.validTo(), recruiter, cur.jd(), cur.jdVersion(), cur.source(),
                cur.sourceUpdatedAt(), cur.visible(), cur.hiddenReason(), now);
        RequisitionRecord visible = listing.applyVisibility(next, true);
        store.upsert(visible);
        if (visible.visible()) {
            listing.republish(visible);
        }
        audit.record("ACTIVITY", "REQUISITION_UPDATED", "REQUISITION", cur.requisitionId(), null,
                AuditRecorder.details("changes", diff, "outcome", outcome, "uploadId", uploadId));
        return result(in, cur.requisitionId(), outcome, message, diff, uploadId, caller, ref, false);
    }

    private void validateValues(List<String> problems, RequisitionInput in, int filled) {
        if (in.title() != null && in.title().length() > 300) {
            problems.add("Title is longer than 300 characters");
        }
        if (in.openings() != null) {
            if (in.openings() < 1 || in.openings() > settings.maxOpenings()) {
                problems.add("Openings must be between 1 and " + settings.maxOpenings());
            } else if (in.openings() < filled) {
                problems.add("Openings can not be below the " + filled + " already filled");
            }
        }
        if (in.validTo() != null) {
            LocalDate today = clock.today();
            if (in.validTo().isBefore(today)) {
                problems.add("Valid To is in the past");
            } else if (in.validTo().isAfter(today.plusDays(settings.maxValidDays()))) {
                problems.add("Valid To can be at most " + settings.maxValidDays() + " days ahead");
            }
        }
        if (in.status() != null && !STATUSES.contains(in.status())) {
            problems.add("Status must be one of " + STATUSES);
        }
        if (in.lob() != null && !lobKnown(in.lob())) {
            problems.add("LOB " + in.lob() + " is not in the LOB master");
        }
        if (in.recruiterId() != null && !in.recruiterId().matches("[A-Za-z0-9._@+-]{2,64}")) {
            problems.add("Recruiter Id is not valid");
        }
    }

    private boolean lobKnown(String lob) {
        Long total = jdbc.queryForObject("SELECT count(*) FROM job_p5_lob", Long.class);
        if (total == null || total == 0) {
            return true;
        }
        Long n = jdbc.queryForObject("SELECT count(*) FROM job_p5_lob WHERE active = TRUE AND (UPPER(code) = ? OR UPPER(name) = ?)", Long.class,
                lob.trim().toUpperCase(Locale.ROOT), lob.trim().toUpperCase(Locale.ROOT));
        return n != null && n > 0;
    }

    static boolean inScope(Caller caller, String lob) {
        if (caller.scopeAll()) {
            return true;
        }
        if (lob == null) {
            return false;
        }
        return caller.lobs().stream().anyMatch(l -> l.equalsIgnoreCase(lob.trim()));
    }

    private RowResult reject(RequisitionInput in, String uploadId, Caller caller, String message, boolean dryRun) {
        return reject(in, in.requisitionId(), uploadId, caller, message, dryRun);
    }

    private RowResult reject(RequisitionInput in, String id, String uploadId, Caller caller, String message, boolean dryRun) {
        return result(in, id, "REJECTED", message, Map.of(), uploadId, caller, null, dryRun);
    }

    private RowResult result(RequisitionInput in, String id, String outcome, String message, Map<String, Object> diff, String uploadId,
                             Caller caller, String ref, boolean dryRun) {
        String action = action(in.action());
        if (uploadId != null || !dryRun) {
            changes.change(uploadId, in.rowNo(), id, action == null ? String.valueOf(in.action()) : action, outcome, json(diff), message, ref,
                    caller.userId(), clock.now());
        }
        return new RowResult(in.rowNo(), action, id, outcome, message, diff);
    }

    private String json(Map<String, Object> m) {
        try {
            return m.isEmpty() ? null : mapper.writeValueAsString(m);
        } catch (JsonProcessingException e) {
            return String.valueOf(m);
        }
    }

    private static void diff(Map<String, Object> d, String field, Object current, Object requested) {
        if (requested == null) {
            return;
        }
        Object r = requested instanceof String s ? s.trim() : requested;
        if (!Objects.equals(current, r)) {
            Map<String, Object> m = new LinkedHashMap<>();
            m.put("from", current);
            m.put("to", r);
            d.put(field, m);
        }
    }

    private static void require(List<String> problems, String field, String v) {
        if (v == null || v.isBlank()) {
            problems.add(field + " is required");
        }
    }

    private static String action(String a) {
        if (a == null) {
            return null;
        }
        return switch (a.trim().toUpperCase(Locale.ROOT)) {
            case "CREATE", "NEW", "ADD" -> "CREATE";
            case "UPDATE", "MODIFY", "EDIT" -> "UPDATE";
            default -> null;
        };
    }

    private String generateId() {
        StringBuilder sb = new StringBuilder("DH-").append(DateTimeFormatter.ofPattern("yyMMdd").format(clock.today())).append('-');
        for (int i = 0; i < 5; i++) {
            sb.append(ALPHABET.charAt(RANDOM.nextInt(ALPHABET.length())));
        }
        return sb.toString();
    }

    private static String pick(String v, String fallback) {
        return v == null || v.isBlank() ? fallback : v.trim();
    }

    private static String trim(String v) {
        return v == null || v.isBlank() ? null : v.trim();
    }
}
