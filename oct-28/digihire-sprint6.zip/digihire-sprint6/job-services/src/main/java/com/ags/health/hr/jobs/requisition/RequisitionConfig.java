package com.ags.health.hr.jobs.requisition;

import com.ags.health.hr.common.platform.audit.AuditRecorder;
import com.ags.health.hr.common.platform.concurrency.IdempotencyStore;
import com.ags.health.hr.common.platform.concurrency.IdempotentExecutor;
import com.ags.health.hr.common.platform.db.SchemaInitializer;
import com.ags.health.hr.common.platform.time.BusinessClock;
import com.ags.health.hr.jobs.listing.ListingService;
import com.ags.health.hr.jobs.listing.RequisitionStore;
import com.ags.health.hr.jobs.p5shared.JobsP5Properties;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.transaction.support.TransactionTemplate;

import javax.sql.DataSource;
import java.time.Clock;
import java.time.Duration;
import java.util.List;

@Configuration
@EnableConfigurationProperties(JobsS6Properties.class)
@ConditionalOnProperty(prefix = "digihire.s6.requisitions", name = "enabled", havingValue = "true", matchIfMissing = true)
public class RequisitionConfig {

    public static final String SCHEMA = "db/p6/job-p6-schema.sql";

    @Bean(initMethod = "run")
    @ConditionalOnProperty(prefix = "digihire.s6", name = "schema-init", havingValue = "true", matchIfMissing = true)
    public SchemaInitializer p6SchemaInitializer(DataSource dataSource) {
        return new SchemaInitializer(dataSource, List.of(SCHEMA));
    }

    @Bean
    public RequisitionChangeStore p6RequisitionChangeStore(JdbcTemplate jdbc) {
        return new RequisitionChangeStore(jdbc);
    }

    @Bean
    @ConditionalOnMissingBean(RequisitionPushPort.class)
    public RequisitionPushPort p6RequisitionPushPort(ObjectMapper mapper, JobsS6Properties s6, JobsP5Properties p5) {
        JobsS6Properties.Requisitions r = s6.getRequisitions();
        if ("REST".equalsIgnoreCase(r.getPushMode())) {
            JobsP5Properties.Oracle o = p5.getOracle();
            if (r.getPushCreateUrl() == null || r.getPushUpdateUrl() == null || o.getUsername() == null || o.getPassword() == null) {
                throw new IllegalStateException("digihire.s6.requisitions.push-mode=REST needs push-create-url, push-update-url and Oracle credentials");
            }
            return new RestOracleRequisitionPush(mapper, r.getPushCreateUrl(), r.getPushUpdateUrl(), o.getUsername(), o.getPassword(),
                    r.getPushFieldMap(), Duration.ofSeconds(p5.getTimeoutSeconds()));
        }
        return new StubRequisitionPush();
    }

    @Bean
    public LocalOverrideSink p6LocalOverrideSink(RequisitionChangeStore p6RequisitionChangeStore, RequisitionStore p5RequisitionStore) {
        return new LocalOverrideSink(p6RequisitionChangeStore, p5RequisitionStore);
    }

    @Bean
    public RequisitionChangeService p6RequisitionChangeService(RequisitionStore p5RequisitionStore, RequisitionChangeStore p6RequisitionChangeStore,
                                                               ListingService p5ListingService, RequisitionPushPort push, JdbcTemplate jdbc,
                                                               TransactionTemplate p5TransactionTemplate, AuditRecorder audit,
                                                               BusinessClock clock, ObjectMapper mapper, JobsS6Properties s6) {
        JobsS6Properties.Requisitions r = s6.getRequisitions();
        return new RequisitionChangeService(p5RequisitionStore, p6RequisitionChangeStore, p5ListingService, push,
                new RequisitionFileReader(r.getMaxRows(), r.getMaxUploadBytes()), jdbc, p5TransactionTemplate, audit, clock, mapper,
                new RequisitionChangeService.Settings(r.getMaxOpenings(), r.getMaxValidDays(), r.isPushLocalToOracle()));
    }

    @Bean
    public IdempotentExecutor p6IdempotentExecutor(JdbcTemplate jdbc, Clock p5Clock, ObjectMapper mapper, JobsS6Properties s6) {
        return new IdempotentExecutor(new IdempotencyStore(jdbc, p5Clock, "job_p6_idempotency",
                Duration.ofHours(s6.getRequisitions().getIdempotencyTtlHours()), Duration.ofSeconds(120)), mapper);
    }
}
