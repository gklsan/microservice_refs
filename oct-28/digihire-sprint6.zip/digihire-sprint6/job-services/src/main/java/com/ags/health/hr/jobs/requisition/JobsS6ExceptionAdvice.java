package com.ags.health.hr.jobs.requisition;

import com.ags.health.hr.jobs.p5shared.JobsP5ExceptionAdvice;
import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.web.bind.annotation.RestControllerAdvice;

@Order(Ordered.HIGHEST_PRECEDENCE)
@RestControllerAdvice(basePackages = {"com.ags.health.hr.jobs.requisition", "com.ags.health.hr.jobs.ops"})
public class JobsS6ExceptionAdvice extends JobsP5ExceptionAdvice {
}
