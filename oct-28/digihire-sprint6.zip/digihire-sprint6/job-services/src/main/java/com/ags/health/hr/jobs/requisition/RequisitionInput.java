package com.ags.health.hr.jobs.requisition;

import java.time.LocalDate;

public record RequisitionInput(int rowNo, String action, String requisitionId, String title, String lob, String location, String orcId,
                               String roleCode, Integer openings, LocalDate validTo, String recruiterId, String status) {

    public RequisitionInput withRow(int row) {
        return new RequisitionInput(row, action, requisitionId, title, lob, location, orcId, roleCode, openings, validTo, recruiterId, status);
    }
}
