package com.ags.health.hr.jobs.requisition;

import org.springframework.dao.DuplicateKeyException;
import org.springframework.jdbc.core.JdbcTemplate;

import java.sql.Timestamp;
import java.time.Instant;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;

public class RequisitionChangeStore {

    private final JdbcTemplate jdbc;

    public RequisitionChangeStore(JdbcTemplate jdbc) {
        this.jdbc = jdbc;
    }

    public void startUpload(String id, String fileName, boolean dryRun, int total, String actor, Instant at) {
        jdbc.update("INSERT INTO job_p6_upload (id, file_name, dry_run, total, created_by, created_at) VALUES (?, ?, ?, ?, ?, ?)", id,
                fileName == null ? null : fileName.length() > 190 ? fileName.substring(0, 190) : fileName, dryRun, total, actor, Timestamp.from(at));
    }

    public void finishUpload(String id, int applied, int pending, int rejected, Instant at) {
        jdbc.update("UPDATE job_p6_upload SET applied = ?, pending = ?, rejected = ?, finished_at = ? WHERE id = ?", applied, pending, rejected,
                Timestamp.from(at), id);
    }

    public void change(String uploadId, int rowNo, String requisitionId, String action, String status, String changes, String message,
                       String externalRef, String actor, Instant at) {
        jdbc.update("INSERT INTO job_p6_requisition_change (id, upload_id, row_no, requisition_id, action, status, changes, message, "
                        + "external_ref, actor_id, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)", UUID.randomUUID().toString(), uploadId,
                rowNo, requisitionId, action, status, cut(changes, 3990), cut(message, 990), externalRef, actor, Timestamp.from(at));
    }

    public Map<String, Object> upload(String id) {
        List<Map<String, Object>> rows = jdbc.queryForList("SELECT id, file_name, dry_run, total, applied, pending, rejected, created_by, "
                + "created_at, finished_at FROM job_p6_upload WHERE id = ?", id);
        return rows.isEmpty() ? null : rows.get(0);
    }

    public List<Map<String, Object>> uploadRows(String uploadId) {
        return jdbc.queryForList("SELECT row_no, requisition_id, action, status, changes, message, external_ref FROM job_p6_requisition_change "
                + "WHERE upload_id = ? ORDER BY row_no", uploadId);
    }

    public List<Map<String, Object>> history(String requisitionId, int limit) {
        return jdbc.queryForList("SELECT upload_id, row_no, action, status, changes, message, external_ref, actor_id, created_at "
                + "FROM job_p6_requisition_change WHERE requisition_id = ? ORDER BY created_at DESC LIMIT ?", requisitionId, limit);
    }

    public void override(String requisitionId, String field, String value, String actor, Instant at) {
        int n = jdbc.update("UPDATE job_p6_requisition_override SET field_value = ?, set_by = ?, set_at = ? WHERE requisition_id = ? AND field_name = ?",
                value, actor, Timestamp.from(at), requisitionId, field);
        if (n == 0) {
            try {
                jdbc.update("INSERT INTO job_p6_requisition_override (requisition_id, field_name, field_value, set_by, set_at) VALUES (?, ?, ?, ?, ?)",
                        requisitionId, field, value, actor, Timestamp.from(at));
            } catch (DuplicateKeyException e) {
                jdbc.update("UPDATE job_p6_requisition_override SET field_value = ?, set_by = ?, set_at = ? WHERE requisition_id = ? AND field_name = ?",
                        value, actor, Timestamp.from(at), requisitionId, field);
            }
        }
    }

    public Optional<String> overrideValue(String requisitionId, String field) {
        return jdbc.queryForList("SELECT field_value FROM job_p6_requisition_override WHERE requisition_id = ? AND field_name = ?", String.class,
                requisitionId, field).stream().findFirst();
    }

    private static String cut(String v, int max) {
        return v == null ? null : v.length() > max ? v.substring(0, max) : v;
    }
}
