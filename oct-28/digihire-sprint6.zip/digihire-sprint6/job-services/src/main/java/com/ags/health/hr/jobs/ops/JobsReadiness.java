package com.ags.health.hr.jobs.ops;

import com.ags.health.hr.common.platform.caller.Caller;
import com.ags.health.hr.common.platform.caller.CallerProvider;
import com.ags.health.hr.common.platform.caller.InternalKeyVerifier;
import com.ags.health.hr.common.platform.db.JdbcValues;
import com.ags.health.hr.common.platform.error.PlatformException;
import com.ags.health.hr.common.platform.readiness.Checks;
import com.ags.health.hr.common.platform.readiness.ReadinessCheck;
import com.ags.health.hr.common.platform.readiness.ReadinessReport;
import com.ags.health.hr.common.platform.readiness.ReadinessResult;
import com.ags.health.hr.common.platform.readiness.ReadinessService;
import com.ags.health.hr.jobs.p5shared.JobsP5Properties;
import com.ags.health.hr.jobs.requisition.JobsS6Properties;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.time.Clock;
import java.time.Duration;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;

@ConditionalOnProperty(prefix = "digihire.s6.readiness", name = "enabled", havingValue = "true", matchIfMissing = true)
@RestController
public class JobsReadiness {

    private final ReadinessService service;
    private final CallerProvider callers;
    private final InternalKeyVerifier internal;

    public JobsReadiness(JdbcTemplate jdbc, JobsP5Properties p5, JobsS6Properties s6, Clock p5Clock, CallerProvider callers,
                         InternalKeyVerifier internal) {
        this.service = new ReadinessService(p5.getServiceName(), s6.getEnvironment(), checks(jdbc, p5, s6, p5Clock),
                Duration.ofSeconds(s6.getReadiness().getTimeoutSeconds()), p5Clock);
        this.callers = callers;
        this.internal = internal;
    }

    public static List<ReadinessCheck> checks(JdbcTemplate jdbc, JobsP5Properties p5, JobsS6Properties s6, Clock clock) {
        boolean prod = s6.getEnvironment() != null && s6.getEnvironment().toLowerCase(Locale.ROOT).startsWith("prod");
        List<ReadinessCheck> c = new ArrayList<>();
        c.add(Checks.database(jdbc));
        c.add(Checks.tables(jdbc, List.of("job_p5_requisition", "job_p5_sync_run", "job_p5_sync_failure", "job_p5_lob", "job_p6_upload",
                "job_p6_requisition_change", "job_p6_requisition_override", "job_p6_idempotency", "audit_log")));
        c.add(Checks.setting("jwt-secret", "security", p5.getJwtSecret(), true, "JWT_SECRET"));
        c.add(Checks.setting("internal-key", "security", p5.getInternalKey(), true, "Internal service key"));
        c.add(Checks.notStub("oracle-requisitions", "integration", p5.getOracle().getMode(), prod));
        c.add(Checks.notStub("oracle-push", "integration", s6.getRequisitions().getPushMode(), false));
        c.add(Checks.backlog("sync-parked", "integration", () -> {
            Long n = jdbc.queryForObject("SELECT count(*) FROM job_p5_sync_failure WHERE status = 'PARKED'", Long.class);
            return n == null ? 0 : n;
        }, 1, 25));
        c.add(Checks.of("last-sync", "integration", () -> lastSync(jdbc, clock, s6.getReadiness().getSyncMaxAgeMinutes(), prod)));
        return c;
    }

    static ReadinessResult lastSync(JdbcTemplate jdbc, Clock clock, int maxAgeMinutes, boolean prod) {
        List<Map<String, Object>> rows = jdbc.queryForList("SELECT status, started_at, error FROM job_p5_sync_run WHERE kind = 'ORACLE_REQUISITION' "
                + "ORDER BY started_at DESC LIMIT 1");
        if (rows.isEmpty()) {
            return prod ? ReadinessResult.fail("No requisition sync has run") : ReadinessResult.warn("No requisition sync has run");
        }
        Map<String, Object> r = rows.get(0);
        Instant at = JdbcValues.instant(r.get("started_at"));
        String status = String.valueOf(r.get("status"));
        Map<String, Object> d = Map.of("status", status, "at", String.valueOf(at));
        if (at.isBefore(clock.instant().minus(Duration.ofMinutes(maxAgeMinutes)))) {
            return ReadinessResult.warn("Last sync is older than " + maxAgeMinutes + " minutes").with(d);
        }
        return "FAILED".equalsIgnoreCase(status) ? ReadinessResult.fail("Last sync failed: " + r.get("error")).with(d)
                : ReadinessResult.pass("Last sync " + status).with(d);
    }

    @GetMapping("/ops/readiness")
    public ReadinessReport readiness() {
        Caller c = callers.require();
        if (!c.has("OPS:READINESS")) {
            throw PlatformException.forbidden("PERMISSION_DENIED", "Missing permission OPS:READINESS");
        }
        return service.run();
    }

    @GetMapping("/internal/readiness")
    public ResponseEntity<ReadinessReport> internalReadiness(HttpServletRequest request) {
        internal.require(request);
        ReadinessReport r = service.run();
        return ResponseEntity.status(r.overall() == ReadinessResult.Status.FAIL ? HttpStatus.SERVICE_UNAVAILABLE : HttpStatus.OK).body(r);
    }
}
