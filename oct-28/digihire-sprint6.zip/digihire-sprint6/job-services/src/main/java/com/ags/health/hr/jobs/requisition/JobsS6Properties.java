package com.ags.health.hr.jobs.requisition;

import lombok.Getter;
import lombok.Setter;
import org.springframework.boot.context.properties.ConfigurationProperties;

import java.util.LinkedHashMap;
import java.util.Map;

@Getter
@Setter
@ConfigurationProperties(prefix = "digihire.s6")
public class JobsS6Properties {

    private boolean schemaInit = true;
    private String environment = "dev";
    private Requisitions requisitions = new Requisitions();
    private Readiness readiness = new Readiness();

    @Getter
    @Setter
    public static class Requisitions {
        private boolean enabled = true;
        private int maxRows = 500;
        private long maxUploadBytes = 2L * 1024 * 1024;
        private int maxOpenings = 500;
        private int maxValidDays = 365;
        private boolean pushLocalToOracle = false;
        private String pushMode = "STUB";
        private String pushCreateUrl;
        private String pushUpdateUrl;
        private Map<String, String> pushFieldMap = new LinkedHashMap<>();
        private int idempotencyTtlHours = 24;
    }

    @Getter
    @Setter
    public static class Readiness {
        private boolean enabled = true;
        private int timeoutSeconds = 10;
        private int syncMaxAgeMinutes = 60;
    }
}
