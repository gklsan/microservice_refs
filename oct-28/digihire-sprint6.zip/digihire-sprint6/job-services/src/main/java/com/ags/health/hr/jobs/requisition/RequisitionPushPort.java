package com.ags.health.hr.jobs.requisition;

import com.ags.health.hr.jobs.listing.RequisitionRecord;

import java.util.Map;

public interface RequisitionPushPort {

    record PushResult(boolean pushed, String externalRef, String message) {
    }

    String mode();

    PushResult create(RequisitionRecord record);

    PushResult update(String requisitionId, Map<String, Object> changes);
}
