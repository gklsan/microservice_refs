package com.ags.health.hr.jobs.requisition;

import com.ags.health.hr.common.platform.caller.Caller;
import com.ags.health.hr.common.platform.caller.CallerProvider;
import com.ags.health.hr.common.platform.concurrency.IdempotentExecutor;
import com.ags.health.hr.common.platform.error.PlatformException;
import com.ags.health.hr.common.platform.export.XlsxReportWriter;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.time.LocalDate;
import java.util.List;
import java.util.Map;

@ConditionalOnProperty(prefix = "digihire.s6.requisitions", name = "enabled", havingValue = "true", matchIfMissing = true)
@RestController
public class RequisitionController {

    public record RequisitionBody(String requisitionId, String title, String lob, String location, String orcId, String roleCode,
                                  Integer openings, LocalDate validTo, String recruiterId, String status) {

        RequisitionInput input() {
            return new RequisitionInput(0, null, requisitionId, title, lob, location, orcId, roleCode, openings, validTo, recruiterId,
                    status == null ? null : status.trim().toUpperCase(java.util.Locale.ROOT));
        }
    }

    private final RequisitionChangeService service;
    private final IdempotentExecutor idempotent;
    private final CallerProvider callers;

    public RequisitionController(RequisitionChangeService service, IdempotentExecutor idempotent, CallerProvider callers) {
        this.service = service;
        this.idempotent = idempotent;
        this.callers = callers;
    }

    @PostMapping(value = "/requisition-uploads", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public RequisitionChangeService.UploadResult upload(@RequestParam MultipartFile file, @RequestParam(defaultValue = "false") boolean dryRun) {
        try {
            return service.upload(callers.require(), file.getOriginalFilename(), file.getBytes(), dryRun);
        } catch (IOException e) {
            throw PlatformException.badRequest("FILE_UNREADABLE", "Uploaded file could not be read");
        }
    }

    @GetMapping("/requisition-uploads/template")
    public ResponseEntity<byte[]> template() {
        callers.require();
        return ResponseEntity.ok().contentType(MediaType.parseMediaType(XlsxReportWriter.contentType()))
                .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"requisition-upload-template.xlsx\"").body(service.template());
    }

    @GetMapping("/requisition-uploads/{uploadId}")
    public Map<String, Object> upload(@PathVariable String uploadId) {
        return service.upload(callers.require(), uploadId);
    }

    @PostMapping("/requisitions")
    public RequisitionChangeService.RowResult create(@RequestHeader(value = IdempotentExecutor.HEADER, required = false) String key,
                                                     @RequestBody RequisitionBody body) {
        Caller c = callers.require();
        return idempotent.run(c.userId(), key, "/requisitions", body, RequisitionChangeService.RowResult.class,
                () -> service.create(c, body.input()));
    }

    @PatchMapping("/requisitions/{requisitionId}")
    public RequisitionChangeService.RowResult modify(@RequestHeader(value = IdempotentExecutor.HEADER, required = false) String key,
                                                     @PathVariable String requisitionId, @RequestBody RequisitionBody body) {
        Caller c = callers.require();
        return idempotent.run(c.userId(), key, "/requisitions/" + requisitionId, body, RequisitionChangeService.RowResult.class,
                () -> service.modify(c, requisitionId, body.input()));
    }

    @GetMapping("/requisitions/{requisitionId}/change-history")
    public List<Map<String, Object>> history(@PathVariable String requisitionId) {
        return service.history(callers.require(), requisitionId);
    }
}
