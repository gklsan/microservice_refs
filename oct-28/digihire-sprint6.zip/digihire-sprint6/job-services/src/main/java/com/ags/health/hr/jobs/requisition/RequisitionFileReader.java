package com.ags.health.hr.jobs.requisition;

import com.ags.health.hr.common.platform.error.PlatformException;
import com.ags.health.hr.common.platform.export.XlsxSheetReader;

import java.nio.charset.StandardCharsets;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeFormatterBuilder;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public class RequisitionFileReader {

    public static final List<String> HEADERS = List.of("Action", "Requisition Id", "Title", "LOB", "Location", "ORC Id", "Role", "Openings",
            "Valid To", "Recruiter Id", "Status");

    public record Parsed(List<RequisitionInput> rows, List<String> problems) {
    }

    private static final List<DateTimeFormatter> DATES = List.of(DateTimeFormatter.ISO_LOCAL_DATE,
            new DateTimeFormatterBuilder().parseCaseInsensitive().appendPattern("dd-MMM-yyyy").toFormatter(Locale.ENGLISH),
            DateTimeFormatter.ofPattern("dd-MM-yyyy"), DateTimeFormatter.ofPattern("dd/MM/yyyy"));

    private final int maxRows;
    private final long maxBytes;

    public RequisitionFileReader(int maxRows, long maxBytes) {
        this.maxRows = maxRows;
        this.maxBytes = maxBytes;
    }

    public Parsed read(String fileName, byte[] content) {
        if (content == null || content.length == 0) {
            throw PlatformException.badRequest("FILE_EMPTY", "The uploaded file is empty");
        }
        if (content.length > maxBytes) {
            throw PlatformException.badRequest("FILE_TOO_LARGE", "File is larger than " + maxBytes + " bytes");
        }
        String name = fileName == null ? "" : fileName.toLowerCase(Locale.ROOT);
        List<List<String>> table;
        boolean excel = name.endsWith(".xlsx");
        try {
            if (excel) {
                table = new XlsxSheetReader(maxBytes * 20, maxRows + 1).firstSheet(content);
            } else if (name.endsWith(".csv")) {
                table = csv(new String(content, StandardCharsets.UTF_8));
            } else {
                throw PlatformException.badRequest("FILE_TYPE", "Upload a .xlsx or .csv file");
            }
        } catch (IllegalArgumentException e) {
            throw PlatformException.badRequest("FILE_UNREADABLE", e.getMessage());
        }
        if (table.isEmpty()) {
            throw PlatformException.badRequest("FILE_EMPTY", "The file has no header row");
        }
        Map<String, Integer> idx = header(table.get(0));
        List<String> missing = new ArrayList<>();
        for (String h : List.of("Action", "Requisition Id")) {
            if (!idx.containsKey(key(h))) {
                missing.add(h);
            }
        }
        if (!missing.isEmpty()) {
            throw PlatformException.badRequest("HEADER_MISSING", "Missing columns: " + String.join(", ", missing));
        }
        if (table.size() - 1 > maxRows) {
            throw PlatformException.badRequest("TOO_MANY_ROWS", "At most " + maxRows + " rows per upload");
        }
        List<RequisitionInput> rows = new ArrayList<>();
        List<String> problems = new ArrayList<>();
        for (int i = 1; i < table.size(); i++) {
            List<String> r = table.get(i);
            if (r.stream().allMatch(c -> c == null || c.isBlank())) {
                continue;
            }
            int rowNo = i + 1;
            try {
                rows.add(new RequisitionInput(rowNo, upper(cell(r, idx, "Action")), cell(r, idx, "Requisition Id"), cell(r, idx, "Title"),
                        cell(r, idx, "LOB"), cell(r, idx, "Location"), cell(r, idx, "ORC Id"), cell(r, idx, "Role"),
                        integer(cell(r, idx, "Openings")), date(cell(r, idx, "Valid To"), excel), cell(r, idx, "Recruiter Id"),
                        upper(cell(r, idx, "Status"))));
            } catch (IllegalArgumentException e) {
                problems.add("Row " + rowNo + ": " + e.getMessage());
            }
        }
        return new Parsed(rows, problems);
    }

    private static Map<String, Integer> header(List<String> row) {
        Map<String, Integer> m = new HashMap<>();
        for (int i = 0; i < row.size(); i++) {
            if (row.get(i) != null && !row.get(i).isBlank()) {
                m.put(key(row.get(i)), i);
            }
        }
        return m;
    }

    private static String key(String h) {
        return h.replaceAll("[^A-Za-z0-9]", "").toLowerCase(Locale.ROOT);
    }

    private static String cell(List<String> r, Map<String, Integer> idx, String header) {
        Integer i = idx.get(key(header));
        if (i == null || i >= r.size()) {
            return null;
        }
        String v = r.get(i);
        if (v == null || v.isBlank()) {
            return null;
        }
        v = v.trim();
        if (v.startsWith("'") && v.length() > 1 && "=+-@".indexOf(v.charAt(1)) >= 0) {
            v = v.substring(1);
        }
        if (!v.isEmpty() && "=+-@".indexOf(v.charAt(0)) >= 0 && !v.matches("-?\\d+(\\.\\d+)?")) {
            throw new IllegalArgumentException(header + " looks like a formula");
        }
        return v;
    }

    private static Integer integer(String v) {
        if (v == null) {
            return null;
        }
        try {
            double d = Double.parseDouble(v);
            if (d != Math.floor(d)) {
                throw new IllegalArgumentException("Openings must be a whole number");
            }
            return (int) d;
        } catch (NumberFormatException e) {
            throw new IllegalArgumentException("Openings must be a number");
        }
    }

    private static LocalDate date(String v, boolean excel) {
        if (v == null) {
            return null;
        }
        if (excel && v.matches("\\d+(\\.\\d+)?")) {
            return XlsxSheetReader.dateFromSerial(v);
        }
        for (DateTimeFormatter f : DATES) {
            try {
                return LocalDate.parse(v, f);
            } catch (DateTimeParseException ignored) {
                continue;
            }
        }
        throw new IllegalArgumentException("Valid To must be a date like 2026-12-31 or 31-Dec-2026");
    }

    private static String upper(String v) {
        return v == null ? null : v.toUpperCase(Locale.ROOT);
    }

    static List<List<String>> csv(String text) {
        List<List<String>> rows = new ArrayList<>();
        List<String> row = new ArrayList<>();
        StringBuilder cur = new StringBuilder();
        boolean quoted = false;
        String s = text.startsWith("﻿") ? text.substring(1) : text;
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (quoted) {
                if (c == '"' && i + 1 < s.length() && s.charAt(i + 1) == '"') {
                    cur.append('"');
                    i++;
                } else if (c == '"') {
                    quoted = false;
                } else {
                    cur.append(c);
                }
            } else if (c == '"') {
                quoted = true;
            } else if (c == ',') {
                row.add(cur.toString());
                cur.setLength(0);
            } else if (c == '\n' || c == '\r') {
                if (c == '\r' && i + 1 < s.length() && s.charAt(i + 1) == '\n') {
                    i++;
                }
                row.add(cur.toString());
                cur.setLength(0);
                rows.add(row);
                row = new ArrayList<>();
            } else {
                cur.append(c);
            }
        }
        if (cur.length() > 0 || !row.isEmpty()) {
            row.add(cur.toString());
            rows.add(row);
        }
        return rows;
    }
}
