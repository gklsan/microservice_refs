package com.ags.health.hr.jobs.requisition;

import com.ags.health.hr.jobs.listing.RequisitionRecord;

import java.util.Map;

public class StubRequisitionPush implements RequisitionPushPort {

    @Override
    public String mode() {
        return "STUB";
    }

    @Override
    public PushResult create(RequisitionRecord record) {
        return new PushResult(false, null, "Oracle push is not configured");
    }

    @Override
    public PushResult update(String requisitionId, Map<String, Object> changes) {
        return new PushResult(false, null, "Oracle push is not configured");
    }
}
