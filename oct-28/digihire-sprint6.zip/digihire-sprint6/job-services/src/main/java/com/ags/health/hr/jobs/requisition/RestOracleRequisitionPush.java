package com.ags.health.hr.jobs.requisition;

import com.ags.health.hr.jobs.listing.RequisitionRecord;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.Base64;
import java.util.LinkedHashMap;
import java.util.Map;

public class RestOracleRequisitionPush implements RequisitionPushPort {

    private final HttpClient client;
    private final ObjectMapper mapper;
    private final String createUrl;
    private final String updateUrl;
    private final String auth;
    private final Map<String, String> fieldMap;
    private final Duration timeout;

    public RestOracleRequisitionPush(ObjectMapper mapper, String createUrl, String updateUrl, String username, String password,
                                     Map<String, String> fieldMap, Duration timeout) {
        this.client = HttpClient.newBuilder().connectTimeout(timeout).build();
        this.mapper = mapper;
        this.createUrl = createUrl;
        this.updateUrl = updateUrl;
        this.auth = "Basic " + Base64.getEncoder().encodeToString((username + ":" + password).getBytes(StandardCharsets.UTF_8));
        this.fieldMap = fieldMap == null ? Map.of() : Map.copyOf(fieldMap);
        this.timeout = timeout;
    }

    @Override
    public String mode() {
        return "REST";
    }

    @Override
    public PushResult create(RequisitionRecord r) {
        Map<String, Object> body = new LinkedHashMap<>();
        put(body, "requisitionId", r.requisitionId());
        put(body, "title", r.title());
        put(body, "lob", r.lob());
        put(body, "location", r.location());
        put(body, "orcId", r.orcId());
        put(body, "roleCode", r.roleCode());
        put(body, "openings", r.openings());
        put(body, "validTo", r.validTo() == null ? null : r.validTo().toString());
        put(body, "recruiterId", r.recruiterId());
        put(body, "status", r.status());
        return send("POST", createUrl, body);
    }

    @Override
    public PushResult update(String requisitionId, Map<String, Object> changes) {
        Map<String, Object> body = new LinkedHashMap<>();
        changes.forEach((k, v) -> put(body, k, v));
        return send("PATCH", updateUrl.replace("{id}", java.net.URLEncoder.encode(requisitionId, StandardCharsets.UTF_8)), body);
    }

    private void put(Map<String, Object> body, String field, Object value) {
        if (value != null) {
            body.put(fieldMap.getOrDefault(field, field), value);
        }
    }

    private PushResult send(String method, String url, Map<String, Object> body) {
        try {
            HttpRequest req = HttpRequest.newBuilder(URI.create(url)).timeout(timeout).header("Authorization", auth)
                    .header("Content-Type", "application/json").header("Accept", "application/json")
                    .method(method, HttpRequest.BodyPublishers.ofByteArray(mapper.writeValueAsBytes(body))).build();
            HttpResponse<String> res = client.send(req, HttpResponse.BodyHandlers.ofString());
            if (res.statusCode() / 100 == 2) {
                String ref = null;
                if (res.body() != null && !res.body().isBlank()) {
                    JsonNode n = mapper.readTree(res.body());
                    JsonNode id = n.has("RequisitionId") ? n.get("RequisitionId") : n.get("id");
                    ref = id == null || id.isNull() ? null : id.asText();
                }
                return new PushResult(true, ref, "HTTP " + res.statusCode());
            }
            String text = res.body() == null ? "" : res.body();
            return new PushResult(false, null, "Oracle answered HTTP " + res.statusCode() + ": " + (text.length() > 300 ? text.substring(0, 300) : text));
        } catch (IOException e) {
            return new PushResult(false, null, "Oracle push failed: " + e.getMessage());
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            return new PushResult(false, null, "Interrupted");
        }
    }
}
