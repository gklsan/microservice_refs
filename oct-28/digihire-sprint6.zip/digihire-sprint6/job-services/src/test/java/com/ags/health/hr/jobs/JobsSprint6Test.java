package com.ags.health.hr.jobs;

import com.ags.health.hr.common.platform.audit.AuditRecorder;
import com.ags.health.hr.common.platform.audit.SharedAuditLogSink;
import com.ags.health.hr.common.platform.caller.Caller;
import com.ags.health.hr.common.platform.error.PlatformException;
import com.ags.health.hr.common.platform.export.ReportTable;
import com.ags.health.hr.common.platform.export.XlsxReportWriter;
import com.ags.health.hr.common.platform.export.XlsxSheetReader;
import com.ags.health.hr.common.platform.readiness.ReadinessCheck;
import com.ags.health.hr.common.platform.readiness.ReadinessResult;
import com.ags.health.hr.common.platform.time.BusinessClock;
import com.ags.health.hr.jobs.listing.JobVisibilityPolicy;
import com.ags.health.hr.jobs.listing.ListingService;
import com.ags.health.hr.jobs.listing.LocalPublicationPort;
import com.ags.health.hr.jobs.listing.PublicationStore;
import com.ags.health.hr.jobs.listing.RequisitionRecord;
import com.ags.health.hr.jobs.listing.RequisitionStore;
import com.ags.health.hr.jobs.ops.JobsReadiness;
import com.ags.health.hr.jobs.p5shared.JobsP5Properties;
import com.ags.health.hr.jobs.requisition.JobsS6Properties;
import com.ags.health.hr.jobs.requisition.LocalOverrideSink;
import com.ags.health.hr.jobs.requisition.RequisitionChangeService;
import com.ags.health.hr.jobs.requisition.RequisitionChangeStore;
import com.ags.health.hr.jobs.requisition.RequisitionFileReader;
import com.ags.health.hr.jobs.requisition.RequisitionInput;
import com.ags.health.hr.jobs.requisition.RequisitionPushPort;
import com.ags.health.hr.jobs.sync.FieldMapping;
import com.ags.health.hr.jobs.sync.RequisitionSyncService;
import com.ags.health.hr.jobs.sync.StubOracleRequisitionSource;
import com.ags.health.hr.jobs.sync.SyncStore;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.transaction.support.TransactionTemplate;

import java.io.ByteArrayOutputStream;
import java.nio.charset.StandardCharsets;
import java.time.Clock;
import java.time.Instant;
import java.time.LocalDate;
import java.time.ZoneId;
import java.time.ZoneOffset;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

class JobsSprint6Test {

    private static final Instant NOW = Instant.parse("2026-11-30T05:30:00Z");
    private final ObjectMapper mapper = new ObjectMapper();
    private final Clock clock = Clock.fixed(NOW, ZoneOffset.UTC);
    private final BusinessClock business = new BusinessClock(clock, ZoneId.of("Asia/Kolkata"));
    private JdbcTemplate jdbc;
    private RequisitionStore store;
    private ListingService listing;
    private RequisitionChangeStore changes;
    private RequisitionChangeService service;
    private TransactionTemplate tx;
    private AuditRecorder audit;
    private final List<String> pushed = new ArrayList<>();
    private boolean oracleUp = false;

    private final RequisitionPushPort push = new RequisitionPushPort() {
        public String mode() {
            return "TEST";
        }

        public PushResult create(RequisitionRecord r) {
            pushed.add("create:" + r.requisitionId());
            return new PushResult(oracleUp, oracleUp ? "ORC-" + r.requisitionId() : null, oracleUp ? "ok" : "down");
        }

        public PushResult update(String id, Map<String, Object> changes) {
            pushed.add("update:" + id + ":" + changes.keySet());
            return new PushResult(oracleUp, null, oracleUp ? "ok" : "Oracle unavailable");
        }
    };

    private static Caller tl(String id, Set<String> lobs, String... perms) {
        return new Caller(id, id + "@agshealth.com", id, Set.of("RECRUITMENT_MANAGER"), Set.of(perms), Set.of(), lobs.isEmpty() ? "ALL" : "LOB", Set.of(),
                lobs, Set.of(), false);
    }

    @BeforeEach
    void setUp() {
        DriverManagerDataSource ds = TestDatabase.create("jobs6", List.of("db/p5/job-p5-schema.sql", "db/p6/job-p6-schema.sql"));
        jdbc = new JdbcTemplate(ds);
        tx = new TransactionTemplate(new DataSourceTransactionManager(ds));
        audit = new AuditRecorder(List.of(SharedAuditLogSink.create(jdbc, mapper, "audit_log", 4000)), Optional::empty, "job-services", clock);
        store = new RequisitionStore(jdbc);
        listing = new ListingService(store, new PublicationStore(jdbc), List.of(new LocalPublicationPort("CAREER_PAGE")), new JobVisibilityPolicy(),
                audit, business);
        changes = new RequisitionChangeStore(jdbc);
        service = new RequisitionChangeService(store, changes, listing, push, new RequisitionFileReader(500, 2_000_000), jdbc, tx, audit, business,
                mapper, new RequisitionChangeService.Settings(500, 365, false));
        store.upsert(new RequisitionRecord("ORA-1", "JOB-1", "Analyst", "LOB1", "Chennai", "ORC-1", "AR", "OPEN", 5, 2,
                LocalDate.of(2027, 1, 31), "rec1", null, 0, "ORACLE", NOW, true, null, NOW));
    }

    @Test
    void csvUploadCreatesUpdatesAndRejectsRowByRow() {
        String csv = "Action,Requisition Id,Title,LOB,Location,ORC Id,Role,Openings,Valid To,Recruiter Id,Status\r\n"
                + "CREATE,,\"Analyst, AR\",LOB1,Chennai,ORC-9,AR,4,31-Jan-2027,,\r\n"
                + "CREATE,NEW-2,Coder,LOB1,Trichy,,CODER,0,2027-01-31,,\r\n"
                + "UPDATE,ORA-1,,,,,,1,,,\r\n"
                + "UPDATE,ORA-1,Renamed,,,,,,,,\r\n"
                + "UPDATE,ORA-1,,,,,,,,rec9,\r\n"
                + "DELETE,ORA-1,,,,,,,,,\r\n"
                + "CREATE,NEW-3,=cmd(),LOB1,Chennai,,AR,1,2027-01-31,,\r\n";
        Caller lead = tl("tl1", Set.of(), "REQUISITION:UPLOAD", "REQUISITION:MODIFY");
        RequisitionChangeService.UploadResult r = service.upload(lead, "reqs.csv", csv.getBytes(StandardCharsets.UTF_8), false);
        assertThat(r.rows()).extracting(RequisitionChangeService.RowResult::outcome)
                .containsExactly("APPLIED", "REJECTED", "REJECTED", "REJECTED", "APPLIED", "REJECTED");
        assertThat(r.fileProblems()).hasSize(1).first().asString().contains("Row 8").contains("formula");
        assertThat(r.rows().get(0).requisitionId()).startsWith("DH-261130-");
        assertThat(r.rows().get(1).message()).contains("Openings must be between 1 and 500");
        assertThat(r.rows().get(2).message()).contains("below the 2 already filled");
        assertThat(r.rows().get(3).message()).contains("owned by Oracle can not be changed here: title");
        assertThat(store.find(r.rows().get(0).requisitionId()).orElseThrow().title()).isEqualTo("Analyst, AR");
        assertThat(store.find("ORA-1").orElseThrow().recruiterId()).isEqualTo("rec9");
        assertThat(service.upload(lead, r.uploadId()).get("rows")).asList().hasSize(6);
    }

    @Test
    void oracleOwnedNumbersWaitForOracleButRecruiterChangesApplyAndSurviveSync() {
        Caller lead = tl("tl1", Set.of("LOB1"), "REQUISITION:MODIFY");
        RequisitionChangeService.RowResult r = service.modify(lead, "ORA-1", new RequisitionInput(0, null, null, null, null, null, null, null,
                8, null, "rec7", null));
        assertThat(r.outcome()).isEqualTo("PENDING_PUSH");
        assertThat(pushed).containsExactly("update:ORA-1:[openings]");
        RequisitionRecord now = store.find("ORA-1").orElseThrow();
        assertThat(now.openings()).isEqualTo(5);
        assertThat(now.recruiterId()).isEqualTo("rec7");
        oracleUp = true;
        assertThat(service.modify(lead, "ORA-1", new RequisitionInput(0, null, null, null, null, null, null, null, 8, null, null, null)).outcome())
                .isEqualTo("APPLIED");
        assertThat(store.find("ORA-1").orElseThrow().openings()).isEqualTo(8);
        StubOracleRequisitionSource oracle = new StubOracleRequisitionSource();
        ObjectNode n = mapper.createObjectNode();
        n.put("RequisitionNumber", "ORA-1").put("RequisitionId", "ORC1").put("Title", "Analyst").put("OrganizationName", "LOB1")
                .put("PrimaryLocation", "Chennai").put("CurrentPhaseCode", "OPEN").put("NumberOfOpenings", 8).put("HiredCount", 2)
                .put("LastUpdateDate", "2026-11-30T00:00:00Z").put("JobFamilyName", "AR").put("RecruiterPersonNumber", "rec1");
        oracle.add(n);
        new RequisitionSyncService(oracle, new FieldMapping(Map.of()), new SyncStore(jdbc), store, listing, List.of(new LocalOverrideSink(changes, store)),
                tx, audit, mapper, clock, new RequisitionSyncService.Settings(25, 10, 3)).run(true, "test");
        assertThat(store.find("ORA-1").orElseThrow().recruiterId()).isEqualTo("rec7");
        assertThat(service.history(lead, "ORA-1")).hasSize(2);
    }

    @Test
    void scopeAndPermissionAreEnforced() {
        Caller otherLob = tl("tl2", Set.of("LOB9"), "REQUISITION:MODIFY", "REQUISITION:UPLOAD");
        assertThatThrownBy(() -> service.modify(otherLob, "ORA-1", new RequisitionInput(0, null, null, null, null, null, null, null, 6, null, null, null)))
                .isInstanceOf(PlatformException.class).hasMessageContaining("outside your LOB scope");
        Caller viewer = tl("rec", Set.of(), "JOB:VIEW");
        assertThatThrownBy(() -> service.create(viewer, new RequisitionInput(0, null, "X-1", "T", "LOB1", "Chennai", null, "AR", 1,
                LocalDate.of(2027, 1, 1), null, null))).hasMessageContaining("REQUISITION:UPLOAD");
        jdbc.update("INSERT INTO job_p5_lob (code, name, active, updated_at) VALUES ('LOB1', 'Lob one', TRUE, CURRENT_TIMESTAMP)");
        Caller all = tl("ta", Set.of(), "REQUISITION:UPLOAD");
        assertThatThrownBy(() -> service.create(all, new RequisitionInput(0, null, "X-2", "T", "LOB-X", "Chennai", null, "AR", 1,
                LocalDate.of(2027, 1, 1), null, null))).hasMessageContaining("not in the LOB master");
        assertThat(service.create(all, new RequisitionInput(0, null, "X-3", "T", "lob one", "Chennai", null, "AR", 1,
                LocalDate.of(2027, 1, 1), null, null)).outcome()).isEqualTo("APPLIED");
    }

    @Test
    void xlsxUploadDryRunAndTemplate() throws Exception {
        List<ReportTable.Column> cols = new ArrayList<>();
        for (String h : RequisitionFileReader.HEADERS) {
            cols.add(h.equals("Valid To") ? ReportTable.Column.date(h, h) : h.equals("Openings") ? ReportTable.Column.integer(h, h)
                    : ReportTable.Column.text(h, h, 15));
        }
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        new XlsxReportWriter(ZoneId.of("Asia/Kolkata")).write(new ReportTable("x", cols, List.of(
                Arrays.asList("create", "XL-1", "Billing", "LOB1", "Pune", null, "BILL", 3, LocalDate.of(2027, 2, 28), null, "on_hold")), null), out);
        Caller lead = tl("tl1", Set.of(), "REQUISITION:UPLOAD");
        RequisitionChangeService.UploadResult dry = service.upload(lead, "r.xlsx", out.toByteArray(), true);
        assertThat(dry.rows()).extracting(RequisitionChangeService.RowResult::outcome).containsExactly("VALID");
        assertThat(store.find("XL-1")).isEmpty();
        RequisitionChangeService.UploadResult real = service.upload(lead, "r.xlsx", out.toByteArray(), false);
        assertThat(real.applied()).isEqualTo(1);
        RequisitionRecord rec = store.find("XL-1").orElseThrow();
        assertThat(rec.validTo()).isEqualTo(LocalDate.of(2027, 2, 28));
        assertThat(rec.status()).isEqualTo("ON_HOLD");
        assertThat(rec.visible()).isFalse();
        assertThat(rec.hiddenReason()).isEqualTo("INACTIVE");
        List<List<String>> template = new XlsxSheetReader(5_000_000, 50).firstSheet(service.template());
        assertThat(template.get(0)).containsExactlyElementsOf(RequisitionFileReader.HEADERS);
        assertThatThrownBy(() -> service.upload(lead, "r.txt", "x".getBytes(), false)).hasMessageContaining(".xlsx or .csv");
    }

    @Test
    void readinessFlagsStubOracleAndMissingSync() {
        JobsP5Properties p5 = new JobsP5Properties();
        JobsS6Properties s6 = new JobsS6Properties();
        s6.setEnvironment("production");
        List<ReadinessCheck> checks = JobsReadiness.checks(jdbc, p5, s6, clock);
        assertThat(checks.stream().filter(c -> c.name().equals("schema")).findFirst().orElseThrow().run().status())
                .isEqualTo(ReadinessResult.Status.PASS);
        assertThat(checks.stream().filter(c -> c.name().equals("oracle-requisitions")).findFirst().orElseThrow().run().status())
                .isEqualTo(ReadinessResult.Status.FAIL);
        assertThat(checks.stream().filter(c -> c.name().equals("last-sync")).findFirst().orElseThrow().run().status())
                .isEqualTo(ReadinessResult.Status.FAIL);
    }
}
