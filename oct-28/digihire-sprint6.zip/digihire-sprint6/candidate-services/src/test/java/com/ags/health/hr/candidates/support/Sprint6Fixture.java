package com.ags.health.hr.candidates.support;

import com.ags.health.hr.candidates.reporting.client.PortBackedReportSource;
import com.ags.health.hr.candidates.reporting.port.UserDirectoryPort;
import com.ags.health.hr.candidates.reporting.port.VendorDirectoryPort;
import com.ags.health.hr.candidates.reporting.service.AuditCompletenessService;
import com.ags.health.hr.candidates.reporting.service.DashboardService;
import com.ags.health.hr.candidates.reporting.service.DrillDownService;
import com.ags.health.hr.candidates.reporting.service.FactCalculator;
import com.ags.health.hr.candidates.reporting.service.FactProjector;
import com.ags.health.hr.candidates.reporting.service.FactRebuildService;
import com.ags.health.hr.candidates.reporting.service.FilterOptionsService;
import com.ags.health.hr.candidates.reporting.service.FunnelReportService;
import com.ags.health.hr.candidates.reporting.service.PerformanceReportService;
import com.ags.health.hr.candidates.reporting.service.ReportAccuracyService;
import com.ags.health.hr.candidates.reporting.service.ReportExportService;
import com.ags.health.hr.candidates.reporting.store.CheckRunStore;
import com.ags.health.hr.candidates.reporting.store.DirtyStore;
import com.ags.health.hr.candidates.reporting.store.FactStore;
import com.ags.health.hr.candidates.reporting.store.SqlDialect;
import com.ags.health.hr.candidates.reporting.store.StageEventStore;
import com.ags.health.hr.candidates.shared.domain.StageCatalog;
import com.ags.health.hr.candidates.shared.domain.TabMovementPolicy;
import com.ags.health.hr.candidates.shared.port.ApplicationPort;
import com.ags.health.hr.candidates.shared.port.ApplicationView;
import com.ags.health.hr.candidates.shared.port.NewApplication;
import com.ags.health.hr.candidates.shared.port.StageEntry;
import com.ags.health.hr.candidates.shared.port.StageHistoryPort;
import com.ags.health.hr.candidates.shared.port.StatusChange;
import com.ags.health.hr.candidates.shared.service.ApplicantActionGuard;
import com.ags.health.hr.candidates.shared.service.MoveGuard;
import com.ags.health.hr.candidates.shared.service.StatusMover;
import com.ags.health.hr.common.platform.audit.AuditRecorder;
import com.ags.health.hr.common.platform.caller.Caller;
import com.ags.health.hr.common.platform.time.BusinessClock;

import java.time.Clock;
import java.time.Duration;
import java.time.Instant;
import java.time.ZoneId;
import java.time.ZoneOffset;
import java.util.ArrayList;
import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;

public class Sprint6Fixture {

    public static final class MutableClock extends Clock {
        public Instant now;

        public MutableClock(Instant start) {
            this.now = start;
        }

        public void advance(Duration d) {
            now = now.plus(d);
        }

        @Override
        public ZoneId getZone() {
            return ZoneOffset.UTC;
        }

        @Override
        public Clock withZone(ZoneId zone) {
            return this;
        }

        @Override
        public Instant instant() {
            return now;
        }
    }

    public final class Apps implements ApplicationPort, StageHistoryPort {
        public final Map<String, ApplicationView> apps = new LinkedHashMap<>();
        public final Map<String, List<StageEntry>> history = new LinkedHashMap<>();

        @Override
        public Optional<ApplicationView> find(String id) {
            return Optional.ofNullable(apps.get(id));
        }

        @Override
        public List<ApplicationView> findOpenByCandidate(String candidateId) {
            return apps.values().stream().filter(a -> a.candidateId().equals(candidateId) && catalog.isOpen(a.status())).toList();
        }

        @Override
        public List<ApplicationView> findByCandidate(String candidateId) {
            return apps.values().stream().filter(a -> a.candidateId().equals(candidateId)).toList();
        }

        @Override
        public ApplicationView create(NewApplication n) {
            throw new UnsupportedOperationException();
        }

        @Override
        public void changeStatus(String id, String toStatus, StatusChange change) {
            ApplicationView a = apps.get(id);
            apps.put(id, new ApplicationView(a.id(), a.candidateId(), a.jobId(), a.requisitionId(), toStatus, a.hrUserId(), a.lob(),
                    a.location(), a.orcId(), a.roleCode(), a.source(), clock.instant()));
            history.computeIfAbsent(id, k -> new ArrayList<>()).add(new StageEntry(toStatus, clock.instant(), change.actorId(), change.system()));
        }

        @Override
        public void retag(String id, String hrUserId, StatusChange change) {
            throw new UnsupportedOperationException();
        }

        @Override
        public void changeRequisition(String id, String requisitionId, String jobId, StatusChange change) {
            throw new UnsupportedOperationException();
        }

        @Override
        public List<StageEntry> history(String applicationId) {
            return history.getOrDefault(applicationId, List.of());
        }
    }

    public final MutableClock clock = new MutableClock(Instant.parse("2026-10-01T04:30:00Z"));
    public final P5TestDb db = P5TestDb.h2("db/p5/candidate-p5-schema.sql", "db/p5/candidate-p5-data.sql", "db/p6/candidate-p6-schema.sql");
    public final Apps apps = new Apps();
    public final Fakes.Candidates candidates = new Fakes.Candidates();
    public final Fakes.Notifications notifications = new Fakes.Notifications();
    public final Fakes.Callers callers = new Fakes.Callers(null);
    public final StageCatalog catalog = StageCatalog.standard();
    public final BusinessClock business = new BusinessClock(clock, ZoneId.of("Asia/Kolkata"));
    public final AuditRecorder audit = db.audit(callers, clock);
    public final Map<String, String> vendorOf = new LinkedHashMap<>();
    public final UserDirectoryPort users = ids -> {
        Map<String, String> m = new LinkedHashMap<>();
        ids.forEach(i -> m.put(i, "Name of " + i));
        return m;
    };
    public final VendorDirectoryPort vendors = new VendorDirectoryPort() {
        @Override
        public Map<String, String> names(Collection<String> ids) {
            Map<String, String> m = new LinkedHashMap<>();
            ids.forEach(i -> m.put(i, "Vendor " + i));
            return m;
        }

        @Override
        public Optional<String> vendorOfApplication(String applicationId) {
            return Optional.ofNullable(vendorOf.get(applicationId));
        }
    };
    public final FactStore facts = new FactStore(db.jdbc, SqlDialect.detect(db.jdbc));
    public final StageEventStore events = new StageEventStore(db.jdbc);
    public final DirtyStore dirty = new DirtyStore(db.jdbc);
    public final CheckRunStore runs = new CheckRunStore(db.jdbc);
    public final PortBackedReportSource source = new PortBackedReportSource(apps, apps, candidates, vendors, events);
    public final FactCalculator calc = new FactCalculator(catalog, business);
    public final FactProjector projector = new FactProjector(facts, events, dirty, source, calc, business, null);
    public final List<MoveGuard> guards = new ArrayList<>();
    public final StatusMover mover = new StatusMover(apps, new ApplicantActionGuard(false), null, new TabMovementPolicy(catalog, null), catalog,
            audit, notifications, List.of(projector), clock, Set.of("REPROCESS", "REMAP"),
            List.of((c, a, t, m) -> guards.forEach(g -> g.check(c, a, t, m))));
    public final FunnelReportService funnel = new FunnelReportService(facts, users, vendors, business, 366);
    public final PerformanceReportService performance = new PerformanceReportService(facts, events, users, vendors, business, 366);
    public final DashboardService dashboard = new DashboardService(facts, events, funnel, users, business, Duration.ofSeconds(60), 366);
    public final DrillDownService drill = new DrillDownService(facts, business, 200, 366);
    public final FilterOptionsService options = new FilterOptionsService(facts, users, vendors, Duration.ofSeconds(60), clock);
    public final ReportExportService export = new ReportExportService(funnel, performance, drill, (t, f) -> ("PDF:" + t.rows().size()).getBytes(),
            db.jdbc, audit, business, 1000, 50);
    public final ReportAccuracyService accuracy = new ReportAccuracyService(source, facts, calc, runs, audit, business,
            new ReportAccuracyService.Settings(99.0, true, 100, 50));
    public final AuditCompletenessService auditCheck = new AuditCompletenessService(events, db.jdbc, runs, audit, business, "audit_log",
            Duration.ofSeconds(5), 100);
    public final FactRebuildService rebuild = new FactRebuildService(source, facts, dirty, calc, audit, business, 5);

    public static final Caller SYSTEM = Caller.system("test");

    public ApplicationView create(String id, String candidate, String hr, String lob, String location, String source, String requisition) {
        candidates.add(candidate, true, hr);
        ApplicationView a = new ApplicationView(id, candidate, "JOB-" + requisition, requisition, "CREATED", hr, lob, location,
                "ORC-" + requisition, "ROLE-" + lob, source, clock.instant());
        apps.apps.put(id, a);
        apps.history.computeIfAbsent(id, k -> new ArrayList<>()).add(new StageEntry("CREATED", clock.instant(), hr, false));
        mover.announce(SYSTEM, a, null, "CREATED", null, "created", Map.of());
        return a;
    }

    public void path(String id, String... statuses) {
        for (String s : statuses) {
            clock.advance(Duration.ofDays(1));
            mover.move(SYSTEM, StatusMover.Move.to(id, s, "APPLICATION:MOVE_STAGE").reason("REPROCESS", "test").asReset());
        }
    }

    public static Caller user(String id, String scope, Set<String> team, Set<String> lobs, String... permissions) {
        return new Caller(id, id + "@agshealth.com", "User " + id, Set.of("RECRUITER"), Set.of(permissions), Set.of(), scope, team, lobs,
                Set.of(), false);
    }
}
