package com.ags.health.hr.candidates.worklist;

import com.ags.health.hr.candidates.concurrency.ApplicationMutexGuard;
import com.ags.health.hr.candidates.ops.CandidateReadinessChecks;
import com.ags.health.hr.candidates.reporting.domain.DrillRow;
import com.ags.health.hr.candidates.s6shared.CandidateS6Properties;
import com.ags.health.hr.candidates.shared.config.CandidateP5Properties;
import com.ags.health.hr.candidates.shared.domain.Statuses;
import com.ags.health.hr.candidates.shared.port.ApplicationView;
import com.ags.health.hr.candidates.shared.service.StatusMover;
import com.ags.health.hr.candidates.support.Sprint6Fixture;
import com.ags.health.hr.common.platform.caller.Caller;
import com.ags.health.hr.common.platform.error.PlatformException;
import com.ags.health.hr.common.platform.readiness.ReadinessReport;
import com.ags.health.hr.common.platform.readiness.ReadinessResult;
import com.ags.health.hr.common.platform.readiness.ReadinessService;
import org.junit.jupiter.api.Test;

import java.time.Duration;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

class WorklistAndConcurrencyTest {

    private final Sprint6Fixture f = new Sprint6Fixture();

    @Test
    void keysetPagesWalkTheWholeTabWithoutDuplicatesAndRespectScope() {
        for (int i = 0; i < 23; i++) {
            f.clock.advance(Duration.ofMinutes(7));
            f.create(String.format("APP%02d", i), "C" + i, i % 2 == 0 ? "rec1" : "rec2", "LOB1", "CHENNAI", "DIRECT", "R1");
        }
        WorklistService w = new WorklistService(f.facts, f.business, 100, 1000);
        Caller head = Sprint6Fixture.user("head", "ALL", Set.of(), Set.of(), "CANDIDATE:VIEW");
        Set<String> seen = new HashSet<>();
        List<String> order = new ArrayList<>();
        String cursor = null;
        int pages = 0;
        do {
            WorklistPage p = w.page(head, new WorklistQuery("APPLICANT", null, null, null, null, null, null, "RECENT", cursor, 10, pages == 0));
            if (pages == 0) {
                assertThat(p.count()).isEqualTo(23);
            }
            for (DrillRow r : p.items()) {
                assertThat(seen.add(r.applicationId())).isTrue();
                order.add(r.applicationId());
            }
            cursor = p.nextCursor();
            pages++;
        } while (cursor != null);
        assertThat(pages).isEqualTo(3);
        assertThat(order).hasSize(23).first().isEqualTo("APP22");
        Caller rec1 = Sprint6Fixture.user("rec1", "OWN", Set.of(), Set.of(), "CANDIDATE:VIEW");
        assertThat(w.page(rec1, new WorklistQuery(null, null, null, null, null, null, null, "OLDEST", null, 50, true)).count()).isEqualTo(12);
        assertThatThrownBy(() -> w.page(head, new WorklistQuery(null, null, null, null, null, null, null, null, "not-a-cursor", 10, false)))
                .isInstanceOf(PlatformException.class).hasMessageContaining("Cursor");
    }

    @Test
    void staleViewOfAnApplicationIsRefused() {
        f.create("A", "CA", "rec1", "LOB1", "CHENNAI", "DIRECT", "R1");
        ApplicationView stale = f.apps.find("A").orElseThrow();
        f.guards.add(new ApplicationMutexGuard(f.apps, f.db.jdbc, f.clock, true, true));
        Caller rec = Sprint6Fixture.user("rec1", "OWN", Set.of(), Set.of(), "APPLICATION:MOVE_STAGE");
        f.mover.move(rec, StatusMover.Move.to("A", Statuses.WAITING_FOR_HRROUND, "APPLICATION:MOVE_STAGE"));
        assertThatThrownBy(() -> f.mover.move(rec, stale, StatusMover.Move.to("A", Statuses.PIPELINE, "APPLICATION:MOVE_STAGE")))
                .isInstanceOf(PlatformException.class)
                .satisfies(e -> assertThat(((PlatformException) e).getCode()).isEqualTo("STALE_STATUS"));
        assertThat(f.apps.find("A").orElseThrow().status()).isEqualTo(Statuses.WAITING_FOR_HRROUND);
        assertThat(f.facts.find("A").orElseThrow().tab()).isEqualTo("HR_INTERVIEW");
        new ApplicationMutexGuard(f.apps, f.db.jdbc, f.clock, true, true).lock("A");
        assertThat(f.db.count("cand_p6_app_mutex")).isEqualTo(1);
    }

    @Test
    void readinessReportsMissingSecretsLocalUrlsAndStaleChecks() {
        f.create("A", "CA", "rec1", "LOB1", "CHENNAI", "DIRECT", "R1");
        CandidateP5Properties p5 = new CandidateP5Properties();
        CandidateS6Properties s6 = new CandidateS6Properties();
        s6.setEnvironment("prod");
        ReadinessService svc = new ReadinessService("candidate-services", "prod",
                CandidateReadinessChecks.all(f.db.jdbc, p5, s6, f.runs, f.dirty, f.clock), Duration.ofSeconds(5), f.clock);
        ReadinessReport r = svc.run();
        assertThat(r.overall()).isEqualTo(ReadinessResult.Status.FAIL);
        assertThat(status(r, "jwt-secret")).isEqualTo(ReadinessResult.Status.FAIL);
        assertThat(status(r, "document-storage")).isEqualTo(ReadinessResult.Status.FAIL);
        assertThat(status(r, "service-urls")).isEqualTo(ReadinessResult.Status.FAIL);
        assertThat(status(r, "schema")).isEqualTo(ReadinessResult.Status.PASS);
        assertThat(status(r, "database")).isEqualTo(ReadinessResult.Status.PASS);
        assertThat(status(r, "report-accuracy")).isEqualTo(ReadinessResult.Status.FAIL);
        f.accuracy.check("test", LocalDate.of(2026, 10, 1), LocalDate.of(2026, 10, 1), false);
        assertThat(status(svc.run(), "report-accuracy")).isEqualTo(ReadinessResult.Status.PASS);
    }

    private static ReadinessResult.Status status(ReadinessReport r, String name) {
        return r.checks().stream().filter(c -> c.name().equals(name)).findFirst().orElseThrow().status();
    }
}
