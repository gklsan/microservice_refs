package com.ags.health.hr.candidates.reporting;

import com.ags.health.hr.candidates.reporting.domain.ReportFilter;
import com.ags.health.hr.candidates.reporting.service.DashboardService;
import com.ags.health.hr.candidates.reporting.service.DrillDownService;
import com.ags.health.hr.candidates.reporting.service.FunnelReportService;
import com.ags.health.hr.candidates.reporting.service.PerformanceReportService;
import com.ags.health.hr.candidates.reporting.store.FactStore;
import com.ags.health.hr.candidates.reporting.store.SqlDialect;
import com.ags.health.hr.candidates.reporting.store.StageEventStore;
import com.ags.health.hr.candidates.reporting.port.UserDirectoryPort;
import com.ags.health.hr.candidates.reporting.port.VendorDirectoryPort;
import com.ags.health.hr.candidates.worklist.WorklistPage;
import com.ags.health.hr.candidates.worklist.WorklistQuery;
import com.ags.health.hr.candidates.worklist.WorklistService;
import com.ags.health.hr.common.platform.caller.Caller;
import com.ags.health.hr.common.platform.time.BusinessClock;
import org.junit.jupiter.api.Assumptions;
import org.junit.jupiter.api.Test;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.datasource.DriverManagerDataSource;

import java.time.Clock;
import java.time.Duration;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.function.Supplier;

import static org.assertj.core.api.Assertions.assertThat;

class ReportVolumeCheckTest {

    private static final String URL = "p6.volume.url";

    @Test
    void reportsStayUnderThreeSecondsOnTheSeededVolume() {
        String url = System.getProperty(URL);
        Assumptions.assumeTrue(url != null && !url.isBlank(), "Set -D" + URL + " to a database seeded by perf/seed");
        JdbcTemplate jdbc = new JdbcTemplate(new DriverManagerDataSource(url, System.getProperty("p5.test.pg.user", "p5"),
                System.getProperty("p5.test.pg.password", "p5")));
        BusinessClock clock = new BusinessClock(Clock.systemUTC(), ZoneId.of("Asia/Kolkata"));
        FactStore facts = new FactStore(jdbc, SqlDialect.detect(jdbc));
        StageEventStore events = new StageEventStore(jdbc);
        UserDirectoryPort users = ids -> {
            Map<String, String> m = new LinkedHashMap<>();
            ids.forEach(i -> m.put(i, i));
            return m;
        };
        VendorDirectoryPort vendors = new VendorDirectoryPort() {
            public Map<String, String> names(Collection<String> ids) {
                return users.names(ids);
            }

            public Optional<String> vendorOfApplication(String id) {
                return Optional.empty();
            }
        };
        FunnelReportService funnel = new FunnelReportService(facts, users, vendors, clock, 366);
        PerformanceReportService perf = new PerformanceReportService(facts, events, users, vendors, clock, 366);
        DashboardService dash = new DashboardService(facts, events, funnel, users, clock, Duration.ZERO, 366);
        DrillDownService drill = new DrillDownService(facts, clock, 200, 366);
        WorklistService worklist = new WorklistService(facts, clock, 100, 1000);
        Caller head = new Caller("head", "h@x", "Head", Set.of("TA_HEAD"), Set.of("REPORT:VIEW", "REPORT:FUNNEL", "REPORT:RECRUITER",
                "REPORT:VENDOR", "CANDIDATE:VIEW"), Set.of(), "ALL", Set.of(), Set.of(), Set.of(), false);
        Caller lead = new Caller("perf-rec-1", "l@x", "Lead", Set.of("RECRUITMENT_MANAGER"), head.permissions(), Set.of(), "TEAM",
                Set.of("perf-rec-2", "perf-rec-3", "perf-rec-4", "perf-rec-5"), Set.of(), Set.of(), false);
        LocalDate today = clock.today();
        ReportFilter quarter = ReportFilter.range(today.minusDays(89), today);
        ReportFilter half = ReportFilter.range(today.minusDays(179), today);
        time("funnel 90d all", () -> funnel.funnel(head, quarter, "lob"));
        time("funnel 180d all", () -> funnel.funnel(head, half, "recruiter"));
        time("recruiters 90d all", () -> perf.recruiters(head, quarter));
        time("vendors 180d all", () -> perf.vendors(head, half));
        time("dashboard all", () -> dash.dashboard(head, ReportFilter.range(null, null)));
        time("dashboard team", () -> dash.dashboard(lead, ReportFilter.range(null, null)));
        time("drill aging", () -> drill.drill(head, ReportFilter.range(null, null), "aging:D31_PLUS", 5, 25, null));
        WorklistPage first = time("worklist page 1", () -> worklist.page(head, new WorklistQuery("APPLICANT", null, null, null, null, null,
                null, null, null, 25, true)));
        time("worklist page 2", () -> worklist.page(head, new WorklistQuery("APPLICANT", null, null, null, null, null, null, null,
                first.nextCursor(), 25, false)));
        time("worklist search", () -> worklist.page(head, new WorklistQuery(null, null, null, null, null, null, "candidate 12345", null, null,
                25, false)));
    }

    private static <T> T time(String label, Supplier<T> work) {
        work.get();
        long start = System.nanoTime();
        T out = work.get();
        long ms = (System.nanoTime() - start) / 1_000_000;
        System.out.println("VOLUME " + label + " " + ms + " ms");
        assertThat(ms).as(label).isLessThan(3000);
        return out;
    }
}
