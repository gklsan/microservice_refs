package com.ags.health.hr.candidates.reporting;

import com.ags.health.hr.candidates.reporting.domain.CheckRun;
import com.ags.health.hr.candidates.reporting.domain.DashboardView;
import com.ags.health.hr.candidates.reporting.domain.DrillRow;
import com.ags.health.hr.candidates.reporting.domain.ExportFile;
import com.ags.health.hr.candidates.reporting.domain.FunnelReport;
import com.ags.health.hr.candidates.reporting.domain.FunnelStage;
import com.ags.health.hr.candidates.reporting.domain.ReportFilter;
import com.ags.health.hr.candidates.reporting.service.PerformanceReportService;
import com.ags.health.hr.candidates.reporting.service.ReportExportService;
import com.ags.health.hr.candidates.shared.domain.Statuses;
import com.ags.health.hr.candidates.support.Sprint6Fixture;
import com.ags.health.hr.common.platform.caller.Caller;
import com.ags.health.hr.common.platform.error.PlatformException;
import com.ags.health.hr.common.platform.export.XlsxSheetReader;
import com.ags.health.hr.common.platform.page.PageResult;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.nio.charset.StandardCharsets;
import java.time.LocalDate;
import java.util.List;
import java.util.Set;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

class ReportingScenariosTest {

    private static final String[] ALL = {"REPORT:VIEW", "REPORT:FUNNEL", "REPORT:RECRUITER", "REPORT:VENDOR", "REPORT:EXPORT",
            "REPORT:QUALITY", "CANDIDATE:VIEW", "CANDIDATE:EXPORT"};

    private Sprint6Fixture f;
    private Caller head;
    private final ReportFilter october = ReportFilter.range(LocalDate.of(2026, 10, 1), LocalDate.of(2026, 10, 31));

    @BeforeEach
    void setUp() {
        f = new Sprint6Fixture();
        head = Sprint6Fixture.user("head", "ALL", Set.of(), Set.of(), ALL);
        f.create("A", "CA", "rec1", "LOB1", "CHENNAI", "DIRECT", "R1");
        f.create("B", "CB", "rec1", "LOB1", "CHENNAI", "ERS", "R1");
        f.create("C", "CC", "rec2", "LOB2", "TRICHY", "DIRECT", "R2");
        f.vendorOf.put("D", "V1");
        f.create("D", "CD", "rec2", "LOB2", "TRICHY", "VENDOR", "R2");
        f.path("A", Statuses.WAITING_FOR_HRROUND, Statuses.ASSESEMENT_YET_TO_START, Statuses.PANEL_YET_TO_SCHEDULE, Statuses.PANEL_SELECTED,
                Statuses.OFFERED, Statuses.JOINED);
        f.path("B", Statuses.WAITING_FOR_HRROUND, Statuses.HR_REJECTED);
        f.path("D", Statuses.WAITING_FOR_HRROUND, Statuses.ASSESEMENT_YET_TO_START, Statuses.ASSESEMENT_FAILED);
    }

    @Test
    void funnelCountsReachedOrPassedStagesAndWhereCandidatesDropped() {
        FunnelReport r = f.funnel.funnel(head, october, "source");
        assertThat(r.total()).isEqualTo(4);
        assertThat(step(r, FunnelStage.HR_ROUND).reached()).isEqualTo(3);
        assertThat(step(r, FunnelStage.ASSESSMENT).reached()).isEqualTo(2);
        assertThat(step(r, FunnelStage.VERSANT).reached()).isEqualTo(1);
        assertThat(step(r, FunnelStage.JOINED).reached()).isEqualTo(1);
        assertThat(step(r, FunnelStage.HR_ROUND).conversionFromApplied()).isEqualTo(0.75);
        assertThat(step(r, FunnelStage.HR_ROUND).droppedHere()).isEqualTo(1);
        assertThat(step(r, FunnelStage.ASSESSMENT).droppedHere()).isEqualTo(1);
        assertThat(step(r, FunnelStage.APPLIED).openHere()).isEqualTo(1);
        assertThat(step(r, FunnelStage.JOINED).avgDaysFromApplied()).isEqualTo(6.0);
        assertThat(r.breakdown()).extracting(FunnelReport.Breakdown::value).containsExactly("DIRECT", "ERS", "VENDOR");
    }

    @Test
    void scopeLimitsWhatEachRoleSees() {
        Caller rec1 = Sprint6Fixture.user("rec1", "OWN", Set.of(), Set.of(), "REPORT:FUNNEL");
        Caller lead = Sprint6Fixture.user("tl", "TEAM", Set.of("rec1", "rec2"), Set.of(), "REPORT:FUNNEL");
        Caller lob2 = Sprint6Fixture.user("lm", "LOB", Set.of(), Set.of("LOB2"), "REPORT:FUNNEL");
        assertThat(f.funnel.funnel(rec1, october, null).total()).isEqualTo(2);
        assertThat(f.funnel.funnel(lead, october, null).total()).isEqualTo(4);
        assertThat(f.funnel.funnel(lob2, october, null).total()).isEqualTo(2);
        Caller nobody = Sprint6Fixture.user("x", "ALL", Set.of(), Set.of());
        assertThatThrownBy(() -> f.funnel.funnel(nobody, october, null)).isInstanceOf(PlatformException.class)
                .hasMessageContaining("REPORT:FUNNEL");
        assertThatThrownBy(() -> f.funnel.funnel(head, ReportFilter.range(LocalDate.of(2025, 1, 1), LocalDate.of(2026, 10, 31)), null))
                .hasMessageContaining("366");
    }

    @Test
    void recruiterAndVendorPerformance() {
        PerformanceReportService.Report rec = f.performance.recruiters(head, october);
        assertThat(rec.rows()).extracting(r -> r.id() + ":" + r.applications() + ":" + r.joined() + ":" + r.rejected())
                .containsExactly("rec1:2:1:1", "rec2:2:0:1");
        assertThat(rec.rows().get(0).name()).isEqualTo("Name of rec1");
        assertThat(rec.rows().get(0).avgDaysToOffer()).isEqualTo(5.0);
        assertThat(rec.total().applications()).isEqualTo(4);
        PerformanceReportService.Report ven = f.performance.vendors(head, october);
        assertThat(ven.rows()).extracting(r -> r.id() + ":" + r.name() + ":" + r.applications() + ":" + r.rejected())
                .containsExactly("V1:Vendor V1:1:1");
    }

    @Test
    void dashboardIsCachedAndEveryBucketDrillsDown() {
        DashboardView v = f.dashboard.dashboard(head, ReportFilter.range(null, null));
        assertThat(v.cached()).isFalse();
        DashboardView.Widget pipeline = widget(v, "pipeline");
        assertThat(pipeline.total()).isEqualTo(1);
        assertThat(pipeline.buckets()).filteredOn(b -> b.key().equals("APPLICANT")).extracting(DashboardView.Bucket::count).containsExactly(1L);
        assertThat(widget(v, "funnel").buckets()).hasSize(8);
        assertThat(f.dashboard.dashboard(head, ReportFilter.range(null, null)).cached()).isTrue();
        PageResult<DrillRow> open = f.drill.drill(head, ReportFilter.range(null, null), "pipeline:APPLICANT", 0, 10, null);
        assertThat(open.items()).extracting(DrillRow::applicationId).containsExactly("C");
        PageResult<DrillRow> joined = f.drill.drill(head, october, "funnel:JOINED", 0, 10, null);
        assertThat(joined.items()).extracting(DrillRow::applicationId).containsExactly("A");
        PageResult<DrillRow> dropped = f.drill.drill(head, october, "dropped:ASSESSMENT", 0, 10, null);
        assertThat(dropped.items()).extracting(DrillRow::applicationId).containsExactly("D");
        assertThatThrownBy(() -> f.drill.drill(head, october, "pipeline:NOPE", 0, 10, null)).hasMessageContaining("Unknown tab");
        assertThat(f.options.options(head).get("recruiter")).extracting(o -> o.label()).containsExactly("Name of rec1", "Name of rec2");
    }

    @Test
    void exportsAreRealWorkbooksSafeCsvAndGuardedLists() {
        ExportFile x = f.export.export(head, new ReportExportService.ExportRequest("RECRUITER", "XLSX", october, null, null));
        List<List<String>> sheet = new XlsxSheetReader(10_000_000, 1000).firstSheet(x.content());
        assertThat(sheet.get(0)).startsWith("Recruiter id", "Recruiter", "Applications");
        assertThat(sheet.get(1).subList(0, 3)).containsExactly("rec1", "Name of rec1", "2");
        assertThat(sheet).hasSize(4);
        f.candidates.candidates.put("CC", new com.ags.health.hr.candidates.shared.port.CandidateView("CC", "U", "c@x", "9", "=HYPERLINK(\"x\")",
                true, "rec2", "DIRECT", null, null));
        f.rebuild.rebuild("C");
        ExportFile csv = f.export.export(head, new ReportExportService.ExportRequest("DRILL", "CSV", ReportFilter.range(null, null), null,
                "pipeline:APPLICANT"));
        String text = new String(csv.content(), StandardCharsets.UTF_8);
        assertThat(text).contains("\"'=HYPERLINK(\"\"x\"\")\"");
        Caller noPii = Sprint6Fixture.user("tl", "ALL", Set.of(), Set.of(), "REPORT:VIEW", "REPORT:EXPORT", "CANDIDATE:VIEW");
        assertThatThrownBy(() -> f.export.export(noPii, new ReportExportService.ExportRequest("DRILL", "XLSX", october, null, "funnel:APPLIED")))
                .hasMessageContaining("CANDIDATE:EXPORT");
        assertThat(f.db.count("cand_p6_export_log")).isEqualTo(2);
        assertThat(f.db.auditRows("REPORT_EXPORTED")).hasSize(2);
    }

    @Test
    void accuracyCheckFindsAndRepairsDrift() {
        CheckRun ok = f.accuracy.run(head, LocalDate.of(2026, 10, 1), LocalDate.of(2026, 10, 31), true);
        assertThat(ok.sample()).isEmpty();
        assertThat(ok.status()).isEqualTo("PASS");
        assertThat(ok.checked()).isEqualTo(4);
        f.db.jdbc.update("UPDATE cand_p6_app_fact SET status = 'CREATED', tab = 'APPLICANT' WHERE application_id = 'B'");
        f.db.jdbc.update("DELETE FROM cand_p6_app_fact WHERE application_id = 'D'");
        CheckRun bad = f.accuracy.run(head, LocalDate.of(2026, 10, 1), LocalDate.of(2026, 10, 31), true);
        assertThat(bad.status()).isEqualTo("FAIL");
        assertThat(bad.mismatched()).isEqualTo(1);
        assertThat(bad.missing()).isEqualTo(1);
        assertThat(bad.repaired()).isEqualTo(2);
        assertThat(bad.score()).isEqualTo(50.0);
        assertThat(f.accuracy.run(head, LocalDate.of(2026, 10, 1), LocalDate.of(2026, 10, 31), false).status()).isEqualTo("PASS");
    }

    @Test
    void auditCompletenessMatchesEveryMoveToAnAuditRow() {
        CheckRun ok = f.auditCheck.run(head, LocalDate.of(2026, 10, 1), LocalDate.of(2026, 10, 31));
        assertThat(ok.checked()).isEqualTo(11);
        assertThat(ok.status()).isEqualTo("PASS");
        f.db.jdbc.update("DELETE FROM audit_log WHERE target_id = 'B' AND action = 'STATUS_RESET' AND CAST(details AS VARCHAR(4000)) LIKE '%HR_REJECTED%'");
        CheckRun bad = f.auditCheck.run(head, LocalDate.of(2026, 10, 1), LocalDate.of(2026, 10, 31));
        assertThat(bad.status()).isEqualTo("FAIL");
        assertThat(bad.missing()).isEqualTo(1);
        assertThat(bad.sample().get(0)).startsWith("B: WAITING_FOR_HRROUND -> HR_REJECTED");
    }

    @Test
    void dirtyFactsAreRebuiltFromTheSource() {
        f.db.jdbc.update("DELETE FROM cand_p6_app_fact WHERE application_id = 'A'");
        f.dirty.mark("A", "test", f.clock.instant());
        assertThat(f.rebuild.repairDirty(10)).isEqualTo(1);
        assertThat(f.facts.find("A").orElseThrow().joinedAt()).isNotNull();
        assertThat(f.dirty.backlog()).isZero();
    }

    private static FunnelReport.Step step(FunnelReport r, FunnelStage s) {
        return r.steps().stream().filter(x -> x.stage() == s).findFirst().orElseThrow();
    }

    private static DashboardView.Widget widget(DashboardView v, String key) {
        return v.widgets().stream().filter(w -> w.key().equals(key)).findFirst().orElseThrow();
    }
}
