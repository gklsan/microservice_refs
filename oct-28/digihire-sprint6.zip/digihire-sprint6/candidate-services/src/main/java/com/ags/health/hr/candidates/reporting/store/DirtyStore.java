package com.ags.health.hr.candidates.reporting.store;

import org.springframework.jdbc.core.JdbcTemplate;

import java.sql.Timestamp;
import java.time.Instant;
import java.util.List;

public class DirtyStore {

    private final JdbcTemplate jdbc;

    public DirtyStore(JdbcTemplate jdbc) {
        this.jdbc = jdbc;
    }

    public void mark(String applicationId, String reason, Instant at) {
        String r = reason == null ? null : reason.length() > 290 ? reason.substring(0, 290) : reason;
        int n = jdbc.update("UPDATE cand_p6_fact_dirty SET reason = ?, marked_at = ? WHERE application_id = ?", r, Timestamp.from(at), applicationId);
        if (n == 0) {
            try {
                jdbc.update("INSERT INTO cand_p6_fact_dirty (application_id, reason, marked_at, attempts) VALUES (?, ?, ?, 0)",
                        applicationId, r, Timestamp.from(at));
            } catch (org.springframework.dao.DuplicateKeyException ignored) {
                jdbc.update("UPDATE cand_p6_fact_dirty SET reason = ?, marked_at = ? WHERE application_id = ?", r, Timestamp.from(at), applicationId);
            }
        }
    }

    public List<String> due(int limit, int maxAttempts) {
        return jdbc.queryForList("SELECT application_id FROM cand_p6_fact_dirty WHERE attempts < ? ORDER BY marked_at LIMIT ?", String.class,
                maxAttempts, limit);
    }

    public void done(String applicationId) {
        jdbc.update("DELETE FROM cand_p6_fact_dirty WHERE application_id = ?", applicationId);
    }

    public void failed(String applicationId, String reason) {
        jdbc.update("UPDATE cand_p6_fact_dirty SET attempts = attempts + 1, reason = ? WHERE application_id = ?",
                reason == null ? null : reason.length() > 290 ? reason.substring(0, 290) : reason, applicationId);
    }

    public long backlog() {
        Long n = jdbc.queryForObject("SELECT count(*) FROM cand_p6_fact_dirty", Long.class);
        return n == null ? 0 : n;
    }
}
