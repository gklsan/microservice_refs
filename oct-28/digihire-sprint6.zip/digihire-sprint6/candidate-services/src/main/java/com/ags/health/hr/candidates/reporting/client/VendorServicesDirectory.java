package com.ags.health.hr.candidates.reporting.client;

import com.ags.health.hr.candidates.reporting.port.VendorDirectoryPort;
import com.ags.health.hr.common.platform.cache.TtlCache;
import com.ags.health.hr.common.platform.http.InternalHttp;
import com.fasterxml.jackson.databind.JsonNode;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.time.Clock;
import java.time.Duration;
import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Optional;
import java.util.TreeSet;

public class VendorServicesDirectory implements VendorDirectoryPort {

    private static final Logger log = LoggerFactory.getLogger(VendorServicesDirectory.class);

    private final InternalHttp http;
    private final String base;
    private final TtlCache<String, Map<String, String>> names;

    public VendorServicesDirectory(InternalHttp http, String vendorUrl, Duration ttl, Clock clock) {
        this.http = http;
        this.base = InternalHttp.trimBase(vendorUrl);
        this.names = new TtlCache<>(ttl, 500, clock);
    }

    @Override
    public Map<String, String> names(Collection<String> vendorIds) {
        TreeSet<String> ids = new TreeSet<>();
        vendorIds.stream().filter(v -> v != null && !v.isBlank()).forEach(ids::add);
        Map<String, String> out = new LinkedHashMap<>();
        if (ids.isEmpty()) {
            return out;
        }
        Map<String, String> found;
        try {
            found = names.get(String.join(",", ids), () -> fetch(ids));
        } catch (RuntimeException e) {
            log.warn("Vendor directory unavailable: {}", e.getMessage());
            found = Map.of();
        }
        for (String id : ids) {
            out.put(id, found.getOrDefault(id, id));
        }
        return out;
    }

    @Override
    public Optional<String> vendorOfApplication(String applicationId) {
        try {
            JsonNode n = http.get(base + "/internal/vendor-links/by-application/" + InternalHttp.encode(applicationId));
            JsonNode v = n == null ? null : n.get("vendorId");
            return v == null || v.isNull() || v.asText().isBlank() ? Optional.empty() : Optional.of(v.asText());
        } catch (InternalHttp.Failure f) {
            if (f.status() == 404) {
                return Optional.empty();
            }
            throw f;
        }
    }

    private Map<String, String> fetch(TreeSet<String> ids) {
        JsonNode n = http.get(InternalHttp.query(base + "/internal/vendors/names", Map.of("ids", String.join(",", ids))));
        Map<String, String> m = new LinkedHashMap<>();
        if (n != null && n.isObject()) {
            n.fields().forEachRemaining(e -> m.put(e.getKey(), e.getValue().asText()));
        }
        return m;
    }
}
