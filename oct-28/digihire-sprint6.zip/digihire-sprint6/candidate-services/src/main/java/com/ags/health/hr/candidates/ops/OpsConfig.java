package com.ags.health.hr.candidates.ops;

import com.ags.health.hr.candidates.reporting.store.CheckRunStore;
import com.ags.health.hr.candidates.reporting.store.DirtyStore;
import com.ags.health.hr.candidates.s6shared.CandidateS6Properties;
import com.ags.health.hr.candidates.shared.config.CandidateP5Properties;
import com.ags.health.hr.common.platform.readiness.ReadinessService;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.core.JdbcTemplate;

import java.time.Clock;
import java.time.Duration;

@Configuration
@ConditionalOnProperty(prefix = "digihire.s6.readiness", name = "enabled", havingValue = "true", matchIfMissing = true)
public class OpsConfig {

    @Bean
    public ReadinessService p6ReadinessService(JdbcTemplate jdbc, CandidateP5Properties p5, CandidateS6Properties s6, CheckRunStore p6CheckRunStore,
                                               DirtyStore p6DirtyStore, Clock p5Clock) {
        return new ReadinessService(p5.getServiceName(), s6.getEnvironment(),
                CandidateReadinessChecks.all(jdbc, p5, s6, p6CheckRunStore, p6DirtyStore, p5Clock),
                Duration.ofSeconds(s6.getReadiness().getTimeoutSeconds()), p5Clock);
    }
}
