package com.ags.health.hr.candidates.reporting.service;

import com.ags.health.hr.candidates.reporting.domain.DrillRow;
import com.ags.health.hr.candidates.reporting.domain.ExportFile;
import com.ags.health.hr.candidates.reporting.domain.FunnelReport;
import com.ags.health.hr.candidates.reporting.domain.PerformanceRow;
import com.ags.health.hr.candidates.reporting.domain.ReportFilter;
import com.ags.health.hr.candidates.s6shared.S6Permissions;
import com.ags.health.hr.common.platform.audit.AuditRecorder;
import com.ags.health.hr.common.platform.caller.Caller;
import com.ags.health.hr.common.platform.error.PlatformException;
import com.ags.health.hr.common.platform.export.CsvReportWriter;
import com.ags.health.hr.common.platform.export.ReportTable;
import com.ags.health.hr.common.platform.export.XlsxReportWriter;
import com.ags.health.hr.common.platform.time.BusinessClock;
import org.springframework.jdbc.core.JdbcTemplate;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.sql.Timestamp;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.UUID;

public class ReportExportService {

    public enum Report { FUNNEL, RECRUITER, VENDOR, DRILL }

    public enum Format { XLSX, CSV, PDF }

    public record ExportRequest(String report, String format, ReportFilter filter, String breakdown, String drill) {
    }

    private static final DateTimeFormatter STAMP = DateTimeFormatter.ofPattern("yyyyMMdd-HHmm");

    private final FunnelReportService funnel;
    private final PerformanceReportService performance;
    private final DrillDownService drill;
    private final ReportPdfRenderer pdf;
    private final JdbcTemplate jdbc;
    private final AuditRecorder audit;
    private final BusinessClock clock;
    private final int maxRows;
    private final int maxPdfRows;

    public ReportExportService(FunnelReportService funnel, PerformanceReportService performance, DrillDownService drill, ReportPdfRenderer pdf,
                               JdbcTemplate jdbc, AuditRecorder audit, BusinessClock clock, int maxRows, int maxPdfRows) {
        this.funnel = funnel;
        this.performance = performance;
        this.drill = drill;
        this.pdf = pdf;
        this.jdbc = jdbc;
        this.audit = audit;
        this.clock = clock;
        this.maxRows = maxRows;
        this.maxPdfRows = maxPdfRows;
    }

    public ExportFile export(Caller caller, ExportRequest req) {
        if (caller == null || !caller.has(S6Permissions.EXPORT)) {
            throw PlatformException.forbidden("PERMISSION_DENIED", "Missing permission " + S6Permissions.EXPORT);
        }
        Report report = parse(Report.class, req.report(), "REPORT_INVALID");
        Format format = parse(Format.class, req.format() == null ? "XLSX" : req.format(), "FORMAT_INVALID");
        ReportFilter filter = req.filter() == null ? ReportFilter.range(null, null) : req.filter();
        ReportTable table = switch (report) {
            case FUNNEL -> funnelTable(funnel.funnel(caller, filter, req.breakdown()));
            case RECRUITER -> performanceTable("Recruiter performance", "Recruiter", performance.recruiters(caller, filter));
            case VENDOR -> performanceTable("Vendor performance", "Vendor", performance.vendors(caller, filter));
            case DRILL -> drillTable(caller, filter, req.drill(), format == Format.PDF ? maxPdfRows : maxRows);
        };
        int limit = format == Format.PDF ? maxPdfRows : maxRows;
        if (table.rows().size() > limit) {
            throw PlatformException.unprocessable("EXPORT_TOO_LARGE", "Export has " + table.rows().size() + " rows; the limit for "
                    + format + " is " + limit + ". Narrow the filters.", null);
        }
        String stamp = STAMP.format(clock.zoned(clock.now()));
        String base = report.name().toLowerCase(Locale.ROOT) + "-report-" + stamp;
        byte[] bytes;
        String type;
        String name;
        try {
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            switch (format) {
                case XLSX -> {
                    new XlsxReportWriter(clock.zone()).write(table, out);
                    type = XlsxReportWriter.contentType();
                    name = base + ".xlsx";
                }
                case CSV -> {
                    new CsvReportWriter(clock.zone()).write(table, out);
                    type = "text/csv; charset=UTF-8";
                    name = base + ".csv";
                }
                default -> {
                    out.write(pdf.render(table, "DigiHire | " + caller.displayName() + " | " + clock.zoned(clock.now()).toLocalDateTime().withNano(0)));
                    type = "application/pdf";
                    name = base + ".pdf";
                }
            }
            bytes = out.toByteArray();
        } catch (IOException e) {
            throw new IllegalStateException("Export failed", e);
        }
        String filters = table.filters().toString();
        jdbc.update("INSERT INTO cand_p6_export_log (id, report, format, row_count, filters, requested_by, requested_at) VALUES (?, ?, ?, ?, ?, ?, ?)",
                UUID.randomUUID().toString(), report.name(), format.name(), table.rows().size(),
                filters.length() > 1990 ? filters.substring(0, 1990) : filters, caller.userId(), Timestamp.from(clock.now()));
        audit.record("ACTIVITY", "REPORT_EXPORTED", "REPORT", report.name(), null, AuditRecorder.details("format", format.name(),
                "rows", table.rows().size(), "filters", table.filters(), "drill", req.drill()));
        return new ExportFile(name, type, bytes, table.rows().size());
    }

    private ReportTable funnelTable(FunnelReport r) {
        List<ReportTable.Column> cols = List.of(ReportTable.Column.text("stage", "Stage", 16), ReportTable.Column.integer("reached", "Reached"),
                ReportTable.Column.percent("fromPrev", "From previous"), ReportTable.Column.percent("fromApplied", "From applied"),
                ReportTable.Column.integer("dropped", "Rejected here"), ReportTable.Column.integer("open", "Open here"),
                ReportTable.Column.decimal("days", "Avg days from applied"));
        List<List<Object>> rows = new ArrayList<>();
        for (FunnelReport.Step s : r.steps()) {
            rows.add(java.util.Arrays.asList(DashboardService.label(s.stage().name()), s.reached(), s.conversionFromPrevious(),
                    s.conversionFromApplied(), s.droppedHere(), s.openHere(), s.avgDaysFromApplied()));
        }
        for (FunnelReport.Breakdown b : r.breakdown()) {
            rows.add(java.util.Arrays.asList(b.dimension() + ": " + b.label(), b.applied(), null, b.conversion(), null, null, null));
        }
        return new ReportTable("Hiring funnel", cols, rows, r.filters());
    }

    private static ReportTable performanceTable(String title, String who, PerformanceReportService.Report r) {
        List<ReportTable.Column> cols = List.of(ReportTable.Column.text("id", who + " id", 18), ReportTable.Column.text("name", who, 26),
                ReportTable.Column.integer("applications", "Applications"), ReportTable.Column.integer("hr", "HR round"),
                ReportTable.Column.integer("selected", "Selected"), ReportTable.Column.integer("offered", "Offered"),
                ReportTable.Column.integer("joined", "Joined"), ReportTable.Column.integer("rejected", "Rejected"),
                ReportTable.Column.integer("open", "Open"), ReportTable.Column.integer("actions", "Actions"),
                ReportTable.Column.percent("conversion", "Joined / applications"), ReportTable.Column.percent("acceptance", "Joined / offered"),
                ReportTable.Column.decimal("daysOffer", "Avg days to offer"), ReportTable.Column.decimal("daysJoin", "Avg days to join"));
        List<List<Object>> rows = new ArrayList<>();
        for (PerformanceRow p : r.rows()) {
            rows.add(perfRow(p));
        }
        rows.add(perfRow(r.total()));
        return new ReportTable(title, cols, rows, r.filters());
    }

    private static List<Object> perfRow(PerformanceRow p) {
        return java.util.Arrays.asList(p.id(), p.name(), p.applications(), p.hrRound(), p.selected(), p.offered(), p.joined(), p.rejected(),
                p.open(), p.actions(), p.conversion(), p.offerAcceptance(), p.avgDaysToOffer(), p.avgDaysToJoin());
    }

    private ReportTable drillTable(Caller caller, ReportFilter filter, String drillKey, int limit) {
        if (!caller.has(S6Permissions.CANDIDATE_EXPORT)) {
            throw PlatformException.forbidden("PERMISSION_DENIED", "Exporting candidate lists needs " + S6Permissions.CANDIDATE_EXPORT);
        }
        List<DrillRow> data = drill.all(caller, filter, drillKey, limit + 1);
        List<ReportTable.Column> cols = List.of(ReportTable.Column.text("app", "Application", 20), ReportTable.Column.text("cand", "Candidate id", 20),
                ReportTable.Column.text("name", "Candidate", 26), ReportTable.Column.text("req", "Requisition", 16),
                ReportTable.Column.text("lob", "LOB", 16), ReportTable.Column.text("loc", "Location", 14), ReportTable.Column.text("role", "Role", 14),
                ReportTable.Column.text("source", "Source", 10), ReportTable.Column.text("hr", "Recruiter", 16),
                ReportTable.Column.text("status", "Status", 20), ReportTable.Column.date("applied", "Applied"),
                ReportTable.Column.dateTime("since", "In status since"), ReportTable.Column.integer("days", "Days in status"));
        List<List<Object>> rows = new ArrayList<>();
        for (DrillRow d : data) {
            rows.add(java.util.Arrays.asList(d.applicationId(), d.candidateId(), d.candidateName(), d.requisitionId(), d.lob(), d.location(),
                    d.roleCode(), d.source(), d.hrUserId(), d.status(), d.appliedDate(), d.statusSince(), d.daysInStatus()));
        }
        java.util.Map<String, String> f = new java.util.LinkedHashMap<>(filter.describe());
        f.put("Drill", drillKey);
        return new ReportTable("Applications", cols, rows, f);
    }

    private static <E extends Enum<E>> E parse(Class<E> type, String v, String code) {
        try {
            return Enum.valueOf(type, v.trim().toUpperCase(Locale.ROOT));
        } catch (RuntimeException e) {
            throw PlatformException.badRequest(code, "Unknown value " + v);
        }
    }
}
