package com.ags.health.hr.candidates.reporting.service;

import com.ags.health.hr.candidates.reporting.domain.DashboardView;
import com.ags.health.hr.candidates.reporting.domain.FunnelReport;
import com.ags.health.hr.candidates.reporting.domain.ReportFilter;
import com.ags.health.hr.candidates.reporting.domain.ReportScope;
import com.ags.health.hr.candidates.reporting.domain.Where;
import com.ags.health.hr.candidates.reporting.port.UserDirectoryPort;
import com.ags.health.hr.candidates.reporting.store.FactStore;
import com.ags.health.hr.candidates.reporting.store.StageEventStore;
import com.ags.health.hr.candidates.s6shared.S6Permissions;
import com.ags.health.hr.candidates.shared.domain.Tab;
import com.ags.health.hr.common.platform.cache.TtlCache;
import com.ags.health.hr.common.platform.caller.Caller;
import com.ags.health.hr.common.platform.time.BusinessClock;

import java.sql.Timestamp;
import java.time.Duration;
import java.time.Instant;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

public class DashboardService {

    public static final List<String> AGING = List.of("D0_2", "D3_7", "D8_14", "D15_30", "D31_PLUS");
    private static final Map<String, String> AGING_LABELS = Map.of("D0_2", "0-2 days", "D3_7", "3-7 days", "D8_14", "8-14 days",
            "D15_30", "15-30 days", "D31_PLUS", "Over 30 days");
    private static final List<Tab> OPEN_TABS = List.of(Tab.APPLICANT, Tab.HR_INTERVIEW, Tab.ASSESSMENT, Tab.VERSANT, Tab.PANEL,
            Tab.PIPELINE, Tab.OFFER);

    private final FactStore facts;
    private final StageEventStore events;
    private final FunnelReportService funnel;
    private final UserDirectoryPort users;
    private final BusinessClock clock;
    private final TtlCache<String, DashboardView> cache;
    private final int maxRangeDays;

    public DashboardService(FactStore facts, StageEventStore events, FunnelReportService funnel, UserDirectoryPort users,
                            BusinessClock clock, Duration cacheTtl, int maxRangeDays) {
        this.facts = facts;
        this.events = events;
        this.funnel = funnel;
        this.users = users;
        this.clock = clock;
        this.cache = new TtlCache<>(cacheTtl, 2000, clock.clock());
        this.maxRangeDays = maxRangeDays;
    }

    public DashboardView dashboard(Caller caller, ReportFilter filter) {
        ReportScope scope = ReportScope.of(caller, S6Permissions.DASHBOARD);
        String key = scope.key() + "#" + filter.cacheKey() + "#" + clock.today() + "#" + caller.has(S6Permissions.FUNNEL);
        long before = cache.stats().loads();
        DashboardView v = cache.get(key, () -> build(caller, scope, filter));
        return v.cached(cache.stats().loads() == before);
    }

    public TtlCache.Stats cacheStats() {
        return cache.stats();
    }

    private DashboardView build(Caller caller, ReportScope scope, ReportFilter filter) {
        boolean dated = filter.from() != null || filter.to() != null;
        ReportFilter current = dated ? filter.withDefaults(clock.today(), 30, maxRangeDays) : filter;
        List<DashboardView.Widget> widgets = new ArrayList<>();
        widgets.add(pipeline(scope, current, dated));
        widgets.add(aging(scope, current, dated));
        widgets.add(movements(scope, current, dated));
        if (caller.has(S6Permissions.FUNNEL)) {
            widgets.add(funnelWidget(scope, filter));
        }
        widgets.add(requisitions(scope, current, dated));
        if (scope.teamOrWider()) {
            widgets.add(recruiters(scope, current, dated));
        }
        return new DashboardView(clock.now(), false, filter.describe(), widgets);
    }

    private DashboardView.Widget pipeline(ReportScope scope, ReportFilter f, boolean dated) {
        Where w = Where.fact(scope, f, dated).raw(FactQueries.OPEN);
        Map<String, Long> counts = new LinkedHashMap<>();
        for (Map<String, Object> r : facts.grouped("tab", "count(*) AS n", w, "grp", 50)) {
            counts.put((String) FactQueries.value(r, "grp"), FactQueries.num(r, "n"));
        }
        List<DashboardView.Bucket> buckets = new ArrayList<>();
        long total = 0;
        for (Tab t : OPEN_TABS) {
            long n = counts.getOrDefault(t.name(), 0L);
            total += n;
            buckets.add(new DashboardView.Bucket(t.name(), label(t.name()), n, "pipeline:" + t.name()));
        }
        return new DashboardView.Widget("pipeline", "Open applications by tab", total, buckets);
    }

    private DashboardView.Widget aging(ReportScope scope, ReportFilter f, boolean dated) {
        Where w = Where.fact(scope, f, dated).raw(FactQueries.OPEN);
        Instant now = clock.now();
        String sql = "SELECT grp, count(*) AS n FROM (SELECT CASE WHEN status_since >= ? THEN 'D0_2' WHEN status_since >= ? THEN 'D3_7' "
                + "WHEN status_since >= ? THEN 'D8_14' WHEN status_since >= ? THEN 'D15_30' ELSE 'D31_PLUS' END AS grp FROM "
                + FactStore.TABLE + w.sql() + ") x GROUP BY grp";
        List<Object> args = new ArrayList<>(agingBounds(now));
        args.addAll(w.argList());
        Map<String, Long> counts = new LinkedHashMap<>();
        for (Map<String, Object> r : facts.jdbc().queryForList(sql, args.toArray())) {
            counts.put((String) FactQueries.value(r, "grp"), FactQueries.num(r, "n"));
        }
        List<DashboardView.Bucket> buckets = new ArrayList<>();
        long total = 0;
        for (String b : AGING) {
            long n = counts.getOrDefault(b, 0L);
            total += n;
            buckets.add(new DashboardView.Bucket(b, AGING_LABELS.get(b), n, "aging:" + b));
        }
        return new DashboardView.Widget("aging", "Days in current status", total, buckets);
    }

    static List<Object> agingBounds(Instant now) {
        return List.of(Timestamp.from(now.minus(Duration.ofDays(3))), Timestamp.from(now.minus(Duration.ofDays(8))),
                Timestamp.from(now.minus(Duration.ofDays(15))), Timestamp.from(now.minus(Duration.ofDays(31))));
    }

    private DashboardView.Widget movements(ReportScope scope, ReportFilter f, boolean dated) {
        List<DashboardView.Bucket> buckets = new ArrayList<>();
        long total = 0;
        for (Map<String, Object> r : events.movesByTab(Where.fact("f", scope, f, dated), clock.today())) {
            String tab = (String) FactQueries.value(r, "grp");
            long n = FactQueries.num(r, "n");
            total += n;
            buckets.add(new DashboardView.Bucket(tab, label(tab), n, "movements:" + tab));
        }
        return new DashboardView.Widget("movements", "Moves today", total, buckets);
    }

    private DashboardView.Widget funnelWidget(ReportScope scope, ReportFilter f) {
        FunnelReport report = funnel.funnel(scope, f, null);
        List<DashboardView.Bucket> buckets = new ArrayList<>();
        for (FunnelReport.Step s : report.steps()) {
            buckets.add(new DashboardView.Bucket(s.stage().name(), label(s.stage().name()), s.reached(), "funnel:" + s.stage().name()));
        }
        return new DashboardView.Widget("funnel", "Hiring funnel " + report.from() + " to " + report.to(), report.total(), buckets);
    }

    private DashboardView.Widget requisitions(ReportScope scope, ReportFilter f, boolean dated) {
        Where w = Where.fact(scope, f, dated).raw(FactQueries.OPEN).raw("requisition_id IS NOT NULL");
        List<DashboardView.Bucket> buckets = new ArrayList<>();
        long total = 0;
        for (Map<String, Object> r : facts.grouped("requisition_id", "count(*) AS n", w, "n DESC, grp", 10)) {
            String id = (String) FactQueries.value(r, "grp");
            long n = FactQueries.num(r, "n");
            total += n;
            buckets.add(new DashboardView.Bucket(id, id, n, "requisition:" + id));
        }
        return new DashboardView.Widget("requisitions", "Requisitions with most open applications", total, buckets);
    }

    private DashboardView.Widget recruiters(ReportScope scope, ReportFilter f, boolean dated) {
        Where w = Where.fact(scope, f, dated).raw(FactQueries.OPEN).raw("hr_user_id IS NOT NULL");
        List<Map<String, Object>> rows = facts.grouped("hr_user_id", "count(*) AS n", w, "n DESC, grp", 10);
        Map<String, String> names = users.names(rows.stream().map(r -> (String) FactQueries.value(r, "grp")).filter(Objects::nonNull).toList());
        List<DashboardView.Bucket> buckets = new ArrayList<>();
        long total = 0;
        for (Map<String, Object> r : rows) {
            String id = (String) FactQueries.value(r, "grp");
            long n = FactQueries.num(r, "n");
            total += n;
            buckets.add(new DashboardView.Bucket(id, names.getOrDefault(id, id), n, "recruiter:" + id));
        }
        return new DashboardView.Widget("recruiters", "Open applications by recruiter", total, buckets);
    }

    static String label(String code) {
        if (code == null) {
            return "(not set)";
        }
        String s = code.replace('_', ' ').toLowerCase(java.util.Locale.ROOT);
        return Character.toUpperCase(s.charAt(0)) + s.substring(1);
    }
}
