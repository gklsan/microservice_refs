package com.ags.health.hr.candidates.s6shared;

import lombok.Getter;
import lombok.Setter;
import org.springframework.boot.context.properties.ConfigurationProperties;

import java.util.ArrayList;
import java.util.List;

@Getter
@Setter
@ConfigurationProperties(prefix = "digihire.s6")
public class CandidateS6Properties {

    private boolean schemaInit = true;
    private String environment = "dev";
    private Reporting reporting = new Reporting();
    private Worklist worklist = new Worklist();
    private Concurrency concurrency = new Concurrency();
    private Readiness readiness = new Readiness();

    @Getter
    @Setter
    public static class Reporting {
        private boolean enabled = true;
        private int maxRangeDays = 366;
        private int dashboardCacheSeconds = 60;
        private int optionsCacheSeconds = 300;
        private int maxPageSize = 200;
        private int maxExportRows = 100_000;
        private int maxPdfRows = 2_000;
        private double accuracyThreshold = 99.0;
        private boolean accuracyRepair = true;
        private int accuracyBatch = 500;
        private int dirtyBatch = 200;
        private String accuracyCron = "0 40 1 * * *";
        private String dirtyCron = "0 */5 * * * *";
        private String auditCheckCron = "0 10 2 * * *";
        private List<String> directoryRoles = new ArrayList<>(List.of("RECRUITER", "RECRUITMENT_MANAGER", "TA_HEAD"));
        private int directoryCacheMinutes = 10;
        private int auditMatchSeconds = 5;
    }

    @Getter
    @Setter
    public static class Worklist {
        private boolean enabled = true;
        private int maxPageSize = 100;
        private int countCap = 1000;
        private int requisitionCacheSeconds = 60;
        private int batchAssessMax = 25;
        private int batchAssessThreads = 4;
    }

    @Getter
    @Setter
    public static class Concurrency {
        private boolean enabled = true;
        private boolean staleCheck = true;
        private boolean rowLock = true;
        private int idempotencyTtlHours = 24;
        private int inFlightSeconds = 120;
        private List<String> idempotentPaths = new ArrayList<>(List.of("/mapping/map", "/pipeline/bulk-status",
                "/pipeline/bulk-status/upload", "/applicants/*/move", "/applicants/*/reject", "/applicants/*/move-to-hr",
                "/applicants/*/move-to-pipeline", "/applicants/*/offer/push"));
    }

    @Getter
    @Setter
    public static class Readiness {
        private boolean enabled = true;
        private int timeoutSeconds = 10;
        private long outboxWarn = 200;
        private long outboxFail = 2000;
        private long dirtyWarn = 50;
        private long dirtyFail = 1000;
        private int checkMaxAgeHours = 48;
    }
}
