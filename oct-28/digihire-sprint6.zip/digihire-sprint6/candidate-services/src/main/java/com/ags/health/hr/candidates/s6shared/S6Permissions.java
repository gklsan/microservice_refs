package com.ags.health.hr.candidates.s6shared;

public final class S6Permissions {

    public static final String DASHBOARD = "REPORT:VIEW";
    public static final String FUNNEL = "REPORT:FUNNEL";
    public static final String RECRUITER = "REPORT:RECRUITER";
    public static final String VENDOR = "REPORT:VENDOR";
    public static final String EXPORT = "REPORT:EXPORT";
    public static final String QUALITY = "REPORT:QUALITY";
    public static final String CANDIDATE_EXPORT = "CANDIDATE:EXPORT";
    public static final String CANDIDATE_VIEW = "CANDIDATE:VIEW";
    public static final String MAP = "APPLICATION:MAP";
    public static final String READINESS = "OPS:READINESS";

    private S6Permissions() {
    }
}
