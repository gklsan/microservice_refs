package com.ags.health.hr.candidates.reporting.service;

import com.ags.health.hr.candidates.reporting.domain.FactRow;
import com.ags.health.hr.candidates.reporting.port.ReportSourcePort;
import com.ags.health.hr.candidates.reporting.port.SourceApplication;
import com.ags.health.hr.candidates.reporting.store.DirtyStore;
import com.ags.health.hr.candidates.reporting.store.FactStore;
import com.ags.health.hr.candidates.reporting.store.StageEventStore;
import com.ags.health.hr.candidates.shared.service.StatusMoveListener;
import com.ags.health.hr.candidates.shared.service.StatusMovedEvent;
import com.ags.health.hr.common.platform.time.BusinessClock;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.transaction.support.TransactionTemplate;

import java.util.Optional;

public class FactProjector implements StatusMoveListener {

    private static final Logger log = LoggerFactory.getLogger(FactProjector.class);

    private final FactStore facts;
    private final StageEventStore events;
    private final DirtyStore dirty;
    private final ReportSourcePort source;
    private final FactCalculator calc;
    private final BusinessClock clock;
    private final TransactionTemplate requiresNew;

    public FactProjector(FactStore facts, StageEventStore events, DirtyStore dirty, ReportSourcePort source, FactCalculator calc,
                         BusinessClock clock, TransactionTemplate requiresNew) {
        this.facts = facts;
        this.events = events;
        this.dirty = dirty;
        this.source = source;
        this.calc = calc;
        this.clock = clock;
        this.requiresNew = requiresNew;
    }

    @Override
    public void onMoved(StatusMovedEvent e) {
        AfterCommit.run(() -> {
            if (requiresNew == null) {
                project(e);
            } else {
                try {
                    requiresNew.execute(s -> {
                        project(e);
                        return null;
                    });
                } catch (RuntimeException ex) {
                    log.warn("REPORT_FACT_PROJECTION_TX_FAILED application={} error={}", e.application().id(), ex.getMessage());
                }
            }
        });
    }

    void project(StatusMovedEvent e) {
        String id = e.application().id();
        try {
            events.append(new StageEventStore.Event(id, e.fromStatus(), e.toStatus(), e.fromTab() == null ? null : e.fromTab().name(),
                    e.toTab().name(), e.reasonCode(), e.actorId(), e.system(), e.at(), clock.dateOf(e.at())));
            Optional<FactRow> existing = facts.find(id);
            if (existing.isPresent()) {
                facts.save(calc.apply(existing.get(), e));
                return;
            }
            Optional<SourceApplication> src = loadQuietly(id);
            if (src.isPresent() && !src.get().history().isEmpty()) {
                facts.save(calc.fromSource(src.get()));
            } else {
                facts.save(calc.fromEvent(e, src.map(SourceApplication::candidateName).orElse(null),
                        src.map(SourceApplication::vendorId).orElse(null)));
            }
        } catch (RuntimeException ex) {
            log.warn("REPORT_FACT_PROJECTION_FAILED application={} error={}", id, ex.getMessage());
            try {
                dirty.mark(id, ex.getClass().getSimpleName() + ": " + ex.getMessage(), clock.now());
            } catch (RuntimeException again) {
                log.error("REPORT_FACT_DIRTY_MARK_FAILED application={} error={}", id, again.getMessage());
            }
        }
    }

    private Optional<SourceApplication> loadQuietly(String id) {
        try {
            return source.load(id);
        } catch (RuntimeException e) {
            log.warn("Report source lookup for {} failed: {}", id, e.getMessage());
            return Optional.empty();
        }
    }
}
