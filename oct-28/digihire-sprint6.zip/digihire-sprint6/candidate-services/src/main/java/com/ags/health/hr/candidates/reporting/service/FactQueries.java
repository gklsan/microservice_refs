package com.ags.health.hr.candidates.reporting.service;

import com.ags.health.hr.candidates.reporting.domain.FunnelStage;
import com.ags.health.hr.candidates.reporting.store.SqlDialect;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.Map;

final class FactQueries {

    static final String OPEN = "tab NOT IN ('REJECTED', 'JOINED', 'CLOSED')";

    private FactQueries() {
    }

    static String reached(FunnelStage s) {
        return "SUM(CASE WHEN " + s.reachedSql() + " THEN 1 ELSE 0 END)";
    }

    static String openAt(FunnelStage s) {
        String cond = switch (s) {
            case APPLIED -> "tab IN ('APPLICANT', 'MAP_CANDIDATE', 'PIPELINE')";
            case HR_ROUND -> "tab = 'HR_INTERVIEW'";
            case ASSESSMENT -> "tab = 'ASSESSMENT'";
            case VERSANT -> "tab = 'VERSANT'";
            case PANEL -> "tab = 'PANEL'";
            case SELECTED -> "status IN ('PANEL_SELECTED', 'SHORTLISTED')";
            case OFFERED -> "status = 'OFFERED'";
            case JOINED -> "status = 'JOINED'";
        };
        return "SUM(CASE WHEN " + cond + " THEN 1 ELSE 0 END)";
    }

    static String performance(SqlDialect d) {
        return "count(*) AS applications, " + reached(FunnelStage.HR_ROUND) + " AS hr_round, " + reached(FunnelStage.SELECTED)
                + " AS selected, " + reached(FunnelStage.OFFERED) + " AS offered, " + reached(FunnelStage.JOINED) + " AS joined, "
                + "SUM(CASE WHEN tab = 'REJECTED' THEN 1 ELSE 0 END) AS rejected, SUM(CASE WHEN " + OPEN + " THEN 1 ELSE 0 END) AS open_count, "
                + "AVG(CASE WHEN offered_at IS NOT NULL THEN " + d.daysBetween("applied_at", "offered_at") + " END) AS days_offer, "
                + "AVG(CASE WHEN joined_at IS NOT NULL THEN " + d.daysBetween("applied_at", "joined_at") + " END) AS days_join";
    }

    static long num(Map<String, Object> row, String key) {
        Object v = value(row, key);
        return v instanceof Number n ? n.longValue() : 0;
    }

    static Double dbl(Map<String, Object> row, String key) {
        Object v = value(row, key);
        return v instanceof Number n ? round(n.doubleValue(), 2) : null;
    }

    static Object value(Map<String, Object> row, String key) {
        if (row.containsKey(key)) {
            return row.get(key);
        }
        for (Map.Entry<String, Object> e : row.entrySet()) {
            if (e.getKey().equalsIgnoreCase(key)) {
                return e.getValue();
            }
        }
        return null;
    }

    static Double ratio(long part, long whole) {
        return whole <= 0 ? null : round((double) part / whole, 4);
    }

    static double round(double v, int scale) {
        return BigDecimal.valueOf(v).setScale(scale, RoundingMode.HALF_UP).doubleValue();
    }
}
