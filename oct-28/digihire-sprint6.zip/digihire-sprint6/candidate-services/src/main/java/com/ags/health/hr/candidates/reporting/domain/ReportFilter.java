package com.ags.health.hr.candidates.reporting.domain;

import com.ags.health.hr.common.platform.error.PlatformException;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;

public record ReportFilter(LocalDate from, LocalDate to, Set<String> lobs, Set<String> locations, Set<String> recruiterIds,
                           Set<String> vendorIds, Set<String> sources, Set<String> requisitionIds, Set<String> roles,
                           Set<String> tabs, Set<String> statuses, String q) {

    private static final int MAX_VALUES = 200;

    public ReportFilter {
        lobs = clean(lobs, false);
        locations = clean(locations, false);
        recruiterIds = clean(recruiterIds, false);
        vendorIds = clean(vendorIds, false);
        sources = clean(sources, true);
        requisitionIds = clean(requisitionIds, false);
        roles = clean(roles, false);
        tabs = clean(tabs, true);
        statuses = clean(statuses, true);
        q = q == null || q.isBlank() ? null : q.trim();
        if (q != null && q.length() > 100) {
            q = q.substring(0, 100);
        }
    }

    public static ReportFilter range(LocalDate from, LocalDate to) {
        return new ReportFilter(from, to, null, null, null, null, null, null, null, null, null, null);
    }

    public ReportFilter withDefaults(LocalDate today, int defaultDays, int maxDays) {
        LocalDate t = to == null ? today : to;
        LocalDate f = from == null ? t.minusDays(defaultDays - 1L) : from;
        if (f.isAfter(t)) {
            throw PlatformException.badRequest("DATE_RANGE_INVALID", "'from' must not be after 'to'");
        }
        if (ChronoUnit.DAYS.between(f, t) + 1 > maxDays) {
            throw PlatformException.badRequest("DATE_RANGE_TOO_LONG", "Date range can be at most " + maxDays + " days");
        }
        return new ReportFilter(f, t, lobs, locations, recruiterIds, vendorIds, sources, requisitionIds, roles, tabs, statuses, q);
    }

    public ReportFilter withoutDates() {
        return new ReportFilter(null, null, lobs, locations, recruiterIds, vendorIds, sources, requisitionIds, roles, tabs, statuses, q);
    }

    public Map<String, String> describe() {
        Map<String, String> m = new LinkedHashMap<>();
        if (from != null) {
            m.put("From", from.toString());
        }
        if (to != null) {
            m.put("To", to.toString());
        }
        put(m, "LOB", lobs);
        put(m, "Location", locations);
        put(m, "Recruiter", recruiterIds);
        put(m, "Vendor", vendorIds);
        put(m, "Source", sources);
        put(m, "Requisition", requisitionIds);
        put(m, "Role", roles);
        put(m, "Tab", tabs);
        put(m, "Status", statuses);
        if (q != null) {
            m.put("Search", q);
        }
        return m;
    }

    public String cacheKey() {
        return describe().toString();
    }

    private static void put(Map<String, String> m, String k, Set<String> v) {
        if (!v.isEmpty()) {
            m.put(k, String.join(", ", v));
        }
    }

    private static Set<String> clean(Set<String> in, boolean upper) {
        if (in == null || in.isEmpty()) {
            return Set.of();
        }
        TreeSet<String> out = new TreeSet<>();
        for (String s : in) {
            if (s != null && !s.isBlank()) {
                String v = s.trim();
                out.add(upper ? v.toUpperCase(Locale.ROOT) : v);
            }
        }
        if (out.size() > MAX_VALUES) {
            throw PlatformException.badRequest("FILTER_TOO_LARGE", "A filter can hold at most " + MAX_VALUES + " values");
        }
        return Set.copyOf(out);
    }

    public static Set<String> split(String csv) {
        if (csv == null || csv.isBlank()) {
            return Set.of();
        }
        return Set.copyOf(List.of(csv.split(",")).stream().map(String::trim).filter(s -> !s.isEmpty()).toList());
    }
}
