package com.ags.health.hr.candidates.reporting.service;

import com.ags.health.hr.candidates.reporting.domain.FunnelReport;
import com.ags.health.hr.candidates.reporting.domain.FunnelStage;
import com.ags.health.hr.candidates.reporting.domain.ReportFilter;
import com.ags.health.hr.candidates.reporting.domain.ReportScope;
import com.ags.health.hr.candidates.reporting.domain.Where;
import com.ags.health.hr.candidates.reporting.port.UserDirectoryPort;
import com.ags.health.hr.candidates.reporting.port.VendorDirectoryPort;
import com.ags.health.hr.candidates.reporting.store.FactStore;
import com.ags.health.hr.candidates.s6shared.S6Permissions;
import com.ags.health.hr.common.platform.caller.Caller;
import com.ags.health.hr.common.platform.error.PlatformException;
import com.ags.health.hr.common.platform.time.BusinessClock;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public class FunnelReportService {

    static final Map<String, String> DIMENSIONS = Map.of("lob", "lob", "location", "location", "source", "source", "recruiter",
            "hr_user_id", "vendor", "vendor_id", "role", "role_code", "requisition", "requisition_id");

    private final FactStore facts;
    private final UserDirectoryPort users;
    private final VendorDirectoryPort vendors;
    private final BusinessClock clock;
    private final int maxRangeDays;

    public FunnelReportService(FactStore facts, UserDirectoryPort users, VendorDirectoryPort vendors, BusinessClock clock, int maxRangeDays) {
        this.facts = facts;
        this.users = users;
        this.vendors = vendors;
        this.clock = clock;
        this.maxRangeDays = maxRangeDays;
    }

    public FunnelReport funnel(Caller caller, ReportFilter filter, String breakdown) {
        ReportScope scope = ReportScope.of(caller, S6Permissions.FUNNEL);
        return funnel(scope, filter, breakdown);
    }

    FunnelReport funnel(ReportScope scope, ReportFilter raw, String breakdown) {
        ReportFilter filter = raw.withDefaults(clock.today(), 30, maxRangeDays);
        Where w = Where.fact(scope, filter, true);
        StringBuilder select = new StringBuilder("count(*) AS total");
        for (FunnelStage s : FunnelStage.values()) {
            String k = s.name().toLowerCase(Locale.ROOT);
            select.append(", ").append(FactQueries.reached(s)).append(" AS r_").append(k);
            select.append(", ").append(FactQueries.openAt(s)).append(" AS o_").append(k);
            select.append(", SUM(CASE WHEN tab = 'REJECTED' AND rejected_stage = '").append(s.name()).append("' THEN 1 ELSE 0 END) AS d_").append(k);
            if (s != FunnelStage.APPLIED) {
                select.append(", AVG(CASE WHEN ").append(s.column()).append(" IS NOT NULL THEN ")
                        .append(facts.dialect().daysBetween("applied_at", s.column())).append(" END) AS a_").append(k);
            }
        }
        Map<String, Object> row = facts.aggregate(select.toString(), w);
        long total = FactQueries.num(row, "total");
        List<FunnelReport.Step> steps = new ArrayList<>();
        long previous = total;
        for (FunnelStage s : FunnelStage.values()) {
            String k = s.name().toLowerCase(Locale.ROOT);
            long reached = FactQueries.num(row, "r_" + k);
            steps.add(new FunnelReport.Step(s, reached, s == FunnelStage.APPLIED ? null : FactQueries.ratio(reached, previous),
                    FactQueries.ratio(reached, total), FactQueries.num(row, "d_" + k), FactQueries.num(row, "o_" + k),
                    s == FunnelStage.APPLIED ? null : FactQueries.dbl(row, "a_" + k)));
            previous = reached;
        }
        return new FunnelReport(filter.from(), filter.to(), total, steps, breakdown(w, breakdown), filter.describe());
    }

    private List<FunnelReport.Breakdown> breakdown(Where w, String dimension) {
        if (dimension == null || dimension.isBlank()) {
            return List.of();
        }
        String key = dimension.trim().toLowerCase(Locale.ROOT);
        String column = DIMENSIONS.get(key);
        if (column == null) {
            throw PlatformException.badRequest("BREAKDOWN_INVALID", "Breakdown must be one of " + DIMENSIONS.keySet());
        }
        String select = "count(*) AS applied, " + FactQueries.reached(FunnelStage.HR_ROUND) + " AS hr_round, "
                + FactQueries.reached(FunnelStage.SELECTED) + " AS selected, " + FactQueries.reached(FunnelStage.OFFERED) + " AS offered, "
                + FactQueries.reached(FunnelStage.JOINED) + " AS joined";
        List<Map<String, Object>> rows = facts.grouped(column, select, w, "applied DESC, grp", 100);
        List<String> ids = rows.stream().map(r -> (String) FactQueries.value(r, "grp")).filter(java.util.Objects::nonNull).toList();
        Map<String, String> labels = "recruiter".equals(key) ? users.names(ids) : "vendor".equals(key) ? vendors.names(ids) : Map.of();
        List<FunnelReport.Breakdown> out = new ArrayList<>();
        for (Map<String, Object> r : rows) {
            String v = (String) FactQueries.value(r, "grp");
            long applied = FactQueries.num(r, "applied");
            long joined = FactQueries.num(r, "joined");
            out.add(new FunnelReport.Breakdown(key, v, v == null ? "(not set)" : labels.getOrDefault(v, v), applied,
                    FactQueries.num(r, "hr_round"), FactQueries.num(r, "selected"), FactQueries.num(r, "offered"), joined,
                    FactQueries.ratio(joined, applied)));
        }
        return out;
    }
}
