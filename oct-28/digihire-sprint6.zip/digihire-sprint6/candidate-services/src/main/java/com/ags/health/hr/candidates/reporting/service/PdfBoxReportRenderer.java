package com.ags.health.hr.candidates.reporting.service;

import com.ags.health.hr.common.platform.export.ReportTable;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.pdmodel.PDPageContentStream;
import org.apache.pdfbox.pdmodel.common.PDRectangle;
import org.apache.pdfbox.pdmodel.font.PDType1Font;
import org.apache.pdfbox.pdmodel.font.Standard14Fonts;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.Instant;
import java.time.LocalDate;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Map;

public class PdfBoxReportRenderer implements ReportPdfRenderer {

    private static final float MARGIN = 36f;
    private static final float ROW = 13f;
    private static final DateTimeFormatter DATE = DateTimeFormatter.ofPattern("dd-MMM-yyyy");
    private static final DateTimeFormatter DATE_TIME = DateTimeFormatter.ofPattern("dd-MMM-yyyy HH:mm");

    private final ZoneId zone;

    public PdfBoxReportRenderer(ZoneId zone) {
        this.zone = zone;
    }

    @Override
    public byte[] render(ReportTable table, String footer) {
        PDType1Font regular = new PDType1Font(Standard14Fonts.FontName.HELVETICA);
        PDType1Font bold = new PDType1Font(Standard14Fonts.FontName.HELVETICA_BOLD);
        PDRectangle size = new PDRectangle(PDRectangle.A4.getHeight(), PDRectangle.A4.getWidth());
        float usable = size.getWidth() - 2 * MARGIN;
        float[] widths = widths(table.columns(), usable);
        try (PDDocument pdf = new PDDocument(); ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            int pageNo = 0;
            int index = 0;
            List<List<Object>> rows = table.rows();
            do {
                PDPage page = new PDPage(size);
                pdf.addPage(page);
                pageNo++;
                try (PDPageContentStream cs = new PDPageContentStream(pdf, page)) {
                    float y = size.getHeight() - MARGIN;
                    if (pageNo == 1) {
                        text(cs, bold, 13, MARGIN, y, table.title(), 120);
                        y -= ROW * 1.6f;
                        for (Map.Entry<String, String> f : table.filters().entrySet()) {
                            text(cs, regular, 8, MARGIN, y, f.getKey() + ": " + f.getValue(), 160);
                            y -= ROW * 0.9f;
                        }
                        y -= ROW * 0.5f;
                    }
                    float x = MARGIN;
                    for (int c = 0; c < table.columns().size(); c++) {
                        text(cs, bold, 8, x, y, table.columns().get(c).header(), chars(widths[c]));
                        x += widths[c];
                    }
                    y -= ROW;
                    while (index < rows.size() && y > MARGIN + ROW) {
                        x = MARGIN;
                        List<Object> r = rows.get(index++);
                        for (int c = 0; c < r.size(); c++) {
                            text(cs, regular, 8, x, y, format(table.columns().get(c).kind(), r.get(c)), chars(widths[c]));
                            x += widths[c];
                        }
                        y -= ROW;
                    }
                    text(cs, regular, 7, MARGIN, MARGIN / 2, footer + "   Page " + pageNo, 200);
                }
            } while (index < rows.size());
            pdf.save(out);
            return out.toByteArray();
        } catch (IOException e) {
            throw new IllegalStateException("Could not render the report PDF", e);
        }
    }

    private static float[] widths(List<ReportTable.Column> columns, float usable) {
        float total = 0;
        for (ReportTable.Column c : columns) {
            total += Math.max(6, c.width());
        }
        float[] w = new float[columns.size()];
        for (int i = 0; i < w.length; i++) {
            w[i] = usable * Math.max(6, columns.get(i).width()) / total;
        }
        return w;
    }

    private static int chars(float width) {
        return Math.max(4, (int) (width / 4.6f));
    }

    String format(ReportTable.Kind kind, Object v) {
        if (v == null) {
            return "";
        }
        return switch (kind) {
            case DATE -> v instanceof LocalDate d ? DATE.format(d) : v instanceof Instant i ? DATE.format(i.atZone(zone)) : String.valueOf(v);
            case DATETIME -> v instanceof Instant i ? DATE_TIME.format(i.atZone(zone)) : String.valueOf(v);
            case PERCENT -> v instanceof Number n ? BigDecimal.valueOf(n.doubleValue() * 100).setScale(1, RoundingMode.HALF_UP) + "%" : String.valueOf(v);
            default -> String.valueOf(v);
        };
    }

    private static void text(PDPageContentStream cs, PDType1Font font, float size, float x, float y, String value, int max)
            throws IOException {
        cs.beginText();
        cs.setFont(font, size);
        cs.newLineAtOffset(x, y);
        cs.showText(safe(value, max));
        cs.endText();
    }

    static String safe(String value, int max) {
        if (value == null) {
            return "";
        }
        StringBuilder sb = new StringBuilder(value.length());
        for (char c : value.toCharArray()) {
            sb.append(c >= 0x20 && c <= 0x7E ? c : (c >= 0xA0 && c <= 0xFF ? c : '?'));
        }
        return sb.length() > max ? sb.substring(0, Math.max(1, max - 3)) + "..." : sb.toString();
    }
}
