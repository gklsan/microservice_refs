package com.ags.health.hr.candidates.worklist;

import com.ags.health.hr.candidates.mapping.domain.MappingAssessment;
import com.ags.health.hr.candidates.mapping.service.MappingService;
import com.ags.health.hr.common.platform.caller.Caller;
import com.ags.health.hr.common.platform.error.PlatformException;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Future;

public class MapCandidateBatchService {

    public record Item(int index, MappingService.AssessRequest request, MappingAssessment assessment, String errorCode, String error) {
    }

    private final MappingService mapping;
    private final ExecutorService pool;
    private final int max;

    public MapCandidateBatchService(MappingService mapping, ExecutorService pool, int max) {
        this.mapping = mapping;
        this.pool = pool;
        this.max = max;
    }

    public List<Item> assess(Caller caller, List<MappingService.AssessRequest> requests) {
        if (requests == null || requests.isEmpty()) {
            return List.of();
        }
        if (requests.size() > max) {
            throw PlatformException.badRequest("BATCH_TOO_LARGE", "Send at most " + max + " candidates per call");
        }
        List<Future<MappingAssessment>> futures = new ArrayList<>();
        for (MappingService.AssessRequest r : requests) {
            futures.add(pool.submit(() -> mapping.assess(caller, r)));
        }
        List<Item> out = new ArrayList<>();
        for (int i = 0; i < futures.size(); i++) {
            MappingService.AssessRequest r = requests.get(i);
            try {
                out.add(new Item(i, r, futures.get(i).get(), null, null));
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                out.add(new Item(i, r, null, "INTERRUPTED", "Interrupted"));
            } catch (ExecutionException e) {
                Throwable c = e.getCause();
                if (c instanceof PlatformException p) {
                    out.add(new Item(i, r, null, p.getCode(), p.getMessage()));
                } else {
                    out.add(new Item(i, r, null, "ASSESS_FAILED", c == null ? "Failed" : c.getMessage()));
                }
            }
        }
        return out;
    }
}
