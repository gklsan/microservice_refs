package com.ags.health.hr.candidates.worklist;

import com.ags.health.hr.candidates.reporting.domain.DrillRow;
import com.ags.health.hr.candidates.reporting.domain.ReportFilter;
import com.ags.health.hr.candidates.reporting.domain.ReportScope;
import com.ags.health.hr.candidates.reporting.domain.Where;
import com.ags.health.hr.candidates.reporting.store.FactStore;
import com.ags.health.hr.candidates.s6shared.S6Permissions;
import com.ags.health.hr.candidates.shared.domain.Tab;
import com.ags.health.hr.common.platform.caller.Caller;
import com.ags.health.hr.common.platform.error.PlatformException;
import com.ags.health.hr.common.platform.time.BusinessClock;

import java.nio.charset.StandardCharsets;
import java.sql.Date;
import java.sql.Timestamp;
import java.time.Instant;
import java.time.LocalDate;
import java.util.Base64;
import java.util.List;
import java.util.Locale;

public class WorklistService {

    public enum Sort { RECENT, OLDEST, APPLIED_DESC }

    private final FactStore facts;
    private final BusinessClock clock;
    private final int maxPageSize;
    private final int countCap;

    public WorklistService(FactStore facts, BusinessClock clock, int maxPageSize, int countCap) {
        this.facts = facts;
        this.clock = clock;
        this.maxPageSize = maxPageSize;
        this.countCap = countCap;
    }

    public WorklistPage page(Caller caller, WorklistQuery q) {
        ReportScope scope = ReportScope.of(caller, S6Permissions.CANDIDATE_VIEW);
        Tab tab = tab(q.tab());
        int size = Math.max(1, Math.min(q.size() <= 0 ? 25 : q.size(), maxPageSize));
        Sort sort = sort(q.sort());
        ReportFilter f = new ReportFilter(null, null, q.lobs(), q.locations(), q.recruiterIds(), null, null, q.requisitionIds(), null,
                tab == null ? null : java.util.Set.of(tab.name()), q.statuses(), q.q());
        Where base = Where.fact(scope, f, false);
        Long count = null;
        boolean capped = false;
        if (q.withCount()) {
            long n = facts.countCapped(base, countCap);
            capped = n > countCap;
            count = capped ? (long) countCap : n;
        }
        Where w = Where.fact(scope, f, false);
        Cursor c = Cursor.decode(q.cursor());
        String order;
        switch (sort) {
            case OLDEST -> {
                if (c != null) {
                    w.raw("(status_since > ? OR (status_since = ? AND application_id > ?))", c.ts(), c.ts(), c.id());
                }
                order = "status_since ASC, application_id ASC";
            }
            case APPLIED_DESC -> {
                if (c != null) {
                    w.raw("(applied_date < ? OR (applied_date = ? AND application_id < ?))", c.date(), c.date(), c.id());
                }
                order = "applied_date DESC, application_id DESC";
            }
            default -> {
                if (c != null) {
                    w.raw("(status_since < ? OR (status_since = ? AND application_id < ?))", c.ts(), c.ts(), c.id());
                }
                order = "status_since DESC, application_id DESC";
            }
        }
        List<DrillRow> rows = facts.keyset(w, order, size + 1, clock.now());
        String next = null;
        if (rows.size() > size) {
            rows = rows.subList(0, size);
            DrillRow last = rows.get(rows.size() - 1);
            next = sort == Sort.APPLIED_DESC ? Cursor.encode(last.appliedDate().toString(), last.applicationId())
                    : Cursor.encode(last.statusSince().toString(), last.applicationId());
        }
        return new WorklistPage(rows, next, count, capped);
    }

    private static Tab tab(String v) {
        if (v == null || v.isBlank()) {
            return null;
        }
        try {
            return Tab.valueOf(v.trim().toUpperCase(Locale.ROOT));
        } catch (IllegalArgumentException e) {
            throw PlatformException.badRequest("TAB_INVALID", "Unknown tab " + v);
        }
    }

    private static Sort sort(String v) {
        if (v == null || v.isBlank()) {
            return Sort.RECENT;
        }
        try {
            return Sort.valueOf(v.trim().toUpperCase(Locale.ROOT));
        } catch (IllegalArgumentException e) {
            throw PlatformException.badRequest("SORT_INVALID", "Sort must be RECENT, OLDEST or APPLIED_DESC");
        }
    }

    record Cursor(String key, String id) {

        static String encode(String key, String id) {
            return Base64.getUrlEncoder().withoutPadding().encodeToString((key + "|" + id).getBytes(StandardCharsets.UTF_8));
        }

        static Cursor decode(String v) {
            if (v == null || v.isBlank()) {
                return null;
            }
            try {
                String s = new String(Base64.getUrlDecoder().decode(v.trim()), StandardCharsets.UTF_8);
                int i = s.indexOf('|');
                if (i <= 0 || i == s.length() - 1) {
                    throw new IllegalArgumentException();
                }
                return new Cursor(s.substring(0, i), s.substring(i + 1));
            } catch (IllegalArgumentException e) {
                throw PlatformException.badRequest("CURSOR_INVALID", "Cursor is not valid; start again without it");
            }
        }

        Timestamp ts() {
            try {
                return Timestamp.from(Instant.parse(key));
            } catch (RuntimeException e) {
                throw PlatformException.badRequest("CURSOR_INVALID", "Cursor does not match the sort");
            }
        }

        Date date() {
            try {
                return Date.valueOf(LocalDate.parse(key));
            } catch (RuntimeException e) {
                throw PlatformException.badRequest("CURSOR_INVALID", "Cursor does not match the sort");
            }
        }
    }
}
