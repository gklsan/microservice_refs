package com.ags.health.hr.candidates.reporting.domain;

import java.time.Instant;
import java.time.LocalDate;
import java.util.List;

public record CheckRun(String id, String kind, LocalDate from, LocalDate to, int checked, int matched, int mismatched, int missing,
                       int repaired, double score, double threshold, String status, List<String> sample, Instant startedAt,
                       Instant finishedAt) {

    public static final String ACCURACY = "REPORT_ACCURACY";
    public static final String AUDIT = "AUDIT_COMPLETENESS";

    public CheckRun {
        sample = sample == null ? List.of() : List.copyOf(sample);
    }
}
