package com.ags.health.hr.candidates.worklist;

import com.ags.health.hr.candidates.mapping.service.MappingService;
import com.ags.health.hr.candidates.reporting.store.FactStore;
import com.ags.health.hr.candidates.s6shared.CandidateS6Properties;
import com.ags.health.hr.candidates.shared.client.JobServicesRequisitionClient;
import com.ags.health.hr.candidates.shared.config.CandidateP5Properties;
import com.ags.health.hr.candidates.shared.port.RequisitionPort;
import com.ags.health.hr.common.platform.http.InternalHttp;
import com.ags.health.hr.common.platform.time.BusinessClock;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;

import java.time.Clock;
import java.time.Duration;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

@Configuration
@ConditionalOnProperty(prefix = "digihire.s6.worklist", name = "enabled", havingValue = "true", matchIfMissing = true)
public class WorklistConfig {

    @Bean
    @Primary
    @ConditionalOnProperty(prefix = "digihire.s6.worklist", name = "cache-requisitions", havingValue = "true", matchIfMissing = true)
    public RequisitionPort p6CachingRequisitionPort(InternalHttp p5InternalHttp, CandidateP5Properties p5, CandidateS6Properties s6, Clock p5Clock) {
        return new CachingRequisitionPort(new JobServicesRequisitionClient(p5InternalHttp, p5.getClients().getJobUrl()),
                Duration.ofSeconds(s6.getWorklist().getRequisitionCacheSeconds()), p5Clock);
    }

    @Bean
    public WorklistService p6WorklistService(FactStore p6FactStore, BusinessClock p5BusinessClock, CandidateS6Properties s6) {
        return new WorklistService(p6FactStore, p5BusinessClock, s6.getWorklist().getMaxPageSize(), s6.getWorklist().getCountCap());
    }

    @Bean(destroyMethod = "shutdown")
    public ExecutorService p6AssessPool(CandidateS6Properties s6) {
        int n = Math.max(1, s6.getWorklist().getBatchAssessThreads());
        return Executors.newFixedThreadPool(n, r -> {
            Thread t = new Thread(r, "p6-assess");
            t.setDaemon(true);
            return t;
        });
    }

    @Bean
    public MapCandidateBatchService p6MapCandidateBatchService(MappingService mapping, ExecutorService p6AssessPool, CandidateS6Properties s6) {
        return new MapCandidateBatchService(mapping, p6AssessPool, s6.getWorklist().getBatchAssessMax());
    }
}
