package com.ags.health.hr.candidates.reporting.web;

import com.ags.health.hr.candidates.reporting.domain.CheckRun;
import com.ags.health.hr.candidates.reporting.domain.DashboardView;
import com.ags.health.hr.candidates.reporting.domain.DrillRow;
import com.ags.health.hr.candidates.reporting.domain.ExportFile;
import com.ags.health.hr.candidates.reporting.domain.FunnelReport;
import com.ags.health.hr.candidates.reporting.domain.ReportFilter;
import com.ags.health.hr.candidates.reporting.service.AuditCompletenessService;
import com.ags.health.hr.candidates.reporting.service.DashboardService;
import com.ags.health.hr.candidates.reporting.service.DrillDownService;
import com.ags.health.hr.candidates.reporting.service.FactRebuildService;
import com.ags.health.hr.candidates.reporting.service.FilterOptionsService;
import com.ags.health.hr.candidates.reporting.service.FunnelReportService;
import com.ags.health.hr.candidates.reporting.service.PerformanceReportService;
import com.ags.health.hr.candidates.reporting.service.ReportAccuracyService;
import com.ags.health.hr.candidates.reporting.service.ReportExportService;
import com.ags.health.hr.common.platform.caller.CallerProvider;
import com.ags.health.hr.common.platform.error.PlatformException;
import com.ags.health.hr.common.platform.page.PageResult;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.http.CacheControl;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.time.LocalDate;
import java.time.format.DateTimeParseException;
import java.util.List;
import java.util.Map;

@ConditionalOnProperty(prefix = "digihire.s6.reporting", name = "enabled", havingValue = "true", matchIfMissing = true)
@RestController
public class ReportController {

    public record RangeRequest(LocalDate from, LocalDate to, Boolean repair) {
    }

    public record RebuildRequest(List<String> applicationIds, LocalDate from, LocalDate to) {
    }

    private final DashboardService dashboard;
    private final DrillDownService drill;
    private final FilterOptionsService options;
    private final FunnelReportService funnel;
    private final PerformanceReportService performance;
    private final ReportExportService export;
    private final ReportAccuracyService accuracy;
    private final AuditCompletenessService auditCheck;
    private final FactRebuildService rebuild;
    private final CallerProvider callers;

    public ReportController(DashboardService dashboard, DrillDownService drill, FilterOptionsService options, FunnelReportService funnel,
                            PerformanceReportService performance, ReportExportService export, ReportAccuracyService accuracy,
                            AuditCompletenessService auditCheck, FactRebuildService rebuild, CallerProvider callers) {
        this.dashboard = dashboard;
        this.drill = drill;
        this.options = options;
        this.funnel = funnel;
        this.performance = performance;
        this.export = export;
        this.accuracy = accuracy;
        this.auditCheck = auditCheck;
        this.rebuild = rebuild;
        this.callers = callers;
    }

    @GetMapping("/reports/dashboard")
    public DashboardView dashboard(@RequestParam Map<String, String> params) {
        return dashboard.dashboard(callers.require(), filter(params));
    }

    @GetMapping("/reports/dashboard/drill")
    public PageResult<DrillRow> drill(@RequestParam Map<String, String> params) {
        return drill.drill(callers.require(), filter(params), params.get("drill"), integer(params, "page", 0), integer(params, "size", 25),
                params.get("sort"));
    }

    @GetMapping("/reports/filter-options")
    public Map<String, List<FilterOptionsService.Option>> options() {
        return options.options(callers.require());
    }

    @GetMapping("/reports/funnel")
    public FunnelReport funnel(@RequestParam Map<String, String> params) {
        return funnel.funnel(callers.require(), filter(params), params.get("breakdown"));
    }

    @GetMapping("/reports/recruiters")
    public PerformanceReportService.Report recruiters(@RequestParam Map<String, String> params) {
        return performance.recruiters(callers.require(), filter(params));
    }

    @GetMapping("/reports/vendors")
    public PerformanceReportService.Report vendors(@RequestParam Map<String, String> params) {
        return performance.vendors(callers.require(), filter(params));
    }

    @PostMapping("/reports/export")
    public ResponseEntity<byte[]> export(@RequestBody ReportExportService.ExportRequest body) {
        ExportFile f = export.export(callers.require(), body);
        return ResponseEntity.ok().contentType(MediaType.parseMediaType(f.contentType()))
                .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + f.fileName() + "\"")
                .header("X-Row-Count", String.valueOf(f.rows())).cacheControl(CacheControl.noStore()).body(f.content());
    }

    @PostMapping("/reports/quality/accuracy")
    public CheckRun runAccuracy(@RequestBody RangeRequest body) {
        return accuracy.run(callers.require(), body.from(), body.to(), body.repair());
    }

    @GetMapping("/reports/quality/accuracy")
    public List<CheckRun> accuracyRuns(@RequestParam(defaultValue = "10") int limit) {
        return accuracy.recent(callers.require(), limit);
    }

    @PostMapping("/reports/quality/audit-completeness")
    public CheckRun runAudit(@RequestBody RangeRequest body) {
        return auditCheck.run(callers.require(), body.from(), body.to());
    }

    @GetMapping("/reports/quality/audit-completeness")
    public List<CheckRun> auditRuns(@RequestParam(defaultValue = "10") int limit) {
        return auditCheck.recent(callers.require(), limit);
    }

    @PostMapping("/reports/facts/rebuild")
    public FactRebuildService.Result rebuild(@RequestBody RebuildRequest body) {
        if (body.applicationIds() != null && !body.applicationIds().isEmpty()) {
            return rebuild.rebuild(callers.require(), body.applicationIds());
        }
        return rebuild.rebuildRange(callers.require(), body.from(), body.to(), 500);
    }

    static ReportFilter filter(Map<String, String> p) {
        return new ReportFilter(date(p, "from"), date(p, "to"), ReportFilter.split(p.get("lob")), ReportFilter.split(p.get("location")),
                ReportFilter.split(p.get("recruiter")), ReportFilter.split(p.get("vendor")), ReportFilter.split(p.get("source")),
                ReportFilter.split(p.get("requisition")), ReportFilter.split(p.get("role")), ReportFilter.split(p.get("tab")),
                ReportFilter.split(p.get("status")), p.get("q"));
    }

    private static LocalDate date(Map<String, String> p, String key) {
        String v = p.get(key);
        if (v == null || v.isBlank()) {
            return null;
        }
        try {
            return LocalDate.parse(v.trim());
        } catch (DateTimeParseException e) {
            throw PlatformException.badRequest("DATE_INVALID", key + " must be YYYY-MM-DD");
        }
    }

    private static int integer(Map<String, String> p, String key, int fallback) {
        String v = p.get(key);
        if (v == null || v.isBlank()) {
            return fallback;
        }
        try {
            return Integer.parseInt(v.trim());
        } catch (NumberFormatException e) {
            throw PlatformException.badRequest("NUMBER_INVALID", key + " must be a number");
        }
    }
}
