package com.ags.health.hr.candidates.reporting.domain;

import java.time.Instant;
import java.util.List;
import java.util.Map;

public record DashboardView(Instant generatedAt, boolean cached, Map<String, String> filters, List<Widget> widgets) {

    public record Widget(String key, String title, long total, List<Bucket> buckets) {

        public Widget {
            buckets = List.copyOf(buckets);
        }
    }

    public record Bucket(String key, String label, long count, String drill) {
    }

    public DashboardView {
        filters = filters == null ? Map.of() : Map.copyOf(filters);
        widgets = List.copyOf(widgets);
    }

    public DashboardView cached(boolean c) {
        return new DashboardView(generatedAt, c, filters, widgets);
    }
}
