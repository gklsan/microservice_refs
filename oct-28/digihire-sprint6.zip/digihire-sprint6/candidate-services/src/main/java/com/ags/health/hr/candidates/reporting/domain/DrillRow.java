package com.ags.health.hr.candidates.reporting.domain;

import java.time.Instant;
import java.time.LocalDate;

public record DrillRow(String applicationId, String candidateId, String candidateName, String requisitionId, String lob,
                       String location, String roleCode, String source, String hrUserId, String status, String tab,
                       LocalDate appliedDate, Instant statusSince, long daysInStatus) {
}
