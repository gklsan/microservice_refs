package com.ags.health.hr.candidates.reporting.domain;

import com.ags.health.hr.common.platform.caller.Caller;
import com.ags.health.hr.common.platform.error.PlatformException;

import java.util.LinkedHashSet;
import java.util.Locale;
import java.util.Set;
import java.util.TreeSet;

public record ReportScope(boolean all, Set<String> recruiterIds, Set<String> lobs, Set<String> locations, String key) {

    public static ReportScope of(Caller caller, String permission) {
        if (caller == null) {
            throw PlatformException.unauthorized("Login required");
        }
        if (!caller.has(permission)) {
            throw PlatformException.forbidden("PERMISSION_DENIED", "Missing permission " + permission);
        }
        if (caller.scopeAll()) {
            return new ReportScope(true, Set.of(), Set.of(), Set.of(), "ALL");
        }
        String level = caller.scopeLevel() == null ? "OWN" : caller.scopeLevel().toUpperCase(Locale.ROOT);
        Set<String> recruiters = new LinkedHashSet<>();
        switch (level) {
            case "LOB", "LOCATION" -> {
                if (caller.lobs().isEmpty() && caller.locations().isEmpty()) {
                    recruiters.add(caller.userId());
                }
            }
            case "TEAM" -> {
                recruiters.add(caller.userId());
                recruiters.addAll(caller.teamUserIds());
            }
            default -> recruiters.add(caller.userId());
        }
        String key = level + "|" + new TreeSet<>(recruiters) + "|" + new TreeSet<>(caller.lobs()) + "|" + new TreeSet<>(caller.locations());
        return new ReportScope(false, Set.copyOf(recruiters), Set.copyOf(caller.lobs()), Set.copyOf(caller.locations()), key);
    }

    public boolean teamOrWider() {
        return all || recruiterIds.isEmpty() || recruiterIds.size() > 1;
    }
}
