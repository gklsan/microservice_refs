package com.ags.health.hr.candidates.reporting.service;

import com.ags.health.hr.candidates.reporting.domain.CheckRun;
import com.ags.health.hr.candidates.reporting.store.CheckRunStore;
import com.ags.health.hr.candidates.reporting.store.StageEventStore;
import com.ags.health.hr.candidates.s6shared.S6Permissions;
import com.ags.health.hr.common.platform.audit.AuditRecorder;
import com.ags.health.hr.common.platform.caller.Caller;
import com.ags.health.hr.common.platform.db.JdbcValues;
import com.ags.health.hr.common.platform.error.PlatformException;
import com.ags.health.hr.common.platform.time.BusinessClock;
import org.springframework.jdbc.core.JdbcTemplate;

import java.sql.Timestamp;
import java.time.Duration;
import java.time.Instant;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.regex.Pattern;

public class AuditCompletenessService {

    private static final Pattern TABLE = Pattern.compile("[A-Za-z_][A-Za-z0-9_]{0,62}");

    private final StageEventStore events;
    private final JdbcTemplate jdbc;
    private final CheckRunStore runs;
    private final AuditRecorder audit;
    private final BusinessClock clock;
    private final String auditTable;
    private final Duration window;
    private final int batch;

    public AuditCompletenessService(StageEventStore events, JdbcTemplate jdbc, CheckRunStore runs, AuditRecorder audit, BusinessClock clock,
                                    String auditTable, Duration window, int batch) {
        if (!TABLE.matcher(auditTable).matches()) {
            throw new IllegalArgumentException("Invalid audit table " + auditTable);
        }
        this.events = events;
        this.jdbc = jdbc;
        this.runs = runs;
        this.audit = audit;
        this.clock = clock;
        this.auditTable = auditTable;
        this.window = window;
        this.batch = batch;
    }

    public CheckRun run(Caller caller, LocalDate from, LocalDate to) {
        if (caller == null || !caller.has(S6Permissions.QUALITY)) {
            throw PlatformException.forbidden("PERMISSION_DENIED", "Missing permission " + S6Permissions.QUALITY);
        }
        if (from == null || to == null || from.isAfter(to) || from.plusDays(31).isBefore(to)) {
            throw PlatformException.badRequest("DATE_RANGE_INVALID", "Give a range of at most 31 days");
        }
        return check(caller.userId(), from, to);
    }

    public List<CheckRun> recent(Caller caller, int limit) {
        if (caller == null || !caller.hasAny(S6Permissions.QUALITY, S6Permissions.READINESS)) {
            throw PlatformException.forbidden("PERMISSION_DENIED", "Missing permission " + S6Permissions.QUALITY);
        }
        return runs.recent(CheckRun.AUDIT, Math.max(1, Math.min(limit, 50)));
    }

    public CheckRun check(String triggeredBy, LocalDate from, LocalDate to) {
        Instant started = clock.now();
        Instant start = clock.startOf(from);
        Instant end = clock.startOf(to.plusDays(1));
        int checked = 0;
        int matched = 0;
        List<String> sample = new ArrayList<>();
        String after = null;
        while (true) {
            List<Map<String, Object>> page = events.moves(start, end, after, batch);
            if (page.isEmpty()) {
                break;
            }
            Set<String> apps = new LinkedHashSet<>();
            Instant min = null;
            Instant max = null;
            for (Map<String, Object> m : page) {
                apps.add((String) m.get("application_id"));
                Instant at = JdbcValues.instant(m.get("moved_at"));
                min = min == null || at.isBefore(min) ? at : min;
                max = max == null || at.isAfter(max) ? at : max;
            }
            Map<String, List<Instant>> audited = audited(apps, min.minus(window), max.plus(window));
            for (Map<String, Object> m : page) {
                checked++;
                String app = (String) m.get("application_id");
                Instant at = JdbcValues.instant(m.get("moved_at"));
                if (consume(audited.get(app), at)) {
                    matched++;
                } else if (sample.size() < 50) {
                    sample.add(app + ": " + m.get("from_status") + " -> " + m.get("to_status") + " at " + at + " has no audit row");
                }
            }
            after = (String) page.get(page.size() - 1).get("id");
        }
        int missing = checked - matched;
        double score = checked == 0 ? 100.0 : FactQueries.round(matched * 100.0 / checked, 4);
        String status = missing == 0 ? "PASS" : "FAIL";
        CheckRun run = new CheckRun(UUID.randomUUID().toString(), CheckRun.AUDIT, from, to, checked, matched, 0, missing, 0, score, 100.0,
                status, sample, started, clock.now());
        runs.save(run, triggeredBy);
        audit.recordQuietly("ACTIVITY", "AUDIT_COMPLETENESS_CHECKED", "AUDIT_LOG", run.id(), null,
                missing == 0 ? AuditRecorder.SUCCESS : AuditRecorder.FAILURE, null,
                AuditRecorder.details("from", from.toString(), "to", to.toString(), "moves", checked, "missing", missing));
        return run;
    }

    private Map<String, List<Instant>> audited(Set<String> apps, Instant from, Instant to) {
        StringBuilder in = new StringBuilder();
        List<Object> args = new ArrayList<>();
        for (String a : apps) {
            in.append(in.length() == 0 ? "?" : ", ?");
            args.add(a);
        }
        args.add(Timestamp.from(from));
        args.add(Timestamp.from(to));
        Map<String, List<Instant>> out = new HashMap<>();
        for (Map<String, Object> r : jdbc.queryForList("SELECT target_id, event_time FROM " + auditTable + " WHERE target_id IN (" + in
                + ") AND action IN ('STATUS_CHANGED', 'STATUS_RESET') AND event_time >= ? AND event_time <= ?", args.toArray())) {
            Instant at = JdbcValues.instant(r.get("event_time"));
            if (at != null) {
                out.computeIfAbsent(String.valueOf(r.get("target_id")), k -> new ArrayList<>()).add(at);
            }
        }
        return out;
    }

    private boolean consume(List<Instant> times, Instant at) {
        if (times == null) {
            return false;
        }
        Iterator<Instant> it = times.iterator();
        while (it.hasNext()) {
            Instant t = it.next();
            if (!t.isBefore(at.minus(window)) && !t.isAfter(at.plus(window))) {
                it.remove();
                return true;
            }
        }
        return false;
    }
}
