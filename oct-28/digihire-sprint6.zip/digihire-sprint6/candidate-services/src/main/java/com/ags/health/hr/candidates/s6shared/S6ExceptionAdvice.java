package com.ags.health.hr.candidates.s6shared;

import com.ags.health.hr.candidates.shared.web.P5ExceptionAdvice;
import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.web.bind.annotation.RestControllerAdvice;

@Order(Ordered.HIGHEST_PRECEDENCE)
@RestControllerAdvice(basePackages = {
        "com.ags.health.hr.candidates.reporting",
        "com.ags.health.hr.candidates.worklist",
        "com.ags.health.hr.candidates.ops"})
public class S6ExceptionAdvice extends P5ExceptionAdvice {
}
