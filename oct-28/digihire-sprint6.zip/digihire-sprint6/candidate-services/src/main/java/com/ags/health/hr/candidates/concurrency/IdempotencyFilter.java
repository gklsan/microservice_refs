package com.ags.health.hr.candidates.concurrency;

import com.ags.health.hr.common.platform.caller.Caller;
import com.ags.health.hr.common.platform.caller.CallerProvider;
import com.ags.health.hr.common.platform.concurrency.IdempotencyStore;
import com.ags.health.hr.common.platform.concurrency.IdempotentExecutor;
import com.ags.health.hr.common.platform.error.PlatformException;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ReadListener;
import jakarta.servlet.ServletException;
import jakarta.servlet.ServletInputStream;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletRequestWrapper;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.web.filter.OncePerRequestFilter;
import org.springframework.web.util.ContentCachingResponseWrapper;

import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.regex.Pattern;

public class IdempotencyFilter extends OncePerRequestFilter {

    private static final long MAX_BODY = 5L * 1024 * 1024;

    private final IdempotencyStore store;
    private final CallerProvider callers;
    private final List<Pattern> paths;

    public IdempotencyFilter(IdempotencyStore store, CallerProvider callers, List<String> pathPatterns) {
        this.store = store;
        this.callers = callers;
        this.paths = pathPatterns.stream().map(IdempotencyFilter::compile).toList();
    }

    static Pattern compile(String glob) {
        StringBuilder re = new StringBuilder();
        for (String part : glob.split("\\*", -1)) {
            if (re.length() > 0) {
                re.append("[^/]+");
            }
            re.append(Pattern.quote(part));
        }
        return Pattern.compile(re.toString());
    }

    boolean applies(String method, String path) {
        return "POST".equalsIgnoreCase(method) && paths.stream().anyMatch(p -> p.matcher(path).matches());
    }

    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain chain)
            throws ServletException, IOException {
        String key = request.getHeader(IdempotentExecutor.HEADER);
        String path = request.getRequestURI().substring(request.getContextPath() == null ? 0 : request.getContextPath().length());
        if (key == null || key.isBlank() || !applies(request.getMethod(), path) || request.getContentLengthLong() > MAX_BODY) {
            chain.doFilter(request, response);
            return;
        }
        byte[] body = request.getInputStream().readAllBytes();
        String actor = callers.current().map(Caller::userId).orElseGet(() -> String.valueOf(request.getHeader("Authorization")).hashCode() + "");
        IdempotencyStore.Claim claim;
        try {
            claim = store.claim(actor, key.trim(), request.getMethod(), request.getQueryString() == null ? path : path + "?" + request.getQueryString(), body);
        } catch (PlatformException e) {
            write(response, e.getStatus(), "application/problem+json", "{\"code\":\"" + e.getCode() + "\",\"detail\":\""
                    + e.getMessage().replace("\"", "'") + "\"}");
            return;
        }
        if (claim instanceof IdempotencyStore.Claim.Replay r) {
            response.setHeader("Idempotent-Replay", "true");
            write(response, r.response().status(), r.response().contentType(), new String(r.response().body(), StandardCharsets.UTF_8));
            return;
        }
        if (claim instanceof IdempotencyStore.Claim.InFlight) {
            write(response, 409, "application/problem+json", "{\"code\":\"REQUEST_IN_PROGRESS\",\"detail\":\"The same request is still being processed\"}");
            return;
        }
        String scoped = ((IdempotencyStore.Claim.Fresh) claim).key();
        ContentCachingResponseWrapper wrapped = new ContentCachingResponseWrapper(response);
        try {
            chain.doFilter(new CachedBodyRequest(request, body), wrapped);
            store.complete(scoped, wrapped.getStatus(), wrapped.getContentType(), wrapped.getContentAsByteArray());
        } catch (IOException | ServletException | RuntimeException e) {
            store.release(scoped);
            throw e;
        } finally {
            wrapped.copyBodyToResponse();
        }
    }

    private static void write(HttpServletResponse response, int status, String type, String body) throws IOException {
        response.setStatus(status);
        response.setContentType(type);
        response.setCharacterEncoding("UTF-8");
        response.getWriter().write(body);
    }

    static final class CachedBodyRequest extends HttpServletRequestWrapper {

        private final byte[] body;

        CachedBodyRequest(HttpServletRequest request, byte[] body) {
            super(request);
            this.body = body;
        }

        @Override
        public ServletInputStream getInputStream() {
            ByteArrayInputStream in = new ByteArrayInputStream(body);
            return new ServletInputStream() {
                @Override
                public boolean isFinished() {
                    return in.available() == 0;
                }

                @Override
                public boolean isReady() {
                    return true;
                }

                @Override
                public void setReadListener(ReadListener listener) {
                    throw new UnsupportedOperationException("Async reads are not supported");
                }

                @Override
                public int read() {
                    return in.read();
                }
            };
        }

        @Override
        public BufferedReader getReader() {
            return new BufferedReader(new InputStreamReader(new ByteArrayInputStream(body), StandardCharsets.UTF_8));
        }

        @Override
        public int getContentLength() {
            return body.length;
        }

        @Override
        public long getContentLengthLong() {
            return body.length;
        }
    }
}
