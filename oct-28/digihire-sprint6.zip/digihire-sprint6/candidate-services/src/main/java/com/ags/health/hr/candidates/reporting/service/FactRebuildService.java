package com.ags.health.hr.candidates.reporting.service;

import com.ags.health.hr.candidates.reporting.port.ReportSourcePort;
import com.ags.health.hr.candidates.reporting.port.SourceApplication;
import com.ags.health.hr.candidates.reporting.store.DirtyStore;
import com.ags.health.hr.candidates.reporting.store.FactStore;
import com.ags.health.hr.candidates.s6shared.S6Permissions;
import com.ags.health.hr.common.platform.audit.AuditRecorder;
import com.ags.health.hr.common.platform.caller.Caller;
import com.ags.health.hr.common.platform.error.PlatformException;
import com.ags.health.hr.common.platform.time.BusinessClock;

import java.time.LocalDate;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

public class FactRebuildService {

    public record Result(int requested, int rebuilt, int notFound, int failed) {
    }

    private final ReportSourcePort source;
    private final FactStore facts;
    private final DirtyStore dirty;
    private final FactCalculator calc;
    private final AuditRecorder audit;
    private final BusinessClock clock;
    private final int maxAttempts;

    public FactRebuildService(ReportSourcePort source, FactStore facts, DirtyStore dirty, FactCalculator calc, AuditRecorder audit,
                              BusinessClock clock, int maxAttempts) {
        this.source = source;
        this.facts = facts;
        this.dirty = dirty;
        this.calc = calc;
        this.audit = audit;
        this.clock = clock;
        this.maxAttempts = maxAttempts;
    }

    public boolean rebuild(String applicationId) {
        Optional<SourceApplication> src = source.load(applicationId);
        if (src.isEmpty()) {
            return false;
        }
        facts.save(calc.fromSource(src.get()));
        return true;
    }

    public Result rebuild(Caller caller, List<String> applicationIds) {
        require(caller);
        if (applicationIds == null || applicationIds.isEmpty() || applicationIds.size() > 1000) {
            throw PlatformException.badRequest("APPLICATION_IDS_INVALID", "Send between 1 and 1000 application ids");
        }
        Result r = rebuildAll(applicationIds);
        audit.record("ACTIVITY", "REPORT_FACTS_REBUILT", "REPORT", "facts", null, details(r, null, null));
        return r;
    }

    public Result rebuildRange(Caller caller, LocalDate from, LocalDate to, int batch) {
        require(caller);
        if (from == null || to == null || from.isAfter(to) || from.plusDays(400).isBefore(to)) {
            throw PlatformException.badRequest("DATE_RANGE_INVALID", "Give a range of at most 400 days");
        }
        int requested = 0;
        int rebuilt = 0;
        int notFound = 0;
        int failed = 0;
        String after = null;
        while (true) {
            List<String> ids = source.applicationIdsChangedBetween(clock.startOf(from), clock.startOf(to.plusDays(1)), after, batch);
            if (ids.isEmpty()) {
                break;
            }
            Result part = rebuildAll(ids);
            requested += part.requested();
            rebuilt += part.rebuilt();
            notFound += part.notFound();
            failed += part.failed();
            after = ids.get(ids.size() - 1);
        }
        Result r = new Result(requested, rebuilt, notFound, failed);
        audit.record("ACTIVITY", "REPORT_FACTS_REBUILT", "REPORT", "facts", null, details(r, from, to));
        return r;
    }

    public int repairDirty(int limit) {
        int done = 0;
        for (String id : dirty.due(limit, maxAttempts)) {
            try {
                rebuild(id);
                dirty.done(id);
                done++;
            } catch (RuntimeException e) {
                dirty.failed(id, e.getMessage());
            }
        }
        return done;
    }

    private Result rebuildAll(List<String> ids) {
        int rebuilt = 0;
        int notFound = 0;
        int failed = 0;
        for (String id : ids) {
            try {
                if (rebuild(id)) {
                    rebuilt++;
                } else {
                    notFound++;
                }
            } catch (RuntimeException e) {
                failed++;
                dirty.mark(id, e.getMessage(), clock.now());
            }
        }
        return new Result(ids.size(), rebuilt, notFound, failed);
    }

    private static void require(Caller caller) {
        if (caller == null || !caller.has(S6Permissions.QUALITY)) {
            throw PlatformException.forbidden("PERMISSION_DENIED", "Missing permission " + S6Permissions.QUALITY);
        }
    }

    private static Map<String, Object> details(Result r, LocalDate from, LocalDate to) {
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("requested", r.requested());
        m.put("rebuilt", r.rebuilt());
        m.put("notFound", r.notFound());
        m.put("failed", r.failed());
        if (from != null) {
            m.put("from", from.toString());
            m.put("to", to.toString());
        }
        return m;
    }
}
