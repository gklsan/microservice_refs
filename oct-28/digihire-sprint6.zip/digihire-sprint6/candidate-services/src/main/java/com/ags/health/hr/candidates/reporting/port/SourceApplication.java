package com.ags.health.hr.candidates.reporting.port;

import com.ags.health.hr.candidates.shared.port.ApplicationView;
import com.ags.health.hr.candidates.shared.port.StageEntry;

import java.util.List;

public record SourceApplication(ApplicationView application, String candidateName, String vendorId, List<StageEntry> history) {

    public SourceApplication {
        history = history == null ? List.of() : List.copyOf(history);
    }
}
