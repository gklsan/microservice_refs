package com.ags.health.hr.candidates.reporting.port;

import java.time.Instant;
import java.util.List;
import java.util.Optional;

public interface ReportSourcePort {

    Optional<SourceApplication> load(String applicationId);

    List<String> applicationIdsChangedBetween(Instant from, Instant to, String afterId, int limit);
}
