package com.ags.health.hr.candidates.reporting.port;

import java.util.Collection;
import java.util.Map;

public interface UserDirectoryPort {

    Map<String, String> names(Collection<String> userIds);
}
