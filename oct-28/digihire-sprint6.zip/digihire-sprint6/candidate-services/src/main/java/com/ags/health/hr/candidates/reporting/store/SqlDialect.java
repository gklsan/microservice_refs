package com.ags.health.hr.candidates.reporting.store;

import com.ags.health.hr.common.platform.audit.AuditTableInspector;
import org.springframework.jdbc.core.JdbcTemplate;

public final class SqlDialect {

    private final boolean h2;

    private SqlDialect(boolean h2) {
        this.h2 = h2;
    }

    public static SqlDialect detect(JdbcTemplate jdbc) {
        return new SqlDialect(AuditTableInspector.isH2(jdbc));
    }

    public static SqlDialect postgres() {
        return new SqlDialect(false);
    }

    public boolean isH2() {
        return h2;
    }

    public String daysBetween(String start, String end) {
        return h2 ? "(DATEDIFF('SECOND', " + start + ", " + end + ") / 86400.0)"
                : "(EXTRACT(EPOCH FROM (" + end + " - " + start + ")) / 86400.0)";
    }
}
