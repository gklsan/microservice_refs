package com.ags.health.hr.candidates.reporting.domain;

import java.sql.Date;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Locale;

public final class Where {

    private final StringBuilder sql = new StringBuilder(" WHERE 1 = 1");
    private final List<Object> args = new ArrayList<>();
    private final String alias;

    private Where(String alias) {
        this.alias = alias == null || alias.isEmpty() ? "" : alias + ".";
    }

    public static Where fact(ReportScope scope, ReportFilter filter, boolean dates) {
        return fact("", scope, filter, dates);
    }

    public static Where fact(String alias, ReportScope scope, ReportFilter filter, boolean dates) {
        Where w = new Where(alias);
        if (!scope.all()) {
            w.in("hr_user_id", scope.recruiterIds());
            w.in("lob", scope.lobs());
            w.in("location", scope.locations());
        }
        if (filter != null) {
            if (dates && filter.from() != null) {
                w.raw(w.alias + "applied_date >= ?", Date.valueOf(filter.from()));
            }
            if (dates && filter.to() != null) {
                w.raw(w.alias + "applied_date <= ?", Date.valueOf(filter.to()));
            }
            w.in("lob", filter.lobs());
            w.in("location", filter.locations());
            w.in("hr_user_id", filter.recruiterIds());
            w.in("vendor_id", filter.vendorIds());
            w.inUpper("source", filter.sources());
            w.in("requisition_id", filter.requisitionIds());
            w.in("role_code", filter.roles());
            w.inUpper("tab", filter.tabs());
            w.inUpper("status", filter.statuses());
            if (filter.q() != null) {
                String like = "%" + filter.q().toLowerCase(Locale.ROOT).replace("\\", "").replace("%", "").replace("_", "") + "%";
                w.raw("(LOWER(" + w.alias + "candidate_name) LIKE ? OR LOWER(" + w.alias + "application_id) LIKE ? OR LOWER("
                        + w.alias + "candidate_id) LIKE ? OR LOWER(" + w.alias + "requisition_id) LIKE ?)", like, like, like, like);
            }
        }
        return w;
    }

    public Where raw(String clause, Object... values) {
        sql.append(" AND ").append(clause);
        for (Object v : values) {
            args.add(v);
        }
        return this;
    }

    public Where eq(String column, Object value) {
        return raw(alias + column + " = ?", value);
    }

    public Where in(String column, Collection<String> values) {
        if (values == null || values.isEmpty()) {
            return this;
        }
        sql.append(" AND ").append(alias).append(column).append(" IN (");
        int i = 0;
        for (String v : values) {
            sql.append(i++ == 0 ? "?" : ", ?");
            args.add(v);
        }
        sql.append(")");
        return this;
    }

    private void inUpper(String column, Collection<String> values) {
        if (values == null || values.isEmpty()) {
            return;
        }
        sql.append(" AND UPPER(").append(alias).append(column).append(") IN (");
        int i = 0;
        for (String v : values) {
            sql.append(i++ == 0 ? "?" : ", ?");
            args.add(v.toUpperCase(Locale.ROOT));
        }
        sql.append(")");
    }

    public String sql() {
        return sql.toString();
    }

    public Object[] args() {
        return args.toArray();
    }

    public List<Object> argList() {
        return new ArrayList<>(args);
    }
}
