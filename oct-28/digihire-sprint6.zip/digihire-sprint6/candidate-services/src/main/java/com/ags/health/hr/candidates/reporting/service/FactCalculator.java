package com.ags.health.hr.candidates.reporting.service;

import com.ags.health.hr.candidates.reporting.domain.FactRow;
import com.ags.health.hr.candidates.reporting.domain.FunnelStage;
import com.ags.health.hr.candidates.reporting.port.SourceApplication;
import com.ags.health.hr.candidates.shared.domain.StageCatalog;
import com.ags.health.hr.candidates.shared.domain.Tab;
import com.ags.health.hr.candidates.shared.port.ApplicationView;
import com.ags.health.hr.candidates.shared.port.StageEntry;
import com.ags.health.hr.candidates.shared.service.StatusMovedEvent;
import com.ags.health.hr.common.platform.time.BusinessClock;

import java.time.Instant;
import java.util.Comparator;
import java.util.EnumMap;
import java.util.List;
import java.util.Map;

public class FactCalculator {

    private final StageCatalog catalog;
    private final BusinessClock clock;

    public FactCalculator(StageCatalog catalog, BusinessClock clock) {
        this.catalog = catalog;
        this.clock = clock;
    }

    public FactRow fromSource(SourceApplication src) {
        ApplicationView a = src.application();
        List<StageEntry> history = src.history().stream().filter(h -> h.status() != null && h.at() != null)
                .sorted(Comparator.comparing(StageEntry::at)).toList();
        Map<FunnelStage, Instant> reached = new EnumMap<>(FunnelStage.class);
        Instant applied = history.isEmpty() ? (a.statusUpdatedAt() == null ? clock.now() : a.statusUpdatedAt()) : history.get(0).at();
        reached.put(FunnelStage.APPLIED, applied);
        Instant rejectedAt = null;
        String rejectedStage = null;
        String prevStatus = null;
        Instant since = applied;
        for (StageEntry h : history) {
            Tab tab = tabOf(h.status());
            FunnelStage s = FunnelStage.of(h.status(), tab);
            if (s != null) {
                reached.putIfAbsent(s, h.at());
            }
            if (tab == Tab.REJECTED) {
                if (rejectedAt == null || !isRejected(prevStatus)) {
                    rejectedAt = h.at();
                    rejectedStage = furthest(reached).name();
                }
            } else {
                rejectedAt = null;
                rejectedStage = null;
            }
            if (prevStatus == null || !prevStatus.equals(h.status())) {
                since = h.at();
            }
            prevStatus = h.status();
        }
        String status = a.status();
        Tab tab = tabOf(status);
        if (!history.isEmpty() && !status.equals(history.get(history.size() - 1).status())) {
            since = a.statusUpdatedAt() == null ? since : a.statusUpdatedAt();
            FunnelStage s = FunnelStage.of(status, tab);
            if (s != null) {
                reached.putIfAbsent(s, since);
            }
            if (tab == Tab.REJECTED && rejectedAt == null) {
                rejectedAt = since;
                rejectedStage = furthest(reached).name();
            } else if (tab != Tab.REJECTED) {
                rejectedAt = null;
                rejectedStage = null;
            }
        }
        if (history.isEmpty()) {
            FunnelStage s = FunnelStage.of(status, tab);
            if (s != null) {
                reached.putIfAbsent(s, applied);
            }
            if (tab == Tab.REJECTED) {
                rejectedAt = applied;
                rejectedStage = FunnelStage.APPLIED.name();
            }
        }
        return new FactRow(a.id(), a.candidateId(), src.candidateName(), a.requisitionId(), a.jobId(), a.lob(), a.location(),
                a.roleCode(), a.orcId(), upper(a.source()), src.vendorId(), a.hrUserId(), status, tab.name(), applied,
                clock.dateOf(applied), reached.get(FunnelStage.HR_ROUND), reached.get(FunnelStage.ASSESSMENT),
                reached.get(FunnelStage.VERSANT), reached.get(FunnelStage.PANEL), reached.get(FunnelStage.SELECTED),
                reached.get(FunnelStage.OFFERED), reached.get(FunnelStage.JOINED), rejectedAt, rejectedStage, since, clock.now());
    }

    public FactRow apply(FactRow f, StatusMovedEvent e) {
        ApplicationView a = e.application();
        String to = e.toStatus();
        Tab toTab = e.toTab() != null ? e.toTab() : tabOf(to);
        boolean changed = e.fromStatus() == null || !e.fromStatus().equalsIgnoreCase(to);
        Instant at = e.at();
        FunnelStage stage = FunnelStage.of(to, toTab);
        Instant hr = f.hrRoundAt();
        Instant as = f.assessmentAt();
        Instant ve = f.versantAt();
        Instant pa = f.panelAt();
        Instant se = f.selectedAt();
        Instant of = f.offeredAt();
        Instant jo = f.joinedAt();
        if (stage != null && changed) {
            switch (stage) {
                case HR_ROUND -> hr = hr == null ? at : hr;
                case ASSESSMENT -> as = as == null ? at : as;
                case VERSANT -> ve = ve == null ? at : ve;
                case PANEL -> pa = pa == null ? at : pa;
                case SELECTED -> se = se == null ? at : se;
                case OFFERED -> of = of == null ? at : of;
                case JOINED -> jo = jo == null ? at : jo;
                default -> {
                }
            }
        }
        Instant rejectedAt = f.rejectedAt();
        String rejectedStage = f.rejectedStage();
        if (toTab == Tab.REJECTED) {
            if (changed && !"REJECTED".equals(f.tab())) {
                rejectedAt = at;
                rejectedStage = furthest(f).name();
            }
        } else {
            rejectedAt = null;
            rejectedStage = null;
        }
        return new FactRow(f.applicationId(), nz(a.candidateId(), f.candidateId()), f.candidateName(), nz(a.requisitionId(), f.requisitionId()),
                nz(a.jobId(), f.jobId()), nz(a.lob(), f.lob()), nz(a.location(), f.location()), nz(a.roleCode(), f.roleCode()),
                nz(a.orcId(), f.orcId()), nz(upper(a.source()), f.source()), f.vendorId(), nz(a.hrUserId(), f.hrUserId()), to, toTab.name(),
                f.appliedAt(), f.appliedDate(), hr, as, ve, pa, se, of, jo, rejectedAt, rejectedStage, changed ? at : f.statusSince(), at);
    }

    public FactRow fromEvent(StatusMovedEvent e, String candidateName, String vendorId) {
        ApplicationView a = e.application();
        Tab tab = e.toTab() != null ? e.toTab() : tabOf(e.toStatus());
        FactRow seed = new FactRow(a.id(), a.candidateId(), candidateName, a.requisitionId(), a.jobId(), a.lob(), a.location(), a.roleCode(),
                a.orcId(), upper(a.source()), vendorId, a.hrUserId(), e.toStatus(), tab.name(), e.at(), clock.dateOf(e.at()), null, null,
                null, null, null, null, null, null, null, e.at(), e.at());
        return apply(seed, new StatusMovedEvent(a, null, e.toStatus(), null, tab, e.reasonCode(), e.remarks(), e.actorId(), e.system(),
                e.at(), e.context()));
    }

    private static FunnelStage furthest(Map<FunnelStage, Instant> reached) {
        FunnelStage best = FunnelStage.APPLIED;
        for (FunnelStage s : reached.keySet()) {
            if (s.ordinal() > best.ordinal()) {
                best = s;
            }
        }
        return best;
    }

    public static FunnelStage furthest(FactRow f) {
        FunnelStage best = FunnelStage.APPLIED;
        for (FunnelStage s : FunnelStage.values()) {
            if (f.reachedAt(s) != null) {
                best = s;
            }
        }
        return best;
    }

    private Tab tabOf(String status) {
        return catalog.known(status) ? catalog.tabOf(status) : Tab.APPLICANT;
    }

    private boolean isRejected(String status) {
        return status != null && catalog.isRejected(status);
    }

    private static String nz(String v, String fallback) {
        return v == null || v.isBlank() ? fallback : v;
    }

    private static String upper(String v) {
        return v == null ? null : v.trim().toUpperCase(java.util.Locale.ROOT);
    }
}
