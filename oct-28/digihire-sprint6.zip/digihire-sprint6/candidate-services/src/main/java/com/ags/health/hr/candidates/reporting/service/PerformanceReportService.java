package com.ags.health.hr.candidates.reporting.service;

import com.ags.health.hr.candidates.reporting.domain.PerformanceRow;
import com.ags.health.hr.candidates.reporting.domain.ReportFilter;
import com.ags.health.hr.candidates.reporting.domain.ReportScope;
import com.ags.health.hr.candidates.reporting.domain.Where;
import com.ags.health.hr.candidates.reporting.port.UserDirectoryPort;
import com.ags.health.hr.candidates.reporting.port.VendorDirectoryPort;
import com.ags.health.hr.candidates.reporting.store.FactStore;
import com.ags.health.hr.candidates.reporting.store.StageEventStore;
import com.ags.health.hr.candidates.s6shared.S6Permissions;
import com.ags.health.hr.common.platform.caller.Caller;
import com.ags.health.hr.common.platform.time.BusinessClock;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

public class PerformanceReportService {

    public record Report(String kind, java.time.LocalDate from, java.time.LocalDate to, List<PerformanceRow> rows, PerformanceRow total,
                         Map<String, String> filters) {

        public Report {
            rows = List.copyOf(rows);
            filters = filters == null ? Map.of() : Map.copyOf(filters);
        }
    }

    private final FactStore facts;
    private final StageEventStore events;
    private final UserDirectoryPort users;
    private final VendorDirectoryPort vendors;
    private final BusinessClock clock;
    private final int maxRangeDays;

    public PerformanceReportService(FactStore facts, StageEventStore events, UserDirectoryPort users, VendorDirectoryPort vendors,
                                    BusinessClock clock, int maxRangeDays) {
        this.facts = facts;
        this.events = events;
        this.users = users;
        this.vendors = vendors;
        this.clock = clock;
        this.maxRangeDays = maxRangeDays;
    }

    public Report recruiters(Caller caller, ReportFilter raw) {
        ReportScope scope = ReportScope.of(caller, S6Permissions.RECRUITER);
        ReportFilter filter = raw.withDefaults(clock.today(), 30, maxRangeDays);
        Where w = Where.fact(scope, filter, true);
        List<Map<String, Object>> rows = facts.grouped("hr_user_id", FactQueries.performance(facts.dialect()), w,
                "joined DESC, applications DESC, grp", 500);
        Map<String, Long> actions = new HashMap<>();
        for (Map<String, Object> r : events.actionsByActor(Where.fact("f", scope, filter, true), filter.from(), filter.to())) {
            actions.put((String) FactQueries.value(r, "grp"), FactQueries.num(r, "n"));
        }
        List<String> ids = rows.stream().map(r -> (String) FactQueries.value(r, "grp")).filter(Objects::nonNull).toList();
        return build("RECRUITER", filter, rows, users.names(ids), actions);
    }

    public Report vendors(Caller caller, ReportFilter raw) {
        ReportScope scope = ReportScope.of(caller, S6Permissions.VENDOR);
        ReportFilter filter = raw.withDefaults(clock.today(), 30, maxRangeDays);
        Where w = Where.fact(scope, filter, true).raw("vendor_id IS NOT NULL");
        List<Map<String, Object>> rows = facts.grouped("vendor_id", FactQueries.performance(facts.dialect()), w,
                "joined DESC, applications DESC, grp", 500);
        List<String> ids = rows.stream().map(r -> (String) FactQueries.value(r, "grp")).filter(Objects::nonNull).toList();
        return build("VENDOR", filter, rows, vendors.names(ids), Map.of());
    }

    private Report build(String kind, ReportFilter filter, List<Map<String, Object>> rows, Map<String, String> names,
                         Map<String, Long> actions) {
        List<PerformanceRow> out = new ArrayList<>();
        long[] t = new long[8];
        for (Map<String, Object> r : rows) {
            String id = (String) FactQueries.value(r, "grp");
            PerformanceRow p = row(id, id == null ? "(not set)" : names.getOrDefault(id, id), r, actions.getOrDefault(id, 0L));
            out.add(p);
            t[0] += p.applications();
            t[1] += p.hrRound();
            t[2] += p.selected();
            t[3] += p.offered();
            t[4] += p.joined();
            t[5] += p.rejected();
            t[6] += p.open();
            t[7] += p.actions();
        }
        PerformanceRow total = new PerformanceRow("TOTAL", "Total", t[0], t[1], t[2], t[3], t[4], t[5], t[6], t[7],
                FactQueries.ratio(t[4], t[0]), FactQueries.ratio(t[4], t[3]), null, null);
        return new Report(kind, filter.from(), filter.to(), out, total, filter.describe());
    }

    private static PerformanceRow row(String id, String name, Map<String, Object> r, long actions) {
        long applications = FactQueries.num(r, "applications");
        long offered = FactQueries.num(r, "offered");
        long joined = FactQueries.num(r, "joined");
        return new PerformanceRow(id, name, applications, FactQueries.num(r, "hr_round"), FactQueries.num(r, "selected"), offered, joined,
                FactQueries.num(r, "rejected"), FactQueries.num(r, "open_count"), actions, FactQueries.ratio(joined, applications),
                FactQueries.ratio(joined, offered), FactQueries.dbl(r, "days_offer"), FactQueries.dbl(r, "days_join"));
    }
}
