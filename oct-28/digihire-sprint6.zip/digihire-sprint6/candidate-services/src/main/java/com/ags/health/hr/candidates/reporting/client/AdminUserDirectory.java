package com.ags.health.hr.candidates.reporting.client;

import com.ags.health.hr.candidates.reporting.port.UserDirectoryPort;
import com.ags.health.hr.common.platform.cache.TtlCache;
import com.ags.health.hr.common.platform.http.InternalHttp;
import com.fasterxml.jackson.databind.JsonNode;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.time.Clock;
import java.time.Duration;
import java.util.Collection;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class AdminUserDirectory implements UserDirectoryPort {

    private static final Logger log = LoggerFactory.getLogger(AdminUserDirectory.class);

    private final InternalHttp http;
    private final String base;
    private final List<String> roles;
    private final TtlCache<String, Map<String, String>> cache;

    public AdminUserDirectory(InternalHttp http, String adminUrl, List<String> roles, Duration ttl, Clock clock) {
        this.http = http;
        this.base = InternalHttp.trimBase(adminUrl);
        this.roles = List.copyOf(roles);
        this.cache = new TtlCache<>(ttl, 1, clock);
    }

    @Override
    public Map<String, String> names(Collection<String> userIds) {
        Map<String, String> all;
        try {
            all = cache.get("all", this::load);
        } catch (RuntimeException e) {
            log.warn("User directory unavailable: {}", e.getMessage());
            all = Map.of();
        }
        Map<String, String> out = new LinkedHashMap<>();
        for (String id : userIds) {
            if (id != null) {
                out.put(id, all.getOrDefault(id, all.getOrDefault(id.toLowerCase(java.util.Locale.ROOT), id)));
            }
        }
        return out;
    }

    private Map<String, String> load() {
        Map<String, String> m = new HashMap<>();
        for (String role : roles) {
            JsonNode list = http.get(base + "/internal/users/by-role/" + InternalHttp.encode(role));
            if (list == null || !list.isArray()) {
                continue;
            }
            for (JsonNode u : list) {
                String name = text(u, "fullName");
                if (name == null) {
                    continue;
                }
                for (String key : new String[]{text(u, "id"), text(u, "email"), text(u, "employeeCode"), text(u, "smartieUserId")}) {
                    if (key != null) {
                        m.put(key, name);
                        m.put(key.toLowerCase(java.util.Locale.ROOT), name);
                    }
                }
            }
        }
        return m;
    }

    private static String text(JsonNode n, String f) {
        JsonNode v = n.get(f);
        return v == null || v.isNull() || v.asText().isBlank() ? null : v.asText();
    }
}
