package com.ags.health.hr.candidates.reporting.service;

import com.ags.health.hr.candidates.reporting.domain.ReportScope;
import com.ags.health.hr.candidates.reporting.domain.Where;
import com.ags.health.hr.candidates.reporting.port.UserDirectoryPort;
import com.ags.health.hr.candidates.reporting.port.VendorDirectoryPort;
import com.ags.health.hr.candidates.reporting.store.FactStore;
import com.ags.health.hr.candidates.s6shared.S6Permissions;
import com.ags.health.hr.common.platform.cache.TtlCache;
import com.ags.health.hr.common.platform.caller.Caller;

import java.time.Clock;
import java.time.Duration;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class FilterOptionsService {

    public record Option(String value, String label) {
    }

    private final FactStore facts;
    private final UserDirectoryPort users;
    private final VendorDirectoryPort vendors;
    private final TtlCache<String, Map<String, List<Option>>> cache;

    public FilterOptionsService(FactStore facts, UserDirectoryPort users, VendorDirectoryPort vendors, Duration ttl, Clock clock) {
        this.facts = facts;
        this.users = users;
        this.vendors = vendors;
        this.cache = new TtlCache<>(ttl, 500, clock);
    }

    public Map<String, List<Option>> options(Caller caller) {
        ReportScope scope = ReportScope.of(caller, S6Permissions.DASHBOARD);
        return cache.get(scope.key(), () -> load(scope));
    }

    private Map<String, List<Option>> load(ReportScope scope) {
        Map<String, List<Option>> m = new LinkedHashMap<>();
        m.put("lob", plain(facts.distinct("lob", Where.fact(scope, null, false), 300)));
        m.put("location", plain(facts.distinct("location", Where.fact(scope, null, false), 300)));
        m.put("source", plain(facts.distinct("source", Where.fact(scope, null, false), 50)));
        m.put("role", plain(facts.distinct("role_code", Where.fact(scope, null, false), 300)));
        m.put("tab", plain(List.of("APPLICANT", "HR_INTERVIEW", "ASSESSMENT", "VERSANT", "PANEL", "PIPELINE", "OFFER", "JOINED", "REJECTED")));
        List<String> recruiters = facts.distinct("hr_user_id", Where.fact(scope, null, false), 500);
        m.put("recruiter", labelled(recruiters, users.names(recruiters)));
        List<String> vendorIds = facts.distinct("vendor_id", Where.fact(scope, null, false), 300);
        m.put("vendor", labelled(vendorIds, vendors.names(vendorIds)));
        m.put("requisition", plain(facts.distinct("requisition_id", Where.fact(scope, null, false).raw(FactQueries.OPEN), 300)));
        return m;
    }

    private static List<Option> plain(List<String> values) {
        return values.stream().map(v -> new Option(v, v)).toList();
    }

    private static List<Option> labelled(List<String> values, Map<String, String> names) {
        List<Option> out = new ArrayList<>();
        for (String v : values) {
            out.add(new Option(v, names.getOrDefault(v, v)));
        }
        out.sort((a, b) -> a.label().compareToIgnoreCase(b.label()));
        return out;
    }
}
