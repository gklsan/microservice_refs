package com.ags.health.hr.candidates.reporting.port;

import java.util.Collection;
import java.util.Map;
import java.util.Optional;

public interface VendorDirectoryPort {

    Map<String, String> names(Collection<String> vendorIds);

    Optional<String> vendorOfApplication(String applicationId);
}
