package com.ags.health.hr.candidates.worklist;

import java.util.Set;

public record WorklistQuery(String tab, Set<String> statuses, Set<String> lobs, Set<String> locations, Set<String> recruiterIds,
                            Set<String> requisitionIds, String q, String sort, String cursor, int size, boolean withCount) {
}
