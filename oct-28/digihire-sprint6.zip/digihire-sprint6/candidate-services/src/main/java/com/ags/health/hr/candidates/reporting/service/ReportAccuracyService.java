package com.ags.health.hr.candidates.reporting.service;

import com.ags.health.hr.candidates.reporting.domain.CheckRun;
import com.ags.health.hr.candidates.reporting.domain.FactRow;
import com.ags.health.hr.candidates.reporting.domain.FunnelStage;
import com.ags.health.hr.candidates.reporting.port.ReportSourcePort;
import com.ags.health.hr.candidates.reporting.port.SourceApplication;
import com.ags.health.hr.candidates.reporting.store.CheckRunStore;
import com.ags.health.hr.candidates.reporting.store.FactStore;
import com.ags.health.hr.candidates.s6shared.S6Permissions;
import com.ags.health.hr.common.platform.audit.AuditRecorder;
import com.ags.health.hr.common.platform.caller.Caller;
import com.ags.health.hr.common.platform.error.PlatformException;
import com.ags.health.hr.common.platform.time.BusinessClock;

import java.time.Instant;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.UUID;

public class ReportAccuracyService {

    public record Settings(double threshold, boolean repair, int batch, int maxSample) {
    }

    private final ReportSourcePort source;
    private final FactStore facts;
    private final FactCalculator calc;
    private final CheckRunStore runs;
    private final AuditRecorder audit;
    private final BusinessClock clock;
    private final Settings settings;

    public ReportAccuracyService(ReportSourcePort source, FactStore facts, FactCalculator calc, CheckRunStore runs, AuditRecorder audit,
                                 BusinessClock clock, Settings settings) {
        this.source = source;
        this.facts = facts;
        this.calc = calc;
        this.runs = runs;
        this.audit = audit;
        this.clock = clock;
        this.settings = settings;
    }

    public CheckRun run(Caller caller, LocalDate from, LocalDate to, Boolean repair) {
        if (caller == null || !caller.has(S6Permissions.QUALITY)) {
            throw PlatformException.forbidden("PERMISSION_DENIED", "Missing permission " + S6Permissions.QUALITY);
        }
        if (from == null || to == null || from.isAfter(to) || from.plusDays(92).isBefore(to)) {
            throw PlatformException.badRequest("DATE_RANGE_INVALID", "Give a range of at most 92 days");
        }
        return check(caller.userId(), from, to, repair == null ? settings.repair() : repair);
    }

    public List<CheckRun> recent(Caller caller, int limit) {
        if (caller == null || !caller.hasAny(S6Permissions.QUALITY, S6Permissions.READINESS)) {
            throw PlatformException.forbidden("PERMISSION_DENIED", "Missing permission " + S6Permissions.QUALITY);
        }
        return runs.recent(CheckRun.ACCURACY, Math.max(1, Math.min(limit, 50)));
    }

    public CheckRun check(String triggeredBy, LocalDate from, LocalDate to, boolean repair) {
        Instant started = clock.now();
        int matched = 0;
        int mismatched = 0;
        int missing = 0;
        int repaired = 0;
        List<String> sample = new ArrayList<>();
        String after = null;
        while (true) {
            List<String> ids = source.applicationIdsChangedBetween(clock.startOf(from), clock.startOf(to.plusDays(1)), after, settings.batch());
            if (ids.isEmpty()) {
                break;
            }
            for (String id : ids) {
                Optional<SourceApplication> src = source.load(id);
                if (src.isEmpty()) {
                    continue;
                }
                FactRow expected = calc.fromSource(src.get());
                Optional<FactRow> actual = facts.find(id);
                String diff = actual.isPresent() ? diff(expected, actual.get()) : "missing";
                if (diff == null) {
                    matched++;
                    continue;
                }
                if (actual.isEmpty()) {
                    missing++;
                } else {
                    mismatched++;
                }
                if (sample.size() < settings.maxSample()) {
                    sample.add(id + ": " + diff);
                }
                if (repair) {
                    facts.save(expected);
                    repaired++;
                }
            }
            after = ids.get(ids.size() - 1);
        }
        int checked = matched + mismatched + missing;
        double score = checked == 0 ? 100.0 : FactQueries.round(matched * 100.0 / checked, 4);
        String status = score >= settings.threshold() ? "PASS" : "FAIL";
        CheckRun run = new CheckRun(UUID.randomUUID().toString(), CheckRun.ACCURACY, from, to, checked, matched, mismatched, missing,
                repaired, score, settings.threshold(), status, sample, started, clock.now());
        runs.save(run, triggeredBy);
        audit.recordQuietly("ACTIVITY", "REPORT_ACCURACY_CHECKED", "REPORT", run.id(), null, "PASS".equals(status) ? AuditRecorder.SUCCESS
                        : AuditRecorder.FAILURE, null, AuditRecorder.details("from", from.toString(), "to", to.toString(), "checked", checked,
                        "score", score, "threshold", settings.threshold(), "repaired", repaired));
        return run;
    }

    static String diff(FactRow e, FactRow a) {
        List<String> d = new ArrayList<>();
        cmp(d, "status", e.status(), a.status());
        cmp(d, "tab", e.tab(), a.tab());
        cmp(d, "recruiter", e.hrUserId(), a.hrUserId());
        cmp(d, "requisition", e.requisitionId(), a.requisitionId());
        cmp(d, "lob", e.lob(), a.lob());
        cmp(d, "location", e.location(), a.location());
        cmp(d, "source", e.source(), a.source());
        cmp(d, "appliedDate", e.appliedDate(), a.appliedDate());
        cmp(d, "rejectedStage", e.rejectedStage(), a.rejectedStage());
        for (FunnelStage s : FunnelStage.values()) {
            boolean ex = e.reachedAt(s) != null;
            boolean ac = a.reachedAt(s) != null;
            if (ex != ac) {
                d.add(s.name() + " reached expected " + ex + " found " + ac);
            }
        }
        return d.isEmpty() ? null : String.join("; ", d);
    }

    private static void cmp(List<String> d, String field, Object expected, Object actual) {
        if (!Objects.equals(expected, actual)) {
            d.add(field + " expected " + expected + " found " + actual);
        }
    }
}
