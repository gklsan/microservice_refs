package com.ags.health.hr.candidates.reporting.domain;

public record ExportFile(String fileName, String contentType, byte[] content, int rows) {
}
