package com.ags.health.hr.candidates.reporting.client;

import com.ags.health.hr.candidates.reporting.port.ReportSourcePort;
import com.ags.health.hr.candidates.reporting.port.SourceApplication;
import com.ags.health.hr.candidates.reporting.port.VendorDirectoryPort;
import com.ags.health.hr.candidates.reporting.store.StageEventStore;
import com.ags.health.hr.candidates.shared.port.ApplicationPort;
import com.ags.health.hr.candidates.shared.port.ApplicationView;
import com.ags.health.hr.candidates.shared.port.CandidatePort;
import com.ags.health.hr.candidates.shared.port.CandidateView;
import com.ags.health.hr.candidates.shared.port.StageHistoryPort;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.time.Instant;
import java.util.List;
import java.util.Optional;

public class PortBackedReportSource implements ReportSourcePort {

    private static final Logger log = LoggerFactory.getLogger(PortBackedReportSource.class);

    private final ApplicationPort applications;
    private final StageHistoryPort history;
    private final CandidatePort candidates;
    private final VendorDirectoryPort vendors;
    private final StageEventStore events;

    public PortBackedReportSource(ApplicationPort applications, StageHistoryPort history, CandidatePort candidates,
                                  VendorDirectoryPort vendors, StageEventStore events) {
        this.applications = applications;
        this.history = history;
        this.candidates = candidates;
        this.vendors = vendors;
        this.events = events;
    }

    @Override
    public Optional<SourceApplication> load(String applicationId) {
        Optional<ApplicationView> app = applications.find(applicationId);
        if (app.isEmpty()) {
            return Optional.empty();
        }
        ApplicationView a = app.get();
        String name = candidates.find(a.candidateId()).map(CandidateView::fullName).orElse(null);
        String vendor = null;
        if ("VENDOR".equalsIgnoreCase(a.source()) && vendors != null) {
            try {
                vendor = vendors.vendorOfApplication(a.id()).orElse(null);
            } catch (RuntimeException e) {
                log.warn("Vendor lookup for {} failed: {}", a.id(), e.getMessage());
            }
        }
        return Optional.of(new SourceApplication(a, name, vendor, history.history(a.id())));
    }

    @Override
    public List<String> applicationIdsChangedBetween(Instant from, Instant to, String afterId, int limit) {
        return events.applicationIdsBetween(from, to, afterId, limit);
    }
}
