package com.ags.health.hr.candidates.worklist;

import com.ags.health.hr.candidates.shared.port.RequisitionPort;
import com.ags.health.hr.candidates.shared.port.RequisitionView;
import com.ags.health.hr.common.platform.cache.TtlCache;

import java.time.Clock;
import java.time.Duration;
import java.util.Optional;

public class CachingRequisitionPort implements RequisitionPort {

    private final RequisitionPort delegate;
    private final TtlCache<String, Optional<RequisitionView>> cache;

    public CachingRequisitionPort(RequisitionPort delegate, Duration ttl, Clock clock) {
        this.delegate = delegate;
        this.cache = new TtlCache<>(ttl, 5000, clock);
    }

    @Override
    public Optional<RequisitionView> find(String requisitionId) {
        if (requisitionId == null || requisitionId.isBlank()) {
            return Optional.empty();
        }
        return cache.get(requisitionId.trim(), () -> delegate.find(requisitionId));
    }

    public TtlCache.Stats stats() {
        return cache.stats();
    }
}
