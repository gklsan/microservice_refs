package com.ags.health.hr.candidates.reporting.service;

import com.ags.health.hr.candidates.reporting.domain.DrillRow;
import com.ags.health.hr.candidates.reporting.domain.FunnelStage;
import com.ags.health.hr.candidates.reporting.domain.ReportFilter;
import com.ags.health.hr.candidates.reporting.domain.ReportScope;
import com.ags.health.hr.candidates.reporting.domain.Where;
import com.ags.health.hr.candidates.reporting.store.FactStore;
import com.ags.health.hr.candidates.reporting.store.StageEventStore;
import com.ags.health.hr.candidates.s6shared.S6Permissions;
import com.ags.health.hr.candidates.shared.domain.Tab;
import com.ags.health.hr.common.platform.caller.Caller;
import com.ags.health.hr.common.platform.error.PlatformException;
import com.ags.health.hr.common.platform.page.PageResult;
import com.ags.health.hr.common.platform.time.BusinessClock;

import java.sql.Date;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public class DrillDownService {

    static final Map<String, String> SORTS = Map.of("status_since", "status_since ASC, application_id",
            "-status_since", "status_since DESC, application_id", "applied", "applied_date ASC, application_id",
            "-applied", "applied_date DESC, application_id", "name", "candidate_name ASC, application_id");

    private final FactStore facts;
    private final BusinessClock clock;
    private final int maxPageSize;
    private final int maxRangeDays;

    public DrillDownService(FactStore facts, BusinessClock clock, int maxPageSize, int maxRangeDays) {
        this.facts = facts;
        this.clock = clock;
        this.maxPageSize = maxPageSize;
        this.maxRangeDays = maxRangeDays;
    }

    public PageResult<DrillRow> drill(Caller caller, ReportFilter filter, String drill, int page, int size, String sort) {
        ReportScope scope = ReportScope.of(caller, S6Permissions.DASHBOARD);
        if (!caller.has(S6Permissions.CANDIDATE_VIEW)) {
            throw PlatformException.forbidden("PERMISSION_DENIED", "Missing permission " + S6Permissions.CANDIDATE_VIEW);
        }
        int s = PageResult.safeSize(size, maxPageSize);
        int p = PageResult.safePage(page);
        Where w = where(scope, filter, drill);
        String order = SORTS.getOrDefault(sort == null ? "-status_since" : sort, SORTS.get("-status_since"));
        long total = facts.count(w);
        return new PageResult<>(facts.page(w, order, s, (long) p * s, clock.now()), p, s, total);
    }

    public List<DrillRow> all(Caller caller, ReportFilter filter, String drill, int limit) {
        ReportScope scope = ReportScope.of(caller, S6Permissions.DASHBOARD);
        return facts.page(where(scope, filter, drill), SORTS.get("-status_since"), limit, 0, clock.now());
    }

    Where where(ReportScope scope, ReportFilter filter, String drill) {
        if (drill == null || !drill.contains(":")) {
            throw PlatformException.badRequest("DRILL_INVALID", "Drill must look like widget:key");
        }
        String widget = drill.substring(0, drill.indexOf(':')).toLowerCase(Locale.ROOT);
        String key = drill.substring(drill.indexOf(':') + 1).trim();
        if (key.isEmpty() || key.length() > 64) {
            throw PlatformException.badRequest("DRILL_INVALID", "Drill key is missing or too long");
        }
        boolean dated = filter.from() != null || filter.to() != null;
        switch (widget) {
            case "pipeline" -> {
                ReportFilter f = dated ? filter.withDefaults(clock.today(), 30, maxRangeDays) : filter;
                return Where.fact(scope, f, dated).raw(FactQueries.OPEN).eq("tab", tab(key).name());
            }
            case "aging" -> {
                ReportFilter f = dated ? filter.withDefaults(clock.today(), 30, maxRangeDays) : filter;
                Where w = Where.fact(scope, f, dated).raw(FactQueries.OPEN);
                List<Object> b = DashboardService.agingBounds(clock.now());
                return switch (key.toUpperCase(Locale.ROOT)) {
                    case "D0_2" -> w.raw("status_since >= ?", b.get(0));
                    case "D3_7" -> w.raw("status_since < ? AND status_since >= ?", b.get(0), b.get(1));
                    case "D8_14" -> w.raw("status_since < ? AND status_since >= ?", b.get(1), b.get(2));
                    case "D15_30" -> w.raw("status_since < ? AND status_since >= ?", b.get(2), b.get(3));
                    case "D31_PLUS" -> w.raw("status_since < ?", b.get(3));
                    default -> throw PlatformException.badRequest("DRILL_INVALID", "Unknown aging bucket " + key);
                };
            }
            case "movements" -> {
                ReportFilter f = dated ? filter.withDefaults(clock.today(), 30, maxRangeDays) : filter;
                return Where.fact(scope, f, dated).raw("application_id IN (SELECT application_id FROM " + StageEventStore.TABLE
                        + " WHERE moved_date = ? AND to_tab = ?)", Date.valueOf(clock.today()), tab(key).name());
            }
            case "funnel" -> {
                ReportFilter f = filter.withDefaults(clock.today(), 30, maxRangeDays);
                return Where.fact(scope, f, true).raw(stage(key).reachedSql());
            }
            case "dropped" -> {
                ReportFilter f = filter.withDefaults(clock.today(), 30, maxRangeDays);
                return Where.fact(scope, f, true).raw("tab = 'REJECTED'").eq("rejected_stage", stage(key).name());
            }
            case "requisition" -> {
                ReportFilter f = dated ? filter.withDefaults(clock.today(), 30, maxRangeDays) : filter;
                return Where.fact(scope, f, dated).raw(FactQueries.OPEN).eq("requisition_id", key);
            }
            case "recruiter" -> {
                ReportFilter f = dated ? filter.withDefaults(clock.today(), 30, maxRangeDays) : filter;
                return Where.fact(scope, f, dated).raw(FactQueries.OPEN).eq("hr_user_id", key);
            }
            default -> throw PlatformException.badRequest("DRILL_INVALID", "Unknown widget " + widget);
        }
    }

    private static Tab tab(String key) {
        try {
            return Tab.valueOf(key.toUpperCase(Locale.ROOT));
        } catch (IllegalArgumentException e) {
            throw PlatformException.badRequest("DRILL_INVALID", "Unknown tab " + key);
        }
    }

    private static FunnelStage stage(String key) {
        try {
            return FunnelStage.parse(key);
        } catch (IllegalArgumentException e) {
            throw PlatformException.badRequest("DRILL_INVALID", e.getMessage());
        }
    }
}
