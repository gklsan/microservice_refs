package com.ags.health.hr.candidates.ops;

import com.ags.health.hr.candidates.reporting.domain.CheckRun;
import com.ags.health.hr.candidates.reporting.store.CheckRunStore;
import com.ags.health.hr.candidates.reporting.store.DirtyStore;
import com.ags.health.hr.candidates.s6shared.CandidateS6Properties;
import com.ags.health.hr.candidates.shared.config.CandidateP5Properties;
import com.ags.health.hr.common.platform.readiness.Checks;
import com.ags.health.hr.common.platform.readiness.ReadinessCheck;
import com.ags.health.hr.common.platform.readiness.ReadinessResult;
import org.springframework.jdbc.core.JdbcTemplate;

import java.time.Clock;
import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Optional;

public final class CandidateReadinessChecks {

    static final List<String> TABLES = List.of("cand_p5_outbox", "cand_p5_inbox", "cand_mapping_action", "cand_rejection_reason",
            "cand_interview_slot", "cand_id_document", "cand_bulk_job", "cand_competency", "cand_hr_interview", "cand_panel_schedule",
            "cand_orc_restriction", "cand_p6_app_fact", "cand_p6_stage_event", "cand_p6_check_run", "cand_p6_idempotency", "audit_log");

    private CandidateReadinessChecks() {
    }

    public static List<ReadinessCheck> all(JdbcTemplate jdbc, CandidateP5Properties p5, CandidateS6Properties s6, CheckRunStore runs,
                                           DirtyStore dirty, Clock clock) {
        boolean prod = isProduction(s6.getEnvironment());
        CandidateS6Properties.Readiness r = s6.getReadiness();
        List<ReadinessCheck> checks = new ArrayList<>();
        checks.add(Checks.database(jdbc));
        checks.add(Checks.tables(jdbc, TABLES));
        checks.add(Checks.setting("jwt-secret", "security", p5.getSecurity().getJwtSecret(), true, "JWT_SECRET"));
        checks.add(Checks.setting("internal-key", "security", p5.getSecurity().getInternalKey(), true, "Internal service key"));
        checks.add(Checks.setting("kek-keys", "security", p5.getStorage().getKekKeys(), true, "Document encryption keys"));
        checks.add(Checks.notStub("document-storage", "integration", p5.getStorage().getMode(), prod));
        checks.add(Checks.of("service-urls", "configuration", () -> urls(p5, prod)));
        checks.add(Checks.backlog("outbox-backlog", "integration", () -> count(jdbc,
                "SELECT count(*) FROM cand_p5_outbox WHERE published_at IS NULL AND parked_at IS NULL"), r.getOutboxWarn(), r.getOutboxFail()));
        checks.add(Checks.backlog("outbox-parked", "integration", () -> count(jdbc,
                "SELECT count(*) FROM cand_p5_outbox WHERE parked_at IS NOT NULL AND published_at IS NULL"), 1, 50));
        checks.add(Checks.backlog("report-dirty", "reporting", dirty::backlog, r.getDirtyWarn(), r.getDirtyFail()));
        checks.add(Checks.of("report-accuracy", "reporting", () -> lastRun(runs.latest(CheckRun.ACCURACY), clock, r.getCheckMaxAgeHours(), prod)));
        checks.add(Checks.of("audit-completeness", "audit", () -> lastRun(runs.latest(CheckRun.AUDIT), clock, r.getCheckMaxAgeHours(), prod)));
        return checks;
    }

    static boolean isProduction(String env) {
        String e = env == null ? "" : env.toLowerCase(Locale.ROOT);
        return e.startsWith("prod");
    }

    static ReadinessResult urls(CandidateP5Properties p5, boolean prod) {
        CandidateP5Properties.Clients c = p5.getClients();
        List<String> local = new ArrayList<>();
        for (String u : List.of(c.getAdminUrl(), c.getJobUrl(), c.getAssessmentUrl(), c.getIntegrationUrl(), c.getVendorUrl(), c.getWorkflowUrl())) {
            if (u == null || u.contains("localhost") || u.contains("127.0.0.1")) {
                local.add(String.valueOf(u));
            }
        }
        if (local.isEmpty()) {
            return ReadinessResult.pass("All service URLs point to real hosts");
        }
        ReadinessResult res = prod ? ReadinessResult.fail(local.size() + " service URLs point to localhost")
                : ReadinessResult.warn(local.size() + " service URLs point to localhost");
        return res.with(Map.of("urls", local));
    }

    static ReadinessResult lastRun(Optional<CheckRun> run, Clock clock, int maxAgeHours, boolean prod) {
        if (run.isEmpty()) {
            return prod ? ReadinessResult.fail("Never run") : ReadinessResult.warn("Never run");
        }
        CheckRun c = run.get();
        Map<String, Object> d = Map.of("status", c.status(), "score", c.score(), "checked", c.checked(), "at", String.valueOf(c.startedAt()));
        if (c.startedAt().isBefore(clock.instant().minus(Duration.ofHours(maxAgeHours)))) {
            return ReadinessResult.warn("Last run is older than " + maxAgeHours + "h").with(d);
        }
        return "PASS".equals(c.status()) ? ReadinessResult.pass("Last run passed with " + c.score() + "%").with(d)
                : ReadinessResult.fail("Last run failed with " + c.score() + "%").with(d);
    }

    private static long count(JdbcTemplate jdbc, String sql) {
        Long n = jdbc.queryForObject(sql, Long.class);
        return n == null ? 0 : n;
    }
}
