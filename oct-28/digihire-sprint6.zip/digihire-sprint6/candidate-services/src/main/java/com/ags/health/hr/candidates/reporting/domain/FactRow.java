package com.ags.health.hr.candidates.reporting.domain;

import java.time.Instant;
import java.time.LocalDate;

public record FactRow(String applicationId, String candidateId, String candidateName, String requisitionId, String jobId, String lob,
                      String location, String roleCode, String orcId, String source, String vendorId, String hrUserId,
                      String status, String tab, Instant appliedAt, LocalDate appliedDate, Instant hrRoundAt,
                      Instant assessmentAt, Instant versantAt, Instant panelAt, Instant selectedAt, Instant offeredAt,
                      Instant joinedAt, Instant rejectedAt, String rejectedStage, Instant statusSince, Instant updatedAt) {

    public Instant reachedAt(FunnelStage stage) {
        return switch (stage) {
            case APPLIED -> appliedAt;
            case HR_ROUND -> hrRoundAt;
            case ASSESSMENT -> assessmentAt;
            case VERSANT -> versantAt;
            case PANEL -> panelAt;
            case SELECTED -> selectedAt;
            case OFFERED -> offeredAt;
            case JOINED -> joinedAt;
        };
    }
}
