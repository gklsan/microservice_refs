package com.ags.health.hr.candidates.reporting.domain;

import java.time.LocalDate;
import java.util.List;
import java.util.Map;

public record FunnelReport(LocalDate from, LocalDate to, long total, List<Step> steps, List<Breakdown> breakdown,
                           Map<String, String> filters) {

    public record Step(FunnelStage stage, long reached, Double conversionFromPrevious, Double conversionFromApplied,
                       long droppedHere, long openHere, Double avgDaysFromApplied) {
    }

    public record Breakdown(String dimension, String value, String label, long applied, long hrRound, long selected,
                            long offered, long joined, Double conversion) {
    }

    public FunnelReport {
        steps = List.copyOf(steps);
        breakdown = breakdown == null ? List.of() : List.copyOf(breakdown);
        filters = filters == null ? Map.of() : Map.copyOf(filters);
    }
}
