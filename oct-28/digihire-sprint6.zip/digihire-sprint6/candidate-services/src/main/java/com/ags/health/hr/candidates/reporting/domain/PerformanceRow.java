package com.ags.health.hr.candidates.reporting.domain;

public record PerformanceRow(String id, String name, long applications, long hrRound, long selected, long offered, long joined,
                             long rejected, long open, long actions, Double conversion, Double offerAcceptance,
                             Double avgDaysToOffer, Double avgDaysToJoin) {
}
