package com.ags.health.hr.candidates.concurrency;

import com.ags.health.hr.candidates.s6shared.CandidateS6Properties;
import com.ags.health.hr.candidates.shared.port.ApplicationPort;
import com.ags.health.hr.common.platform.caller.CallerProvider;
import com.ags.health.hr.common.platform.concurrency.IdempotencyStore;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.core.JdbcTemplate;

import java.time.Clock;
import java.time.Duration;

@Configuration
@ConditionalOnProperty(prefix = "digihire.s6.concurrency", name = "enabled", havingValue = "true", matchIfMissing = true)
public class ConcurrencyConfig {

    @Bean
    public IdempotencyStore p6IdempotencyStore(JdbcTemplate jdbc, Clock p5Clock, CandidateS6Properties s6) {
        CandidateS6Properties.Concurrency c = s6.getConcurrency();
        return new IdempotencyStore(jdbc, p5Clock, "cand_p6_idempotency", Duration.ofHours(c.getIdempotencyTtlHours()),
                Duration.ofSeconds(c.getInFlightSeconds()));
    }

    @Bean
    public FilterRegistrationBean<IdempotencyFilter> p6IdempotencyFilter(IdempotencyStore p6IdempotencyStore, CallerProvider callers,
                                                                         CandidateS6Properties s6) {
        FilterRegistrationBean<IdempotencyFilter> reg = new FilterRegistrationBean<>(new IdempotencyFilter(p6IdempotencyStore, callers,
                s6.getConcurrency().getIdempotentPaths()));
        reg.setOrder(10);
        reg.addUrlPatterns("/*");
        return reg;
    }

    @Bean
    public ApplicationMutexGuard p6ApplicationMutexGuard(ApplicationPort applications, JdbcTemplate jdbc, Clock p5Clock, CandidateS6Properties s6) {
        CandidateS6Properties.Concurrency c = s6.getConcurrency();
        return new ApplicationMutexGuard(applications, jdbc, p5Clock, c.isStaleCheck(), c.isRowLock());
    }
}
