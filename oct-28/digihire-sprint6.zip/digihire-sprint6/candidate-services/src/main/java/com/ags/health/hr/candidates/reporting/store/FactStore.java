package com.ags.health.hr.candidates.reporting.store;

import com.ags.health.hr.candidates.reporting.domain.DrillRow;
import com.ags.health.hr.candidates.reporting.domain.FactRow;
import com.ags.health.hr.candidates.reporting.domain.Where;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;

public class FactStore {

    public static final String TABLE = "cand_p6_app_fact";
    static final String COLUMNS = "application_id, candidate_id, candidate_name, requisition_id, job_id, lob, location, role_code, orc_id, "
            + "source, vendor_id, hr_user_id, status, tab, applied_at, applied_date, hr_round_at, assessment_at, versant_at, panel_at, "
            + "selected_at, offered_at, joined_at, rejected_at, rejected_stage, status_since, updated_at";
    private static final String DRILL_COLUMNS = "application_id, candidate_id, candidate_name, requisition_id, lob, location, role_code, "
            + "source, hr_user_id, status, tab, applied_date, status_since";

    public static final RowMapper<FactRow> ROW = (rs, i) -> new FactRow(rs.getString(1), rs.getString(2), rs.getString(3),
            rs.getString(4), rs.getString(5), rs.getString(6), rs.getString(7), rs.getString(8), rs.getString(9), rs.getString(10),
            rs.getString(11), rs.getString(12), rs.getString(13), rs.getString(14), ts(rs, 15), rs.getDate(16).toLocalDate(),
            ts(rs, 17), ts(rs, 18), ts(rs, 19), ts(rs, 20), ts(rs, 21), ts(rs, 22), ts(rs, 23), ts(rs, 24), rs.getString(25),
            ts(rs, 26), ts(rs, 27));

    private final JdbcTemplate jdbc;
    private final SqlDialect dialect;

    public FactStore(JdbcTemplate jdbc, SqlDialect dialect) {
        this.jdbc = jdbc;
        this.dialect = dialect;
    }

    public SqlDialect dialect() {
        return dialect;
    }

    public JdbcTemplate jdbc() {
        return jdbc;
    }

    public Optional<FactRow> find(String applicationId) {
        return jdbc.query("SELECT " + COLUMNS + " FROM " + TABLE + " WHERE application_id = ?", ROW, applicationId).stream().findFirst();
    }

    public void save(FactRow f) {
        Object[] values = {f.candidateId(), f.candidateName(), f.requisitionId(), f.jobId(), f.lob(), f.location(), f.roleCode(),
                f.orcId(), f.source(), f.vendorId(), f.hrUserId(), f.status(), f.tab(), t(f.appliedAt()), Date.valueOf(f.appliedDate()),
                t(f.hrRoundAt()), t(f.assessmentAt()), t(f.versantAt()), t(f.panelAt()), t(f.selectedAt()), t(f.offeredAt()),
                t(f.joinedAt()), t(f.rejectedAt()), f.rejectedStage(), t(f.statusSince()), t(f.updatedAt()), f.applicationId()};
        String update = "UPDATE " + TABLE + " SET candidate_id = ?, candidate_name = ?, requisition_id = ?, job_id = ?, lob = ?, "
                + "location = ?, role_code = ?, orc_id = ?, source = ?, vendor_id = ?, hr_user_id = ?, status = ?, tab = ?, applied_at = ?, "
                + "applied_date = ?, hr_round_at = ?, assessment_at = ?, versant_at = ?, panel_at = ?, selected_at = ?, offered_at = ?, "
                + "joined_at = ?, rejected_at = ?, rejected_stage = ?, status_since = ?, updated_at = ?, version = version + 1 "
                + "WHERE application_id = ?";
        if (jdbc.update(update, values) > 0) {
            return;
        }
        try {
            jdbc.update("INSERT INTO " + TABLE + " (candidate_id, candidate_name, requisition_id, job_id, lob, location, role_code, "
                    + "orc_id, source, vendor_id, hr_user_id, status, tab, applied_at, applied_date, hr_round_at, assessment_at, versant_at, "
                    + "panel_at, selected_at, offered_at, joined_at, rejected_at, rejected_stage, status_since, updated_at, application_id) "
                    + "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)", values);
        } catch (DuplicateKeyException e) {
            jdbc.update(update, values);
        }
    }

    public long count(Where w) {
        Long n = jdbc.queryForObject("SELECT count(*) FROM " + TABLE + w.sql(), Long.class, w.args());
        return n == null ? 0 : n;
    }

    public Map<String, Object> aggregate(String selectList, Where w) {
        return jdbc.queryForMap("SELECT " + selectList + " FROM " + TABLE + w.sql(), w.args());
    }

    public List<Map<String, Object>> grouped(String groupColumn, String selectList, Where w, String orderBy, int limit) {
        List<Object> args = w.argList();
        args.add(limit);
        return jdbc.queryForList("SELECT " + groupColumn + " AS grp, " + selectList + " FROM " + TABLE + w.sql() + " GROUP BY "
                + groupColumn + " ORDER BY " + orderBy + " LIMIT ?", args.toArray());
    }

    public List<DrillRow> page(Where w, String orderBy, int limit, long offset, Instant now) {
        List<Object> args = w.argList();
        args.add(limit);
        args.add(offset);
        return jdbc.query("SELECT " + DRILL_COLUMNS + " FROM " + TABLE + w.sql() + " ORDER BY " + orderBy + " LIMIT ? OFFSET ?",
                (rs, i) -> drill(rs, now), args.toArray());
    }

    public List<DrillRow> keyset(Where w, String orderBy, int limit, Instant now) {
        List<Object> args = w.argList();
        args.add(limit);
        return jdbc.query("SELECT " + DRILL_COLUMNS + " FROM " + TABLE + w.sql() + " ORDER BY " + orderBy + " LIMIT ?",
                (rs, i) -> drill(rs, now), args.toArray());
    }

    public long countCapped(Where w, int cap) {
        List<Object> args = w.argList();
        args.add(cap + 1);
        Long n = jdbc.queryForObject("SELECT count(*) FROM (SELECT 1 AS x FROM " + TABLE + w.sql() + " LIMIT ?) capped", Long.class,
                args.toArray());
        return n == null ? 0 : n;
    }

    public List<String> distinct(String column, Where w, int limit) {
        List<Object> args = w.argList();
        args.add(limit);
        return jdbc.queryForList("SELECT DISTINCT " + column + " FROM " + TABLE + w.sql() + " AND " + column + " IS NOT NULL ORDER BY "
                + column + " LIMIT ?", String.class, args.toArray());
    }

    private static DrillRow drill(ResultSet rs, Instant now) throws SQLException {
        Instant since = ts(rs, 13);
        return new DrillRow(rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5), rs.getString(6),
                rs.getString(7), rs.getString(8), rs.getString(9), rs.getString(10), rs.getString(11), rs.getDate(12).toLocalDate(), since,
                since == null ? 0 : Math.max(0, ChronoUnit.DAYS.between(since, now)));
    }

    static Instant ts(ResultSet rs, int i) throws SQLException {
        Timestamp t = rs.getTimestamp(i);
        return t == null ? null : t.toInstant();
    }

    static Timestamp t(Instant i) {
        return i == null ? null : Timestamp.from(i);
    }

    public List<String> idsWithout(List<String> ids) {
        if (ids.isEmpty()) {
            return List.of();
        }
        StringBuilder in = new StringBuilder();
        for (int i = 0; i < ids.size(); i++) {
            in.append(i == 0 ? "?" : ", ?");
        }
        List<String> present = jdbc.queryForList("SELECT application_id FROM " + TABLE + " WHERE application_id IN (" + in + ")",
                String.class, ids.toArray());
        List<String> out = new ArrayList<>(ids);
        out.removeAll(present);
        return out;
    }
}
