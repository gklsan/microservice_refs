package com.ags.health.hr.candidates.reporting.service;

import com.ags.health.hr.common.platform.export.ReportTable;

public interface ReportPdfRenderer {

    byte[] render(ReportTable table, String footer);
}
