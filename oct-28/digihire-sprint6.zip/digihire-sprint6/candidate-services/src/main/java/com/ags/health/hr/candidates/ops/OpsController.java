package com.ags.health.hr.candidates.ops;

import com.ags.health.hr.candidates.s6shared.S6Permissions;
import com.ags.health.hr.common.platform.caller.Caller;
import com.ags.health.hr.common.platform.caller.CallerProvider;
import com.ags.health.hr.common.platform.caller.InternalKeyVerifier;
import com.ags.health.hr.common.platform.error.PlatformException;
import com.ags.health.hr.common.platform.readiness.ReadinessReport;
import com.ags.health.hr.common.platform.readiness.ReadinessResult;
import com.ags.health.hr.common.platform.readiness.ReadinessService;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@ConditionalOnProperty(prefix = "digihire.s6.readiness", name = "enabled", havingValue = "true", matchIfMissing = true)
@RestController
public class OpsController {

    private final ReadinessService readiness;
    private final CallerProvider callers;
    private final InternalKeyVerifier internal;

    public OpsController(ReadinessService readiness, CallerProvider callers, InternalKeyVerifier internal) {
        this.readiness = readiness;
        this.callers = callers;
        this.internal = internal;
    }

    @GetMapping("/ops/readiness")
    public ReadinessReport readiness() {
        Caller c = callers.require();
        if (!c.has(S6Permissions.READINESS)) {
            throw PlatformException.forbidden("PERMISSION_DENIED", "Missing permission " + S6Permissions.READINESS);
        }
        return readiness.run();
    }

    @GetMapping("/internal/readiness")
    public ResponseEntity<ReadinessReport> internalReadiness(HttpServletRequest request) {
        internal.require(request);
        ReadinessReport r = readiness.run();
        return ResponseEntity.status(r.overall() == ReadinessResult.Status.FAIL ? org.springframework.http.HttpStatus.SERVICE_UNAVAILABLE
                : org.springframework.http.HttpStatus.OK).body(r);
    }
}
