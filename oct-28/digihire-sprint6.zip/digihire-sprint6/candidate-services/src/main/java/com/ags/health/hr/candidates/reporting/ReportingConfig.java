package com.ags.health.hr.candidates.reporting;

import com.ags.health.hr.candidates.reporting.client.AdminUserDirectory;
import com.ags.health.hr.candidates.reporting.client.PortBackedReportSource;
import com.ags.health.hr.candidates.reporting.client.VendorServicesDirectory;
import com.ags.health.hr.candidates.reporting.port.ReportSourcePort;
import com.ags.health.hr.candidates.reporting.port.UserDirectoryPort;
import com.ags.health.hr.candidates.reporting.port.VendorDirectoryPort;
import com.ags.health.hr.candidates.reporting.service.AuditCompletenessService;
import com.ags.health.hr.candidates.reporting.service.DashboardService;
import com.ags.health.hr.candidates.reporting.service.DrillDownService;
import com.ags.health.hr.candidates.reporting.service.FactCalculator;
import com.ags.health.hr.candidates.reporting.service.FactProjector;
import com.ags.health.hr.candidates.reporting.service.FactRebuildService;
import com.ags.health.hr.candidates.reporting.service.FilterOptionsService;
import com.ags.health.hr.candidates.reporting.service.FunnelReportService;
import com.ags.health.hr.candidates.reporting.service.PdfBoxReportRenderer;
import com.ags.health.hr.candidates.reporting.service.PerformanceReportService;
import com.ags.health.hr.candidates.reporting.service.ReportAccuracyService;
import com.ags.health.hr.candidates.reporting.service.ReportExportService;
import com.ags.health.hr.candidates.reporting.service.ReportJobs;
import com.ags.health.hr.candidates.reporting.service.ReportPdfRenderer;
import com.ags.health.hr.candidates.reporting.store.CheckRunStore;
import com.ags.health.hr.candidates.reporting.store.DirtyStore;
import com.ags.health.hr.candidates.reporting.store.FactStore;
import com.ags.health.hr.candidates.reporting.store.SqlDialect;
import com.ags.health.hr.candidates.reporting.store.StageEventStore;
import com.ags.health.hr.candidates.s6shared.CandidateS6Properties;
import com.ags.health.hr.candidates.shared.config.CandidateP5Properties;
import com.ags.health.hr.candidates.shared.domain.StageCatalog;
import com.ags.health.hr.candidates.shared.port.ApplicationPort;
import com.ags.health.hr.candidates.shared.port.CandidatePort;
import com.ags.health.hr.candidates.shared.port.StageHistoryPort;
import com.ags.health.hr.common.platform.audit.AuditRecorder;
import com.ags.health.hr.common.platform.concurrency.IdempotencyStore;
import com.ags.health.hr.common.platform.http.InternalHttp;
import com.ags.health.hr.common.platform.jobs.ScheduledJobRunner;
import com.ags.health.hr.common.platform.time.BusinessClock;
import org.springframework.beans.factory.ObjectProvider;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.TransactionDefinition;
import org.springframework.transaction.support.TransactionTemplate;

import java.time.Clock;
import java.time.Duration;

@Configuration
@ConditionalOnProperty(prefix = "digihire.s6.reporting", name = "enabled", havingValue = "true", matchIfMissing = true)
public class ReportingConfig {

    @Bean
    public FactStore p6FactStore(JdbcTemplate jdbc) {
        return new FactStore(jdbc, SqlDialect.detect(jdbc));
    }

    @Bean
    public StageEventStore p6StageEventStore(JdbcTemplate jdbc) {
        return new StageEventStore(jdbc);
    }

    @Bean
    public DirtyStore p6DirtyStore(JdbcTemplate jdbc) {
        return new DirtyStore(jdbc);
    }

    @Bean
    public CheckRunStore p6CheckRunStore(JdbcTemplate jdbc) {
        return new CheckRunStore(jdbc);
    }

    @Bean
    @ConditionalOnMissingBean(UserDirectoryPort.class)
    public UserDirectoryPort p6UserDirectory(InternalHttp p5InternalHttp, CandidateP5Properties p5, CandidateS6Properties s6, Clock p5Clock) {
        CandidateS6Properties.Reporting r = s6.getReporting();
        return new AdminUserDirectory(p5InternalHttp, p5.getClients().getAdminUrl(), r.getDirectoryRoles(),
                Duration.ofMinutes(r.getDirectoryCacheMinutes()), p5Clock);
    }

    @Bean
    @ConditionalOnMissingBean(VendorDirectoryPort.class)
    public VendorDirectoryPort p6VendorDirectory(InternalHttp p5InternalHttp, CandidateP5Properties p5, CandidateS6Properties s6, Clock p5Clock) {
        return new VendorServicesDirectory(p5InternalHttp, p5.getClients().getVendorUrl(),
                Duration.ofMinutes(s6.getReporting().getDirectoryCacheMinutes()), p5Clock);
    }

    @Bean
    @ConditionalOnMissingBean(ReportSourcePort.class)
    public ReportSourcePort p6ReportSource(ApplicationPort applications, StageHistoryPort history, CandidatePort candidates,
                                           VendorDirectoryPort vendors, StageEventStore p6StageEventStore) {
        return new PortBackedReportSource(applications, history, candidates, vendors, p6StageEventStore);
    }

    @Bean
    public FactCalculator p6FactCalculator(StageCatalog p5StageCatalog, BusinessClock p5BusinessClock) {
        return new FactCalculator(p5StageCatalog, p5BusinessClock);
    }

    @Bean
    public FactProjector p6FactProjector(FactStore p6FactStore, StageEventStore p6StageEventStore, DirtyStore p6DirtyStore,
                                         ReportSourcePort source, FactCalculator p6FactCalculator, BusinessClock p5BusinessClock,
                                         PlatformTransactionManager tm) {
        TransactionTemplate requiresNew = new TransactionTemplate(tm);
        requiresNew.setPropagationBehavior(TransactionDefinition.PROPAGATION_REQUIRES_NEW);
        return new FactProjector(p6FactStore, p6StageEventStore, p6DirtyStore, source, p6FactCalculator, p5BusinessClock, requiresNew);
    }

    @Bean
    public FactRebuildService p6FactRebuildService(ReportSourcePort source, FactStore p6FactStore, DirtyStore p6DirtyStore,
                                                   FactCalculator p6FactCalculator, AuditRecorder audit, BusinessClock p5BusinessClock) {
        return new FactRebuildService(source, p6FactStore, p6DirtyStore, p6FactCalculator, audit, p5BusinessClock, 5);
    }

    @Bean
    public FunnelReportService p6FunnelReportService(FactStore p6FactStore, UserDirectoryPort users, VendorDirectoryPort vendors,
                                                     BusinessClock p5BusinessClock, CandidateS6Properties s6) {
        return new FunnelReportService(p6FactStore, users, vendors, p5BusinessClock, s6.getReporting().getMaxRangeDays());
    }

    @Bean
    public PerformanceReportService p6PerformanceReportService(FactStore p6FactStore, StageEventStore p6StageEventStore, UserDirectoryPort users,
                                                               VendorDirectoryPort vendors, BusinessClock p5BusinessClock, CandidateS6Properties s6) {
        return new PerformanceReportService(p6FactStore, p6StageEventStore, users, vendors, p5BusinessClock, s6.getReporting().getMaxRangeDays());
    }

    @Bean
    public DashboardService p6DashboardService(FactStore p6FactStore, StageEventStore p6StageEventStore, FunnelReportService p6FunnelReportService,
                                               UserDirectoryPort users, BusinessClock p5BusinessClock, CandidateS6Properties s6) {
        CandidateS6Properties.Reporting r = s6.getReporting();
        return new DashboardService(p6FactStore, p6StageEventStore, p6FunnelReportService, users, p5BusinessClock,
                Duration.ofSeconds(r.getDashboardCacheSeconds()), r.getMaxRangeDays());
    }

    @Bean
    public DrillDownService p6DrillDownService(FactStore p6FactStore, BusinessClock p5BusinessClock, CandidateS6Properties s6) {
        return new DrillDownService(p6FactStore, p5BusinessClock, s6.getReporting().getMaxPageSize(), s6.getReporting().getMaxRangeDays());
    }

    @Bean
    public FilterOptionsService p6FilterOptionsService(FactStore p6FactStore, UserDirectoryPort users, VendorDirectoryPort vendors,
                                                       CandidateS6Properties s6, Clock p5Clock) {
        return new FilterOptionsService(p6FactStore, users, vendors, Duration.ofSeconds(s6.getReporting().getOptionsCacheSeconds()), p5Clock);
    }

    @Bean
    @ConditionalOnMissingBean(ReportPdfRenderer.class)
    public ReportPdfRenderer p6ReportPdfRenderer(BusinessClock p5BusinessClock) {
        return new PdfBoxReportRenderer(p5BusinessClock.zone());
    }

    @Bean
    public ReportExportService p6ReportExportService(FunnelReportService p6FunnelReportService, PerformanceReportService p6PerformanceReportService,
                                                     DrillDownService p6DrillDownService, ReportPdfRenderer pdf, JdbcTemplate jdbc,
                                                     AuditRecorder audit, BusinessClock p5BusinessClock, CandidateS6Properties s6) {
        return new ReportExportService(p6FunnelReportService, p6PerformanceReportService, p6DrillDownService, pdf, jdbc, audit,
                p5BusinessClock, s6.getReporting().getMaxExportRows(), s6.getReporting().getMaxPdfRows());
    }

    @Bean
    public ReportAccuracyService p6ReportAccuracyService(ReportSourcePort source, FactStore p6FactStore, FactCalculator p6FactCalculator,
                                                         CheckRunStore p6CheckRunStore, AuditRecorder audit, BusinessClock p5BusinessClock,
                                                         CandidateS6Properties s6) {
        CandidateS6Properties.Reporting r = s6.getReporting();
        return new ReportAccuracyService(source, p6FactStore, p6FactCalculator, p6CheckRunStore, audit, p5BusinessClock,
                new ReportAccuracyService.Settings(r.getAccuracyThreshold(), r.isAccuracyRepair(), r.getAccuracyBatch(), 50));
    }

    @Bean
    public AuditCompletenessService p6AuditCompletenessService(StageEventStore p6StageEventStore, JdbcTemplate jdbc, CheckRunStore p6CheckRunStore,
                                                               AuditRecorder audit, BusinessClock p5BusinessClock, CandidateP5Properties p5,
                                                               CandidateS6Properties s6) {
        return new AuditCompletenessService(p6StageEventStore, jdbc, p6CheckRunStore, audit, p5BusinessClock, p5.getAudit().getTable(),
                Duration.ofSeconds(s6.getReporting().getAuditMatchSeconds()), 500);
    }

    @Bean
    public ReportJobs p6ReportJobs(ScheduledJobRunner p5JobRunner, FactRebuildService p6FactRebuildService, ReportAccuracyService p6ReportAccuracyService,
                                   AuditCompletenessService p6AuditCompletenessService, ObjectProvider<IdempotencyStore> idempotency,
                                   BusinessClock p5BusinessClock, CandidateS6Properties s6) {
        return new ReportJobs(p5JobRunner, p6FactRebuildService, p6ReportAccuracyService, p6AuditCompletenessService,
                idempotency.getIfAvailable(), p5BusinessClock, s6.getReporting().getDirtyBatch());
    }
}
