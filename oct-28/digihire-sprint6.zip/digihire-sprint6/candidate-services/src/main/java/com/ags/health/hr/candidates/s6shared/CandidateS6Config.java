package com.ags.health.hr.candidates.s6shared;

import com.ags.health.hr.common.platform.db.SchemaInitializer;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import javax.sql.DataSource;
import java.util.List;

@Configuration
@EnableConfigurationProperties(CandidateS6Properties.class)
public class CandidateS6Config {

    public static final String SCHEMA = "db/p6/candidate-p6-schema.sql";

    @Bean(initMethod = "run")
    @ConditionalOnProperty(prefix = "digihire.s6", name = "schema-init", havingValue = "true", matchIfMissing = true)
    public SchemaInitializer p6SchemaInitializer(DataSource dataSource) {
        return new SchemaInitializer(dataSource, List.of(SCHEMA));
    }
}
