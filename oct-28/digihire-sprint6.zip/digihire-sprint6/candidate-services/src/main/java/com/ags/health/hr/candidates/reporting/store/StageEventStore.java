package com.ags.health.hr.candidates.reporting.store;

import com.ags.health.hr.candidates.reporting.domain.Where;
import org.springframework.jdbc.core.JdbcTemplate;

import java.sql.Date;
import java.sql.Timestamp;
import java.time.Instant;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.UUID;

public class StageEventStore {

    public static final String TABLE = "cand_p6_stage_event";

    public record Event(String applicationId, String fromStatus, String toStatus, String fromTab, String toTab, String reasonCode,
                        String actorId, boolean system, Instant at, LocalDate date) {
    }

    private final JdbcTemplate jdbc;

    public StageEventStore(JdbcTemplate jdbc) {
        this.jdbc = jdbc;
    }

    public void append(Event e) {
        jdbc.update("INSERT INTO " + TABLE + " (id, application_id, from_status, to_status, from_tab, to_tab, reason_code, actor_id, "
                        + "system_move, moved_at, moved_date) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)", UUID.randomUUID().toString(),
                e.applicationId(), e.fromStatus(), e.toStatus(), e.fromTab(), e.toTab(), e.reasonCode(), e.actorId(), e.system(),
                Timestamp.from(e.at()), Date.valueOf(e.date()));
    }

    public List<Map<String, Object>> movesByTab(Where factWhere, LocalDate date) {
        List<Object> args = new ArrayList<>(factWhere.argList());
        args.add(Date.valueOf(date));
        return jdbc.queryForList("SELECT e.to_tab AS grp, count(*) AS n FROM " + TABLE + " e JOIN " + FactStore.TABLE
                + " f ON f.application_id = e.application_id" + factWhere.sql() + " AND e.moved_date = ? AND e.system_move = FALSE "
                + "GROUP BY e.to_tab ORDER BY e.to_tab", args.toArray());
    }

    public List<Map<String, Object>> actionsByActor(Where factWhere, LocalDate from, LocalDate to) {
        List<Object> args = new ArrayList<>(factWhere.argList());
        args.add(Date.valueOf(from));
        args.add(Date.valueOf(to));
        return jdbc.queryForList("SELECT e.actor_id AS grp, count(*) AS n FROM " + TABLE + " e JOIN " + FactStore.TABLE
                + " f ON f.application_id = e.application_id" + factWhere.sql()
                + " AND e.moved_date >= ? AND e.moved_date <= ? AND e.system_move = FALSE GROUP BY e.actor_id", args.toArray());
    }

    public List<String> applicationIdsBetween(Instant from, Instant to, String afterId, int limit) {
        return jdbc.queryForList("SELECT DISTINCT application_id FROM " + TABLE + " WHERE moved_at >= ? AND moved_at < ? AND application_id > ? "
                + "ORDER BY application_id LIMIT ?", String.class, Timestamp.from(from), Timestamp.from(to), afterId == null ? "" : afterId, limit);
    }

    public List<Map<String, Object>> moves(Instant from, Instant to, String afterId, int limit) {
        return jdbc.queryForList("SELECT id, application_id, from_status, to_status, moved_at FROM " + TABLE + " WHERE moved_at >= ? "
                + "AND moved_at < ? AND from_status IS NOT NULL AND from_status <> to_status AND id > ? ORDER BY id LIMIT ?",
                Timestamp.from(from), Timestamp.from(to), afterId == null ? "" : afterId, limit);
    }

    public long count(Instant from, Instant to) {
        Long n = jdbc.queryForObject("SELECT count(*) FROM " + TABLE + " WHERE moved_at >= ? AND moved_at < ? AND from_status IS NOT NULL "
                + "AND from_status <> to_status", Long.class, Timestamp.from(from), Timestamp.from(to));
        return n == null ? 0 : n;
    }
}
