package com.ags.health.hr.candidates.reporting.service;

import com.ags.health.hr.common.platform.concurrency.IdempotencyStore;
import com.ags.health.hr.common.platform.jobs.ScheduledJobRunner;
import com.ags.health.hr.common.platform.time.BusinessClock;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.scheduling.annotation.Scheduled;

import java.time.Duration;
import java.time.LocalDate;

public class ReportJobs {

    private static final Logger log = LoggerFactory.getLogger(ReportJobs.class);

    private final ScheduledJobRunner runner;
    private final FactRebuildService rebuild;
    private final ReportAccuracyService accuracy;
    private final AuditCompletenessService auditCheck;
    private final IdempotencyStore idempotency;
    private final BusinessClock clock;
    private final int dirtyBatch;

    public ReportJobs(ScheduledJobRunner runner, FactRebuildService rebuild, ReportAccuracyService accuracy, AuditCompletenessService auditCheck,
                      IdempotencyStore idempotency, BusinessClock clock, int dirtyBatch) {
        this.runner = runner;
        this.rebuild = rebuild;
        this.accuracy = accuracy;
        this.auditCheck = auditCheck;
        this.idempotency = idempotency;
        this.clock = clock;
        this.dirtyBatch = dirtyBatch;
    }

    @Scheduled(cron = "${digihire.s6.reporting.dirty-cron:0 */5 * * * *}", zone = "Asia/Kolkata")
    public void repairDirty() {
        runner.run("p6-report-dirty", Duration.ofSeconds(30), () -> {
            int n = rebuild.repairDirty(dirtyBatch);
            if (n > 0) {
                log.info("REPORT_FACTS_REPAIRED count={}", n);
            }
        });
    }

    @Scheduled(cron = "${digihire.s6.reporting.accuracy-cron:0 40 1 * * *}", zone = "Asia/Kolkata")
    public void nightlyAccuracy() {
        runner.run("p6-report-accuracy", Duration.ofMinutes(5), () -> {
            LocalDate yesterday = clock.today().minusDays(1);
            accuracy.check("system", yesterday.minusDays(1), yesterday, true);
        });
    }

    @Scheduled(cron = "${digihire.s6.reporting.audit-check-cron:0 10 2 * * *}", zone = "Asia/Kolkata")
    public void nightlyAuditCheck() {
        runner.run("p6-audit-completeness", Duration.ofMinutes(5), () -> {
            LocalDate yesterday = clock.today().minusDays(1);
            auditCheck.check("system", yesterday, yesterday);
        });
    }

    @Scheduled(cron = "0 17 * * * *", zone = "Asia/Kolkata")
    public void purgeIdempotency() {
        if (idempotency != null) {
            runner.run("p6-idempotency-purge", Duration.ofMinutes(1), idempotency::purgeExpired);
        }
    }
}
