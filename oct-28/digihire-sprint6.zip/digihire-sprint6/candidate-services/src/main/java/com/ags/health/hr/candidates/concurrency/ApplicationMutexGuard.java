package com.ags.health.hr.candidates.concurrency;

import com.ags.health.hr.candidates.shared.port.ApplicationPort;
import com.ags.health.hr.candidates.shared.port.ApplicationView;
import com.ags.health.hr.candidates.shared.service.MoveGuard;
import com.ags.health.hr.candidates.shared.service.StatusMover;
import com.ags.health.hr.common.platform.caller.Caller;
import com.ags.health.hr.common.platform.error.PlatformException;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.transaction.support.TransactionSynchronizationManager;

import java.sql.Timestamp;
import java.time.Clock;
import java.util.List;
import java.util.Map;

public class ApplicationMutexGuard implements MoveGuard {

    private final ApplicationPort applications;
    private final JdbcTemplate jdbc;
    private final Clock clock;
    private final boolean staleCheck;
    private final boolean rowLock;

    public ApplicationMutexGuard(ApplicationPort applications, JdbcTemplate jdbc, Clock clock, boolean staleCheck, boolean rowLock) {
        this.applications = applications;
        this.jdbc = jdbc;
        this.clock = clock;
        this.staleCheck = staleCheck;
        this.rowLock = rowLock;
    }

    @Override
    public void check(Caller caller, ApplicationView application, String toStatus, StatusMover.Move move) {
        if (rowLock && TransactionSynchronizationManager.isActualTransactionActive()) {
            lock(application.id());
        }
        if (!staleCheck) {
            return;
        }
        String current = applications.find(application.id()).map(ApplicationView::status).orElse(null);
        if (current != null && application.status() != null && !current.equalsIgnoreCase(application.status())) {
            throw new PlatformException(409, "STALE_STATUS", "Application " + application.id() + " is now " + current
                    + "; refresh and try again", List.of(Map.of("expected", application.status(), "current", current)));
        }
    }

    public void lock(String applicationId) {
        List<String> rows = jdbc.queryForList("SELECT application_id FROM cand_p6_app_mutex WHERE application_id = ? FOR UPDATE",
                String.class, applicationId);
        if (rows.isEmpty()) {
            try {
                jdbc.update("INSERT INTO cand_p6_app_mutex (application_id, touched_at) VALUES (?, ?)", applicationId,
                        Timestamp.from(clock.instant()));
            } catch (DuplicateKeyException e) {
                jdbc.queryForList("SELECT application_id FROM cand_p6_app_mutex WHERE application_id = ? FOR UPDATE", String.class,
                        applicationId);
            }
        }
    }
}
