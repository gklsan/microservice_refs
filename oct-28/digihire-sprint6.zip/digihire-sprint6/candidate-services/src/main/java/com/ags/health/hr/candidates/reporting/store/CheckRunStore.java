package com.ags.health.hr.candidates.reporting.store;

import com.ags.health.hr.candidates.reporting.domain.CheckRun;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

import java.math.BigDecimal;
import java.sql.Date;
import java.sql.Timestamp;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

public class CheckRunStore {

    private static final RowMapper<CheckRun> ROW = (rs, i) -> new CheckRun(rs.getString(1), rs.getString(2), rs.getDate(3).toLocalDate(),
            rs.getDate(4).toLocalDate(), rs.getInt(5), rs.getInt(6), rs.getInt(7), rs.getInt(8), rs.getInt(9),
            rs.getBigDecimal(10) == null ? 0 : rs.getBigDecimal(10).doubleValue(), rs.getBigDecimal(11) == null ? 0 : rs.getBigDecimal(11).doubleValue(),
            rs.getString(12), rs.getString(13) == null || rs.getString(13).isEmpty() ? List.of() : Arrays.asList(rs.getString(13).split("\n")),
            rs.getTimestamp(14).toInstant(), rs.getTimestamp(15) == null ? null : rs.getTimestamp(15).toInstant());

    private final JdbcTemplate jdbc;

    public CheckRunStore(JdbcTemplate jdbc) {
        this.jdbc = jdbc;
    }

    public void save(CheckRun r, String triggeredBy) {
        String sample = String.join("\n", r.sample());
        if (sample.length() > 3900) {
            sample = sample.substring(0, 3900);
        }
        jdbc.update("INSERT INTO cand_p6_check_run (id, kind, from_date, to_date, checked, matched, mismatched, missing, repaired, score, "
                        + "threshold, status, sample, triggered_by, started_at, finished_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
                r.id(), r.kind(), Date.valueOf(r.from()), Date.valueOf(r.to()), r.checked(), r.matched(), r.mismatched(), r.missing(),
                r.repaired(), BigDecimal.valueOf(r.score()).setScale(4, java.math.RoundingMode.HALF_UP),
                BigDecimal.valueOf(r.threshold()).setScale(4, java.math.RoundingMode.HALF_UP), r.status(), sample, triggeredBy,
                Timestamp.from(r.startedAt()), r.finishedAt() == null ? null : Timestamp.from(r.finishedAt()));
    }

    public List<CheckRun> recent(String kind, int limit) {
        return jdbc.query("SELECT id, kind, from_date, to_date, checked, matched, mismatched, missing, repaired, score, threshold, status, "
                + "sample, started_at, finished_at FROM cand_p6_check_run WHERE kind = ? ORDER BY started_at DESC LIMIT ?", ROW, kind, limit);
    }

    public Optional<CheckRun> latest(String kind) {
        return recent(kind, 1).stream().findFirst();
    }
}
