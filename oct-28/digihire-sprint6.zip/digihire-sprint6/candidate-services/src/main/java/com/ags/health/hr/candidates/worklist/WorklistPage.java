package com.ags.health.hr.candidates.worklist;

import com.ags.health.hr.candidates.reporting.domain.DrillRow;

import java.util.List;

public record WorklistPage(List<DrillRow> items, String nextCursor, Long count, boolean countCapped) {

    public WorklistPage {
        items = List.copyOf(items);
    }
}
