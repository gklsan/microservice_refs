package com.ags.health.hr.candidates.worklist;

import com.ags.health.hr.candidates.mapping.service.MappingService;
import com.ags.health.hr.candidates.reporting.domain.ReportFilter;
import com.ags.health.hr.common.platform.caller.CallerProvider;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@ConditionalOnProperty(prefix = "digihire.s6.worklist", name = "enabled", havingValue = "true", matchIfMissing = true)
@RestController
public class WorklistController {

    public record BatchAssessRequest(List<MappingService.AssessRequest> items) {
    }

    private final WorklistService worklist;
    private final MapCandidateBatchService batch;
    private final CallerProvider callers;

    public WorklistController(WorklistService worklist, MapCandidateBatchService batch, CallerProvider callers) {
        this.worklist = worklist;
        this.batch = batch;
        this.callers = callers;
    }

    @GetMapping("/worklist/applicants")
    public WorklistPage applicants(@RequestParam(required = false) String tab, @RequestParam(required = false) String status,
                                   @RequestParam(required = false) String lob, @RequestParam(required = false) String location,
                                   @RequestParam(required = false) String recruiter, @RequestParam(required = false) String requisition,
                                   @RequestParam(required = false) String q, @RequestParam(required = false) String sort,
                                   @RequestParam(required = false) String cursor, @RequestParam(defaultValue = "25") int size,
                                   @RequestParam(defaultValue = "false") boolean count) {
        return worklist.page(callers.require(), new WorklistQuery(tab, ReportFilter.split(status), ReportFilter.split(lob),
                ReportFilter.split(location), ReportFilter.split(recruiter), ReportFilter.split(requisition), q, sort, cursor, size, count));
    }

    @PostMapping("/mapping/assess/batch")
    public List<MapCandidateBatchService.Item> assess(@RequestBody BatchAssessRequest body) {
        return batch.assess(callers.require(), body.items());
    }
}
