package com.ags.health.hr.candidates.reporting.domain;

import com.ags.health.hr.candidates.shared.domain.Statuses;
import com.ags.health.hr.candidates.shared.domain.Tab;

import java.util.List;

public enum FunnelStage {
    APPLIED("applied_at"),
    HR_ROUND("hr_round_at"),
    ASSESSMENT("assessment_at"),
    VERSANT("versant_at"),
    PANEL("panel_at"),
    SELECTED("selected_at"),
    OFFERED("offered_at"),
    JOINED("joined_at");

    private final String column;

    FunnelStage(String column) {
        this.column = column;
    }

    public String column() {
        return column;
    }

    public List<FunnelStage> fromHere() {
        return List.of(values()).subList(ordinal(), values().length);
    }

    public String reachedSql() {
        if (this == APPLIED) {
            return "applied_at IS NOT NULL";
        }
        StringBuilder sb = new StringBuilder("COALESCE(");
        List<FunnelStage> later = fromHere();
        for (int i = 0; i < later.size(); i++) {
            if (i > 0) {
                sb.append(", ");
            }
            sb.append(later.get(i).column());
        }
        return sb.append(") IS NOT NULL").toString();
    }

    public static FunnelStage of(String status, Tab tab) {
        if (status == null || tab == null) {
            return null;
        }
        if (Statuses.JOINED.equals(status)) {
            return JOINED;
        }
        if (Statuses.OFFERED.equals(status)) {
            return OFFERED;
        }
        if (Statuses.PANEL_SELECTED.equals(status) || Statuses.SHORTLISTED.equals(status)) {
            return SELECTED;
        }
        return switch (tab) {
            case HR_INTERVIEW -> HR_ROUND;
            case ASSESSMENT -> ASSESSMENT;
            case VERSANT -> VERSANT;
            case PANEL -> PANEL;
            case APPLICANT, MAP_CANDIDATE, PIPELINE -> APPLIED;
            default -> null;
        };
    }

    public static FunnelStage parse(String v) {
        try {
            return valueOf(v.trim().toUpperCase(java.util.Locale.ROOT));
        } catch (RuntimeException e) {
            throw new IllegalArgumentException("Unknown funnel stage " + v);
        }
    }
}
