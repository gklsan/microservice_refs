CREATE TABLE IF NOT EXISTS cand_p6_app_fact (
    application_id   VARCHAR(64)   PRIMARY KEY,
    candidate_id     VARCHAR(64),
    candidate_name   VARCHAR(200),
    requisition_id   VARCHAR(64),
    job_id           VARCHAR(64),
    lob              VARCHAR(100),
    location         VARCHAR(100),
    role_code        VARCHAR(100),
    orc_id           VARCHAR(64),
    source           VARCHAR(30),
    vendor_id        VARCHAR(64),
    hr_user_id       VARCHAR(64),
    status           VARCHAR(40)   NOT NULL,
    tab              VARCHAR(20)   NOT NULL,
    applied_at       TIMESTAMP WITH TIME ZONE NOT NULL,
    applied_date     DATE          NOT NULL,
    hr_round_at      TIMESTAMP WITH TIME ZONE,
    assessment_at    TIMESTAMP WITH TIME ZONE,
    versant_at       TIMESTAMP WITH TIME ZONE,
    panel_at         TIMESTAMP WITH TIME ZONE,
    selected_at      TIMESTAMP WITH TIME ZONE,
    offered_at       TIMESTAMP WITH TIME ZONE,
    joined_at        TIMESTAMP WITH TIME ZONE,
    rejected_at      TIMESTAMP WITH TIME ZONE,
    rejected_stage   VARCHAR(20),
    status_since     TIMESTAMP WITH TIME ZONE NOT NULL,
    updated_at       TIMESTAMP WITH TIME ZONE NOT NULL,
    version          INT           NOT NULL DEFAULT 0
)@@
CREATE INDEX IF NOT EXISTS ix_cand_p6_fact_applied ON cand_p6_app_fact (applied_date)@@
CREATE INDEX IF NOT EXISTS ix_cand_p6_fact_hr ON cand_p6_app_fact (hr_user_id, applied_date)@@
CREATE INDEX IF NOT EXISTS ix_cand_p6_fact_lob ON cand_p6_app_fact (lob, location, applied_date)@@
CREATE INDEX IF NOT EXISTS ix_cand_p6_fact_vendor ON cand_p6_app_fact (vendor_id, applied_date)@@
CREATE INDEX IF NOT EXISTS ix_cand_p6_fact_tab ON cand_p6_app_fact (tab, status_since, application_id)@@
CREATE INDEX IF NOT EXISTS ix_cand_p6_fact_req ON cand_p6_app_fact (requisition_id)@@
CREATE INDEX IF NOT EXISTS ix_cand_p6_fact_candidate ON cand_p6_app_fact (candidate_id)@@

CREATE TABLE IF NOT EXISTS cand_p6_stage_event (
    id               VARCHAR(36)   PRIMARY KEY,
    application_id   VARCHAR(64)   NOT NULL,
    from_status      VARCHAR(40),
    to_status        VARCHAR(40)   NOT NULL,
    from_tab         VARCHAR(20),
    to_tab           VARCHAR(20)   NOT NULL,
    reason_code      VARCHAR(60),
    actor_id         VARCHAR(64),
    system_move      BOOLEAN       NOT NULL DEFAULT FALSE,
    moved_at         TIMESTAMP WITH TIME ZONE NOT NULL,
    moved_date       DATE          NOT NULL
)@@
CREATE INDEX IF NOT EXISTS ix_cand_p6_event_date ON cand_p6_stage_event (moved_date, to_tab)@@
CREATE INDEX IF NOT EXISTS ix_cand_p6_event_app ON cand_p6_stage_event (application_id, moved_at)@@
CREATE INDEX IF NOT EXISTS ix_cand_p6_event_actor ON cand_p6_stage_event (actor_id, moved_date)@@

CREATE TABLE IF NOT EXISTS cand_p6_fact_dirty (
    application_id   VARCHAR(64)   PRIMARY KEY,
    reason           VARCHAR(300),
    marked_at        TIMESTAMP WITH TIME ZONE NOT NULL,
    attempts         INT           NOT NULL DEFAULT 0
)@@

CREATE TABLE IF NOT EXISTS cand_p6_check_run (
    id               VARCHAR(36)   PRIMARY KEY,
    kind             VARCHAR(30)   NOT NULL,
    from_date        DATE          NOT NULL,
    to_date          DATE          NOT NULL,
    checked          INT           NOT NULL DEFAULT 0,
    matched          INT           NOT NULL DEFAULT 0,
    mismatched       INT           NOT NULL DEFAULT 0,
    missing          INT           NOT NULL DEFAULT 0,
    repaired         INT           NOT NULL DEFAULT 0,
    score            NUMERIC(7,4),
    threshold        NUMERIC(7,4),
    status           VARCHAR(10)   NOT NULL,
    sample           VARCHAR(4000),
    triggered_by     VARCHAR(64),
    started_at       TIMESTAMP WITH TIME ZONE NOT NULL,
    finished_at      TIMESTAMP WITH TIME ZONE
)@@
CREATE INDEX IF NOT EXISTS ix_cand_p6_check_kind ON cand_p6_check_run (kind, started_at)@@

CREATE TABLE IF NOT EXISTS cand_p6_export_log (
    id               VARCHAR(36)   PRIMARY KEY,
    report           VARCHAR(40)   NOT NULL,
    format           VARCHAR(10)   NOT NULL,
    row_count        INT           NOT NULL,
    filters          VARCHAR(2000),
    requested_by     VARCHAR(64)   NOT NULL,
    requested_at     TIMESTAMP WITH TIME ZONE NOT NULL
)@@
CREATE INDEX IF NOT EXISTS ix_cand_p6_export_at ON cand_p6_export_log (requested_at)@@

CREATE TABLE IF NOT EXISTS cand_p6_app_mutex (
    application_id   VARCHAR(64)   PRIMARY KEY,
    touched_at       TIMESTAMP WITH TIME ZONE NOT NULL
)@@

CREATE TABLE IF NOT EXISTS cand_p6_idempotency (
    idem_key         VARCHAR(64)   PRIMARY KEY,
    request_hash     VARCHAR(64)   NOT NULL,
    state            VARCHAR(12)   NOT NULL,
    status_code      INT,
    content_type     VARCHAR(100),
    body             TEXT,
    created_at       TIMESTAMP WITH TIME ZONE NOT NULL,
    expires_at       TIMESTAMP WITH TIME ZONE NOT NULL
)@@
CREATE INDEX IF NOT EXISTS ix_cand_p6_idem_expires ON cand_p6_idempotency (expires_at)@@
