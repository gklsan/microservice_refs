package com.ags.health.hr.common.platform.sprint6;

import com.ags.health.hr.common.platform.cache.TtlCache;
import com.ags.health.hr.common.platform.concurrency.IdempotencyStore;
import com.ags.health.hr.common.platform.concurrency.IdempotentExecutor;
import com.ags.health.hr.common.platform.error.PlatformException;
import com.ags.health.hr.common.platform.export.CsvReportWriter;
import com.ags.health.hr.common.platform.export.ReportTable;
import com.ags.health.hr.common.platform.export.XlsxReportWriter;
import com.ags.health.hr.common.platform.export.XlsxSheetReader;
import com.ags.health.hr.common.platform.readiness.Checks;
import com.ags.health.hr.common.platform.readiness.ReadinessReport;
import com.ags.health.hr.common.platform.readiness.ReadinessResult;
import com.ags.health.hr.common.platform.readiness.ReadinessService;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.Test;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.datasource.DriverManagerDataSource;

import java.io.ByteArrayOutputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.Clock;
import java.time.Duration;
import java.time.Instant;
import java.time.LocalDate;
import java.time.ZoneId;
import java.time.ZoneOffset;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.atomic.AtomicInteger;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

class PlatformSprint6Test {

    private static final ZoneId IST = ZoneId.of("Asia/Kolkata");

    private static ReportTable table() {
        List<ReportTable.Column> cols = List.of(ReportTable.Column.text("name", "Name", 20), ReportTable.Column.integer("n", "Count"),
                ReportTable.Column.percent("p", "Share"), ReportTable.Column.date("d", "Applied"),
                ReportTable.Column.dateTime("t", "Since"), ReportTable.Column.decimal("x", "Avg days"));
        return new ReportTable("Recruiter / performance: Oct", cols, List.of(
                Arrays.asList("Asha <&> \"Q\"", 12, 0.25, LocalDate.of(2026, 10, 20), Instant.parse("2026-10-20T05:30:00Z"), 2.5),
                Arrays.asList("=SUM(A1:A2)", 0, null, null, null, null),
                Arrays.asList("Ravi\nKumar", 3L, 1.0, LocalDate.of(2026, 1, 1), Instant.parse("2026-01-01T00:00:00Z"), 10)),
                Map.of("From", "2026-10-01", "To", "2026-10-31"));
    }

    @Test
    void xlsxWriterOutputReadsBackWithTypesAndInjectionGuard() throws Exception {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        new XlsxReportWriter(IST).write(table(), out);
        String target = System.getProperty("p6.xlsx.out");
        if (target != null) {
            Files.write(Path.of(target), out.toByteArray());
        }
        List<List<String>> rows = new XlsxSheetReader(5_000_000, 100).firstSheet(out.toByteArray());
        assertThat(rows.get(0)).containsExactly("Name", "Count", "Share", "Applied", "Since", "Avg days");
        assertThat(rows.get(1).get(0)).isEqualTo("Asha <&> \"Q\"");
        assertThat(rows.get(1).get(1)).isEqualTo("12");
        assertThat(rows.get(1).get(2)).isEqualTo("0.25");
        assertThat(XlsxSheetReader.dateFromSerial(rows.get(1).get(3))).isEqualTo(LocalDate.of(2026, 10, 20));
        assertThat(rows.get(2).get(0)).isEqualTo("'=SUM(A1:A2)");
        assertThat(rows.get(3).get(0)).isEqualTo("Ravi\nKumar");
        assertThat(XlsxReportWriter.ref(27, 3)).isEqualTo("AB3");
    }

    @Test
    void xlsxReaderRefusesZipBombsAndNonWorkbooks() throws Exception {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        new XlsxReportWriter(IST).write(table(), out);
        assertThatThrownBy(() -> new XlsxSheetReader(200, 100).firstSheet(out.toByteArray())).hasMessageContaining("larger than");
        assertThatThrownBy(() -> new XlsxSheetReader(5_000_000, 2).firstSheet(out.toByteArray())).hasMessageContaining("more than 2 rows");
        assertThatThrownBy(() -> new XlsxSheetReader(5_000_000, 100).firstSheet("not a zip".getBytes())).hasMessageContaining("xlsx");
    }

    @Test
    void csvIsQuotedAndSafe() throws Exception {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        new CsvReportWriter(IST).write(table(), out);
        String csv = new String(out.toByteArray(), StandardCharsets.UTF_8);
        assertThat(csv).startsWith("﻿Name,Count,Share,Applied,Since,Avg days\r\n");
        assertThat(csv).contains("\"Asha <&> \"\"Q\"\"\",12,25.00%,2026-10-20,2026-10-20 11:00:00,2.5");
        assertThat(csv).contains("'=SUM(A1:A2),0,,,,");
        assertThat(csv).contains("\"Ravi\nKumar\"");
    }

    @Test
    void ttlCacheLoadsOncePerKeyUntilExpiry() {
        AtomicInteger loads = new AtomicInteger();
        Instant[] now = {Instant.parse("2026-10-20T00:00:00Z")};
        Clock clock = new Clock() {
            public ZoneId getZone() {
                return ZoneOffset.UTC;
            }

            public Clock withZone(ZoneId z) {
                return this;
            }

            public Instant instant() {
                return now[0];
            }
        };
        TtlCache<String, Integer> c = new TtlCache<>(Duration.ofSeconds(60), 10, clock);
        assertThat(c.get("a", loads::incrementAndGet)).isEqualTo(1);
        assertThat(c.get("a", loads::incrementAndGet)).isEqualTo(1);
        now[0] = now[0].plusSeconds(61);
        assertThat(c.get("a", loads::incrementAndGet)).isEqualTo(2);
        assertThatThrownBy(() -> c.get("b", () -> {
            throw new IllegalStateException("boom");
        })).hasMessage("boom");
        assertThat(c.get("b", () -> 7)).isEqualTo(7);
        assertThat(c.stats().hits()).isEqualTo(1);
    }

    @Test
    void idempotencyReplaysRefusesReuseAndReleasesFailures() {
        DriverManagerDataSource ds = new DriverManagerDataSource("jdbc:h2:mem:idem" + UUID.randomUUID() + ";DB_CLOSE_DELAY=-1", "sa", "");
        JdbcTemplate jdbc = new JdbcTemplate(ds);
        jdbc.execute("CREATE TABLE t_idem (idem_key VARCHAR(64) PRIMARY KEY, request_hash VARCHAR(64) NOT NULL, state VARCHAR(12) NOT NULL, "
                + "status_code INT, content_type VARCHAR(100), body TEXT, created_at TIMESTAMP WITH TIME ZONE NOT NULL, "
                + "expires_at TIMESTAMP WITH TIME ZONE NOT NULL)");
        Clock clock = Clock.fixed(Instant.parse("2026-10-20T00:00:00Z"), ZoneOffset.UTC);
        IdempotencyStore store = new IdempotencyStore(jdbc, clock, "t_idem", Duration.ofHours(24), Duration.ofSeconds(120));
        IdempotentExecutor exec = new IdempotentExecutor(store, new ObjectMapper());
        AtomicInteger runs = new AtomicInteger();
        Map<String, Object> req = Map.of("applicationId", "A1", "to", "PIPELINE");
        Map<?, ?> first = exec.run("u1", "key-000001", "/mapping/map", req, Map.class, () -> Map.of("n", runs.incrementAndGet()));
        Map<?, ?> again = exec.run("u1", "key-000001", "/mapping/map", req, Map.class, () -> Map.of("n", runs.incrementAndGet()));
        assertThat(first.get("n")).isEqualTo(1);
        assertThat(again.get("n")).isEqualTo(1);
        assertThat(runs.get()).isEqualTo(1);
        assertThatThrownBy(() -> exec.run("u1", "key-000001", "/mapping/map", Map.of("other", 1), Map.class, () -> Map.of()))
                .isInstanceOf(PlatformException.class).hasMessageContaining("different request");
        assertThat(exec.run("u2", "key-000001", "/mapping/map", req, Map.class, () -> Map.of("n", 9)).get("n")).isEqualTo(9);
        assertThatThrownBy(() -> exec.run("u1", "key-000002", "/x", req, Map.class, () -> {
            throw PlatformException.conflict("NOPE", "nope");
        })).hasMessage("nope");
        assertThat(store.state("u1", "key-000002")).isEmpty();
        assertThat(store.claim("u1", "key-000003", "POST", "/x", new byte[0])).isInstanceOf(IdempotencyStore.Claim.Fresh.class);
        assertThat(store.claim("u1", "key-000003", "POST", "/x", new byte[0])).isInstanceOf(IdempotencyStore.Claim.InFlight.class);
        assertThatThrownBy(() -> store.claim("u1", "short", "POST", "/x", new byte[0])).hasMessageContaining("Idempotency-Key");
    }

    @Test
    void readinessAggregatesAndTimesOutSlowChecks() {
        ReadinessService svc = new ReadinessService("svc", "uat", List.of(
                Checks.of("ok", "a", () -> ReadinessResult.pass("fine")),
                Checks.setting("secret", "security", "", false, "SECRET"),
                Checks.backlog("queue", "b", () -> 60L, 10, 50),
                Checks.notStub("oracle", "integration", "STUB", true),
                Checks.of("slow", "c", () -> {
                    try {
                        Thread.sleep(3000);
                    } catch (InterruptedException e) {
                        Thread.currentThread().interrupt();
                    }
                    return ReadinessResult.pass("late");
                })), Duration.ofMillis(300), Clock.systemUTC());
        ReadinessReport r = svc.run();
        assertThat(r.overall()).isEqualTo(ReadinessResult.Status.FAIL);
        assertThat(r.passed()).isEqualTo(1);
        assertThat(r.warnings()).isEqualTo(1);
        assertThat(r.failures()).isEqualTo(3);
        assertThat(r.checks().get(4).message()).contains("did not finish");
    }
}
