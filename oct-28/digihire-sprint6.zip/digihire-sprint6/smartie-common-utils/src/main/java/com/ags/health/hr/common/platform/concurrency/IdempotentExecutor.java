package com.ags.health.hr.common.platform.concurrency;

import com.ags.health.hr.common.platform.error.PlatformException;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JavaType;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.function.Supplier;

public class IdempotentExecutor {

    public static final String HEADER = "Idempotency-Key";

    private final IdempotencyStore store;
    private final ObjectMapper mapper;

    public IdempotentExecutor(IdempotencyStore store, ObjectMapper mapper) {
        this.store = store;
        this.mapper = mapper;
    }

    public <T> T run(String actor, String key, String operation, Object request, Class<T> type, Supplier<T> work) {
        return run(actor, key, operation, request, mapper.getTypeFactory().constructType(type), work);
    }

    public <T> T run(String actor, String key, String operation, Object request, JavaType type, Supplier<T> work) {
        if (key == null || key.isBlank()) {
            return work.get();
        }
        byte[] body;
        try {
            body = mapper.writeValueAsBytes(request);
        } catch (JsonProcessingException e) {
            throw new IllegalArgumentException("Request could not be serialised for idempotency", e);
        }
        IdempotencyStore.Claim claim = store.claim(actor, key.trim(), "POST", operation, body);
        if (claim instanceof IdempotencyStore.Claim.Replay replay) {
            try {
                return mapper.readValue(replay.response().body(), type);
            } catch (IOException e) {
                throw new IllegalStateException("Stored response could not be read", e);
            }
        }
        if (claim instanceof IdempotencyStore.Claim.InFlight) {
            throw PlatformException.conflict("REQUEST_IN_PROGRESS", "The same request is still being processed; retry shortly");
        }
        String scoped = ((IdempotencyStore.Claim.Fresh) claim).key();
        T result;
        try {
            result = work.get();
        } catch (RuntimeException e) {
            store.release(scoped);
            throw e;
        }
        try {
            store.complete(scoped, 200, "application/json", mapper.writeValueAsString(result).getBytes(StandardCharsets.UTF_8));
        } catch (JsonProcessingException e) {
            store.release(scoped);
        }
        return result;
    }
}
