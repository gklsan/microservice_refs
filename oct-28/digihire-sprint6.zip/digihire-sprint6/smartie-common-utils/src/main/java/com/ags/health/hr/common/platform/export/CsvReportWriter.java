package com.ags.health.hr.common.platform.export;

import java.io.IOException;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.nio.charset.StandardCharsets;
import java.time.Instant;
import java.time.LocalDate;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;

public class CsvReportWriter {

    private static final DateTimeFormatter DATE = DateTimeFormatter.ISO_LOCAL_DATE;
    private static final DateTimeFormatter DATE_TIME = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

    private final ZoneId zone;

    public CsvReportWriter(ZoneId zone) {
        this.zone = zone;
    }

    public void write(ReportTable table, OutputStream out) throws IOException {
        Writer w = new OutputStreamWriter(out, StandardCharsets.UTF_8);
        w.write('﻿');
        for (int i = 0; i < table.columns().size(); i++) {
            if (i > 0) {
                w.write(',');
            }
            w.write(quote(CellSafety.text(table.columns().get(i).header())));
        }
        w.write("\r\n");
        for (var row : table.rows()) {
            for (int i = 0; i < row.size(); i++) {
                if (i > 0) {
                    w.write(',');
                }
                w.write(quote(format(table.columns().get(i).kind(), row.get(i))));
            }
            w.write("\r\n");
        }
        w.flush();
    }

    String format(ReportTable.Kind kind, Object v) {
        if (v == null) {
            return "";
        }
        return switch (kind) {
            case DATE -> v instanceof LocalDate d ? DATE.format(d) : v instanceof Instant i ? DATE.format(i.atZone(zone)) : CellSafety.text(v);
            case DATETIME -> v instanceof Instant i ? DATE_TIME.format(i.atZone(zone)) : CellSafety.text(v);
            case PERCENT -> v instanceof Number n ? BigDecimal.valueOf(n.doubleValue() * 100).setScale(2, RoundingMode.HALF_UP).toPlainString() + "%"
                    : CellSafety.text(v);
            case INTEGER, DECIMAL -> v instanceof Number ? String.valueOf(v) : CellSafety.text(v);
            default -> CellSafety.text(v);
        };
    }

    static String quote(String s) {
        if (s.indexOf(',') >= 0 || s.indexOf('"') >= 0 || s.indexOf('\n') >= 0 || s.indexOf('\r') >= 0) {
            return '"' + s.replace("\"", "\"\"") + '"';
        }
        return s;
    }
}
