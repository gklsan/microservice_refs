package com.ags.health.hr.common.platform.cache;

import java.time.Clock;
import java.time.Duration;
import java.time.Instant;
import java.util.Iterator;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.atomic.AtomicLong;
import java.util.function.Supplier;

public class TtlCache<K, V> {

    public record Stats(long hits, long misses, long loads, int size) {
    }

    private record Entry<V>(CompletableFuture<V> value, Instant expires) {
    }

    private final Map<K, Entry<V>> entries = new ConcurrentHashMap<>();
    private final Duration ttl;
    private final int maxEntries;
    private final Clock clock;
    private final AtomicLong hits = new AtomicLong();
    private final AtomicLong misses = new AtomicLong();
    private final AtomicLong loads = new AtomicLong();

    public TtlCache(Duration ttl, int maxEntries, Clock clock) {
        this.ttl = ttl;
        this.maxEntries = Math.max(1, maxEntries);
        this.clock = clock;
    }

    public V get(K key, Supplier<V> loader) {
        if (ttl.isZero() || ttl.isNegative()) {
            loads.incrementAndGet();
            return loader.get();
        }
        Instant now = clock.instant();
        Entry<V> existing = entries.get(key);
        if (existing != null && existing.expires().isAfter(now)) {
            hits.incrementAndGet();
            return join(key, existing);
        }
        misses.incrementAndGet();
        CompletableFuture<V> mine = new CompletableFuture<>();
        Entry<V> fresh = new Entry<>(mine, now.plus(ttl));
        Entry<V> winner = entries.compute(key, (k, cur) -> cur != null && cur.expires().isAfter(now) ? cur : fresh);
        if (winner != fresh) {
            return join(key, winner);
        }
        if (entries.size() > maxEntries) {
            evict(now);
        }
        try {
            loads.incrementAndGet();
            V v = loader.get();
            mine.complete(v);
            return v;
        } catch (RuntimeException e) {
            entries.remove(key, fresh);
            mine.completeExceptionally(e);
            throw e;
        }
    }

    public void invalidate(K key) {
        entries.remove(key);
    }

    public void clear() {
        entries.clear();
    }

    public Stats stats() {
        return new Stats(hits.get(), misses.get(), loads.get(), entries.size());
    }

    private V join(K key, Entry<V> e) {
        try {
            return e.value().get();
        } catch (InterruptedException ex) {
            Thread.currentThread().interrupt();
            throw new IllegalStateException("Interrupted while waiting for " + key, ex);
        } catch (ExecutionException ex) {
            if (ex.getCause() instanceof RuntimeException re) {
                throw re;
            }
            throw new IllegalStateException(ex.getCause());
        }
    }

    private void evict(Instant now) {
        Iterator<Map.Entry<K, Entry<V>>> it = entries.entrySet().iterator();
        while (it.hasNext()) {
            if (!it.next().getValue().expires().isAfter(now)) {
                it.remove();
            }
        }
        it = entries.entrySet().iterator();
        while (entries.size() > maxEntries && it.hasNext()) {
            Map.Entry<K, Entry<V>> e = it.next();
            if (e.getValue().value().isDone()) {
                it.remove();
            }
        }
    }
}
