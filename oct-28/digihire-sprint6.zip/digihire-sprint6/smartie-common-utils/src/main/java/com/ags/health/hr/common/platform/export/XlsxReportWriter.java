package com.ags.health.hr.common.platform.export;

import java.io.IOException;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.nio.charset.StandardCharsets;
import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.temporal.ChronoUnit;
import java.util.Map;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

public class XlsxReportWriter {

    public static final int MAX_ROWS = 1_048_000;
    private static final LocalDateTime EPOCH = LocalDateTime.of(1899, 12, 30, 0, 0);
    private static final int STYLE_HEADER = 1;
    private static final int STYLE_DATE = 2;
    private static final int STYLE_DATETIME = 3;
    private static final int STYLE_PERCENT = 4;
    private static final int STYLE_INTEGER = 5;
    private static final int STYLE_DECIMAL = 6;

    private final ZoneId zone;

    public XlsxReportWriter(ZoneId zone) {
        this.zone = zone;
    }

    public void write(ReportTable table, OutputStream out) throws IOException {
        if (table.rows().size() > MAX_ROWS) {
            throw new IllegalArgumentException("Too many rows for one sheet: " + table.rows().size());
        }
        ZipOutputStream zip = new ZipOutputStream(out, StandardCharsets.UTF_8);
        boolean filters = !table.filters().isEmpty();
        entry(zip, "[Content_Types].xml", contentTypes(filters));
        entry(zip, "_rels/.rels", "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>"
                + "<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">"
                + "<Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument\" Target=\"xl/workbook.xml\"/>"
                + "</Relationships>");
        entry(zip, "xl/workbook.xml", workbook(sheetName(table.title()), filters));
        entry(zip, "xl/_rels/workbook.xml.rels", workbookRels(filters));
        entry(zip, "xl/styles.xml", styles());
        zip.putNextEntry(new ZipEntry("xl/worksheets/sheet1.xml"));
        Writer w = new OutputStreamWriter(zip, StandardCharsets.UTF_8);
        sheet(table, w);
        w.flush();
        zip.closeEntry();
        if (filters) {
            zip.putNextEntry(new ZipEntry("xl/worksheets/sheet2.xml"));
            Writer f = new OutputStreamWriter(zip, StandardCharsets.UTF_8);
            filterSheet(table.filters(), f);
            f.flush();
            zip.closeEntry();
        }
        zip.finish();
    }

    private void sheet(ReportTable table, Writer w) throws IOException {
        int cols = table.columns().size();
        int lastRow = table.rows().size() + 1;
        w.write("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>");
        w.write("<worksheet xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\" "
                + "xmlns:r=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships\">");
        w.write("<sheetViews><sheetView workbookViewId=\"0\"><pane ySplit=\"1\" topLeftCell=\"A2\" activePane=\"bottomLeft\" state=\"frozen\"/>"
                + "</sheetView></sheetViews><sheetFormatPr defaultRowHeight=\"15\"/><cols>");
        for (int i = 0; i < cols; i++) {
            int width = Math.max(8, Math.min(80, table.columns().get(i).width()));
            w.write("<col min=\"" + (i + 1) + "\" max=\"" + (i + 1) + "\" width=\"" + width + "\" customWidth=\"1\"/>");
        }
        w.write("</cols><sheetData><row r=\"1\">");
        for (int i = 0; i < cols; i++) {
            inline(w, ref(i, 1), table.columns().get(i).header(), STYLE_HEADER);
        }
        w.write("</row>");
        int r = 2;
        for (var row : table.rows()) {
            w.write("<row r=\"" + r + "\">");
            for (int i = 0; i < cols; i++) {
                cell(w, ref(i, r), table.columns().get(i).kind(), row.get(i));
            }
            w.write("</row>");
            r++;
        }
        w.write("</sheetData>");
        if (cols > 0) {
            w.write("<autoFilter ref=\"A1:" + ref(cols - 1, lastRow) + "\"/>");
        }
        w.write("</worksheet>");
    }

    private void filterSheet(Map<String, String> filters, Writer w) throws IOException {
        w.write("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>");
        w.write("<worksheet xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\"><cols>"
                + "<col min=\"1\" max=\"1\" width=\"28\" customWidth=\"1\"/><col min=\"2\" max=\"2\" width=\"60\" customWidth=\"1\"/></cols><sheetData>");
        w.write("<row r=\"1\">");
        inline(w, "A1", "Filter", STYLE_HEADER);
        inline(w, "B1", "Value", STYLE_HEADER);
        w.write("</row>");
        int r = 2;
        for (Map.Entry<String, String> e : filters.entrySet()) {
            w.write("<row r=\"" + r + "\">");
            inline(w, "A" + r, CellSafety.text(e.getKey()), 0);
            inline(w, "B" + r, CellSafety.text(e.getValue()), 0);
            w.write("</row>");
            r++;
        }
        w.write("</sheetData></worksheet>");
    }

    private void cell(Writer w, String ref, ReportTable.Kind kind, Object v) throws IOException {
        if (v == null) {
            return;
        }
        switch (kind) {
            case INTEGER, DECIMAL, PERCENT -> {
                if (v instanceof Number n && Double.isFinite(n.doubleValue())) {
                    int style = kind == ReportTable.Kind.PERCENT ? STYLE_PERCENT : kind == ReportTable.Kind.INTEGER ? STYLE_INTEGER : STYLE_DECIMAL;
                    w.write("<c r=\"" + ref + "\" s=\"" + style + "\"><v>" + plain(n) + "</v></c>");
                } else {
                    inline(w, ref, CellSafety.text(v), 0);
                }
            }
            case DATE -> {
                LocalDate d = v instanceof LocalDate ld ? ld : v instanceof Instant i ? LocalDate.ofInstant(i, zone) : null;
                if (d == null) {
                    inline(w, ref, CellSafety.text(v), 0);
                } else {
                    w.write("<c r=\"" + ref + "\" s=\"" + STYLE_DATE + "\"><v>" + ChronoUnit.DAYS.between(EPOCH.toLocalDate(), d) + "</v></c>");
                }
            }
            case DATETIME -> {
                if (v instanceof Instant i) {
                    LocalDateTime t = LocalDateTime.ofInstant(i, zone);
                    double serial = ChronoUnit.SECONDS.between(EPOCH, t) / 86400.0;
                    w.write("<c r=\"" + ref + "\" s=\"" + STYLE_DATETIME + "\"><v>" + serial + "</v></c>");
                } else {
                    inline(w, ref, CellSafety.text(v), 0);
                }
            }
            default -> inline(w, ref, CellSafety.text(v), 0);
        }
    }

    private static void inline(Writer w, String ref, String text, int style) throws IOException {
        String t = text == null ? "" : text.length() > 32767 ? text.substring(0, 32767) : text;
        w.write("<c r=\"" + ref + "\" t=\"inlineStr\"" + (style > 0 ? " s=\"" + style + "\"" : "") + "><is><t xml:space=\"preserve\">"
                + CellSafety.xml(t) + "</t></is></c>");
    }

    private static String plain(Number n) {
        if (n instanceof Integer || n instanceof Long || n instanceof Short) {
            return String.valueOf(n.longValue());
        }
        return new java.math.BigDecimal(n.toString()).stripTrailingZeros().toPlainString();
    }

    public static String ref(int col, int row) {
        StringBuilder sb = new StringBuilder();
        int c = col + 1;
        while (c > 0) {
            int m = (c - 1) % 26;
            sb.insert(0, (char) ('A' + m));
            c = (c - 1) / 26;
        }
        return sb.append(row).toString();
    }

    static String sheetName(String title) {
        String s = title == null || title.isBlank() ? "Report" : title.replaceAll("[\\\\/?*\\[\\]:]", " ").replaceAll("\\s+", " ").trim();
        if (s.isEmpty()) {
            s = "Report";
        }
        return s.length() > 31 ? s.substring(0, 31) : s;
    }

    private static String contentTypes(boolean filters) {
        return "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>"
                + "<Types xmlns=\"http://schemas.openxmlformats.org/package/2006/content-types\">"
                + "<Default Extension=\"rels\" ContentType=\"application/vnd.openxmlformats-package.relationships+xml\"/>"
                + "<Default Extension=\"xml\" ContentType=\"application/xml\"/>"
                + "<Override PartName=\"/xl/workbook.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml\"/>"
                + "<Override PartName=\"/xl/styles.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml\"/>"
                + "<Override PartName=\"/xl/worksheets/sheet1.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml\"/>"
                + (filters ? "<Override PartName=\"/xl/worksheets/sheet2.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml\"/>" : "")
                + "</Types>";
    }

    private static String workbook(String name, boolean filters) {
        return "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>"
                + "<workbook xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\" "
                + "xmlns:r=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships\"><sheets>"
                + "<sheet name=\"" + CellSafety.xml(name) + "\" sheetId=\"1\" r:id=\"rId1\"/>"
                + (filters ? "<sheet name=\"Filters\" sheetId=\"2\" r:id=\"rId3\"/>" : "")
                + "</sheets></workbook>";
    }

    private static String workbookRels(boolean filters) {
        return "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>"
                + "<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">"
                + "<Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet\" Target=\"worksheets/sheet1.xml\"/>"
                + "<Relationship Id=\"rId2\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles\" Target=\"styles.xml\"/>"
                + (filters ? "<Relationship Id=\"rId3\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet\" Target=\"worksheets/sheet2.xml\"/>" : "")
                + "</Relationships>";
    }

    private static String styles() {
        return "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>"
                + "<styleSheet xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\">"
                + "<numFmts count=\"3\"><numFmt numFmtId=\"164\" formatCode=\"dd-mmm-yyyy\"/>"
                + "<numFmt numFmtId=\"165\" formatCode=\"dd-mmm-yyyy hh:mm\"/><numFmt numFmtId=\"166\" formatCode=\"#,##0.00\"/></numFmts>"
                + "<fonts count=\"3\"><font><sz val=\"10\"/><name val=\"Arial\"/></font>"
                + "<font><b/><sz val=\"10\"/><color rgb=\"FF1F3B4D\"/><name val=\"Arial\"/></font>"
                + "<font><b/><sz val=\"12\"/><name val=\"Arial\"/></font></fonts>"
                + "<fills count=\"3\"><fill><patternFill patternType=\"none\"/></fill><fill><patternFill patternType=\"gray125\"/></fill>"
                + "<fill><patternFill patternType=\"solid\"><fgColor rgb=\"FFDDEBF7\"/><bgColor indexed=\"64\"/></patternFill></fill></fills>"
                + "<borders count=\"1\"><border><left/><right/><top/><bottom/><diagonal/></border></borders>"
                + "<cellStyleXfs count=\"1\"><xf numFmtId=\"0\" fontId=\"0\" fillId=\"0\" borderId=\"0\"/></cellStyleXfs>"
                + "<cellXfs count=\"8\">"
                + "<xf numFmtId=\"0\" fontId=\"0\" fillId=\"0\" borderId=\"0\" xfId=\"0\"/>"
                + "<xf numFmtId=\"0\" fontId=\"1\" fillId=\"2\" borderId=\"0\" xfId=\"0\" applyFont=\"1\" applyFill=\"1\"/>"
                + "<xf numFmtId=\"164\" fontId=\"0\" fillId=\"0\" borderId=\"0\" xfId=\"0\" applyNumberFormat=\"1\"/>"
                + "<xf numFmtId=\"165\" fontId=\"0\" fillId=\"0\" borderId=\"0\" xfId=\"0\" applyNumberFormat=\"1\"/>"
                + "<xf numFmtId=\"10\" fontId=\"0\" fillId=\"0\" borderId=\"0\" xfId=\"0\" applyNumberFormat=\"1\"/>"
                + "<xf numFmtId=\"3\" fontId=\"0\" fillId=\"0\" borderId=\"0\" xfId=\"0\" applyNumberFormat=\"1\"/>"
                + "<xf numFmtId=\"166\" fontId=\"0\" fillId=\"0\" borderId=\"0\" xfId=\"0\" applyNumberFormat=\"1\"/>"
                + "<xf numFmtId=\"0\" fontId=\"2\" fillId=\"0\" borderId=\"0\" xfId=\"0\" applyFont=\"1\"/>"
                + "</cellXfs><cellStyles count=\"1\"><cellStyle name=\"Normal\" xfId=\"0\" builtinId=\"0\"/></cellStyles></styleSheet>";
    }

    private static void entry(ZipOutputStream zip, String name, String content) throws IOException {
        zip.putNextEntry(new ZipEntry(name));
        zip.write(content.getBytes(StandardCharsets.UTF_8));
        zip.closeEntry();
    }

    public static String contentType() {
        return "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
    }
}
