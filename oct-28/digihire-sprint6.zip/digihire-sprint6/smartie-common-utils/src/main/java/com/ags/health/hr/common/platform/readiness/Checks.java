package com.ags.health.hr.common.platform.readiness;

import org.springframework.jdbc.core.JdbcTemplate;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.function.Supplier;
import java.util.regex.Pattern;

public final class Checks {

    private static final Pattern IDENT = Pattern.compile("[A-Za-z_][A-Za-z0-9_]{0,62}");

    private Checks() {
    }

    public static ReadinessCheck of(String name, String area, Supplier<ReadinessResult> body) {
        return new ReadinessCheck() {
            @Override
            public String name() {
                return name;
            }

            @Override
            public String area() {
                return area;
            }

            @Override
            public ReadinessResult run() {
                return body.get();
            }
        };
    }

    public static ReadinessCheck database(JdbcTemplate jdbc) {
        return of("database", "infrastructure", () -> {
            Integer one = jdbc.queryForObject("SELECT 1", Integer.class);
            return one != null && one == 1 ? ReadinessResult.pass("Database reachable") : ReadinessResult.fail("Unexpected answer from database");
        });
    }

    public static ReadinessCheck tables(JdbcTemplate jdbc, List<String> tables) {
        for (String t : tables) {
            if (!IDENT.matcher(t).matches()) {
                throw new IllegalArgumentException("Invalid table name " + t);
            }
        }
        return of("schema", "database", () -> {
            List<String> missing = new ArrayList<>();
            for (String t : tables) {
                try {
                    jdbc.queryForObject("SELECT count(*) FROM " + t + " WHERE 1 = 0", Long.class);
                } catch (RuntimeException e) {
                    missing.add(t);
                }
            }
            return missing.isEmpty() ? ReadinessResult.pass(tables.size() + " tables present")
                    : ReadinessResult.fail("Missing tables: " + String.join(", ", missing)).with(Map.of("missing", missing));
        });
    }

    public static ReadinessCheck setting(String name, String area, String value, boolean production, String help) {
        return of(name, area, () -> {
            if (value == null || value.isBlank()) {
                return production ? ReadinessResult.fail(help + " is not set") : ReadinessResult.warn(help + " is not set");
            }
            return ReadinessResult.pass(help + " is set");
        });
    }

    public static ReadinessCheck notStub(String name, String area, String mode, boolean production) {
        return of(name, area, () -> {
            String m = mode == null ? "" : mode.toUpperCase(Locale.ROOT);
            if (m.isEmpty() || "STUB".equals(m) || "MEMORY".equals(m)) {
                return production ? ReadinessResult.fail("Mode is " + (m.isEmpty() ? "unset" : m) + " in production")
                        : ReadinessResult.warn("Mode is " + (m.isEmpty() ? "unset" : m));
            }
            return ReadinessResult.pass("Mode is " + m);
        });
    }

    public static ReadinessCheck backlog(String name, String area, Supplier<Long> count, long warnAt, long failAt) {
        return of(name, area, () -> {
            long n = count.get();
            Map<String, Object> d = Map.of("count", n, "warnAt", warnAt, "failAt", failAt);
            if (n >= failAt) {
                return ReadinessResult.fail(n + " items waiting").with(d);
            }
            if (n >= warnAt) {
                return ReadinessResult.warn(n + " items waiting").with(d);
            }
            return ReadinessResult.pass(n + " items waiting").with(d);
        });
    }
}
