package com.ags.health.hr.common.platform.readiness;

import java.util.Map;

public record ReadinessResult(String name, String area, Status status, String message, Map<String, Object> details, long millis) {

    public enum Status { PASS, WARN, FAIL }

    public ReadinessResult {
        details = details == null ? Map.of() : Map.copyOf(details);
    }

    public static ReadinessResult pass(String message) {
        return new ReadinessResult(null, null, Status.PASS, message, null, 0);
    }

    public static ReadinessResult warn(String message) {
        return new ReadinessResult(null, null, Status.WARN, message, null, 0);
    }

    public static ReadinessResult fail(String message) {
        return new ReadinessResult(null, null, Status.FAIL, message, null, 0);
    }

    public ReadinessResult with(Map<String, Object> more) {
        return new ReadinessResult(name, area, status, message, more, millis);
    }

    ReadinessResult named(String n, String a, long ms) {
        return new ReadinessResult(n, a, status, message, details, ms);
    }
}
