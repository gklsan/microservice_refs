package com.ags.health.hr.common.platform.concurrency;

import com.ags.health.hr.common.platform.db.JdbcValues;
import com.ags.health.hr.common.platform.error.PlatformException;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.jdbc.core.JdbcTemplate;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.sql.Timestamp;
import java.time.Clock;
import java.time.Duration;
import java.time.Instant;
import java.util.HexFormat;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.regex.Pattern;

public class IdempotencyStore {

    public record Stored(int status, String contentType, byte[] body) {
    }

    public sealed interface Claim permits Claim.Fresh, Claim.Replay, Claim.InFlight {

        record Fresh(String key) implements Claim {
        }

        record Replay(Stored response) implements Claim {
        }

        record InFlight() implements Claim {
        }
    }

    private static final Pattern KEY = Pattern.compile("[A-Za-z0-9._:-]{8,100}");
    private static final Pattern TABLE = Pattern.compile("[A-Za-z_][A-Za-z0-9_]{0,62}");

    private final JdbcTemplate jdbc;
    private final Clock clock;
    private final String table;
    private final Duration ttl;
    private final Duration inFlightTimeout;

    public IdempotencyStore(JdbcTemplate jdbc, Clock clock, String table, Duration ttl, Duration inFlightTimeout) {
        if (!TABLE.matcher(table).matches()) {
            throw new IllegalArgumentException("Invalid idempotency table " + table);
        }
        this.jdbc = jdbc;
        this.clock = clock;
        this.table = table;
        this.ttl = ttl;
        this.inFlightTimeout = inFlightTimeout;
    }

    public static boolean validKey(String key) {
        return key != null && KEY.matcher(key).matches();
    }

    public Claim claim(String actor, String key, String method, String path, byte[] requestBody) {
        if (!validKey(key)) {
            throw PlatformException.badRequest("IDEMPOTENCY_KEY_INVALID", "Idempotency-Key must be 8-100 characters of A-Z, 0-9, . _ : -");
        }
        String scoped = scope(actor, key);
        String hash = hash(method + " " + path + "\n" + new String(requestBody == null ? new byte[0] : requestBody, StandardCharsets.UTF_8));
        Instant now = clock.instant();
        try {
            jdbc.update("INSERT INTO " + table + " (idem_key, request_hash, state, created_at, expires_at) VALUES (?, ?, 'IN_FLIGHT', ?, ?)",
                    scoped, hash, Timestamp.from(now), Timestamp.from(now.plus(ttl)));
            return new Claim.Fresh(scoped);
        } catch (DuplicateKeyException e) {
            List<Map<String, Object>> rows = jdbc.queryForList("SELECT request_hash, state, status_code, content_type, body, created_at, expires_at FROM "
                    + table + " WHERE idem_key = ?", scoped);
            if (rows.isEmpty()) {
                return claim(actor, key, method, path, requestBody);
            }
            Map<String, Object> row = rows.get(0);
            Instant expires = JdbcValues.instant(row.get("expires_at"));
            Instant created = JdbcValues.instant(row.get("created_at"));
            boolean stale = "IN_FLIGHT".equals(row.get("state")) && created.plus(inFlightTimeout).isBefore(now);
            if (!expires.isAfter(now) || stale) {
                int n = jdbc.update("UPDATE " + table + " SET request_hash = ?, state = 'IN_FLIGHT', status_code = NULL, content_type = NULL, body = NULL, "
                        + "created_at = ?, expires_at = ? WHERE idem_key = ? AND created_at = ?", hash, Timestamp.from(now),
                        Timestamp.from(now.plus(ttl)), scoped, Timestamp.from(created));
                return n == 1 ? new Claim.Fresh(scoped) : new Claim.InFlight();
            }
            if (!hash.equals(row.get("request_hash"))) {
                throw PlatformException.unprocessable("IDEMPOTENCY_KEY_REUSED",
                        "This Idempotency-Key was already used with a different request", null);
            }
            if ("IN_FLIGHT".equals(row.get("state"))) {
                return new Claim.InFlight();
            }
            Object body = row.get("body");
            return new Claim.Replay(new Stored(((Number) row.get("status_code")).intValue(), (String) row.get("content_type"),
                    body == null ? new byte[0] : String.valueOf(body).getBytes(StandardCharsets.UTF_8)));
        }
    }

    public void complete(String scopedKey, int status, String contentType, byte[] body) {
        if (status >= 500) {
            release(scopedKey);
            return;
        }
        jdbc.update("UPDATE " + table + " SET state = 'DONE', status_code = ?, content_type = ?, body = ? WHERE idem_key = ?",
                status, contentType, body == null ? null : new String(body, StandardCharsets.UTF_8), scopedKey);
    }

    public void release(String scopedKey) {
        jdbc.update("DELETE FROM " + table + " WHERE idem_key = ? AND state = 'IN_FLIGHT'", scopedKey);
    }

    public int purgeExpired() {
        return jdbc.update("DELETE FROM " + table + " WHERE expires_at < ?", Timestamp.from(clock.instant()));
    }

    public Optional<String> state(String actor, String key) {
        return jdbc.queryForList("SELECT state FROM " + table + " WHERE idem_key = ?", String.class, scope(actor, key)).stream().findFirst();
    }

    static String scope(String actor, String key) {
        return hash((actor == null ? "anonymous" : actor) + "|" + key);
    }

    static String hash(String value) {
        try {
            return HexFormat.of().formatHex(MessageDigest.getInstance("SHA-256").digest(value.getBytes(StandardCharsets.UTF_8)));
        } catch (NoSuchAlgorithmException e) {
            throw new IllegalStateException(e);
        }
    }
}
