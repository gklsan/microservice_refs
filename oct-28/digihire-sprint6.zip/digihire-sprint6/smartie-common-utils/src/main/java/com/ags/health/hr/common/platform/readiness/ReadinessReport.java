package com.ags.health.hr.common.platform.readiness;

import java.time.Instant;
import java.util.List;

public record ReadinessReport(String service, String environment, ReadinessResult.Status overall, int passed, int warnings,
                              int failures, List<ReadinessResult> checks, Instant at) {

    public ReadinessReport {
        checks = List.copyOf(checks);
    }
}
