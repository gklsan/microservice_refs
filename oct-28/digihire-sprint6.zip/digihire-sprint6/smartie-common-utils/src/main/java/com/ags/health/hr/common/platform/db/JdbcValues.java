package com.ags.health.hr.common.platform.db;

import java.sql.Timestamp;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.OffsetDateTime;
import java.time.ZoneOffset;
import java.time.ZonedDateTime;

public final class JdbcValues {

    private JdbcValues() {
    }

    public static Instant instant(Object v) {
        if (v == null) {
            return null;
        }
        if (v instanceof Timestamp t) {
            return t.toInstant();
        }
        if (v instanceof OffsetDateTime o) {
            return o.toInstant();
        }
        if (v instanceof ZonedDateTime z) {
            return z.toInstant();
        }
        if (v instanceof Instant i) {
            return i;
        }
        if (v instanceof LocalDateTime l) {
            return l.toInstant(ZoneOffset.UTC);
        }
        if (v instanceof java.util.Date d) {
            return d.toInstant();
        }
        throw new IllegalArgumentException("Not a timestamp: " + v.getClass().getName());
    }
}
