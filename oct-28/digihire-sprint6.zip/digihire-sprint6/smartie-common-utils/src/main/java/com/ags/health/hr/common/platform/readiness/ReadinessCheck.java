package com.ags.health.hr.common.platform.readiness;

public interface ReadinessCheck {

    String name();

    String area();

    ReadinessResult run();
}
