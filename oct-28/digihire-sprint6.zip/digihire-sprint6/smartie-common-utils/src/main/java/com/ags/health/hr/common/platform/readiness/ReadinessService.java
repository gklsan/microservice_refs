package com.ags.health.hr.common.platform.readiness;

import java.time.Clock;
import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

public class ReadinessService {

    private final String service;
    private final String environment;
    private final List<ReadinessCheck> checks;
    private final Duration timeout;
    private final Clock clock;

    public ReadinessService(String service, String environment, List<ReadinessCheck> checks, Duration timeout, Clock clock) {
        this.service = service;
        this.environment = environment;
        this.checks = List.copyOf(checks);
        this.timeout = timeout;
        this.clock = clock;
    }

    public ReadinessReport run() {
        List<ReadinessResult> results = new ArrayList<>();
        ExecutorService pool = Executors.newFixedThreadPool(Math.max(1, Math.min(4, checks.size())), r -> {
            Thread t = new Thread(r, "readiness-check");
            t.setDaemon(true);
            return t;
        });
        try {
            List<Future<ReadinessResult>> futures = new ArrayList<>();
            for (ReadinessCheck c : checks) {
                futures.add(pool.submit(() -> timed(c)));
            }
            for (int i = 0; i < checks.size(); i++) {
                ReadinessCheck c = checks.get(i);
                try {
                    results.add(futures.get(i).get(timeout.toMillis(), TimeUnit.MILLISECONDS));
                } catch (TimeoutException e) {
                    futures.get(i).cancel(true);
                    results.add(ReadinessResult.fail("Check did not finish within " + timeout.toSeconds() + "s").named(c.name(), c.area(), timeout.toMillis()));
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                    results.add(ReadinessResult.fail("Interrupted").named(c.name(), c.area(), 0));
                } catch (Exception e) {
                    results.add(ReadinessResult.fail(String.valueOf(e.getCause() == null ? e.getMessage() : e.getCause().getMessage()))
                            .named(c.name(), c.area(), 0));
                }
            }
        } finally {
            pool.shutdownNow();
        }
        int pass = 0;
        int warn = 0;
        int fail = 0;
        for (ReadinessResult r : results) {
            switch (r.status()) {
                case PASS -> pass++;
                case WARN -> warn++;
                case FAIL -> fail++;
            }
        }
        ReadinessResult.Status overall = fail > 0 ? ReadinessResult.Status.FAIL : warn > 0 ? ReadinessResult.Status.WARN : ReadinessResult.Status.PASS;
        return new ReadinessReport(service, environment, overall, pass, warn, fail, results, clock.instant());
    }

    private static ReadinessResult timed(ReadinessCheck c) {
        long start = System.nanoTime();
        ReadinessResult r;
        try {
            r = c.run();
            if (r == null) {
                r = ReadinessResult.fail("Check returned nothing");
            }
        } catch (RuntimeException e) {
            r = ReadinessResult.fail(e.getClass().getSimpleName() + ": " + e.getMessage());
        }
        return r.named(c.name(), c.area(), (System.nanoTime() - start) / 1_000_000);
    }
}
