package com.ags.health.hr.common.platform.export;

import javax.xml.stream.XMLInputFactory;
import javax.xml.stream.XMLStreamConstants;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamReader;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

public class XlsxSheetReader {

    private static final LocalDate EPOCH = LocalDate.of(1899, 12, 30);
    private static final String REL = "http://schemas.openxmlformats.org/officeDocument/2006/relationships";

    private final long maxUncompressedBytes;
    private final int maxRows;

    public XlsxSheetReader(long maxUncompressedBytes, int maxRows) {
        this.maxUncompressedBytes = maxUncompressedBytes;
        this.maxRows = maxRows;
    }

    public List<List<String>> firstSheet(byte[] file) {
        Map<String, byte[]> parts = unzip(file);
        String sheetPath = firstSheetPath(parts);
        byte[] sheet = parts.get(sheetPath);
        if (sheet == null) {
            throw new IllegalArgumentException("Workbook has no worksheet");
        }
        List<String> shared = sharedStrings(parts.get("xl/sharedStrings.xml"));
        return rows(sheet, shared);
    }

    public static LocalDate dateFromSerial(String value) {
        double d = Double.parseDouble(value.trim());
        return EPOCH.plusDays((long) Math.floor(d));
    }

    private Map<String, byte[]> unzip(byte[] file) {
        Map<String, byte[]> parts = new HashMap<>();
        long total = 0;
        try (ZipInputStream zip = new ZipInputStream(new ByteArrayInputStream(file))) {
            ZipEntry e;
            byte[] buf = new byte[8192];
            while ((e = zip.getNextEntry()) != null) {
                String name = e.getName();
                if (e.isDirectory() || !(name.equals("xl/workbook.xml") || name.equals("xl/_rels/workbook.xml.rels")
                        || name.equals("xl/sharedStrings.xml") || name.startsWith("xl/worksheets/sheet"))) {
                    continue;
                }
                ByteArrayOutputStream out = new ByteArrayOutputStream();
                int n;
                while ((n = zip.read(buf)) > 0) {
                    total += n;
                    if (total > maxUncompressedBytes) {
                        throw new IllegalArgumentException("Workbook is larger than " + maxUncompressedBytes + " bytes when unpacked");
                    }
                    out.write(buf, 0, n);
                }
                parts.put(name, out.toByteArray());
            }
        } catch (IOException ex) {
            throw new IllegalArgumentException("File is not a readable .xlsx workbook", ex);
        }
        if (parts.isEmpty()) {
            throw new IllegalArgumentException("File is not a readable .xlsx workbook");
        }
        return parts;
    }

    private String firstSheetPath(Map<String, byte[]> parts) {
        byte[] wb = parts.get("xl/workbook.xml");
        byte[] rels = parts.get("xl/_rels/workbook.xml.rels");
        if (wb == null || rels == null) {
            return "xl/worksheets/sheet1.xml";
        }
        String rid = null;
        try {
            XMLStreamReader r = reader(wb);
            while (r.hasNext() && rid == null) {
                if (r.next() == XMLStreamConstants.START_ELEMENT && "sheet".equals(r.getLocalName())) {
                    rid = r.getAttributeValue(REL, "id");
                }
            }
            if (rid == null) {
                return "xl/worksheets/sheet1.xml";
            }
            XMLStreamReader rr = reader(rels);
            while (rr.hasNext()) {
                if (rr.next() == XMLStreamConstants.START_ELEMENT && "Relationship".equals(rr.getLocalName())
                        && rid.equals(rr.getAttributeValue(null, "Id"))) {
                    String target = rr.getAttributeValue(null, "Target");
                    return target.startsWith("/") ? target.substring(1) : "xl/" + target;
                }
            }
        } catch (XMLStreamException e) {
            throw new IllegalArgumentException("Workbook structure could not be read", e);
        }
        return "xl/worksheets/sheet1.xml";
    }

    private List<String> sharedStrings(byte[] xml) {
        List<String> out = new ArrayList<>();
        if (xml == null) {
            return out;
        }
        try {
            XMLStreamReader r = reader(xml);
            StringBuilder cur = null;
            boolean inPhonetic = false;
            while (r.hasNext()) {
                int ev = r.next();
                if (ev == XMLStreamConstants.START_ELEMENT) {
                    switch (r.getLocalName()) {
                        case "si" -> cur = new StringBuilder();
                        case "rPh" -> inPhonetic = true;
                        case "t" -> {
                            if (cur != null && !inPhonetic) {
                                cur.append(r.getElementText());
                            }
                        }
                        default -> {
                        }
                    }
                } else if (ev == XMLStreamConstants.END_ELEMENT) {
                    if ("si".equals(r.getLocalName()) && cur != null) {
                        out.add(cur.toString());
                        cur = null;
                    } else if ("rPh".equals(r.getLocalName())) {
                        inPhonetic = false;
                    }
                }
            }
        } catch (XMLStreamException e) {
            throw new IllegalArgumentException("Shared strings could not be read", e);
        }
        return out;
    }

    private List<List<String>> rows(byte[] xml, List<String> shared) {
        List<List<String>> rows = new ArrayList<>();
        try {
            XMLStreamReader r = reader(xml);
            List<String> row = null;
            int rowIndex = 0;
            String ref = null;
            String type = null;
            String value = null;
            StringBuilder inline = null;
            while (r.hasNext()) {
                int ev = r.next();
                if (ev == XMLStreamConstants.START_ELEMENT) {
                    switch (r.getLocalName()) {
                        case "row" -> {
                            String rr = r.getAttributeValue(null, "r");
                            int target = rr == null ? rowIndex + 1 : Integer.parseInt(rr);
                            while (rowIndex + 1 < target) {
                                rows.add(new ArrayList<>());
                                rowIndex++;
                            }
                            rowIndex = target;
                            if (rows.size() >= maxRows) {
                                throw new IllegalArgumentException("Sheet has more than " + maxRows + " rows");
                            }
                            row = new ArrayList<>();
                        }
                        case "c" -> {
                            ref = r.getAttributeValue(null, "r");
                            type = r.getAttributeValue(null, "t");
                            value = null;
                            inline = null;
                        }
                        case "v" -> value = r.getElementText();
                        case "is" -> inline = new StringBuilder();
                        case "t" -> {
                            if (inline != null) {
                                inline.append(r.getElementText());
                            }
                        }
                        default -> {
                        }
                    }
                } else if (ev == XMLStreamConstants.END_ELEMENT) {
                    if ("c".equals(r.getLocalName()) && row != null) {
                        int col = ref == null ? row.size() : column(ref);
                        while (row.size() < col) {
                            row.add("");
                        }
                        String text;
                        if ("s".equals(type)) {
                            int idx = value == null ? -1 : Integer.parseInt(value.trim());
                            text = idx >= 0 && idx < shared.size() ? shared.get(idx) : "";
                        } else if ("inlineStr".equals(type)) {
                            text = inline == null ? "" : inline.toString();
                        } else if ("b".equals(type)) {
                            text = "1".equals(value) ? "TRUE" : "FALSE";
                        } else {
                            text = value == null ? "" : value;
                        }
                        row.add(text);
                    } else if ("row".equals(r.getLocalName()) && row != null) {
                        rows.add(row);
                        row = null;
                    }
                }
            }
        } catch (XMLStreamException e) {
            throw new IllegalArgumentException("Worksheet could not be read", e);
        }
        while (!rows.isEmpty() && rows.get(rows.size() - 1).stream().allMatch(String::isBlank)) {
            rows.remove(rows.size() - 1);
        }
        return rows;
    }

    static int column(String ref) {
        int col = 0;
        for (int i = 0; i < ref.length(); i++) {
            char c = ref.charAt(i);
            if (c < 'A' || c > 'Z') {
                break;
            }
            col = col * 26 + (c - 'A' + 1);
        }
        return col - 1;
    }

    private static XMLStreamReader reader(byte[] xml) throws XMLStreamException {
        XMLInputFactory f = XMLInputFactory.newFactory();
        f.setProperty(XMLInputFactory.SUPPORT_DTD, false);
        f.setProperty(XMLInputFactory.IS_SUPPORTING_EXTERNAL_ENTITIES, false);
        f.setProperty(XMLInputFactory.IS_NAMESPACE_AWARE, true);
        InputStream in = new ByteArrayInputStream(xml);
        return f.createXMLStreamReader(in);
    }
}
