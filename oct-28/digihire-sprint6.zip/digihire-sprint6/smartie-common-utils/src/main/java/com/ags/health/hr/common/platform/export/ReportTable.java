package com.ags.health.hr.common.platform.export;

import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public record ReportTable(String title, List<Column> columns, List<List<Object>> rows, Map<String, String> filters) {

    public enum Kind { TEXT, INTEGER, DECIMAL, PERCENT, DATE, DATETIME }

    public record Column(String key, String header, Kind kind, int width) {

        public static Column text(String key, String header, int width) {
            return new Column(key, header, Kind.TEXT, width);
        }

        public static Column integer(String key, String header) {
            return new Column(key, header, Kind.INTEGER, 12);
        }

        public static Column decimal(String key, String header) {
            return new Column(key, header, Kind.DECIMAL, 12);
        }

        public static Column percent(String key, String header) {
            return new Column(key, header, Kind.PERCENT, 12);
        }

        public static Column date(String key, String header) {
            return new Column(key, header, Kind.DATE, 14);
        }

        public static Column dateTime(String key, String header) {
            return new Column(key, header, Kind.DATETIME, 18);
        }
    }

    public ReportTable {
        columns = List.copyOf(columns);
        List<List<Object>> copy = new ArrayList<>(rows.size());
        for (List<Object> r : rows) {
            if (r.size() != columns.size()) {
                throw new IllegalArgumentException("Row has " + r.size() + " cells, expected " + columns.size());
            }
            copy.add(Collections.unmodifiableList(new ArrayList<>(r)));
        }
        rows = Collections.unmodifiableList(copy);
        filters = filters == null ? Map.of() : Collections.unmodifiableMap(new LinkedHashMap<>(filters));
    }

    public static ReportTable fromMaps(String title, List<Column> columns, List<Map<String, Object>> data, Map<String, String> filters) {
        List<List<Object>> rows = new ArrayList<>(data.size());
        for (Map<String, Object> m : data) {
            List<Object> r = new ArrayList<>(columns.size());
            for (Column c : columns) {
                r.add(m.get(c.key()));
            }
            rows.add(r);
        }
        return new ReportTable(title, columns, rows, filters);
    }
}
