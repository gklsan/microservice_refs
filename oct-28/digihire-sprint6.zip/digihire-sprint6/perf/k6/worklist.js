import { sleep } from 'k6';
import { BASE, thresholds, get, pick, stages } from './lib.js';

const PEAK = Number(__ENV.PEAK_VUS || 150);

export const options = {
  scenarios: { worklist: { executor: 'ramping-vus', stages: stages(PEAK) } },
  thresholds: Object.assign({}, thresholds, { 'http_req_duration{name:worklist}': ['p(95)<1500'] }),
};

const TABS = ['APPLICANT', 'HR_INTERVIEW', 'ASSESSMENT', 'VERSANT', 'PANEL', 'PIPELINE', 'OFFER'];

export default function () {
  let cursor = '';
  const tab = pick(TABS);
  for (let page = 0; page < 3; page++) {
    const res = get(`${BASE}/worklist/applicants?tab=${tab}&size=25&count=${page === 0}${cursor ? `&cursor=${cursor}` : ''}`, 'worklist');
    const next = res.status === 200 ? res.json('nextCursor') : null;
    if (!next) {
      break;
    }
    cursor = encodeURIComponent(next);
    sleep(2);
  }
  sleep(3);
}
