import http from 'k6/http';
import { check } from 'k6';

export const BASE = __ENV.BASE_URL || 'http://localhost:8980/candidate-services';
export const JOBS = __ENV.JOBS_URL || 'http://localhost:8980/job-services';
const TOKEN = __ENV.TOKEN || '';

export const thresholds = {
  http_req_failed: ['rate<0.005'],
  http_req_duration: ['p(95)<3000', 'p(99)<5000'],
  checks: ['rate>0.995'],
};

export function headers(extra) {
  return Object.assign({ Authorization: `Bearer ${TOKEN}`, 'Content-Type': 'application/json' }, extra || {});
}

export function get(url, name) {
  const res = http.get(url, { headers: headers(), tags: { name } });
  check(res, { [`${name} 200`]: (r) => r.status === 200 });
  return res;
}

export function post(url, body, name, extra) {
  const res = http.post(url, JSON.stringify(body), { headers: headers(extra), tags: { name } });
  check(res, { [`${name} 2xx`]: (r) => r.status >= 200 && r.status < 300 });
  return res;
}

export function pick(list) {
  return list[Math.floor(Math.random() * list.length)];
}

export function stages(peakVus) {
  return [
    { duration: '2m', target: Math.ceil(peakVus / 5) },
    { duration: '5m', target: peakVus },
    { duration: '10m', target: peakVus },
    { duration: '2m', target: 0 },
  ];
}
