import { sleep } from 'k6';
import { BASE, thresholds, get, pick, stages } from './lib.js';

const PEAK = Number(__ENV.PEAK_VUS || 60);

export const options = {
  scenarios: { dashboard: { executor: 'ramping-vus', stages: stages(PEAK) } },
  thresholds: Object.assign({}, thresholds, {
    'http_req_duration{name:dashboard}': ['p(95)<3000'],
    'http_req_duration{name:funnel}': ['p(95)<3000'],
    'http_req_duration{name:drill}': ['p(95)<2000'],
  }),
};

const RANGES = [['2026-11-01', '2026-11-30'], ['2026-10-01', '2026-12-31'], ['2026-07-01', '2026-12-31']];
const DRILLS = ['pipeline:APPLICANT', 'pipeline:HR_INTERVIEW', 'pipeline:PANEL', 'aging:D8_14', 'funnel:OFFERED', 'dropped:HR_ROUND'];

export default function () {
  const [from, to] = pick(RANGES);
  get(`${BASE}/reports/dashboard`, 'dashboard');
  sleep(1);
  get(`${BASE}/reports/funnel?from=${from}&to=${to}&breakdown=lob`, 'funnel');
  sleep(1);
  get(`${BASE}/reports/dashboard/drill?drill=${pick(DRILLS)}&from=${from}&to=${to}&page=0&size=25`, 'drill');
  sleep(2);
  if (Math.random() < 0.3) {
    get(`${BASE}/reports/recruiters?from=${from}&to=${to}`, 'recruiters');
  }
  sleep(3);
}
