import { sleep } from 'k6';
import { BASE, thresholds, post, stages } from './lib.js';

const PEAK = Number(__ENV.PEAK_VUS || 80);
const REQUISITION = __ENV.REQUISITION_ID || 'REQ-PERF-1';

export const options = {
  scenarios: { map: { executor: 'ramping-vus', stages: stages(PEAK) } },
  thresholds: Object.assign({}, thresholds, { 'http_req_duration{name:assess-batch}': ['p(95)<3000'] }),
};

export default function () {
  const items = [];
  for (let i = 0; i < 25; i++) {
    const n = Math.floor(Math.random() * 500000);
    items.push({ email: `perf.candidate.${n}@example.com`, mobile: `9${String(n).padStart(9, '0')}`, requisitionId: REQUISITION });
  }
  post(`${BASE}/mapping/assess/batch`, { items }, 'assess-batch');
  sleep(5);
}
