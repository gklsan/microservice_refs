import { sleep } from 'k6';
import { BASE, get } from './lib.js';

export const options = {
  scenarios: { soak: { executor: 'constant-arrival-rate', rate: Number(__ENV.RPS || 20), timeUnit: '1s',
    duration: __ENV.DURATION || '4h', preAllocatedVUs: 50, maxVUs: 200 } },
  thresholds: { checks: ['rate>0.995'], http_req_failed: ['rate<0.005'], http_req_duration: ['p(95)<3000'] },
};

export default function () {
  const r = Math.random();
  if (r < 0.5) {
    get(`${BASE}/worklist/applicants?tab=APPLICANT&size=25`, 'worklist');
  } else if (r < 0.8) {
    get(`${BASE}/reports/dashboard`, 'dashboard');
  } else {
    get(`${BASE}/reports/filter-options`, 'options');
  }
  sleep(0.1);
}
