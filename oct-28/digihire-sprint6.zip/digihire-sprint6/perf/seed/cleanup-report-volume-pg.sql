DELETE FROM cand_p6_stage_event WHERE application_id LIKE 'PERF-%';
DELETE FROM cand_p6_app_fact WHERE application_id LIKE 'PERF-%';
