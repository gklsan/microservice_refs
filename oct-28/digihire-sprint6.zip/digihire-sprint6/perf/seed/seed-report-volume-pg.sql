\set rows :rows
\set days 180

INSERT INTO cand_p6_app_fact (application_id, candidate_id, candidate_name, requisition_id, job_id, lob, location, role_code, orc_id, source,
    vendor_id, hr_user_id, status, tab, applied_at, applied_date, hr_round_at, assessment_at, versant_at, panel_at, selected_at, offered_at,
    joined_at, rejected_at, rejected_stage, status_since, updated_at)
SELECT 'PERF-' || g,
       'PERF-C-' || g,
       'Perf Candidate ' || g,
       'REQ-PERF-' || (g % 400),
       'JOB-PERF-' || (g % 400),
       'LOB' || (g % 12),
       (ARRAY['Chennai', 'Trichy', 'Hyderabad', 'Pune', 'Vellore'])[1 + g % 5],
       'ROLE' || (g % 30),
       'ORC-' || (g % 400),
       (ARRAY['DIRECT', 'ERS', 'VENDOR', 'RECRUITER', 'CAMPUS', 'SOCIAL'])[1 + g % 6],
       CASE WHEN g % 6 = 2 THEN 'V' || (g % 25) END,
       'perf-rec-' || (g % 300),
       s.status, s.tab,
       a.applied, (a.applied AT TIME ZONE 'Asia/Kolkata')::date,
       CASE WHEN s.stage >= 1 THEN a.applied + interval '1 day' END,
       CASE WHEN s.stage >= 2 THEN a.applied + interval '2 day' END,
       CASE WHEN s.stage >= 3 AND g % 3 = 0 THEN a.applied + interval '3 day' END,
       CASE WHEN s.stage >= 4 THEN a.applied + interval '5 day' END,
       CASE WHEN s.stage >= 5 THEN a.applied + interval '7 day' END,
       CASE WHEN s.stage >= 6 THEN a.applied + interval '9 day' END,
       CASE WHEN s.stage >= 7 THEN a.applied + interval '25 day' END,
       CASE WHEN s.tab = 'REJECTED' THEN a.applied + interval '4 day' END,
       CASE WHEN s.tab = 'REJECTED' THEN 'HR_ROUND' END,
       a.applied + (s.stage || ' day')::interval,
       now()
FROM generate_series(1, :rows) AS g
CROSS JOIN LATERAL (SELECT now() - ((g % :days) || ' day')::interval - ((g % 1440) || ' minute')::interval AS applied) a
CROSS JOIN LATERAL (SELECT * FROM (VALUES
    (0, 'CREATED', 'APPLICANT'), (1, 'WAITING_FOR_HRROUND', 'HR_INTERVIEW'), (2, 'ASSESEMENT_INPROGRESS', 'ASSESSMENT'),
    (3, 'VERSANT_YET_TO_START', 'VERSANT'), (4, 'PANEL_INPROGRESS', 'PANEL'), (5, 'PANEL_SELECTED', 'OFFER'),
    (6, 'OFFERED', 'OFFER'), (7, 'JOINED', 'JOINED'), (1, 'HR_REJECTED', 'REJECTED')) v(stage, status, tab)
    OFFSET (g % 9) LIMIT 1) s
ON CONFLICT (application_id) DO NOTHING;

INSERT INTO cand_p6_stage_event (id, application_id, from_status, to_status, from_tab, to_tab, reason_code, actor_id, system_move, moved_at, moved_date)
SELECT md5(application_id || '-move'), application_id, 'CREATED', status, 'APPLICANT', tab, NULL, hr_user_id, FALSE, status_since,
       (status_since AT TIME ZONE 'Asia/Kolkata')::date
FROM cand_p6_app_fact
WHERE application_id LIKE 'PERF-%' AND status <> 'CREATED'
ON CONFLICT (id) DO NOTHING;

ANALYZE cand_p6_app_fact;
ANALYZE cand_p6_stage_event;

SELECT count(*) AS facts, count(DISTINCT hr_user_id) AS recruiters, min(applied_date) AS first_day, max(applied_date) AS last_day
FROM cand_p6_app_fact WHERE application_id LIKE 'PERF-%';
