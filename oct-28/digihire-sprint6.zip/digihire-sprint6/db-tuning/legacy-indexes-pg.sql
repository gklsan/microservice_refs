SET lock_timeout = '5s';
SET statement_timeout = '15min';

CREATE TEMP TABLE p6_index_plan (tbl TEXT, idx TEXT, cols TEXT, why TEXT);

INSERT INTO p6_index_plan VALUES
 ('application', 'ix_p6_app_candidate', 'candidate_id', 'Map Candidate: open applications of a candidate'),
 ('application', 'ix_p6_app_status_updated', 'status, updated_date', 'Applicant tabs: list by status, newest first'),
 ('application', 'ix_p6_app_hr_status', 'hr_user_id, status', 'Recruiter worklists'),
 ('application', 'ix_p6_app_requisition', 'requisition_id, status', 'Requisition fill and mapping checks'),
 ('application_status_log', 'ix_p6_status_log_app', 'application_id, created_date', 'Stage history and re-processing'),
 ('candidate', 'ix_p6_candidate_email', 'lower(email)', 'Map Candidate lookup by email'),
 ('candidate', 'ix_p6_candidate_mobile', 'mobile_number', 'Map Candidate lookup by mobile'),
 ('candidate', 'ix_p6_candidate_tagged', 'tagged_recruiter_id', 'Tagged recruiter checks'),
 ('interview', 'ix_p6_interview_app', 'application_id, status', 'Interview lookups per application'),
 ('audit_log', 'ix_p6_audit_target_time', 'target_id, event_time', 'Audit trail per record and completeness check'),
 ('audit_log', 'ix_p6_audit_type_time', 'event_type, event_time', 'Audit viewer filters'),
 ('audit_log', 'ix_p6_audit_actor_time', 'actor_id, event_time', 'Audit viewer by user');

DO $$
DECLARE
    p RECORD;
    c TEXT;
    col TEXT;
    ok BOOLEAN;
BEGIN
    FOR p IN SELECT * FROM p6_index_plan LOOP
        ok := EXISTS (SELECT 1 FROM information_schema.tables WHERE table_schema = current_schema() AND table_name = p.tbl);
        IF ok THEN
            FOREACH c IN ARRAY string_to_array(p.cols, ',') LOOP
                col := btrim(regexp_replace(c, '^\s*lower\((.*)\)\s*$', '\1'));
                IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_schema = current_schema()
                               AND table_name = p.tbl AND column_name = col) THEN
                    ok := FALSE;
                    RAISE NOTICE 'SKIP % on %: column % not found', p.idx, p.tbl, col;
                END IF;
            END LOOP;
        ELSE
            RAISE NOTICE 'SKIP % : table % not found', p.idx, p.tbl;
        END IF;
        IF ok THEN
            EXECUTE format('CREATE INDEX IF NOT EXISTS %I ON %I (%s)', p.idx, p.tbl, p.cols);
            RAISE NOTICE 'OK   % on %(%) - %', p.idx, p.tbl, p.cols, p.why;
        END IF;
    END LOOP;
    FOR p IN SELECT DISTINCT tbl FROM p6_index_plan LOOP
        IF EXISTS (SELECT 1 FROM information_schema.tables WHERE table_schema = current_schema() AND table_name = p.tbl) THEN
            EXECUTE format('ANALYZE %I', p.tbl);
        END IF;
    END LOOP;
END $$;

SELECT relname AS table_name, indexrelname AS index_name, pg_size_pretty(pg_relation_size(indexrelid)) AS size, idx_scan AS scans
FROM pg_stat_user_indexes
WHERE indexrelname LIKE 'ix_p6_%'
ORDER BY relname, indexrelname;
