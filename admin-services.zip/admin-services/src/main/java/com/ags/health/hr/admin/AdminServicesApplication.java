package com.ags.health.hr.admin;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.properties.ConfigurationPropertiesScan;

@SpringBootApplication
@ConfigurationPropertiesScan
public class AdminServicesApplication {

    public static void main(String[] args) {
        SpringApplication.run(AdminServicesApplication.class, args);
    }
}
