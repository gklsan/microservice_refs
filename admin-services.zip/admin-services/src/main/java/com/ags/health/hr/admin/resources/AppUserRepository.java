package com.ags.health.hr.admin.resources;

import com.ags.health.hr.admin.entities.AppUser;
import com.ags.health.hr.admin.enums.UserStatus;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.EntityGraph;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.Collection;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

public interface AppUserRepository extends JpaRepository<AppUser, UUID> {

    /** Everything the access resolver reads, in one round trip (hot path: every authenticated request). */
    @EntityGraph(attributePaths = {"roles", "roles.permissions", "permissionGrants", "scopes"})
    Optional<AppUser> findWithAccessBySmartieUserId(String smartieUserId);

    @EntityGraph(attributePaths = {"roles", "roles.permissions", "permissionGrants", "scopes"})
    Optional<AppUser> findWithAccessByEmail(String email);

    @EntityGraph(attributePaths = {"roles", "roles.permissions", "permissionGrants", "scopes"})
    Optional<AppUser> findWithAccessById(UUID id);

    Optional<AppUser> findByEmail(String email);

    boolean existsByEmail(String email);

    /** Admin user list: free text on name / e-mail / employee code, plus status and role filters. */
    @Query(value = """
            select u from AppUser u
            where (:search is null
                   or lower(u.fullName) like concat('%', cast(:search as string), '%')
                   or lower(u.email) like concat('%', cast(:search as string), '%')
                   or lower(u.employeeCode) like concat('%', cast(:search as string), '%'))
              and (:status is null or u.status = :status)
              and (:roleCode is null or exists (select 1 from u.roles r where r.code = :roleCode))
            """,
            countQuery = """
            select count(u) from AppUser u
            where (:search is null
                   or lower(u.fullName) like concat('%', cast(:search as string), '%')
                   or lower(u.email) like concat('%', cast(:search as string), '%')
                   or lower(u.employeeCode) like concat('%', cast(:search as string), '%'))
              and (:status is null or u.status = :status)
              and (:roleCode is null or exists (select 1 from u.roles r where r.code = :roleCode))
            """)
    Page<AppUser> search(@Param("search") String lowerCaseSearch,
                         @Param("status") UserStatus status,
                         @Param("roleCode") String roleCode,
                         Pageable pageable);

    @Query("select count(distinct u) from AppUser u join u.roles r where r.code = :roleCode and u.status = :status")
    long countByRoleAndStatus(@Param("roleCode") String roleCode, @Param("status") UserStatus status);

    @Query("select distinct u from AppUser u join u.roles r where r.code = :roleCode and u.status = :status order by u.fullName")
    List<AppUser> findByRoleAndStatus(@Param("roleCode") String roleCode, @Param("status") UserStatus status);

    List<AppUser> findByIdIn(Collection<UUID> ids);

    long countByManagerIdAndStatus(UUID managerId, UserStatus status);

    /** Smartie user ids of every direct and indirect report - TEAM visibility for TLs / managers. */
    @Query(value = """
            WITH RECURSIVE team AS (
                SELECT id, smartie_user_id FROM adm_app_user WHERE manager_id = :managerId AND status = 'ACTIVE'
                UNION
                SELECT u.id, u.smartie_user_id FROM adm_app_user u JOIN team t ON u.manager_id = t.id
                WHERE u.status = 'ACTIVE'
            )
            SELECT smartie_user_id FROM team WHERE smartie_user_id IS NOT NULL
            """, nativeQuery = true)
    List<String> findTeamSmartieUserIds(@Param("managerId") UUID managerId);

    /** Ids of the managers above a user (upwards chain) - used to reject reporting-line cycles. */
    @Query(value = """
            WITH RECURSIVE chain AS (
                SELECT id, manager_id FROM adm_app_user WHERE id = :userId
                UNION
                SELECT u.id, u.manager_id FROM adm_app_user u JOIN chain c ON u.id = c.manager_id
            )
            SELECT CAST(id AS VARCHAR) FROM chain
            """, nativeQuery = true)
    List<String> findChainUpwards(@Param("userId") UUID userId);
}
