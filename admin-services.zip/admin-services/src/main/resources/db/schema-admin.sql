-- =====================================================================================================
-- admin-services schema (Phase 5 - Admin user management + RBAC)
--
-- How it runs: Spring Boot executes this file on every start (spring.sql.init.mode=always).
-- Every statement is idempotent (IF NOT EXISTS / ON CONFLICT), so the existing bash deploy
-- (prod_deploy.sh) needs no extra migration step and no Flyway.
--
-- All tables are prefixed adm_ so they never collide with the Hibernate ddl-auto tables the other
-- services create in the shared smartiedb schema. Hibernate in admin-services runs with
-- ddl-auto=validate: it checks these tables, it never changes them.
--
-- Requires PostgreSQL 13+ (gen_random_uuid() is built in, no pgcrypto extension needed).
-- Statement separator is "@@" (see spring.sql.init.separator) so function bodies stay intact.
-- =====================================================================================================

-- ---------- bookkeeping: one row per applied seed changeset ----------
CREATE TABLE IF NOT EXISTS adm_schema_change (
    id          VARCHAR(100) PRIMARY KEY,
    applied_at  TIMESTAMPTZ  NOT NULL DEFAULT now()
)@@

-- ---------- roles ----------
CREATE TABLE IF NOT EXISTS adm_role (
    id             UUID         PRIMARY KEY DEFAULT gen_random_uuid(),
    code           VARCHAR(50)  NOT NULL UNIQUE,            -- readable, immutable: SUPER_ADMIN, RECRUITER ...
    legacy_code    VARCHAR(10),                             -- R01..R07 from the access matrix (traceability only)
    name           VARCHAR(100) NOT NULL,
    description    VARCHAR(500),
    default_scope  VARCHAR(20)  NOT NULL DEFAULT 'OWN',     -- NONE | OWN | TEAM | LOB | LOCATION | ALL
    system_role    BOOLEAN      NOT NULL DEFAULT FALSE,     -- seeded role: cannot be renamed to another code
    active         BOOLEAN      NOT NULL DEFAULT TRUE,      -- retired roles grant nothing (checked on every request)
    created_date   TIMESTAMPTZ  NOT NULL DEFAULT now(),
    created_by     VARCHAR(254),
    updated_date   TIMESTAMPTZ,
    updated_by     VARCHAR(254),
    version        BIGINT       NOT NULL DEFAULT 0
)@@

-- ---------- permission catalogue (OBJECT:ACTION). Seed-only: there is no "create permission" API ----------
CREATE TABLE IF NOT EXISTS adm_permission (
    code         VARCHAR(80)  PRIMARY KEY,
    object_type  VARCHAR(50)  NOT NULL,
    action       VARCHAR(30)  NOT NULL,                     -- VIEW | CREATE | EDIT | DELETE
    module       VARCHAR(100) NOT NULL,                     -- label shown on the matrix screen
    description  VARCHAR(300),
    privileged   BOOLEAN      NOT NULL DEFAULT FALSE,       -- only reachable through the SUPER_ADMIN role, never a user-level ALLOW
    sort_order   INT          NOT NULL DEFAULT 0
)@@

-- role -> permission. conditional = the "C" cell of the matrix (see AccessEvaluator for the rule)
CREATE TABLE IF NOT EXISTS adm_role_permission (
    role_id          UUID        NOT NULL REFERENCES adm_role (id) ON DELETE CASCADE,
    permission_code  VARCHAR(80) NOT NULL REFERENCES adm_permission (code),
    conditional      BOOLEAN     NOT NULL DEFAULT FALSE,
    PRIMARY KEY (role_id, permission_code)
)@@

-- Factory defaults, used by "reset role to defaults" and by the first seed.
-- The foreign keys make a typo in a seeded role or permission code FAIL the start-up
-- instead of being dropped silently by a JOIN.
CREATE TABLE IF NOT EXISTS adm_default_role_permission (
    role_code        VARCHAR(50) NOT NULL REFERENCES adm_role (code),
    permission_code  VARCHAR(80) NOT NULL REFERENCES adm_permission (code),
    conditional      BOOLEAN     NOT NULL DEFAULT FALSE,
    PRIMARY KEY (role_code, permission_code)
)@@

-- ---------- admin-module users (authorisation data only; login identity stays in auth-services) ----------
CREATE TABLE IF NOT EXISTS adm_app_user (
    id                   UUID         PRIMARY KEY DEFAULT gen_random_uuid(),
    smartie_user_id      VARCHAR(64)  UNIQUE,              -- auth-services smartie_user.id, back-filled on first request
    email                VARCHAR(254) NOT NULL UNIQUE,     -- always lower case, the link to the login identity
    full_name            VARCHAR(200) NOT NULL,
    employee_code        VARCHAR(50),
    user_type            VARCHAR(40)  NOT NULL DEFAULT 'EMPLOYEE_HR',
    status               VARCHAR(20)  NOT NULL DEFAULT 'ACTIVE',   -- ACTIVE | INACTIVE
    scope_level          VARCHAR(20),                      -- null = widest default_scope of the user's roles
    manager_id           UUID         REFERENCES adm_app_user (id),
    status_changed_date  TIMESTAMPTZ,
    status_changed_by    VARCHAR(254),
    status_reason        VARCHAR(1000),
    created_date         TIMESTAMPTZ  NOT NULL DEFAULT now(),
    created_by           VARCHAR(254),
    updated_date         TIMESTAMPTZ,
    updated_by           VARCHAR(254),
    version              BIGINT       NOT NULL DEFAULT 0
)@@
CREATE INDEX IF NOT EXISTS ix_adm_app_user_manager ON adm_app_user (manager_id)@@
CREATE INDEX IF NOT EXISTS ix_adm_app_user_status  ON adm_app_user (status)@@
CREATE INDEX IF NOT EXISTS ix_adm_app_user_name    ON adm_app_user (lower(full_name))@@

CREATE TABLE IF NOT EXISTS adm_user_role (
    user_id  UUID NOT NULL REFERENCES adm_app_user (id) ON DELETE CASCADE,
    role_id  UUID NOT NULL REFERENCES adm_role (id),
    PRIMARY KEY (user_id, role_id)
)@@
CREATE INDEX IF NOT EXISTS ix_adm_user_role_role ON adm_user_role (role_id)@@

-- Granular user-based permissions: ALLOW adds, DENY removes (deny always wins). Optional expiry.
CREATE TABLE IF NOT EXISTS adm_user_permission (
    user_id          UUID          NOT NULL REFERENCES adm_app_user (id) ON DELETE CASCADE,
    permission_code  VARCHAR(80)   NOT NULL REFERENCES adm_permission (code),
    effect           VARCHAR(10)   NOT NULL,               -- ALLOW | DENY
    conditional      BOOLEAN       NOT NULL DEFAULT FALSE, -- only for ALLOW
    expires_at       TIMESTAMPTZ,                          -- null = no expiry
    reason           VARCHAR(500),
    granted_by       VARCHAR(254),
    granted_date     TIMESTAMPTZ   NOT NULL DEFAULT now(),
    PRIMARY KEY (user_id, permission_code)
)@@

-- Data scope values for LOB / LOCATION level users
CREATE TABLE IF NOT EXISTS adm_user_scope (
    user_id    UUID         NOT NULL REFERENCES adm_app_user (id) ON DELETE CASCADE,
    dimension  VARCHAR(20)  NOT NULL,                      -- LOB | LOCATION
    value      VARCHAR(100) NOT NULL,
    PRIMARY KEY (user_id, dimension, value)
)@@

-- ---------- central audit log (BRD 4.21, tracker #9-14) ----------
-- ONE table for every service. Column list matches the reference digihire-platform-starter JdbcAuditLogger
-- (id, category, action, entity_type, entity_id, candidate_id, actor_id, actor_name, actor_email, actor_roles,
--  outcome, description, details, correlation_id, service_name, client_ip, occurred_at), so the central logging
-- framework can write here unchanged. Retention / sizing: DEP-S1-05.
CREATE TABLE IF NOT EXISTS adm_audit_log (
    id              UUID          PRIMARY KEY DEFAULT gen_random_uuid(),
    category        VARCHAR(30)   NOT NULL,                -- SECURITY | CONFIG_CHANGE | ACTIVITY | APPROVAL | WORKFLOW_TRANSITION
    action          VARCHAR(100)  NOT NULL,
    entity_type     VARCHAR(60),
    entity_id       VARCHAR(100),
    candidate_id    VARCHAR(100),                          -- candidate audit mapping (BRD 4.9 / 4.21)
    actor_id        VARCHAR(100),
    actor_name      VARCHAR(200),
    actor_email     VARCHAR(254),
    actor_roles     VARCHAR(500),
    outcome         VARCHAR(10)   NOT NULL DEFAULT 'SUCCESS',
    description     VARCHAR(2000),
    details         JSONB,
    correlation_id  VARCHAR(64),
    service_name    VARCHAR(60),
    client_ip       VARCHAR(64),
    occurred_at     TIMESTAMPTZ   NOT NULL DEFAULT now()
)@@
CREATE INDEX IF NOT EXISTS ix_adm_audit_occurred ON adm_audit_log (occurred_at DESC)@@
CREATE INDEX IF NOT EXISTS ix_adm_audit_entity   ON adm_audit_log (entity_type, entity_id)@@
CREATE INDEX IF NOT EXISTS ix_adm_audit_actor    ON adm_audit_log (actor_id, occurred_at DESC)@@
CREATE INDEX IF NOT EXISTS ix_adm_audit_category ON adm_audit_log (category, occurred_at DESC)@@
CREATE INDEX IF NOT EXISTS ix_adm_audit_candidate ON adm_audit_log (candidate_id, occurred_at DESC)@@
CREATE INDEX IF NOT EXISTS ix_adm_audit_correlation ON adm_audit_log (correlation_id)@@
-- existing dev databases created by the first cut of this script
ALTER TABLE adm_audit_log ADD COLUMN IF NOT EXISTS candidate_id VARCHAR(100)@@
ALTER TABLE adm_audit_log ADD COLUMN IF NOT EXISTS actor_name VARCHAR(200)@@
ALTER TABLE adm_audit_log ADD COLUMN IF NOT EXISTS actor_roles VARCHAR(500)@@
ALTER TABLE adm_audit_log ADD COLUMN IF NOT EXISTS description VARCHAR(2000)@@

-- ---------- enterprise configuration (tracker #32 "Restrict enterprise configuration to Admin") ----------
-- Plain settings only. Credentials / API keys do NOT belong here: they go to the S2 secret store (tracker #33).
CREATE TABLE IF NOT EXISTS adm_enterprise_config (
    config_key    VARCHAR(150) PRIMARY KEY,
    config_value  TEXT,
    value_type    VARCHAR(20)  NOT NULL DEFAULT 'STRING', -- STRING | NUMBER | BOOLEAN | JSON | LIST
    category      VARCHAR(60)  NOT NULL DEFAULT 'GENERAL',
    description   VARCHAR(500),
    created_date  TIMESTAMPTZ  NOT NULL DEFAULT now(),
    created_by    VARCHAR(254),
    updated_date  TIMESTAMPTZ,
    updated_by    VARCHAR(254),
    version       BIGINT       NOT NULL DEFAULT 0
)@@
CREATE INDEX IF NOT EXISTS ix_adm_config_category ON adm_enterprise_config (category)@@
