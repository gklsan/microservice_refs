# admin-services - setup and wiring

## Run it

```bash
cd admin-services
# copy mvnw, mvnw.cmd and .mvn/ from any other service so prod_deploy.sh can call ./mvnw
# smartie-common-utils must be installed first (prod_deploy.sh already does this)
./mvnw clean package
./mvnw -DskipCommonUtils test   # build and test without common-utils
java -jar target/admin-services-1.0.0.jar
```

Port 8989, context path `/admin-services`, Eureka id `admin-services`.

The integration test starts a real PostgreSQL (zonky embedded-postgres). No Docker needed.

## Swagger and calling the service

- Swagger UI: `http://localhost:8989/admin-services/swagger-ui.html` (spec: `/admin-services/openapi.yaml`, every endpoint with sample request and response).
- Token for local calls: `JWT_SECRET=<secret> ./scripts/dev-token.sh first.admin@agshealth.com`, then "Authorize" in Swagger. Dev only - it signs a token like auth-services does.
- `http/admin-services.http`: the same calls for IntelliJ HTTP Client / VS Code REST Client.
- Through the gateway the Swagger page itself sits behind AuthFilter, so use the direct port locally.

## Environment variables

| Variable | Required | Notes |
|---|---|---|
| DB_URL / DB_USERNAME / DB_PASSWORD | yes | same smartiedb as the other services, PostgreSQL 13+ |
| JWT_SECRET | yes | the same Base64 string auth-services JwtService and gateway JwtUtil use. Service refuses to start without it |
| INTERNAL_API_KEY | yes | shared key for `/internal/**`. Put the same value in every service that calls admin-services |
| BOOTSTRAP_SUPER_ADMIN_EMAILS | first deploy | comma separated. These become active SUPER_ADMINs on every start |
| ADMIN_ALLOWED_EMAIL_DOMAINS | no | e.g. `agshealth.com`. Blocks typos like `@agshealth.co` |
| EUREKA_URL | no | default `http://localhost:8761/eureka/` |
| SWAGGER_ENABLED | no | default `true`. Set `false` on production |

## Database

- `src/main/resources/db/schema-admin.sql` and `data-admin.sql` run on every start (`spring.sql.init.mode=always`).
- Every statement is idempotent. Only `adm_*` tables are touched.
- The live matrix is copied from the defaults once, guarded by `adm_schema_change('rbac-seed-v1')`. An admin removing a permission is never undone by a restart.
- To add permissions later: add rows to `data-admin.sql` and a new changeset block `rbac-seed-v2` that inserts only the new grants. Never edit v1.
- Set `ADMIN_SQL_INIT_MODE=never` if your DBA wants to run the scripts by hand.

## Gateway (gateway-services)

1. Add the route in `application.yml`:

```yaml
       - id: admin-services
         uri: lb://admin-services
         predicates:
           - Path=/admin-services/**
         filters:
           - AuthFilter
```

2. Never expose `/internal/**` through the gateway. In `AuthFilter.apply(...)`, before the token check:

```java
if (exchange.getRequest().getURI().getPath().matches("^/[^/]+/internal/.*")) {
    exchange.getResponse().setStatusCode(HttpStatus.NOT_FOUND);
    return exchange.getResponse().setComplete();
}
```

3. Watch out: `RouteValidator` uses `path.contains("/auth-services")`. A path like `/admin-services/auth-services/x` skips the AuthFilter. admin-services verifies the JWT itself, so it is safe here, but the check should become `startsWith`.

## Deploy scripts

- `prod_deploy.sh` / `run_all.sh`: add `admin-services` to the service list and `8989` to the port list and `status_all`.
- `.env.prod` / `.env.uat`: add the variables above.

## Endpoints

All paths start with `/admin-services`.

| Method | Path | Rule | Purpose |
|---|---|---|---|
| POST | /admin/users | SUPER_ADMIN + USER:MANAGE | create admin user (roles, manager, scope) |
| GET | /admin/users?search=&status=&role=&page=&size=&sort=&direction= | USER:VIEW | list / search (name, e-mail, employee code) |
| GET | /admin/users/{id} | USER:VIEW | detail |
| PUT | /admin/users/{id} | SUPER_ADMIN + USER:MANAGE | name, employee code, manager, scope. Optional `version` for 409 on stale edits |
| PATCH | /admin/users/{id}/deactivate | SUPER_ADMIN + USER:MANAGE | body `{reason}` (required) |
| PATCH | /admin/users/{id}/reactivate | SUPER_ADMIN + USER:MANAGE | body `{reason}` optional |
| PUT | /admin/users/{id}/roles | SUPER_ADMIN + USER:MANAGE | full replace |
| GET | /admin/users/{id}/permissions | USER:VIEW | user-level grants |
| PUT | /admin/users/{id}/permissions | SUPER_ADMIN + USER:MANAGE | full replace. `{grants:[{permission, effect, conditional, expiresAt, reason}]}` |
| GET | /admin/users/{id}/effective-access | USER:VIEW | every permission with its sources (role / ALLOW / DENY) |
| GET | /admin/roles | ROLE:VIEW | roles with active user count |
| POST / PUT | /admin/roles, /admin/roles/{code} | SUPER_ADMIN + ROLE:MANAGE | create / edit / retire |
| POST | /admin/roles/{code}/reset-defaults | SUPER_ADMIN + ROLE:MANAGE | back to the matrix defaults |
| GET | /admin/permissions | ROLE:VIEW | catalogue |
| GET / PUT | /admin/permission-matrix | view / SUPER_ADMIN | matrix screen |
| GET | /admin/permission-matrix/defaults?objectType=JOB | ROLE:VIEW | default permission set per object (tracker #1-3) |
| GET | /admin/config?category= | CONFIG:VIEW | enterprise settings (tracker #32) |
| POST / PUT | /admin/config, /admin/config/{key} | SUPER_ADMIN + CONFIG:MANAGE | create / change a setting, type-checked, audited |
| GET | /internal/config, /internal/config/{key} | X-Internal-Key | settings for other services |
| GET | /rbac/me | logged in | roles, permissions, conditional set, scope for menus and buttons |
| POST | /rbac/check | logged in | record-level check `{permission, ownerId, assigneeIds, lob, location}` |
| GET | /internal/rbac/effective | X-Internal-Key | for other services |
| GET | /internal/users/by-role/{code} | X-Internal-Key | e.g. notification recipients |

Every error is RFC 7807 with a `code` field. Branch on `code`, never on text: `USER_EXISTS`, `SELF_MODIFICATION_NOT_ALLOWED`, `LAST_SUPER_ADMIN`, `SUPER_ADMIN_ROLE_LOCKED`, `PRIVILEGED_PERMISSION`, `UNKNOWN_PERMISSION`, `UNKNOWN_ROLE`, `ROLE_INACTIVE`, `ROLE_NOT_ASSIGNABLE`, `INVALID_MANAGER`, `SCOPE_VALUES_REQUIRED`, `REASON_REQUIRED`, `DUPLICATE_PERMISSION`, `CONCURRENT_MODIFICATION`, `EMAIL_DOMAIN_NOT_ALLOWED`, `ACCESS_DENIED`, `UNAUTHORIZED`, `INVALID_TOKEN`, `VALIDATION_FAILED`.

## Frontend notes

- Call `GET /rbac/me` once after login and cache it. Gate menus with permissions, not with a "isSuperAdmin" flag.
- Admin user screen: roles, scope and grants are three separate saves (three endpoints, three audit events).
- Hide edit / deactivate buttons on the logged-in admin's own row. The API refuses anyway.
- Show `/effective-access` next to the grant editor so the admin sees what a DENY overrides.
- `loginLinked=false` means the person has not logged in since the account was created. Show it as "Not signed in yet".
- A change applies at once in admin-services and within 2 minutes in other services. Say so after saving.

## Rollout to the other services (next step, one at a time)

1. Put the RBAC client in smartie-common-utils (AutoConfiguration, off by default): verify JWT, call `/internal/rbac/effective`, cache 2 minutes, turn roles and permissions into authorities.
2. job-services first (fewest public paths), then candidate-services, then vendor-services.
3. For each: list its public paths, add `@PreAuthorize` per endpoint, copy `EndpointSecurityTest`, then add `AccessEvaluator` checks for conditional permissions.
